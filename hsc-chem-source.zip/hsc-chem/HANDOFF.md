# HANDOFF — notes for the next developer (or the next Claude session)

Read this first. It explains how the project is built, the content/visual conventions, how to check work,
and the planned-but-not-built features (optional login + teacher dashboard).

## 1. What this is

A Bengali-medium HSC Chemistry study app. Pure static HTML/CSS/JS, no framework, no server.
`python3 build.py` concatenates everything into:

- `dist/hsc-chemistry.html` — the whole app in one file (≈ 11.7 MB, works offline from `file://`).
- `docs/index.html` — the same file, for GitHub Pages (`/docs` folder). `docs/.nojekyll` is written too.
- `dist/index.html` + `dist/ch/<id>.js` + `dist/ch/<id>-vis.js` — a split version: core inline, one script per
  chapter. (Used when the app was hosted as a claude.ai artifact; fine for any static host too.)

All user-facing text is Bengali, using Bengali digits (`X.bn()` / `bn()` convert). Keep it that way.

## 2. Source layout

```
src/core/registry.js   window.HSC registry: HSC.chapter({...}), SEC (sections), VIS (visuals), CMPT (comparison tables)
src/core/vx.js         window.VX visual toolkit (X.fit, X.anim, X.onResize, X.C() theme colours, X.seg, X.svg,
                       periodic-table data X.PT / X.PTCAT / X.PTBLK, electron configs X.occZ / X.cfgZ / X.EXC …)
src/core/texmap.js, tex.js   TeX rendering (KaTeX + mhchem), lazy typesetting via MutationObserver
src/core/app.js        app engine: state S (localStorage), views (VIEWS.*), actions (ACT.*, data-act="…" delegation),
                       render(), go(name,args), lessons, quizzes, bank, library, settings, themes (THEMES / GLASSY)
src/core/plus.js       home sections (HSEC / HS.*), XP & levels, badges, flashcards SRS, mistakes, tests, games
src/core/plus2.js      saves (S.sv) + library, tricks, goals sheet, scoped tools (chapter/subject/all), minimal home,
                       "read" marks with verification quiz (S.done = mastered, S.self = self-marked),
                       home-arrange sheet, 48-hour delayed progress reset, global micro-interactions (enterFx, ripple, tilt)
src/core/style.css     all styles + 14 themes (glass themes need html[data-glass] + --aurora/--glass-* vars)
src/core/template.html commented template appended to the standalone file ("add new chapters here")
src/chapters/<id>/chapter.js        chapter metadata + optional book outline
src/chapters/<id>/content/sNN.js    sections: SEC.push({...}) and CMPT.push({...})
src/chapters/<id>/visuals*.js       visuals: V.key = {...}; files load in name order (visuals1…9, then visualsa)
```

`app.js` contains the marker `/*@@PLUS@@*/`; build.py replaces it with plus.js + plus2.js, so those run inside
the same BOOT closure and can use S, VIEWS, ACT, render, go, LMAP, SMAP, MCQ, CHAPTERS, CH, SECS, etc.

## 3. Content schema (one section)

```js
SEC.push({ id, no, sym, cat, w, t, st, intro, exam,
  L: [ /* lessons */ { id, no, t, ov, dp, sc, fx, ap, cm, tr, sn, mh, mf, cf, ho, xm, xs, v } ],
  Q: { mcq, sq, cq, bq, aq, nq, hq, wp },   // question bank
  F,  // flashcards  [front, back]
  FM  // formulas     [name, tex, note]
});
CMPT.push({ g, t, l, k });   // comparison table: k must equal an <h4> text in lesson l, followed by a .table-wrap
```

- Lesson exercise MCQ ids become `lessonId + 'x' + i`; bank MCQ ids `sectionId + 'm' + i`.
  MCQ objects: `{ id, sid, q, o:[4 options], a, d:'e'|'m'|'h', x: explanation, l: lessonId }`.
- `wp` (written practice) = 5 items `[marks, question, modelAnswer, scheme, commonMistake]`, marks 2/3/5/7/10
  (except sections with `cat: 'E'`). The UI groups them into the board's four levels
  (জ্ঞানমূলক, অনুধাবনমূলক, প্রয়োগমূলক, উচ্চতর দক্ষতামূলক) — see `wpLevel()` in app.js.
- `w` = exam weight; the section page shows it as 1–5 stars (`starN()` clamps; some 2nd-paper chapters use up to 12).
- Inline maths/chemistry in content strings: `{m|…}` inline TeX, `{M|…}` display TeX, `{ce|…}` / `{CE|…}` mhchem.
  Outside those blocks never write raw `X_y`; use `X<sub>y</sub>` (`tools/qa/subfix.py --apply` converts).

## 4. Visual API

```js
V.key = { t: 'title', k: ['2d'|'3d'|'anim'|'int'|'calc'|'info'], cap: 'caption',
          html: () => '<markup>', mount(el) { /* … */ return () => cleanup(); } };
```

Use `X.C()` for theme colours (never hard-code light-only colours), `X.anim(el, step)` for animation loops (pauses
off-screen and in reduced-motion mode), `X.onResize`. Keep labels short on phones (test at 360 px).
Example of a large, polished visual: `src/chapters/c3/visuals7.js` (Figure 3.1, interactive periodic table —
property heat-maps, cursor "dock" magnification, touch-drag magnifier, Bohr model, orbital boxes).

## 5. Checks (run before publishing)

```bash
python3 build.py
node tools/check.js <chapterId>      # structure, ids, CMPT keys, wp marks, answer distribution
node tools/balance.js <chapterId>    # rebalance MCQ answer positions, then rebuild
python3 tools/qa/subfix.py [--apply] # find/fix raw underscores outside TeX blocks
# browser checks (need Node + Playwright: npm i playwright && npx playwright install chromium)
node tools/qa/allles.js <chapterId>  # opens every lesson, reports runtime errors
node tools/qa/txcheck.js <chapterId> # TeX render errors
node tools/qa/ovf.js                 # horizontal overflow at 360 px
node tools/qa/txtcheck.js            # raw underscores in rendered text
node tools/qa/crawl.js               # opens every section page, bank tab, quiz and tool view in all chapters
node tools/qa/figshot.js '["c3_ptable"]' 375 glass 2500   # screenshot one visual (width, theme, wait ms)
```

All six chapters currently pass: no structural problems, 0 runtime errors, no 360 px overflow.

## 6. Conventions worth keeping

- Phone first: everything must work at 360 px; tables scroll inside a box; touch targets ≥ 44 px.
- Cheap phones: animate only transform/opacity, throttle pointer work with requestAnimationFrame, stop loops
  off-screen, respect `html[data-motion="reduce"]` and `prefers-reduced-motion`.
- Default theme: Glass Aurora (`glass`). All themes unlocked.
- Progress honesty: `S.done[id]` = mastered (passed a 3-question check or read long enough), `S.self[id]` = self-marked.
  XP, progress % and badges count only mastered lessons.
- Everything is stored in localStorage (`S`). The app also looks for an optional `window.claude` runtime
  (artifact hosting) for cloud saving; on GitHub Pages it is simply absent and the app runs locally.

## 7. Planned, not built: optional login + teacher dashboard

Goal: students may optionally sign in so their progress is saved; the owner sees all students in a dashboard.

Suggested design (GitHub Pages + Firebase, free tier):

1. Firebase project → Authentication (Google provider) → Firestore. Add `<user>.github.io` to authorised domains.
   The web config object is public by design; security comes from Firestore rules.
2. Student app: a "লগইন করে অগ্রগতি সংরক্ষণ করো" button (optional; the app must keep working without it).
   On sign-in, write ONE summary document per student, debounced (on lesson done / every few minutes), e.g.
   `students/{uid}` = `{ nick, batch, updatedAt, progressPct, mastered, self, mcqAcc, streak, xp,
   chapters: {c2: pct, …}, weekMinutes: [7], weakTopics: {sid: wrongCount} }`. Do not store phone numbers or addresses.
3. Rules: a student can read/write only `students/{own uid}`; only the admin uid can read the collection.
4. `docs/admin.html`: sign in with the owner's Google account; KPIs (total, active today/week, average progress,
   accuracy, mastered lessons), daily-active chart, comparison table (sortable, searchable, row → detail),
   chapter heat-map, most-missed topics, weekly awards, CSV export.
   A visual mock-up of this dashboard was made earlier (sample data only).
5. Privacy (many users are under 18): login optional, say clearly what is stored and why, nickname on
   leaderboards, a "delete my data" button, parental consent where appropriate.
