const APP = require('path').resolve(__dirname, '../../dist/hsc-chemistry.html');
const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:375,height:780}});let errs=[];p.on('pageerror',e=>errs.push('PE '+e.message));p.on('console',m=>{if(m.type()==='error'&&!/ERR_TUNNEL|Failed to load resource/.test(m.text()))errs.push('CE '+m.text().slice(0,300))});
await p.goto('file://' + APP);await p.waitForTimeout(2500);
const act=(o)=>p.evaluate(o=>{const b=document.createElement('button');for(const k in o)b.dataset[k]=o[k];document.body.appendChild(b);b.click();b.remove()},o);
const clean=()=>p.evaluate(()=>{const c=document.getElementById('celebrate');c&&c.remove();const s=document.getElementById('sheetWrap');s&&s.remove()});
const bad=[];let n=0;const chk=async(tag)=>{n++;const t=await p.evaluate(()=>document.querySelector('#tbTitle').textContent);await clean();if(t==='ত্রুটি'||errs.length)bad.push([tag,t,errs.join(' | ').slice(0,300)]);errs=[];};
for(const ch of ['c2','c3','c4','p2c1','p2c2','p2c3']){
 await act({act:'chOpen',id:ch});await p.waitForTimeout(500);
 const sids=await p.evaluate(()=>[...document.querySelectorAll('details.sa')].map(d=>d.dataset.sid));
 for(const sid of sids){await act({act:'sec',id:sid});await p.waitForTimeout(150);await chk(ch+' sec '+sid);
  for(const tab of ['mcq','cq','wp']){await act({act:'bank',id:sid,tab});await p.waitForTimeout(120);await chk(ch+' bank '+sid+' '+tab);}
  await act({act:'quiz',id:sid,mode:'all'});await p.waitForTimeout(150);await chk(ch+' quiz '+sid);}
 // other chapter lesson from this chapter (cross-open)
}
await act({act:'chOpen',id:'c2'});await p.waitForTimeout(400);
for(const v of ['figures','formulas','compare']){await act({act:'go',v});await p.waitForTimeout(200);await act({act:'scope',k:'all'});await p.waitForTimeout(800);await chk('all '+v);
 if(v==='figures'){await p.evaluate(()=>document.getElementById('figAll').click());await p.waitForTimeout(8000);await chk('all figAll');
  const ls=await p.$$eval('#figList [data-act="lesson"]',e=>e.slice(-3).map(x=>x.dataset.id));for(const id of ls){await act({act:'lesson',id});await p.waitForTimeout(500);await chk('cross lesson '+id);await act({act:'go',v:'figures'});await p.waitForTimeout(300);}}}
await act({act:'go',v:'search'});await p.waitForTimeout(300);
console.log('checked',n);console.log(JSON.stringify(bad,null,1));await b.close()})()
