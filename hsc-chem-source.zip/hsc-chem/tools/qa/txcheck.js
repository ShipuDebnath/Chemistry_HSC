const APP = require('path').resolve(__dirname, '../../dist/hsc-chemistry.html');
const { chromium } = require('playwright');
(async () => {
  const cid = process.argv[2];
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 390, height: 844 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(500);
  const ids = await p.evaluate(cid => { APP.setCh(cid); return APP.LESSONS.filter(l => l.ch === cid).map(l => l.id); }, cid);
  const views = ids.map(id => ['lesson', { id }]).concat([['formulas', {}], ['compare', {}], ['revision', {}]]);
  const sids = await p.evaluate(cid => APP.SECS.filter(s => s.ch === cid).map(s => s.id), cid);
  sids.forEach(sid => views.push(['bank', { id: sid, tab: 'cq' }], ['bank', { id: sid, tab: 'mcq' }], ['bank', { id: sid, tab: 'wp' }], ['section', { sid }]));
  for (const [v, a] of views) {
    await p.evaluate(([v, a]) => APP.go(v, a), [v, a]); await p.waitForTimeout(150);
    await p.evaluate(() => { document.querySelectorAll('details').forEach(d => d.open = true); document.querySelectorAll('.reveal-btn,[data-act=reveal]').forEach(x => { try { x.click(); } catch (e) { } }); }); await p.waitForTimeout(120);
    const r = await p.evaluate(() => { const t = document.querySelector('#app').innerText; const m = t.match(/\{(ce|m|CE|M)\|[^}]{0,40}/g); return { raw: m ? m.slice(0, 3) : null, w: document.documentElement.scrollWidth }; });
    if (r.raw || r.w > 390) console.log(v, JSON.stringify(a), JSON.stringify(r));
  }
  console.log('TX errors:', JSON.stringify(await p.evaluate(() => (TX.errors || []).slice(0, 8))), errs.slice(0, 5));
  await b.close();
})();
