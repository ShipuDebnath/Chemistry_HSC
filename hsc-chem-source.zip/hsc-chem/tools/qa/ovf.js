const APP = require('path').resolve(__dirname, '../../dist/hsc-chemistry.html');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 360, height: 760 } });
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(500);
  const ids = await p.evaluate(() => APP.LESSONS.map(l => l.id));
  const bad = [];
  for (const id of ids) {
    await p.evaluate(id => { const l = APP.LESSONS.find(x => x.id === id); APP.setCh(l.ch); APP.go('lesson', { id }); }, id); await p.waitForTimeout(150);
    await p.evaluate(async () => { for (let y = 0; y < document.body.scrollHeight; y += 700) { window.scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); } });
    await p.waitForTimeout(200);
    const r = await p.evaluate(() => { const W = document.documentElement.clientWidth; const out = []; if (document.documentElement.scrollWidth > W + 2) out.push('PAGE ' + document.documentElement.scrollWidth); document.querySelectorAll('.fig').forEach(f => { if (f.scrollWidth > f.clientWidth + 2) out.push('FIG ' + f.dataset.vis + ' ' + f.scrollWidth + '/' + f.clientWidth); }); return out; });
    if (r.length) bad.push([id, r]);
  }
  console.log(JSON.stringify(bad));
  await b.close();
})();
