import re,glob,sys
apply='--apply' in sys.argv
pat=re.compile(r'(?<![A-Za-z0-9_\\])(p?[A-Za-zμ])_(rms|mp|atm|hi|lo|STP|IS|CO|eq|av|max|min|obs|tot|mix|net|cell|sol|[A-Za-z][0-9]?|[0-9]{1,2})(?![{])')
tot=0
for f in sorted(glob.glob('src/chapters/*/content/*.js')):
  s=open(f).read(); out=[]; i=0; n=len(s); cnt=0
  while i<n:
    m=re.compile(r'\{(m|M|ce|CE)\|').search(s,i)
    j=m.start() if m else n
    seg=s[i:j]
    def rep(mm):
      global cnt
      return f'{mm.group(1)}<sub>{mm.group(2)}</sub>'
    new,c=pat.subn(rep,seg); cnt+=c
    if c and not apply:
      for mm in pat.finditer(seg): print(f, repr(seg[max(0,mm.start()-25):mm.end()+10]))
    out.append(new)
    if not m: break
    # skip math block with brace matching
    k=m.end(); d=1
    while k<n and d: 
      if s[k]=='{': d+=1
      elif s[k]=='}': d-=1
      k+=1
    out.append(s[j:k]); i=k
  tot+=cnt
  if apply and cnt: open(f,'w').write(''.join(out))
print('total',tot)
