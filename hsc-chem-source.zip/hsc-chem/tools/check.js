/* node tools/check.js c3  — content statistics + structural checks for one chapter (reads dist/ch) */
const fs = require('fs'), vm = require('vm'), path = require('path');
const R = path.join(__dirname, '..');
const ctx = { console, Proxy, Math, JSON, Object, Array, String, Number, Set, Map };
ctx.window = ctx; ctx.document = { addEventListener() {} }; ctx.getComputedStyle = () => ({ getPropertyValue: () => '' });
vm.createContext(ctx);
const run = f => vm.runInContext(fs.readFileSync(f, 'utf8'), ctx, { filename: f });
run(path.join(R, 'src/core/registry.js')); run(path.join(R, 'src/core/vx.js'));
const order = fs.readdirSync(path.join(R, 'src/chapters')).sort();
for (const c of order) { const f = path.join(R, 'dist/ch', c + '.js'), v = path.join(R, 'dist/ch', c + '-vis.js'); if (fs.existsSync(f)) run(f); if (fs.existsSync(v)) run(v); }
const cid = process.argv[2] || 'c3';
const S = ctx.SEC.filter(s => s.ch === cid);
const B = ['ov', 'dp', 'sc', 'fx', 'ap', 'cm', 'tr', 'sn', 'mh', 'mf', 'cf', 'ho'];
const words = h => String(h || '').replace(/<[^>]+>/g, ' ').split(/\s+/).filter(Boolean).length;
let ans = [0, 0, 0, 0], diff = { e: 0, m: 0, h: 0 }, multi = 0, nM = 0, probs = [], ids = new Set(), tot = { L: 0, xm: 0, xs: 0, sq: 0, cq: 0, bq: 0, aq: 0, nq: 0, hq: 0, wp: 0, F: 0, FM: 0, vis: new Set() };
const chkM = (m, where) => {
  nM++;
  if (!Array.isArray(m) || !Array.isArray(m[1]) || m[1].length !== 4 || !(m[2] >= 0 && m[2] <= 3)) { probs.push(where + ' bad MCQ'); return; }
  ans[m[2]]++; diff[m[3]] = (diff[m[3]] || 0) + 1; if (!['e', 'm', 'h'].includes(m[3])) probs.push(where + ' diff ' + m[3]);
  if (/i ও ii/.test(m[1].join('|'))) multi++;
  if (!m[4]) probs.push(where + ' no explanation');
  if (new Set(m[1]).size !== 4) probs.push(where + ' duplicate options');
};
const rows = [];
for (const s of S) {
  if (ids.has(s.id)) probs.push('dup id ' + s.id); ids.add(s.id);
  for (const l of s.L) {
    tot.L++; if (ids.has(l.id)) probs.push('dup id ' + l.id); ids.add(l.id);
    const miss = B.filter(k => !l[k] || (Array.isArray(l[k]) && !l[k].length));
    if (miss.length) probs.push(l.id + ' missing ' + miss.join(','));
    (l.v || []).forEach(k => { tot.vis.add(k); if (!ctx.VIS[k]) probs.push(l.id + ' visual missing ' + k); });
    if (!(l.v || []).length) probs.push(l.id + ' no visual');
    (l.xm || []).forEach((m, i) => chkM(m, l.id + ' xm' + i)); tot.xm += (l.xm || []).length; tot.xs += (l.xs || []).length;
    rows.push([l.id, l.no, (l.xm || []).length, (l.xs || []).length, words(l.ov), words(l.dp), words(l.sc), (l.fx || []).length, (l.v || []).join(',')]);
  }
  const Q = s.Q || {}; (Q.mcq || []).forEach((m, i) => { chkM(m, s.id + ' mcq' + i); if (m[5] && !s.L.some(l => l.id === m[5])) probs.push(s.id + ' mcq' + i + ' lesson ' + m[5]); });
  for (const k of ['sq', 'cq', 'bq', 'aq', 'nq', 'hq', 'wp']) tot[k] += (Q[k] || []).length;
  (Q.cq || []).forEach((c, i) => { if (!c.s || !c.p || c.p.length !== 4) probs.push(s.id + ' cq' + i + ' shape'); });
  if ((Q.wp || []).map(w => w[0]).join(',') !== '2,3,5,7,10' && s.cat !== 'E') probs.push(s.id + ' wp marks ' + (Q.wp || []).map(w => w[0]).join(','));
  if ((Q.cq || []).length < 2) probs.push(s.id + ' cq<2');
  tot.F += (s.F || []).length; tot.FM += (s.FM || []).length;
  if ((s.F || []).length < 8) probs.push(s.id + ' flashcards ' + (s.F || []).length);
}
ctx.CMPT.filter(c => c.ch === cid).forEach(c => { if (!ids.has(c.l)) { probs.push('CMPT lesson ' + c.l); return; } if (c.k) { let L0 = null; ctx.SEC.forEach(s => (s.L || []).forEach(l => { if (l.id === c.l) L0 = l; })); const src = L0 ? ['dp', 'sc', 'fx'].map(k => typeof L0[k] === 'string' ? L0[k] : '').join('') : ''; const i = src.indexOf('<h4>' + c.k + '</h4>'); if (i < 0 || src.indexOf('<div class="table-wrap"', i) < 0) probs.push('CMPT table not found: ' + c.k); } });
if (process.argv.includes('-v')) rows.forEach(r => console.log(r.join('\t')));
const pct = a => a.map(x => Math.round(100 * x / (nM || 1)) + '%').join(' ');
console.log(`${cid}: ${S.length} sections, ${tot.L} lessons, MCQ ${nM} (lesson ${tot.xm}), short ${tot.xs}+${tot.sq}, cq ${tot.cq}, bq ${tot.bq}, aq ${tot.aq}, nq ${tot.nq}, hq ${tot.hq}, wp ${tot.wp}, F ${tot.F}, FM ${tot.FM}, visuals used ${tot.vis.size}`);
console.log(`answers ক খ গ ঘ: ${ans.join(' ')} (${pct(ans)}) · diff e/m/h: ${diff.e}/${diff.m}/${diff.h} · multi-statement ${multi} (${Math.round(100 * multi / (nM || 1))}%)`);
console.log(probs.length ? 'PROBLEMS (' + probs.length + '):\n' + probs.slice(0, 80).join('\n') : 'no problems');
