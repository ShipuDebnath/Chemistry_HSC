/* ২য় পত্র অধ্যায় ১ visuals part 15 — arsenic: aquifer source, speciation, detection & removal (1.21) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const asOfDepth = d => d < 8 ? 0.01 + d * 0.004 : d < 120 ? 0.04 + 0.28 * Math.exp(-((d - 35) ** 2) / (2 * 22 * 22)) : d < 150 ? 0.02 * (150 - d) / 30 + 0.004 : 0.004;

/* ======================= জলাধারে আর্সেনিকের উৎস ======================= */
V.p2c1_arsenicSource = {
  t: 'আর্সেনিকের ভূতাত্ত্বিক উৎস: হলোসিন পলিতে অণুজীব দ্বারা FeOOH এর বিজারক দ্রবণে আর্সেনিক মুক্তি এবং নলকূপের গভীরতার প্রভাব', k: ['anim', 'int', '2d', 'calc'],
  cap: 'মাটির নিচের প্রস্থচ্ছেদ: উপরে ধূসর হলোসিন বালি ও পলি (কালো জৈব পদার্থের স্তরসহ), নিচে কাদার স্তর ও বাদামি প্লাইস্টোসিন বালি। বালিকণার কমলা প্রলেপ FeOOH, তাতে আটকে থাকা লাল বিন্দু আর্সেনিক। সবুজ অণুজীব জৈব পদার্থ খেয়ে FeOOH বিজারিত করে — কমলা প্রলেপ মিলিয়ে যায়, Fe²⁺ (নীল) ও As (লাল) পানিতে মুক্ত হয়ে নলকূপে আসে। নলকূপের গভীরতা স্লাইডারে বদলাও; ডানে গভীরতা বনাম আর্সেনিকের লেখচিত্র (প্রতিনিধিত্বমূলক) এবং নলকূপের মাথার রং (লাল/সবুজ)।',
  html: () => `${X.cv('আর্সেনিকের উৎস')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:180px">নলকূপের গভীরতা = <b data-dv></b> m<input type="range" min="10" max="250" step="5" value="35" data-d></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 520;
    let L = X.fit(c, hf), depth = 35, t = 0; const Rn = X.rng(33);
    const grains = Array.from({ length: 70 }, () => ({ x: Rn(), y: Rn(), r: 4 + Rn() * 4, fe: 1, as: 2 + Math.floor(Rn() * 3) }));
    let ions = [];
    const DMAX = 260;
    const step = dt => { t += dt; grains.forEach(gr => { const d = gr.y * DMAX; const zone = d > 10 && d < 110; if (zone && gr.fe > 0 && Rn() < dt * 0.05 * (1 - Math.abs(d - 40) / 80)) { gr.fe = Math.max(0, gr.fe - 0.25); if (gr.as > 0 && Rn() < 0.7) { gr.as--; ions.push({ k: 'as', x: gr.x, y: gr.y, life: 0 }); } ions.push({ k: 'fe', x: gr.x, y: gr.y, life: 0 }); } if (!zone && gr.fe < 1) gr.fe = Math.min(1, gr.fe + dt * 0.02); if (zone && gr.fe <= 0 && Rn() < dt * 0.02) { gr.fe = 1; gr.as = 2; } });
      ions.forEach(i => { i.life += dt; i.x += (Rn() - .5) * dt * 0.02; i.y += (Rn() - .5) * dt * 0.01; }); ions = ions.filter(i => i.life < 6); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const sx = 10, sw = wd ? W * 0.58 : W - 20, sy = 26, sh = wd ? H - 36 : H * 0.6; const dY = d => sy + d / DMAX * sh;
      // surface
      g.fillStyle = '#7fb069'; g.fillRect(sx, sy - 8, sw, 8);
      // layers
      [[0, 8, '#a89a7a', 'পলি মাটি'], [8, 110, '#9a9ea3', 'হলোসিন ধূসর বালি (বিজারক)'], [110, 140, '#7a6a5a', 'কাদার স্তর'], [140, DMAX, '#c8a060', 'প্লাইস্টোসিন বাদামি বালি (জারক)']].forEach(([a, b, cl, nm]) => { g.fillStyle = cl; g.fillRect(sx, dY(a), sw, dY(b) - dY(a)); g.fillStyle = 'rgba(255,255,255,.85)'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'right'; g.fillText(nm, sx + sw - 6, dY(a) + 13); });
      g.fillStyle = 'rgba(30,25,20,.55)'; [[20, 3], [48, 4], [75, 3]].forEach(([d, h]) => { g.fillRect(sx, dY(d), sw * 0.85, h); }); g.fillStyle = 'rgba(255,255,255,.75)'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('জৈব পদার্থ (পিট)', sx + 6, dY(20) - 2);
      // grains
      grains.forEach(gr => { const x = sx + 10 + gr.x * (sw - 20), y = dY(gr.y * DMAX); if (y < sy + 2) return; const pl = gr.y * DMAX > 140; g.fillStyle = pl ? '#e8d0a0' : '#d8d8d8'; g.beginPath(); g.arc(x, y, gr.r, 0, 7); g.fill(); if (gr.fe > 0) { g.strokeStyle = `rgba(210,110,30,${0.3 + 0.7 * gr.fe})`; g.lineWidth = 2.2; g.beginPath(); g.arc(x, y, gr.r, 0, 7); g.stroke(); } for (let k = 0; k < gr.as; k++) { const a = k * 2.1 + gr.x * 9; g.fillStyle = '#c0392b'; g.beginPath(); g.arc(x + Math.cos(a) * gr.r, y + Math.sin(a) * gr.r, 1.6, 0, 7); g.fill(); } });
      // microbes
      for (let k = 0; k < 12; k++) { const d = 15 + (k * 7.7) % 90, x = sx + 20 + ((k * 0.17 + t * 0.01) % 1) * (sw - 40), y = dY(d) + Math.sin(t + k) * 3; g.save(); g.translate(x, y); g.rotate(k + t * 0.5); g.fillStyle = '#2f9e44'; rr(g, -4, -1.5, 8, 3, 1.5); g.fill(); g.restore(); }
      // ions
      ions.forEach(i => { const x = sx + 10 + i.x * (sw - 20), y = dY(i.y * DMAX); g.globalAlpha = Math.max(0, 1 - i.life / 6); g.fillStyle = i.k === 'as' ? '#ff3b2b' : '#2d6fd6'; g.beginPath(); g.arc(x, y, i.k === 'as' ? 2.4 : 2, 0, 7); g.fill(); g.globalAlpha = 1; });
      // tube well
      const wx = sx + sw * 0.42, wy = dY(depth); const As = asOfDepth(depth), safe = As <= 0.05; g.fillStyle = '#666'; g.fillRect(wx - 3, sy - 30, 6, wy - sy + 30); g.fillStyle = 'rgba(255,255,255,.4)'; for (let y = wy - 14; y < wy; y += 3) g.fillRect(wx - 3, y, 6, 1.5);
      g.fillStyle = safe ? '#2f9e44' : '#c0392b'; g.fillRect(wx - 10, sy - 34, 20, 12); g.fillStyle = '#555'; g.fillRect(wx + 10, sy - 30, 14, 4); g.fillRect(wx - 26, sy - 32, 16, 3);
      const fl = (t * 3) % 1; g.fillStyle = safe ? 'rgba(120,180,240,.9)' : 'rgba(220,120,90,.9)'; g.beginPath(); g.arc(wx + 24, sy - 24 + fl * 14, 2.5, 0, 7); g.fill();
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`${bn(depth)} m`, wx + 8, wy + 4);
      // depth profile
      const gx0 = wd ? W * 0.68 : 50, gy0 = wd ? sy : sy + sh + 30, gw = wd ? W * 0.29 : W - 66, gh = wd ? sh - 30 : H - gy0 - 40;
      if (wd) { const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 0.35, ymax: DMAX, col, xt: [0, 0.1, 0.2, 0.3], yt: [], xl: 'As (mg L⁻¹)' }); const Yd = d => gy0 + d / DMAX * gh; [0, 50, 100, 150, 200, 250].forEach(d => { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText(bn(d), gx0 - 4, Yd(d) + 3); }); const pts = []; for (let d = 0; d <= DMAX; d += 2) pts.push([Pl.X(asOfDepth(d)), Yd(d)]); path(g, pts, '#c0392b', 2.2); path(g, [[Pl.X(0.05), gy0], [Pl.X(0.05), gy0 + gh]], '#e0a020', 1, [4, 3]); path(g, [[Pl.X(0.01), gy0], [Pl.X(0.01), gy0 + gh]], '#2f9e44', 1, [2, 3]); ball(g, Pl.X(As), Yd(depth), 5, '#c0392b', '#fff'); g.fillStyle = '#e0a020'; g.font = `8.5px ${col.font}`; g.textAlign = 'left'; g.fillText('BD ০.০৫', Pl.X(0.05) + 2, gy0 + gh - 4); g.fillStyle = '#2f9e44'; g.fillText('WHO', Pl.X(0.01) + 2, gy0 + gh - 16); g.save(); g.translate(gx0 - 28, gy0 + gh / 2); g.rotate(-Math.PI / 2); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('গভীরতা (m) ↓', 0, 0); g.restore(); }
      else { const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: DMAX, ymax: 0.35, col, xt: [0, 50, 100, 150, 200, 250], yt: [0, 0.1, 0.2, 0.3], xl: 'গভীরতা (m)', yl: 'As (mg L⁻¹)', fy: v => bn(v.toFixed(1)) }); const pts = []; for (let d = 0; d <= DMAX; d += 2) pts.push([Pl.X(d), Pl.Y(asOfDepth(d))]); path(g, pts, '#c0392b', 2.2); path(g, [[gx0, Pl.Y(0.05)], [gx0 + gw, Pl.Y(0.05)]], '#e0a020', 1, [4, 3]); ball(g, Pl.X(depth), Pl.Y(As), 5, '#c0392b', '#fff'); }
    };
    const info = () => { q('[data-dv]').textContent = bn(depth); const As = asOfDepth(depth);
      out.innerHTML = `<div>নলকূপের পানিতে আর্সেনিক ≈ <b>${bn(As.toFixed(3))} mg L⁻¹</b> — ${As <= 0.01 ? '<span style="color:var(--ok)">নিরাপদ (WHO মান পূরণ)</span>, মাথা সবুজ।' : As <= 0.05 ? 'বাংলাদেশের মানের মধ্যে কিন্তু WHO এর চেয়ে বেশি — সবুজ, তবে সতর্কতা।' : '<span style="color:var(--bad)">অনিরাপদ</span> — মাথা লাল; পান ও রান্নায় নিষেধ।'}</div>` + TXB('\\ce{4FeOOH + CH2O + 7H2CO3 -> 4Fe^2+ + 8HCO3- + 6H2O}') + `<div class="small">${depth < 110 ? 'হলোসিন ধূসর বালি: জৈব পদার্থ ও অণুজীব FeOOH বিজারিত করছে — শোষিত As মুক্ত।' : depth < 145 ? 'কাদার স্তর: অভেদ্য, উপরের দূষিত পানি নিচে নামতে বাধা দেয়।' : 'প্লাইস্টোসিন বাদামি বালি: FeOOH অক্ষত, As তার পৃষ্ঠে আটকে — সাধারণত নিরাপদ। তবে অতিরিক্ত পানি তুললে উপরের পানি টেনে আনার ঝুঁকি।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    q('[data-d]').oninput = e => { depth = +e.target.value; info(); A.draw(); };
    for (let i = 0; i < 200; i++) step(0.05);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= আর্সেনিকের রূপ বণ্টন (pH) ======================= */
const frac = (pH, pks) => { const h = Math.pow(10, -pH); const K = pks.map(p => Math.pow(10, -p)); const terms = [1]; let prod = 1; K.forEach(k => { prod *= k / h; terms.push(prod); }); const s = terms.reduce((a, b) => a + b, 0); return terms.map(x => x / s); };
V.p2c1_arsenicSpecies = {
  t: 'আর্সেনিকের রূপ বণ্টন চিত্র: pH এর সাথে আর্সেনাইট (As(III)) ও আর্সেনেট (As(V)) এর আয়নিক রূপ এবং Fe(OH)₃ পৃষ্ঠে শোষণ', k: ['int', 'calc', '2d', 'anim'],
  cap: 'উপরের লেখচিত্রে As(V) (H₃AsO₄ → H₂AsO₄⁻ → HAsO₄²⁻ → AsO₄³⁻; pKa ২.২, ৬.৯৭, ১১.৫), নিচেরটিতে As(III) (H₃AsO₃ → H₂AsO₃⁻; pKa ৯.২) এর প্রতিটি রূপের ভগ্নাংশ। সবুজ পটি প্রাকৃতিক পানির pH (৬.৫–৮.৫)। pH স্লাইডার টানো — ডানে Fe(OH)₃ কণার ধনাত্মক পৃষ্ঠের (pH < ~৮) দিকে ঋণাত্মক আর্সেনেট আকৃষ্ট হয়, কিন্তু চার্জহীন H₃AsO₃ ভেসে বেড়ায়। "জারণ" বোতামে As(III) → As(V) রূপান্তর দেখো।',
  html: () => `${X.cv('আর্সেনিকের রূপ')}<div class="ctl"><label class="small" style="flex:1;min-width:180px">pH = <b data-pv></b><input type="range" min="2" max="12" step="0.1" value="7.2" data-p></label><button class="btn sm" data-ox>জারণ (Cl₂/KMnO₄)</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 560;
    let L = X.fit(c, hf), pH = 7.2, ox = 0, t = 0; const Rn = X.rng(44); const mols = Array.from({ length: 22 }, (_, i) => ({ x: Rn(), y: Rn(), k: i < 18 ? 3 : 5, ad: 0 }));
    const P5 = [2.2, 6.97, 11.5], P3 = [9.2, 12.1, 13.4];
    const N5 = ['H₃AsO₄', 'H₂AsO₄⁻', 'HAsO₄²⁻', 'AsO₄³⁻'], N3 = ['H₃AsO₃', 'H₂AsO₃⁻', 'HAsO₃²⁻', 'AsO₃³⁻'], CC = ['#7d8590', '#2d6fd6', '#7b3fa0', '#c0392b'];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const gw = wd ? W * 0.55 - 60 : W - 66, gx0 = 50; const gh = wd ? (H - 90) / 2 : 120;
      [[P5, N5, 'As(V) — আর্সেনেট', 16], [P3, N3, 'As(III) — আর্সেনাইট', 16 + gh + 44]].forEach(([pk, nm, title, gy0]) => { const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: 2, xmax: 12, ymax: 1, col, xt: [2, 4, 6, 8, 10, 12], yt: [0, 0.5, 1], xl: 'pH', fy: v => bn(v) }); g.fillStyle = 'rgba(47,158,68,.12)'; g.fillRect(Pl.X(6.5), gy0, Pl.X(8.5) - Pl.X(6.5), gh);
        for (let i = 0; i < 4; i++) { const pts = []; for (let p = 2; p <= 12; p += 0.05) pts.push([Pl.X(p), Pl.Y(frac(p, pk)[i])]); if (pts.some(pp => pp[1] < gy0 + gh - 2)) path(g, pts, CC[i], 2.2); }
        path(g, [[Pl.X(pH), gy0], [Pl.X(pH), gy0 + gh]], col.fg, 1, [3, 3]); g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(title, gx0 + 4, gy0 - 4);
        const f = frac(pH, pk); const items = f.map((v, i) => [CC[i], `${nm[i]} ${bn(Math.round(v * 100))}%`]).filter((_, i) => f[i] > 0.005 || i < 2); legend(g, col, gx0 + gw, gy0 + 2, items.slice(0, 3), true); });
      // micro panel
      const mx = wd ? W * 0.6 : 10, my = wd ? 16 : 16 + 2 * gh + 80, mw = wd ? W * 0.38 : W - 20, mh = wd ? H - 32 : H - my - 10; g.fillStyle = col.sf; g.strokeStyle = col.line || col.mu; g.lineWidth = 1; rr(g, mx, my, mw, mh, 10); g.fill(); g.stroke();
      const fx0 = mx + mw / 2, fy0 = my + mh / 2, fr = Math.min(mw, mh) * 0.17; const pzc = 8.0, surf = pH < pzc - 0.3 ? '+' : pH > pzc + 0.3 ? '−' : '০';
      const gg = g.createRadialGradient(fx0 - fr * 0.3, fy0 - fr * 0.3, 2, fx0, fy0, fr); gg.addColorStop(0, '#e0904a'); gg.addColorStop(1, '#8a4a1a'); g.fillStyle = gg; g.beginPath(); g.arc(fx0, fy0, fr, 0, 7); g.fill(); for (let k = 0; k < 10; k++) { const a = k * Math.PI / 5; g.fillStyle = '#fff'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(surf, fx0 + Math.cos(a) * (fr - 8), fy0 + Math.sin(a) * (fr - 8) + 4); } g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.fillText('Fe(OH)₃', fx0, fy0 + 4);
      mols.forEach(m => { const x = mx + 10 + m.x * (mw - 20), y = my + 10 + m.y * (mh - 20); const charged = m.k === 5 ? frac(pH, P5)[0] < 0.5 : frac(pH, P3)[0] < 0.5; ball(g, x, y, 5.5, m.k === 5 ? (charged ? '#7b3fa0' : '#7d8590') : '#c0392b', '#fff'); g.fillStyle = '#fff'; g.font = `bold 7px ${col.font}`; g.textAlign = 'center'; g.fillText(m.k === 5 ? 'V' : 'III', x, y + 2.5); if (m.k === 5 && charged) { g.fillStyle = col.fg; g.font = `bold 8px ${col.font}`; g.fillText('−', x + 7, y - 4); } });
      g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`পৃষ্ঠ চার্জ: ${surf === '+' ? 'ধনাত্মক' : surf === '−' ? 'ঋণাত্মক' : 'শূন্য'} (শূন্য চার্জ বিন্দু ~pH ৮)`, mx + 8, my + mh - 8);
    };
    const step = dt => { t += dt; const { W, H } = L; const charged5 = frac(pH, P5)[0] < 0.5; const attract = pH < 7.7 ? 1 : pH < 8.3 ? 0.3 : -0.3;
      mols.forEach(m => { if (ox && m.k === 3 && Rn() < dt * 0.6) m.k = 5; const dx = 0.5 - m.x, dy = 0.5 - m.y, d = Math.hypot(dx, dy) + 1e-3; const pull = m.k === 5 && charged5 ? attract * 0.12 : 0; if (m.ad && pull <= 0) m.ad = 0; if (!m.ad) { m.x += (Rn() - .5) * dt * 0.15 + dx / d * pull * dt; m.y += (Rn() - .5) * dt * 0.15 + dy / d * pull * dt; } if (d < 0.2 && pull > 0) m.ad = 1; m.x = Math.max(0.03, Math.min(0.97, m.x)); m.y = Math.max(0.03, Math.min(0.97, m.y)); }); };
    const info = () => { q('[data-pv]').textContent = bn(pH.toFixed(1)); q('[data-ox]').classList.toggle('primary', !!ox); const f5 = frac(pH, P5), f3 = frac(pH, P3); const ads = mols.filter(m => m.ad).length, tot = mols.length;
      out.innerHTML = TXB(`\\dfrac{[\\ce{H2AsO3-}]}{[\\ce{H3AsO3}]} = 10^{${pH.toFixed(1)}-9.2} = ${Math.pow(10, pH - 9.2).toExponential(1).replace('e', '\\times10^{') + '}'}`) + `<div class="small">pH ${bn(pH.toFixed(1))} এ As(III) এর ${bn(Math.round(f3[0] * 100))}% চার্জহীন H₃AsO₃; As(V) এর ${bn(Math.round((1 - f5[0]) * 100))}% ঋণাত্মক আয়ন। ${pH > 8.3 ? 'Fe(OH)₃ পৃষ্ঠ এখন ঋণাত্মক — আর্সেনেটও বিকর্ষিত, শোষণ কমে যায়।' : 'ধনাত্মক Fe(OH)₃ পৃষ্ঠে কেবল ঋণাত্মক আর্সেনেট (বেগুনি) আটকে যাচ্ছে।'} ${!ox ? 'জারণ বোতাম চাপো — লাল As(III) গুলো As(V) এ রূপান্তরিত হয়ে শোষিত হবে।' : `পৃষ্ঠে শোষিত: ${bn(ads)}/${bn(tot)}।`}</div>`; };
    const A = X.anim(el, dt => { if (dt) { step(Math.min(dt, 0.05)); if (Math.floor(t * 4) !== Math.floor((t - dt) * 4)) info(); } draw(); }, { paused: false });
    q('[data-p]').oninput = e => { pH = +e.target.value; info(); A.draw(); };
    q('[data-ox]').onclick = () => { ox = ox ? 0 : 1; if (!ox) mols.forEach((m, i) => { m.k = i < 18 ? 3 : 5; m.ad = 0; }); info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= আর্সেনিক পরীক্ষা ও অপসারণ ======================= */
V.p2c1_arsenicFilter = {
  t: 'আর্সেনিক শনাক্তকরণ ও অপসারণ: গুটজাইট মাঠ পরীক্ষা কিট, তিন-কলসি ফিল্টার এবং শোষণ কলামের ব্রেকথ্রু বক্ররেখা', k: ['anim', 'int', 'calc', '2d'],
  cap: '"পরীক্ষা কিট": নমুনায় জিংক ও এসিড দিলে আর্সিন গ্যাস (AsH₃) উঠে HgBr₂ কাগজে রং দেয় — নমুনার আর্সেনিক বদলে রং চার্টের সাথে মেলাও। "তিন-কলসি": উপরের কলসিতে লোহা-বালি (জারণ ও শোষণ), মাঝে কাঠকয়লা-বালি, নিচে নিরাপদ পানি — লাল বিন্দু (As) ধাপে ধাপে কমে। "ব্রেকথ্রু": একটি আয়রন অক্সাইড ফিল্টার দিয়ে যত বেশি পানি যায়, শোষণ পৃষ্ঠ তত সম্পৃক্ত হয়; নির্গত পানিতে As হঠাৎ বাড়ার বিন্দুতে মাধ্যম বদলাতে হবে। কাঁচা পানির আর্সেনিক ও মাধ্যমের ভর বদলে আয়ু হিসাব করো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('af', [['kit', 'পরীক্ষা কিট'], ['pot', 'তিন-কলসি'], ['bt', 'ব্রেকথ্রু']], 'kit')}</div>${X.cv('আর্সেনিক অপসারণ')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:130px">কাঁচা পানিতে As = <b data-av></b> mg L⁻¹<input type="range" min="0" max="0.5" step="0.01" value="0.2" data-a></label><label class="small" style="flex:1;min-width:130px" data-ml>মাধ্যম = <b data-mv></b> kg<input type="range" min="1" max="20" step="1" value="10" data-m></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 420;
    let L = X.fit(c, hf), md = 'kit', As0 = 0.2, mkg = 10, t = 0, P = []; const Rn = X.rng(51); const QMAX = 2, DAILY = 40;
    const KIT = [[0, '#f8f4e0'], [0.01, '#f5eab0'], [0.05, '#f0d870'], [0.1, '#e8b840'], [0.2, '#c88a30'], [0.5, '#8a5020']];
    const kitCol = a => { for (let i = 1; i < KIT.length; i++) if (a <= KIT[i][0]) { const [x0, c0] = KIT[i - 1], [x1, c1] = KIT[i]; const u = (a - x0) / (x1 - x0); const h = s => [1, 3, 5].map(j => parseInt(s.substr(j, 2), 16)); const A0 = h(c0), A1 = h(c1); return `rgb(${A0.map((v, k) => Math.round(v + (A1[k] - v) * u)).join(',')})`; } return KIT[5][1]; };
    const potOut = a => [a, a * 0.12, a * 0.04];
    const btC = V0 => { const cap = mkg * 1000 * QMAX; const Vb = cap / (As0 - 0.005 + 1e-9); const x = V0 / Vb; return As0 / (1 + Math.exp(-(x - 1) * 9)) + 0.003; };
    const step = dt => { t += dt; if (md === 'pot') { if (Rn() < dt * 8) P.push({ s: 0, y: 0, x: 0.3 + Rn() * 0.4, as: Rn() < As0 / 0.5 * 1.5 }); P.forEach(p => { p.y += dt * 0.25; if (p.y > 1) { p.y = 0; p.s++; if (p.as) { const keep = p.s === 1 ? 0.12 : p.s === 2 ? 0.33 : 1; if (Rn() > keep) p.as = false; } } }); P = P.filter(p => p.s < 3); } };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 'kit') { const bx = wd ? W * 0.18 : W * 0.25, by = 50, bw = 70, bh = H * 0.55; g.fillStyle = 'rgba(160,200,240,.35)'; rr(g, bx - bw / 2, by + 30, bw, bh - 30, 10); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 2; rr(g, bx - bw / 2, by, bw, bh, 10); g.stroke(); g.fillStyle = '#ccc'; g.fillRect(bx - bw / 2 - 4, by - 10, bw + 8, 12);
          for (let k = 0; k < 18; k++) { const x = bx - bw / 2 + 8 + ((k * 0.29) % 1) * (bw - 16), y = by + bh - ((t * 30 + k * 13) % (bh - 30)); g.strokeStyle = 'rgba(255,255,255,.8)'; g.beginPath(); g.arc(x, y, 2, 0, 7); g.stroke(); if (k % 3 === 0 && As0 > 0) { g.fillStyle = '#c0392b'; g.beginPath(); g.arc(x + 3, y - 2, 1.5, 0, 7); g.fill(); } }
          const prog = Math.min(1, t / 6); const pc = kitCol(As0 * prog); g.fillStyle = '#fff'; g.strokeStyle = col.fg; g.lineWidth = 1; g.fillRect(bx - 12, by - 52, 24, 40); g.strokeRect(bx - 12, by - 52, 24, 40); g.fillStyle = pc; g.beginPath(); g.arc(bx, by - 32, 9, 0, 7); g.fill();
          g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('নমুনা + Zn + এসিড', bx, by + bh + 16); g.font = `9.5px ${col.font}`; g.fillText('HgBr₂ কাগজ', bx + 42, by - 30);
          const cx0 = wd ? W * 0.42 : 14, cy0 = wd ? 60 : by + bh + 34, cw = wd ? W * 0.52 : W - 28; g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('রং চার্ট (µg L⁻¹)', cx0, cy0 - 10); KIT.forEach(([a, cc], i) => { const x = cx0 + i * cw / 6 + cw / 12; g.fillStyle = cc; g.strokeStyle = col.fg; g.beginPath(); g.arc(x, cy0 + 18, 13, 0, 7); g.fill(); g.stroke(); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(a * 1000), x, cy0 + 46); });
          if (prog >= 1) { let best = 0; KIT.forEach(([a], i) => { if (Math.abs(a - As0) < Math.abs(KIT[best][0] - As0)) best = i; }); const x = cx0 + best * cw / 6 + cw / 12; g.strokeStyle = col.acc; g.lineWidth = 2.5; g.beginPath(); g.arc(x, cy0 + 18, 17, 0, 7); g.stroke(); } }
      else if (md === 'pot') { const px = wd ? W * 0.28 : W / 2, ph = (H - 40) / 3, pw = wd ? 110 : 100; const lab = [['লোহার গুঁড়ো + মোটা বালি', '#b06030'], ['কাঠকয়লা + মিহি বালি', '#444'], ['নিরাপদ পানি', '#8ac0f0']]; const conc = potOut(As0);
          lab.forEach(([nm, cl], i) => { const y = 14 + i * ph; g.fillStyle = 'rgba(190,120,70,.55)'; g.beginPath(); g.ellipse(px, y + ph * 0.5, pw / 2, ph * 0.42, 0, 0, 7); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.stroke(); g.fillStyle = cl; g.globalAlpha = 0.7; g.beginPath(); g.ellipse(px, y + ph * 0.62, pw * 0.38, ph * 0.18, 0, 0, 7); g.fill(); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = wd ? 'left' : 'center'; if (wd) g.fillText(`${bn(i + 1)}. ${nm}`, px + pw / 2 + 12, y + ph * 0.45); g.font = `10px ${col.font}`; const cv = i === 0 ? As0 : conc[i]; if (wd) { g.fillStyle = cv > 0.05 ? '#c0392b' : cv > 0.01 ? '#e0a020' : '#2f9e44'; g.fillText(`${i === 0 ? 'আগত' : 'নির্গত'} As: ${bn(cv.toFixed(3))} mg L⁻¹`, px + pw / 2 + 12, y + ph * 0.45 + 15); } });
          P.forEach(p => { const y = 14 + p.s * ph + ph * 0.15 + p.y * ph * 0.7, x = px - pw * 0.35 + p.x * pw * 0.7; g.fillStyle = p.as ? '#ff3b2b' : 'rgba(120,180,240,.9)'; g.beginPath(); g.arc(x, y, p.as ? 2.6 : 2, 0, 7); g.fill(); }); }
      else { const gx0 = 54, gy0 = 18, gw = W - 70, gh = H - 64; const cap = mkg * 1000 * QMAX, Vb = cap / (As0 - 0.005 + 1e-9), Vmax = Math.max(20000, Vb * 1.8); const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: Vmax / 1000, ymax: Math.max(0.1, As0 * 1.1), col, xt: [0, 0.25, 0.5, 0.75, 1].map(f => +(f * Vmax / 1000).toFixed(0)), yt: [0, 0.05, Math.max(0.1, As0)].map(v => +v.toFixed(2)), xl: 'শোধিত পানির আয়তন (×১০০০ L)', yl: 'নির্গত As (mg L⁻¹)', fy: v => bn(v.toFixed(2)) });
          path(g, [[gx0, Pl.Y(0.05)], [gx0 + gw, Pl.Y(0.05)]], '#e0a020', 1, [4, 3]); path(g, [[gx0, Pl.Y(0.01)], [gx0 + gw, Pl.Y(0.01)]], '#2f9e44', 1, [2, 3]); path(g, [[gx0, Pl.Y(As0)], [gx0 + gw, Pl.Y(As0)]], col.mu, 1, [6, 3]);
          const pts = []; for (let v = 0; v <= Vmax; v += Vmax / 300) pts.push([Pl.X(v / 1000), Pl.Y(btC(v))]); path(g, pts, '#c0392b', 2.4);
          let vb = 0; for (let v = 0; v <= Vmax; v += Vmax / 2000) if (btC(v) > 0.01) { vb = v; break; } ball(g, Pl.X(vb / 1000), Pl.Y(0.01), 5, '#2f9e44', '#fff');
          const vNow = (t * Vmax / 12) % Vmax; ball(g, Pl.X(vNow / 1000), Pl.Y(btC(vNow)), 4, '#c0392b', '#fff');
          g.fillStyle = '#2f9e44'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('WHO ০.০১', gx0 + 4, Pl.Y(0.01) - 3); g.fillStyle = '#e0a020'; g.fillText('BD ০.০৫', gx0 + 4, Pl.Y(0.05) - 3); g.fillStyle = col.mu; g.fillText('কাঁচা পানি', gx0 + 4, Pl.Y(As0) - 3); }
    };
    const info = () => { q('[data-av]').textContent = bn(As0.toFixed(2)); q('[data-mv]').textContent = bn(mkg); q('[data-ml]').style.display = md === 'bt' ? '' : 'none';
      if (md === 'kit') out.innerHTML = TXB('\\ce{H3AsO3 + 3Zn + 6H+ -> AsH3 ^ + 3Zn^2+ + 3H2O}') + `<div class="small">${t < 6 ? 'আর্সিন উঠছে… (২০ মিনিটের পরীক্ষা সংক্ষেপে দেখানো)' : `কাগজের রং চার্টের প্রায় ${bn(Math.round(KIT.reduce((b, k) => Math.abs(k[0] - As0) < Math.abs(b[0] - As0) ? k : b)[0] * 1000))} µg L⁻¹ এর সাথে মেলে।`} সতর্কতা: AsH₃ অত্যন্ত বিষাক্ত — খোলা জায়গায় পরীক্ষা করতে হয়। কিট আধা-পরিমাণগত; সীমার কাছাকাছি মানে পরীক্ষাগারে নিশ্চিত হতে হয়।</div>`;
      else if (md === 'pot') { const o = potOut(As0)[2]; out.innerHTML = TXB('\\ce{Fe -> Fe^2+ -> Fe(OH)3}') + TXB('\\equiv\\ce{FeOH + H2AsO4- ->}\\ \\equiv\\ce{FeHAsO4- + H2O}') + `<div class="small">আগত ${bn(As0.toFixed(2))} → নির্গত <b>${bn(o.toFixed(3))} mg L⁻¹</b> (~৯৬% অপসারণ) — ${o <= 0.01 ? 'WHO মানও পূরণ।' : o <= 0.05 ? 'বাংলাদেশের মান পূরণ।' : 'এখনো অনিরাপদ — উৎস বদলানো জরুরি।'} উপরের কলসির লোহা As(III) কে As(V) এ জারিত করে Fe(OH)₃ পৃষ্ঠে আটকায়; মাঝের কাঠকয়লা ও বালি অবশিষ্ট ফ্লক ও লোহা আটকায়।</div>`; }
      else { const cap = mkg * 1000 * QMAX; let vb = 0; const Vmax = Math.max(20000, cap / (As0 - 0.005 + 1e-9) * 1.8); for (let v = 0; v <= Vmax; v += Vmax / 2000) if (btC(v) > 0.01) { vb = v; break; } out.innerHTML = TXB(`t = \\dfrac{m\\,q_{\\max}}{V(C_0 - C)} \\approx \\dfrac{${mkg * 1000}\\times${QMAX}}{${DAILY}\\times(${As0.toFixed(2)} - 0.01)}`) + `<div class="small">মাধ্যমের ধারণক্ষমতা ${bn(cap / 1000)} g As। নির্গত পানি WHO সীমা (০.০১) ছাড়ায় প্রায় <b>${bn(Math.round(vb / 1000))} হাজার লিটার</b> পরে — দৈনিক ${bn(DAILY)} L এ প্রায় <b>${bn((vb / DAILY / 365).toFixed(1))} বছর</b>। এর আগেই মাধ্যম বদলাও ও পুরনো মাধ্যম নিরাপদে নিষ্কাশন করো।</div>`; } };
    const A = X.anim(el, dt => { if (dt) { step(Math.min(dt, 0.05)); if (md === 'kit' && t < 6.2 && Math.floor(t) !== Math.floor(t - dt)) info(); } draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'af', k => { md = k; t = 0; P = []; info(); A.draw(); });
    q('[data-a]').oninput = e => { As0 = +e.target.value; if (md === 'kit') t = 0; info(); A.draw(); };
    q('[data-m]').oninput = e => { mkg = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
