/* ২য় পত্র অধ্যায় ১ visuals part 8 — air pollutants, smog, AQI, catalytic converter (1.10) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };

/* ======================= দূষকের উৎস: শহরের দৃশ্য ও উষ্ণতা বৈপরীত্য ======================= */
const PCOL = { CO: ['#555', '#bbb'], SO2: ['#d6b21e', '#fff2a8'], NOx: ['#a8541e', '#ffc9a0'], PM: ['#3a3a3a', '#8a8a8a'], VOC: ['#2f9e44', '#c8f0cf'], Pb: ['#6a5acd', '#d6d0ff'] };
const PNAME = { CO: 'CO', SO2: 'SO₂', NOx: 'NOx', PM: 'PM₂.₅/ঝুল', VOC: 'VOC', Pb: 'Pb' };
const SRC = [
  ['car', 'যানবাহন', 0.16, { CO: 3, NOx: 3, VOC: 2, PM: 1 }, 'অসম্পূর্ণ দহনে CO ও হাইড্রোকার্বন, উচ্চ তাপমাত্রায় N₂ + O₂ → 2NO, ডিজেল ইঞ্জিনে ঝুল (কালো কার্বন)।'],
  ['kiln', 'ইটভাটা', 0.4, { PM: 4, SO2: 3, CO: 2 }, 'নিম্নমানের কয়লা ও কাঠ পোড়ানো: সালফার থেকে SO₂ (S + O₂ → SO₂), অসম্পূর্ণ দহনে CO ও প্রচুর কালো ধোঁয়া — ঢাকার শীতকালীন PM₂.₅ এর সবচেয়ে বড় উৎস।'],
  ['plant', 'বিদ্যুৎকেন্দ্র/কারখানা', 0.64, { SO2: 3, NOx: 2, PM: 2 }, 'কয়লা/তেলভিত্তিক বিদ্যুৎকেন্দ্র — SO₂ ও NOx; সিমেন্ট ও স্টিল কারখানা — ধুলা। স্ক্রাবার ও ইলেকট্রোস্ট্যাটিক প্রেসিপিটেটর দিয়ে নিয়ন্ত্রণ সম্ভব।'],
  ['batt', 'ব্যাটারি রিসাইক্লিং', 0.86, { Pb: 3, PM: 1, SO2: 1 }, 'অনানুষ্ঠানিক সীসা-এসিড ব্যাটারি গলানো — সীসার ধোঁয়া, যা শিশুদের স্নায়ুতন্ত্রের মারাত্মক ক্ষতি করে।']
];
V.p2c1_pollutants = {
  t: 'শহরের বায়ু দূষকের উৎস ও উষ্ণতা বৈপরীত্যে দূষক আটকে যাওয়া (অ্যানিমেশন)', k: ['anim', 'int', '2d', 'info'],
  cap: 'চারটি উৎস — যানবাহন, ইটভাটা, বিদ্যুৎকেন্দ্র ও ব্যাটারি রিসাইক্লিং — থেকে রঙিন কণায় বিভিন্ন দূষক বের হচ্ছে (রঙের সংকেত নিচে)। একটি উৎস বেছে নিলে তার ধোঁয়া উজ্জ্বল হয় ও বিবরণ দেখায়। "শীতের রাত" বেছে নিলে উষ্ণতা বৈপরীত্য দেখা যায়: ডানের তাপমাত্রা-উচ্চতা রেখায় উষ্ণ স্তর ঢাকনার মতো ধোঁয়াকে নিচে আটকে রাখে, তাই ভূপৃষ্ঠে ঘনত্ব (উপরের মিটার) কয়েক গুণ বেড়ে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('wx', [['day', 'গ্রীষ্মের দুপুর'], ['inv', 'শীতের রাত (বৈপরীত্য)']], 'inv')}</div>${X.cv('শহরের বায়ু দূষণ')}<div class="ctl" style="flex-wrap:wrap">${SRC.map(s => `<button class="btn sm" data-src="${s[0]}">${s[1]}</button>`).join('')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 340 : 380;
    let L = X.fit(c, hf), wx = 'inv', sel = 'kiln', t = 0, conc = 0;
    const Rn = X.rng(3); let P = [];
    const spawn = (s, i) => { const keys = Object.entries(s[3]).flatMap(([k, n]) => Array(n).fill(k)); return { s: s[0], k: keys[Math.floor(Rn() * keys.length)], x: s[2] + (Rn() - .5) * 0.02, y: 0, vx: (Rn() - .5) * 0.02, vy: 0.08 + Rn() * 0.05, age: 0 }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const sceneW = wd ? W * 0.78 : W, gy = H * 0.82, capY = wx === 'inv' ? H * 0.42 : -1e9;
      const sky = g.createLinearGradient(0, 0, 0, gy); if (wx === 'inv') { sky.addColorStop(0, '#1b2238'); sky.addColorStop(1, '#4a4f63'); } else { sky.addColorStop(0, '#5f9fe0'); sky.addColorStop(1, '#cfe4f7'); } g.fillStyle = sky; g.fillRect(0, 0, sceneW, gy);
      if (wx === 'inv') { g.fillStyle = 'rgba(255,180,120,.13)'; g.fillRect(0, capY - 18, sceneW, 30); g.strokeStyle = 'rgba(255,170,110,.8)'; g.setLineDash([6, 4]); g.lineWidth = 1.4; g.beginPath(); g.moveTo(0, capY); g.lineTo(sceneW, capY); g.stroke(); g.setLineDash([]); g.fillStyle = '#ffd2a8'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('উষ্ণ বায়ুর স্তর (ঢাকনা)', 8, capY - 6); g.fillStyle = '#e8e8f0'; g.beginPath(); g.arc(sceneW * 0.85, H * 0.12, 10, 0, 7); g.fill(); }
      else { g.fillStyle = '#ffd84a'; g.beginPath(); g.arc(sceneW * 0.85, H * 0.12, 16, 0, 7); g.fill(); }
      // haze overlay proportional to trapped particles
      const nlow = P.filter(p => p.y < (gy - capY) / H + 0.05).length; conc = conc * 0.97 + 0.03 * nlow; if (wx === 'inv') { g.fillStyle = `rgba(120,110,100,${Math.min(0.35, conc / 900)})`; g.fillRect(0, capY, sceneW, gy - capY); }
      g.fillStyle = '#5b5040'; g.fillRect(0, gy, sceneW, H - gy);
      // sources
      SRC.forEach(([id, nm, xf]) => { const x = xf * sceneW, on = id === sel; g.globalAlpha = on ? 1 : 0.75;
        if (id === 'car') { for (let k = 0; k < 3; k++) { const cx = x - 34 + k * 26 + ((t * 18) % 26), cy = gy - 10; g.fillStyle = ['#c0392b', '#2d6fd6', '#e0a020'][k]; rr(g, cx - 10, cy - 7, 20, 9, 3); g.fill(); g.fillStyle = '#222'; g.beginPath(); g.arc(cx - 6, cy + 3, 2.6, 0, 7); g.arc(cx + 6, cy + 3, 2.6, 0, 7); g.fill(); } }
        else if (id === 'kiln') { g.fillStyle = '#8a3b22'; g.fillRect(x - 22, gy - 16, 44, 16); g.fillStyle = '#6b2e1a'; g.fillRect(x - 5, gy - 62, 10, 48); for (let k = 0; k < 4; k++) { g.fillStyle = '#b5533a'; g.fillRect(x - 30 + k * 4, gy - 6 - k * 4, 12, 4); } }
        else if (id === 'plant') { g.fillStyle = '#7d8590'; g.fillRect(x - 24, gy - 30, 30, 30); g.fillStyle = '#9aa2ad'; g.fillRect(x + 8, gy - 58, 9, 58); g.fillStyle = '#c0392b'; g.fillRect(x + 8, gy - 58, 9, 4); }
        else { g.fillStyle = '#6a5a4a'; g.fillRect(x - 16, gy - 20, 32, 20); g.fillStyle = '#4a3e33'; g.fillRect(x - 3, gy - 36, 6, 18); }
        g.globalAlpha = 1; g.fillStyle = on ? '#fff' : 'rgba(255,255,255,.75)'; g.font = `${on ? 'bold ' : ''}${wd ? 10 : 9}px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x, H - 6); });
      // particles
      const srcY = { car: 14, kiln: 62, plant: 58, batt: 36 };
      P.forEach(p => { const x = p.x * sceneW, y = gy - srcY[p.s] - p.y * H; const [c1, c2] = PCOL[p.k]; g.globalAlpha = (p.s === sel ? 1 : 0.35) * Math.max(0, 1 - p.age / 14); ball(g, x, y, p.s === sel ? 3.2 : 2.4, c1, c2); }); g.globalAlpha = 1;
      // profile panel
      if (wd) { const px = sceneW + 10, pw = W - px - 8; g.fillStyle = col.sf; g.fillRect(px, 0, pw, gy); g.strokeStyle = col.mu; g.lineWidth = 1; g.strokeRect(px, 0, pw, gy);
        g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('উচ্চতা ↑', px + pw / 2, 12); g.fillText('তাপমাত্রা →', px + pw / 2, gy - 6);
        const pts = []; for (let y = gy - 18; y >= 20; y -= 4) { const h = (gy - 18 - y) / (gy - 38); let T; if (wx === 'inv') T = h < 0.45 ? 0.25 + h * 1.2 : 0.79 - (h - 0.45) * 0.9; else T = 0.85 - h * 0.7; pts.push([px + 8 + T * (pw - 16), y]); } path(g, pts, '#d06a1e', 2.4);
        g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText(wx === 'inv' ? 'বৈপরীত্য' : 'স্বাভাবিক', px + 4, 26); }
      // meter
      const lvl = Math.min(1, conc / (wx === 'inv' ? 420 : 420)); const mx = 10, my = 10, mw = Math.min(150, sceneW * 0.4); g.fillStyle = 'rgba(0,0,0,.45)'; rr(g, mx, my, mw, 24, 6); g.fill(); const mg = g.createLinearGradient(mx, 0, mx + mw, 0); mg.addColorStop(0, '#2f9e44'); mg.addColorStop(0.35, '#e0c020'); mg.addColorStop(0.65, '#d0402b'); mg.addColorStop(1, '#7e2a8e'); g.fillStyle = mg; g.fillRect(mx + 4, my + 15, (mw - 8) * lvl, 5); g.fillStyle = '#fff'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`ভূপৃষ্ঠের দূষণ: ${lvl < 0.3 ? 'কম' : lvl < 0.6 ? 'মাঝারি' : 'উচ্চ'}`, mx + 5, my + 11);
    };
    const step = dt => { t += dt; if (Rn() < dt * 40) SRC.forEach(s => { if (Rn() < 0.6) P.push(spawn(s)); });
      const capH = (L.H * 0.82 - L.H * 0.42) / L.H; P.forEach(p => { p.age += dt; p.x += p.vx * dt + (Rn() - .5) * 0.004; if (wx === 'inv') { if (p.y < capH - 0.22) p.y += p.vy * dt; else { p.y += (Rn() - .5) * 0.01; p.vx += (Rn() - .5) * 0.01; } } else { p.y += p.vy * dt * 1.6; p.vx += (Rn() - .5) * 0.004; } });
      P = P.filter(p => p.age < (wx === 'inv' ? 14 : 8) && p.x > -0.05 && p.x < 1.05 && p.y < 1); };
    const info = () => { const s = SRC.find(x => x[0] === sel); el.querySelectorAll('[data-src]').forEach(b => b.classList.toggle('primary', b.dataset.src === sel)); out.innerHTML = `<div><b>${s[1]}:</b> ${Object.keys(s[3]).map(k => `<span style="display:inline-flex;align-items:center;gap:3px;margin-right:8px"><span style="width:9px;height:9px;border-radius:50%;background:${PCOL[k][0]};border:1px solid #999;display:inline-block"></span>${PNAME[k]}</span>`).join('')}</div><div class="small" style="margin-top:4px">${s[4]}</div><div class="small" style="margin-top:4px">${wx === 'inv' ? '<b>শীতের রাত:</b> ভূপৃষ্ঠ দ্রুত ঠান্ডা — নিচের বায়ু উপরের চেয়ে ঠান্ডা ও ভারী, উপরে উঠতে পারে না; দূষক নিচে জমে ঘন ধোঁয়াশা।' : '<b>গ্রীষ্মের দুপুর:</b> ভূপৃষ্ঠ গরম — উষ্ণ দূষিত বায়ু উপরে উঠে ছড়িয়ে পড়ে (তবে রোদে আলোক-রাসায়নিক O₃ তৈরি হয়)।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false });
    X.onSeg(el, 'wx', k => { wx = k; info(); });
    el.querySelectorAll('[data-src]').forEach(b => { b.onclick = () => { sel = b.dataset.src; info(); A.draw(); }; });
    for (let i = 0; i < 400; i++) step(0.03);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= আলোক-রাসায়নিক ধোঁয়াশা: দিনের NO, NO₂, O₃ ======================= */
function smogRun(traffic, voc, sun) {
  let NO = 5, NO2 = 10, O3 = 30; const dt = 0.004, out = [];
  const em = t => traffic * (6 + 90 * Math.exp(-((t - 8) ** 2) / 2.2) + 40 * Math.exp(-((t - 18.5) ** 2) / 2.5));
  const jf = t => { const s = Math.sin(Math.PI * (t - 6) / 12); return s > 0 ? 30 * sun * s : 0; };
  const dil = t => 0.25 + 0.35 * Math.max(0, Math.sin(Math.PI * (t - 7) / 12));
  for (let day = 0; day < 3; day++) for (let i = 0; i < 24 / dt; i++) { const t = i * dt, j = jf(t), kv = 0.12 * voc * (j / 30); const r1 = j * NO2, r3 = 1.6 * O3 * NO, rv = kv * NO * 40, d = dil(t);
    NO += (em(t) * 0.9 + r1 - r3 - rv - d * NO) * dt; NO2 += (em(t) * 0.1 - r1 + r3 + rv - d * (NO2 - 2) - 0.05 * NO2 * j / 30) * dt; O3 += (r1 - r3 - d * (O3 - 35)) * dt;
    if (day === 2 && i % 25 === 0) out.push([t, NO, NO2, O3, j / 30]); }
  return out;
}
V.p2c1_smog = {
  t: 'আলোক-রাসায়নিক ধোঁয়াশা: সারাদিনে NO, NO₂ ও O₃ এর ঘনত্বের পরিবর্তন (গতিবিদ্যা মডেল)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'একটি ব্যস্ত শহরের ২৪ ঘণ্টা: সকালের যানজটে প্রথমে NO (নীল) এর চূড়া, তারপর NO₂ (বাদামি), আর দুপুরের রোদে O₃ (বেগুনি) এর চূড়া। সময় চলার সাথে বাম দিকের আকাশের রং NO₂ এর ঘনত্ব অনুযায়ী বাদামি হয়। স্লাইডারে যানবাহনের সংখ্যা, হাইড্রোকার্বন (VOC) এর মাত্রা ও রোদ বদলাও — VOC শূন্যের কাছে নিলে ওজোন প্রায় জমে না, কারণ O₃ + NO → NO₂ + O₂ বিক্রিয়ায় তা খরচ হয়ে যায়।',
  html: () => `${X.cv('ধোঁয়াশার দৈনিক চক্র')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:110px">যানবাহন ×<b data-a1></b><input type="range" min="0.3" max="2" step="0.1" value="1" data-s1></label><label class="small" style="flex:1;min-width:110px">VOC ×<b data-a2></b><input type="range" min="0" max="2" step="0.1" value="1" data-s2></label><label class="small" style="flex:1;min-width:110px">রোদ ×<b data-a3></b><input type="range" min="0.2" max="1.2" step="0.1" value="1" data-s3></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 470;
    let L = X.fit(c, hf), tr = 1, voc = 1, sun = 1, D = smogRun(1, 1, 1), hr = 6;
    const at = h => D[Math.min(D.length - 1, Math.max(0, Math.round(h / 0.1)))];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), d = at(hr);
      const sw = wd ? W * 0.3 : W, sh = wd ? H - 20 : 150;
      // sky scene
      const day = d[4] > 0, sk = g.createLinearGradient(0, 0, 0, sh); const br = Math.min(1, d[2] / 70); if (day) { sk.addColorStop(0, `rgb(${Math.round(95 + 70 * br)},${Math.round(160 - 40 * br)},${Math.round(225 - 120 * br)})`); sk.addColorStop(1, `rgb(${Math.round(205 + 20 * br)},${Math.round(225 - 60 * br)},${Math.round(245 - 140 * br)})`); } else { sk.addColorStop(0, '#141a2e'); sk.addColorStop(1, '#3a3f55'); }
      g.fillStyle = sk; g.fillRect(0, 0, sw, sh);
      const sa = Math.PI * (hr - 6) / 12; if (day) { const sx = sw * (0.1 + 0.8 * (hr - 6) / 12), sy = sh * 0.75 - Math.sin(sa) * sh * 0.6; g.fillStyle = '#ffd84a'; g.beginPath(); g.arc(sx, sy, 12, 0, 7); g.fill(); g.strokeStyle = 'rgba(255,216,74,.5)'; g.lineWidth = 2; for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; g.beginPath(); g.moveTo(sx + Math.cos(a) * 15, sy + Math.sin(a) * 15); g.lineTo(sx + Math.cos(a) * 21, sy + Math.sin(a) * 21); g.stroke(); } }
      g.fillStyle = '#3d3d48'; for (let k = 0; k < 7; k++) { const bh = 20 + ((k * 37) % 30); g.fillRect(k * sw / 7 + 2, sh - 16 - bh, sw / 7 - 4, bh); }
      g.fillStyle = '#555'; g.fillRect(0, sh - 16, sw, 16); const ncar = Math.round(at(hr)[1] / 8 * 1 + 1); for (let k = 0; k < Math.min(10, ncar); k++) { g.fillStyle = ['#c0392b', '#2d6fd6', '#e0a020', '#eee'][k % 4]; g.fillRect(((k * 0.13 + hr * 0.07) % 1) * sw, sh - 12, 12, 6); }
      g.fillStyle = '#fff'; g.font = `bold 12px ${col.font}`; g.textAlign = 'left'; const hh = Math.floor(hr), mm = Math.floor((hr - hh) * 60); g.fillText(`${bn(hh)}:${bn(String(mm).padStart(2, '0'))}`, 8, 18);
      // chart
      const gx0 = wd ? sw + 52 : 50, gy0 = wd ? 18 : sh + 22, gw = wd ? W - gx0 - 14 : W - 64, gh = wd ? H - 62 : H - sh - 66;
      const ymax = Math.max(100, Math.ceil(Math.max(...D.map(r => Math.max(r[1], r[2], r[3]))) / 25) * 25);
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 24, ymax, col, xt: [0, 6, 12, 18, 24], yt: [0, ymax / 4, ymax / 2, 3 * ymax / 4, ymax], xl: 'দিনের সময় (ঘণ্টা)', yl: 'ঘনত্ব (ppb)', fy: v => bn(Math.round(v)) });
      // sunlight band
      g.fillStyle = 'rgba(255,210,60,.12)'; g.fillRect(Pl.X(6), gy0, Pl.X(18) - Pl.X(6), gh);
      [[1, '#2d6fd6', 'NO'], [2, '#a8541e', 'NO₂'], [3, '#7b3fa0', 'O₃']].forEach(([i, cl]) => path(g, D.map(r => [Pl.X(r[0]), Pl.Y(r[i])]), cl, 2.4));
      g.strokeStyle = col.fg; g.lineWidth = 1; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(Pl.X(hr), gy0); g.lineTo(Pl.X(hr), gy0 + gh); g.stroke(); g.setLineDash([]);
      [[1, '#2d6fd6'], [2, '#a8541e'], [3, '#7b3fa0']].forEach(([i, cl]) => ball(g, Pl.X(hr), Pl.Y(d[i]), 4.5, cl, '#fff'));
      legend(g, col, gx0 + gw, gy0 + 2, [['#2d6fd6', `NO ${bn(Math.round(d[1]))}`], ['#a8541e', `NO₂ ${bn(Math.round(d[2]))}`], ['#7b3fa0', `O₃ ${bn(Math.round(d[3]))}`]], true);
    };
    const info = () => { q('[data-a1]').textContent = bn(tr.toFixed(1)); q('[data-a2]').textContent = bn(voc.toFixed(1)); q('[data-a3]').textContent = bn(sun.toFixed(1));
      const pk = i => D.reduce((a, r) => r[i] > a[i] ? r : a, D[0]); const pNO = pk(1), pNO2 = pk(2), pO3 = pk(3);
      out.innerHTML = `<div class="small">চূড়া: NO ${bn(Math.round(pNO[1]))} ppb (${bn(Math.round(pNO[0]))} টা), NO₂ ${bn(Math.round(pNO2[2]))} ppb (${bn(Math.round(pNO2[0]))} টা), O₃ <b>${bn(Math.round(pO3[3]))} ppb</b> (${bn(Math.round(pO3[0]))} টা)। ${pO3[3] > 70 ? 'O₃ এর ৮ ঘণ্টার মানদণ্ড ৭০ ppb ছাড়িয়েছে — "অস্বাস্থ্যকর" ধোঁয়াশা দিন।' : 'O₃ মানদণ্ডের (৭০ ppb) নিচে।'}</div>` + TXB('\\ce{NO2 ->[h\\nu] NO + O},\\quad \\ce{O + O2 -> O3}') + TXB('\\ce{O3 + NO -> NO2 + O2}') + `<div class="small">${voc < 0.3 ? 'VOC প্রায় নেই: তৃতীয় বিক্রিয়ায় যত O₃ তৈরি হয় প্রায় তত খরচ — একটি "ফটোস্টেশনারি" সাম্য।' : 'VOC থেকে তৈরি RO₂• র‍্যাডিকেল O₃ ছাড়াই NO কে NO₂ তে জারিত করে — ফলে O₃ খরচ না হয়ে জমতে থাকে।'}</div>`; };
    const recompute = () => { D = smogRun(tr, voc, sun); info(); A.draw(); };
    const A = X.anim(el, dt => { if (dt) hr = (hr + dt * 1.6) % 24; draw(); }, { paused: false }); X.pp(el, A);
    q('[data-s1]').oninput = e => { tr = +e.target.value; recompute(); };
    q('[data-s2]').oninput = e => { voc = +e.target.value; recompute(); };
    q('[data-s3]').oninput = e => { sun = +e.target.value; recompute(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= AQI ক্যালকুলেটর ======================= */
const AQI_I = [[0, 50], [51, 100], [101, 150], [151, 200], [201, 300], [301, 500]];
const AQI_CAT = [['ভালো', '#00b050'], ['মাঝারি', '#e8c800'], ['সংবেদনশীলদের জন্য অস্বাস্থ্যকর', '#ff7e00'], ['অস্বাস্থ্যকর', '#e02020'], ['খুবই অস্বাস্থ্যকর', '#8f3f97'], ['দুর্যোগপূর্ণ', '#7e0023']];
const AQI_P = [
  ['pm25', 'PM₂.₅', 'µg m⁻³ (২৪ ঘ.)', 0, 300, 1, [[0, 9.0], [9.1, 35.4], [35.5, 55.4], [55.5, 125.4], [125.5, 225.4], [225.5, 325.4]], 0, 1],
  ['pm10', 'PM₁₀', 'µg m⁻³ (২৪ ঘ.)', 0, 500, 1, [[0, 54], [55, 154], [155, 254], [255, 354], [355, 424], [425, 604]], 0, 0],
  ['o3', 'O₃', 'ppb (৮ ঘ.)', 0, 200, 1, [[0, 54], [55, 70], [71, 85], [86, 105], [106, 200], [201, 400]], 48, 0],
  ['co', 'CO', 'ppm (৮ ঘ.)', 0, 40, 0.1, [[0, 4.4], [4.5, 9.4], [9.5, 12.4], [12.5, 15.4], [15.5, 30.4], [30.5, 50.4]], 28, 1],
  ['so2', 'SO₂', 'ppb (১ ঘ.)', 0, 600, 1, [[0, 35], [36, 75], [76, 185], [186, 304], [305, 604], [605, 1004]], 64, 0],
  ['no2', 'NO₂', 'ppb (১ ঘ.)', 0, 800, 1, [[0, 53], [54, 100], [101, 360], [361, 649], [650, 1249], [1250, 2049]], 46, 0]
];
const subI = (p, C) => { const bp = p[6]; let i = bp.findIndex(([lo, hi], k) => C <= hi + (k < 5 ? (bp[k + 1][0] - hi) * 0.999 : 1e9)); if (i < 0) i = 5; const [cl, ch] = bp[i], [il, ih] = AQI_I[i]; const Cc = Math.max(cl, Math.min(C, ch)); return { I: Math.round((ih - il) / (ch - cl) * (Cc - cl) + il), i, cl, ch, il, ih }; };
const PRESET = { dhakaJan: { pm25: 80, pm10: 180, o3: 30, co: 2.5, so2: 20, no2: 60 }, dhakaJul: { pm25: 18, pm10: 45, o3: 35, co: 0.8, so2: 5, no2: 22 }, smog: { pm25: 35, pm10: 70, o3: 95, co: 3, so2: 10, no2: 120 }, kiln: { pm25: 160, pm10: 320, o3: 20, co: 6, so2: 150, no2: 50 } };
V.p2c1_aqi = {
  t: 'বায়ুর মান সূচক (AQI) ক্যালকুলেটর: ছয়টি দূষকের উপ-সূচক, রৈখিক অন্তর্বেশন ও সামগ্রিক AQI', k: ['int', 'calc', '2d'],
  cap: 'ছয়টি দূষকের ঘনত্ব স্লাইডারে বদলাও (অথবা উপরে প্রস্তুত দৃশ্য বেছে নাও)। প্রতিটি দূষকের উপ-সূচক রঙিন দণ্ডে, আর সবচেয়ে বড়টি (তারকা চিহ্নিত) সামগ্রিক AQI — অর্ধবৃত্তাকার মিটারে। নিচে প্রধান দূষকের রৈখিক অন্তর্বেশন সূত্রে সংখ্যা বসিয়ে দেখানো হয়েছে; গ্যাসের ঘনত্বের µg m⁻³ মানও (২৫ °C, C = ppm × M / ২৪.৪৫) দেওয়া আছে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap"><button class="btn sm" data-pre="dhakaJan">ঢাকা জানুয়ারি</button><button class="btn sm" data-pre="dhakaJul">ঢাকা জুলাই</button><button class="btn sm" data-pre="smog">গ্রীষ্মের ধোঁয়াশা</button><button class="btn sm" data-pre="kiln">ইটভাটার পাশে</button></div>${X.cv('AQI ক্যালকুলেটর')}<div class="aqi-sl" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:4px 12px;margin:6px 0">${AQI_P.map(p => `<label class="small">${p[1]} = <b data-v="${p[0]}"></b> ${p[2]}<input type="range" min="${p[3]}" max="${p[4]}" step="${p[5]}" data-r="${p[0]}"></label>`).join('')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 270 : 420;
    let L = X.fit(c, hf); const C = Object.assign({}, PRESET.dhakaJan);
    const calc = () => AQI_P.map(p => Object.assign({ p }, subI(p, C[p[0]])));
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), R = calc(), top = R.reduce((a, r) => r.I > a.I ? r : a, R[0]);
      // gauge
      const gx = wd ? W * 0.22 : W / 2, gy = wd ? H * 0.68 : 150, gr = wd ? Math.min(W * 0.18, H * 0.55) : Math.min(W * 0.4, 120);
      const A2 = v => Math.PI + Math.PI * Math.min(500, v) / 500;
      AQI_I.forEach(([lo, hi], i) => { g.strokeStyle = AQI_CAT[i][1]; g.lineWidth = gr * 0.22; g.beginPath(); g.arc(gx, gy, gr, A2(lo), A2(hi + (i < 5 ? 1 : 0))); g.stroke(); });
      [0, 50, 100, 150, 200, 300, 500].forEach(v => { const a = A2(v); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(v), gx + Math.cos(a) * (gr + gr * 0.2), gy + Math.sin(a) * (gr + gr * 0.2) + 3); });
      const na = A2(top.I); g.strokeStyle = col.fg; g.lineWidth = 3; g.beginPath(); g.moveTo(gx, gy); g.lineTo(gx + Math.cos(na) * gr * 0.82, gy + Math.sin(na) * gr * 0.82); g.stroke(); g.fillStyle = col.fg; g.beginPath(); g.arc(gx, gy, 5, 0, 7); g.fill();
      g.fillStyle = AQI_CAT[top.i][1]; g.font = `bold ${wd ? 26 : 24}px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(top.I), gx, gy + 30); g.font = `bold 10.5px ${col.font}`; g.fillStyle = col.fg; g.fillText(AQI_CAT[top.i][0], gx, gy + 46);
      // bars
      const bx = wd ? W * 0.47 : 70, by = wd ? 20 : gy + 66, bw = wd ? W * 0.5 : W - 84, bh = wd ? (H - 40) / 6 : (H - by - 10) / 6;
      const sc = v => bx + bw * Math.min(1, v / 300);
      AQI_I.slice(0, 5).forEach(([lo, hi], i) => { g.fillStyle = AQI_CAT[i][1]; g.globalAlpha = 0.12; g.fillRect(sc(lo), by, sc(Math.min(300, hi + 1)) - sc(lo), bh * 6); }); g.globalAlpha = 1;
      R.forEach((r, k) => { const y = by + k * bh; g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'right'; g.fillText(r.p[1], bx - 6, y + bh / 2 + 4); g.fillStyle = AQI_CAT[r.i][1]; rr(g, bx, y + bh * 0.2, Math.max(3, sc(r.I) - bx), bh * 0.6, 4); g.fill(); g.fillStyle = col.fg; g.textAlign = 'left'; g.font = `${r === top ? 'bold ' : ''}10px ${col.font}`; const lx = Math.min(sc(r.I) + 4, bx + bw - 34); g.fillText(`${bn(r.I)}${r === top ? ' ★' : ''}`, lx, y + bh / 2 + 4); });
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; [0, 100, 200, 300].forEach(v => g.fillText(bn(v), sc(v), by + 6 * bh + 9));
    };
    const info = () => { const R = calc(), top = R.reduce((a, r) => r.I > a.I ? r : a, R[0]), p = top.p;
      AQI_P.forEach(pp => { const v = C[pp[0]]; el.querySelector(`[data-v="${pp[0]}"]`).textContent = bn(pp[5] < 1 ? v.toFixed(1) : Math.round(v)); el.querySelector(`[data-r="${pp[0]}"]`).value = v; });
      const Cv = C[p[0]], f = n => +n.toFixed(p[5] < 1 ? 1 : 1);
      let conv = AQI_P.filter(q => q[7]).map(q => { const v = C[q[0]], ppm = q[0] === 'co' ? v : v / 1000, mg = ppm * q[7] / 24.45; return `${q[1]}: ${bn(q[0] === 'co' ? v.toFixed(1) + ' ppm' : Math.round(v) + ' ppb')} = ${bn(q[0] === 'co' ? mg.toFixed(1) + ' mg' : Math.round(mg * 1000) + ' µg')} m⁻³`; }).join(' · ');
      out.innerHTML = `<div><b>সামগ্রিক AQI = ${bn(top.I)}</b> (${AQI_CAT[top.i][0]}); প্রধান দূষক ${p[1]}</div>` + TXB(`\\begin{aligned}I_{${p[0] === 'pm25' ? '\\mathrm{PM_{2.5}}' : p[0] === 'pm10' ? '\\mathrm{PM_{10}}' : '\\ce{' + ({ o3: 'O3', co: 'CO', so2: 'SO2', no2: 'NO2' })[p[0]] + '}'}} &= \\frac{${top.ih} - ${top.il}}{${top.ch} - ${top.cl}}\\,(${f(Math.min(Cv, top.ch))} - ${top.cl})\\\\ &\\quad + ${top.il} = ${top.I}\\end{aligned}`) + `<div class="small" style="margin-top:4px">${conv}</div><div class="small">${top.i >= 3 ? 'সবার জন্য বাইরের পরিশ্রম কমানো, N95 মাস্ক; শিশু, বয়স্ক ও হাঁপানি রোগীরা ঘরে থাকুন।' : top.i === 2 ? 'শিশু, বয়স্ক ও শ্বাসকষ্টের রোগীরা দীর্ঘ সময় বাইরে থাকা এড়িয়ে চলুন।' : 'বাইরের কাজকর্মে বাধা নেই।'}</div>`; };
    el.querySelectorAll('[data-r]').forEach(r => { r.oninput = e => { C[e.target.dataset.r] = +e.target.value; info(); draw(); }; });
    el.querySelectorAll('[data-pre]').forEach(b => { b.onclick = () => { Object.assign(C, PRESET[b.dataset.pre]); info(); draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= ত্রিমুখী ক্যাটালিটিক কনভার্টার ======================= */
const sig = x => 1 / (1 + Math.exp(-x));
const ccEff = (afr, T) => { const lam = afr / 14.7; const co = sig((T - 240) / 22) * (0.12 + 0.87 * sig((lam - 0.99) / 0.003)); const hc = sig((T - 270) / 22) * (0.15 + 0.83 * sig((lam - 0.988) / 0.0035)); const nox = sig((T - 260) / 22) * (0.04 + 0.94 * sig((1.01 - lam) / 0.003)); return { co, hc, nox }; };
V.p2c1_catconv = {
  t: 'ত্রিমুখী ক্যাটালিটিক কনভার্টার: মৌচাক কাঠামোয় CO, HC ও NO এর রূপান্তর; বায়ু-জ্বালানি অনুপাত ও তাপমাত্রার প্রভাব', k: ['anim', 'int', '3d', 'calc'],
  cap: 'উপরে কনভার্টারের কাটা-অংশ (ত্রিমাত্রিক): বাম দিক থেকে ইঞ্জিনের গ্যাস — CO (কালো-লাল), NO (নীল-লাল), হাইড্রোকার্বন (সবুজ) — Pt/Pd/Rh আস্তরিত মৌচাক নালিতে ঢুকে CO₂, N₂ ও H₂O হয়ে ডানে বের হয়। নিচে বায়ু-জ্বালানি অনুপাতের বিপরীতে তিন দূষকের রূপান্তর দক্ষতা: ১৪.৭ এর চারপাশে সংকীর্ণ "জানালা"তেই তিনটি একসাথে দূর হয়। তাপমাত্রা ~২৫০ °C ("লাইট-অফ") এর নিচে নামালে অনুঘটক কাজ করে না — ঠান্ডা ইঞ্জিনে প্রথম কয়েক মিনিট দূষণ সবচেয়ে বেশি।',
  html: () => `${X.cv('ক্যাটালিটিক কনভার্টার')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:140px">বায়ু : জ্বালানি = <b data-av></b> : ১<input type="range" min="13.8" max="15.6" step="0.05" value="14.7" data-a></label><label class="small" style="flex:1;min-width:140px">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="50" max="700" step="10" value="450" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 470;
    let L = X.fit(c, hf), afr = 14.7, T = 450, t = 0; const Rn = X.rng(8); let M = [];
    const KIND = { CO: ['#333', '#ff9a8a'], NO: ['#2d6fd6', '#ff9a8a'], HC: ['#2f9e44', '#c8f0cf'], CO2: ['#333', '#ffd0c8'], N2: ['#2d6fd6', '#a9c8ff'], H2O: ['#c0392b', '#e8f2ff'], O2: ['#c0392b', '#ffb3a8'] };
    const mol = (g, x, y, k, s) => { const [a, b] = KIND[k]; if (k === 'CO') { ball(g, x - s * .6, y, s, '#333', '#888'); ball(g, x + s * .6, y, s * .9, '#c0392b', '#ffb3a8'); } else if (k === 'NO') { ball(g, x - s * .6, y, s, '#2d6fd6', '#a9c8ff'); ball(g, x + s * .6, y, s * .9, '#c0392b', '#ffb3a8'); } else if (k === 'CO2') { ball(g, x - s * 1.1, y, s * .85, '#c0392b', '#ffb3a8'); ball(g, x, y, s, '#333', '#888'); ball(g, x + s * 1.1, y, s * .85, '#c0392b', '#ffb3a8'); } else if (k === 'N2') { ball(g, x - s * .55, y, s, '#2d6fd6', '#a9c8ff'); ball(g, x + s * .55, y, s, '#2d6fd6', '#a9c8ff'); } else if (k === 'H2O') { ball(g, x, y, s, '#c0392b', '#ffb3a8'); ball(g, x - s * .8, y + s * .6, s * .6, '#ddd', '#fff'); ball(g, x + s * .8, y + s * .6, s * .6, '#ddd', '#fff'); } else if (k === 'HC') { ball(g, x - s * .7, y, s, '#2f9e44', '#c8f0cf'); ball(g, x + s * .7, y, s, '#2f9e44', '#c8f0cf'); } };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), E = ccEff(afr, T);
      // converter body (isometric cylinder)
      const x0 = 30, x1 = W - 30, cy = wd ? 92 : 90, ry = wd ? 54 : 50, rx = 16;
      const bx0 = x0 + (x1 - x0) * 0.28, bx1 = x0 + (x1 - x0) * 0.72;
      g.fillStyle = '#8a9099'; g.fillRect(x0, cy - 14, bx0 - x0, 28); g.fillRect(bx1, cy - 14, x1 - bx1, 28);
      const hot = Math.min(1, Math.max(0, (T - 50) / 600)); const sg = g.createLinearGradient(0, cy - ry, 0, cy + ry); sg.addColorStop(0, `rgb(${170 + 60 * hot},${170 - 40 * hot},${175 - 90 * hot})`); sg.addColorStop(0.5, `rgb(${215 + 30 * hot},${215 - 40 * hot},${220 - 110 * hot})`); sg.addColorStop(1, `rgb(${120 + 60 * hot},${120 - 30 * hot},${125 - 70 * hot})`);
      g.fillStyle = sg; g.beginPath(); g.moveTo(bx0, cy - ry); g.lineTo(bx1, cy - ry); g.ellipse(bx1, cy, rx, ry, 0, -Math.PI / 2, Math.PI / 2); g.lineTo(bx0, cy + ry); g.ellipse(bx0, cy, rx, ry, 0, Math.PI / 2, Math.PI * 1.5); g.fill();
      // cut-away honeycomb front face
      const fx0 = bx0 + 18, fx1 = bx1 - 18; g.fillStyle = col.s2 || '#eee'; g.fillRect(fx0, cy - ry + 10, fx1 - fx0, 2 * ry - 20);
      const nch = 5, chh = (2 * ry - 20) / nch; for (let k = 0; k <= nch; k++) { const y = cy - ry + 10 + k * chh; g.fillStyle = `rgba(${150 + 60 * hot},${150 - 30 * hot},${150 - 60 * hot},.9)`; g.fillRect(fx0, y - 1.5, fx1 - fx0, 3); for (let x = fx0; x < fx1; x += 7) { g.fillStyle = (x / 7 | 0) % 3 === 0 ? '#c9b26b' : (x / 7 | 0) % 3 === 1 ? '#d8d8e0' : '#b9a0c8'; g.fillRect(x, y - 0.6, 3, 1.2); } }
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('Pt/Pd/Rh আস্তরিত সিরামিক মৌচাক', (fx0 + fx1) / 2, cy + ry + 14); g.textAlign = 'left'; g.fillText('ইঞ্জিন থেকে', x0, cy - 20); g.textAlign = 'right'; g.fillText('সাইলেন্সারে', x1, cy - 20);
      // molecules
      M.forEach(m => { const x = x0 + m.x * (x1 - x0), y = m.ch < 0 ? cy + m.dy * 10 : cy - ry + 10 + (m.ch + 0.5) * chh + m.dy * 3; mol(g, x, y, m.k, wd ? 3.4 : 2.6); });
      // efficiency chart
      const gx0 = 52, gy0 = cy + ry + 34, gw = W - gx0 - 18, gh = H - gy0 - 40;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: 13.8, xmax: 15.6, ymax: 100, col, xt: [14, 14.4, 14.7, 15, 15.4], yt: [0, 25, 50, 75, 100], xl: 'বায়ু : জ্বালানি (ভর অনুপাত)', yl: 'রূপান্তর (%)', fx: v => bn(v) });
      g.fillStyle = 'rgba(47,158,68,.12)'; g.fillRect(Pl.X(14.6), gy0, Pl.X(14.8) - Pl.X(14.6), gh);
      [['co', '#555', 'CO'], ['hc', '#2f9e44', 'HC'], ['nox', '#2d6fd6', 'NOx']].forEach(([k, cl]) => { const pts = []; for (let a = 13.8; a <= 15.6; a += 0.02) pts.push([Pl.X(a), Pl.Y(ccEff(a, T)[k] * 100)]); path(g, pts, cl, 2.2); ball(g, Pl.X(afr), Pl.Y(E[k] * 100), 4.5, cl, '#fff'); });
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('← জ্বালানি-সমৃদ্ধ', gx0 + 4, gy0 + gh - 4); g.textAlign = 'right'; g.fillText('বায়ু-সমৃদ্ধ →', gx0 + gw - 4, gy0 + gh - 4);
      legend(g, col, gx0 + gw, gy0 + gh * 0.32, [['#555', 'CO'], ['#2f9e44', 'HC'], ['#2d6fd6', 'NOx']], true);
    };
    const step = dt => { t += dt; const E = ccEff(afr, T); if (Rn() < dt * 7) { const r = Rn(); M.push({ k: r < 0.45 ? 'CO' : r < 0.75 ? 'NO' : 'HC', x: 0, ch: -1, dy: (Rn() - .5), done: false }); }
      M.forEach(m => { m.x += dt * 0.12; if (m.ch < 0 && m.x > 0.33 && m.x < 0.4) m.ch = Math.floor(Rn() * 5); if (m.ch >= 0 && m.x > 0.66) m.ch = -1;
        if (!m.done && m.x > 0.5) { m.done = true; const e = m.k === 'CO' ? E.co : m.k === 'NO' ? E.nox : E.hc; if (Rn() < e) m.k = m.k === 'CO' ? 'CO2' : m.k === 'NO' ? 'N2' : (Rn() < 0.5 ? 'CO2' : 'H2O'); } });
      M = M.filter(m => m.x < 1); };
    const info = () => { const E = ccEff(afr, T); q('[data-av]').textContent = bn(afr.toFixed(2)); q('[data-tv]').textContent = bn(T);
      out.innerHTML = `<div style="display:flex;gap:12px;flex-wrap:wrap"><span>CO → CO₂: <b>${bn(Math.round(E.co * 100))}%</b></span><span>HC → CO₂ + H₂O: <b>${bn(Math.round(E.hc * 100))}%</b></span><span>NO → N₂: <b>${bn(Math.round(E.nox * 100))}%</b></span></div>` + TXB('\\ce{2CO + O2 ->[Pt/Pd] 2CO2}') + TXB('\\ce{2NO + 2CO ->[Rh] N2 + 2CO2}') + `<div class="small">${T < 250 ? '<b>ঠান্ডা অনুঘটক:</b> সক্রিয়ণ শক্তি অতিক্রমের মতো তাপ নেই — গ্যাস প্রায় অপরিবর্তিত বের হচ্ছে।' : afr < 14.55 ? '<b>জ্বালানি-সমৃদ্ধ:</b> O₂ কম, তাই CO ও HC জারিত হতে পারে না; কিন্তু প্রচুর CO থাকায় NO বিজারণ ভালো।' : afr > 14.85 ? '<b>বায়ু-সমৃদ্ধ:</b> বাড়তি O₂ অনুঘটকের পৃষ্ঠ দখল করে ও CO খরচ করে ফেলে, তাই NO বিজারিত হয় না।' : '<b>স্টয়কিওমেট্রিক জানালা:</b> জারণ ও বিজারণ সমানতালে — তিন দূষকই ৯০% এর বেশি দূর। অক্সিজেন সেন্সর (λ-সেন্সর) ইঞ্জিনকে এই জানালায় রাখে।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    q('[data-a]').oninput = e => { afr = +e.target.value; info(); A.draw(); };
    q('[data-t]').oninput = e => { T = +e.target.value; info(); A.draw(); };
    for (let i = 0; i < 300; i++) step(0.03);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
