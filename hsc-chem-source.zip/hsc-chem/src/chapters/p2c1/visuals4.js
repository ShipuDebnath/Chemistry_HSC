/* ২য় পত্র অধ্যায় ১ visuals part 4 — practicals (1.4, 1.4.1) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide;
const { flame, legend } = P2;

/* least squares */
const fit = (pts, origin) => { const n = pts.length; if (n < 2) return null; if (origin) { let sxy = 0, sxx = 0; pts.forEach(([x, y]) => { sxy += x * y; sxx += x * x; }); return { m: sxy / sxx, c: 0 }; } let sx = 0, sy = 0, sxy = 0, sxx = 0; pts.forEach(([x, y]) => { sx += x; sy += y; sxy += x * y; sxx += x * x; }); const m = (n * sxy - sx * sy) / (n * sxx - sx * sx); return { m, c: (sy - m * sx) / n }; };
/* magnifier lens */
const lens = (g, col, cx, cy, r, drawInside) => { g.save(); g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fillStyle = col.sf; g.fill(); g.clip(); drawInside(); g.restore(); g.strokeStyle = col.fg; g.lineWidth = 2.5; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.stroke(); g.lineWidth = 5; g.strokeStyle = '#7a5a3a'; g.beginPath(); g.moveTo(cx + r * 0.72, cy + r * 0.72); g.lineTo(cx + r * 1.15, cy + r * 1.15); g.stroke(); };
const btnRow = items => `<div class="ctl">${items.map(([k, t]) => `<button class="btn sm" data-${k}>${t}</button>`).join('')}</div>`;

/* ======================= ১.৪ বয়েলের সূত্রের ব্যবহারিক ======================= */
V.p2c1_boyleLab = {
  t: 'ভার্চুয়াল ল্যাব: সিরিঞ্জ ও ভর দিয়ে বয়েলের সূত্র যাচাই — পাঠ, সারণি, লেখচিত্র ও ত্রুটি বিশ্লেষণ', k: ['anim', 'int', '2d', 'calc'],
  cap: 'স্ট্যান্ডে আটকানো বায়ুরোধী গ্যাস সিরিঞ্জ (A = ৪.৯৯ cm², শুরুতে ৪০ mL বায়ু, ২৮ °C)। "+১ kg" চাপলে প্ল্যাটফর্মে একটি ভর বসে, পিস্টন নামে — দ্রুত সংকোচনে বায়ু ক্ষণিকের জন্য গরম হয় (লাল থার্মোমিটার বার), তাই "স্থির" সংকেত সবুজ না হওয়া পর্যন্ত অপেক্ষা করে "পাঠ নাও"। গোল আতশকাচে পিস্টনের প্রান্ত ও দাগ বড় করে দেখায় (পাঠ ০.২ mL পর্যন্ত)। ডানে V বনাম 1/P লেখচিত্রে প্রতিটি পাঠ ও মূলবিন্দুগামী সর্বোত্তম রেখা; নিচের সারণিতে P, V, PV ও গড় থেকে বিচ্যুতি। "ঘর্ষণ" ও "লিক" চালু করে দেখো ত্রুটি কেমন দেখায়।',
  html: () => `${X.cv('বয়েলের সূত্রের ভার্চুয়াল ল্যাব')}${btnRow([['add', '+১ kg'], ['rem', '−১ kg'], ['rec', 'পাঠ নাও'], ['clr', 'মুছো']])}<div class="ctl"><label class="small"><input type="checkbox" data-fr> পিস্টনে ঘর্ষণ</label><label class="small"><input type="checkbox" data-lk> সিরিঞ্জে লিক</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 400 : 760;
    const A = 4.99e-4, Pa = 1.010e5, T0 = 301.15, Rg = 8.314, g9 = 9.8;
    let L = X.fit(c, hf), m = 0, n = Pa * 40e-6 / (Rg * T0), dT = 0, Vshow = 40, dir = 1, fr = false, lk = false, t = 0, flash = 0;
    const rec = []; const rnd = X.rng(17);
    const Pof = mm => Pa + mm * g9 / A;
    const Vtarget = () => { const P = Pof(m), Pe = fr && m > 0 ? P - dir * 2600 : P; return n * Rg * (T0 + dT) / Pe * 1e6; };
    const settled = () => Math.abs(dT) < 0.08 && Math.abs(Vshow - Vtarget()) < 0.05;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      // stand
      const sx = wd ? 40 : 10, base = wd ? H - 26 : 400;
      const MH = 8;
      g.fillStyle = '#5b4a3a'; g.fillRect(sx - 20, base, 170, 10); g.fillStyle = '#9aa0a8'; g.fillRect(sx, 30, 6, base - 30);
      // syringe geometry
      const bx = sx + (wd ? 60 : 50), bw = 40, btop = 130, bbot = base - 50, mlpx = (bbot - btop) / 50; // 50 mL scale
      g.fillStyle = '#9aa0a8'; g.fillRect(sx + 6, bbot - 40, 60, 6); g.fillStyle = '#c9cdd3'; g.fillRect(bx - 4, bbot - 44, bw + 8, 14);
      // barrel (tip at bottom, sealed with cap)
      const yPl = bbot - Vshow * mlpx; // plunger face (gas below it)
      g.fillStyle = 'rgba(150,200,240,.22)'; g.fillRect(bx, yPl, bw, bbot - yPl);
      // hot tint
      if (dT > 0.05) { g.fillStyle = `rgba(230,80,40,${Math.min(0.35, dT / 6)})`; g.fillRect(bx, yPl, bw, bbot - yPl); }
      g.strokeStyle = col.fg; g.lineWidth = 1.8; g.beginPath(); g.moveTo(bx, btop - 20); g.lineTo(bx, bbot); g.lineTo(bx + bw / 2 - 5, bbot + 12); g.lineTo(bx + bw / 2 + 5, bbot + 12); g.lineTo(bx + bw, bbot); g.lineTo(bx + bw, btop - 20); g.stroke();
      g.fillStyle = '#c0392b'; g.fillRect(bx + bw / 2 - 7, bbot + 12, 14, 9); // cap
      // graduations
      g.strokeStyle = col.mu; g.fillStyle = col.mu; g.font = `8.5px ${col.font}`; g.textAlign = 'left'; g.lineWidth = 0.8;
      for (let v = 0; v <= 50; v += 1) { const y = bbot - v * mlpx; g.beginPath(); g.moveTo(bx + bw, y); g.lineTo(bx + bw - (v % 10 ? (v % 5 ? 4 : 7) : 11), y); g.stroke(); if (v % 10 === 0) g.fillText(bn(v), bx + bw + 3, y + 3); }
      // plunger
      const pg = g.createLinearGradient(bx, 0, bx + bw, 0); pg.addColorStop(0, '#2a2a2a'); pg.addColorStop(0.5, '#555'); pg.addColorStop(1, '#222');
      g.fillStyle = pg; g.fillRect(bx + 1, yPl - 8, bw - 2, 8); const rod = 58; g.fillStyle = '#e8e8e8'; g.globalAlpha = 0.9; g.fillRect(bx + bw / 2 - 5, yPl - 8 - rod, 10, rod); g.globalAlpha = 1;
      g.strokeStyle = col.mu; g.lineWidth = 0.8; g.strokeRect(bx + bw / 2 - 5, yPl - 8 - rod, 10, rod);
      // platform + masses
      const py = yPl - 8 - rod; g.fillStyle = '#7a6a5a'; g.fillRect(bx - 14, py - 5, bw + 28, 5);
      for (let k = 0; k < m; k++) { const yy = py - 5 - (k + 1) * (MH + 1); const mg = g.createLinearGradient(bx - 10, 0, bx + bw + 10, 0); mg.addColorStop(0, '#4a4f56'); mg.addColorStop(0.45, '#9aa1aa'); mg.addColorStop(1, '#3d4248'); g.fillStyle = mg; g.fillRect(bx - 10, yy, bw + 20, MH); g.fillStyle = '#fff'; g.font = `bold 7px ${col.font}`; g.textAlign = 'center'; g.fillText('১ kg', bx + bw / 2, yy + MH - 1); }
      // gas particles
      const R = X.rng(5); for (let i = 0; i < 24; i++) { const xx = bx + 5 + R() * (bw - 10), ph = R() * 6; const yy = yPl + 4 + ((R() + t * (0.3 + R() * 0.3)) % 1) * Math.max(4, bbot - yPl - 8); ball(g, xx + Math.sin(t * 6 + ph) * 2, yy, 2.3, '#2d6fd6', '#a9c8ff'); }
      // thermometer of gas (excess)
      const tx = bx + bw + (wd ? 40 : 30), ty = btop + 10, th = 110;
      g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1; g.fillRect(tx - 4, ty, 8, th); g.strokeRect(tx - 4, ty, 8, th); g.beginPath(); g.arc(tx, ty + th + 6, 7, 0, 7); g.fillStyle = '#d63a2a'; g.fill(); g.stroke();
      const lv = 0.45 + Math.max(-0.4, Math.min(0.5, dT / 8)); g.fillStyle = '#d63a2a'; g.fillRect(tx - 2, ty + th * (1 - lv), 4, th * lv + 2);
      g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(`বায়ু ${fx(T0 - 273.15 + dT, 1)} °C`, tx, ty - 6);
      // settled indicator
      const ok = settled(); g.fillStyle = ok ? '#2f9e44' : '#d06a1e'; g.beginPath(); g.arc(tx, ty + th + 30, 7, 0, 7); g.fill(); g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.fillText(ok ? 'স্থির ✓' : 'অপেক্ষা…', tx, ty + th + 50);
      // lens
      const lr = wd ? 46 : 38, lx = wd ? bx + bw + 100 : W - lr - 6, ly = bbot - 40;
      lens(g, col, lx, ly, lr, () => { const zoom = 9, v0 = Vshow; g.fillStyle = 'rgba(150,200,240,.25)'; g.fillRect(lx - lr, ly, lr * 2, lr); g.fillStyle = '#333'; g.fillRect(lx - lr, ly - 10, lr * 2, 10); g.strokeStyle = col.fg; g.fillStyle = col.fg; g.lineWidth = 1; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; for (let v = Math.floor(v0 - 6); v <= v0 + 6; v += 0.2) { const y = ly - (v - v0) * zoom; const vi = Math.round(v * 5); const major = vi % 5 === 0; g.beginPath(); g.moveTo(lx + lr, y); g.lineTo(lx + lr - (major ? 22 : 10), y); g.stroke(); if (major) g.fillText(bn(Math.round(v)), lx + lr - 40, y + 4); } g.strokeStyle = '#c0392b'; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(lx - lr, ly); g.lineTo(lx + lr, ly); g.stroke(); g.setLineDash([]); });
      g.strokeStyle = col.mu; g.setLineDash([2, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(bx + bw, yPl); g.lineTo(lx - lr, ly); g.stroke(); g.setLineDash([]);
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`ভর = ${bn(m)} kg`, bx + bw / 2, Math.max(12, py - 5 - m * (MH + 1) - 6));
      if (flash > 0) { g.fillStyle = `rgba(47,158,68,${flash})`; g.fillRect(0, 0, W, 4); }
      // graph
      const gx0 = wd ? W * 0.56 : 60, gy0 = wd ? 36 : base + 50, gw = wd ? W - gx0 - 20 : W - 84, gh = wd ? H - 86 : H - gy0 - 46;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 1.0, ymax: 45, col, xt: [0, 0.25, 0.5, 0.75, 1.0], yt: [0, 15, 30, 45], fx: v => bn(v.toFixed(2)), xl: '1/P (×10⁻⁵ Pa⁻¹)', yl: 'V (mL)' });
      const pts = rec.map(r => [1e5 / r.P, r.V]); const F = fit(pts, true);
      if (F) { path(g, [[Pl.X(0), Pl.Y(0)], [Pl.X(1.0), Pl.Y(F.m * 1.0)]], '#2d6fd6', 2); }
      pts.forEach(([x, y]) => { ball(g, Pl.X(x), Pl.Y(y), 4.5, '#c0392b', '#ffb3a8'); });
      g.fillStyle = col.fg; g.font = `bold 11.5px ${col.font}`; g.textAlign = 'center'; g.fillText('V বনাম 1/P', gx0 + gw / 2, gy0 - 16);
      if (F) { g.fillStyle = '#2d6fd6'; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`ঢাল = PV ≈ ${fx(F.m * 100, 0)} Pa·L`, gx0 + 10, gy0 + 10); }
    };
    const info = () => {
      const P = Pof(m);
      let h = TXB(`P = P_{\\text{atm}} + \\dfrac{mg}{A} = 1.010\\times10^5 + \\dfrac{${m}\\times9.8}{4.99\\times10^{-4}} = ${(P / 1e5).toFixed(3)}\\times10^5\\ \\mathrm{Pa}`);
      if (rec.length) {
        const pvL = rec.map(r => r.P * r.V * 1e-3); const av = pvL.reduce((a, b) => a + b, 0) / pvL.length;
        h += `<div class="table-wrap"><table class="t"><thead><tr><th>ক্রম</th><th>m (kg)</th><th>P (×10⁵ Pa)</th><th>V (mL)</th><th>1/P (×10⁻⁵)</th><th>PV (Pa·L)</th><th>বিচ্যুতি</th></tr></thead><tbody>${rec.map((r, i) => `<tr><td>${bn(i + 1)}</td><td>${bn(r.m)}</td><td>${fx(r.P / 1e5, 3)}</td><td>${fx(r.V, 1)}</td><td>${fx(1e5 / r.P, 3)}</td><td>${fx(pvL[i], 0)}</td><td>${(pvL[i] - av) / av * 100 >= 0 ? '+' : ''}${fx((pvL[i] - av) / av * 100, 2)}%</td></tr>`).join('')}</tbody></table></div>`;
        if (rec.length >= 3) { const spread = Math.max(...pvL.map(v => Math.abs(v - av) / av * 100)); const nmol = av / 1000 / (8.314 * T0); h += TXB(`\\overline{PV} = ${av.toFixed(0)}\\ \\mathrm{Pa\\,L},\\quad n = \\dfrac{\\overline{PV}}{RT} = \\dfrac{${(av / 1000).toFixed(3)}\\ \\mathrm{J}}{8.314\\times${T0.toFixed(2)}} = ${nmol.toExponential(2).replace('e-', '\\times10^{-') + '}'}\\ \\mathrm{mol}`) + `<div class="small">সর্বোচ্চ বিচ্যুতি ${fx(spread, 2)}% — ${spread < 1 ? 'পরীক্ষণীয় ত্রুটির মধ্যে PV ধ্রুবক: বয়েলের সূত্র যাচাই হলো।' : 'বিচ্যুতি বেশি — ঘর্ষণ, লিক বা অপেক্ষা না করে পাঠ নেওয়ার প্রভাব খুঁজে দেখো।'}</div>`; }
      } else h += '<div class="small">শুরুতে ভরশূন্য অবস্থায় একটি পাঠ নাও, তারপর একে একে ভর যোগ করে ৫–৬টি পাঠ নাও।</div>';
      out.innerHTML = h;
    };
    const A_ = X.anim(el, dt => { if (dt) { t += dt; dT *= Math.exp(-dt / 1.4); if (lk) n *= Math.exp(-dt * 0.0012); const tv = Vtarget(); Vshow += (tv - Vshow) * Math.min(1, dt * 4); flash = Math.max(0, flash - dt * 2); } draw(); }, { paused: false });
    const change = d => { const nm = Math.max(0, Math.min(8, m + d)); if (nm === m) return; dir = d; const P1 = Pof(m), P2_ = Pof(nm); dT += 301 * (Math.pow(P2_ / P1, 0.2857) - 1) * 0.55; m = nm; info(); A_.draw(); };
    q('[data-add]').onclick = () => change(1); q('[data-rem]').onclick = () => change(-1);
    q('[data-rec]').onclick = () => { if (rec.length >= 10) return; const Vr = Math.round((Vshow + (rnd() - 0.5) * 0.2) * 5) / 5; rec.push({ m, P: Pof(m), V: Vr }); flash = 0.6; info(); A_.draw(); };
    q('[data-clr]').onclick = () => { rec.length = 0; n = Pa * 40e-6 / (Rg * T0); info(); A_.draw(); };
    q('[data-fr]').onchange = e => { fr = e.target.checked; A_.draw(); }; q('[data-lk]').onchange = e => { lk = e.target.checked; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A_.draw(); });
    return () => { A_.stop(); un(); };
  }
};

/* ======================= ১.৪.১ চার্লসের সূত্রের ব্যবহারিক ======================= */
const VPw = t => 4.58 * Math.exp(17.27 * t / (t + 237.3)) * 1.0; // mmHg (Magnus approx, ~ matches table)
V.p2c1_charlesLab = {
  t: 'ভার্চুয়াল ল্যাব: কৈশিক নল ও পানির বাথে চার্লসের সূত্র যাচাই এবং লেখচিত্র বহির্বেশনে পরম শূন্য নির্ণয়', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বিকারে পানি, তার মধ্যে মিটার স্কেল ও থার্মোমিটারের সাথে বাঁধা এক মুখ বন্ধ কৈশিক নল; গাঢ় H₂SO₄ এর ফোঁটা (হলুদ) শুষ্ক বায়ু আটকে রেখেছে। "বরফ দাও" চাপলে বাথ ~২ °C এ নামে; "বার্নার" চালু করলে পানি গরম হয় — বায়ু স্তম্ভ (নীল) পানির তাপমাত্রা একটু দেরিতে অনুসরণ করে, তাই বার্নার বন্ধ করে "স্থির" সংকেতের পর "পাঠ নাও"। আতশকাচে ফোঁটার নিচের প্রান্ত ও mm দাগ। ডানে ℓ বনাম t লেখচিত্র: পাঠের বিন্দু, সর্বোত্তম সরলরেখা ও তার কাটা-রেখা বহির্বেশন — t অক্ষ ছেদ করার বিন্দুই পরীক্ষালব্ধ পরম শূন্য। "পানির ফোঁটা" চালু করলে জলীয় বাষ্পের কারণে ফল কেমন নষ্ট হয় দেখো।',
  html: () => `${X.cv('চার্লসের সূত্রের ভার্চুয়াল ল্যাব')}${btnRow([['ice', 'বরফ দাও'], ['burn', 'বার্নার চালু'], ['rec', 'পাঠ নাও'], ['clr', 'মুছো']])}<div class="ctl"><label class="small"><input type="checkbox" data-wet> H₂SO₄ এর বদলে পানির ফোঁটা</label><label class="small"><input type="checkbox" data-nost> নাড়ানো বন্ধ</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 400 : 780;
    let L = X.fit(c, hf), Tw = 28, Ta = 28, burn = false, wet = false, nost = false, t = 0, flash = 0;
    const rec = []; const rnd = X.rng(31);
    const ell = () => { const dry = 10 * (Ta + 273.15) / 273.15; if (!wet) return dry; const f = Math.min(700, VPw(Ta)); return dry * (760 - VPw(2)) / (760 - f); };
    const settled = () => !burn && Math.abs(Tw - Ta) < 0.15;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const cx = wd ? 185 : W / 2 + 10, base = wd ? H - 30 : 410, bw = 140, bh = 170, btop = base - 60 - bh;
      // tripod & burner
      g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(cx - bw / 2 - 5, base - 60); g.lineTo(cx - bw / 2 + 10, base); g.moveTo(cx + bw / 2 + 5, base - 60); g.lineTo(cx + bw / 2 - 10, base); g.stroke();
      g.fillStyle = '#777'; g.fillRect(cx - bw / 2 - 10, base - 62, bw + 20, 4);
      g.fillStyle = '#4a4f56'; g.fillRect(cx - 9, base - 30, 18, 30); g.fillRect(cx - 20, base - 4, 40, 4);
      if (burn) flame(g, cx, base - 32, 9, t);
      // beaker water
      const hot = Math.max(0, Math.min(1, (Tw - 2) / 90));
      g.fillStyle = `rgba(${Math.round(80 + 150 * hot)},${Math.round(150 - 40 * hot)},${Math.round(225 - 150 * hot)},.30)`; g.fillRect(cx - bw / 2, btop + 24, bw, bh - 24);
      if (Tw < 6) { g.fillStyle = 'rgba(200,230,255,.85)'; g.strokeStyle = 'rgba(100,150,200,.8)'; g.lineWidth = 1; [[-50, 30], [-30, 50], [35, 28], [50, 60], [-45, 90]].forEach(([dx, dy]) => { g.beginPath(); g.rect(cx + dx - 8, btop + 24 + dy, 16, 13); g.fill(); g.stroke(); }); }
      if (burn && Tw > 70) { for (let k = 0; k < 6; k++) { const by = btop + bh - ((t * 50 + k * 30) % (bh - 30)); g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 1; g.beginPath(); g.arc(cx - 50 + k * 20, by, 2.5, 0, 7); g.stroke(); } }
      g.strokeStyle = col.fg; g.lineWidth = 1.8; g.beginPath(); g.moveTo(cx - bw / 2, btop); g.lineTo(cx - bw / 2, btop + bh); g.lineTo(cx + bw / 2, btop + bh); g.lineTo(cx + bw / 2, btop); g.stroke();
      // ruler + capillary (tube bottom closed at ruler 0 near beaker bottom)
      const rx = cx - 18, r0 = btop + bh - 10, pxcm = (bh - 30) / 15, rtop = r0 - 22 * pxcm;
      g.fillStyle = '#e9d9a8'; g.fillRect(rx - 14, rtop, 14, r0 - rtop + 4); g.strokeStyle = '#8a7444'; g.lineWidth = 0.8; g.strokeRect(rx - 14, rtop, 14, r0 - rtop + 4);
      g.fillStyle = '#5a4a2a'; g.font = `7.5px ${col.font}`; g.textAlign = 'right';
      for (let cm = 0; cm <= 22; cm++) { const y = r0 - cm * pxcm; g.beginPath(); g.moveTo(rx, y); g.lineTo(rx - (cm % 5 ? 5 : 9), y); g.stroke(); if (cm % 5 === 0) g.fillText(bn(cm), rx - 9, y + 3); }
      const l = ell(), yTop = r0 - l * pxcm;
      g.fillStyle = 'rgba(80,140,220,.55)'; g.fillRect(rx + 2, yTop, 5, r0 - yTop);
      g.fillStyle = wet ? '#6fb6e8' : '#e8c440'; g.fillRect(rx + 2, yTop - 0.6 * pxcm, 5, 0.6 * pxcm);
      g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(rx + 1, rtop - 8); g.lineTo(rx + 1, r0); g.arc(rx + 4.5, r0, 3.5, Math.PI, 0, true); g.lineTo(rx + 8, rtop - 8); g.stroke();
      // thermometer
      const tx = cx + 20, tt = rtop - 10, tb = r0 - 4; g.fillStyle = col.sf; g.strokeStyle = col.fg; g.fillRect(tx - 3, tt, 6, tb - tt); g.strokeRect(tx - 3, tt, 6, tb - tt); g.beginPath(); g.arc(tx, tb + 5, 6, 0, 7); g.fillStyle = '#d63a2a'; g.fill(); g.stroke();
      const tf = Math.max(0, Math.min(1, Tw / 100)); g.fillStyle = '#d63a2a'; g.fillRect(tx - 1.5, tb - (tb - tt) * tf, 3, (tb - tt) * tf + 2);
      g.fillStyle = col.mu; g.font = `7.5px ${col.font}`; g.textAlign = 'left'; [0, 50, 100].forEach(v => g.fillText(bn(v), tx + 5, tb - (tb - tt) * v / 100 + 3));
      // rubber bands
      g.fillStyle = '#c0392b'; [0.25, 0.75].forEach(f => g.fillRect(rx - 15, rtop + (r0 - rtop) * f, tx - rx + 19, 3));
      // labels
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`পানি ${fx(Tw, 1)} °C`, cx + 45, btop + 16);
      g.font = `9.5px ${col.font}`; g.fillStyle = col.mu; g.textAlign = 'right'; g.fillText('বায়ু স্তম্ভ', cx - bw / 2 - 4, btop + bh - 22); g.fillText(`${fx(Ta, 1)} °C`, cx - bw / 2 - 4, btop + bh - 9);
      const ok = settled(); g.fillStyle = ok ? '#2f9e44' : '#d06a1e'; g.beginPath(); g.arc(cx + 20, btop - 26, 7, 0, 7); g.fill(); g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(ok ? 'স্থির ✓' : 'অপেক্ষা…', cx + 31, btop - 22);
      // lens
      const lx = wd ? 54 : cx - bw / 2 - 18, ly = wd ? 110 : 60, lr = 40;
      lens(g, col, lx + (wd ? 0 : 0), ly, lr, () => { const zoom = 22, c0 = l; g.fillStyle = '#e9d9a8'; g.fillRect(lx - lr, ly - lr, lr, lr * 2); g.strokeStyle = '#5a4a2a'; g.fillStyle = '#5a4a2a'; g.font = `bold 9px ${col.font}`; g.textAlign = 'right'; g.lineWidth = 1; for (let mm = Math.floor((c0 - 2) * 10); mm <= (c0 + 2) * 10; mm++) { const y = ly - (mm / 10 - c0) * zoom; g.beginPath(); g.moveTo(lx, y); g.lineTo(lx - (mm % 10 ? (mm % 5 ? 6 : 10) : 16), y); g.stroke(); if (mm % 10 === 0) g.fillText(bn(mm / 10), lx - 18, y + 3); } g.fillStyle = 'rgba(80,140,220,.55)'; g.fillRect(lx + 4, ly, 14, lr); g.fillStyle = wet ? '#6fb6e8' : '#e8c440'; g.fillRect(lx + 4, ly - 0.6 * zoom, 14, 0.6 * zoom); g.strokeStyle = '#c0392b'; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(lx - lr, ly); g.lineTo(lx + lr, ly); g.stroke(); g.setLineDash([]); });
      g.strokeStyle = col.mu; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(lx + lr, ly); g.lineTo(rx + 2, yTop); g.stroke(); g.setLineDash([]);
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`ℓ = ${fx(l, 2)} cm`, lx, ly + lr + 14);
      if (flash > 0) { g.fillStyle = `rgba(47,158,68,${flash})`; g.fillRect(0, 0, W, 4); }
      // graph
      const gx0 = wd ? W * 0.5 : 56, gy0 = wd ? 40 : base + 50, gw = wd ? W - gx0 - 20 : W - 78, gh = wd ? H - 90 : H - gy0 - 46;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: -300, xmax: 100, ymax: 16, col, xt: [-300, -200, -100, 0, 100], yt: [0, 4, 8, 12, 16], xl: 't (°C)', yl: 'ℓ (cm)' });
      g.strokeStyle = col.mu; g.lineWidth = 0.8; g.beginPath(); g.moveTo(Pl.X(0), gy0); g.lineTo(Pl.X(0), gy0 + gh); g.stroke();
      g.strokeStyle = 'rgba(123,63,160,.6)'; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(Pl.X(-273.15), gy0 + gh); g.lineTo(Pl.X(-273.15), gy0 + gh - 18); g.stroke(); g.setLineDash([]); g.fillStyle = '#7b3fa0'; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('−২৭৩.১৫', Pl.X(-273.15), gy0 + gh - 22);
      const pts = rec.map(r => [r.t, r.l]); const F = fit(pts);
      if (F && rec.length >= 2) { const t0 = -F.c / F.m; const xa = Math.max(-300, t0); path(g, [[Pl.X(xa), Pl.Y(F.m * xa + F.c)], [Pl.X(Math.min(...pts.map(p => p[0]))), Pl.Y(F.m * Math.min(...pts.map(p => p[0])) + F.c)]], '#2d6fd6', 1.6, [5, 4]); path(g, [[Pl.X(Math.min(...pts.map(p => p[0]))), Pl.Y(F.m * Math.min(...pts.map(p => p[0])) + F.c)], [Pl.X(100), Pl.Y(F.m * 100 + F.c)]], '#2d6fd6', 2.4);
        if (t0 >= -300) { ball(g, Pl.X(t0), Pl.Y(0), 5.5, '#c0392b', '#ffb3a8'); g.fillStyle = '#c0392b'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`t₀ = ${fx(t0, 1)} °C`, Pl.X(t0) + 8, Pl.Y(0) - 40); } }
      pts.forEach(([x, y]) => ball(g, Pl.X(x), Pl.Y(y), 4, '#c0392b', '#ffb3a8'));
      g.fillStyle = col.fg; g.font = `bold 11.5px ${col.font}`; g.textAlign = 'center'; g.fillText('ℓ বনাম t: বহির্বেশনে পরম শূন্য', gx0 + gw / 2, gy0 - 18);
    };
    const info = () => {
      let h = '';
      if (rec.length) {
        h += `<div class="table-wrap"><table class="t"><thead><tr><th>ক্রম</th><th>t (°C)</th><th>ℓ (cm)</th><th>T (K)</th><th>ℓ/T (×10⁻²)</th></tr></thead><tbody>${rec.map((r, i) => `<tr><td>${bn(i + 1)}</td><td>${fx(r.t, 1)}</td><td>${fx(r.l, 2)}</td><td>${fx(r.t + 273.15, 1)}</td><td>${fx(r.l / (r.t + 273.15) * 100, 3)}</td></tr>`).join('')}</tbody></table></div>`;
        const F = fit(rec.map(r => [r.t, r.l]));
        if (F && rec.length >= 3 && Math.max(...rec.map(r => r.t)) - Math.min(...rec.map(r => r.t)) > 15) { const t0 = -F.c / F.m, err = Math.abs(t0 + 273.15) / 273.15 * 100;
          h += TXB(`\\ell = ${F.m.toFixed(5)}\\,t + ${F.c.toFixed(3)}\\quad(\\text{সর্বোত্তম রেখা})`) + TXB(`t_0 = -\\dfrac{c}{m} = -\\dfrac{${F.c.toFixed(3)}}{${F.m.toFixed(5)}} = ${t0.toFixed(1)}\\,^\\circ\\mathrm{C}`) + TXB(`\\text{শতকরা ত্রুটি} = \\dfrac{|${t0.toFixed(1)} - (-273.15)|}{273.15}\\times100 = ${err.toFixed(2)}\\%`) +
            `<div class="small">${err < 2 ? 'চমৎকার! ℓ/T কলাম প্রায় ধ্রুবক — চার্লসের সূত্র যাচাই হলো।' : wet ? 'জলীয় বাষ্পের চাপ উচ্চ তাপমাত্রায় দ্রুত বাড়ে, ফলে ℓ অতিরিক্ত বাড়ে ও রেখা বেঁকে যায় — পরম শূন্য অনেক ভুল আসে।' : 'ত্রুটি বেশি — সম্ভবত তাপমাত্রা স্থির হওয়ার আগে পাঠ নেওয়া হয়েছে (বায়ু স্তম্ভ পানির তাপমাত্রায় পৌঁছায়নি)।'}</div>`; }
        else h += '<div class="small">বিস্তৃত তাপমাত্রা পরিসরে (যেমন ২ থেকে ৯০ °C) কমপক্ষে ৪–৬টি পাঠ নাও।</div>';
      } else h = '<div class="small">ধাপ: (১) বরফ দাও → স্থির হলে পাঠ নাও; (২) বার্নার চালু করে ১০–১৫ °C বাড়াও → বার্নার বন্ধ → স্থির হলে পাঠ নাও; (৩) ৯০ °C পর্যন্ত পুনরাবৃত্তি।</div>';
      out.innerHTML = h;
    };
    const A_ = X.anim(el, dt => { if (dt) { const s = dt * 3; t += dt; if (burn) Tw = Math.min(98, Tw + s * 1.6 * (1 - Tw / 110)); else if (Tw > 28) Tw -= s * 0.012 * (Tw - 28); else Tw += s * 0.006 * (28 - Tw); const tau = nost ? 8 : 1.1; Ta += (Tw - Ta) * Math.min(1, s / tau); flash = Math.max(0, flash - dt * 2); } draw(); }, { paused: false });
    q('[data-ice]').onclick = () => { Tw = 2; burn = false; q('[data-burn]').textContent = 'বার্নার চালু'; A_.draw(); };
    q('[data-burn]').onclick = () => { burn = !burn; q('[data-burn]').textContent = burn ? 'বার্নার বন্ধ' : 'বার্নার চালু'; A_.draw(); };
    q('[data-rec]').onclick = () => { if (rec.length >= 10) return; const tr = Math.round(Tw * 2) / 2, lr = Math.round((ell() + (rnd() - 0.5) * 0.04) * 100) / 100; rec.push({ t: tr, l: lr }); rec.sort((a, b) => a.t - b.t); flash = 0.6; info(); A_.draw(); };
    q('[data-clr]').onclick = () => { rec.length = 0; info(); A_.draw(); };
    q('[data-wet]').onchange = e => { wet = e.target.checked; rec.length = 0; info(); A_.draw(); };
    q('[data-nost]').onchange = e => { nost = e.target.checked; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A_.draw(); });
    return () => { A_.stop(); un(); };
  }
};
})();
