/* ২য় পত্র অধ্যায় ১ visuals part 18 — chapter summary: concept map + numeric drill */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };

/* ======================= ধারণা মানচিত্র ======================= */
const GRP = [
  ['gas', 'গ্যাসের ভাষা', '#2d6fd6'],
  ['air', 'বায়ু ও দূষণ', '#c0392b'],
  ['ab', 'এসিড-ক্ষারক', '#8e44ad'],
  ['wat', 'পানির রসায়ন', '#0f8b8d'],
  ['sol', 'দ্রবণ', '#d06a1e']
];
// [id, label, group, desc, lessonId]
const NODES = [
  ['atm', 'বায়ুমণ্ডল', 'gas', 'N₂ ৭৮%, O₂ ২১%, Ar ০.৯৩%, CO₂ ০.০৪%; ট্রপোস্ফিয়ার → স্ট্র্যাটোস্ফিয়ার (ওজোন স্তর)', 'p2c1s1a'],
  ['law', 'গ্যাস সূত্র', 'gas', 'বয়েল, চার্লস, অ্যাভোগেড্রো → PV = nRT; ডাল্টন pᵢ = xᵢP; গ্রাহাম r ∝ 1/√M', 'p2c1s3a'],
  ['kmt', 'গতিতত্ত্ব', 'gas', 'PV = ⅓mNc̄²; গড় গতিশক্তি = 3/2 kT — তাপমাত্রা অণুর গতির পরিমাপ', 'p2c1s5a'],
  ['real', 'বাস্তব গ্যাস', 'gas', 'Z = PV/nRT; (P + an²/V²)(V − nb) = nRT; উচ্চ T ও নিম্ন P তে আদর্শ', 'p2c1s7a'],
  ['cyl', 'সিলিন্ডার', 'gas', 'CNG সংকুচিত (২০০ bar), LPG তরলীকৃত (বাষ্পচাপ ~৫–৮ bar); সংকট তাপমাত্রা নির্ধারক', 'p2c1s8a'],
  ['ltn', 'বজ্রপাত ও N চক্র', 'air', 'N₂ + O₂ → 2NO → NO₂ → HNO₃ → মাটিতে NO₃⁻; প্রাকৃতিক N-সংবন্ধন', 'p2c1s9a'],
  ['pol', 'দূষক ও AQI', 'air', 'প্রাথমিক (CO, SO₂, NOx, PM) ও গৌণ (O₃, H₂SO₄); mg m⁻³ = ppm × M/২৪.৪৫', 'p2c1s10a'],
  ['ghg', 'গ্রিনহাউস', 'air', 'দ্বিপোল পরিবর্তনশীল কম্পন IR শোষে (CO₂, H₂O, CH₄); ΔF = ৫.৩৫ ln(C/C₀)', 'p2c1s11a'],
  ['oz', 'ওজোন ক্ষয়', 'air', 'চ্যাপম্যান চক্র; CFC → Cl• অনুঘটকীয় শৃঙ্খল: Cl• + O₃ → ClO• + O₂', 'p2c1s12a'],
  ['rain', 'এসিড বৃষ্টি', 'air', 'pH < ৫.৬; SO₂ → SO₃ → H₂SO₄, NO₂ → HNO₃; মার্বেল ক্ষয়, মাটির বাফার', 'p2c1s13a'],
  ['arr', 'আরহেনিয়াস', 'ab', 'পানিতে H⁺ দেয় এসিড, OH⁻ দেয় ক্ষারক — জলীয় দ্রবণে সীমাবদ্ধ', 'p2c1s14a'],
  ['bl', 'ব্রনস্টেড-লাউরি', 'ab', 'প্রোটন দাতা/গ্রহীতা; অনুবন্ধী যুগল; Ka × Kb = Kw', 'p2c1s15a'],
  ['lw', 'লুইস', 'ab', 'ইলেকট্রন জোড় গ্রহীতা (BF₃, AlCl₃, Fe³⁺) ও দাতা (NH₃, H₂O); সন্নিবেশ বন্ধন', 'p2c1s16a'],
  ['wq', 'পানির মানদণ্ড', 'wat', 'pH ৬.৫–৮.৫, TDS, DO ≥ ৫, BOD = (D₁−D₂)/P, COD (ডাইক্রোমেট)', 'p2c1s17a'],
  ['hd', 'খরতা', 'wat', 'Ca²⁺/Mg²⁺; অস্থায়ী (HCO₃⁻, ফুটিয়ে) ও স্থায়ী; EDTA টাইট্রেশন: ppm = VM×১০⁵/Vs', 'p2c1s18a'],
  ['wtp', 'পানি শোধন', 'wat', 'ফিটকিরি জমাটকরণ → থিতানো → বালি ফিল্টার → Cl₂ (HOCl); ব্রেকপয়েন্ট', 'p2c1s19a'],
  ['etp', 'ETP', 'wat', 'প্রাথমিক → সক্রিয় কাদা (BOD হ্রাস) → তৃতীয় পর্যায়; নির্গমন মান BOD ≤ ৫০', 'p2c1s20a'],
  ['as', 'আর্সেনিক', 'wat', 'FeOOH বিজারক দ্রবণে As মুক্ত; As(III) জারিত করে As(V) → Fe(OH)₃ এ শোষণ', 'p2c1s21a'],
  ['bm', 'জৈব বিবর্ধন', 'wat', 'Hg (মিথাইলমারকারি), Cd, Pb, Cr(VI); প্রতিটি পুষ্টিস্তরে ঘনত্ব বহুগুণ', 'p2c1s22a'],
  ['cu', 'ঘনত্বের একক', 'sol', '%, M, m, x, ppm, ppb; লঘু জলীয় দ্রবণে ppm ≈ mg L⁻¹', 'p2c1s23a'],
  ['hn', 'হেনরির সূত্র', 'sol', 'C = K_H p; তাপমাত্রা বাড়লে K_H কমে — সোডা, ডুবুরির বেন্ডস, গরমে DO হ্রাস', 'p2c1s23b']
];
const EDGES = [
  ['atm', 'law', 'চাপের একক'], ['law', 'kmt', 'আণবিক ব্যাখ্যা'], ['kmt', 'real', 'বিচ্যুতি'], ['real', 'cyl', 'তরলীকরণ'], ['law', 'cyl', 'P-V হিসাব'],
  ['atm', 'ltn', 'N₂ + O₂'], ['law', 'pol', 'ppm ↔ mg m⁻³'], ['atm', 'ghg', 'IR শোষণ'], ['atm', 'oz', 'স্ট্র্যাটোস্ফিয়ার'], ['ltn', 'rain', 'HNO₃'], ['pol', 'rain', 'SO₂, NOx'], ['pol', 'oz', 'NO + O₃'],
  ['arr', 'bl', 'সাধারণীকরণ'], ['bl', 'lw', 'সাধারণীকরণ'], ['rain', 'bl', 'H⁺ প্রশমন'],
  ['bl', 'wq', 'pH'], ['wq', 'hd', ''], ['hd', 'lw', 'EDTA সন্নিবেশ'], ['wq', 'wtp', ''], ['wtp', 'etp', ''], ['wq', 'etp', 'BOD/COD'], ['wtp', 'as', 'জারণ-শোষণ'], ['as', 'bm', 'ভারী ধাতু'], ['rain', 'bm', 'ধাতু দ্রবণ'],
  ['cu', 'hn', ''], ['hn', 'wq', 'DO'], ['law', 'hn', 'আংশিক চাপ'], ['cu', 'as', 'mg L⁻¹']
];
V.p2c1_conceptMap = {
  t: 'অধ্যায় ১ এর ধারণা মানচিত্র: গ্যাসের ভাষা → বায়ু ও দূষণ → এসিড-ক্ষারক → পানির রসায়ন → দ্রবণ', k: ['int', '2d'],
  cap: 'পরিবেশ রসায়ন অধ্যায়ের ২১টি মূল ধারণা পাঁচটি রঙিন স্তম্ভে: গ্যাস (নীল), বায়ু ও দূষণ (লাল), এসিড-ক্ষারক (বেগুনি), পানি (সবুজাভ নীল), দ্রবণ (কমলা)। সংযোগ রেখাগুলো দেখায় একটি ধারণা কীভাবে অন্যটিতে লাগে — যেমন গ্যাস সূত্রের আংশিক চাপ হেনরির সূত্রে, এসিড বৃষ্টির H⁺ ব্রনস্টেড প্রশমনে, EDTA এর সন্নিবেশ লুইস তত্ত্বে। যেকোনো ধারণায় চাপ দিলে সংযুক্ত রেখায় প্রবাহ-অ্যানিমেশন চলে, মূল সূত্র নিচে আসে; "পাঠে যাও" দিয়ে সংশ্লিষ্ট পাঠ খোলো।',
  html: () => `${X.cv('অধ্যায় ১ এর ধারণা মানচিত্র')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const rowsN = GRP.map(([gid]) => Math.ceil(NODES.filter(n => n[2] === gid).length / 2));
    const hf = w => wide(w) ? 440 : 30 + rowsN.reduce((a, r) => a + 26 + r * 40, 0);
    let L = X.fit(c, hf), sel = 'law', t = 0;
    const layout = () => {
      const { W, H } = L, P = {}, wd = wide(W), band = [];
      if (wd) {
        const cw = (W - 20) / GRP.length;
        GRP.forEach(([gid], gi) => { const ns = NODES.filter(n => n[2] === gid), x = 10 + cw * (gi + 0.5), top = 44, sp = Math.min(70, (H - top - 20) / ns.length); const y0 = top + ((H - top - 10) - sp * ns.length) / 2 + sp / 2; ns.forEach((n, i) => { P[n[0]] = [x + (i % 2 ? 1 : -1) * Math.min(14, cw * 0.06), y0 + i * sp]; }); band.push([10 + cw * gi + 3, 6, cw - 6, H - 12, gi]); });
      } else {
        let y = 10; GRP.forEach(([gid], gi) => { const ns = NODES.filter(n => n[2] === gid), r = rowsN[gi], h = 26 + r * 40; ns.forEach((n, i) => { P[n[0]] = [W * (i % 2 ? 0.74 : 0.26), y + 38 + Math.floor(i / 2) * 40]; }); band.push([6, y, W - 12, h - 6, gi]); y += h; });
      }
      return { P, band, wd };
    };
    let LY = layout();
    const draw = () => {
      const { g, W, H } = L, col = X.C(), { P, band, wd } = LY; g.clearRect(0, 0, W, H);
      band.forEach(([x, y, w, h, gi]) => { const cc = GRP[gi][2]; g.fillStyle = cc + '14'; g.strokeStyle = cc + '55'; g.lineWidth = 1; rr(g, x, y, w, h, 10); g.fill(); g.stroke(); g.fillStyle = cc; g.font = `bold 11px ${col.font}`; g.textAlign = wd ? 'center' : 'left'; g.fillText(GRP[gi][1], wd ? x + w / 2 : x + 10, y + 16); });
      const nb = new Set([sel]); EDGES.forEach(([a, b]) => { if (a === sel) nb.add(b); if (b === sel) nb.add(a); });
      const curve = (a, b) => { const [x1, y1] = P[a], [x2, y2] = P[b], mx = (x1 + x2) / 2, my = (y1 + y2) / 2, dx = x2 - x1, dy = y2 - y1, k = Math.abs(dx) < 30 ? 0.35 : 0.12; return [x1, y1, mx - dy * k, my + dx * k, x2, y2]; };
      // faint edges first
      EDGES.forEach(([a, b]) => { if (a === sel || b === sel) return; const [x1, y1, cx, cy, x2, y2] = curve(a, b); g.strokeStyle = col.mu; g.globalAlpha = 0.28; g.lineWidth = 1; g.beginPath(); g.moveTo(x1, y1); g.quadraticCurveTo(cx, cy, x2, y2); g.stroke(); g.globalAlpha = 1; });
      const placed = [];
      const selCol = GRP.find(z => z[0] === NODES.find(n => n[0] === sel)[2])[2];
      EDGES.forEach(([a, b, lab]) => {
        if (a !== sel && b !== sel) return; const [x1, y1, cx, cy, x2, y2] = curve(a, b);
        g.strokeStyle = selCol; g.lineWidth = 2.4; g.setLineDash([7, 5]); g.lineDashOffset = -t * 30; g.beginPath(); g.moveTo(x1, y1); g.quadraticCurveTo(cx, cy, x2, y2); g.stroke(); g.setLineDash([]);
        // moving particle
        const s = (t * 0.6) % 1, bx = (1 - s) * (1 - s) * x1 + 2 * (1 - s) * s * cx + s * s * x2, by = (1 - s) * (1 - s) * y1 + 2 * (1 - s) * s * cy + s * s * y2; g.fillStyle = selCol; g.beginPath(); g.arc(bx, by, 3.5, 0, 7); g.fill();
        if (lab) { const lx = 0.25 * x1 + 0.5 * cx + 0.25 * x2; let ly = 0.25 * y1 + 0.5 * cy + 0.25 * y2; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; const tw = g.measureText(lab).width; for (let tries = 0; tries < 6 && placed.some(([px, py, pw]) => Math.abs(px - lx) < (pw + tw) / 2 + 6 && Math.abs(py - ly) < 16); tries++) ly += 16; placed.push([lx, ly, tw]); g.fillStyle = col.sf; rr(g, lx - tw / 2 - 4, ly - 9, tw + 8, 14, 5); g.fill(); g.strokeStyle = selCol; g.lineWidth = 1; g.stroke(); g.fillStyle = selCol; g.fillText(lab, lx, ly + 2); }
      });
      NODES.forEach(n => {
        const [x, y] = P[n[0]], on = nb.has(n[0]), me = n[0] === sel, cc = GRP.find(z => z[0] === n[2])[2];
        g.font = `${me ? 'bold ' : ''}10.5px ${col.font}`; const tw = Math.max(64, g.measureText(n[1]).width + 18), h = 26;
        if (me) { g.save(); g.shadowColor = cc; g.shadowBlur = 10 + 4 * Math.sin(t * 4); }
        g.fillStyle = me ? cc : on ? col.s3 : col.sf; g.strokeStyle = cc; g.lineWidth = me ? 2.2 : on ? 1.8 : 1; g.globalAlpha = on ? 1 : 0.8; rr(g, x - tw / 2, y - h / 2, tw, h, 13); g.fill(); g.stroke(); g.globalAlpha = 1; if (me) g.restore();
        g.fillStyle = me ? '#fff' : col.fg; g.textAlign = 'center'; g.fillText(n[1], x, y + 4); n.bb = [x - tw / 2, y - h / 2, tw, h];
      });
    };
    const info = () => { const n = NODES.find(z => z[0] === sel), gp = GRP.find(z => z[0] === n[2]); const links = EDGES.filter(([a, b]) => a === sel || b === sel).map(([a, b, lab]) => { const o = NODES.find(z => z[0] === (a === sel ? b : a)); return `${o[1]}${lab ? ` <span class="small">(${lab})</span>` : ''}`; }); out.innerHTML = `<div><span style="color:${gp[2]};font-weight:700">${gp[1]} ›</span> <b>${n[1]}</b>: ${n[3]}</div><div class="small" style="margin-top:4px">সংযুক্ত: ${links.join(' · ')}</div><div class="ctl" style="margin-top:6px"><button class="btn sm" data-act="lesson" data-id="${n[4]}">পাঠে যাও →</button></div>`; };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; const n = NODES.find(z => z.bb && x >= z.bb[0] && x <= z.bb[0] + z.bb[2] && y >= z.bb[1] && y <= z.bb[1] + z.bb[3]); if (n) { sel = n[0]; info(); A.draw(); } });
    c.style.cursor = 'pointer';
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); LY = layout(); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= এলোমেলো গাণিতিক চর্চা ======================= */
const r2 = (a, b, s) => Math.round((a + Math.random() * (b - a)) / s) * s;
const pick = a => a[Math.floor(Math.random() * a.length)];
const f = (v, d = 3) => (+v.toPrecision(d)).toString();
const GEN = {
  gas: [
    () => { const m = r2(2, 40, 1), G = pick([['O₂', 'O_2', 32], ['N₂', 'N_2', 28], ['CO₂', 'CO_2', 44], ['CH₄', 'CH_4', 16], ['He', 'He', 4]]), T = r2(0, 80, 1), P = r2(0.5, 5, 0.1); const n = m / G[2], V = n * 0.0821 * (T + 273) / P; return { q: `${bn(T)} °C তাপমাত্রা ও ${bn(f(P))} atm চাপে ${bn(m)} g ${G[0]} গ্যাসের আয়তন কত?`, u: 'L', a: V, s: [`n = \\dfrac{${m}}{${G[2]}} = ${f(n)}\\ \\mathrm{mol},\\quad T = ${T + 273}\\ \\mathrm{K}`, `V = \\dfrac{nRT}{P} = \\dfrac{${f(n)}\\times0.0821\\times${T + 273}}{${f(P)}} = ${f(V)}\\ \\mathrm{L}`], tag: 'আদর্শ গ্যাস সমীকরণ' }; },
    () => { const V1 = r2(2, 20, 1), P1 = r2(1, 4, 0.5), T1 = r2(10, 40, 1), P2 = r2(1, 6, 0.5), T2 = r2(50, 150, 5); const V2 = P1 * V1 * (T2 + 273) / ((T1 + 273) * P2); return { q: `${bn(T1)} °C ও ${bn(f(P1))} atm এ একটি গ্যাসের আয়তন ${bn(V1)} L। ${bn(T2)} °C ও ${bn(f(P2))} atm এ আয়তন কত হবে?`, u: 'L', a: V2, s: [`\\dfrac{P_1V_1}{T_1} = \\dfrac{P_2V_2}{T_2}`, `V_2 = \\dfrac{${f(P1)}\\times${V1}\\times${T2 + 273}}{${T1 + 273}\\times${f(P2)}} = ${f(V2)}\\ \\mathrm{L}`], tag: 'সমন্বিত গ্যাস সূত্র' }; },
    () => { const a = r2(1, 6, 1), b = r2(1, 6, 1), P = r2(2, 12, 1); const pa = a / (a + b) * P; return { q: `একটি পাত্রে ${bn(a)} mol N₂ ও ${bn(b)} mol O₂ আছে; মোট চাপ ${bn(P)} atm। N₂ এর আংশিক চাপ কত?`, u: 'atm', a: pa, s: [`x_{\\ce{N2}} = \\dfrac{${a}}{${a}+${b}} = ${f(a / (a + b))}`, `p_{\\ce{N2}} = x\\,P = ${f(a / (a + b))}\\times${P} = ${f(pa)}\\ \\mathrm{atm}`], tag: 'ডাল্টনের আংশিক চাপ সূত্র' }; },
    () => { const A = pick([['H₂', 'H_2', 2], ['He', 'He', 4], ['CH₄', 'CH_4', 16], ['NH₃', 'NH_3', 17]]), B = pick([['O₂', 'O_2', 32], ['CO₂', 'CO_2', 44], ['SO₂', 'SO_2', 64], ['Cl₂', 'Cl_2', 71]]); const r = Math.sqrt(B[2] / A[2]); return { q: `একই অবস্থায় ${A[0]} ও ${B[0]} এর ব্যাপন হারের অনুপাত (${A[0]} : ${B[0]}) কত?`, u: '', a: r, s: [`\\dfrac{r_{\\ce{${A[1]}}}}{r_{\\ce{${B[1]}}}} = \\sqrt{\\dfrac{M_{\\ce{${B[1]}}}}{M_{\\ce{${A[1]}}}}} = \\sqrt{\\dfrac{${B[2]}}{${A[2]}}} = ${f(r)}`], tag: 'গ্রাহামের ব্যাপন সূত্র' }; },
    () => { const T = r2(0, 500, 10), G = pick([['O₂', 32], ['N₂', 28], ['He', 4], ['CO₂', 44]]); const c = Math.sqrt(3 * 8.314 * (T + 273) / (G[1] / 1000)); return { q: `${bn(T)} °C তাপমাত্রায় ${G[0]} অণুর মূল-গড়-বর্গ (rms) বেগ কত?`, u: 'm s⁻¹', a: c, s: [`c_{rms} = \\sqrt{\\dfrac{3RT}{M}} = \\sqrt{\\dfrac{3\\times8.314\\times${T + 273}}{${G[1] / 1000}}} = ${f(c)}\\ \\mathrm{m\\,s^{-1}}`], tag: 'আণবিক গতিতত্ত্ব' }; }
  ],
  air: [
    () => { const G = pick([['SO₂', 64], ['NO₂', 46], ['CO', 28], ['O₃', 48]]), p = r2(0.05, 12, 0.05); const m = p * G[1] / 24.45; return { q: `২৫ °C ও ১ atm এ বায়ুতে ${G[0]} এর ঘনত্ব ${bn(f(p))} ppm। এটি mg m⁻³ এককে কত?`, u: 'mg m⁻³', a: m, s: [`\\text{mg m}^{-3} = \\text{ppm}\\times\\dfrac{M}{24.45} = ${f(p)}\\times\\dfrac{${G[1]}}{24.45} = ${f(m)}`], tag: 'ppm ↔ mg m⁻³ রূপান্তর' }; },
    () => { const C = r2(300, 800, 10); const F = 5.35 * Math.log(C / 280); return { q: `CO₂ এর ঘনত্ব প্রাক-শিল্প ২৮০ ppm থেকে ${bn(C)} ppm হলে বিকিরণ চাপ (ΔF) কত?`, u: 'W m⁻²', a: F, s: [`\\Delta F = 5.35\\ln\\dfrac{${C}}{280} = ${f(F)}\\ \\mathrm{W\\,m^{-2}}`], tag: 'গ্রিনহাউস বিকিরণ চাপ' }; },
    () => { const c = r2(1, 50, 1); const H = 2 * c * 1e-6, pH = -Math.log10(H); return { q: `বৃষ্টির পানিতে H₂SO₄ এর ঘনত্ব ${bn(c)} × ১০⁻⁶ mol L⁻¹ (সম্পূর্ণ বিয়োজিত, অন্য এসিড উপেক্ষা)। pH কত?`, u: '', a: pH, tol: 0.02, abs: true, s: [`[\\ce{H+}] = 2\\times${c}\\times10^{-6} = ${f(H)}\\ \\mathrm{M}`, `\\mathrm{pH} = -\\log(${f(H)}) = ${pH.toFixed(2)}`], tag: 'এসিড বৃষ্টির pH' }; },
    () => { const t = r2(1, 20, 1), S = r2(0.5, 3, 0.1); const so2 = t * S / 100 * 64 / 32; return { q: `একটি ইটভাটায় দৈনিক ${bn(t)} টন কয়লা (${bn(f(S))}% S) পোড়ে। দৈনিক কত টন SO₂ নির্গত হয়?`, u: 'টন', a: so2, s: [`\\ce{S + O2 -> SO2}:\\ 32\\ \\text{g S} \\to 64\\ \\text{g}\\ \\ce{SO2}`, `${t}\\times\\dfrac{${f(S)}}{100}\\times\\dfrac{64}{32} = ${f(so2)}\\ \\text{টন}`], tag: 'দহন থেকে SO₂' }; }
  ],
  wat: [
    () => { const D1 = r2(7.5, 9.0, 0.1), D2 = r2(2, D1 - 2, 0.1), v = pick([3, 5, 6, 10, 15, 30]); const P = v / 300, B = (D1 - D2) / P; return { q: `৩০০ mL BOD বোতলে ${bn(v)} mL নমুনা নিয়ে লঘু করা হলো। প্রাথমিক DO ${bn(f(D1))} ও ৫ দিন পর ${bn(f(D2))} mg L⁻¹। BOD₅ কত?`, u: 'mg L⁻¹', a: B, s: [`P = \\dfrac{${v}}{300} = ${f(P)}`, `\\mathrm{BOD_5} = \\dfrac{D_1 - D_2}{P} = \\dfrac{${f(D1)} - ${f(D2)}}{${f(P)}} = ${f(B)}`], tag: 'BOD₅' }; },
    () => { const A = r2(18, 25, 0.1), B = r2(6, A - 3, 0.1), M = pick([0.1, 0.25]), Vs = pick([20, 25, 50]); const cod = (A - B) * M * 8000 / Vs; return { q: `COD পরীক্ষায় ব্ল্যাংকে ${bn(f(A))} mL ও নমুনায় ${bn(f(B))} mL ${bn(M)} M FAS লেগেছে; নমুনা ${bn(Vs)} mL। COD কত?`, u: 'mg L⁻¹', a: cod, s: [`\\mathrm{COD} = \\dfrac{(A-B)\\times M\\times8000}{V} = \\dfrac{(${f(A)}-${f(B)})\\times${M}\\times8000}{${Vs}} = ${f(cod)}`], tag: 'COD (ডাইক্রোমেট)' }; },
    () => { const V = r2(4, 30, 0.5), M = 0.01, Vs = pick([25, 50, 100]); const h = V * M * 1e5 / Vs; return { q: `${bn(Vs)} mL পানির নমুনার টাইট্রেশনে ${bn(M)} M EDTA এর ${bn(f(V))} mL লাগল। মোট খরতা (CaCO₃ হিসেবে) কত ppm?`, u: 'ppm', a: h, s: [`n_{\\ce{CaCO3}} = n_{\\text{EDTA}} = ${f(V)}\\times10^{-3}\\times${M}`, `\\text{খরতা} = \\dfrac{V M\\times100\\times1000}{V_s} = \\dfrac{${f(V)}\\times${M}\\times10^5}{${Vs}} = ${f(h)}\\ \\mathrm{ppm}`], tag: 'খরতা (EDTA)' }; },
    () => { const L = r2(10, 500, 10), d = r2(0.2, 2, 0.1), av = pick([25, 30, 35]); const mg = L * d * 100 / av; return { q: `${bn(L)} L পানিতে ${bn(f(d))} mg L⁻¹ ক্লোরিন দিতে ${bn(av)}% লভ্য ক্লোরিনযুক্ত ব্লিচিং পাউডার কত mg লাগবে?`, u: 'mg', a: mg, s: [`\\text{প্রয়োজনীয় } \\ce{Cl2} = ${L}\\times${f(d)} = ${f(L * d)}\\ \\mathrm{mg}`, `\\text{ব্লিচিং} = ${f(L * d)}\\times\\dfrac{100}{${av}} = ${f(mg)}\\ \\mathrm{mg}`], tag: 'ক্লোরিনেশন মাত্রা' }; },
    () => { const c = r2(0.02, 0.5, 0.01), L = pick([2, 3, 4, 5]), y = pick([1, 5, 10]); const mg = c * L * 365 * y; return { q: `নলকূপের পানিতে As ${bn(f(c))} mg L⁻¹। দৈনিক ${bn(L)} L পান করলে ${bn(y)} বছরে মোট কত mg আর্সেনিক গ্রহণ হবে?`, u: 'mg', a: mg, s: [`${f(c)}\\times${L}\\times365\\times${y} = ${f(mg)}\\ \\mathrm{mg}`], tag: 'আর্সেনিক গ্রহণ' }; }
  ],
  sol: [
    () => { const G = pick([['O₂', 32, 1.3e-3, 0.21], ['N₂', 28, 6.1e-4, 0.78], ['CO₂', 44, 3.4e-2, 0.00042]]), mult = pick([1, 2, 5, 10]); const p = G[3] * mult, Cm = G[2] * p, mg = Cm * G[1] * 1000; return { q: `২৫ °C এ ${G[0]} এর K_H = ${bn(f(G[2], 2))} mol L⁻¹ atm⁻¹। ${G[0]} এর আংশিক চাপ ${bn(f(p))} atm হলে দ্রাব্যতা কত mg L⁻¹?`, u: 'mg L⁻¹', a: mg, s: [`C = K_H\\,p = ${f(G[2], 2)}\\times${f(p)} = ${f(Cm)}\\ \\mathrm{mol\\,L^{-1}}`, `= ${f(Cm)}\\times${G[1]}\\times1000 = ${f(mg)}\\ \\mathrm{mg\\,L^{-1}}`], tag: 'হেনরির সূত্র' }; },
    () => { const pc = r2(10, 98, 1), rho = r2(1.05, 1.84, 0.01), S = pick([['H₂SO₄', 98], ['HCl', 36.5], ['HNO₃', 63], ['NaOH', 40]]); const M = pc * rho * 10 / S[1]; return { q: `${bn(pc)}% (w/w) ${S[0]} দ্রবণের ঘনত্ব ${bn(f(rho))} g mL⁻¹। মোলারিটি কত?`, u: 'M', a: M, s: [`M = \\dfrac{\\%\\times\\rho\\times10}{M_r} = \\dfrac{${pc}\\times${f(rho)}\\times10}{${S[1]}} = ${f(M)}\\ \\mathrm{mol\\,L^{-1}}`], tag: '% থেকে মোলারিটি' }; },
    () => { const mg = r2(0.5, 50, 0.5), V = r2(1, 10, 1); const ppm = mg / V; return { q: `${bn(V)} L পানির নমুনায় ${bn(f(mg))} mg Pb²⁺ পাওয়া গেল। ঘনত্ব কত ppm?`, u: 'ppm', a: ppm, s: [`\\text{লঘু জলীয় দ্রবণে } 1\\ \\mathrm{ppm} \\approx 1\\ \\mathrm{mg\\,L^{-1}}`, `\\dfrac{${f(mg)}}{${V}} = ${f(ppm)}\\ \\mathrm{ppm}`], tag: 'ppm (জলীয় দ্রবণ)' }; }
  ]
};
const CATS = [['all', 'সব'], ['gas', 'গ্যাস'], ['air', 'বায়ু'], ['wat', 'পানি'], ['sol', 'দ্রবণ']];
const toNum = s => { const map = { '০': 0, '১': 1, '২': 2, '৩': 3, '৪': 4, '৫': 5, '৬': 6, '৭': 7, '৮': 8, '৯': 9 }; const t = String(s).trim().replace(/[০-৯]/g, d => map[d]).replace(/,/g, '').replace(/×\s*10\^?/i, 'e').replace(/\s/g, ''); return t === '' ? NaN : +t; };
V.p2c1_calcDrill = {
  t: 'অনুশীলনী-১ গাণিতিক চর্চা: গ্যাস সূত্র, দূষকের ঘনত্ব, এসিড বৃষ্টি, BOD, COD, খরতা ও হেনরির সূত্র — প্রতিবার নতুন সংখ্যা', k: ['int', 'calc', '2d'],
  cap: 'বিষয় বেছে নাও (বা "সব"), প্রশ্ন পড়ে উত্তর লেখো (বাংলা বা ইংরেজি অঙ্ক — যেমন ১২.৩ বা 12.3; বড় সংখ্যায় 1.2e4) এবং যাচাই করো। নিচের সংখ্যারেখায় তোমার উত্তর (লাল/সবুজ চিহ্ন) ও সঠিক মান (সবুজ পট্টি = ±২% গ্রহণযোগ্য সীমা) পাশাপাশি দেখায় — কতটা কাছে গেলে তা চোখে পড়ে। প্রতিটি উত্তরের পর ধাপে ধাপে সমাধান আসে; বিষয়ভিত্তিক স্কোর ও ধারাবাহিক সঠিক উত্তরের সংখ্যা (streak) দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ct', CATS, 'all')}</div><div class="calc-out" data-q></div><div class="ctl" style="flex-wrap:wrap;gap:6px"><input type="text" inputmode="decimal" data-in placeholder="উত্তর" style="flex:1;min-width:120px;padding:7px 10px;border-radius:8px;border:1px solid var(--line);background:var(--sf);color:var(--fg);font:inherit"><span class="small" data-u></span><button class="btn sm primary" data-chk>যাচাই করো</button><button class="btn sm" data-sh>সমাধান</button><button class="btn sm" data-nx>পরের প্রশ্ন →</button></div>${X.cv('উত্তর বনাম সঠিক মান', 120)}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), qq = el.querySelector('[data-q]'), inp = el.querySelector('[data-in]'), q = s => el.querySelector(s);
    let L = X.fit(c, () => 120), cat = 'all', cur = null, ans = null, done = false, score = 0, tot = 0, streak = 0, best = 0, mk = 0, mkT = 0; const per = {};
    const next = () => {
      const keys = cat === 'all' ? Object.keys(GEN) : [cat], k = pick(keys); cur = pick(GEN[k])(); cur.cat = k; ans = null; done = false; mkT = 0; inp.value = '';
      qq.innerHTML = `<div class="small" style="color:var(--acc);font-weight:700">${CATS.find(z => z[0] === k)[1]} · ${cur.tag}</div><div style="margin-top:3px">${cur.q}</div>`;
      q('[data-u]').textContent = cur.u ? `(${cur.u})` : ''; status(); A.draw();
    };
    const status = (extra = '') => { const pc = Object.entries(per).map(([k, [a, b]]) => `${CATS.find(z => z[0] === k)[1]} ${bn(a)}/${bn(b)}`).join(' · '); out.innerHTML = `${extra}<div class="small" style="margin-top:4px">স্কোর: <b>${bn(score)}/${bn(tot)}</b> · ধারাবাহিক: ${bn(streak)} (সেরা ${bn(best)})${pc ? ' · ' + pc : ''}</div>`; };
    const sol = () => `<div style="margin-top:6px">${cur.s.map(s => TXB(s)).join('')}</div><div class="small">উত্তর ≈ <b>${bn(f(cur.a))}</b> ${cur.u}</div>`;
    const ok = v => { const tol = cur.tol || 0.02; return cur.abs ? Math.abs(v - cur.a) <= tol + 1e-9 : Math.abs(v - cur.a) <= tol * Math.abs(cur.a); };
    q('[data-chk]').onclick = () => {
      if (done) return; const v = toNum(inp.value); if (!isFinite(v)) { status('<div class="small">একটি সংখ্যা লেখো।</div>'); return; }
      ans = v; done = true; tot++; per[cur.cat] = per[cur.cat] || [0, 0]; per[cur.cat][1]++; const good = ok(v);
      if (good) { score++; streak++; best = Math.max(best, streak); per[cur.cat][0]++; } else streak = 0;
      const err = cur.a ? Math.abs(v - cur.a) / Math.abs(cur.a) * 100 : 0;
      status(`<div style="font-weight:700;color:${good ? 'var(--ok)' : 'var(--bad)'}">${good ? '✓ সঠিক!' : `✗ হয়নি — বিচ্যুতি ${bn(err.toFixed(err < 10 ? 1 : 0))}%`}</div>${sol()}`); mkT = 0; A.draw();
    };
    q('[data-sh]').onclick = () => { if (!done) { done = true; tot++; streak = 0; per[cur.cat] = per[cur.cat] || [0, 0]; per[cur.cat][1]++; } status(sol()); A.draw(); };
    q('[data-nx]').onclick = next;
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') q('[data-chk]').click(); });
    X.onSeg(el, 'ct', v => { cat = v; next(); });
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); if (!cur) return;
      const a = cur.a, vals = [a]; if (ans !== null && isFinite(ans)) vals.push(ans);
      let lo = Math.min(...vals), hi = Math.max(...vals); const span = Math.max(hi - lo, Math.abs(a) * 0.3, 1e-9); lo -= span * 0.35; hi += span * 0.35; if (a > 0 && lo < 0 && (ans === null || ans >= 0)) lo = 0;
      const x0 = 24, x1 = W - 24, y = 62, X_ = v => x0 + (v - lo) / (hi - lo) * (x1 - x0);
      g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x0, y); g.lineTo(x1, y); g.stroke();
      g.font = `9.5px ${col.font}`; g.fillStyle = col.mu; g.textAlign = 'center'; if (done) for (let i = 0; i <= 4; i++) { const v = lo + (hi - lo) * i / 4, x = X_(v); g.beginPath(); g.moveTo(x, y - 4); g.lineTo(x, y + 4); g.stroke(); g.fillText(bn(f(v, 3)), x, y + 18); }
      if (done) {
        const tol = cur.abs ? (cur.tol || 0.02) : Math.abs(a) * (cur.tol || 0.02), bw = Math.max(4, X_(a + tol) - X_(a - tol)); g.fillStyle = 'rgba(39,174,96,.35)'; g.fillRect(X_(a) - bw / 2, y - 12, bw, 24);
        g.fillStyle = '#27ae60'; g.beginPath(); g.moveTo(X_(a), y - 14); g.lineTo(X_(a) - 6, y - 24); g.lineTo(X_(a) + 6, y - 24); g.fill(); g.font = `bold 10px ${col.font}`; g.fillText(`সঠিক ${bn(f(a))}`, X_(a), y - 28);
        if (ans !== null) { const k = Math.min(1, mkT * 2.5), e = 1 - Math.pow(1 - k, 3), xa = X_(a) + (X_(ans) - X_(a)) * 1, ya = y + 14 + (1 - e) * 20; const good = ok(ans); g.fillStyle = good ? '#27ae60' : '#c0392b'; g.beginPath(); g.moveTo(xa, y + 3); g.lineTo(xa - 6, ya + 10); g.lineTo(xa + 6, ya + 10); g.globalAlpha = e; g.fill(); g.font = `bold 10px ${col.font}`; g.fillText(`তোমার ${bn(f(ans))}`, xa, H - 6); g.globalAlpha = 1; }
      } else { g.fillStyle = col.mu; g.font = `10.5px ${col.font}`; g.fillText('উত্তর যাচাই করলে এখানে সঠিক মানের সাথে তুলনা দেখাবে', W / 2, 26); }
      // streak flames
      for (let i = 0; i < Math.min(streak, 10); i++) { const x = W - 14 - i * 12, yy = 14; g.fillStyle = `hsl(${30 + i * 4},90%,${55 + 6 * Math.sin(mk * 6 + i)}%)`; g.beginPath(); g.arc(x, yy, 4.5, 0, 7); g.fill(); }
    };
    const A = X.anim(el, dt => { if (dt) { mk += dt; mkT += dt; } draw(); }, { paused: false });
    next();
    const un = X.onResize(el, () => { L = X.fit(c, () => 120); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
