/* ২য় পত্র অধ্যায় ১ visuals part 7 — gas cylinders (1.8), lightning & nitrogen cycle (1.9) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend, flame = P2.flame;
const R = 0.0821;
const pvProp = T => Math.exp(9.97 - 2300 / T), pvBut = T => Math.exp(10.32 - 2811 / T); // bar
const arrowTo = (g, x1, y1, x2, y2, cl, w = 2, hs = 8) => { g.strokeStyle = cl; g.fillStyle = cl; g.lineWidth = w; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); const a = Math.atan2(y2 - y1, x2 - x1); g.beginPath(); g.moveTo(x2, y2); g.lineTo(x2 - hs * Math.cos(a - .42), y2 - hs * Math.sin(a - .42)); g.lineTo(x2 - hs * Math.cos(a + .42), y2 - hs * Math.sin(a + .42)); g.fill(); };

/* ======================= ১.৮ গ্যাস সিলিন্ডার: CNG বনাম LPG ======================= */
V.p2c1_cylinder = {
  t: 'সংকুচিত (CNG) বনাম তরলীকৃত (LPG) গ্যাস সিলিন্ডার: ব্যবহারে চাপের পরিবর্তন ও তাপমাত্রার প্রভাব', k: ['anim', 'int', '2d', 'calc'],
  cap: '"CNG" দৃশ্যে ৬০ L সিলিন্ডারে মিথেন গ্যাস (২৭ °C এ পূর্ণ অবস্থায় ২০০ bar); "LPG" দৃশ্যে ২৬ L সিলিন্ডারে ১২ kg প্রোপেন-বিউটেন (৩০:৭০) — নিচে তরল, উপরে বাষ্প। "গ্যাস ব্যবহার" স্লাইডারে কতটুকু খরচ হয়েছে বদলাও (চুলায় নীল আগুন জ্বলে): CNG এর চাপ সমানুপাতে কমে, LPG এর চাপ তরল থাকা পর্যন্ত বাষ্পচাপে স্থির থেকে শেষে হঠাৎ পড়ে যায় (ডানের লেখচিত্র)। তাপমাত্রা স্লাইডারে রোদ/ঠান্ডার প্রভাব দেখো — নিরাপত্তা ভাল্ভের সীমা লাল রেখায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('cy', [['cng', 'CNG (সংকুচিত)'], ['lpg', 'LPG (তরলীকৃত)']], 'lpg')}</div>${X.cv('গ্যাস সিলিন্ডার')}<div class="ctl"><label class="small" style="flex:1;min-width:140px">গ্যাস ব্যবহার = <b data-uv></b>%<input type="range" min="0" max="100" step="1" value="20" data-u></label><label class="small" style="flex:1;min-width:140px">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="0" max="70" step="1" value="27" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 600;
    let L = X.fit(c, hf), md = 'lpg', use = 20, tc = 27, t = 0;
    const CNG = { V: 60, n0: 200 / 1.01325 * 60 / (R * 300.15), relief: 250 }, LPG = { V: 26, n0: 12000 / 53.8, relief: 17.5, xl: 0.3 };
    const Pof = (u, T) => { // absolute bar
      if (md === 'cng') { const n = CNG.n0 * (1 - u / 100); return n * R * T / CNG.V * 1.01325; }
      const n = LPG.n0 * (1 - u / 100), ps = LPG.xl * pvProp(T) + (1 - LPG.xl) * pvBut(T); const nvap = ps / 1.01325 * LPG.V / (R * T); return n > nvap ? ps : n * R * T / LPG.V * 1.01325;
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), T = tc + 273.15, P = Pof(use, T), S = md === 'cng' ? CNG : LPG;
      // cylinder body
      const cx = wd ? 40 : W / 2 - 70, cy = 46, cw = md === 'cng' ? 70 : 96, ch = wd ? H - 110 : 230;
      const bodyG = g.createLinearGradient(cx, 0, cx + cw, 0); const base = md === 'cng' ? ['#5b6b7a', '#9fb0c0', '#4a5866'] : ['#a3271c', '#e2604f', '#86201a']; bodyG.addColorStop(0, base[0]); bodyG.addColorStop(.45, base[1]); bodyG.addColorStop(1, base[2]);
      g.fillStyle = bodyG; g.beginPath(); g.roundRect ? g.roundRect(cx, cy, cw, ch, cw * 0.45) : g.rect(cx, cy, cw, ch); g.fill();
      // inner cut-away window
      const ix = cx + 10, iy = cy + 20, iw = cw - 20, ih = ch - 40; g.fillStyle = col.sf; g.globalAlpha = .9; g.fillRect(ix, iy, iw, ih); g.globalAlpha = 1;
      const rem = 1 - use / 100, Rn = X.rng(5);
      if (md === 'cng') { const N = Math.round(90 * rem); for (let i = 0; i < N; i++) { const x = ix + 4 + ((Rn() + t * 0.05 * (Rn() - .5)) % 1 + 1) % 1 * (iw - 8), y = iy + 4 + ((Rn() + t * 0.05 * (Rn() - .5)) % 1 + 1) % 1 * (ih - 8); ball(g, x, y, 2.6, '#2f9e44', '#c8f0cf'); } }
      else { const ps = LPG.xl * pvProp(T) + (1 - LPG.xl) * pvBut(T), nvap = ps / 1.01325 * LPG.V / (R * T), nliq = Math.max(0, LPG.n0 * rem - nvap), lf = nliq / LPG.n0 * 0.84;
        const ly = iy + ih * (1 - lf); g.fillStyle = 'rgba(255,190,60,.55)'; g.fillRect(ix, ly, iw, iy + ih - ly); g.strokeStyle = '#c98a10'; g.lineWidth = 1.4; g.beginPath(); for (let x = 0; x <= iw; x += 4) { const yy = ly + Math.sin(x / 9 + t * 3) * 1.6; x ? g.lineTo(ix + x, yy) : g.moveTo(ix, yy); } g.stroke();
        for (let i = 0; i < 26; i++) { const x = ix + 4 + Rn() * (iw - 8), y = iy + 4 + ((Rn() - t * 0.08) % 1 + 1) % 1 * Math.max(4, ly - iy - 8); ball(g, x, y, 2.2, '#d06a1e', '#ffd2a8'); }
        if (lf > 0.01) { for (let i = 0; i < 6; i++) { const bx = ix + 8 + Rn() * (iw - 16), by = iy + ih - ((t * 30 + i * 23) % Math.max(10, iy + ih - ly)); if (by > ly) { g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 1; g.beginPath(); g.arc(bx, by, 2, 0, 7); g.stroke(); } } }
        g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; if (lf > 0.04) g.fillText('তরল LPG', ix + iw / 2, Math.min(iy + ih - 6, ly + 16)); g.fillText('বাষ্প', ix + iw / 2, iy + 14); }
      // valve and gauge
      g.fillStyle = '#7a7f86'; g.fillRect(cx + cw / 2 - 8, cy - 14, 16, 16); g.fillRect(cx + cw / 2 + 6, cy - 10, 34, 6);
      const gx = cx + cw / 2 + 56, gy = cy - 8, gr = 22; g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.arc(gx, gy, gr, 0, 7); g.fill(); g.stroke();
      const Pg = Math.max(0, P - 1.013), Pmax = md === 'cng' ? 300 : 20; for (let k = 0; k <= 10; k++) { const a = Math.PI * (0.75 + 1.5 * k / 10); g.strokeStyle = k / 10 * Pmax >= S.relief ? '#c0392b' : col.fg; g.beginPath(); g.moveTo(gx + Math.cos(a) * gr * .75, gy + Math.sin(a) * gr * .75); g.lineTo(gx + Math.cos(a) * gr * .95, gy + Math.sin(a) * gr * .95); g.stroke(); }
      const na = Math.PI * (0.75 + 1.5 * Math.min(1, Pg / Pmax)); g.strokeStyle = '#c0392b'; g.lineWidth = 2; g.beginPath(); g.moveTo(gx, gy); g.lineTo(gx + Math.cos(na) * gr * .85, gy + Math.sin(na) * gr * .85); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`${fx(Pg, 1)} bar (গেজ)`, gx + gr + 6, gy + 4);
      // burner
      if (use < 100) { const bx = cx + cw + (wd ? 60 : 50), by = cy + ch - 10; g.strokeStyle = col.mu; g.lineWidth = 2; g.beginPath(); g.moveTo(cx + cw / 2 + 40, cy - 7); g.quadraticCurveTo(bx + 40, cy, bx, by - 20); g.stroke(); g.fillStyle = '#444'; g.fillRect(bx - 18, by - 20, 36, 8); const fl = Math.min(1, P / (md === 'cng' ? 20 : 2.5)); for (let k = -2; k <= 2; k++) { const fh = 14 * fl * (1 + 0.2 * Math.sin(t * 9 + k)); const gg = g.createLinearGradient(0, by - 22 - fh, 0, by - 22); gg.addColorStop(0, 'rgba(80,140,255,0)'); gg.addColorStop(1, 'rgba(60,110,255,.9)'); g.fillStyle = gg; g.beginPath(); g.ellipse(bx + k * 6, by - 22 - fh / 2, 2.6, fh / 2, 0, 0, 7); g.fill(); } }
      if (P - 1.013 > S.relief) { g.fillStyle = '#c0392b'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('⚠ নিরাপত্তা ভাল্ভ খুলবে!', cx + cw / 2, cy + ch + 20); }
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(md === 'cng' ? 'CNG ৬০ L' : 'LPG ১২ kg', cx + cw / 2, cy + ch + (P - 1.013 > S.relief ? 36 : 20));
      // graph
      const gx0 = wd ? W * 0.52 : 56, gy0 = wd ? 30 : cy + ch + 60, gw = wd ? W - gx0 - 20 : W - 78, gh = wd ? H - 80 : H - gy0 - 46;
      const ymax = md === 'cng' ? 300 : 20;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 100, ymax, col, xt: [0, 25, 50, 75, 100], yt: md === 'cng' ? [0, 100, 200, 300] : [0, 5, 10, 15, 20], xl: 'গ্যাস ব্যবহৃত (%)', yl: 'চাপ (bar, গেজ)', ylx: 34 });
      path(g, [[Pl.X(0), Pl.Y(S.relief)], [Pl.X(100), Pl.Y(S.relief)]], '#c0392b', 1.2, [5, 4]); g.fillStyle = '#c0392b'; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('নিরাপত্তা ভাল্ভ', Pl.X(98), Pl.Y(S.relief) - 4);
      [[273.15, '#2d6fd6', '০ °C'], [T, '#d06a1e', `${bn(tc)} °C`]].forEach(([TT, cl]) => { const pts = []; for (let u = 0; u <= 100; u += 0.5) pts.push([Pl.X(u), Pl.Y(Math.min(ymax, Math.max(0, Pof(u, TT) - 1.013)))]); path(g, pts, cl, TT === T ? 2.6 : 1.4, TT === T ? [] : [4, 3]); });
      ball(g, Pl.X(use), Pl.Y(Math.min(ymax, Pg)), 6, '#c0392b', '#ffb3a8');
      legend(g, col, gx0 + gw, gy0 + gh * 0.42, [['#d06a1e', `বর্তমান T = ${bn(tc)} °C`], ['#2d6fd6', '০ °C (শীত)', [4, 3]]], true);
    };
    const info = () => { const T = tc + 273.15, P = Pof(use, T); q('[data-uv]').textContent = bn(use); q('[data-tv]').textContent = bn(tc);
      if (md === 'cng') { const n = CNG.n0 * (1 - use / 100); out.innerHTML = TXB(`\\begin{aligned}P &= \\dfrac{nRT}{V} = \\dfrac{${n.toFixed(0)}\\times0.0821\\times${T.toFixed(0)}}{60}\\\\ &= ${(P / 1.01325).toFixed(1)}\\ \\mathrm{atm}\\\\ &= ${P.toFixed(1)}\\ \\mathrm{bar}\\end{aligned}`) + `<div class="small">বাকি মিথেন ${fx(n * 16 / 1000, 2)} kg (আদর্শ হিসাবে; উচ্চ চাপে বাস্তবে Z ≈ ০.৮৩ বলে আরও বেশি)। চাপ বাকি গ্যাসের সমানুপাতিক — গেজ দেখেই বোঝা যায় কতটুকু আছে।</div>`; }
      else { const pp = pvProp(T), pb = pvBut(T), ps = 0.3 * pp + 0.7 * pb; out.innerHTML = TXB(`\\begin{aligned}P_{\\text{বাষ্প}} &= x_{\\text{প্রোপেন}}P^\\circ_{\\text{প্রোপেন}} + x_{\\text{বিউটেন}}P^\\circ_{\\text{বিউটেন}}\\\\ &= 0.3\\times${pp.toFixed(2)} + 0.7\\times${pb.toFixed(2)}\\\\ &= ${ps.toFixed(2)}\\ \\mathrm{bar}\\end{aligned}`) + `<div class="small">বাকি LPG ${fx(12 * (1 - use / 100), 2)} kg। ${P < ps - 0.05 ? '<b>তরল শেষ</b> — এখন চাপ বাকি বাষ্পের সমানুপাতে দ্রুত কমছে; সিলিন্ডার বদলানোর সময়।' : 'তরল থাকা পর্যন্ত চাপ পরিমাণ নয়, কেবল তাপমাত্রার উপর নির্ভর করে — গেজ দেখে বাকি গ্যাস বোঝা যায় না, ওজন মাপতে হয়।'} ${tc < 8 ? 'ঠান্ডায় বিউটেন ঠিকমতো বাষ্পীভূত হয় না — আগুন দুর্বল।' : ''}</div>`; } };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'cy', k => { md = k; info(); A.draw(); });
    q('[data-u]').oninput = e => { use = +e.target.value; info(); A.draw(); };
    q('[data-t]').oninput = e => { tc = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৯ বজ্রপাত থেকে নাইট্রেট ======================= */
const LSTEP = [
  [0.00, 'বজ্রপাত', 'বজ্রের পথে বায়ুর তাপমাত্রা ~৩০,০০০ K — N≡N ত্রিবন্ধন ভাঙার শক্তি মেলে।', '\\text{বিদ্যুৎ ঝলক: } \\ce{N2} \\text{ ও } \\ce{O2} \\text{ পরমাণুতে ভাঙে}'],
  [0.16, 'NO গঠন', 'অতি উচ্চ তাপমাত্রায় নাইট্রোজেন ও অক্সিজেন যুক্ত হয়ে বর্ণহীন নাইট্রিক অক্সাইড; দ্রুত ঠান্ডা হওয়ায় NO ভাঙার সময় পায় না।', '\\ce{N2 + O2 -> 2NO}\\quad \\Delta H = +180.5\\ \\mathrm{kJ}'],
  [0.36, 'NO₂ গঠন', 'ঠান্ডা বায়ুতে NO অক্সিজেনের সাথে মিলে বাদামি নাইট্রোজেন ডাইঅক্সাইড।', '\\ce{2NO + O2 -> 2NO2}'],
  [0.56, 'নাইট্রিক এসিড', 'মেঘ ও বৃষ্টির পানিতে NO₂ দ্রবীভূত হয়ে নাইট্রিক এসিড (অসমানুপাতিক বিক্রিয়া)।', '\\ce{3NO2 + H2O -> 2HNO3 + NO}'],
  [0.78, 'মাটিতে নাইট্রেট', 'বৃষ্টির সাথে HNO₃ মাটিতে পড়ে লবণের সাথে নাইট্রেট তৈরি করে — উদ্ভিদ শিকড় দিয়ে শোষণ করে।', '\\ce{CaCO3 + 2HNO3 -> Ca(NO3)2 + CO2 + H2O}']
];
V.p2c1_lightning = {
  t: 'বজ্রপাতে নাইট্রোজেন সংবন্ধন: N₂ + O₂ → NO → NO₂ → HNO₃ → মাটিতে নাইট্রেট (অ্যানিমেশন)', k: ['anim', 'int', '2d'],
  cap: 'ঝড়ো মেঘ থেকে বজ্রপাত হয় (সাদা ঝলক)। বজ্রের পথে নীল N₂ ও লাল O₂ অণু ভেঙে NO (বেগুনি-ধূসর) তৈরি হয়; বাতাসে NO অক্সিজেনের সাথে মিলে বাদামি NO₂ মেঘ; বৃষ্টির ফোঁটায় দ্রবীভূত হয়ে HNO₃; মাটিতে পড়ে নাইট্রেট — আর ধানগাছ গাঢ় সবুজ হয়ে ওঠে। ধাপ বোতাম দিয়ে যেকোনো পর্যায়ে যাও, নিচে সেই ধাপের সমীকরণ।',
  html: () => `${X.cv('বজ্রপাত ও নাইট্রোজেন সংবন্ধন')}<div class="ctl" style="flex-wrap:wrap"><button class="btn sm" data-pp></button>${LSTEP.map((s, i) => `<button class="btn sm" data-ls="${i}">${bn(i + 1)}. ${s[1]}</button>`).join('')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 330 : 380;
    let L = X.fit(c, hf), ph = 0, cur = -1;
    const Rn = X.rng(14), mol = Array.from({ length: 34 }, (_, i) => ({ x: Rn(), y: 0.15 + Rn() * 0.4, k: i % 4 === 0 ? 'O' : 'N', ph: Rn() * 6 })), drops = Array.from({ length: 40 }, () => ({ x: Rn(), y: Rn(), v: 0.6 + Rn() * 0.4 }));
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const step = LSTEP.reduce((a, s, i) => ph >= s[0] ? i : a, 0); const sky = g.createLinearGradient(0, 0, 0, H * 0.78); const dark = step <= 3; sky.addColorStop(0, dark ? '#2c3240' : '#7a9cc6'); sky.addColorStop(1, dark ? '#59627a' : '#c9dcf0'); g.fillStyle = sky; g.fillRect(0, 0, W, H * 0.78);
      // flash
      const fl = ph < 0.12 ? Math.max(0, 1 - Math.abs(ph - 0.03) * 18) : 0; if (fl > 0) { g.fillStyle = `rgba(255,255,240,${fl * 0.35})`; g.fillRect(0, 0, W, H); }
      // clouds
      const cloud = (x, y, s) => { g.fillStyle = dark ? '#3d4456' : '#eef2f7'; [[0, 0, 1], [0.8, -0.2, 0.8], [1.5, 0.05, 0.9], [-0.8, 0.1, 0.75], [0.4, 0.3, 0.9]].forEach(([dx, dy, r]) => { g.beginPath(); g.arc(x + dx * s, y + dy * s, r * s, 0, 7); g.fill(); }); };
      cloud(W * 0.3, H * 0.1, 34); cloud(W * 0.68, H * 0.08, 40);
      // bolt
      const bx0 = W * 0.48; const bolt = [[bx0, H * 0.14], [bx0 - 18, H * 0.3], [bx0 + 8, H * 0.32], [bx0 - 14, H * 0.5], [bx0 + 10, H * 0.52], [bx0 - 6, H * 0.76]];
      if (ph < 0.16) { const op = ph < 0.14 ? 0.65 + 0.35 * Math.sin(ph * 260) : 0; g.globalAlpha = Math.max(0, op); g.strokeStyle = '#fffbe0'; g.lineWidth = 5; g.shadowColor = '#fff6a0'; g.shadowBlur = 18; g.beginPath(); bolt.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y)); g.stroke(); g.lineWidth = 2; g.strokeStyle = '#ffffff'; g.stroke(); g.shadowBlur = 0; g.globalAlpha = 1; }
      // molecules
      mol.forEach((m, i) => { const x = m.x * W + Math.sin(ph * 20 + m.ph) * 6, y = m.y * H + Math.cos(ph * 17 + m.ph) * 4, near = Math.abs(x - bx0) < W * 0.14;
        if (ph < 0.16 || !near) { const [c1, c2] = m.k === 'N' ? ['#2d6fd6', '#a9c8ff'] : ['#c0392b', '#ffb3a8']; ball(g, x - 3, y, 3.4, c1, c2); ball(g, x + 3, y, 3.4, c1, c2); }
        else if (ph < 0.36) { ball(g, x - 3, y, 3.4, '#2d6fd6', '#a9c8ff'); ball(g, x + 3, y, 3.2, '#c0392b', '#ffb3a8'); }
        else { ball(g, x - 3, y, 3.4, '#2d6fd6', '#a9c8ff'); ball(g, x + 3, y - 3, 3.2, '#c0392b', '#ffb3a8'); ball(g, x + 3, y + 3, 3.2, '#c0392b', '#ffb3a8'); } });
      if (ph >= 0.36 && ph < 0.8) { const op = Math.min(1, (ph - 0.36) / 0.1) * (ph > 0.7 ? Math.max(0, 1 - (ph - 0.7) / 0.1) : 1); g.fillStyle = `rgba(150,80,30,${0.25 * op})`; g.beginPath(); g.ellipse(bx0, H * 0.35, W * 0.2, H * 0.12, 0, 0, 7); g.fill(); g.fillStyle = `rgba(110,55,20,${op})`; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('NO₂ (বাদামি)', bx0, H * 0.24); }
      // rain
      if (ph >= 0.5) drops.forEach(d => { const y = ((d.y + ph * 3 * d.v) % 1) * H * 0.78; g.strokeStyle = ph >= 0.56 && ph < 0.92 ? 'rgba(200,120,60,.75)' : 'rgba(180,210,255,.7)'; g.lineWidth = 1.3; g.beginPath(); g.moveTo(d.x * W, y); g.lineTo(d.x * W - 2, y + 9); g.stroke(); });
      // ground
      g.fillStyle = '#6b4a2b'; g.fillRect(0, H * 0.78, W, H * 0.22); g.fillStyle = '#8a6a43'; g.fillRect(0, H * 0.78, W, 6);
      if (ph >= 0.78) { const op = Math.min(1, (ph - 0.78) / 0.1); for (let i = 0; i < 18; i++) { const x = (i * 0.057 + 0.03) * W, y = H * 0.84 + (i % 3) * 10; g.fillStyle = `rgba(255,255,255,${op})`; g.font = `bold 9px ${col.font}`; g.textAlign = 'center'; g.fillText('NO₃⁻', x, y); } }
      // rice plants
      const green = ph >= 0.85 ? Math.min(1, (ph - 0.85) / 0.1) : 0; for (let i = 0; i < 9; i++) { const x = W * (0.08 + i * 0.105), y0 = H * 0.79; const cl = `rgb(${Math.round(150 - 110 * green)},${Math.round(180 - 30 * green)},${Math.round(70 - 30 * green)})`; g.strokeStyle = cl; g.lineWidth = 2.2; for (let k = -2; k <= 2; k++) { g.beginPath(); g.moveTo(x, y0); g.quadraticCurveTo(x + k * 5, y0 - 22, x + k * 10, y0 - 34 - Math.abs(k) * -3); g.stroke(); } }
      g.fillStyle = '#fff'; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`ধাপ ${bn(step + 1)}: ${LSTEP[step][1]}`, 10, 18); if (ph < 0.16) g.fillText('~৩০,০০০ K', bx0 + 14, H * 0.42);
    };
    const info = () => { const step = LSTEP.reduce((a, s, i) => ph >= s[0] ? i : a, 0); if (step === cur) return; cur = step; el.querySelectorAll('[data-ls]').forEach(b => b.classList.toggle('primary', +b.dataset.ls === step)); out.innerHTML = `<div class="small" style="margin-bottom:4px">${LSTEP[step][2]}</div>` + TXB(LSTEP[step][3]); };
    const A = X.anim(el, dt => { if (dt) { ph = (ph + dt / 14) % 1; info(); } draw(); }, { paused: false }); X.pp(el, A);
    el.querySelectorAll('[data-ls]').forEach(b => { b.onclick = () => { ph = LSTEP[+b.dataset.ls][0] + 0.01; info(); A.draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৯ নাইট্রোজেন চক্র ======================= */
const NN = { air: ['বায়ুর N₂ (৭৮%)', 'বায়ুর N₂', 0.5, 0.46], nh: ['NH₃ / NH₄⁺', 'NH₄⁺', 0.13, 0.52], no2: ['NO₂⁻ (নাইট্রাইট)', 'NO₂⁻', 0.27, 0.9], no3: ['NO₃⁻ (নাইট্রেট)', 'NO₃⁻', 0.73, 0.9], plant: ['উদ্ভিদ প্রোটিন', 'উদ্ভিদ', 0.87, 0.52], animal: ['প্রাণী প্রোটিন', 'প্রাণী', 0.8, 0.1], dead: ['মৃতদেহ ও বর্জ্য', 'মৃত/বর্জ্য', 0.2, 0.1] };
const NP = [['lightning', 'বজ্রপাত', 'air', 'no3', '#d69a1e', 'N₂ + O₂ → 2NO → NO₂ → HNO₃ → বৃষ্টিতে নাইট্রেট (১.৯)।'], ['bio', 'জৈবিক সংবন্ধন', 'air', 'nh', '#2f9e44', 'রাইজোবিয়াম (ডালের শিকড়ের গুটি), অ্যাজোটোব্যাক্টর, নীলাভ-সবুজ শৈবাল — নাইট্রোজিনেজ এনজাইম N₂ কে NH₃ এ রূপান্তর করে।'], ['haber', 'হেবার পদ্ধতি', 'air', 'nh', '#7b3fa0', 'N₂ + 3H₂ ⇌ 2NH₃ (Fe, ৪৫০ °C, ২০০ atm) — ইউরিয়া সারের উৎস; শিল্প সংবন্ধন জৈবিকের প্রায় সমান।'], ['nitri1', 'নাইট্রিফিকেশন ১', 'nh', 'no2', '#2d6fd6', 'নাইট্রোসোমোনাস ব্যাকটেরিয়া NH₄⁺ কে NO₂⁻ এ জারিত করে।'], ['nitri2', 'নাইট্রিফিকেশন ২', 'no2', 'no3', '#2d6fd6', 'নাইট্রোব্যাক্টর NO₂⁻ কে NO₃⁻ এ জারিত করে।'], ['uptake', 'শোষণ', 'no3', 'plant', '#2f9e44', 'উদ্ভিদ শিকড় দিয়ে NO₃⁻ (ও NH₄⁺) শোষণ করে অ্যামিনো এসিড, প্রোটিন, নিউক্লিক এসিড ও ক্লোরোফিল তৈরি করে।'], ['food', 'খাদ্য শৃঙ্খল', 'plant', 'animal', '#c0392b', 'প্রাণী উদ্ভিদ খেয়ে নাইট্রোজেন গ্রহণ করে।'], ['death', 'মৃত্যু ও রেচন', 'animal', 'dead', '#8a8f98', 'মৃতদেহ, মলমূত্র (ইউরিয়া) ও ঝরা পাতায় জৈব নাইট্রোজেন।'], ['ammon', 'অ্যামোনিফিকেশন', 'dead', 'nh', '#a8692b', 'বিয়োজক ব্যাকটেরিয়া ও ছত্রাক জৈব N কে NH₄⁺ এ ভাঙে।'], ['denit', 'ডিনাইট্রিফিকেশন', 'no3', 'air', '#c0392b', 'জলাবদ্ধ (অক্সিজেনহীন) মাটিতে সিউডোমোনাস জাতীয় ব্যাকটেরিয়া NO₃⁻ কে N₂ (ও N₂O) এ রূপান্তর করে বায়ুতে ফেরত পাঠায়।']];
V.p2c1_nCycle = {
  t: 'নাইট্রোজেন চক্র: সংবন্ধন, নাইট্রিফিকেশন, শোষণ, অ্যামোনিফিকেশন ও ডিনাইট্রিফিকেশন (ইন্টারঅ্যাকটিভ)', k: ['anim', 'int', '2d', 'info'],
  cap: 'বায়ুর N₂ থেকে মাটি, উদ্ভিদ, প্রাণী হয়ে আবার বায়ুতে ফেরা নাইট্রোজেনের পূর্ণ চক্র। প্রতিটি তীর একটি প্রক্রিয়া, চলমান বিন্দু নাইট্রোজেনের প্রবাহের দিক দেখায়। নিচের বোতামে একটি প্রক্রিয়া বেছে নিলে সেই তীরটি উজ্জ্বল হয় এবং বিবরণ দেখায় — বজ্রপাত (হলুদ) হলো তিনটি সংবন্ধন পথের একটি।',
  html: () => `${X.cv('নাইট্রোজেন চক্র')}<div class="ctl" style="flex-wrap:wrap">${NP.map(p => `<button class="btn sm" data-np="${p[0]}">${p[1]}</button>`).join('')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 360 : 440;
    let L = X.fit(c, hf), sel = 'lightning', t = 0;
    const BEND = { lightning: 0.22, denit: 0.22, bio: 0.2, haber: -0.2, death: 0, food: 0.12, uptake: 0.12, nitri1: 0.12, nitri2: 0.08, ammon: 0.12 };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const pos = k => [NN[k][2] * W, NN[k][3] * H], bw = wd ? 128 : 62, bh = wd ? 30 : 26;
      const clip = (x, y, tx, ty, pad) => { const dx = tx - x, dy = ty - y, s = Math.min(Math.abs(dx) > 1e-6 ? (bw / 2 + pad) / Math.abs(dx) : 1e9, Math.abs(dy) > 1e-6 ? (bh / 2 + pad) / Math.abs(dy) : 1e9); return [x + dx * s, y + dy * s]; };
      // soil / sky hint
      g.fillStyle = 'rgba(140,100,60,.10)'; g.fillRect(0, H * 0.72, W, H * 0.28); g.fillStyle = 'rgba(120,170,230,.10)'; g.fillRect(0, 0, W, H * 0.72);
      const labels = [];
      NP.forEach(([id, nm, a, b, cl]) => { const [x1, y1] = pos(a), [x2, y2] = pos(b), on = id === sel; const mx = (x1 + x2) / 2, my = (y1 + y2) / 2, L2 = Math.hypot(x2 - x1, y2 - y1), nx = -(y2 - y1) / L2, ny = (x2 - x1) / L2, bd = BEND[id] * L2; const qx = mx + nx * bd, qy = my + ny * bd;
        const [sx, sy] = clip(x1, y1, qx, qy, 3), [ex, ey] = clip(x2, y2, qx, qy, 5);
        g.globalAlpha = on ? 1 : 0.4; g.strokeStyle = cl; g.lineWidth = on ? 3.6 : 2; g.beginPath(); g.moveTo(sx, sy); g.quadraticCurveTo(qx, qy, ex, ey); g.stroke();
        const a2 = Math.atan2(ey - qy, ex - qx), hs = on ? 11 : 8; g.fillStyle = cl; g.beginPath(); g.moveTo(ex, ey); g.lineTo(ex - hs * Math.cos(a2 - .42), ey - hs * Math.sin(a2 - .42)); g.lineTo(ex - hs * Math.cos(a2 + .42), ey - hs * Math.sin(a2 + .42)); g.fill();
        const nd = on ? 4 : 2; for (let k = 0; k < nd; k++) { const u = (t * 0.22 + k / nd) % 1, qx2 = (1 - u) * (1 - u) * sx + 2 * u * (1 - u) * qx + u * u * ex, qy2 = (1 - u) * (1 - u) * sy + 2 * u * (1 - u) * qy + u * u * ey; ball(g, qx2, qy2, on ? 4 : 2.6, cl, '#fff'); }
        g.globalAlpha = 1; if (wd || on) labels.push([nm, 0.25 * sx + 0.5 * qx + 0.25 * ex, 0.25 * sy + 0.5 * qy + 0.25 * ey, cl, on]); });
      Object.keys(NN).forEach(k => { const [x, y] = pos(k), on = NP.some(p => p[0] === sel && (p[2] === k || p[3] === k)); g.fillStyle = col.sf; g.strokeStyle = on ? col.acc : col.fg; g.lineWidth = on ? 2.4 : 1.2; g.beginPath(); g.roundRect ? g.roundRect(x - bw / 2, y - bh / 2, bw, bh, 10) : g.rect(x - bw / 2, y - bh / 2, bw, bh); g.fill(); g.stroke(); g.fillStyle = col.fg; g.font = `bold ${wd ? 11 : 10}px ${col.font}`; g.textAlign = 'center'; g.fillText(NN[k][wd ? 0 : 1], x, y + 4); });
      labels.forEach(([nm, x, y, cl, on]) => { g.font = `${on ? 'bold ' : ''}${wd ? 10 : 10}px ${col.font}`; const tw = g.measureText(nm).width + 10; g.globalAlpha = on ? 1 : 0.85; g.fillStyle = col.sf; g.strokeStyle = cl; g.lineWidth = on ? 1.6 : 0.8; g.beginPath(); g.roundRect ? g.roundRect(x - tw / 2, y - 9, tw, 18, 8) : g.rect(x - tw / 2, y - 9, tw, 18); g.fill(); g.stroke(); g.fillStyle = col.fg; g.textAlign = 'center'; g.fillText(nm, x, y + 4); g.globalAlpha = 1; });
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('মাটি', 6, H - 6);
    };
    const info = () => { const p = NP.find(x => x[0] === sel); el.querySelectorAll('[data-np]').forEach(b => b.classList.toggle('primary', b.dataset.np === sel)); out.innerHTML = `<div><b>${p[1]}</b>: ${NN[p[2]][0]} → ${NN[p[3]][0]}</div><div class="small" style="margin-top:4px">${p[5]}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    el.querySelectorAll('[data-np]').forEach(b => { b.onclick = () => { sel = b.dataset.np; info(); A.draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
