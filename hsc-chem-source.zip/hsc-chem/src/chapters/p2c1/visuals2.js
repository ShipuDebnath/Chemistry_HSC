/* ২য় পত্র অধ্যায় ১ visuals part 2 — gas laws (1.3–1.3.5) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide;
const R = 0.0821;

/* ---------- shared: gas particles in a box ---------- */
const GCOL = { N2: ['#2d6fd6', '#a9c8ff'], O2: ['#c0392b', '#ffb3a8'], Ar: ['#7b3fa0', '#d9b8f0'], H2: ['#8a8f98', '#ffffff'], He: ['#d69a1e', '#ffe2a0'], CO2: ['#3a3a3a', '#9a9a9a'], NH3: ['#2d6fd6', '#cfe0ff'], HCl: ['#2f9e44', '#b8f0c4'], HBr: ['#9c4a12', '#f0b890'], Cl2: ['#5aa02c', '#d4f5a0'], SO2: ['#c9a400', '#fff09a'], H2O: ['#3b8fd0', '#cfeaff'], X: ['#1f8a7a', '#a8efe2'] };
const mkGas = (n, seed, kinds) => { const r = X.rng(seed), a = []; for (let i = 0; i < n; i++) { const th = r() * 6.283, s = 0.6 + r() * 0.8; a.push({ x: r(), y: r(), vx: Math.cos(th) * s, vy: Math.sin(th) * s, k: kinds ? kinds[i % kinds.length] : 'N2', hit: 0 }); } return a; };
/* move particles in unit box with top at `top` (0..1 fraction of free space); returns wall hits */
const stepGas = (a, dt, sp, top, nUse) => { let hits = 0; const N = nUse == null ? a.length : nUse; for (let i = 0; i < N; i++) { const p = a[i]; p.x += p.vx * dt * sp; p.y += p.vy * dt * sp; if (p.x < 0.02) { p.x = 0.02; p.vx = Math.abs(p.vx); hits++; p.hit = 0.25; } if (p.x > 0.98) { p.x = 0.98; p.vx = -Math.abs(p.vx); hits++; p.hit = 0.25; } if (p.y < top) { p.y = top; p.vy = Math.abs(p.vy); hits++; p.hit = 0.25; } if (p.y > 0.98) { p.y = 0.98; p.vy = -Math.abs(p.vy); hits++; p.hit = 0.25; } if (p.hit > 0) p.hit -= dt; } return hits; };
/* draw a glass cylinder with piston; frac = gas column fraction (0..1) of inner height; returns inner rect of gas */
const cylinder = (g, col, x, y, w, h, frac, o = {}) => {
  const top = y + h * (1 - frac);
  g.fillStyle = o.fill || 'rgba(150,200,240,.13)'; g.fillRect(x, top, w, y + h - top);
  // glass walls
  g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(x, y - 6); g.lineTo(x, y + h); g.lineTo(x + w, y + h); g.lineTo(x + w, y - 6); g.stroke();
  g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 3; g.beginPath(); g.moveTo(x + 5, y + 4); g.lineTo(x + 5, y + h - 6); g.stroke();
  // graduations
  g.strokeStyle = col.mu; g.lineWidth = 0.8; g.fillStyle = col.mu; g.font = `8.5px ${col.font}`; g.textAlign = 'left';
  for (let k = 0; k <= 10; k++) { const yy = y + h - k * h / 10; g.beginPath(); g.moveTo(x + w, yy); g.lineTo(x + w + (k % 5 ? 4 : 8), yy); g.stroke(); if (o.scale && k % 5 === 0) g.fillText(o.scale(k / 10), x + w + 10, yy + 3); }
  // piston
  const pg = g.createLinearGradient(x, 0, x + w, 0); pg.addColorStop(0, '#6d737c'); pg.addColorStop(0.5, '#b9c0c9'); pg.addColorStop(1, '#5d636b');
  g.fillStyle = pg; g.fillRect(x + 2, top - 12, w - 4, 12); g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 0.8; g.strokeRect(x + 2, top - 12, w - 4, 12);
  if (!o.noRod) { g.fillStyle = '#8a9099'; g.fillRect(x + w / 2 - 4, Math.min(y - 30, top - 40), 8, Math.max(0, top - 12 - Math.min(y - 30, top - 40))); }
  if (o.clamp) { g.fillStyle = '#c0392b'; g.fillRect(x - 10, top - 14, 10, 16); g.fillRect(x + w, top - 14, 10, 16); }
  // weights
  if (o.weights) { const nw = o.weights; for (let k = 0; k < nw; k++) { const ww = Math.min(w * 0.7, 46), bx = x + w / 2 - ww / 2, by = top - 12 - (k + 1) * 9 - (o.noRod ? 0 : 0); g.fillStyle = k % 2 ? '#4e555e' : '#3d434a'; g.fillRect(bx, by, ww, 8); g.strokeStyle = 'rgba(255,255,255,.25)'; g.strokeRect(bx, by, ww, 8); } }
  return { x: x + 3, y: top, w: w - 6, h: y + h - top - 2 };
};
const drawGas = (g, a, box, rad, N) => { const n = N == null ? a.length : N; for (let i = 0; i < n; i++) { const p = a[i], c = GCOL[p.k] || GCOL.N2; ball(g, box.x + p.x * box.w, box.y + p.y * box.h, rad * (p.k === 'H2' || p.k === 'He' ? 0.8 : p.k === 'CO2' || p.k === 'HBr' || p.k === 'Cl2' || p.k === 'SO2' ? 1.2 : 1), c[0], c[1]); } };
const thermo = (g, col, x, y, h, frac, label) => {
  g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.roundRect ? g.roundRect(x - 5, y, 10, h, 5) : g.rect(x - 5, y, 10, h); g.fill(); g.stroke();
  g.beginPath(); g.arc(x, y + h + 6, 9, 0, 7); g.fillStyle = '#d63a2a'; g.fill(); g.stroke();
  const f = Math.max(0, Math.min(1, frac)); g.fillStyle = '#d63a2a'; g.fillRect(x - 2.5, y + h * (1 - f), 5, h * f + 2);
  if (label) { g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(label, x, y - 6); }
};
const flame = (g, x, y, s, t) => { for (let k = 0; k < 3; k++) { const fx_ = x + (k - 1) * s * 0.9, hh = s * (1.3 + 0.25 * Math.sin(t * 9 + k * 2)); const gr = g.createRadialGradient(fx_, y - hh * 0.3, 1, fx_, y - hh * 0.3, hh); gr.addColorStop(0, 'rgba(255,240,150,.95)'); gr.addColorStop(0.5, 'rgba(255,140,30,.8)'); gr.addColorStop(1, 'rgba(255,60,0,0)'); g.fillStyle = gr; g.beginPath(); g.ellipse(fx_, y - hh * 0.45, s * 0.45, hh * 0.6, 0, 0, 7); g.fill(); } };
const ice = (g, x, y, s) => { g.fillStyle = 'rgba(170,215,255,.85)'; g.strokeStyle = 'rgba(80,140,200,.9)'; g.lineWidth = 1; for (let k = 0; k < 4; k++) { const ix = x + (k - 1.5) * s * 1.1, iy = y - s * 0.6 - (k % 2) * 3; g.beginPath(); g.rect(ix - s / 2, iy, s, s * 0.8); g.fill(); g.stroke(); } };
const tag = (g, col, x, y, txt, on, colr) => { g.font = `bold 10.5px ${col.font}`; const w = g.measureText(txt).width + 14; g.fillStyle = on ? (colr || col.acc) : col.s3; g.beginPath(); g.roundRect ? g.roundRect(x, y, w, 20, 10) : g.rect(x, y, w, 20); g.fill(); g.fillStyle = on ? '#fff' : col.fg; g.textAlign = 'left'; g.fillText(txt, x + 7, y + 14); return w; };
/* 3D surface (painter's algorithm) for P-V-T */
const surf3d = (g, W, H, view, fz, nx, ny, colorOf, oy) => {
  const { yaw, pitch } = view, S = Math.min(W * 0.48, H * 0.6), cx = W / 2, cy = H / 2 + (oy || 18);
  const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const P = (x, y, z) => { const x1 = x * cyw - y * syw, y1 = x * syw + y * cyw; const yy = y1 * cp + z * sp, zz = -y1 * sp + z * cp; return [cx + x1 * S, cy - zz * S, yy]; };
  const q = [];
  for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) {
    const u0 = i / nx, u1 = (i + 1) / nx, v0 = j / ny, v1 = (j + 1) / ny;
    const c = [[u0, v0], [u1, v0], [u1, v1], [u0, v1]].map(([u, v]) => P(u - 0.5, v - 0.5, Math.min(1, fz(u, v)) * 0.8 - 0.4));
    q.push({ c, d: c.reduce((s, p) => s + p[2], 0) / 4, val: fz((u0 + u1) / 2, (v0 + v1) / 2) });
  }
  const fl = [[-0.5, -0.5], [0.5, -0.5], [0.5, 0.5], [-0.5, 0.5]].map(([x, y]) => P(x, y, -0.4));
  g.fillStyle = 'rgba(128,128,128,.08)'; g.strokeStyle = 'rgba(128,128,128,.6)'; g.lineWidth = 1; g.beginPath(); fl.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.fill(); g.stroke();
  g.strokeStyle = 'rgba(128,128,128,.3)'; for (let k = 1; k < 5; k++) { const a = P(-0.5 + k / 5, -0.5, -0.4), b = P(-0.5 + k / 5, 0.5, -0.4), c2 = P(-0.5, -0.5 + k / 5, -0.4), d = P(0.5, -0.5 + k / 5, -0.4); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.moveTo(c2[0], c2[1]); g.lineTo(d[0], d[1]); g.stroke(); }
  [[-0.5, 0.5], [0.5, 0.5], [-0.5, -0.5]].forEach(([x, y]) => { const a = P(x, y, -0.4), b = P(x, y, 0.4); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); });
  q.sort((a, b) => b.d - a.d).forEach(f => { g.fillStyle = colorOf(f.val); g.strokeStyle = 'rgba(0,0,0,.16)'; g.lineWidth = 0.5; g.beginPath(); f.c.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.fill(); g.stroke(); });
  return (u, v, z) => P(u - 0.5, v - 0.5, z * 0.8 - 0.4);
};
const legend = (g, col, x, y, items, right) => { g.font = `bold 9.5px ${col.font}`; const w = Math.max(...items.map(i => g.measureText(i[1]).width)) + 30, h = items.length * 15 + 8; const x0 = right ? x - w : x; g.fillStyle = col.sf; g.globalAlpha = 0.92; g.fillRect(x0, y, w, h); g.globalAlpha = 1; g.strokeStyle = col.line || col.mu; g.lineWidth = 0.8; g.strokeRect(x0, y, w, h); items.forEach(([c, t, d], i) => { g.strokeStyle = c; g.lineWidth = 2.4; g.setLineDash(d || []); g.beginPath(); g.moveTo(x0 + 6, y + 12 + i * 15); g.lineTo(x0 + 20, y + 12 + i * 15); g.stroke(); g.setLineDash([]); g.fillStyle = col.fg; g.textAlign = 'left'; g.fillText(t, x0 + 24, y + 15.5 + i * 15); }); };
const heat = v => { const t = Math.max(0, Math.min(1, v)); const st = [[48, 18, 120], [40, 90, 170], [30, 160, 150], [120, 205, 90], [250, 215, 50], [235, 90, 40]]; const k = Math.min(4, Math.floor(t * 5)), f = t * 5 - k; return `rgb(${st[k].map((c, i) => Math.round(c + (st[k + 1][i] - c) * f)).join(',')})`; };
Object.assign(P2, { legend, GCOL, mkGas, stepGas, cylinder, drawGas, thermo, flame, ice, tag, surf3d, heat });

/* ======================= ১.৩ গ্যাস সূত্রের হাব ======================= */
const LAWS = { b: ['বয়েল', 'P', ['T', 'n'], 'V ∝ 1/P'], c: ['চার্লস', 'T', ['P', 'n'], 'V ∝ T'], g: ['গে-লুসাক', 'T', ['V', 'n'], 'P ∝ T'], a: ['অ্যাভোগাড্রো', 'n', ['P', 'T'], 'V ∝ n'] };
V.p2c1_gasHub = {
  t: 'চার গ্যাস সূত্র এক যন্ত্রে: পিস্টন-সিলিন্ডারে P, V, T ও n এর সম্পর্ক', k: ['anim', 'int', '2d', 'calc'],
  cap: 'উপরের বোতামে সূত্র বেছে নাও — যে দুটি রাশি স্থির থাকে তা "স্থির" ট্যাগে চিহ্নিত। বয়েলে পিস্টনের ওপর ওজন (চাপ) বাড়াও; চার্লসে মুক্ত পিস্টনের নিচে আগুন/বরফ দিয়ে তাপমাত্রা বদলাও; গে-লুসাকে লাল ক্ল্যাম্পে পিস্টন আটকানো, তাই তাপমাত্রা বাড়লে চাপ বাড়ে; অ্যাভোগাড্রোতে গ্যাসের অণু যোগ করো। অণুর বেগ √T এর সমানুপাতিক, দেয়ালে ধাক্কা লাগলে অণু ঝলসে ওঠে। ডানের লেখচিত্রে সম্পর্কটি ও বর্তমান অবস্থা (লাল বিন্দু)।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('law', Object.keys(LAWS).map(k => [k, LAWS[k][0]]), 'b')}</div>${X.cv('গ্যাস সূত্রের পিস্টন-সিলিন্ডার')}<label class="small" style="display:block;margin-top:6px"><span data-lab></span> <input type="range" min="0" max="100" value="33" data-s></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 620;
    let L = X.fit(c, hf), law = 'b', s = 33, t = 0, flash = 0;
    const G = mkGas(36, 7);
    const st = () => { // returns P,V,T,n
      const u = s / 100; let P = 1, T = 300, n = 1;
      if (law === 'b') P = 0.5 + u * 2.5; if (law === 'c' || law === 'g') T = 150 + u * 450; if (law === 'a') n = 0.5 + u * 2.5;
      let Vv = n * R * T / P; if (law === 'g') { Vv = R * 300; P = n * R * T / Vv; }
      return { P, V: Vv, T, n };
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const S = st(), Lw = LAWS[law];
      const wd = wide(W), cx = wd ? 60 : W / 2 - 70, cw = 120, cy = wd ? 70 : 90, ch = wd ? 200 : 210;
      const frac = Math.min(1, S.V / 75);
      const box = cylinder(g, col, cx, cy, cw, ch, frac, { weights: law === 'b' ? Math.round(S.P * 2) : law === 'g' ? 0 : 2, clamp: law === 'g', scale: f => bn(Math.round(f * 75)) + ' L' });
      drawGas(g, G, box, 4.6, Math.round(12 * S.n));
      // heat source
      if (S.T > 320) flame(g, cx + cw / 2, cy + ch + 30, 10 + (S.T - 320) / 30, t); else if (S.T < 280) ice(g, cx + cw / 2, cy + ch + 28, 12);
      g.fillStyle = '#555'; g.fillRect(cx - 8, cy + ch + 2, cw + 16, 5);
      thermo(g, col, cx - 34, cy + 20, ch - 40, (S.T - 100) / 520, 'T');
      // pressure gauge
      const gx = cx + cw + 52, gy = cy + 20, gr = 22; g.strokeStyle = col.fg; g.lineWidth = 1.5; g.fillStyle = col.sf; g.beginPath(); g.arc(gx, gy, gr, 0, 7); g.fill(); g.stroke();
      for (let k = 0; k <= 8; k++) { const a = Math.PI * (0.75 + k * 1.5 / 8); g.beginPath(); g.moveTo(gx + Math.cos(a) * gr * 0.78, gy + Math.sin(a) * gr * 0.78); g.lineTo(gx + Math.cos(a) * gr * 0.95, gy + Math.sin(a) * gr * 0.95); g.stroke(); }
      const pa = Math.PI * (0.75 + Math.min(1, S.P / 4) * 1.5); g.strokeStyle = '#c0392b'; g.lineWidth = 2; g.beginPath(); g.moveTo(gx, gy); g.lineTo(gx + Math.cos(pa) * gr * 0.85, gy + Math.sin(pa) * gr * 0.85); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('P', gx, gy + gr + 12);
      // tags
      const ty = wd ? 14 : 14; let tx0 = wd ? 10 : 10;
      ['P', 'V', 'T', 'n'].forEach(k => { const v = { P: fx(S.P, 2) + ' atm', V: fx(S.V, 1) + ' L', T: bn(Math.round(S.T)) + ' K', n: fx(S.n, 2) + ' mol' }[k]; const fixed = Lw[2].includes(k), indep = Lw[1] === k; tx0 += tag(g, col, tx0, (!wd && (k === 'T' || k === 'n')) ? ty + 24 : ty, `${k} = ${v}${fixed ? ' · স্থির' : ''}`, !fixed, indep ? '#c0392b' : '#2d6fd6') + 6; if (!wd && k === 'V') { tx0 = 10; } });
      // graph
      const gx0 = wd ? W * 0.52 : 56, gy0 = wd ? 60 : cy + ch + 80, gw = wd ? W - gx0 - 26 : W - 80, gh = wd ? H - 110 : H - gy0 - 50;
      let xs, ys, xmax, ymax, xl, yl, cur;
      if (law === 'b') { xmax = 3; ymax = 50; xl = 'P (atm)'; yl = 'V (L)'; xs = v => 24.63 / v; cur = [S.P, S.V]; }
      else if (law === 'c') { xmax = 600; ymax = 50; xl = 'T (K)'; yl = 'V (L)'; xs = v => R * v; cur = [S.T, S.V]; }
      else if (law === 'g') { xmax = 600; ymax = 2.2; xl = 'T (K)'; yl = 'P (atm)'; xs = v => v / 300; cur = [S.T, S.P]; }
      else { xmax = 3; ymax = 80; xl = 'n (mol)'; yl = 'V (L)'; xs = v => 24.63 * v; cur = [S.n, S.V]; }
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax, ymax, col, xt: law === 'b' || law === 'a' ? [0, 1, 2, 3] : [0, 200, 400, 600], yt: law === 'g' ? [0, 1, 2] : law === 'a' ? [0, 20, 40, 60, 80] : [0, 10, 20, 30, 40, 50], xl, yl, fy: v => bn(v) });
      const pts = []; const x0v = law === 'b' ? 0.5 : 0; for (let k = 0; k <= 100; k++) { const v = x0v + (xmax - x0v) * k / 100; const yv = xs(v); if (yv <= ymax * 1.05) pts.push([Pl.X(v), Pl.Y(Math.min(yv, ymax * 1.05))]); }
      path(g, pts, '#2d6fd6', 2.6);
      if (law === 'c' || law === 'g') { g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('মূলবিন্দুগামী: ০ K এ শূন্য', Pl.X(20), Pl.Y(ymax * 0.92)); }
      g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(Pl.X(cur[0]), Pl.Y(0)); g.lineTo(Pl.X(cur[0]), Pl.Y(cur[1])); g.lineTo(Pl.X(0), Pl.Y(cur[1])); g.stroke(); g.setLineDash([]);
      ball(g, Pl.X(cur[0]), Pl.Y(cur[1]), 6, '#c0392b', '#ffb3a8');
      g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(`${Lw[0]}: ${Lw[3]}`, gx0 + gw / 2, gy0 - 14);
      if (flash > 0) { g.fillStyle = `rgba(192,57,43,${flash})`; g.fillRect(box.x, box.y - 2, box.w, 3); }
    };
    const info = () => {
      const S = st(), Lw = LAWS[law];
      q('[data-lab]').innerHTML = { b: 'চাপ P (ওজন যোগ/কমাও)', c: 'তাপমাত্রা T (মুক্ত পিস্টন)', g: 'তাপমাত্রা T (পিস্টন আটকানো)', a: 'মোল সংখ্যা n (অণু যোগ করো)' }[law];
      const eq = { b: `PV = ${S.P.toFixed(2)}\\times${S.V.toFixed(1)} = ${(S.P * S.V).toFixed(1)}\\ \\mathrm{L\\,atm}`, c: `\\dfrac{V}{T} = \\dfrac{${S.V.toFixed(1)}}{${S.T.toFixed(0)}} = ${(S.V / S.T).toFixed(4)}\\ \\mathrm{L\\,K^{-1}}`, g: `\\dfrac{P}{T} = \\dfrac{${S.P.toFixed(2)}}{${S.T.toFixed(0)}} = ${(S.P / S.T).toFixed(5)}\\ \\mathrm{atm\\,K^{-1}}`, a: `\\dfrac{V}{n} = \\dfrac{${S.V.toFixed(1)}}{${S.n.toFixed(2)}} = ${(S.V / S.n).toFixed(2)}\\ \\mathrm{L\\,mol^{-1}}`}[law] + `\\quad(= ${{ b: 'nRT', c: 'nR/P', g: 'nR/V', a: 'RT/P' }[law]},\\ \\text{ধ্রুবক})`;
      out.innerHTML = TXB(eq) + `<div class="small">${{ b: 'চাপ বাড়ালে একই অণুগুলো কম জায়গায় চাপা পড়ে — দেয়ালে প্রতি সেকেন্ডে বেশি ধাক্কা লাগে, তাই নতুন সাম্যে চাপ ও আয়তনের গুণফল একই থাকে।', c: 'তাপমাত্রা বাড়লে অণুর বেগ বাড়ে, পিস্টনে জোরে ধাক্কা লাগে; ওজন (চাপ) একই থাকায় পিস্টন উপরে উঠে আয়তন বাড়ায় যতক্ষণ না চাপ আবার সমান হয়।', g: 'পিস্টন আটকানো — আয়তন বদলাতে পারে না; দ্রুততর অণুগুলো দেয়ালে আরও জোরে ও ঘন ঘন ধাক্কা দেয়, তাই চাপ পরম তাপমাত্রার সাথে সমানুপাতে বাড়ে।', a: 'বেশি অণু মানে বেশি ধাক্কা; চাপ ও তাপমাত্রা স্থির রাখতে আয়তন অণুর সংখ্যার সমানুপাতে বাড়ে — গ্যাসের প্রকৃতি যা-ই হোক।' }[law]}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; const S = st(); const h = stepGas(G, dt, 0.5 * Math.sqrt(S.T / 300) / Math.max(0.35, Math.min(1, S.V / 75)) * 0.6, 0.02, Math.round(12 * S.n)); if (h > 2) flash = 0.5; flash = Math.max(0, flash - dt * 2); } draw(); }, { paused: false });
    X.onSeg(el, 'law', k => { law = k; s = 33; q('[data-s]').value = 33; info(); A.draw(); });
    q('[data-s]').oninput = e => { s = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৩.১ একক রূপান্তর ======================= */
const PU = [['atm', 1], ['Pa', 101325], ['kPa', 101.325], ['hPa', 1013.25], ['bar', 1.01325], ['mmHg', 760], ['torr', 760], ['cmHg', 76], ['psi', 14.696]];
V.p2c1_units = {
  t: 'চাপ ও তাপমাত্রার একক: পারদ ব্যারোমিটার ও তিন স্কেলের থার্মোমিটার', k: ['int', '2d', 'calc'],
  cap: 'বামে টরিসেলির পারদ ব্যারোমিটার: বায়ুমণ্ডলের চাপ পাত্রের পারদকে ঠেলে নলের পারদ স্তম্ভ ধরে রাখে; স্তম্ভের উচ্চতা h = P/ρg। চাপের স্লাইডার বদলালে স্তম্ভ ওঠানামা করে এবং সব এককে মান দেখায় (১ atm = ৭৬ cm Hg)। ডানে একই তাপমাত্রা তিনটি পাশাপাশি থার্মোমিটারে — সেলসিয়াস, কেলভিন ও ফারেনহাইট; পরম শূন্য, বরফ গলন, দেহের তাপমাত্রা ও পানির স্ফুটনাঙ্ক চিহ্নিত।',
  html: () => `${X.cv('ব্যারোমিটার ও থার্মোমিটার')}<div class="ctl"><label class="small" style="flex:1;min-width:150px">চাপ = <b data-pv></b> hPa <input type="range" min="300" max="1100" step="1" value="1013" data-p></label><label class="small" style="flex:1;min-width:150px">তাপমাত্রা = <b data-tv></b> °C <input type="range" min="-273.15" max="150" step="0.05" value="25" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 640;
    let L = X.fit(c, hf), hPa = 1013, tc = 25;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      // barometer
      const bx = wd ? 70 : W / 2 - 40, top = 30, bh = 250, base = top + bh; const cmH = hPa / 1013.25 * 76, maxcm = 90;
      const Yc = cm => base - cm / maxcm * (bh - 30);
      // dish
      g.fillStyle = 'rgba(170,175,185,.9)'; g.beginPath(); g.ellipse(bx + 10, base + 4, 60, 12, 0, 0, 7); g.fill();
      g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(bx - 50, base - 14); g.lineTo(bx - 50, base + 6); g.ellipse(bx + 10, base + 6, 60, 12, 0, Math.PI, 0, true); g.lineTo(bx + 70, base - 14); g.stroke();
      // tube
      g.fillStyle = 'rgba(200,225,250,.18)'; g.fillRect(bx, top, 20, bh + 4); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(bx, base + 6); g.lineTo(bx, top + 8); g.arc(bx + 10, top + 8, 10, Math.PI, 0); g.lineTo(bx + 20, base + 6); g.stroke();
      const hg = g.createLinearGradient(bx, 0, bx + 20, 0); hg.addColorStop(0, '#8c939c'); hg.addColorStop(0.45, '#e4e8ee'); hg.addColorStop(1, '#7c838c'); g.fillStyle = hg; g.fillRect(bx + 1.5, Yc(cmH), 17, base + 4 - Yc(cmH));
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('শূন্যস্থান', bx + 10, Math.max(top + 24, Yc(cmH) - 8));
      // scale
      g.strokeStyle = col.fg; g.lineWidth = 1; g.font = `9px ${col.font}`; g.textAlign = 'right';
      for (let cm = 0; cm <= maxcm; cm += 10) { const y = Yc(cm); g.beginPath(); g.moveTo(bx - 4, y); g.lineTo(bx - 12, y); g.stroke(); g.fillStyle = col.mu; g.fillText(bn(cm), bx - 14, y + 3); }
      g.strokeStyle = '#c0392b'; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(bx - 12, Yc(76)); g.lineTo(bx + 34, Yc(76)); g.stroke(); g.setLineDash([]); g.fillStyle = '#c0392b'; g.textAlign = 'left'; g.fillText('৭৬ cm', bx + 26, Yc(76) - 3);
      // h arrow
      g.strokeStyle = col.acc; g.lineWidth = 1.4; g.beginPath(); g.moveTo(bx + 32, base - 10); g.lineTo(bx + 32, Yc(cmH)); g.stroke(); g.fillStyle = col.acc; g.font = `bold 10px ${col.font}`; g.fillText(`h = ${fx(cmH, 1)} cm`, bx + 36, (base + Yc(cmH)) / 2);
      // air arrows
      g.strokeStyle = '#2d6fd6'; g.fillStyle = '#2d6fd6'; g.lineWidth = 1.6; [bx - 36, bx + 56].forEach(ax => { g.beginPath(); g.moveTo(ax, base - 50); g.lineTo(ax, base - 18); g.stroke(); g.beginPath(); g.moveTo(ax - 4, base - 24); g.lineTo(ax, base - 16); g.lineTo(ax + 4, base - 24); g.fill(); });
      g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('বায়ুচাপ', bx - 36, base - 56);
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.fillText('পারদ ব্যারোমিটার', bx + 10, base + 34);
      // thermometers
      const tx0 = wd ? W * 0.45 : 40, ty = wd ? 40 : base + 80, th = wd ? 230 : 230, tw = wd ? W - tx0 - 20 : W - 60;
      const Ym = k => ty + th - (k / 450) * th; // K scale 0..450
      const scales = [['°C', k => k - 273.15, [-273, -200, -100, 0, 100, 150]], ['K', k => k, [0, 100, 200, 273, 373, 450]], ['°F', k => (k - 273.15) * 1.8 + 32, [-459, -300, -100, 32, 212, 300]]];
      const tk = tc + 273.15;
      scales.forEach(([u, cv, ticks], i) => {
        const x = tx0 + 40 + i * (tw - 60) / 2.4;
        g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.rect(x - 6, ty - 4, 12, th + 8); g.fill(); g.stroke(); g.beginPath(); g.arc(x, ty + th + 12, 10, 0, 7); g.fillStyle = '#d63a2a'; g.fill(); g.stroke();
        g.fillStyle = '#d63a2a'; g.fillRect(x - 3, Ym(tk), 6, ty + th + 4 - Ym(tk));
        g.font = `8.5px ${col.font}`; g.textAlign = 'left'; g.fillStyle = col.mu; g.strokeStyle = col.mu; g.lineWidth = 0.8;
        ticks.forEach(v => { let kk; if (u === '°C') kk = v + 273.15; else if (u === 'K') kk = v; else kk = (v - 32) / 1.8 + 273.15; const y = Ym(kk); g.beginPath(); g.moveTo(x + 6, y); g.lineTo(x + 11, y); g.stroke(); g.fillText(bn(v), x + 13, y + 3); });
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(u, x, ty - 12);
        g.fillStyle = '#c0392b'; g.font = `bold 10px ${col.font}`; g.fillText(fx(cv(tk), u === 'K' ? 2 : 1), x, ty + th + 40);
      });
      [[0, 'পরম শূন্য'], [273.15, 'বরফ গলে'], [310.15, 'দেহ'], [373.15, 'পানি ফোটে']].forEach(([k, nm]) => { const y = Ym(k); g.strokeStyle = 'rgba(128,128,128,.45)'; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(tx0 + 30, y); g.lineTo(tx0 + tw - 10, y); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText(nm, tx0 + tw - 4, y - 3); });
    };
    const info = () => {
      const atm = hPa / 1013.25; q('[data-pv]').textContent = bn(hPa); q('[data-tv]').textContent = fx(tc, 1);
      out.innerHTML = `<div class="table-wrap"><table class="t"><tbody><tr>${PU.map(([u]) => `<th>${u}</th>`).join('')}</tr><tr>${PU.map(([u, k]) => `<td>${fx(atm * k, k > 1000 ? 0 : k > 50 ? 1 : 3)}</td>`).join('')}</tr></tbody></table></div>` +
        TXB(`P = h\\rho g = ${(atm * 0.76).toFixed(3)}\\ \\mathrm{m}\\times13595\\ \\mathrm{kg\\,m^{-3}}\\times9.807\\ \\mathrm{m\\,s^{-2}} = ${Math.round(atm * 101325)}\\ \\mathrm{Pa}`) +
        TXB(`T = ${tc.toFixed(1)} + 273.15 = ${(tc + 273.15).toFixed(2)}\\ \\mathrm{K};\\quad t_F = \\tfrac{9}{5}(${tc.toFixed(1)}) + 32 = ${(tc * 1.8 + 32).toFixed(1)}\\,^\\circ\\mathrm{F}`) +
        `<div class="small">${hPa < 700 ? 'এত কম চাপ পাওয়া যায় উঁচু পর্বতে (৩–৯ km)।' : hPa > 1030 ? 'উচ্চচাপ বলয় — পরিষ্কার শুষ্ক আবহাওয়া।' : hPa < 990 ? 'নিম্নচাপ — ঝড়-বৃষ্টির সম্ভাবনা (১.২)।' : 'সমুদ্রপৃষ্ঠের স্বাভাবিক চাপের কাছাকাছি।'}</div>`;
    };
    q('[data-p]').oninput = e => { hPa = +e.target.value; info(); draw(); };
    q('[data-t]').oninput = e => { tc = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ১.৩.২ বয়েলের সূত্র ======================= */
V.p2c1_boyle = {
  t: 'বয়েলের সূত্র: J-নল পরীক্ষা, সমোষ্ণ রেখা এবং P–V, P–1/V ও PV–P লেখচিত্র', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে বয়েলের J-নল: খোলা বাহুতে পারদ ঢাললে (স্লাইডার) পারদ স্তম্ভের পার্থক্য h বাড়ে, আটকানো বায়ুর চাপ P = ৭৬ + h cmHg হয় এবং বায়ু স্তম্ভ ছোট হয়; ভেতরের অণুগুলো ঘন হয়ে দেয়ালে বেশি ধাক্কা দেয়। "পাঠ নাও" চাপলে সারণিতে একটি পাঠ যোগ হয় — PV প্রায় ধ্রুবক। ডানে তিন তাপমাত্রার সমোষ্ণ রেখা; বোতামে লেখচিত্রের ধরন বদলাও: P–V সমপরাবৃত্ত, P–1/V মূলবিন্দুগামী সরলরেখা, PV–P অনুভূমিক রেখা।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('gt', [['pv', 'P – V'], ['pinv', 'P – 1/V'], ['pvp', 'PV – P']], 'pv')}</div>${X.cv('বয়েলের J-নল ও লেখচিত্র')}<div class="ctl"><label class="small" style="flex:1;min-width:150px">পারদের পার্থক্য h = <b data-hv></b> cm <input type="range" min="-30" max="90" step="1" value="0" data-h></label><button class="btn sm" data-rec>পাঠ নাও</button><button class="btn sm" data-clr>মুছো</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 660;
    let L = X.fit(c, hf), h = 0, gt = 'pv', t = 0; const rec = [];
    const G = mkGas(22, 11);
    const L0 = 30; // air column length cm at 76 cmHg
    const st = () => { const P = 76 + h, len = L0 * 76 / P; return { P, len }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), S = st();
      // J tube
      const jx = wd ? 40 : W / 2 - 80, jb = wd ? H - 66 : 300, sc = wd ? 1.3 : 1.3; // px per cm
      const closedTop = jb - 70 * sc, openTop = jb - 230 * sc * 0.95;
      const lw = 18, gap = 70;
      // mercury levels: closed arm mercury top at closedTop + len
      const yAirBot = closedTop + S.len * sc, yOpenHg = yAirBot - h * sc;
      g.lineWidth = 1.6; g.strokeStyle = col.fg;
      // closed arm
      g.fillStyle = 'rgba(200,225,250,.15)'; g.fillRect(jx, closedTop, lw, jb - closedTop); g.fillRect(jx + lw + gap, Math.max(20, openTop), lw, jb - Math.max(20, openTop));
      // air
      g.fillStyle = 'rgba(150,200,240,.25)'; g.fillRect(jx, closedTop, lw, yAirBot - closedTop);
      const box = { x: jx + 2, y: closedTop + 2, w: lw - 4, h: yAirBot - closedTop - 4 }; drawGas(g, G, box, 2.6);
      // mercury
      const hg = g.createLinearGradient(0, 0, lw, 0); hg.addColorStop(0, '#8c939c'); hg.addColorStop(0.5, '#e4e8ee'); hg.addColorStop(1, '#7c838c');
      g.save(); g.translate(jx, 0); g.fillStyle = hg; g.fillRect(0, yAirBot, lw, jb - yAirBot); g.restore();
      g.save(); g.translate(jx + lw + gap, 0); g.fillStyle = hg; g.fillRect(0, yOpenHg, lw, jb - yOpenHg); g.restore();
      g.fillStyle = '#b8bec6'; g.beginPath(); g.moveTo(jx, jb); g.arc(jx + lw + gap / 2 + lw / 2 - lw / 2 + 0, jb, (gap + 2 * lw) / 2, Math.PI, 0, true); g.lineTo(jx + 2 * lw + gap - lw, jb); g.arc(jx + lw + gap / 2, jb, gap / 2, 0, Math.PI, false); g.closePath(); g.fill();
      // outlines
      g.strokeStyle = col.fg; g.beginPath(); g.moveTo(jx, jb); g.lineTo(jx, closedTop); g.lineTo(jx + lw, closedTop); g.lineTo(jx + lw, jb); g.stroke();
      g.beginPath(); g.moveTo(jx + lw + gap, jb); g.lineTo(jx + lw + gap, Math.max(20, openTop)); g.moveTo(jx + 2 * lw + gap, Math.max(20, openTop)); g.lineTo(jx + 2 * lw + gap, jb); g.stroke();
      g.beginPath(); g.arc(jx + lw + gap / 2, jb, gap / 2 + lw, Math.PI, 0, true); g.stroke(); g.beginPath(); g.arc(jx + lw + gap / 2, jb, gap / 2, Math.PI, 0, true); g.stroke();
      // h marker
      g.strokeStyle = '#c0392b'; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(jx, yAirBot); g.lineTo(jx + 2 * lw + gap + 30, yAirBot); g.moveTo(jx + lw + gap, yOpenHg); g.lineTo(jx + 2 * lw + gap + 30, yOpenHg); g.stroke(); g.setLineDash([]);
      g.fillStyle = '#c0392b'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`h = ${bn(h)} cm`, jx + 2 * lw + gap + 6, (yAirBot + yOpenHg) / 2 + 3);
      g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'right'; g.fillText(`বায়ু ${fx(S.len, 1)} cm`, jx - 4, (closedTop + yAirBot) / 2 + 3);
      g.textAlign = 'center'; g.fillText('বন্ধ মুখ', jx + lw / 2, closedTop - 6); g.fillText('খোলা মুখ ↓ পারদ', jx + lw * 1.5 + gap, Math.max(20, openTop) - 6);
      // graph
      const gx0 = wd ? W * 0.45 : 58, gy0 = wd ? 34 : jb + 100, gw = wd ? W - gx0 - 24 : W - 82, gh = wd ? H - 80 : H - gy0 - 48;
      const Ts = [[200, '#2d6fd6'], [300, '#2f9e44'], [400, '#d06a1e']], k300 = 76 * L0; // P*len constant at 300K (cmHg·cm)
      let Pl;
      if (gt === 'pv') { Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 80, xmin: 0, ymax: 250, col, xt: [0, 20, 40, 60, 80], yt: [0, 50, 100, 150, 200, 250], xl: 'V (বায়ু স্তম্ভ, cm)', yl: 'P (cmHg)' }); Ts.forEach(([T, cc]) => { const k = k300 * T / 300, pts = []; for (let v = 6; v <= 80; v += 0.5) { const p = k / v; if (p <= 255) pts.push([Pl.X(v), Pl.Y(p)]); } path(g, pts, cc, T === 300 ? 2.8 : 1.6); }); }
      else if (gt === 'pinv') { Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 0.1, ymax: 250, col, xt: [0, 0.025, 0.05, 0.075, 0.1], yt: [0, 50, 100, 150, 200, 250], fx: v => bn(v.toFixed(3)), xl: '1/V (cm⁻¹)', yl: 'P (cmHg)' }); Ts.forEach(([T, cc]) => { const k = k300 * T / 300; const x1 = Math.min(0.1, 250 / k); path(g, [[Pl.X(0), Pl.Y(0)], [Pl.X(x1), Pl.Y(k * x1)]], cc, T === 300 ? 2.8 : 1.6); }); }
      else { Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 250, ymax: 4000, col, xt: [0, 50, 100, 150, 200, 250], yt: [0, 1000, 2000, 3000, 4000], xl: 'P (cmHg)', yl: 'PV (cmHg·cm)', ylx: 40 }); Ts.forEach(([T, cc]) => { const k = k300 * T / 300; path(g, [[Pl.X(10), Pl.Y(k)], [Pl.X(250), Pl.Y(k)]], cc, T === 300 ? 2.8 : 1.6); }); }
      legend(g, col, gx0 + gw, gy0 + 4, Ts.map(([T, cc]) => [cc, `${bn(T)} K`]), true);
      const xy = (P, len) => gt === 'pv' ? [len, P] : gt === 'pinv' ? [1 / len, P] : [P, P * len];
      rec.forEach(([P, len]) => { const [a, b] = xy(P, len); g.fillStyle = '#fff'; g.strokeStyle = '#2f9e44'; g.lineWidth = 2; g.beginPath(); g.arc(Pl.X(a), Pl.Y(b), 4.5, 0, 7); g.fill(); g.stroke(); });
      const [a, b] = xy(S.P, S.len); ball(g, Pl.X(a), Pl.Y(b), 6.5, '#c0392b', '#ffb3a8');
      g.fillStyle = col.fg; g.font = `bold 11.5px ${col.font}`; g.textAlign = 'center'; g.fillText({ pv: 'সমোষ্ণ রেখা: সমপরাবৃত্ত', pinv: 'P ∝ 1/V: মূলবিন্দুগামী সরলরেখা', pvp: 'PV = ধ্রুবক: অনুভূমিক রেখা' }[gt], gx0 + gw / 2, gy0 - 14);
    };
    const info = () => {
      const S = st(); q('[data-hv]').textContent = bn(h);
      out.innerHTML = TXB(`P = 76 ${h >= 0 ? '+' : '-'} ${Math.abs(h)} = ${S.P}\\ \\mathrm{cmHg}`) + TXB(`V \\propto ${S.len.toFixed(2)}\\ \\mathrm{cm},\\quad PV = ${(S.P * S.len).toFixed(0)}`) +
        (rec.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>পাঠ</th><th>P (cmHg)</th><th>V (cm)</th><th>1/V</th><th>PV</th></tr></thead><tbody>${rec.map(([P, len], i) => `<tr><td>${bn(i + 1)}</td><td>${bn(P)}</td><td>${fx(len, 2)}</td><td>${fx(1 / len, 4)}</td><td>${fx(P * len, 0)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="small">বিভিন্ন h এ "পাঠ নাও" চেপে ৪–৫টি পাঠ নাও; PV এর কলাম লক্ষ্য করো।</div>');
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; stepGas(G, dt, 0.5 * Math.min(2.5, 30 / st().len), 0.02); } draw(); }, { paused: false });
    X.onSeg(el, 'gt', k => { gt = k; A.draw(); });
    q('[data-h]').oninput = e => { h = +e.target.value; info(); A.draw(); };
    q('[data-rec]').onclick = () => { const S = st(); if (rec.length < 8 && !rec.some(r => r[0] === S.P)) rec.push([S.P, S.len]); rec.sort((a, b) => a[0] - b[0]); info(); A.draw(); };
    q('[data-clr]').onclick = () => { rec.length = 0; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৩.৩ চার্লসের সূত্র ======================= */
V.p2c1_charles = {
  t: 'চার্লসের সূত্র: মুক্ত পিস্টনে গ্যাসের প্রসারণ, সমচাপ রেখা ও পরম শূন্যে বহির্বেশন', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে মুক্ত পিস্টনযুক্ত সিলিন্ডার একটি তাপ-স্নানে (চাপ স্থির — পিস্টনের ওজন বদলায় না)। তাপমাত্রা বাড়ালে অণুর বেগ বাড়ে, পিস্টন উপরে ওঠে। ডানে তিনটি চাপে (১, ২, ৪ atm) V বনাম t (°C) সমচাপ রেখা; কাটা রেখায় পেছনে বাড়ালে সবগুলো −২৭৩.১৫ °C এ শূন্য আয়তনে মিলিত হয় — পরম শূন্য। "K স্কেল" বোতামে অক্ষটি কেলভিনে দেখালে রেখাগুলো মূলবিন্দুগামী হয়ে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('ax', [['c', '°C স্কেল'], ['k', 'K স্কেল']], 'c')}</div>${X.cv('চার্লসের সূত্র')}<label class="small" style="display:block;margin-top:6px">তাপমাত্রা t = <b data-tv></b> °C <input type="range" min="-200" max="300" step="1" value="27" data-t></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 640;
    let L = X.fit(c, hf), tc = 27, ax = 'c', t = 0;
    const G = mkGas(20, 5);
    const V0 = 3.0; // L at 27 °C, 1 atm
    const vol = (T, P) => V0 * (T / 300.15) * (1 / P);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), T = tc + 273.15, Vv = vol(T, 1);
      const cx = wd ? 56 : W / 2 - 60, cw = 110, cy = 40, ch = 200;
      // bath
      const hot = Math.max(0, Math.min(1, (tc + 50) / 350)); g.fillStyle = `rgba(${Math.round(60 + 190 * hot)},${Math.round(140 - 60 * hot)},${Math.round(230 - 180 * hot)},.22)`; g.fillRect(cx - 22, cy + ch * 0.45, cw + 44, ch * 0.58); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(cx - 22, cy + ch * 0.45, cw + 44, ch * 0.58);
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('তাপ-স্নান', cx - 18, cy + ch * 1.03 - 4);
      const box = cylinder(g, col, cx, cy, cw, ch, Math.min(1, Vv / 6), { weights: 2, scale: f => bn(Math.round(f * 6)) + ' L' });
      drawGas(g, G, box, 4.5);
      if (tc > 60) flame(g, cx + cw / 2, cy + ch * 1.03 + 26, 9 + tc / 40, t); else if (tc < 0) ice(g, cx + cw / 2, cy + ch * 1.03 + 24, 11);
      thermo(g, col, cx + cw + 40, cy + 30, ch - 50, (tc + 220) / 540, `${bn(Math.round(tc))} °C`);
      // graph
      const gx0 = wd ? W * 0.45 : 58, gy0 = wd ? 44 : cy + ch + 90, gw = wd ? W - gx0 - 22 : W - 80, gh = wd ? H - 90 : H - gy0 - 48;
      const kAx = ax === 'k';
      const Pl = kAx ? cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: 0, xmax: 600, ymax: 6, col, xt: [0, 100, 200, 300, 400, 500, 600], yt: [0, 2, 4, 6], xl: 'T (K)', yl: 'V (L)' })
        : cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: -300, xmax: 300, ymax: 6, col, xt: [-273, -200, -100, 0, 100, 200, 300], yt: [0, 2, 4, 6], xl: 't (°C)', yl: 'V (L)' });
      if (!kAx) { g.strokeStyle = col.mu; g.lineWidth = 1; g.beginPath(); g.moveTo(Pl.X(0), gy0); g.lineTo(Pl.X(0), gy0 + gh); g.stroke(); }
      const PS = [[1, '#d06a1e'], [2, '#2f9e44'], [4, '#2d6fd6']]; PS.forEach(([P, cc]) => {
        const xv = TK => kAx ? TK : TK - 273.15; const solid = [], dash = [];
        for (let TK = 0; TK <= 600; TK += 4) { const v = vol(TK, P); if (v > 6.2) break; (TK < 73 ? dash : solid).push([Pl.X(xv(TK)), Pl.Y(v)]); if (TK === 72) solid.push([Pl.X(xv(TK)), Pl.Y(v)]); }
        path(g, dash, cc, 1.5, [4, 4]); path(g, solid, cc, P === 1 ? 2.8 : 1.7);
      });
      legend(g, col, gx0 + 8, gy0 + 4, PS.map(([P, cc]) => [cc, `P = ${bn(P)} atm`]));
      if (!kAx) { ball(g, Pl.X(-273.15), Pl.Y(0), 5, '#7b3fa0', '#d9b8f0'); g.fillStyle = '#7b3fa0'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('−২৭৩.১৫ °C (পরম শূন্য)', Pl.X(-262), Pl.Y(0) - 18); }
      else { g.fillStyle = '#7b3fa0'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('০ K: সব রেখা মূলবিন্দুতে', Pl.X(8), Pl.Y(0) - 8); }
      const xv = kAx ? T : tc; g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(Pl.X(xv), Pl.Y(0)); g.lineTo(Pl.X(xv), Pl.Y(Vv)); g.stroke(); g.setLineDash([]);
      ball(g, Pl.X(xv), Pl.Y(Vv), 6.5, '#c0392b', '#ffb3a8');
      g.fillStyle = col.fg; g.font = `bold 11.5px ${col.font}`; g.textAlign = 'center'; g.fillText(kAx ? 'V ∝ T: মূলবিন্দুগামী সমচাপ রেখা' : 'V = V₀(1 + t/273)', gx0 + gw / 2, gy0 - 20);
    };
    const info = () => {
      const T = tc + 273.15, Vv = vol(T, 1); q('[data-tv]').textContent = bn(tc);
      out.innerHTML = TXB(`V_2 = V_1\\dfrac{T_2}{T_1} = 3.00\\times\\dfrac{${T.toFixed(2)}}{300.15} = ${Vv.toFixed(2)}\\ \\mathrm{L}`) + TXB(`\\dfrac{V}{T} = ${(Vv / T).toFixed(5)}\\ \\mathrm{L\\,K^{-1}} = \\dfrac{nR}{P}\\ (\\text{ধ্রুবক})`) +
        `<div class="small">${tc < -150 ? 'বাস্তবে এত ঠান্ডায় অধিকাংশ গ্যাস তরল হয়ে যায় (N₂: −১৯৬ °C) — তাই পরম শূন্য পর্যন্ত রেখাটি কেবল বহির্বেশন (কাটা রেখা)।' : 'প্রতি ১ °C পরিবর্তনে আয়তন ০ °C এর আয়তনের ১/২৭৩ ভাগ বদলায়।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; stepGas(G, dt, 0.5 * Math.sqrt((tc + 273.15) / 300), 0.02); } draw(); }, { paused: false });
    X.onSeg(el, 'ax', k => { ax = k; A.draw(); });
    q('[data-t]').oninput = e => { tc = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৩.৪ অ্যাভোগাড্রোর সূত্র ======================= */
const AVG = [['H2', 'H₂', 2.016], ['He', 'He', 4.003], ['O2', 'O₂', 32.00], ['CO2', 'CO₂', 44.01], ['Cl2', 'Cl₂', 70.90]];
const RXV = { hcl: { n: 'H₂ + Cl₂ → 2HCl', r: [['H2', 1], ['Cl2', 1]], p: [['HCl', 2]] }, nh3: { n: 'N₂ + 3H₂ → 2NH₃', r: [['N2', 1], ['H2', 3]], p: [['NH3', 2]] }, h2o: { n: '2H₂ + O₂ → 2H₂O(g)', r: [['H2', 2], ['O2', 1]], p: [['H2O', 2]] } };
V.p2c1_avogadro = {
  t: 'অ্যাভোগাড্রোর সূত্র: সমআয়তন গ্যাসে সমান অণু এবং গ্যাসীয় বিক্রিয়ায় আয়তনের অনুপাত', k: ['anim', 'int', '2d', 'calc'],
  cap: '"সমআয়তন" দৃশ্যে একই তাপমাত্রা ও চাপে পাঁচটি সমান আয়তনের পাত্রে পাঁচ ভিন্ন গ্যাস — প্রতিটিতে ঠিক সমান সংখ্যক অণু (গুনে দেখো), কিন্তু নিচের তুলাদণ্ডে ভর মোলার ভরের অনুপাতে ভিন্ন। হালকা অণুগুলো দ্রুত ছোটে। "আয়তন অনুপাত" দৃশ্যে প্রতিটি ঘনক = ১ আয়তন; বিক্রিয়া চালালে অণুগুলো পুনর্বিন্যস্ত হয়ে উৎপাদের ঘনকে যায় — H₂ + Cl₂ এ ১ + ১ → ২ আয়তন, যা কেবল দ্বিপরমাণুক অণু ধরলেই সম্ভব (অ্যাভোগাড্রোর ব্যাখ্যা)।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['eq', 'সমআয়তন'], ['rx', 'আয়তন অনুপাত']], 'eq')} <span data-rxs style="display:none">${X.seg('r', Object.keys(RXV).map(k => [k, RXV[k].n]), 'hcl')}</span></div>${X.cv('অ্যাভোগাড্রোর সূত্র')}<div class="ctl"><label class="small" style="flex:1;min-width:150px" data-nl>প্রতি পাত্রে অণু = <b data-nv></b> <input type="range" min="4" max="16" step="1" value="8" data-n></label><button class="btn sm" data-go style="display:none">বিক্রিয়া চালাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 560;
    let L = X.fit(c, hf), mode = 'eq', rk = 'hcl', N = 8, t = 0, prog = 0, run = false;
    const gases = AVG.map((a, i) => mkGas(16, 30 + i, [a[0]]));
    const ATOMS = { H2: [['H', 'H']], Cl2: [['Cl', 'Cl']], N2: [['N', 'N']], O2: [['O', 'O']], HCl: [['H', 'Cl']], NH3: [['N', 'H', 'H', 'H']], H2O: [['O', 'H', 'H']] };
    const ACOL = { H: ['#9aa0a8', '#ffffff', 5], Cl: ['#4a9a2a', '#cff5a0', 8], N: ['#2d5fb3', '#9cc0ff', 7], O: ['#c23b2a', '#ff9a8a', 7] };
    const drawMol = (g, x, y, k, s) => { const at = ATOMS[k][0]; if (at.length === 2) { ball(g, x - 4 * s, y, ACOL[at[0]][2] * s, ACOL[at[0]][0], ACOL[at[0]][1]); ball(g, x + 4 * s, y, ACOL[at[1]][2] * s, ACOL[at[1]][0], ACOL[at[1]][1]); } else { ball(g, x, y, ACOL[at[0]][2] * s, ACOL[at[0]][0], ACOL[at[0]][1]); for (let i = 1; i < at.length; i++) { const a = -Math.PI / 2 + (i - 1) * 2.1 + 0.6; ball(g, x + Math.cos(a) * 7 * s, y + Math.sin(a) * 7 * s, ACOL[at[i]][2] * s, ACOL[at[i]][0], ACOL[at[i]][1]); } } };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (mode === 'eq') {
        const n = AVG.length, cols = wd ? 5 : 3, bw = Math.min(110, (W - 30) / cols - 12), bh = bw * 1.05;
        AVG.forEach(([k, nm, M], i) => {
          const r = Math.floor(i / cols), cI = i % cols, x = 15 + cI * ((W - 30) / cols) + ((W - 30) / cols - bw) / 2, y = 30 + r * (bh + 110);
          g.fillStyle = 'rgba(150,200,240,.12)'; g.fillRect(x, y, bw, bh); g.strokeStyle = col.fg; g.lineWidth = 1.4; g.strokeRect(x, y, bw, bh);
          drawGas(g, gases[i], { x: x + 4, y: y + 4, w: bw - 8, h: bh - 8 }, 4.4, N);
          g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + bw / 2, y - 8);
          // balance pan
          const py = y + bh + 26, mass = N * M, mh = Math.min(40, mass / (16 * 71) * 40 + 3);
          g.fillStyle = '#c9a25c'; g.fillRect(x + bw / 2 - 2, y + bh, 4, 18); g.fillStyle = '#8a6d3b'; g.beginPath(); g.ellipse(x + bw / 2, py, bw * 0.42, 6, 0, 0, 7); g.fill();
          g.fillStyle = (GCOL[k] || GCOL.N2)[0]; g.globalAlpha = 0.75; g.fillRect(x + bw / 2 - 10, py - 6 - mh, 20, mh); g.globalAlpha = 1;
          g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText(`অণু: ${bn(N)}`, x + bw / 2, py + 20); g.fillStyle = col.mu; g.fillText(`আপেক্ষিক ভর ${fx(M / 2.016, 1)}`, x + bw / 2, py + 34);
        });
        g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('সব পাত্র: একই V, T, P', 12, 14);
      } else {
        const R0 = RXV[rk], unit = Math.min(64, (W - 60) / (wd ? 8 : 5.5)), e = C4.ease(prog);
        const nR = R0.r.reduce((s, x) => s + x[1], 0), nP = R0.p.reduce((s, x) => s + x[1], 0);
        const y0 = 60, totalW = (nR + nP) * (unit + 10) + 90, sx = Math.max(10, (W - totalW) / 2);
        const yRow = wd ? y0 : 50;
        const cubes = []; let x = sx; R0.r.forEach(([k, m], ri) => { for (let j = 0; j < m; j++) { cubes.push({ x, y: yRow, k, side: 'r' }); x += unit + 10; } if (ri < R0.r.length - 1) { g.fillStyle = col.fg; g.font = `bold 18px ${col.font}`; g.textAlign = 'center'; g.fillText('+', x - 2, yRow + unit / 2 + 6); x += 14; } });
        const ax = x + 6; x += 54; R0.p.forEach(([k, m]) => { for (let j = 0; j < m; j++) { cubes.push({ x, y: yRow, k, side: 'p' }); x += unit + 10; } });
        g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(ax, yRow + unit / 2); g.lineTo(ax + 40, yRow + unit / 2); g.stroke(); g.beginPath(); g.moveTo(ax + 40, yRow + unit / 2); g.lineTo(ax + 32, yRow + unit / 2 - 5); g.lineTo(ax + 32, yRow + unit / 2 + 5); g.fill();
        const per = 4; // molecules per volume (scaled)
        cubes.forEach(cb => { const op = cb.side === 'r' ? 1 - e * 0.8 : 0.2 + e * 0.8; g.globalAlpha = op; g.fillStyle = 'rgba(150,200,240,.15)'; g.fillRect(cb.x, cb.y, unit, unit); g.strokeStyle = col.fg; g.lineWidth = 1.3; g.strokeRect(cb.x, cb.y, unit, unit); g.globalAlpha = 1;
          if ((cb.side === 'r' && e < 0.98) || (cb.side === 'p' && e > 0.02)) { g.globalAlpha = cb.side === 'r' ? 1 - e : e; for (let m = 0; m < per; m++) { const mx = cb.x + unit * (0.27 + 0.46 * (m % 2)) + Math.sin(t * 2 + m * 1.7) * 2, my = cb.y + unit * (0.28 + 0.44 * Math.floor(m / 2)) + Math.cos(t * 2.3 + m) * 2; drawMol(g, mx, my, cb.k, unit / 64); } g.globalAlpha = 1; }
          g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText({ H2: 'H₂', Cl2: 'Cl₂', N2: 'N₂', O2: 'O₂', HCl: 'HCl', NH3: 'NH₃', H2O: 'H₂O' }[cb.k], cb.x + unit / 2, cb.y + unit + 14); });
        // ratio
        g.fillStyle = col.fg; g.font = `bold 13px ${col.font}`; g.textAlign = 'center';
        const ratio = R0.r.map(r => bn(r[1])).join(' : ') + ' : ' + R0.p.map(p => bn(p[1])).join(' : ');
        g.fillText(`আয়তন অনুপাত = ${ratio}`, W / 2, yRow + unit + 50);
        g.font = `11px ${col.font}`; g.fillStyle = col.mu; g.fillText(`প্রতি ঘনকে সমান সংখ্যক অণু (এখানে ${bn(per)}টি) — একই T ও P তে`, W / 2, yRow + unit + 72);
        // Dalton's failure note
        if (rk === 'hcl') { const yy = yRow + unit + 100; g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.fillText('ডাল্টনের পরমাণু ধরে: H + Cl → HCl = ১ আয়তন ✗', W / 2, yy); g.fillStyle = '#2f9e44'; g.fillText('অ্যাভোগাড্রোর অণু ধরে: H₂ + Cl₂ → 2HCl = ২ আয়তন ✓', W / 2, yy + 20); }
        else if (rk === 'nh3') { g.fillStyle = col.mu; g.font = `11px ${col.font}`; g.fillText('৪ আয়তন বিক্রিয়ক → ২ আয়তন উৎপাদ: মোট আয়তন অর্ধেক', W / 2, yRow + unit + 100); }
        else { g.fillStyle = col.mu; g.font = `11px ${col.font}`; g.fillText('১০০ °C এর উপরে H₂O গ্যাস হলে: ৩ আয়তন → ২ আয়তন', W / 2, yRow + unit + 100); }
      }
    };
    const info = () => {
      q('[data-nv]').textContent = bn(N);
      if (mode === 'eq') out.innerHTML = TXB(`\\text{একই }V, T, P:\\quad N_{\\ce{H2}} = N_{\\ce{O2}} = N_{\\ce{CO2}}\\;\\Rightarrow\\; \\dfrac{m_{\\ce{O2}}}{m_{\\ce{H2}}} = \\dfrac{M_{\\ce{O2}}}{M_{\\ce{H2}}} = \\dfrac{32.00}{2.016} = 15.9`) + TXB(`D = \\dfrac{M}{2}\\;\\Rightarrow\\; M = 2D\\quad(\\ce{CO2}: D = 22,\\ M = 44)`) + '<div class="small">অণুর সংখ্যা স্লাইডারে বদলাও — সব পাত্রে একসাথে বদলায়, কারণ V ∝ n এবং আয়তন সমান।</div>';
      else { const R0 = RXV[rk]; out.innerHTML = TXB({ hcl: '\\ce{H2(g) + Cl2(g) -> 2HCl(g)}', nh3: '\\ce{N2(g) + 3H2(g) -> 2NH3(g)}', h2o: '\\ce{2H2(g) + O2(g) -> 2H2O(g)}' }[rk]) + `<div class="small">সমতাকৃত সমীকরণের সহগ (${R0.n}) = একই অবস্থায় গ্যাসগুলোর আয়তনের অনুপাত। যেমন ১০ L N₂ এর সাথে ৩০ L H₂ লাগে, উৎপন্ন হয় ২০ L NH₃।</div>`; }
    };
    const setMode = m => { mode = m; q('[data-rxs]').style.display = m === 'rx' ? '' : 'none'; q('[data-go]').style.display = m === 'rx' ? '' : 'none'; q('[data-nl]').style.display = m === 'eq' ? '' : 'none'; prog = 0; run = false; info(); A.draw(); };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (mode === 'eq') gases.forEach((G, i) => stepGas(G, dt, 0.55 / Math.sqrt(AVG[i][2] / 4), 0.02, N)); if (run) { prog = Math.min(1, prog + dt * 0.5); if (prog >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'm', setMode); X.onSeg(el, 'r', k => { rk = k; prog = 0; run = false; info(); A.draw(); });
    q('[data-n]').oninput = e => { N = +e.target.value; info(); A.draw(); };
    q('[data-go]').onclick = () => { if (prog >= 1) prog = 0; run = true; A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৩.৫ সমন্বয় সূত্র ======================= */
V.p2c1_combined = {
  t: 'সমন্বয় সূত্রের দুই-ধাপ প্রতিপাদন: P–V তলে সমোষ্ণ ও সমচাপ পথ এবং আবহাওয়া বেলুন', k: ['anim', 'int', '2d', 'calc'],
  cap: 'P–V তলে নীল সমোষ্ণ রেখা T₁ ও কমলা সমোষ্ণ রেখা T₂। অবস্থা ১ থেকে প্রথমে T₁ স্থির রেখে চাপ P₂ এ আনা হয় (বয়েল, সমোষ্ণ রেখা বরাবর সবুজ পথ) → মধ্যবর্তী অবস্থা x; তারপর P₂ স্থির রেখে তাপমাত্রা T₂ করা হয় (চার্লস, অনুভূমিক বেগুনি পথ) → অবস্থা ২। বল দুই ধাপে পথ পাড়ি দেয়; প্রতিটি ধাপের সমীকরণ নিচে। ডানে আবহাওয়া বেলুনের আয়তন আনুপাতিকভাবে বদলায়। স্লাইডারে P₂ ও T₂ বদলাও।',
  html: () => `${X.cv('সমন্বয় সূত্র')}<div class="ctl"><label class="small" style="flex:1;min-width:140px">P₂ = <b data-pv></b> atm <input type="range" min="0.2" max="2" step="0.02" value="0.4" data-p></label><label class="small" style="flex:1;min-width:140px">T₂ = <b data-tv></b> K <input type="range" min="200" max="600" step="1" value="450" data-t></label><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 600;
    let L = X.fit(c, hf), P2v = 0.4, T2 = 450, ph = 0;
    const P1 = 1, V1 = 10, T1 = 300, k1 = P1 * V1;
    const st = () => { const Vx = k1 / P2v, V2 = Vx * T2 / T1; return { Vx, V2 }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), S = st();
      const gx0 = 56, gy0 = 30, gw = wd ? W * 0.6 - 70 : W - 80, gh = wd ? H - 76 : 330;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 70, ymax: 2.2, col, xt: [0, 10, 20, 30, 40, 50, 60, 70], yt: [0, 0.5, 1, 1.5, 2], fy: v => bn(v), xl: 'V (L)', yl: 'P (atm)' });
      const iso = (T, cc, lab) => { const k = k1 * T / T1, pts = []; for (let v = 2; v <= 70; v += 0.5) { const p = k / v; if (p <= 2.3) pts.push([Pl.X(v), Pl.Y(p)]); } path(g, pts, cc, 1.6, [5, 3]); };
      iso(T1, '#2d6fd6', `T₁ = ${bn(T1)} K`); iso(T2, '#d06a1e', `T₂ = ${bn(T2)} K`);
      // path 1: along isotherm from V1 to Vx
      const p1 = []; const n1 = 40; for (let i = 0; i <= n1; i++) { const v = V1 + (S.Vx - V1) * i / n1; p1.push([v, k1 / v]); }
      const p2 = [[S.Vx, P2v], [S.V2, P2v]];
      path(g, p1.map(([v, p]) => [Pl.X(v), Pl.Y(p)]), '#2f9e44', 3); path(g, p2.map(([v, p]) => [Pl.X(v), Pl.Y(p)]), '#7b3fa0', 3);
      const pt = (v, p, lab, cc, dy) => { ball(g, Pl.X(Math.min(70, v)), Pl.Y(p), 5.5, cc, '#fff'); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(lab, Pl.X(Math.min(70, v)) + 7, Pl.Y(p) + (dy || -7)); };
      pt(V1, P1, '১ (P₁, V₁, T₁)', '#2d6fd6'); pt(S.Vx, P2v, 'x', '#2f9e44', -9); pt(S.V2, P2v, '২ (P₂, V₂, T₂)', '#d06a1e', -9);
      // moving ball
      const u = (ph % 3) / 3; let mv; if (u < 0.45) { const f = C4.ease(u / 0.45), v = V1 + (S.Vx - V1) * f; mv = [v, k1 / v]; } else if (u < 0.9) { const f = C4.ease((u - 0.45) / 0.45); mv = [S.Vx + (S.V2 - S.Vx) * f, P2v]; } else mv = [S.V2, P2v];
      ball(g, Pl.X(Math.min(70, mv[0])), Pl.Y(mv[1]), 7, '#c0392b', '#ffb3a8');
      legend(g, col, gx0 + gw, gy0 + 2, [['#2d6fd6', `সমোষ্ণ T₁ = ${bn(T1)} K`, [5, 3]], ['#d06a1e', `সমোষ্ণ T₂ = ${bn(T2)} K`, [5, 3]], ['#2f9e44', 'ধাপ ১: বয়েল (T₁ স্থির)'], ['#7b3fa0', 'ধাপ ২: চার্লস (P₂ স্থির)']], true);
      
      // balloon
      const bx = wd ? W * 0.82 : W / 2, by = wd ? H / 2 - 10 : gy0 + gh + 120, Vcur = Math.min(80, mv[0]), r = 18 * Math.cbrt(Vcur / V1);
      const gr = g.createRadialGradient(bx - r * 0.35, by - r * 0.4, r * 0.1, bx, by, r); gr.addColorStop(0, '#ffd2c8'); gr.addColorStop(1, '#d9442f');
      g.fillStyle = gr; g.beginPath(); g.ellipse(bx, by, r, r * 1.12, 0, 0, 7); g.fill(); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 1; g.stroke();
      g.strokeStyle = col.fg; g.beginPath(); g.moveTo(bx, by + r * 1.12); g.lineTo(bx, by + r * 1.12 + 30); g.stroke(); g.fillStyle = '#c9a25c'; g.fillRect(bx - 8, by + r * 1.12 + 30, 16, 12);
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(`V = ${fx(Vcur, 1)} L`, bx, by + r * 1.12 + 58); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText('আবহাওয়া বেলুন (স্কেলে)', bx, Math.max(14, by - r * 1.12 - 10));
    };
    const info = () => {
      const S = st(); q('[data-pv]').textContent = fx(P2v, 2); q('[data-tv]').textContent = bn(T2);
      out.innerHTML = TXB(`\\text{ধাপ ১: } P_1V_1 = P_2V_x \\Rightarrow V_x = \\dfrac{${P1}\\times${V1}}{${P2v.toFixed(2)}} = ${S.Vx.toFixed(2)}\\ \\mathrm{L}`) + TXB(`\\text{ধাপ ২: } \\dfrac{V_x}{T_1} = \\dfrac{V_2}{T_2} \\Rightarrow V_2 = ${S.Vx.toFixed(2)}\\times\\dfrac{${T2}}{${T1}} = ${S.V2.toFixed(2)}\\ \\mathrm{L}`) +
        TXB(`\\text{যাচাই: } \\dfrac{P_1V_1}{T_1} = \\dfrac{${P1}\\times${V1}}{${T1}} = ${(P1 * V1 / T1).toFixed(4)},\\quad \\dfrac{P_2V_2}{T_2} = \\dfrac{${P2v.toFixed(2)}\\times${S.V2.toFixed(2)}}{${T2}} = ${(P2v * S.V2 / T2).toFixed(4)}`) +
        `<div class="small">${P2v < 0.5 && T2 < 280 ? 'উঁচু আকাশের মতো অবস্থা: চাপ কমার প্রভাব (আয়তন বাড়ে) ঠান্ডার প্রভাবকে (আয়তন কমে) ছাপিয়ে যায় — বেলুন বড় হয়।' : 'মধ্যবর্তী অবস্থা x কাল্পনিক; যেকোনো পথে গেলেও শেষ অবস্থা একই।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) ph += dt * 0.9; draw(); }, { paused: false }); X.pp(el, A);
    q('[data-p]').oninput = e => { P2v = +e.target.value; info(); A.draw(); };
    q('[data-t]').oninput = e => { T2 = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
