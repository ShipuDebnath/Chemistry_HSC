/* ২য় পত্র অধ্যায় ১ visuals part 16 — biomagnification, bioaccumulation, chromium chemistry (1.22) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };

/* ======================= খাদ্যশৃঙ্খলে জৈব বিবর্ধন ======================= */
const MET = { // [name, BCF(plankton), BMFs for 4 steps, fish limit mg/kg, color, note]
  hg: ['মিথাইলমারকারি', 10000, [4, 4, 5, 6], 0.5, '#7b3fa0', 'চর্বি ও প্রোটিনে দ্রবণীয়, অত্যন্ত ধীর নিষ্কাশন — প্রতিটি ধাপে প্রবল বিবর্ধন।'],
  cd: ['ক্যাডমিয়াম', 2000, [1.5, 1.2, 1.1, 1.3], 0.1, '#d6a01e', 'কিডনি-যকৃতে জমে, পেশিতে কম — জৈব সঞ্চয়ন বেশি কিন্তু খাদ্যশৃঙ্খলে বিবর্ধন দুর্বল।'],
  pb: ['সীসা', 3000, [2, 1.5, 1.3, 1.5], 0.3, '#555', 'Ca²⁺ এর মতো হাড়, আঁশ ও খোলসে জমে — মাঝারি বিবর্ধন।'],
  as: ['আর্সেনিক', 1500, [0.8, 0.7, 0.8, 0.9], 1.0, '#c0392b', 'জলজ জীব অজৈব As কে কম-বিষাক্ত জৈব রূপে (আর্সেনোবেটাইন) রূপান্তর করে নিষ্কাশন করে — বিবর্ধন সাধারণত হয় না।'],
  cr: ['ক্রোমিয়াম', 800, [0.7, 0.6, 0.6, 0.7], 1.0, '#2f9e44', 'Cr(III) অদ্রবণীয়, শোষণ কম; উচ্চতর স্তরে ঘনত্ব কমে (জৈব হ্রাস)।']
};
const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sciB = v => { if (v >= 0.01 && v < 1000) return bn(v < 1 ? v.toFixed(3) : v.toFixed(1)); const e = Math.floor(Math.log10(v)), m = v / Math.pow(10, e); return `${bn(m.toFixed(1))} × ১০${String(e).split('').map(ch => SUP[ch]).join('')}`; };
const LV = [['পানি', '#4aa0e0'], ['উদ্ভিদ-প্ল্যাংকটন', '#4caf50'], ['প্রাণী-প্ল্যাংকটন', '#8bc34a'], ['ছোট মাছ', '#90a4ae'], ['বড় মাছ', '#607d8b'], ['মাছখেকো পাখি/মানুষ', '#8d6e63']];
V.p2c1_biomag = {
  t: 'খাদ্যশৃঙ্খলে জৈব বিবর্ধন: পানি → প্ল্যাংকটন → মাছ → শিকারি পাখি/মানুষ — বিভিন্ন ভারী ধাতুর ঘনত্বের তুলনা', k: ['anim', 'int', 'calc', '2d'],
  cap: 'বামে খাদ্য পিরামিড — নিচ থেকে উপরে জীবের সংখ্যা কমে (চওড়া থেকে সরু), কিন্তু প্রতিটি জীবে ধাতুর রঙিন বিন্দু বাড়ে। উপরের তালিকা থেকে ধাতু বেছে নাও: মিথাইলমারকারি প্রতিটি ধাপে বহুগুণ বাড়ে, অথচ আর্সেনিক ও ক্রোমিয়াম কমে। ডানে প্রতিটি স্তরের ঘনত্ব লগারিদমিক দণ্ডে; লাল ড্যাশ মাছে খাদ্য-নিরাপত্তা সীমা। পানির ঘনত্ব স্লাইডারে বদলাও।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('mt', Object.entries(MET).map(([k, v]) => [k, v[0]]), 'hg')}</div>${X.cv('জৈব বিবর্ধন')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:180px">পানিতে ঘনত্ব = <b data-wv></b> mg L⁻¹<input type="range" min="-7" max="-3" step="0.1" value="-5.7" data-w></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 600;
    let L = X.fit(c, hf), mt = 'hg', lw = -5.7, t = 0;
    const conc = () => { const M = MET[mt], w = Math.pow(10, lw); const r = [w, w * M[1]]; M[2].forEach(b => r.push(r[r.length - 1] * b)); return r; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), M = MET[mt], C = conc();
      const px = wd ? W * 0.26 : W / 2, py0 = 14, pw = wd ? W * 0.44 : W - 30, ph = wd ? H - 28 : H * 0.5, n = LV.length, lh = ph / n;
      for (let i = 0; i < n; i++) { const y = py0 + ph - (i + 1) * lh, wl = pw * (1 - i / n * 0.85), wu = pw * (1 - (i + 1) / n * 0.85); g.fillStyle = LV[i][1]; g.globalAlpha = 0.35; g.beginPath(); g.moveTo(px - wl / 2, y + lh); g.lineTo(px + wl / 2, y + lh); g.lineTo(px + wu / 2, y); g.lineTo(px - wu / 2, y); g.closePath(); g.fill(); g.globalAlpha = 1; g.strokeStyle = col.fg; g.lineWidth = 1; g.stroke();
        g.fillStyle = col.fg; g.font = `bold ${wd ? 10 : 9.5}px ${col.font}`; g.textAlign = 'center'; g.fillText(LV[i][0], px, y + lh / 2 - 2);
        const lg = Math.log10(C[i]) - lw; const nd = Math.max(1, Math.min(30, Math.round(2 + lg * 2.4))); const Rn = X.rng(i * 7 + 1); for (let k = 0; k < nd; k++) { const xx = px - wu / 2 + 10 + Rn() * (wu - 20) + Math.sin(t * 2 + k) * 2, yy = y + lh / 2 + 4 + Rn() * (lh / 2 - 8); g.fillStyle = M[4]; g.beginPath(); g.arc(xx, yy, 2.3, 0, 7); g.fill(); }
        g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText(`${sciB(C[i])} ${i === 0 ? 'mg L⁻¹' : 'mg kg⁻¹'}`, px, y + lh - 3);
        if (i < n - 1) { g.strokeStyle = col.mu; g.lineWidth = 1.2; g.beginPath(); g.moveTo(px + wu / 2 + 8, y + lh / 2); g.lineTo(px + wu / 2 + 8, y - lh / 2 + 6); g.stroke(); g.beginPath(); g.moveTo(px + wu / 2 + 8, y - lh / 2 + 2); g.lineTo(px + wu / 2 + 4, y - lh / 2 + 9); g.lineTo(px + wu / 2 + 12, y - lh / 2 + 9); g.fillStyle = col.mu; g.fill(); } }
      // bars
      const gx0 = wd ? W * 0.56 : 80, gy0 = wd ? 20 : py0 + ph + 26, gw = wd ? W * 0.41 : W - 96, gh = wd ? H - 50 : H - gy0 - 20;
      const lmin = -7, lmax = 3, X_ = v => gx0 + (Math.log10(Math.max(1e-7, v)) - lmin) / (lmax - lmin) * gw; const rh = gh / n;
      [-6, -4, -2, 0, 2].forEach(e => { const x = X_(Math.pow(10, e)); g.strokeStyle = col.mu; g.globalAlpha = 0.3; g.beginPath(); g.moveTo(x, gy0); g.lineTo(x, gy0 + gh); g.stroke(); g.globalAlpha = 1; g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(`১০${['⁻⁶', '⁻⁴', '⁻²', '⁰', '²'][(e + 6) / 2]}`, x, gy0 + gh + 12); });
      path(g, [[X_(M[3]), gy0], [X_(M[3]), gy0 + gh]], '#c0392b', 1.4, [5, 3]); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('মাছে সীমা', X_(M[3]) + 3, gy0 + 9);
      C.forEach((v, i) => { const y = gy0 + gh - (i + 1) * rh; g.fillStyle = i === 0 ? '#4aa0e0' : (v > M[3] && i >= 3 ? '#c0392b' : M[4]); rr(g, gx0, y + rh * 0.2, Math.max(2, X_(v) - gx0), rh * 0.6, 4); g.fill(); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText(LV[i][0].split('/')[0].replace('উদ্ভিদ-', 'উদ্ভিদ ').slice(0, 14), gx0 - 4, y + rh / 2 + 3); });
    };
    const info = () => { const M = MET[mt], C = conc(); q('[data-wv]').textContent = sciB(Math.pow(10, lw)); const tot = C[5] / C[0]; const unsafe = C[4] > M[3];
      out.innerHTML = TXB(`C_{\\text{শীর্ষ}} = C_{\\text{পানি}}\\times\\mathrm{BCF}\\times\\textstyle\\prod\\mathrm{BMF}`) + TXB(`= ${C[0].toExponential(1).replace('e', '\\times10^{') + '}'}\\times${M[1]}\\times${M[2].reduce((a, b) => a * b, 1).toFixed(1)}`) + `<div class="small">শীর্ষ শিকারিতে পানির তুলনায় <b>${tot >= 1e3 ? sciB(tot) : bn(Math.round(tot))} গুণ</b>। ${M[5]} ${unsafe ? `<span style="color:var(--bad)">বড় মাছে ${bn(C[4].toFixed(2))} mg kg⁻¹ — খাদ্য-নিরাপত্তা সীমা (${bn(M[3])}) অতিক্রম।</span>` : `বড় মাছ নিরাপদ সীমার মধ্যে।`}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'mt', k => { mt = k; info(); A.draw(); });
    q('[data-w]').oninput = e => { lw = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= দেহে জৈব সঞ্চয়ন (বয়সের সাথে) ======================= */
const BA = { pb: ['সীসা (হাড়)', 20, 50, 'µg', '#555'], cd: ['ক্যাডমিয়াম (কিডনি)', 15, 1, 'µg', '#d6a01e'], hg: ['মিথাইলমারকারি', 0.19, 5, 'µg', '#7b3fa0'], as: ['অজৈব আর্সেনিক', 0.011, 300, 'µg', '#c0392b'] }; // t½ years, absorbed intake µg/day
V.p2c1_bioaccum = {
  t: 'দেহে জৈব সঞ্চয়ন: গ্রহণ বনাম নিষ্কাশন — জৈবিক অর্ধায়ুর উপর নির্ভর করে বয়সের সাথে দেহভার (সীসা, ক্যাডমিয়াম, পারদ, আর্সেনিক)', k: ['int', 'calc', '2d'],
  cap: 'একজন মানুষের দেহে একটি ধাতুর মোট পরিমাণ (দেহভার) বয়সের সাথে কীভাবে বাড়ে: প্রতিদিন নির্দিষ্ট পরিমাণ শোষিত হয়, আর দেহ তার একটি ভগ্নাংশ নিষ্কাশন করে (dQ/dt = I − kQ)। জৈবিক অর্ধায়ু যত দীর্ঘ, স্থিতিশীল অবস্থায় পৌঁছাতে তত বেশি সময় লাগে এবং তত বেশি জমে। ধাতু বেছে নাও, দৈনিক শোষিত মাত্রা বদলাও, আর "সংস্পর্শ বন্ধ" এর বয়স ঠিক করে দেখো ধাতু দেহ থেকে কত ধীরে বের হয় — ক্যাডমিয়াম ও সীসা কয়েক দশক থাকে, আর্সেনিক কয়েক দিনে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ba', Object.entries(BA).map(([k, v]) => [k, v[0]]), 'cd')}</div>${X.cv('জৈব সঞ্চয়ন')}<div class="ctl"><label class="small" style="flex:1;min-width:130px">দৈনিক শোষিত = <b data-iv></b> µg<input type="range" min="0.1" max="3" step="0.05" value="1" data-i></label><label class="small" style="flex:1;min-width:130px">সংস্পর্শ বন্ধ = <b data-sv></b> বছর বয়সে<input type="range" min="5" max="80" step="1" value="80" data-s></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 280 : 340;
    let L = X.fit(c, hf), m = 'cd', mul = 1, stop = 80;
    const Q = age => { const [, th, I0] = BA[m]; const k = 0.693 / th; const I = I0 * mul * 365; if (age <= stop) return I / k * (1 - Math.exp(-k * age)); const Qs = I / k * (1 - Math.exp(-k * stop)); return Qs * Math.exp(-k * (age - stop)); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const B = BA[m]; const ymax = Math.max(...Array.from({ length: 81 }, (_, a) => Q(a))) * 1.15 || 1; const sc = ymax > 5000 ? 1000 : 1, un = sc === 1000 ? 'mg' : 'µg';
      const gx0 = 58, gy0 = 16, gw = W - 76, gh = H - 56; const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 80, ymax: ymax / sc, col, xt: [0, 20, 40, 60, 80], yt: [0, 0.25, 0.5, 0.75, 1].map(f => +(f * ymax / sc).toPrecision(2)), xl: 'বয়স (বছর)', yl: `দেহভার (${un})`, fy: v => bn(v), ylx: 42 });
      const ss = B[2] * mul * 365 / (0.693 / B[1]); path(g, [[gx0, Pl.Y(ss / sc)], [gx0 + gw, Pl.Y(ss / sc)]], col.mu, 1, [4, 3]); if (ss < ymax) { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText('স্থিতিশীল মান', gx0 + gw - 4, Pl.Y(ss / sc) - 4); }
      const pts = []; for (let a = 0; a <= 80; a += 0.2) pts.push([Pl.X(a), Pl.Y(Q(a) / sc)]); path(g, pts, B[4], 2.6); if (stop < 80) { path(g, [[Pl.X(stop), gy0], [Pl.X(stop), gy0 + gh]], '#2f9e44', 1.2, [3, 3]); g.fillStyle = '#2f9e44'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('সংস্পর্শ বন্ধ', Pl.X(stop) + 3, gy0 + 10); }
      [10, 40, 70].forEach(a => { ball(g, Pl.X(a), Pl.Y(Q(a) / sc), 3.5, B[4], '#fff'); });
    };
    const info = () => { const B = BA[m]; q('[data-iv]').textContent = bn((B[2] * mul).toFixed(B[2] * mul < 10 ? 1 : 0)); q('[data-sv]').textContent = bn(stop); const k = 0.693 / B[1]; const t90 = Math.log(10) / k;
      out.innerHTML = TXB(`Q(t) = \\dfrac{I}{k}\\left(1 - e^{-kt}\\right),\\quad k = \\dfrac{0.693}{${B[1] < 1 ? (B[1] * 365).toFixed(0) + '\\ \\text{দিন}' : B[1] + '\\ \\text{বছর}'}}`) + `<div class="small">জৈবিক অর্ধায়ু ${B[1] < 1 ? bn(Math.round(B[1] * 365)) + ' দিন' : bn(B[1]) + ' বছর'}: স্থিতিশীল অবস্থার ৯০% এ পৌঁছাতে ${t90 < 1 ? bn(Math.round(t90 * 365)) + ' দিন' : bn(t90.toFixed(0)) + ' বছর'}। ${B[1] > 5 ? 'দীর্ঘ অর্ধায়ু — শৈশবের সংস্পর্শের প্রভাব বার্ধক্য পর্যন্ত থাকে; সংস্পর্শ বন্ধের পরও কয়েক দশক দেহে থাকে।' : 'স্বল্প অর্ধায়ু — উৎস বন্ধ করলে দ্রুত কমে; বিপদ মূলত চলমান উচ্চ সংস্পর্শে (যেমন নলকূপের আর্সেনিক)।'}</div>`; };
    X.onSeg(el, 'ba', k => { m = k; info(); draw(); });
    q('[data-i]').oninput = e => { mul = +e.target.value; info(); draw(); };
    q('[data-s]').oninput = e => { stop = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= ক্রোমিয়ামের রসায়ন: ক্রোমেট-ডাইক্রোমেট, বিজারণ, অধঃক্ষেপণ ======================= */
V.p2c1_chromium = {
  t: 'ক্রোমিয়ামের রসায়ন: CrO₄²⁻ ⇌ Cr₂O₇²⁻ (pH), Fe²⁺ দিয়ে Cr(VI) → Cr(III) বিজারণ এবং Cr(OH)₃ অধঃক্ষেপণ (ভার্চুয়াল ল্যাব)', k: ['int', 'calc', '2d', 'anim'],
  cap: 'একটি বিকারে ট্যানারির Cr(VI) বর্জ্য। প্রথমে pH স্লাইডার: ক্ষারীয় দ্রবণ হলুদ (ক্রোমেট CrO₄²⁻), অম্লীয় দ্রবণ কমলা (ডাইক্রোমেট Cr₂O₇²⁻) — লে শাতেলিয়ের নীতি। তারপর অম্লীয় অবস্থায় Fe²⁺ যোগ করো: কমলা ধীরে সবুজ (Cr³⁺) হয়। শেষে চুন দিয়ে pH ৮–৯ এ তুললে ধূসর-সবুজ Cr(OH)₃ তলায় থিতায় — খুব বেশি pH এ আবার [Cr(OH)₄]⁻ হয়ে দ্রবীভূত। ডানে দ্রবণে Cr(VI), Cr(III) ও অধঃক্ষেপের পরিমাণ।',
  html: () => `${X.cv('ক্রোমিয়াম ল্যাব')}<div class="ctl"><label class="small" style="flex:1;min-width:110px">pH = <b data-pv></b><input type="range" min="1" max="13" step="0.1" value="2.5" data-p></label><label class="small" style="flex:1;min-width:130px">যোগ করা Fe²⁺ = <b data-fv></b>% (স্টয়কিওমেট্রিক)<input type="range" min="0" max="130" step="1" value="0" data-f></label><button class="btn sm" data-rs>নতুন নমুনা</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 460;
    let L = X.fit(c, hf), pH = 2.5, fe = 0, t = 0, settle = 0, RED = 0;
    const state = () => { const red = RED; const cr6 = 1 - red, cr3 = red; const dich = 1 / (1 + Math.pow(10, (pH - 6.5) * 1.3)); const insol = pH >= 6.5 && pH <= 11 ? Math.min(1, (pH - 6.5) / 1.5) * (pH > 10 ? Math.max(0, (11 - pH)) : 1) : 0; return { cr6, cr3, dich, ppt: cr3 * insol, cr3sol: cr3 * (1 - insol) }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), S = state();
      const bx = wd ? W * 0.28 : W / 2, by = 30, bw = wd ? 170 : 150, bh = wd ? H - 70 : 220;
      const yel = [240, 200, 30], ora = [235, 110, 25], grn = [60, 140, 90], vio = [110, 90, 140]; const c6 = yel.map((v, k) => v + (ora[k] - v) * S.dich); const c3 = pH > 11 ? vio.map((v, k) => v * 0.6 + grn[k] * 0.4) : grn; const tot = S.cr6 + S.cr3sol; const mix = c6.map((v, k) => (v * S.cr6 + c3[k] * S.cr3sol) / Math.max(1e-6, tot)); const alpha = 0.15 + 0.7 * Math.min(1, tot * 1.2);
      g.fillStyle = `rgba(${mix.map(Math.round).join(',')},${alpha})`; g.fillRect(bx - bw / 2, by + 20, bw, bh - 20);
      const pp = S.ppt * Math.min(1, settle); if (pp > 0.01) { g.fillStyle = 'rgba(95,120,95,.95)'; const ph2 = 26 * pp; g.beginPath(); g.moveTo(bx - bw / 2, by + bh); for (let x = 0; x <= bw; x += 6) g.lineTo(bx - bw / 2 + x, by + bh - ph2 - Math.sin(x * 0.3) * 2); g.lineTo(bx + bw / 2, by + bh); g.fill(); if (settle < 1) { const Rn = X.rng(3); for (let k = 0; k < 30 * S.ppt; k++) { g.fillStyle = 'rgba(95,120,95,.8)'; g.beginPath(); g.arc(bx - bw / 2 + 6 + Rn() * (bw - 12), by + 30 + Rn() * (bh - 60) * (1 - settle) + settle * (bh - 40), 2.4, 0, 7); g.fill(); } } }
      g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(bx - bw / 2 - 4, by); g.lineTo(bx - bw / 2, by + bh); g.lineTo(bx + bw / 2, by + bh); g.lineTo(bx + bw / 2 + 4, by); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(S.cr6 > 0.5 ? (S.dich > 0.5 ? 'কমলা: Cr₂O₇²⁻' : 'হলুদ: CrO₄²⁻') : S.ppt > 0.5 ? 'স্বচ্ছ + Cr(OH)₃ অধঃক্ষেপ' : pH > 11 ? 'বেগুনি-সবুজ: [Cr(OH)₄]⁻' : 'সবুজ: Cr³⁺', bx, by + bh + 18);
      // pH strip
      const sx = bx - bw / 2, sy = 10; for (let i = 0; i < bw; i++) { const p = 1 + i / bw * 12; g.fillStyle = `hsl(${Math.round((p - 1) / 12 * 260)},70%,55%)`; g.fillRect(sx + i, sy, 1.2, 6); } const mx = sx + (pH - 1) / 12 * bw; g.fillStyle = col.fg; g.beginPath(); g.moveTo(mx, sy + 8); g.lineTo(mx - 4, sy + 14); g.lineTo(mx + 4, sy + 14); g.fill();
      // bars
      const gx0 = wd ? W * 0.56 : 30, gy0 = wd ? 40 : by + bh + 40, gw = wd ? W * 0.4 : W - 60, gh = wd ? H - 90 : H - gy0 - 20; const items = [['Cr(VI) দ্রবণে', S.cr6, '#e07a20'], ['Cr(III) দ্রবণে', S.cr3sol, '#3c8c5a'], ['Cr(OH)₃ অধঃক্ষেপ', S.ppt * Math.min(1, settle), '#5f785f']]; const rh = gh / 3;
      items.forEach(([nm, v, cc], i) => { const y = gy0 + i * rh; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(nm, gx0, y + 12); g.fillStyle = col.s2 || 'rgba(0,0,0,.06)'; rr(g, gx0, y + 18, gw, 16, 8); g.fill(); g.fillStyle = cc; rr(g, gx0, y + 18, Math.max(2, gw * v), 16, 8); g.fill(); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText(`${bn(Math.round(v * 100))}%`, gx0 + gw, y + 12); });
    };
    const info = () => { q('[data-pv]').textContent = bn(pH.toFixed(1)); q('[data-fv]').textContent = bn(fe); const S = state();
      out.innerHTML = (fe === 0 ? TXB('\\ce{2CrO4^2- + 2H+ <=> Cr2O7^2- + H2O}') : TXB('\\ce{Cr2O7^2- + 6Fe^2+ + 14H+ -> 2Cr^3+ + 6Fe^3+ + 7H2O}')) + `<div class="small">${fe > 0 && pH > 5 ? '<b>সতর্কতা:</b> বিজারণ অম্লীয় মাধ্যমে (pH ২–৩) করতে হয় — উচ্চ pH এ Fe²⁺ নিজেই অধঃক্ষিপ্ত হয়, বিক্রিয়া অসম্পূর্ণ। ' : ''}${S.cr6 > 0.05 && S.ppt > 0.3 ? 'Cr(VI) এখনো দ্রবণে — ক্রোমেট অধঃক্ষিপ্ত হয় না! আগে পুরো বিজারণ দরকার। ' : ''}${S.cr6 < 0.05 && S.ppt > 0.9 ? '<b>সফল শোধন:</b> Cr(VI) বিজারিত ও Cr(OH)₃ রূপে অপসারিত। ' : ''}${pH > 10.5 && S.cr3 > 0.5 ? 'pH অত্যধিক — উভধর্মী Cr(OH)₃ আবার [Cr(OH)₄]⁻ রূপে দ্রবীভূত হচ্ছে। ' : ''}${fe > 105 ? 'অতিরিক্ত Fe²⁺ — অপচয় ও বেশি কাদা। ' : ''}ধাপ: pH ২.৫ → Fe²⁺ ১০০% → pH ৮.৫।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; settle = Math.min(1, settle + dt * 0.4); } draw(); }, { paused: false });
    q('[data-p]').oninput = e => { pH = +e.target.value; settle = 0; info(); };
    q('[data-f]').oninput = e => { fe = +e.target.value; RED = Math.max(RED, Math.min(1, fe / 100) * (pH < 5 ? 1 : pH < 7 ? 0.5 : 0.15)); info(); };
    q('[data-rs]').onclick = () => { pH = 2.5; fe = 0; settle = 0; RED = 0; q('[data-p]').value = 2.5; q('[data-f]').value = 0; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
