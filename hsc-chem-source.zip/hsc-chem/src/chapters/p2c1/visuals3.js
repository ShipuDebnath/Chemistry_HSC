/* ২য় পত্র অধ্যায় ১ visuals part 3 — ideal gas (1.3.6), Dalton (1.3.7), Graham (1.3.8) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide;
const { GCOL, mkGas, stepGas, drawGas, surf3d, heat, thermo } = P2;
const R = 0.0821;

/* ======================= ১.৩.৬ P-V-T ত্রিমাত্রিক পৃষ্ঠ ======================= */
V.p2c1_pvt3d = {
  t: 'আদর্শ গ্যাসের P–V–T ত্রিমাত্রিক পৃষ্ঠ (PV = nRT): সমোষ্ণ, সমচাপ ও সমআয়তন ছেদরেখা', k: ['3d', 'int', 'anim'],
  cap: '১ মোল আদর্শ গ্যাসের সব সম্ভাব্য অবস্থা একটি বাঁকা পৃষ্ঠ: অনুভূমিক অক্ষে আয়তন V (৫–৪০ L) ও তাপমাত্রা T (১০০–৬০০ K), উল্লম্ব অক্ষে চাপ P (রং: বেগুনি = নিম্ন, লাল = উচ্চ)। টেনে ঘোরাও। বোতামে একটি ছেদতল বেছে নাও — সমোষ্ণ (T স্থির → বয়েলের পরাবৃত্ত), সমচাপ (P স্থির → চার্লসের সরলরেখা), সমআয়তন (V স্থির → গে-লুসাকের সরলরেখা)। স্লাইডারে ছেদের মান বদলাও; সাদা রেখাটি পৃষ্ঠে ঐ সূত্রের বক্ররেখা, লাল বিন্দু তার উপর চলে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('sl', [['T', 'সমোষ্ণ (T স্থির)'], ['P', 'সমচাপ (P স্থির)'], ['V', 'সমআয়তন (V স্থির)']], 'T')}</div>${X.cv('P-V-T পৃষ্ঠ')}<div class="ctl"><label class="small" style="flex:1;min-width:160px"><span data-lab></span> <input type="range" min="0" max="100" value="40" data-s></label><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 380 : 400;
    let L = X.fit(c, hf), sl = 'T', s = 40, ph = 0;
    const view = { yaw: 3.9, pitch: 0.45 };
    const Vmin = 5, Vmax = 40, Tmin = 100, Tmax = 600, Pmax = 6;
    const Pof = (u, v) => R * (Tmin + v * (Tmax - Tmin)) / (Vmin + u * (Vmax - Vmin));
    const val = () => { const u = s / 100; return sl === 'T' ? Tmin + u * (Tmax - Tmin) : sl === 'P' ? 0.5 + u * 4.5 : Vmin + u * (Vmax - Vmin); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const P3 = surf3d(g, W, H, view, (u, v) => Pof(u, v) / Pmax, 30, 24, z => heat(z), -24);
      const ax = (a, b, txt) => { const p = P3(...a), p2 = P3(...b); g.strokeStyle = col.fg; g.lineWidth = 1.3; g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(p2[0], p2[1]); g.stroke(); g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(txt, p2[0] + (p2[0] - p[0]) * 0.1, p2[1] + (p2[1] - p[1]) * 0.1 + 4); };
      ax([0, 0, 0], [1.12, 0, 0], 'V (৫→৪০ L)'); ax([0, 0, 0], [0, 1.14, 0], 'T (১০০→৬০০ K)'); ax([0, 0, 0], [0, 0, 1.12], 'P (atm)');
      // slice curve
      const v0 = val(), pts = [];
      if (sl === 'T') { const vv = (v0 - Tmin) / (Tmax - Tmin); for (let k = 0; k <= 60; k++) { const u = k / 60, P = Pof(u, vv); if (P <= Pmax) pts.push([u, vv, P / Pmax]); } }
      else if (sl === 'V') { const uu = (v0 - Vmin) / (Vmax - Vmin); for (let k = 0; k <= 60; k++) { const v = k / 60, P = Pof(uu, v); if (P <= Pmax) pts.push([uu, v, P / Pmax]); } }
      else { for (let k = 0; k <= 60; k++) { const v = k / 60, T = Tmin + v * (Tmax - Tmin), Vv = R * T / v0, u = (Vv - Vmin) / (Vmax - Vmin); if (u >= 0 && u <= 1) pts.push([u, v, v0 / Pmax]); } }
      const pp = pts.map(p => P3(...p));
      path(g, pp.map(p => [p[0], p[1]]), 'rgba(0,0,0,.55)', 6); path(g, pp.map(p => [p[0], p[1]]), '#ffffff', 3.2);
      // floor shadow of slice
      path(g, pts.map(p => P3(p[0], p[1], 0)).map(p => [p[0], p[1]]), 'rgba(255,255,255,.55)', 1.4, [4, 3]);
      if (pts.length) { const i = Math.floor((Math.sin(ph) * 0.5 + 0.5) * (pts.length - 1)), p = pts[i], q3 = P3(...p), b = P3(p[0], p[1], 0); g.strokeStyle = '#c0392b'; g.setLineDash([3, 3]); g.lineWidth = 1.2; g.beginPath(); g.moveTo(b[0], b[1]); g.lineTo(q3[0], q3[1]); g.stroke(); g.setLineDash([]); ball(g, q3[0], q3[1], 6.5, '#c0392b', '#ffb3a8');
        const Vv = Vmin + p[0] * (Vmax - Vmin), T = Tmin + p[1] * (Tmax - Tmin), P = p[2] * Pmax; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`P = ${fx(P, 2)} atm, V = ${fx(Vv, 1)} L, T = ${bn(Math.round(T))} K`, 10, H - 10); }
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('টেনে ঘোরাও · n = ১ mol', 10, 14);
      // color legend
      const lx = W - 28, ly = 30, lh = 110; for (let k = 0; k < lh; k++) { g.fillStyle = heat(1 - k / lh); g.fillRect(lx, ly + k, 12, 1.2); } g.strokeStyle = col.fg; g.lineWidth = 0.8; g.strokeRect(lx, ly, 12, lh); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText(`${bn(Pmax)} atm`, lx - 3, ly + 8); g.fillText('০', lx - 3, ly + lh);
    };
    const info = () => {
      const v0 = val(); q('[data-lab]').innerHTML = { T: `T = <b>${bn(Math.round(v0))}</b> K`, P: `P = <b>${fx(v0, 2)}</b> atm`, V: `V = <b>${fx(v0, 1)}</b> L` }[sl];
      out.innerHTML = TXB({ T: `T = ${Math.round(v0)}\\ \\mathrm{K}:\\quad PV = nRT = ${(R * v0).toFixed(2)}\\ \\mathrm{L\\,atm} \\;\\Rightarrow\\; P \\propto \\dfrac{1}{V}\\ (\\text{বয়েল})`, P: `P = ${v0.toFixed(2)}\\ \\mathrm{atm}:\\quad V = \\dfrac{nR}{P}T = ${(R / v0).toFixed(4)}\\,T \\;\\Rightarrow\\; V \\propto T\\ (\\text{চার্লস})`, V: `V = ${v0.toFixed(1)}\\ \\mathrm{L}:\\quad P = \\dfrac{nR}{V}T = ${(R / v0).toFixed(5)}\\,T \\;\\Rightarrow\\; P \\propto T\\ (\\text{গে-লুসাক})`}[sl]) +
        '<div class="small">পৃষ্ঠের প্রতিটি বিন্দু গ্যাসের একটি সম্ভাব্য অবস্থা; পৃষ্ঠের বাইরের কোনো (P, V, T) সমন্বয় আদর্শ গ্যাসের পক্ষে অসম্ভব। ছোট V ও উচ্চ T কোণে চাপ সবচেয়ে বেশি।</div>';
    };
    const A = X.anim(el, dt => { if (dt) { ph += dt * 0.9; if (!view.user) view.yaw += dt * 0.08; } draw(); }, { paused: false }); X.pp(el, A);
    C4.drag3d(c, view, () => A.draw());
    X.onSeg(el, 'sl', k => { sl = k; info(); A.draw(); });
    q('[data-s]').oninput = e => { s = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৩.৬ আদর্শ গ্যাস ক্যালকুলেটর ======================= */
const GM = [['H2', 'H₂', 2.016], ['He', 'He', 4.003], ['CH4', 'CH₄', 16.04], ['NH3', 'NH₃', 17.03], ['N2', 'N₂', 28.01], ['O2', 'O₂', 32.00], ['CO2', 'CO₂', 44.01], ['SO2', 'SO₂', 64.07], ['Cl2', 'Cl₂', 70.90]];
const PUN = { atm: 1, mmHg: 1 / 760, kPa: 1 / 101.325, bar: 1 / 1.01325 };
V.p2c1_idealCalc = {
  t: 'আদর্শ গ্যাস সমীকরণ ক্যালকুলেটর: P, V, T, n, ভর, মোলার ভর ও ঘনত্ব', k: ['calc', 'int', 'info'],
  cap: 'কোন রাশিটি অজানা তা বেছে নাও, বাকিগুলো একক সহ লেখো। ক্যালকুলেটর প্রথমে সব রাশি atm, L, K ও mol এ রূপান্তর করে, তারপর PV = nRT (R = ০.০৮২১ L atm mol⁻¹ K⁻¹) থেকে ধাপে ধাপে সমাধান দেখায় — পরীক্ষার খাতায় যেভাবে লিখতে হয়। গ্যাস বেছে নিলে মোলার ভর বসে যায়; "M নির্ণয়" বেছে নিলে ভর ও অবস্থা থেকে মোলার ভর বের করে সম্ভাব্য গ্যাস শনাক্ত করে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('u', [['P', 'P'], ['V', 'V'], ['T', 'T'], ['n', 'n / ভর'], ['M', 'M নির্ণয়'], ['d', 'ঘনত্ব']], 'P')}</div>
  <div class="grid2" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">
  <label class="small" data-f="P">চাপ P <span style="display:flex;gap:4px"><input type="number" step="any" value="1" data-P style="flex:1;min-width:0"><select data-Pu>${Object.keys(PUN).map(u => `<option>${u}</option>`).join('')}</select></span></label>
  <label class="small" data-f="V">আয়তন V <span style="display:flex;gap:4px"><input type="number" step="any" value="10" data-V style="flex:1;min-width:0"><select data-Vu><option>L</option><option>mL</option><option>m³</option></select></span></label>
  <label class="small" data-f="T">তাপমাত্রা <span style="display:flex;gap:4px"><input type="number" step="any" value="27" data-T style="flex:1;min-width:0"><select data-Tu><option>°C</option><option>K</option></select></span></label>
  <label class="small" data-f="m">ভর m (g) <input type="number" step="any" value="16" data-m style="width:100%"></label>
  <label class="small" data-f="g">গ্যাস (মোলার ভর) <select data-g style="width:100%">${GM.map(([k, n, M], i) => `<option value="${i}" ${k === 'O2' ? 'selected' : ''}>${n} (${M})</option>`).join('')}</select></label>
  </div><div class="calc-out" data-out></div>`,
  mount(el) {
    const out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    let un = 'P';
    const num = s => parseFloat(q(s).value);
    const calc = () => {
      ['P', 'V', 'T', 'm', 'g'].forEach(f => { const lab = q(`[data-f="${f}"]`); const hide = (un === 'P' && f === 'P') || (un === 'V' && f === 'V') || (un === 'T' && f === 'T') || (un === 'n' && f === 'm') || (un === 'M' && f === 'g') || (un === 'd' && (f === 'V' || f === 'm')); lab.style.opacity = hide ? 0.35 : 1; lab.querySelectorAll('input,select').forEach(i => { i.disabled = hide; }); });
      const pu = q('[data-Pu]').value, vu = q('[data-Vu]').value, tu = q('[data-Tu]').value;
      const P = num('[data-P]') * PUN[pu], Vl = num('[data-V]') * (vu === 'mL' ? 1e-3 : vu === 'm³' ? 1e3 : 1), T = tu === '°C' ? num('[data-T]') + 273.15 : num('[data-T]'), m = num('[data-m]'), gi = +q('[data-g]').value, M = GM[gi][2], n = m / M;
      const steps = [], ok = v => isFinite(v) && v > 0;
      if (pu !== 'atm' && un !== 'P') steps.push(`P = ${num('[data-P]')}\\ \\mathrm{${pu}} = ${P.toFixed(4)}\\ \\mathrm{atm}`);
      if (vu !== 'L' && un !== 'V' && un !== 'd') steps.push(`V = ${num('[data-V]')}\\ \\mathrm{${vu === 'm³' ? 'm^3' : vu}} = ${Vl.toPrecision(4)}\\ \\mathrm{L}`);
      if (tu === '°C' && un !== 'T') steps.push(`T = ${num('[data-T]')} + 273.15 = ${T.toFixed(2)}\\ \\mathrm{K}`);
      if (un !== 'n' && un !== 'M' && un !== 'd') steps.push(`n = \\dfrac{m}{M} = \\dfrac{${m}}{${M}} = ${n.toPrecision(4)}\\ \\mathrm{mol}`);
      let res = '', note = '';
      if (un === 'P') { const r = n * R * T / Vl; res = `P = \\dfrac{nRT}{V} = \\dfrac{${n.toPrecision(4)}\\times0.0821\\times${T.toFixed(2)}}{${Vl.toPrecision(4)}} = \\boxed{${r.toPrecision(4)}\\ \\mathrm{atm}} = ${(r * 760).toPrecision(4)}\\ \\mathrm{mmHg}`; if (!ok(r)) res = ''; }
      else if (un === 'V') { const r = n * R * T / P; res = `V = \\dfrac{nRT}{P} = \\dfrac{${n.toPrecision(4)}\\times0.0821\\times${T.toFixed(2)}}{${P.toPrecision(4)}} = \\boxed{${r.toPrecision(4)}\\ \\mathrm{L}}`; if (!ok(r)) res = ''; }
      else if (un === 'T') { const r = P * Vl / (n * R); res = `T = \\dfrac{PV}{nR} = \\dfrac{${P.toPrecision(4)}\\times${Vl.toPrecision(4)}}{${n.toPrecision(4)}\\times0.0821} = \\boxed{${r.toFixed(1)}\\ \\mathrm{K}} = ${(r - 273.15).toFixed(1)}\\,^\\circ\\mathrm{C}`; if (!ok(r)) res = ''; }
      else if (un === 'n') { const r = P * Vl / (R * T); res = `n = \\dfrac{PV}{RT} = \\dfrac{${P.toPrecision(4)}\\times${Vl.toPrecision(4)}}{0.0821\\times${T.toFixed(2)}} = \\boxed{${r.toPrecision(4)}\\ \\mathrm{mol}};\\quad m = nM = ${(r * M).toPrecision(4)}\\ \\mathrm{g};\\quad N = ${(r * 6.022e23).toExponential(3).replace('e+', '\\times10^{') + '}'}\\ \\text{অণু}`; if (!ok(r)) res = ''; }
      else if (un === 'M') { const r = m * R * T / (P * Vl); const best = GM.reduce((b, x) => Math.abs(x[2] - r) < Math.abs(b[2] - r) ? x : b); res = `M = \\dfrac{mRT}{PV} = \\dfrac{${m}\\times0.0821\\times${T.toFixed(2)}}{${P.toPrecision(4)}\\times${Vl.toPrecision(4)}} = \\boxed{${r.toPrecision(4)}\\ \\mathrm{g\\,mol^{-1}}}`; if (!ok(r)) res = ''; else note = Math.abs(best[2] - r) / r < 0.04 ? `সম্ভাব্য গ্যাস: <b>${best[1]}</b> (M = ${best[2]})।` : 'তালিকার কোনো গ্যাসের সাথে মেলে না।'; }
      else { const r = P * M / (R * T); res = `\\rho = \\dfrac{PM}{RT} = \\dfrac{${P.toPrecision(4)}\\times${M}}{0.0821\\times${T.toFixed(2)}} = \\boxed{${r.toPrecision(4)}\\ \\mathrm{g\\,L^{-1}}}`; if (!ok(r)) res = ''; else note = `একই অবস্থায় বায়ুর (M = ২৯) ঘনত্ব ${(P * 28.96 / (R * T)).toFixed(3)} g L⁻¹ — ${GM[gi][1]} বায়ুর চেয়ে ${M > 28.96 ? 'ভারী, নিচে জমে' : 'হালকা, উপরে ওঠে'}।`; }
      out.innerHTML = (steps.length ? steps.map(TXB).join('') : '') + (res ? TXB(res) : '<div class="small">ধনাত্মক সংখ্যা দাও।</div>') + (note ? `<div class="small">${note}</div>` : '');
    };
    X.onSeg(el, 'u', k => { un = k; calc(); });
    el.querySelectorAll('input,select').forEach(i => { i.oninput = calc; i.onchange = calc; });
    calc();
    return () => { };
  }
};

/* ======================= ১.৩.৭ ডাল্টনের আংশিক চাপ ======================= */
const DG = [['N2', 'N₂', 28.01], ['O2', 'O₂', 32.00], ['Ar', 'Ar', 39.95]];
const VP = [[0, 4.6], [10, 9.2], [15, 12.8], [20, 17.5], [25, 23.8], [27, 26.7], [30, 31.8], [35, 42.2], [37, 47.1], [40, 55.3], [50, 92.5], [60, 149.4], [70, 233.7], [80, 355.1], [90, 525.8], [100, 760]];
const vpAt = t => { for (let i = 1; i < VP.length; i++) if (t <= VP[i][0]) { const [a, pa] = VP[i - 1], [b, pb] = VP[i]; return pa * Math.pow(pb / pa, (t - a) / (b - a)); } return 760; };
V.p2c1_dalton = {
  t: 'ডাল্টনের আংশিক চাপ সূত্র: গ্যাস মিশ্রণে চাপের যোগফল এবং পানির উপর গ্যাস সংগ্রহ', k: ['anim', 'int', '2d', 'calc'],
  cap: '"মিশ্রণ" দৃশ্যে তিনটি ছোট পাত্রে আলাদাভাবে N₂, O₂ ও Ar — প্রত্যেকটির চাপ তার অণুর সংখ্যার সমানুপাতিক; ডানের বড় পাত্রে (একই আয়তন ও তাপমাত্রা) তিনটি একসাথে মেশালে মোট চাপ = আংশিক চাপের যোগফল (স্তূপীকৃত দণ্ড)। স্লাইডারে প্রতিটি গ্যাসের মোল বদলাও। "পানির উপর সংগ্রহ" দৃশ্যে গ্যাসজারে পানি অপসারণ করে O₂ সংগ্রহ: ভেতরে-বাইরে পানির তল সমান হলে বায়ুমণ্ডলীয় চাপ = শুষ্ক O₂ এর চাপ + জলীয় বাষ্পচাপ (f); তাপমাত্রা বাড়ালে f দ্রুত বাড়ে (বাষ্পচাপ লেখচিত্র)।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['mix', 'মিশ্রণ'], ['wat', 'পানির উপর সংগ্রহ']], 'mix')}</div>${X.cv('ডাল্টনের সূত্র')}<div class="ctl" data-mixc>${DG.map(([k, nm], i) => `<label class="small" style="flex:1;min-width:100px">${nm}: <b data-v${i}></b> mol <input type="range" min="0" max="4" step="0.5" value="${[2, 1, 0.5][i]}" data-n${i}></label>`).join('')}</div><div class="ctl" data-watc style="display:none"><label class="small" style="flex:1;min-width:140px">তাপমাত্রা = <b data-tv></b> °C <input type="range" min="0" max="80" step="1" value="27" data-t></label><label class="small" style="flex:1;min-width:140px">বায়ুচাপ = <b data-pv></b> mmHg <input type="range" min="720" max="780" step="1" value="760" data-p></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 500;
    let L = X.fit(c, hf), mode = 'mix', ns = [2, 1, 0.5], tc = 27, Pa = 760, t = 0;
    const sep = DG.map((d, i) => mkGas(16, 50 + i, [d[0]])), mix = mkGas(48, 77, ['N2']);
    const Vbox = 10, T = 300;
    const kinds = () => { const a = []; DG.forEach(([k], i) => { for (let j = 0; j < Math.round(ns[i] * 4); j++) a.push(k); }); return a; };
    const drawMix = (g, W, H, col) => {
      const wd = wide(W), ks = kinds(); mix.forEach((p, i) => { p.k = ks[i] || 'N2'; });
      const sw = wd ? 74 : (W - 60) / 3, sh = sw, sy = 30;
      const ps = ns.map(n => n * R * T / Vbox);
      DG.forEach(([k, nm], i) => { const x = wd ? 14 + i * (sw + 12) : 14 + i * (sw + 16); g.fillStyle = 'rgba(150,200,240,.12)'; g.fillRect(x, sy, sw, sh); g.strokeStyle = col.fg; g.lineWidth = 1.3; g.strokeRect(x, sy, sw, sh); drawGas(g, sep[i], { x: x + 3, y: sy + 3, w: sw - 6, h: sh - 6 }, 3.6, Math.round(ns[i] * 4)); g.fillStyle = (GCOL[k])[0]; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + sw / 2, sy - 8); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText(`p = ${fx(ps[i], 2)} atm`, x + sw / 2, sy + sh + 14); });
      const mx = wd ? 14 + 3 * (sw + 12) + 30 : W / 2 - 70, my = wd ? 30 : sy + sh + 60, mw = wd ? 140 : 140, mh = wd ? 140 : 140;
      if (wd) { g.fillStyle = col.fg; g.font = `bold 22px ${col.font}`; g.textAlign = 'center'; g.fillText('→', mx - 16, sy + sh / 2 + 8); }
      g.fillStyle = 'rgba(150,200,240,.12)'; g.fillRect(mx, my, mw, mh); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.strokeRect(mx, my, mw, mh);
      drawGas(g, mix, { x: mx + 3, y: my + 3, w: mw - 6, h: mh - 6 }, 4, ks.length);
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('মিশ্রণ (একই V, T)', mx + mw / 2, my - 8);
      // stacked bar
      const bx = wd ? mx + mw + 40 : 70, by = wd ? 24 : my + mh + 40, bw = wd ? 46 : W - 140, bh = wd ? H - 60 : 46, Ptot = ps.reduce((a, b) => a + b, 0), Pmax = 10;
      if (wd) { let y = by + bh; ps.forEach((p, i) => { const hh = p / Pmax * bh; g.fillStyle = GCOL[DG[i][0]][0]; g.fillRect(bx, y - hh, bw, hh); if (hh > 14) { g.fillStyle = '#fff'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(DG[i][1], bx + bw / 2, y - hh / 2 + 3); } y -= hh; }); g.strokeStyle = col.fg; g.strokeRect(bx, by, bw, bh); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`P = ${fx(Ptot, 2)} atm`, bx + bw + 6, by + bh - Ptot / Pmax * bh + 4); g.font = `9px ${col.font}`; g.fillStyle = col.mu; g.fillText(`০–${bn(Pmax)} atm`, bx, by - 6); }
      else { let x = bx; ps.forEach((p, i) => { const ww = p / Pmax * bw; g.fillStyle = GCOL[DG[i][0]][0]; g.fillRect(x, by, ww, bh); if (ww > 22) { g.fillStyle = '#fff'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(DG[i][1], x + ww / 2, by + bh / 2 + 3); } x += ww; }); g.strokeStyle = col.fg; g.strokeRect(bx, by, bw, bh); g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(`মোট চাপ P = ${fx(Ptot, 2)} atm (স্কেল ০–${bn(Pmax)})`, W / 2, by + bh + 18); }
    };
    const drawWat = (g, W, H, col) => {
      const wd = wide(W), f = vpAt(tc), pO2 = Pa - f;
      // trough
      const tx = wd ? 20 : 20, tw = wd ? W * 0.5 : W - 40, ty = wd ? 150 : 170, th = 110;
      g.fillStyle = 'rgba(80,150,220,.28)'; g.fillRect(tx, ty, tw, th); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(tx, ty - 30); g.lineTo(tx, ty + th); g.lineTo(tx + tw, ty + th); g.lineTo(tx + tw, ty - 30); g.stroke();
      // jar inverted
      const jx = tx + tw * 0.55, jw = 70, jt = 30, jb = ty + 70;
      g.fillStyle = 'rgba(80,150,220,.28)'; g.fillRect(jx, ty, jw, jb - ty);
      g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(jx, jt, jw, ty - jt);
      const box = { x: jx + 3, y: jt + 8, w: jw - 6, h: ty - jt - 10 }; mix.slice(0, 22).forEach((p, i) => { p.k = i < Math.round(22 * f / Pa * 4) ? 'H2O' : 'O2'; }); drawGas(g, mix, box, 3.6, 22);
      g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(jx, jb); g.lineTo(jx, jt + 10); g.quadraticCurveTo(jx, jt, jx + 10, jt); g.lineTo(jx + jw - 10, jt); g.quadraticCurveTo(jx + jw, jt, jx + jw, jt + 10); g.lineTo(jx + jw, jb); g.stroke();
      g.strokeStyle = '#2d6fd6'; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(tx, ty); g.lineTo(tx + tw, ty); g.stroke(); g.setLineDash([]); g.fillStyle = '#2d6fd6'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('ভেতরে-বাইরে পানির তল সমান', tx + 4, ty - 4);
      // delivery tube + flask
      const fxp = tx + 34, fyp = ty + th - 24; g.strokeStyle = col.fg; g.lineWidth = 3; g.beginPath(); g.moveTo(tx - 6, ty - 50); g.lineTo(tx + 26, ty - 50); g.lineTo(tx + 26, jb + 22); g.lineTo(jx + jw / 2, jb + 22); g.lineTo(jx + jw / 2, jb - 6); g.stroke();
      for (let k = 0; k < 4; k++) { const by = jb - 6 - ((t * 40 + k * 18) % 60); if (by > ty - 4) { g.fillStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.arc(jx + jw / 2 + Math.sin(t * 5 + k) * 3, by, 3, 0, 7); g.fill(); } }
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('O₂ + জলীয় বাষ্প', jx + jw / 2, jt - 6);
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('← KClO₃ (Δ) থেকে O₂', tx - 4, ty - 56);
      thermo(g, col, tx + tw - 22, ty - 10, 90, tc / 90, `${bn(tc)} °C`);
      // stacked bar P
      const bx = wd ? W * 0.6 : 50, by = wd ? 30 : ty + th + 40, bw = wd ? 44 : W - 100, bh = wd ? 160 : 40;
      if (wd) { const sc = bh / 780; g.fillStyle = '#c0392b'; g.fillRect(bx, by + bh - pO2 * sc, bw, pO2 * sc); g.fillStyle = '#3b8fd0'; g.fillRect(bx, by + bh - Pa * sc, bw, f * sc); g.strokeStyle = col.fg; g.strokeRect(bx, by, bw, bh); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`f = ${fx(f, 1)} mmHg`, bx + bw + 6, by + bh - Pa * sc + 10); g.fillText(`p(O₂) = ${fx(pO2, 1)}`, bx + bw + 6, by + bh - pO2 * sc / 2); g.font = `bold 10px ${col.font}`; g.fillText(`P = ${bn(Pa)} mmHg`, bx + bw + 6, by + bh - Pa * sc - 4); }
      else { const sc = bw / 780; g.fillStyle = '#c0392b'; g.fillRect(bx, by, pO2 * sc, bh); g.fillStyle = '#3b8fd0'; g.fillRect(bx + pO2 * sc, by, f * sc, bh); g.strokeStyle = col.fg; g.strokeRect(bx, by, bw, bh); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(`p(O₂) = ${fx(pO2, 1)} + f = ${fx(f, 1)} = ${bn(Pa)} mmHg`, W / 2, by + bh + 16); }
      // VP curve
      const gx0 = wd ? W * 0.6 + 10 : 60, gy0 = wd ? by + bh + 50 : by + bh + 60, gw = wd ? W - gx0 - 70 : W - 90, gh = wd ? H - gy0 - 36 : H - gy0 - 40;
      if (gh > 40) { const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 80, ymax: 400, col, xt: [0, 20, 40, 60, 80], yt: [0, 200, 400], xl: 't (°C)', yl: 'f (mmHg)', ylx: 30 }); const pts = []; for (let x = 0; x <= 80; x++) pts.push([Pl.X(x), Pl.Y(vpAt(x))]); path(g, pts, '#3b8fd0', 2.4); ball(g, Pl.X(tc), Pl.Y(f), 5, '#c0392b', '#ffb3a8'); }
    };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); if (mode === 'mix') drawMix(g, W, H, col); else drawWat(g, W, H, col); };
    const info = () => {
      if (mode === 'mix') { ns.forEach((n, i) => { q(`[data-v${i}]`).textContent = fx(n, 1); }); const nt = ns.reduce((a, b) => a + b, 0), ps = ns.map(n => n * R * T / Vbox), Pt = nt * R * T / Vbox;
        out.innerHTML = TXB(`p_i = \\dfrac{n_iRT}{V}`) + TXB(`${ps.map((p, i) => `p_{\\ce{${DG[i][0]}}} = ${p.toFixed(2)}`).join(',\\ ')}\\ \\mathrm{atm}`) + TXB(`P = ${ps.map(p => p.toFixed(2)).join(' + ')} = ${Pt.toFixed(2)}\\ \\mathrm{atm} = \\dfrac{n_{\\text{মোট}}RT}{V}`) + (nt > 0 ? TXB(`x_{\\ce{O2}} = \\dfrac{${ns[1]}}{${nt}} = ${(ns[1] / nt).toFixed(3)}`) + TXB(`p_{\\ce{O2}} = x_{\\ce{O2}}P = ${(ns[1] / nt * Pt).toFixed(2)}\\ \\mathrm{atm}`) : '') + '<div class="small">V = ১০ L, T = ৩০০ K। প্রতিটি গ্যাস এমনভাবে চাপ দেয় যেন অন্যরা নেই — কারণ আদর্শ গ্যাসের অণুর মধ্যে আকর্ষণ-বিকর্ষণ নেই।</div>'; }
      else { const f = vpAt(tc), pO2 = Pa - f; q('[data-tv]').textContent = bn(tc); q('[data-pv]').textContent = bn(Pa); const V0 = 250 * pO2 / 760 * 273 / (tc + 273);
        out.innerHTML = TXB(`p_{\\ce{O2}} = P - f = ${Pa} - ${f.toFixed(1)} = ${pO2.toFixed(1)}\\ \\mathrm{mmHg}`) + TXB(`250\\ \\mathrm{mL}\\ \\text{সংগৃহীত হলে: } V_0 = 250\\times\\dfrac{${pO2.toFixed(1)}}{760}\\times\\dfrac{273}{${tc + 273}} = ${V0.toFixed(1)}\\ \\mathrm{mL\\ (STP,\\ শুষ্ক)}`) + `<div class="small">বাষ্পচাপ উপেক্ষা করলে ত্রুটি ${(f / Pa * 100).toFixed(1)}%। ${tc > 60 ? 'উচ্চ তাপমাত্রায় সংগৃহীত গ্যাসের বড় অংশই জলীয় বাষ্প!' : ''}</div>`; }
    };
    const setMode = m => { mode = m; q('[data-mixc]').style.display = m === 'mix' ? '' : 'none'; q('[data-watc]').style.display = m === 'wat' ? '' : 'none'; info(); A.draw(); };
    const A = X.anim(el, dt => { if (dt) { t += dt; sep.forEach((G, i) => stepGas(G, dt, 0.5, 0.02, Math.round(ns[i] * 4))); stepGas(mix, dt, 0.45, 0.02, mode === 'mix' ? kinds().length : 22); } draw(); }, { paused: false });
    X.onSeg(el, 'm', setMode);
    DG.forEach((d, i) => { q(`[data-n${i}]`).oninput = e => { ns[i] = +e.target.value; info(); A.draw(); }; });
    q('[data-t]').oninput = e => { tc = +e.target.value; info(); A.draw(); };
    q('[data-p]').oninput = e => { Pa = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৩.৮ গ্রাহাম: NH₃–HCl নল ======================= */
const PAIRS = { hcl: ['NH3', 'NH₃', 17.03, 'HCl', 'HCl', 36.46, 'NH₄Cl'], hbr: ['NH3', 'NH₃', 17.03, 'HBr', 'HBr', 80.91, 'NH₄Br'], mea: ['X', 'CH₃NH₂', 31.06, 'HCl', 'HCl', 36.46, 'CH₃NH₃Cl'] };
V.p2c1_graham = {
  t: 'গ্রাহামের ব্যাপন সূত্র: NH₃–HCl কাচনলে সাদা বলয় গঠন (অণু-সিমুলেশন)', k: ['anim', 'int', '2d', 'calc'],
  cap: '১০০ cm কাচনলের বাম প্রান্তে ক্ষারক (নীল) ও ডান প্রান্তে এসিড (সবুজ) গ্যাস একসাথে ছাড়া হয়। অণুগুলো বায়ুর অণুর সাথে ধাক্কা খেয়ে এলোমেলো পথে এগোয় (ব্যাপন); হালকা অণুর গড় বেগ বেশি, তাই তার "ব্যাপন সম্মুখ" দ্রুত এগোয়। দুই সম্মুখ যেখানে মেলে সেখানে কঠিন লবণের সাদা বলয় জমে। নিচের স্কেলে গ্রাহামের সূত্রে পূর্বাভাসিত অবস্থান (লাল ত্রিভুজ)। গ্যাস-জোড় বদলে দেখো: HBr আরও ভারী, তাই বলয় তার প্রান্তের আরও কাছে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('pr', [['hcl', 'NH₃ + HCl'], ['hbr', 'NH₃ + HBr'], ['mea', 'CH₃NH₂ + HCl']], 'hcl')}</div>${X.cv('গ্রাহামের NH3-HCl নল')}<div class="ctl"><button class="btn sm" data-go>আবার শুরু</button><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 250 : 300;
    let L = X.fit(c, hf), pr = 'hcl', t = 0, ring = null, ringA = 0;
    let A_ = [], B_ = []; const rnd = Math.random;
    const reset = () => { A_ = []; B_ = []; t = 0; ring = null; ringA = 0; for (let i = 0; i < 70; i++) { A_.push({ x: rnd() * 2, y: rnd(), born: rnd() * 3 }); B_.push({ x: 100 - rnd() * 2, y: rnd(), born: rnd() * 3 }); } };
    reset();
    const pred = () => { const p = PAIRS[pr], r = Math.sqrt(p[5] / p[2]); return 100 * r / (1 + r); };
    const step = dt => {
      t += dt; const p = PAIRS[pr], D0 = 140; // cm^2/s scaled
      const DA = D0 / Math.sqrt(p[2]), DB = D0 / Math.sqrt(p[5]);
      const mv = (arr, D, dir) => arr.forEach(m => { if (m.dead || t < m.born) return; const s = Math.sqrt(2 * D * dt); m.x += (rnd() * 2 - 1) * s * 1.7 + dir * D * dt * 0.02; m.y = Math.max(0.05, Math.min(0.95, m.y + (rnd() * 2 - 1) * 0.06)); if (m.x < 0) m.x = -m.x; if (m.x > 100) m.x = 200 - m.x; });
      mv(A_, DA, 1); mv(B_, DB, -1);
      // react when fronts meet
      const fa = A_.filter(m => !m.dead && t >= m.born).map(m => m.x).sort((a, b) => b - a), fb = B_.filter(m => !m.dead && t >= m.born).map(m => m.x).sort((a, b) => a - b);
      if (fa.length > 6 && fb.length > 6) { const fA = fa[5], fB = fb[5]; if (fA >= fB && !ring) ring = (fA + fB) / 2; }
      if (ring != null) { A_.forEach(m => { if (!m.dead && Math.abs(m.x - ring) < 3) { const b = B_.find(n => !n.dead && Math.abs(n.x - ring) < 3); if (b) { m.dead = b.dead = true; ringA = Math.min(1, ringA + 0.03); } } }); ringA = Math.min(1, ringA + dt * 0.08); }
      // replenish sources
      A_.forEach(m => { if (m.dead && rnd() < 0.02) { m.dead = false; m.x = rnd() * 2; m.born = t; } }); B_.forEach(m => { if (m.dead && rnd() < 0.02) { m.dead = false; m.x = 100 - rnd() * 2; m.born = t; } });
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const p = PAIRS[pr];
      const x0 = 46, x1 = W - 46, ty = 70, th = 46, Xc = v => x0 + v / 100 * (x1 - x0);
      // tube
      const gr = g.createLinearGradient(0, ty, 0, ty + th); gr.addColorStop(0, 'rgba(255,255,255,.35)'); gr.addColorStop(0.3, 'rgba(180,215,240,.12)'); gr.addColorStop(1, 'rgba(120,160,200,.2)');
      g.fillStyle = gr; g.fillRect(x0, ty, x1 - x0, th); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.strokeRect(x0, ty, x1 - x0, th);
      // cotton plugs
      [[x0 - 18, '#cfe0ff', p[1]], [x1, '#c8f0cf', p[4]]].forEach(([x, cc, nm]) => { g.fillStyle = cc; g.beginPath(); g.roundRect ? g.roundRect(x, ty - 4, 18, th + 8, 6) : g.rect(x, ty - 4, 18, th + 8); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1; g.stroke(); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + 9, ty - 12); });
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('ভেজা তুলা', x0 - 9, ty + th + 18); g.fillText('ভেজা তুলা', x1 + 9, ty + th + 18);
      // ring
      if (ring != null) { const rx = Xc(ring); const rg = g.createLinearGradient(rx - 12, 0, rx + 12, 0); rg.addColorStop(0, 'rgba(255,255,255,0)'); rg.addColorStop(0.5, `rgba(250,250,250,${0.95 * ringA})`); rg.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = rg; g.fillRect(rx - 12, ty + 1, 24, th - 2); g.strokeStyle = `rgba(120,120,120,${0.6 * ringA})`; g.lineWidth = 1; g.strokeRect(rx - 5, ty + 1, 10, th - 2); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.fillText(`${p[6]} বলয়`, rx, ty + th + 32); }
      // molecules
      const ca = GCOL[p[0]] || GCOL.NH3, cb = GCOL[p[3]];
      A_.forEach(m => { if (!m.dead && t >= m.born) ball(g, Xc(m.x), ty + 5 + m.y * (th - 10), 3.2, ca[0], ca[1]); });
      B_.forEach(m => { if (!m.dead && t >= m.born) ball(g, Xc(m.x), ty + 5 + m.y * (th - 10), 3.8, cb[0], cb[1]); });
      // ruler
      const ry = ty + th + 46; g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(x0, ry); g.lineTo(x1, ry); g.stroke(); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center';
      for (let v = 0; v <= 100; v += 10) { g.beginPath(); g.moveTo(Xc(v), ry); g.lineTo(Xc(v), ry + (v % 50 ? 4 : 8)); g.stroke(); if (v % 20 === 0 || v === 50) g.fillText(bn(v), Xc(v), ry + 18); }
      const pv = pred(); g.fillStyle = '#c0392b'; g.beginPath(); g.moveTo(Xc(pv), ry - 2); g.lineTo(Xc(pv) - 6, ry - 12); g.lineTo(Xc(pv) + 6, ry - 12); g.fill(); g.font = `bold 9.5px ${col.font}`; g.fillText(`পূর্বাভাস ${fx(pv, 1)} cm`, Xc(pv), ry - 16);
      g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`t = ${fx(t, 1)} s (সিমুলেশন সময়)`, 10, 18);
      g.textAlign = 'center'; g.fillStyle = ca[0]; g.font = `bold 10px ${col.font}`; g.fillText(`${p[1]} (M = ${p[2]}) →`, Xc(18), 46); g.fillStyle = cb[0]; g.fillText(`← ${p[4]} (M = ${p[5]})`, Xc(82), 46);
    };
    const info = () => { const p = PAIRS[pr], r = Math.sqrt(p[5] / p[2]), d = pred();
      out.innerHTML = TXB(`\\dfrac{r_{\\ce{${{ NH3: 'NH3', X: 'CH3NH2' }[p[0]]}}}}{r_{\\ce{${p[3]}}}} = \\sqrt{\\dfrac{${p[5]}}{${p[2]}}} = ${r.toFixed(3)}`) + TXB(`d_{\\text{বাম}} = \\dfrac{${r.toFixed(3)}}{1 + ${r.toFixed(3)}}\\times100 = ${d.toFixed(1)}\\ \\mathrm{cm};\\quad d_{\\text{ডান}} = ${(100 - d).toFixed(1)}\\ \\mathrm{cm}`) + `<div class="small">একই সময়ে দুই গ্যাস যে দূরত্ব যায় তা তাদের ব্যাপন হারের অনুপাতে। বাস্তব পরীক্ষায় বায়ুর অণু ও তুলার বাষ্পচাপের পার্থক্যের জন্য বলয় পূর্বাভাসের চেয়ে সামান্য সরে থাকতে পারে।</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.03)); draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'pr', k => { pr = k; reset(); info(); A.draw(); });
    q('[data-go]').onclick = () => { reset(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৩.৮ অনুব্যাপন: ছিদ্র দিয়ে গ্যাস বের হওয়া ======================= */
const EPAIR = { hho: ['H2', 'H₂', 2.016, 'O2', 'O₂', 32.00], hen: ['He', 'He', 4.003, 'N2', 'N₂', 28.01], uf6: ['NH3', '²³⁵UF₆', 349.0, 'CO2', '²³⁸UF₆', 352.0] };
V.p2c1_effusion = {
  t: 'অনুব্যাপন: ক্ষুদ্র ছিদ্র দিয়ে গ্যাস মিশ্রণ বের হওয়া ও হারের অনুপাত √(M₂/M₁)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বাম পাত্রে দুই গ্যাসের সমমোল মিশ্রণ, মাঝের দেয়ালে একটি অতি ক্ষুদ্র ছিদ্র, ডানে শূন্যস্থান। অণুগুলো নিজ নিজ গড় বেগে ছোটে (হালকা অণু দ্রুত — বেগ ∝ 1/√M) এবং ছিদ্রে পৌঁছালে বেরিয়ে যায়। নিচের লেখচিত্রে সময়ের সাথে বের হওয়া অণুর সংখ্যা: দুই রেখার ঢালের অনুপাত গ্রাহামের পূর্বাভাস √(M₂/M₁) এর কাছাকাছি। "²³⁵UF₆/²³⁸UF₆" বেছে দেখো — পার্থক্য মাত্র ০.৪৩%, তাই সমৃদ্ধকরণে হাজারো ধাপ লাগে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('ep', [['hho', 'H₂ / O₂'], ['hen', 'He / N₂'], ['uf6', '²³⁵UF₆ / ²³⁸UF₆']], 'hho')}</div>${X.cv('অনুব্যাপন')}<div class="ctl"><button class="btn sm" data-go>আবার শুরু</button><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 520;
    let L = X.fit(c, hf), ep = 'hho', t = 0, cnt = [0, 0], hist = [], G = [];
    const N = 120;
    const reset = () => { const p = EPAIR[ep]; G = mkGas(N, 99, [p[0], p[3]]); G.forEach((m, i) => { m.x *= 0.95; m.out = false; const M = i % 2 ? p[5] : p[2], v = 1 / Math.sqrt(M / 2.016); m.vx *= v; m.vy *= v; }); cnt = [0, 0]; hist = [[0, 0, 0]]; t = 0; };
    reset();
    const scale = () => { const p = EPAIR[ep]; return ep === 'uf6' ? 1 / Math.sqrt(349 / 2.016) : 1; };
    const step = dt => {
      const sp = 0.9 / scale() * (ep === 'uf6' ? 0.6 : 1); t += dt;
      G.forEach((m, i) => { if (m.out) { m.x += m.vx * dt * sp * 0.5; if (m.x > 1.9) m.x = 1.9; return; } m.x += m.vx * dt * sp; m.y += m.vy * dt * sp; if (m.y < 0.02) { m.y = 0.02; m.vy = Math.abs(m.vy); } if (m.y > 0.98) { m.y = 0.98; m.vy = -Math.abs(m.vy); } if (m.x < 0.02) { m.x = 0.02; m.vx = Math.abs(m.vx); } if (m.x > 0.98) { if (Math.abs(m.y - 0.5) < 0.06) { m.out = true; m.vx = Math.abs(m.vx); cnt[i % 2]++; } else { m.x = 0.98; m.vx = -Math.abs(m.vx); } } });
      if (!hist.length || t - hist[hist.length - 1][0] > 0.25) hist.push([t, cnt[0], cnt[1]]);
      if (cnt[0] + cnt[1] > N * 0.9 || t > 60) { /* hold */ }
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const p = EPAIR[ep], wd = wide(W);
      const bx = 20, by = 26, bw = wd ? W * 0.24 : (W - 60) / 2, bh = wd ? 150 : 150;
      g.fillStyle = 'rgba(150,200,240,.12)'; g.fillRect(bx, by, bw, bh); g.fillStyle = 'rgba(128,128,128,.05)'; g.fillRect(bx + bw + 6, by, bw, bh);
      g.strokeStyle = col.fg; g.lineWidth = 1.6; g.strokeRect(bx, by, bw * 2 + 6, bh); g.fillStyle = col.fg; g.fillRect(bx + bw, by, 6, bh * 0.44); g.fillRect(bx + bw, by + bh * 0.56, 6, bh * 0.44);
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('মিশ্রণ', bx + bw / 2, by - 8); g.fillText('শূন্যস্থান', bx + bw * 1.5 + 6, by - 8); g.fillStyle = '#c0392b'; g.fillText('ছিদ্র', bx + bw + 3, by + bh + 14);
      G.forEach((m, i) => { const k = i % 2 ? p[3] : p[0], cc = GCOL[k], x = m.out ? bx + bw + 6 + (m.x - 1) * bw : bx + m.x * bw, r = i % 2 ? 4.2 : 3.2; ball(g, Math.min(bx + 2 * bw + 2, x), by + m.y * bh, r, cc[0], cc[1]); });
      // legend
      [[p[0], p[1]], [p[3], p[4]]].forEach(([k, nm], i) => { const lx = bx + i * 110, ly = by + bh + 30; ball(g, lx + 6, ly - 4, 5, GCOL[k][0], GCOL[k][1]); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`${nm}: ${bn(cnt[i])} বের`, lx + 15, ly); });
      // chart
      const gx0 = wd ? bx + 2 * bw + 60 : 56, gy0 = wd ? 30 : by + bh + 70, gw = wd ? W - gx0 - 20 : W - 76, gh = wd ? H - 80 : H - gy0 - 44;
      const tm = Math.max(10, t), ym = N / 2;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: tm, ymax: ym, col, xt: [0, tm / 2, tm].map(v => +v.toFixed(0)), yt: [0, ym / 2, ym], xl: 'সময়', yl: 'বের হওয়া অণু', ylx: 30 });
      [[1, p[0]], [2, p[3]]].forEach(([j, k]) => path(g, hist.map(h => [Pl.X(h[0]), Pl.Y(h[j])]), GCOL[k][0], 2.4));
    };
    const info = () => { const p = EPAIR[ep], pr = Math.sqrt(p[5] / p[2]); const early = hist.find(h => h[1] + h[2] >= 30) || hist[hist.length - 1]; const obs = early[2] > 0 ? early[1] / early[2] : null;
      out.innerHTML = TXB(`\\dfrac{r_1}{r_2} = \\sqrt{\\dfrac{M_2}{M_1}} = \\sqrt{\\dfrac{${p[5]}}{${p[2]}}} = ${pr.toFixed(ep === 'uf6' ? 4 : 3)}`) + `<div class="small">সিমুলেশনে প্রথম ৩০টি অণুর মধ্যে অনুপাত: <b>${obs ? fx(obs, 2) : '—'}</b> (পরিসংখ্যানগত ওঠানামা থাকবে)। ${ep === 'uf6' ? 'প্রতি ধাপে ²³⁵U এর অনুপাত মাত্র ১.০০৪৩ গুণ বাড়ে; প্রাকৃতিক ০.৭২% থেকে চুল্লির জ্বালানির ~৪% এ নিতে কয়েকশো থেকে হাজারের বেশি ধাপ লাগে (এখন অধিকাংশ ক্ষেত্রে সেন্ট্রিফিউজ ব্যবহৃত হয়)।' : 'হালকা গ্যাস আগে বের হয় — প্রথম দিকে বের হওয়া অংশে হালকা গ্যাস সমৃদ্ধ।'}</div>`; };
    let ti = 0;
    const A = X.anim(el, dt => { if (dt) { step(Math.min(dt, 0.03)); ti += dt; if (ti > 0.5) { ti = 0; info(); } } draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'ep', k => { ep = k; reset(); info(); A.draw(); });
    q('[data-go]').onclick = () => { reset(); info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
