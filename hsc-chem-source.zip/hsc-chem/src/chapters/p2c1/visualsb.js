/* ২য় পত্র অধ্যায় ১ visuals part 11 — acid rain scene, rain pH calculator, risk-map tool (1.13) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
/* universal indicator colour for pH */
const UI = [[1, [200, 30, 30]], [3, [240, 90, 30]], [4.5, [245, 160, 30]], [5.6, [235, 215, 40]], [7, [70, 180, 60]], [8.5, [40, 140, 170]], [10, [50, 70, 190]], [12, [100, 40, 150]]];
const pHcol = (p, a = 1) => { for (let i = 1; i < UI.length; i++) if (p <= UI[i][0]) { const [x0, c0] = UI[i - 1], [x1, c1] = UI[i], u = Math.max(0, Math.min(1, (p - x0) / (x1 - x0))); return `rgba(${c0.map((v, k) => Math.round(v + (c1[k] - v) * u)).join(',')},${a})`; } return `rgba(100,40,150,${a})`; };
/* charge-balance rain pH: h^2 - (2s+n)h - (K1*KH*p + Kw) = 0 ; s, n in mol/L */
const KH = 3.3e-2, K1 = 4.45e-7, KW = 1e-14;
const rainPH = (ppm, s, n, nh = 0) => { const a = 2 * s + n - nh, c = K1 * KH * ppm * 1e-6 + KW; const h = (a + Math.sqrt(a * a + 4 * c)) / 2; return { h, pH: -Math.log10(h), hco3: K1 * KH * ppm * 1e-6 / h }; };

/* ======================= এসিড বৃষ্টির দৃশ্য ======================= */
V.p2c1_acidRain = {
  t: 'এসিড বৃষ্টির পূর্ণ চক্র: কারখানা ও যানবাহনের SO₂/NOx → মেঘে H₂SO₄/HNO₃ → অম্লীয় বৃষ্টি → মার্বেল, বন ও হ্রদে প্রভাব (অ্যানিমেশন)', k: ['anim', 'int', '2d'],
  cap: 'বাম দিকে কয়লা বিদ্যুৎকেন্দ্র (হলুদ SO₂) ও যানবাহন (বাদামি NOx) থেকে গ্যাস বাতাসে ডান দিকে ভেসে মেঘে ঢোকে; মেঘের ভেতরে এসিড তৈরি হয়ে বৃষ্টির ফোঁটা সর্বজনীন নির্দেশকের রং পায় (হলুদ-সবুজ = স্বাভাবিক ৫.৬, কমলা-লাল = অম্লীয়)। ডানে তিনটি লক্ষ্য: মার্বেলের মূর্তি ক্ষয় হয়, গাছের পাতা বাদামি হয়, আর হ্রদের pH নামে। "নির্গমন" স্লাইডার ও "হ্রদের তলদেশ" (গ্রানাইট/চুনাপাথর) বদলে দেখো — চুনাপাথরের হ্রদ বাফারের কারণে প্রায় নিরপেক্ষ থাকে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('bed', [['gr', 'হ্রদের তলদেশ: গ্রানাইট'], ['ls', 'চুনাপাথর']], 'gr')}</div>${X.cv('এসিড বৃষ্টি')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:150px">SO₂ + NOx নির্গমন = <b data-ev></b>%<input type="range" min="0" max="150" step="5" value="100" data-e></label><button class="btn sm" data-scrub>স্ক্রাবার বসাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 400;
    let L = X.fit(c, hf), em = 100, scrub = false, bed = 'gr', t = 0, erosion = 0, leafDmg = 0, lakePH = 6.8; const Rn = X.rng(41); let G = [], D = [];
    const eff = () => em / 100 * (scrub ? 0.1 : 1);
    const rain = () => rainPH(420, 3.0e-5 * eff(), 1.5e-5 * eff()).pH;
    const step = dt => { t += dt; const { W, H } = L, e = eff();
      if (Rn() < dt * 14 * Math.max(0.05, em / 100)) G.push({ k: Rn() < 0.6 ? 'S' : 'N', x: Rn() < 0.6 ? 0.12 : 0.24, y: Rn() < 0.6 ? 0.42 : 0.78, sc: scrub && Rn() < 0.9 ? 1 : 0, age: 0 });
      G.forEach(p => { p.age += dt; p.x += dt * 0.06; p.y += (0.2 - p.y) * dt * 0.5; if (p.sc) p.dead = p.age > 0.6; if (p.x > 0.45 && p.y < 0.28) p.dead = true; }); G = G.filter(p => !p.dead && p.x < 1);
      if (Rn() < dt * 40) D.push({ x: 0.4 + Rn() * 0.55, y: 0.2, v: 0.5 + Rn() * 0.3 }); D.forEach(d => { d.y += d.v * dt; }); D = D.filter(d => d.y < 0.84);
      const pr = rain(), acid = Math.max(0, 5.6 - pr); erosion = Math.min(1, erosion + dt * acid * 0.02); leafDmg += ((acid / 1.8) - leafDmg) * dt * 0.3;
      const target = bed === 'ls' ? 7.6 - acid * 0.15 : Math.max(pr + 0.1, 6.8 - acid * 1.4); lakePH += (target - lakePH) * dt * 0.4; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), pr = rain(), gy = H * 0.84;
      const sky = g.createLinearGradient(0, 0, 0, gy); sky.addColorStop(0, '#5a6680'); sky.addColorStop(1, '#b8c6d8'); g.fillStyle = sky; g.fillRect(0, 0, W, gy);
      // cloud
      const cl = g.createLinearGradient(0, H * 0.08, 0, H * 0.28); cl.addColorStop(0, '#d6dbe4'); cl.addColorStop(1, '#8a93a6'); g.fillStyle = cl; [[0.45, 0.17, 30], [0.55, 0.13, 38], [0.66, 0.15, 34], [0.77, 0.12, 40], [0.88, 0.16, 32], [0.6, 0.21, 30], [0.8, 0.21, 30]].forEach(([x, y, r]) => { g.beginPath(); g.arc(x * W, y * H, r * (wd ? 1 : 0.7), 0, 7); g.fill(); });
      g.fillStyle = pHcol(pr, 0.9); g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(wd ? 'মেঘে: SO₂ → H₂SO₄, NO₂ → HNO₃' : 'H₂SO₄, HNO₃', 0.66 * W, 0.17 * H);
      // ground
      g.fillStyle = '#6b8e4e'; g.fillRect(0, gy, W, H - gy);
      // power plant
      const px = 0.1 * W; g.fillStyle = '#7d8590'; g.fillRect(px - 20, gy - 40, 40, 40); g.fillStyle = '#9aa2ad'; g.fillRect(px + 4, gy - (H * 0.42 > 0 ? gy - H * 0.42 : 80), 10, gy - H * 0.42); g.fillStyle = scrub ? '#2f9e44' : '#c0392b'; g.fillRect(px + 4, H * 0.42, 10, 4);
      if (scrub) { g.fillStyle = 'rgba(255,255,255,.9)'; rr(g, px - 34, gy - 58, 30, 16, 4); g.fill(); g.fillStyle = '#2f9e44'; g.font = `bold 8px ${col.font}`; g.fillText('FGD', px - 19, gy - 47); }
      // road + cars
      g.fillStyle = '#555'; g.fillRect(0.16 * W, gy - 4, 0.16 * W, 4); for (let k = 0; k < 3; k++) { const cx = 0.16 * W + ((t * 30 + k * 30) % (0.16 * W)); g.fillStyle = ['#c0392b', '#2d6fd6', '#e0a020'][k]; g.fillRect(cx, gy - 10, 12, 6); }
      // gas particles
      G.forEach(p => { const x = p.x * W, y = p.y * H; ball(g, x, y, 2.6, p.k === 'S' ? '#d6b21e' : '#a8541e', p.k === 'S' ? '#fff2a8' : '#ffc9a0'); });
      // drops
      D.forEach(d => { const x = d.x * W, y = d.y * H; g.fillStyle = pHcol(pr, 0.9); g.beginPath(); g.moveTo(x, y - 5); g.quadraticCurveTo(x + 3, y + 1, x, y + 2.5); g.quadraticCurveTo(x - 3, y + 1, x, y - 5); g.fill(); });
      // statue
      const sx = wd ? 0.5 * W : 0.47 * W; const er = erosion; g.fillStyle = `rgb(${235 - 40 * er},${232 - 50 * er},${225 - 70 * er})`; g.fillRect(sx - 14, gy - 12, 28, 12); g.beginPath(); g.ellipse(sx, gy - 34, 9 - er * 2, 20 - er * 3, 0, 0, 7); g.fill(); g.beginPath(); g.arc(sx, gy - 58 + er * 4, 7 - er * 1.5, 0, 7); g.fill(); if (er > 0.2) { g.fillStyle = 'rgba(60,60,60,.5)'; for (let k = 0; k < 8 * er; k++) g.fillRect(sx - 6 + (k * 5) % 12, gy - 40 + (k * 7) % 25, 2, 2); }
      g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('মার্বেল', sx, H - 4);
      // trees
      const tx = wd ? 0.66 * W : 0.66 * W; for (let k = 0; k < 2; k++) { const x = tx + k * 22; g.fillStyle = '#6b4a2b'; g.fillRect(x - 2, gy - 22, 4, 22); const d = Math.min(1, Math.max(0, leafDmg)); g.fillStyle = `rgb(${Math.round(50 + 120 * d)},${Math.round(140 - 50 * d)},${Math.round(50 - 10 * d)})`; g.beginPath(); g.arc(x, gy - 30, 12 - 3 * d, 0, 7); g.fill(); }
      g.fillStyle = col.fg; g.fillText('বন', tx + 11, H - 4);
      // lake
      const lx = wd ? 0.86 * W : 0.88 * W, lw = wd ? 0.2 * W : 0.22 * W; g.fillStyle = bed === 'ls' ? '#d8d0b8' : '#8a8a92'; g.beginPath(); g.ellipse(lx, gy + 6, lw / 2 + 4, 12, 0, 0, 7); g.fill(); g.fillStyle = pHcol(lakePH, 0.85); g.beginPath(); g.ellipse(lx, gy + 4, lw / 2, 9, 0, 0, 7); g.fill();
      if (lakePH > 5.5) { const fxp = lx - lw / 4 + Math.sin(t) * lw / 6; g.fillStyle = '#e07a20'; g.beginPath(); g.ellipse(fxp, gy + 4, 5, 2.5, 0, 0, 7); g.fill(); g.beginPath(); g.moveTo(fxp - 5, gy + 4); g.lineTo(fxp - 9, gy + 1); g.lineTo(fxp - 9, gy + 7); g.fill(); }
      g.fillStyle = col.fg; g.fillText(`হ্রদ pH ${bn(lakePH.toFixed(1))}`, lx, H - 4);
      // pH badge
      g.fillStyle = 'rgba(0,0,0,.45)'; rr(g, W - 112, 8, 104, 28, 8); g.fill(); g.fillStyle = pHcol(pr); g.beginPath(); g.arc(W - 96, 22, 8, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`বৃষ্টি pH ${bn(pr.toFixed(2))}`, W - 84, 26);
    };
    const info = () => { q('[data-ev]').textContent = bn(em); q('[data-scrub]').classList.toggle('primary', scrub); const r = rainPH(420, 3.0e-5 * eff(), 1.5e-5 * eff()); const ratio = Math.pow(10, 5.6 - r.pH);
      out.innerHTML = `<div>বৃষ্টির pH = <b>${bn(r.pH.toFixed(2))}</b> ${r.pH < 5.6 ? `— এসিড বৃষ্টি (স্বাভাবিকের ${bn(ratio.toFixed(1))} গুণ অম্লীয়)` : '— স্বাভাবিক (কেবল CO₂)'}</div>` + TXB('\\ce{CaCO3 + H2SO4 -> CaSO4 + CO2 + H2O}') + `<div class="small">${bed === 'ls' ? 'চুনাপাথরের তলদেশ: CaCO₃ + 2H⁺ → Ca²⁺ + CO₂ + H₂O — আগত এসিড প্রশমিত, হ্রদ প্রায় নিরপেক্ষ, মাছ নিরাপদ।' : 'গ্রানাইটের তলদেশ: বাফার নেই — হ্রদের pH বৃষ্টির pH এর দিকে নামছে; pH ৫.৫ এর নিচে মাছ হারিয়ে যায়।'} ${scrub ? 'স্ক্রাবার ৯০% SO₂ আটকাচ্ছে।' : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    q('[data-e]').oninput = e => { em = +e.target.value; info(); };
    q('[data-scrub]').onclick = () => { scrub = !scrub; info(); };
    X.onSeg(el, 'bed', k => { bed = k; info(); });
    for (let i = 0; i < 200; i++) step(0.05);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= বৃষ্টির pH ক্যালকুলেটর (চার্জ-ভারসাম্য) ======================= */
V.p2c1_rainPH = {
  t: 'বৃষ্টির pH ক্যালকুলেটর: CO₂ (হেনরির সূত্র), সালফেট, নাইট্রেট ও অ্যামোনিয়ামের চার্জ-ভারসাম্য থেকে pH', k: ['int', 'calc', '2d'],
  cap: 'বৃষ্টির ফোঁটায় চারটি উৎস: বায়ুর CO₂ (হেনরির সূত্রে দ্রবীভূত হয়ে HCO₃⁻), H₂SO₄ (SO₄²⁻), HNO₃ (NO₃⁻) এবং কৃষিজ NH₃ (NH₄⁺, ক্ষারীয় প্রভাব)। চার্জ-ভারসাম্য [H⁺] + [NH₄⁺] = [HCO₃⁻] + 2[SO₄²⁻] + [NO₃⁻] সমাধান করে pH বের হয়। বাম দিকে pH স্কেলে ফোঁটার রং ও অবস্থান, ডানে ঋণাত্মক আয়নের দণ্ড — কোন এসিড অম্লতার কত অংশের জন্য দায়ী।',
  html: () => `${X.cv('বৃষ্টির pH')}<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:4px 12px;margin:6px 0"><label class="small">CO₂ = <b data-v1></b> ppm<input type="range" min="0" max="1000" step="10" value="420" data-r1></label><label class="small">SO₄²⁻ = <b data-v2></b> µM<input type="range" min="0" max="60" step="0.5" value="0" data-r2></label><label class="small">NO₃⁻ = <b data-v3></b> µM<input type="range" min="0" max="60" step="0.5" value="0" data-r3></label><label class="small">NH₄⁺ = <b data-v4></b> µM<input type="range" min="0" max="40" step="0.5" value="0" data-r4></label></div><div class="ctl" style="flex-wrap:wrap"><button class="btn sm" data-pre="clean">পরিষ্কার বায়ু</button><button class="btn sm" data-pre="ind">শিল্পাঞ্চল</button><button class="btn sm" data-pre="farm">কৃষি এলাকা</button><button class="btn sm" data-pre="fog">শহুরে কুয়াশা</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 230 : 330;
    let L = X.fit(c, hf); const S = { co2: 420, so4: 0, no3: 0, nh4: 0 };
    const PRE = { clean: { co2: 420, so4: 0, no3: 0, nh4: 0 }, ind: { co2: 420, so4: 25, no3: 15, nh4: 5 }, farm: { co2: 420, so4: 10, no3: 8, nh4: 25 }, fog: { co2: 450, so4: 60, no3: 60, nh4: 10 } };
    const calc = () => rainPH(S.co2, S.so4 * 1e-6, S.no3 * 1e-6, S.nh4 * 1e-6);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), r = calc();
      // pH scale
      const sx0 = 20, sx1 = wd ? W * 0.55 : W - 20, sy = 46, sw = sx1 - sx0, X_ = p => sx0 + (p - 2) / 6 * sw;
      for (let i = 0; i < sw; i++) { g.fillStyle = pHcol(2 + i / sw * 6); g.fillRect(sx0 + i, sy, 1.3, 18); }
      for (let p = 2; p <= 8; p++) { g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(p), X_(p), sy + 30); }
      g.strokeStyle = col.fg; g.lineWidth = 1.5; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(X_(5.6), sy - 6); g.lineTo(X_(5.6), sy + 22); g.stroke(); g.setLineDash([]); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText('৫.৬', X_(5.6), sy - 9);
      g.fillStyle = col.mu; g.textAlign = 'left'; g.fillText('← এসিড বৃষ্টি', sx0, sy + 44); g.textAlign = 'right'; g.fillText('স্বাভাবিক →', sx1, sy + 44);
      // drop marker
      const dx = X_(Math.max(2, Math.min(8, r.pH))); g.fillStyle = pHcol(r.pH); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(dx, sy - 30); g.quadraticCurveTo(dx + 12, sy - 12, dx, sy - 6); g.quadraticCurveTo(dx - 12, sy - 12, dx, sy - 30); g.fill(); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(`pH ${bn(r.pH.toFixed(2))}`, dx, sy + 62 > H ? H - 4 : sy + 62);
      // anion bars
      const bx = wd ? W * 0.62 : 60, by = wd ? 20 : sy + 82, bw = wd ? W * 0.34 : W - 80, bh = wd ? H - 50 : H - by - 26; const items = [['HCO₃⁻', r.hco3 * 1e6, '#2d6fd6'], ['2SO₄²⁻', 2 * S.so4, '#d6b21e'], ['NO₃⁻', S.no3, '#a8541e'], ['−NH₄⁺', -S.nh4, '#2f9e44']]; const mx = Math.max(10, ...items.map(i => Math.abs(i[1])), r.h * 1e6);
      const rowH = bh / 5, z = bx + bw * 0.25; items.concat([['H⁺', r.h * 1e6, '#c0392b']]).forEach(([nm, v, cc], k) => { const y = by + k * rowH; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText(nm, bx + 34, y + rowH / 2 + 4); const w = (bw * 0.7) * v / mx; g.fillStyle = cc; g.fillRect(v >= 0 ? z : z + w, y + rowH * 0.2, Math.abs(w), rowH * 0.6); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`${bn(Math.abs(v).toFixed(v < 10 && v > -10 ? 2 : 1))} µM`, z + Math.max(0, w) + 4, y + rowH / 2 + 4); });
      g.strokeStyle = col.mu; g.beginPath(); g.moveTo(z, by); g.lineTo(z, by + bh); g.stroke(); path(g, [[bx + 4, by + 4 * rowH], [bx + bw, by + 4 * rowH]], col.mu, 0.8, [3, 3]);
    };
    const info = () => { const r = calc(); ['co2', 'so4', 'no3', 'nh4'].forEach((k, i) => { q(`[data-v${i + 1}]`).textContent = bn(S[k]); q(`[data-r${i + 1}]`).value = S[k]; }); const ratio = Math.pow(10, 5.6 - r.pH); const strong = 2 * S.so4 + S.no3;
      out.innerHTML = TXB(`\\begin{aligned}[\\ce{H+}] &= \\tfrac{1}{2}\\Big(a + \\sqrt{a^2 + 4K_{a1}K_H p_{\\ce{CO2}}}\\Big)\\\\ a &= 2[\\ce{SO4^2-}] + [\\ce{NO3-}] - [\\ce{NH4+}]\\\\ &= ${(strong - S.nh4).toFixed(1)}\\ \\mu\\mathrm{M}\\\\ [\\ce{H+}] &= ${(r.h * 1e6).toFixed(2)}\\ \\mu\\mathrm{M} \\Rightarrow \\mathrm{pH} = ${r.pH.toFixed(2)}\\end{aligned}`) + `<div class="small">${r.pH < 5.6 ? `এসিড বৃষ্টি — স্বাভাবিকের ${bn(ratio.toFixed(1))} গুণ বেশি H⁺। অম্লতার ${bn(Math.round(strong > 0 ? 2 * S.so4 / strong * 100 : 0))}% সালফিউরিক ও ${bn(Math.round(strong > 0 ? S.no3 / strong * 100 : 0))}% নাইট্রিক এসিড থেকে।` : S.co2 === 0 ? 'CO₂ ও এসিড নেই — বিশুদ্ধ পানি, pH ৭।' : 'কেবল CO₂ (ও প্রশমিত এসিড) — স্বাভাবিক বৃষ্টি।'} ${S.nh4 > 0 ? 'কৃষিজ NH₃ আংশিক প্রশমন করছে, তবে মাটিতে NH₄⁺ নাইট্রিফিকেশনে আবার H⁺ ছাড়ে।' : ''}</div>`; };
    [['1', 'co2'], ['2', 'so4'], ['3', 'no3'], ['4', 'nh4']].forEach(([i, k]) => { q(`[data-r${i}]`).oninput = e => { S[k] = +e.target.value; info(); draw(); }; });
    el.querySelectorAll('[data-pre]').forEach(b => { b.onclick = () => { Object.assign(S, PRE[b.dataset.pre]); info(); draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= ঝুঁকিপূর্ণ এলাকা বিশ্লেষণ মানচিত্র ======================= */
const SOILS = [['ls', 'চুনাপাথর/চুনযুক্ত পলি', 4.0, '#e8dcb0'], ['al', 'সাধারণ পলিমাটি', 1.6, '#c9d9a0'], ['sd', 'বেলে/অম্লীয় পাহাড়ি', 0.5, '#d9b88a'], ['gr', 'গ্রানাইট/শিলা', 0.25, '#b8b8c0']];
V.p2c1_riskMap = {
  t: 'এসিড বৃষ্টির ঝুঁকিপূর্ণ এলাকা বিশ্লেষণ টুল: নির্গমন উৎস, বাতাসের দিক, বৃষ্টিপাত ও মাটির বাফার ক্ষমতা থেকে ঝুঁকি-মানচিত্র', k: ['int', 'calc', '2d'],
  cap: 'একটি কাল্পনিক জেলার মানচিত্র: পটভূমির রং মাটির ধরন (চুনাপাথর, পলি, বেলে-পাহাড়ি, গ্রানাইট), কালো চিমনি দুটি নির্গমন উৎস। বাতাসের দিক ও গতি, উৎসের নির্গমন আর স্ক্রাবার বদলালে গাউসীয় প্লুম মডেলে প্রতিটি ঘরের অধঃক্ষেপণ হিসাব হয়; ঝুঁকি = অধঃক্ষেপণ ÷ বাফার ক্ষমতা — সবুজ (নিরাপদ) থেকে লাল-বেগুনি (তীব্র) ছায়ায় দেখায়। মানচিত্রে যেকোনো জায়গায় ট্যাপ করলে সেই ঘরের হিসাব নিচে আসে। A, B, C তিনটি গ্রাম চিহ্নিত — কোনটি সবচেয়ে বিপদে?',
  html: () => `${X.cv('ঝুঁকি মানচিত্র')}<div class="ctl"><label class="small" style="flex:1;min-width:140px">বাতাসের দিক (যেদিকে বয়) = <b data-wv></b><input type="range" min="0" max="345" step="15" value="90" data-w></label><label class="small" style="flex:1;min-width:120px">উৎস ১ নির্গমন = <b data-q1v></b> t/দিন SO₂<input type="range" min="0" max="80" step="5" value="40" data-q1></label><label class="small" style="flex:1;min-width:120px">উৎস ২ = <b data-q2v></b> t/দিন<input type="range" min="0" max="80" step="5" value="15" data-q2></label><button class="btn sm" data-sc>উৎস ১ এ স্ক্রাবার</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 360;
    let L = X.fit(c, hf), wdir = 90, Q1 = 40, Q2 = 15, sc = false, pick = [0.7, 0.45];
    const NX = 40, NY = 26;
    const soilAt = (u, v) => { const f = Math.sin(u * 7.1 + 1.3) * 0.5 + Math.cos(v * 5.3 - 0.7) * 0.5 + Math.sin((u + v) * 4.1) * 0.3; if (u > 0.72 && v < 0.55) return f > -0.2 ? 3 : 2; if (v > 0.7 && u < 0.45) return 0; if (u > 0.55 && v > 0.62) return 0; return f > 0.45 ? 2 : 1; };
    const rainAt = (u, v) => 1 + 0.8 * Math.max(0, u - 0.6) * 2.5 * (v < 0.6 ? 1 : 0.5);
    const SRCS = () => [[0.22, 0.4, Q1 * (sc ? 0.1 : 1)], [0.5, 0.75, Q2]];
    const VILL = [['A', 0.42, 0.42], ['B', 0.85, 0.3], ['C', 0.05, 0.62]];
    const dep = (u, v) => { const a = wdir * Math.PI / 180, wx = Math.sin(a), wy = -Math.cos(a); let s = 0; SRCS().forEach(([sx, sy, Q]) => { const dx = u - sx, dy = v - sy, along = dx * wx + dy * wy, cross = -dx * wy + dy * wx; const dist = Math.hypot(dx, dy); if (along > 0.005) { const sig = 0.03 + 0.18 * along; s += Q * Math.exp(-(cross * cross) / (2 * sig * sig)) / (sig * 6) * Math.exp(-along * 1.2); } s += Q * 0.6 * Math.exp(-dist * dist / 0.0025); }); return s * rainAt(u, v); };
    const risk = (u, v) => dep(u, v) / SOILS[soilAt(u, v)][2];
    const rcol = r => { const st = [[0, [70, 170, 90]], [8, [220, 210, 60]], [20, [235, 130, 40]], [45, [210, 40, 40]], [90, [120, 30, 120]]]; for (let i = 1; i < st.length; i++) if (r <= st[i][0]) { const [a, ca] = st[i - 1], [b, cb] = st[i], t2 = (r - a) / (b - a); return ca.map((x, k) => Math.round(x + (cb[k] - x) * t2)); } return [120, 30, 120]; };
    const rlab = r => r < 8 ? 'কম' : r < 20 ? 'মাঝারি' : r < 45 ? 'বেশি' : 'তীব্র';
    const geo = () => { const { W, H } = L, wd = wide(W); const mx0 = 8, my0 = 8, mw = wd ? W * 0.72 : W - 16, mh = wd ? H - 16 : H - 70; return { wd, mx0, my0, mw, mh }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const { wd, mx0, my0, mw, mh } = geo(); const cw = mw / NX, ch = mh / NY;
      for (let i = 0; i < NX; i++) for (let j = 0; j < NY; j++) { const u = (i + 0.5) / NX, v = (j + 0.5) / NY, so = soilAt(u, v), r = risk(u, v), rc = rcol(r); const sc2 = SOILS[so][3]; g.fillStyle = sc2; g.fillRect(mx0 + i * cw, my0 + j * ch, cw + 0.5, ch + 0.5); g.fillStyle = `rgba(${rc.join(',')},${Math.min(0.85, 0.25 + r / 60)})`; g.fillRect(mx0 + i * cw, my0 + j * ch, cw + 0.5, ch + 0.5); }
      // river
      g.strokeStyle = 'rgba(60,120,220,.8)'; g.lineWidth = 3; g.beginPath(); for (let k = 0; k <= 20; k++) { const u = k / 20, v = 0.12 + 0.5 * u + 0.06 * Math.sin(u * 9); const x = mx0 + u * mw, y = my0 + v * mh; k ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke();
      // sources
      SRCS().forEach(([sx, sy, Q], k) => { const x = mx0 + sx * mw, y = my0 + sy * mh; g.fillStyle = '#333'; g.fillRect(x - 4, y - 16, 8, 16); g.fillStyle = k === 0 && sc ? '#2f9e44' : '#c0392b'; g.fillRect(x - 4, y - 16, 8, 3); g.fillStyle = '#fff'; g.font = `bold 9px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(k + 1), x, y - 19); });
      // villages
      VILL.forEach(([n, u, v]) => { const x = mx0 + u * mw, y = my0 + v * mh; g.fillStyle = '#fff'; g.strokeStyle = '#222'; g.lineWidth = 1.5; g.beginPath(); g.arc(x, y, 8, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#222'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(n, x, y + 3.5); });
      // pick marker
      const px = mx0 + pick[0] * mw, py = my0 + pick[1] * mh; g.strokeStyle = '#000'; g.lineWidth = 2; g.beginPath(); g.moveTo(px - 7, py); g.lineTo(px + 7, py); g.moveTo(px, py - 7); g.lineTo(px, py + 7); g.stroke(); g.strokeStyle = '#fff'; g.lineWidth = 1; g.stroke();
      // wind arrow
      const a = wdir * Math.PI / 180, ax = mx0 + mw - 28, ay = my0 + 28; g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.arc(ax, ay, 20, 0, 7); g.fill(); g.strokeStyle = '#2d6fd6'; g.fillStyle = '#2d6fd6'; g.lineWidth = 3; g.beginPath(); g.moveTo(ax - Math.sin(a) * 14, ay + Math.cos(a) * 14); g.lineTo(ax + Math.sin(a) * 12, ay - Math.cos(a) * 12); g.stroke(); g.beginPath(); g.moveTo(ax + Math.sin(a) * 16, ay - Math.cos(a) * 16); g.lineTo(ax + Math.sin(a) * 8 - Math.cos(a) * 6, ay - Math.cos(a) * 8 - Math.sin(a) * 6); g.lineTo(ax + Math.sin(a) * 8 + Math.cos(a) * 6, ay - Math.cos(a) * 8 + Math.sin(a) * 6); g.fill(); g.fillStyle = '#222'; g.font = `bold 8px ${col.font}`; g.textAlign = 'center'; g.fillText('উ', ax, ay - 22 + 8);
      // legend
      const lx = wd ? mx0 + mw + 10 : 8, ly = wd ? 10 : my0 + mh + 8; g.font = `9.5px ${col.font}`; g.textAlign = 'left';
      if (wd) { g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.fillText('মাটি (বাফার)', lx, ly + 8); SOILS.forEach(([k, nm, b, cc], i) => { g.fillStyle = cc; g.fillRect(lx, ly + 16 + i * 16, 12, 12); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText(`${nm} (${bn(b)})`, lx + 16, ly + 26 + i * 16); }); g.font = `bold 10px ${col.font}`; g.fillText('ঝুঁকি', lx, ly + 100); [[2, 'কম'], [12, 'মাঝারি'], [30, 'বেশি'], [70, 'তীব্র']].forEach(([r, nm], i) => { g.fillStyle = `rgb(${rcol(r).join(',')})`; g.fillRect(lx, ly + 108 + i * 16, 12, 12); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText(nm, lx + 16, ly + 118 + i * 16); }); }
      else { SOILS.forEach(([k, nm, b, cc], i) => { const x = lx + (i % 2) * (W / 2 - 4), y = ly + Math.floor(i / 2) * 14; g.fillStyle = cc; g.fillRect(x, y, 10, 10); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText(`${nm} (${bn(b)})`, x + 13, y + 9); }); [[2, 'কম'], [12, 'মাঝারি'], [30, 'বেশি'], [70, 'তীব্র']].forEach(([r, nm], i) => { const x = lx + i * (W / 4 - 2), y = ly + 32; g.fillStyle = `rgb(${rcol(r).join(',')})`; g.fillRect(x, y, 10, 10); g.fillStyle = col.fg; g.fillText(nm, x + 13, y + 9); }); }
    };
    const DIRN = ['উত্তর', 'উত্তর-পূর্ব', 'পূর্ব', 'দক্ষিণ-পূর্ব', 'দক্ষিণ', 'দক্ষিণ-পশ্চিম', 'পশ্চিম', 'উত্তর-পশ্চিম'];
    const info = () => { q('[data-wv]').textContent = DIRN[Math.round(wdir / 45) % 8]; q('[data-q1v]').textContent = bn(Q1); q('[data-q2v]').textContent = bn(Q2); q('[data-sc]').classList.toggle('primary', sc);
      const [u, v] = pick, d = dep(u, v), so = SOILS[soilAt(u, v)], r = d / so[2];
      const vr = VILL.map(([n, a, b]) => [n, risk(a, b)]); const worst = vr.reduce((m, x) => x[1] > m[1] ? x : m);
      out.innerHTML = `<div><b>নির্বাচিত স্থান:</b> অধঃক্ষেপণ সূচক ${bn(d.toFixed(1))} · মাটি: ${so[1]} (বাফার ${bn(so[2])}) · বৃষ্টি গুণক ${bn(rainAt(u, v).toFixed(2))}</div>` + TXB(`\\text{ঝুঁকি} = \\dfrac{\\text{অধঃক্ষেপণ}}{\\text{বাফার}} = \\dfrac{${d.toFixed(1)}}{${so[2]}} = ${r.toFixed(1)}\\ (\\text{${rlab(r)}})`) + `<div class="small">গ্রাম: ${vr.map(([n, x]) => `${n} = ${bn(x.toFixed(1))} (${rlab(x)})`).join(' · ')} — সবচেয়ে ঝুঁকিপূর্ণ <b>${worst[0]}</b>। ${worst[0] === 'B' ? 'B পাহাড়ি গ্রানাইট এলাকায়, বেশি বৃষ্টি — অল্প অধঃক্ষেপণেও বাফার না থাকায় তীব্র ঝুঁকি।' : worst[0] === 'A' ? 'A উৎস ১ এর খুব কাছে ও ভাটির দিকে।' : 'C এখন বাতাসের ভাটিতে পড়েছে।'}</div>`; };
    q('[data-w]').oninput = e => { wdir = +e.target.value; info(); draw(); };
    q('[data-q1]').oninput = e => { Q1 = +e.target.value; info(); draw(); };
    q('[data-q2]').oninput = e => { Q2 = +e.target.value; info(); draw(); };
    q('[data-sc]').onclick = () => { sc = !sc; info(); draw(); };
    c.addEventListener('pointerdown', e => { const rc = c.getBoundingClientRect(), { mx0, my0, mw, mh } = geo(); const u = (e.clientX - rc.left - mx0) / mw, v = (e.clientY - rc.top - my0) / mh; if (u >= 0 && u <= 1 && v >= 0 && v <= 1) { pick = [u, v]; info(); draw(); } });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};
})();
