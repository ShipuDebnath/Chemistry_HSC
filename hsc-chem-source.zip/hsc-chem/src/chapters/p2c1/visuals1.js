/* ২য় পত্র অধ্যায় ১ visuals part 1 — atmosphere (1.1), cyclone & gaseous state (1.2) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, TX = C4.tx, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
window.P2V = { fx, wide };

/* ======================= ১.১ বায়ুমণ্ডল ======================= */
const TPROF = [[0, 15], [11, -56.5], [20, -56.5], [32, -44.5], [47, -2.5], [51, -2.5], [71, -58.5], [86, -90], [95, -85], [110, -10], [120, 90]];
const tAt = h => { for (let i = 1; i < TPROF.length; i++) if (h <= TPROF[i][0]) { const [h0, t0] = TPROF[i - 1], [h1, t1] = TPROF[i]; return t0 + (t1 - t0) * (h - h0) / (h1 - h0); } return 90; };
const LAYERS = [[0, 12, 'ট্রপোমণ্ডল', 'rgba(110,170,230,.20)'], [12, 50, 'স্ট্র্যাটোমণ্ডল', 'rgba(150,130,220,.16)'], [50, 85, 'মেসোমণ্ডল', 'rgba(90,110,180,.14)'], [85, 120, 'তাপমণ্ডল', 'rgba(230,120,90,.12)']];
const MARKS = [[8.85, 'এভারেস্ট'], [11, 'যাত্রীবাহী বিমান'], [25, 'ওজোন স্তরের শীর্ষ ঘনত্ব'], [35, 'আবহাওয়া বেলুন'], [80, 'উল্কা পোড়ে'], [105, 'অরোরা']];
const COMP = [['N₂', 78.08, '#2d6fd6'], ['O₂', 20.95, '#e0402e'], ['Ar', 0.93, '#7b3fa0'], ['অন্যান্য', 0.04, '#9aa3ad']];
const TRACE = [['CO₂', 420], ['Ne', 18.2], ['He', 5.2], ['CH₄', 1.9], ['Kr', 1.1], ['H₂', 0.55], ['N₂O', 0.33], ['Xe', 0.09]];
V.p2c1_atmosphere = {
  t: 'বায়ুমণ্ডলের স্তরবিন্যাস: উচ্চতার সাথে তাপমাত্রা, চাপ ও ওজোনের ঘনত্ব এবং শুষ্ক বায়ুর উপাদান', k: ['int', '2d', 'calc', 'info'],
  cap: 'বামে উচ্চতা (০–১২০ km) বনাম তাপমাত্রার লেখচিত্র: লাল বক্ররেখা তাপমাত্রা — ট্রপোমণ্ডলে কমে, স্ট্র্যাটোমণ্ডলে ওজোনের UV শোষণে বাড়ে, মেসোমণ্ডলে আবার কমে (−৯০ °C), তাপমণ্ডলে দ্রুত বাড়ে। বেগুনি ছায়া ওজোনের আপেক্ষিক ঘনত্ব (শীর্ষ ~২৫ km)। স্লাইডারে উচ্চতা বদলালে সেই উচ্চতায় তাপমাত্রা, চাপ (P = P₀e^(−h/8)), বায়ুর ঘনত্ব ও O₂ এর আংশিক চাপ দেখায়; এভারেস্ট, বিমান, উল্কা ও অরোরার উচ্চতা চিহ্নিত। ডানে শুষ্ক বায়ুর উপাদান — বৃত্তচিত্রে প্রধান গ্যাস, দণ্ডচিত্রে (লগ স্কেল) ট্রেস গ্যাসের ppm।',
  html: () => `${X.cv('বায়ুমণ্ডলের স্তর ও উপাদান')}<label class="small" style="display:block;margin-top:8px">উচ্চতা h = <b data-hv></b> km<input type="range" min="0" max="120" step="0.5" value="8.85" data-h></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 420 : 800;
    let L = X.fit(c, hf), h = 8.85;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const pw = wide(W) ? W * 0.58 : W, ph = wide(W) ? H : 420, x0 = 52, y0 = 14, gw = pw - x0 - 20, gh = ph - 50;
      const Xt = t => x0 + (t + 110) / 160 * gw, Yh = v => y0 + gh - v / 120 * gh;
      LAYERS.forEach(([a, b, nm, cc]) => { g.fillStyle = cc; g.fillRect(x0, Yh(b), gw, Yh(a) - Yh(b)); g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'right'; g.fillText(nm, x0 + gw - 6, Yh((a + b) / 2) + 4); });
      // ozone
      g.fillStyle = 'rgba(123,63,160,.28)'; g.beginPath(); g.moveTo(x0, Yh(10)); for (let v = 10; v <= 50; v += 0.5) { const o = Math.exp(-((v - 25) ** 2) / (2 * 6.5 ** 2)); g.lineTo(x0 + o * gw * 0.22, Yh(v)); } g.lineTo(x0, Yh(50)); g.closePath(); g.fill(); g.fillStyle = '#7b3fa0'; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('ওজোন স্তর', x0 + 4, Yh(30));
      // axes
      g.strokeStyle = col.fg; g.lineWidth = 1.3; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0, y0 + gh); g.lineTo(x0 + gw, y0 + gh); g.stroke();
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'right'; [0, 20, 40, 60, 80, 100, 120].forEach(v => g.fillText(bn(v), x0 - 4, Yh(v) + 3)); g.textAlign = 'center'; [-100, -60, -20, 20].forEach(t => { g.fillText(bn(t), Xt(t), y0 + gh + 13); g.strokeStyle = 'rgba(128,128,128,.25)'; g.beginPath(); g.moveTo(Xt(t), y0); g.lineTo(Xt(t), y0 + gh); g.stroke(); });
      g.fillStyle = col.fg; g.fillText('তাপমাত্রা (°C)', x0 + gw / 2, y0 + gh + 30); g.save(); g.translate(14, y0 + gh / 2); g.rotate(-Math.PI / 2); g.fillText('উচ্চতা (km)', 0, 0); g.restore();
      const pts = []; for (let v = 0; v <= 120; v += 0.5) { const t = Math.min(48, tAt(v)); pts.push([Xt(t), Yh(v)]); } path(g, pts, '#e0402e', 2.8);
      g.fillStyle = '#e0402e'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('→ ১০০০ °C+', x0 + gw - 4, Yh(117));
      MARKS.forEach(([v, nm]) => { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.beginPath(); g.arc(Xt(Math.min(48, tAt(v))), Yh(v), 2.5, 0, 7); g.fill(); g.fillText(nm, Xt(Math.min(40, tAt(v))) + 6, Yh(v) + 3); });
      g.strokeStyle = col.acc; g.setLineDash([4, 3]); g.lineWidth = 1.4; g.beginPath(); g.moveTo(x0, Yh(h)); g.lineTo(x0 + gw, Yh(h)); g.stroke(); g.setLineDash([]); ball(g, Xt(Math.min(48, tAt(h))), Yh(h), 6, '#c0392b', '#ffb3a8');
      // composition
      const cx = wide(W) ? pw + (W - pw) / 2 : W * 0.4, cy = wide(W) ? 110 : ph + 90, r = Math.min(70, wide(W) ? (W - pw) / 2 - 20 : W * 0.22);
      let a = -Math.PI / 2; COMP.forEach(([nm, p, cc]) => { const da = Math.max(p, 0.8) / 100.8 * Math.PI * 2; g.fillStyle = cc; g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, r, a, a + da); g.closePath(); g.fill(); const mid = a + da / 2; if (p > 5) { g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`${nm} ${fx(p, 1)}%`, cx + Math.cos(mid) * r * 0.6, cy + Math.sin(mid) * r * 0.6); } a += da; });
      g.fillStyle = col.sf; g.beginPath(); g.arc(cx, cy, r * 0.32, 0, 7); g.fill(); g.fillStyle = col.fg; g.font = `bold 9px ${col.font}`; g.textAlign = 'center'; g.fillText('শুষ্ক বায়ু', cx, cy + 3);
      g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillStyle = '#7b3fa0'; g.fillText('Ar ০.৯৩%', cx + r + 6, cy - 4); g.fillStyle = col.mu; g.fillText('অন্যান্য ০.০৪%', cx + r + 6, cy + 10);
      const bx = wide(W) ? pw + 46 : 70, by = wide(W) ? 210 : ph + 200, bw = wide(W) ? W - bx - 20 : W - bx - 50, bh = wide(W) ? H - by - 30 : 160;
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('ট্রেস গ্যাস (ppm, লগ স্কেল)', bx - 40, by - 4);
      const rh = bh / TRACE.length; TRACE.forEach(([nm, v], i) => { const y = by + 6 + i * rh, w = (Math.log10(v) + 1.5) / 4.2 * bw; g.fillStyle = i === 0 ? '#d06a1e' : 'rgba(123,63,160,.6)'; g.fillRect(bx, y, w, rh * 0.62); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText(nm, bx - 4, y + rh * 0.5); g.textAlign = 'left'; g.fillText(bn(v), bx + w + 4, y + rh * 0.5); });
    };
    const info = () => {
      const T = tAt(h), P = Math.exp(-h / 8), lay = LAYERS.find(l => h >= l[0] && h <= l[1]) || LAYERS[3], rho = P * 28.96 / (0.0821 * (Math.min(T, 1000) + 273.15));
      q('[data-hv]').textContent = fx(h, 1);
      out.innerHTML = TXB(`h = ${h.toFixed(1)}\\ \\mathrm{km}`) + TXB(`P = P_0e^{-h/8} = ${P < 0.001 ? sci(P, 2) : P.toFixed(3)}\\ \\mathrm{atm},\\quad T \\approx ${T.toFixed(0)}\\,^\\circ\\mathrm{C}${h > 110 ? '\\text{ (এবং উপরে আরও বাড়ে)}' : ''}`) +
        TXB(`\\rho = \\dfrac{PM}{RT} \\approx ${rho < 0.001 ? sci(rho, 2) : rho.toFixed(3)}\\ \\mathrm{g\\,L^{-1}}`) + TXB(`p_{\\ce{O2}} = 0.21P = ${(0.21 * P) < 0.001 ? sci(0.21 * P, 2) : (0.21 * P).toFixed(3)}\\ \\mathrm{atm}`) +
        `<div class="small"><b>${lay[2]}</b> — ${{ 'ট্রপোমণ্ডল': 'আবহাওয়ার স্তর; উচ্চতার সাথে প্রায় ৬.৫ °C km⁻¹ হারে তাপমাত্রা কমে।', 'স্ট্র্যাটোমণ্ডল': 'ওজোনের UV শোষণে উচ্চতার সাথে তাপমাত্রা বাড়ে; বায়ু স্থির।', 'মেসোমণ্ডল': 'তাপমাত্রা আবার কমে — শীর্ষে সবচেয়ে শীতল (~−৯০ °C); উল্কা পুড়ে যায়।', 'তাপমণ্ডল': 'সৌর বিকিরণে অণু আয়নিত ও অতি দ্রুতগামী — তাপমাত্রা হাজার ডিগ্রি, কিন্তু অণু অত্যন্ত বিরল।' }[lay[2]]}</div>`;
    };
    q('[data-h]').oninput = e => { h = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ১.২ ঘূর্ণিঝড় ও জলোচ্ছ্বাস ======================= */
const bmd = v => v < 31 ? 'লঘুচাপ' : v < 41 ? 'সুস্পষ্ট লঘুচাপ' : v < 52 ? 'নিম্নচাপ' : v < 62 ? 'গভীর নিম্নচাপ' : v < 89 ? 'ঘূর্ণিঝড়' : v < 118 ? 'প্রবল ঘূর্ণিঝড়' : v < 220 ? 'হারিকেন গতিসম্পন্ন প্রবল ঘূর্ণিঝড়' : 'সুপার সাইক্লোন';
V.p2c1_cyclone = {
  t: 'ঘূর্ণিঝড়ের গঠন ও জলোচ্ছ্বাস: উপগ্রহ দৃশ্য (ঘূর্ণায়মান মেঘবলয়) ও প্রস্থচ্ছেদ (উষ্ণ আর্দ্র বায়ুর ঊর্ধ্বগমন)', k: ['anim', 'int', '2d', 'calc'],
  cap: '"উপগ্রহ দৃশ্য" এ মেঘের সর্পিল বলয় ঘড়ির কাঁটার বিপরীতে (উত্তর গোলার্ধ) ঘুরতে ঘুরতে কেন্দ্রের দিকে যায়; মাঝে শান্ত চোখ। "প্রস্থচ্ছেদ" এ উষ্ণ সমুদ্র থেকে আর্দ্র বায়ু চোখের দেয়ালে উপরে ওঠে, ঘনীভূত হয়ে মেঘ ও সুপ্ত তাপ তৈরি করে, শীর্ষে বাইরের দিকে ছড়িয়ে পড়ে; চোখে বায়ু নেমে আসে। ডানে উপকূলে জলোচ্ছ্বাস। স্লাইডারে কেন্দ্রীয় চাপ ও সমুদ্রপৃষ্ঠের তাপমাত্রা বদলাও — আনুমানিক বায়ুর গতিবেগ, বাংলাদেশ আবহাওয়া অধিদপ্তরের শ্রেণি এবং জলোচ্ছ্বাসের দুই অংশ (নিম্নচাপ + বায়ুর ঠেলা) দেখায়। সমুদ্র ২৬.৫ °C এর কম হলে ঝড় দুর্বল হয়ে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('v', [['top', 'উপগ্রহ দৃশ্য'], ['side', 'প্রস্থচ্ছেদ']], 'top')}</div>${X.cv('ঘূর্ণিঝড়ের গঠন ও জলোচ্ছ্বাস')}<div class="grid2" style="margin-top:8px"><label class="small">কেন্দ্রীয় চাপ = <b data-pv></b> hPa<input type="range" min="920" max="1004" step="1" value="950" data-p></label><label class="small">সমুদ্রপৃষ্ঠের তাপমাত্রা = <b data-sv></b> °C<input type="range" min="24" max="31" step="0.1" value="29" data-s></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 380;
    let L = X.fit(c, hf), view = 'top', Pc = 950, sst = 29, t = 0, P = [], rise = [];
    const R = X.rng(11); for (let i = 0; i < 520; i++) { const arm = i % 4; P.push({ r: 0.12 + R() * 0.9, a: arm * Math.PI / 2 + (R() - 0.5) * 0.45, s: 0.6 + R() * 0.8 }); }
    for (let i = 0; i < 60; i++) rise.push({ u: R(), side: R() < 0.5 ? -1 : 1, o: R() });
    const eff = () => { const pmin = sst > 26.5 ? 1010 - 30 * (sst - 26.5) : 1006; return Math.max(Pc, pmin); };
    const calc = () => { const pe = eff(), dp = Math.max(0, 1010 - pe), v = 6.7 * Math.pow(dp, 0.644) * 1.852, s1 = dp * 0.01, s2 = 0.00011 * v * v; return { pe, dp, v, s1, s2, cat: bmd(v) }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const k = calc(), inten = Math.min(1, k.dp / 90);
      if (view === 'top') {
        g.fillStyle = '#1b3a5c'; g.fillRect(0, 0, W, H);
        // coast (land) on right
        g.fillStyle = '#3f6b3a'; g.beginPath(); g.moveTo(W, 0); g.lineTo(W * 0.78, 0); for (let y = 0; y <= H; y += 12) g.lineTo(W * 0.78 + Math.sin(y * 0.05) * 14 + (y > H * 0.5 ? (y - H * 0.5) * 0.25 : 0), y); g.lineTo(W, H); g.closePath(); g.fill();
        g.fillStyle = 'rgba(255,255,255,.75)'; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText('উপকূল', W - 10, 16);
        const cx = W * 0.42 + Math.sin(t * 0.05) * 6, cy = H * 0.52, Rr = Math.min(W * 0.4, H * 0.48), eye = Rr * (0.12 - inten * 0.04);
        P.forEach(p => { const pr = 0.1 + ((p.r - 0.1 - t * 0.025 * p.s) % 0.92 + 0.92) % 0.92; if (pr * Rr < eye * 1.1) return; const spiral = p.a - Math.log(pr) * 2.4 + t * (0.25 + inten * 0.7); const x = cx + Math.cos(-spiral) * pr * Rr, y = cy + Math.sin(-spiral) * pr * Rr * 0.92; const al = (0.25 + 0.6 * inten) * (1 - pr * 0.6); p.rr = pr; g.fillStyle = `rgba(245,248,252,${al.toFixed(2)})`; g.beginPath(); g.arc(x, y, 3 + (1 - p.rr) * 5, 0, 7); g.fill(); });
        g.fillStyle = '#1b3a5c'; g.beginPath(); g.arc(cx, cy, eye, 0, 7); g.fill(); g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 2; g.beginPath(); g.arc(cx, cy, eye + 2, 0, 7); g.stroke();
        g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('চোখ', cx, cy + 4);
        // rotation arrows
        g.strokeStyle = 'rgba(255,220,120,.9)'; g.lineWidth = 2; for (let i = 0; i < 3; i++) { const a0 = t * 0.8 + i * 2.094; g.beginPath(); g.arc(cx, cy, Rr * 0.75, -a0, -a0 - 0.6, true); g.stroke(); const ex = cx + Math.cos(-a0 - 0.6) * Rr * 0.75, ey = cy + Math.sin(-a0 - 0.6) * Rr * 0.75; g.fillStyle = 'rgba(255,220,120,.9)'; g.beginPath(); g.arc(ex, ey, 3.5, 0, 7); g.fill(); }
        g.fillStyle = 'rgba(255,255,255,.85)'; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('ঘড়ির কাঁটার বিপরীতে ঘূর্ণন (উত্তর গোলার্ধ)', 10, H - 10);
        // surge at coast
        const sh = Math.min(1, (k.s1 + k.s2) / 8); g.fillStyle = `rgba(120,200,255,${(0.3 + 0.5 * sh).toFixed(2)})`; g.beginPath(); g.ellipse(W * 0.79, H * 0.55, 18 + sh * 30, 40 + sh * 60, 0, 0, 7); g.fill();
      } else {
        const sea = H * 0.72; g.fillStyle = `rgba(30,110,${Math.round(140 + (sst - 24) * 12)},.9)`; g.fillRect(0, sea, W, H - sea);
        g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`উষ্ণ সমুদ্র (${fx(sst, 1)} °C)`, 10, H - 10);
        // land & surge
        const surge = Math.min(60, (k.s1 + k.s2) * 9); g.fillStyle = '#3f6b3a'; g.beginPath(); g.moveTo(W * 0.86, sea + 4); g.lineTo(W, sea - 26); g.lineTo(W, H); g.lineTo(W * 0.86, H); g.fill();
        g.fillStyle = 'rgba(120,200,255,.75)'; g.beginPath(); g.moveTo(W * 0.62, sea); g.quadraticCurveTo(W * 0.8, sea - surge, W * 0.9, sea - surge * 0.9); g.lineTo(W * 0.9, sea + 2); g.closePath(); g.fill();
        g.strokeStyle = col.fg; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(W * 0.95, sea); g.lineTo(W * 0.95, sea - surge * 0.9); g.stroke(); g.setLineDash([]); g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'right'; g.fillText(`জলোচ্ছ্বাস ~${fx(k.s1 + k.s2, 1)} m`, W - 6, sea - surge - 6);
        const cx = W * 0.4; // eye
        // clouds (eyewall towers)
        [-1, 1].forEach(sd => { for (let i = 0; i < 6; i++) { const x = cx + sd * (W * 0.07 + i * W * 0.045), top = 30 + i * 12 * (1 - inten * 0.5); g.fillStyle = `rgba(230,236,244,${(0.55 + 0.35 * inten - i * 0.05).toFixed(2)})`; g.beginPath(); g.ellipse(x, top + (sea - top) * 0.35, W * 0.03, (sea - top) * 0.36, 0, 0, 7); g.fill(); } });
        // anvil outflow
        g.fillStyle = 'rgba(230,236,244,.6)'; g.beginPath(); g.ellipse(cx, 30, W * 0.33, 14, 0, 0, 7); g.fill();
        // rising parcels with arrows
        rise.forEach(p => { p.u = (p.u + 0.004 * (1 + inten * 2)) % 1; const x = cx + p.side * (W * 0.075 + p.o * W * 0.04), y = sea - p.u * (sea - 40); g.fillStyle = p.u > 0.45 ? 'rgba(255,255,255,.9)' : 'rgba(255,170,80,.9)'; g.beginPath(); g.arc(x, y, 2.4, 0, 7); g.fill(); });
        // inflow arrows at surface, outflow at top, descending in eye
        g.strokeStyle = '#ffb347'; g.lineWidth = 2; [-1, 1].forEach(sd => { g.beginPath(); g.moveTo(cx + sd * W * 0.35, sea - 8); g.lineTo(cx + sd * W * 0.1, sea - 8); g.stroke(); g.fillStyle = '#ffb347'; g.beginPath(); g.moveTo(cx + sd * W * 0.1, sea - 8); g.lineTo(cx + sd * W * 0.1 + sd * 8, sea - 13); g.lineTo(cx + sd * W * 0.1 + sd * 8, sea - 3); g.fill(); g.strokeStyle = '#8fc1ff'; g.beginPath(); g.moveTo(cx + sd * W * 0.1, 50); g.lineTo(cx + sd * W * 0.33, 50); g.stroke(); g.strokeStyle = '#ffb347'; });
        g.strokeStyle = '#8fc1ff'; g.setLineDash([4, 4]); g.beginPath(); g.moveTo(cx, 60); g.lineTo(cx, sea - 20); g.stroke(); g.setLineDash([]);
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('চোখ', cx, sea - 30); g.font = `9.5px ${col.font}`; g.fillText(`নিম্নচাপ ${bn(Math.round(k.pe))} hPa`, cx, sea + 14);
        g.textAlign = 'left'; g.fillStyle = col.fg; g.fillText('উষ্ণ আর্দ্র বায়ু ঢোকে →', 6, sea - 14); g.fillText('ঘনীভবন + সুপ্ত তাপ', cx + W * 0.13, H * 0.3);
      }
    };
    const info = () => {
      const k = calc(); q('[data-pv]').textContent = bn(Pc); q('[data-sv]').textContent = fx(sst, 1);
      out.innerHTML = TXB(`\\Delta P = 1010 - ${Math.round(k.pe)} = ${Math.round(k.dp)}\\ \\mathrm{hPa}\\;\\Rightarrow\\;v_{\\max} \\approx ${Math.round(k.v)}\\ \\mathrm{km\\,h^{-1}}`) +
        TXB(`\\text{জলোচ্ছ্বাস} \\approx \\underbrace{${k.s1.toFixed(2)}}_{\\text{নিম্নচাপ}} + \\underbrace{${k.s2.toFixed(2)}}_{\\text{বায়ুর ঠেলা}} = ${(k.s1 + k.s2).toFixed(1)}\\ \\mathrm{m}`) +
        `<div class="small"><b>শ্রেণি: ${k.cat}</b>। ${sst < 26.5 ? 'সমুদ্রপৃষ্ঠ ২৬.৫ °C এর কম — পর্যাপ্ত বাষ্প ও সুপ্ত তাপ নেই, ঝড় দুর্বল হয়ে লঘুচাপে পরিণত হয়।' : k.pe > Pc ? `এই সমুদ্র তাপমাত্রায় চাপ সর্বনিম্ন প্রায় ${bn(Math.round(k.pe))} hPa পর্যন্ত নামতে পারে — উষ্ণ সমুদ্র মানে বেশি শক্তি।` : 'উষ্ণ সমুদ্র ঝড়কে শক্তি জোগাচ্ছে।'} (মডেলটি শিক্ষামূলক আনুমানিক; বাস্তব জলোচ্ছ্বাস জোয়ার ও উপকূলের গঠনের উপরও নির্ভর করে।)</div>`;
    };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'v', v => { view = v; });
    q('[data-p]').oninput = e => { Pc = +e.target.value; info(); }; q('[data-s]').oninput = e => { sst = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.২.১ পদার্থের তিন অবস্থা ======================= */
V.p2c1_gasState = {
  t: 'কঠিন, তরল ও গ্যাস: কণার বিন্যাস ও গতি, সংকোচনশীলতা এবং ব্যাপনের তুলনা (কণা-সিমুলেশন)', k: ['anim', 'int', '2d'],
  cap: 'তিনটি পাত্রে একই সংখ্যক কণা: কঠিনে সুশৃঙ্খল জালিতে কেবল কম্পন, তরলে কাছাকাছি থেকে গড়িয়ে চলা, গ্যাসে দূরে দূরে দ্রুত সরলরেখায় ছোটা ও দেয়ালে ধাক্কা। "পিস্টনে চাপ দাও" চাপলে গ্যাসের আয়তন প্রায় অর্ধেক হয়, কিন্তু কঠিন ও তরল প্রায় অপরিবর্তিত — কারণ গ্যাসে কণার মাঝে বিশাল ফাঁকা স্থান। "রং ছাড়ো" চাপলে লাল কণাগুলো তরলে ধীরে, গ্যাসে দ্রুত ছড়িয়ে পড়ে (ব্যাপন); কঠিনে প্রায় নড়ে না। তাপমাত্রা বাড়ালে সব অবস্থায় কণার গতি বাড়ে।',
  html: () => `${X.cv('পদার্থের তিন অবস্থার কণা-সিমুলেশন')}<div class="ctl"><button class="btn sm" data-press>পিস্টনে চাপ দাও</button><button class="btn sm" data-dye>রং ছাড়ো</button><label class="small" style="flex:1;min-width:150px">তাপমাত্রা <input type="range" min="0.5" max="2" step="0.05" value="1" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 260 : 600;
    let L = X.fit(c, hf), press = 0, ptgt = 0, temp = 1, t = 0;
    const R = X.rng(21), N = 36;
    const S = [], Lq = [], G = [];
    for (let i = 0; i < N; i++) { S.push({ ix: i % 6, iy: Math.floor(i / 6), ph: R() * 6, dye: false }); Lq.push({ x: 0.1 + (i % 6) * 0.15 + R() * 0.05, y: 0.45 + Math.floor(i / 6) * 0.09, vx: R() - 0.5, vy: R() - 0.5, dye: false }); G.push({ x: R(), y: R(), vx: (R() - 0.5) * 2, vy: (R() - 0.5) * 2, dye: false }); }
    const dye = () => { [S, Lq, G].forEach(arr => { arr.forEach(p => { p.dye = false; }); }); for (let i = 0; i < 5; i++) { S[i].dye = true; Lq[30 + i].dye = true; G[i].dye = true; } Lq.slice(30, 35).forEach(p => { p.x = 0.08 + Math.random() * 0.1; }); G.slice(0, 5).forEach(p => { p.x = 0.05 + Math.random() * 0.1; p.y = 0.8 + Math.random() * 0.1; }); };
    const panels = () => { const { W, H } = L; if (wide(W)) { const pw = (W - 40) / 3; return [0, 1, 2].map(i => [10 + i * (pw + 10), 34, pw, H - 64]); } return [0, 1, 2].map(i => [14, 30 + i * 190, W - 28, 150]); };
    const step = dt => {
      t += dt; press += (ptgt - press) * Math.min(1, dt * 3);
      Lq.forEach(p => { p.vx += (Math.random() - 0.5) * dt * 3 * temp; p.vy += (Math.random() - 0.5) * dt * 3 * temp; p.vx *= 0.96; p.vy *= 0.96; p.x += p.vx * dt * 0.15 * temp; p.y += p.vy * dt * 0.15 * temp + dt * 0.02; if (p.x < 0.04 || p.x > 0.96) { p.vx *= -1; p.x = Math.max(0.04, Math.min(0.96, p.x)); } if (p.y < 0.38 || p.y > 0.96) { p.vy *= -1; p.y = Math.max(0.38, Math.min(0.96, p.y)); } });
      const top = 0.04 + press * 0.46;
      G.forEach(p => { p.x += p.vx * dt * 0.35 * temp; p.y += p.vy * dt * 0.35 * temp; if (p.x < 0.03 || p.x > 0.97) { p.vx *= -1; p.x = Math.max(0.03, Math.min(0.97, p.x)); } if (p.y < top || p.y > 0.97) { p.vy *= -1; p.y = Math.max(top, Math.min(0.97, p.y)); } });
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const P = panels();
      ['কঠিন', 'তরল', 'গ্যাস'].forEach((nm, k) => {
        const [x, y, w, h] = P[k], pis = [0.02 + press * 0.012, 0.36 + press * 0.004, 0.02 + press * 0.46][k];
        g.fillStyle = 'rgba(160,200,235,.12)'; g.fillRect(x, y, w, h); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x, y - 10); g.lineTo(x, y + h); g.lineTo(x + w, y + h); g.lineTo(x + w, y - 10); g.stroke();
        g.fillStyle = '#5a5a5a'; g.fillRect(x + 2, y + pis * h - 8, w - 4, 8); g.fillStyle = col.s3; g.fillRect(x + w / 2 - 4, y - 24, 8, pis * h - 8 + 24);
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + w / 2, y + h + 16);
        const r = Math.max(4, Math.min(7, w / 30));
        if (k === 0) S.forEach(p => { const ox = x + w * 0.18 + p.ix * w * 0.128 + Math.sin(t * 9 * temp + p.ph) * 1.6 * temp, oy = y + h * 0.42 + p.iy * h * 0.092 + Math.cos(t * 8 * temp + p.ph) * 1.6 * temp; ball(g, ox, oy, r, p.dye ? '#c0392b' : '#2d6fd6', p.dye ? '#ffb3a8' : '#a9c8ff'); });
        if (k === 1) Lq.forEach(p => ball(g, x + p.x * w, y + p.y * h, r, p.dye ? '#c0392b' : '#2d6fd6', p.dye ? '#ffb3a8' : '#a9c8ff'));
        if (k === 2) G.forEach(p => ball(g, x + p.x * w, y + p.y * h, r, p.dye ? '#c0392b' : '#2d6fd6', p.dye ? '#ffb3a8' : '#a9c8ff'));
        const vol = [100, 99.99, 100 / (1 + press)][k]; g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.fillText(`আয়তন ${fx(vol, k === 1 ? 2 : 0)}%`, x + w / 2, y - 14 > 10 ? y - 28 : y + 12);
      });
    };
    const info = () => { out.innerHTML = `<div class="small">${press > 0.5 ? 'চাপে গ্যাসের আয়তন প্রায় অর্ধেক (বয়েলের সূত্র, ১.৩.২); কঠিন ও তরলের আয়তন কার্যত অপরিবর্তিত — তাদের কণাগুলো ইতিমধ্যে প্রায় গায়ে গায়ে।' : 'তিন অবস্থায় কণার বিন্যাস ও গতি তুলনা করো। "রং ছাড়ো" দিয়ে ব্যাপনের হার দেখো।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(dt); draw(); }, { paused: false });
    q('[data-press]').onclick = () => { ptgt = ptgt ? 0 : 1; q('[data-press]').textContent = ptgt ? 'চাপ সরাও' : 'পিস্টনে চাপ দাও'; info(); };
    q('[data-dye]').onclick = dye; q('[data-t]').oninput = e => { temp = +e.target.value; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
