/* ২য় পত্র অধ্যায় ১ visuals part 14 — water treatment plant, jar test/coagulation, chlorination, ETP, activated sludge (1.19–1.20) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const rod = (g, x, y, a, cl, s = 1) => { g.save(); g.translate(x, y); g.rotate(a); g.fillStyle = cl; rr(g, -4 * s, -1.6 * s, 8 * s, 3.2 * s, 1.6 * s); g.fill(); g.restore(); };

/* ======================= পানি শোধনাগার ======================= */
const WST = [
  ['ছাঁকনি', 'লোহার জালিতে বড় বস্তু (পাতা, প্লাস্টিক) আটকে যায়।', '', 120, 5000],
  ['জমাটকরণ', 'ফিটকিরি দ্রুত মেশানো হয়; Al³⁺ কাদাকণার ঋণাত্মক চার্জ প্রশমিত করে।', '\\ce{Al2(SO4)3 + 3Ca(HCO3)2 -> 2Al(OH)3 v + 3CaSO4 + 6CO2}', 120, 5000],
  ['ফ্লক গঠন', 'ধীরে নাড়লে ক্ষুদ্র কণা Al(OH)₃ এর জালে জুড়ে বড় ফ্লক হয়।', '', 90, 4500],
  ['থিতানো', 'শান্ত ট্যাংকে ভারী ফ্লক ২–৪ ঘণ্টায় তলায় নামে (স্লাজ)।', '', 8, 1500],
  ['বালি ফিল্টার', 'মিহি বালি ও নুড়ির স্তরে অবশিষ্ট কণা ও অধিকাংশ জীবাণু আটকায়।', '', 0.5, 150],
  ['ক্লোরিনেশন', 'HOCl জীবাণুর কোষঝিল্লি ভেদ করে এনজাইম জারিত করে।', '\\ce{Cl2 + H2O <=> HOCl + HCl}', 0.5, 0],
  ['জলাধার', '০.২–০.৫ mg L⁻¹ অবশিষ্ট ক্লোরিনসহ বিতরণ — পাইপে পুনর্দূষণ রোধ।', '', 0.5, 0]
];
V.p2c1_wtp = {
  t: 'পানি শোধনাগারের পূর্ণ প্রবাহ: ছাঁকনি → ফিটকিরি জমাটকরণ → ফ্লক গঠন → থিতানো → বালি ফিল্টার → ক্লোরিনেশন → জলাধার (অ্যানিমেশন)', k: ['anim', 'int', '2d'],
  cap: 'বাম থেকে ঘোলা নদীর পানি (বাদামি কাদাকণা, সবুজ ব্যাকটেরিয়া) প্রতিটি ট্যাংক দিয়ে প্রবাহিত হয়। জমাটকরণে সাদা ফিটকিরি যোগ হয়, ফ্লক গঠনে ছোট কণা জুড়ে বড় বাদামি ফ্লক হয়, থিতানো ট্যাংকে ফ্লক তলায় নামে, বালি ফিল্টার অবশিষ্টাংশ আটকায়, ক্লোরিন (হলুদ বিন্দু) ব্যাকটেরিয়া মেরে ধূসর করে। প্রতিটি ট্যাংকের নিচে ঘোলাত্ব (NTU) ও কলিফর্ম সংখ্যা; ট্যাংকে ট্যাপ করলে সেই ধাপের রসায়ন।',
  html: () => `${X.cv('পানি শোধনাগার')}<div class="ctl"><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 300 : 460;
    let L = X.fit(c, hf), t = 0, sel = 1, P = []; const Rn = X.rng(23);
    const geo = () => { const { W, H } = L, wd = wide(W); if (wd) { const tw = (W - 20) / 7; return { wd, box: i => [10 + i * tw + 4, 40, tw - 8, H * 0.55] }; } const tw = (W - 20) / 4; return { wd, box: i => { const r = i < 4 ? 0 : 1, col = i < 4 ? i : 6 - i + 0; const cc = r === 0 ? i : (i - 4); return [10 + cc * tw + 4, 40 + r * (H * 0.46), tw - 8, H * 0.3]; } }; };
    const spawn = () => { const r = Rn(); P.push({ k: r < 0.7 ? 'd' : 'b', s: 0, u: 0, y: 0.15 + Rn() * 0.7, sz: 1, dead: 0, gone: 0 }); };
    const step = dt => { t += dt; if (Rn() < dt * 10) spawn(); if (Rn() < dt * 4) P.push({ k: 'a', s: 1, u: 0.05, y: 0.05, sz: 1 });
      P.forEach(p => { if (p.settled) { p.y = Math.min(0.94, p.y + dt * 0.3); return; } p.u += dt * 0.22; p.y += (Rn() - .5) * dt * 0.2; p.y = Math.max(0.05, Math.min(0.92, p.y));
        if (p.k === 'a') { p.y += dt * 0.3; if (p.s >= 2) p.gone = 1; }
        if (p.s === 2 && p.k === 'd' && Rn() < dt * 0.9) { p.k = 'f'; p.sz = 1.4; } if (p.s === 2 && p.k === 'f') p.sz = Math.min(2.6, p.sz + dt * 0.5);
        if (p.s === 3 && (p.k === 'f' || p.k === 'd')) { p.y += dt * (p.k === 'f' ? 0.45 : 0.12); if (p.y > 0.9) p.settled = 1; }
        if (p.s === 4 && (p.k === 'f' || p.k === 'd') && Rn() < dt * 3) p.gone = 1; if (p.s === 4 && p.k === 'b' && Rn() < dt * 1.5) p.gone = 1;
        if (p.s === 5 && p.k === 'b' && Rn() < dt * 1.8) p.dead = 1;
        if (p.u >= 1) { p.u -= 1; p.s++; if (p.s > 6) p.gone = 1; } });
      P = P.filter(p => !p.gone && !(p.settled && P.filter(q => q.settled && q.s === p.s).length > 40 && Rn() < 0.02)); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const { wd, box } = geo();
      WST.forEach((s, i) => { const [x, y, w, h] = box(i); const clean = Math.min(1, i / 4); g.fillStyle = `rgba(${Math.round(150 - 70 * clean)},${Math.round(130 + 50 * clean)},${Math.round(90 + 140 * clean)},.45)`; g.fillRect(x, y, w, h); g.strokeStyle = i === sel ? col.acc : col.fg; g.lineWidth = i === sel ? 2.6 : 1.4; g.strokeRect(x, y, w, h);
        if (i === 0) { g.strokeStyle = '#555'; g.lineWidth = 1.5; for (let k = 1; k < 6; k++) { g.beginPath(); g.moveTo(x + w * 0.7, y + h * k / 6 - 6); g.lineTo(x + w * 0.7, y + h * k / 6 + 6); g.stroke(); } }
        if (i === 1 || i === 2) { const a = t * (i === 1 ? 8 : 2); g.strokeStyle = '#555'; g.lineWidth = 2; g.beginPath(); g.moveTo(x + w / 2, y - 8); g.lineTo(x + w / 2, y + h * 0.5); g.stroke(); g.beginPath(); g.moveTo(x + w / 2 - Math.cos(a) * w * 0.3, y + h * 0.5); g.lineTo(x + w / 2 + Math.cos(a) * w * 0.3, y + h * 0.5); g.stroke(); }
        if (i === 3) { g.fillStyle = 'rgba(110,80,50,.7)'; g.fillRect(x + 1, y + h - 8, w - 2, 7); }
        if (i === 4) { [['#e8d8a8', 0.45], ['#c9b07a', 0.65], ['#8a7a6a', 0.85]].forEach(([cc, f], k) => { g.fillStyle = cc; g.fillRect(x + 1, y + h * f - h * 0.2 + h * 0.1, w - 2, h * 0.2); }); }
        if (i === 5) { g.fillStyle = '#d6b21e'; g.fillRect(x + w / 2 - 6, y - 14, 12, 10); }
        g.fillStyle = col.fg; g.font = `bold ${wd ? 10 : 9.5}px ${col.font}`; g.textAlign = 'center'; g.fillText(s[0], x + w / 2, y - 18 > 2 ? y - 18 : y + 10); g.font = `9px ${col.font}`; g.fillStyle = col.mu; g.fillText(`${bn(s[3])} NTU`, x + w / 2, y + h + 12); g.fillText(`কলিফর্ম ${bn(s[4])}`, x + w / 2, y + h + 24);
        if (i < 6) { const [x2, y2, w2] = box(i + 1); if (wd || i !== 3) { g.strokeStyle = col.mu; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x + w, y + h / 2); g.lineTo(x2, y2 + h / 2); g.stroke(); } } });
      P.forEach(p => { if (p.s > 6) return; const [x, y, w, h] = box(p.s); const px = x + p.u * w, py = y + p.y * h; if (p.k === 'd') { g.fillStyle = '#8a5a2b'; g.beginPath(); g.arc(px, py, 2.2, 0, 7); g.fill(); } else if (p.k === 'f') { g.fillStyle = 'rgba(120,80,40,.85)'; g.beginPath(); g.arc(px, py, 2.2 * p.sz, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.arc(px - 1, py - 1, 1, 0, 7); g.fill(); } else if (p.k === 'b') rod(g, px, py, p.y * 9, p.dead ? '#999' : '#2f9e44'); else if (p.k === 'a') { g.fillStyle = '#fff'; g.strokeStyle = '#aaa'; g.beginPath(); g.arc(px, py, 2, 0, 7); g.fill(); g.stroke(); } });
      { const [x, y, w, h] = box(5); for (let k = 0; k < 10; k++) { g.fillStyle = 'rgba(214,178,30,.9)'; g.beginPath(); g.arc(x + ((k * 0.13 + t * 0.2) % 1) * w, y + ((k * 0.37) % 1) * h, 1.6, 0, 7); g.fill(); } }
    };
    const info = () => { const s = WST[sel]; out.innerHTML = `<div><b>${bn(sel + 1)}. ${s[0]}:</b> ${s[1]}</div>` + (s[2] ? TXB(s[2]) : '') + `<div class="small">ঘোলাত্ব ${bn(s[3])} NTU, কলিফর্ম ${bn(s[4])}/১০০ mL (প্রতিনিধিত্বমূলক মান)।</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    c.addEventListener('pointerdown', e => { const rc = c.getBoundingClientRect(), x = e.clientX - rc.left, y = e.clientY - rc.top, { box } = geo(); for (let i = 0; i < 7; i++) { const [bx, by, bw, bh] = box(i); if (x >= bx && x <= bx + bw && y >= by - 20 && y <= by + bh + 26) { sel = i; info(); A.draw(); break; } } });
    for (let i = 0; i < 300; i++) step(0.05);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= জার টেস্ট ও কলয়েড জমাটকরণ ======================= */
const turbOf = d => 3 + 77 * Math.exp(-d / 8.5) + 0.0175 * Math.max(0, d - 30) ** 2;
const zetaOf = d => -32 + 1.15 * d; // mV (illustrative)
V.p2c1_coag = {
  t: 'জার টেস্ট ও কলয়েড জমাটকরণ: ফিটকিরির মাত্রার সাথে কণার চার্জ, ফ্লক গঠন ও ঘোলাত্বের পরিবর্তন', k: ['anim', 'int', 'calc', '2d'],
  cap: 'বামে ছয়টি জারে একই ঘোলা পানিতে ভিন্ন মাত্রার ফিটকিরি (০–৬০ mg L⁻¹) — ধীরে নাড়ার পর থিতানো দেখো: মাঝের জারগুলো সবচেয়ে পরিষ্কার। ডানে "আণবিক দৃশ্য": ঋণাত্মক কাদাকণা (−) পরস্পরকে বিকর্ষণ করে; স্লাইডারে ফিটকিরি বাড়ালে Al³⁺ (লাল বিন্দু) পৃষ্ঠে জমে চার্জ প্রশমিত করে, কণা জোড়া লেগে ফ্লক হয়; অতিরিক্ত দিলে চার্জ ধনাত্মক (+) হয়ে আবার আলাদা। নিচে মাত্রা বনাম ঘোলাত্ব লেখচিত্র — সর্বোত্তম মাত্রা চিহ্নিত।',
  html: () => `${X.cv('জার টেস্ট')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:160px">ফিটকিরি (আণবিক দৃশ্য) = <b data-dv></b> mg L⁻¹<input type="range" min="0" max="70" step="1" value="10" data-d></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 560;
    let L = X.fit(c, hf), dose = 10, t = 7; const Rn = X.rng(4); const DOSES = [0, 10, 20, 30, 40, 60];
    const cl = Array.from({ length: 14 }, () => ({ x: Rn(), y: Rn(), vx: 0, vy: 0 }));
    const step = dt => { t += dt; const z = zetaOf(dose), rep = Math.min(1, Math.abs(z) / 25);
      cl.forEach((a, i) => { a.vx += (Rn() - .5) * dt * 0.6; a.vy += (Rn() - .5) * dt * 0.6; cl.forEach((b, j) => { if (i === j) return; const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) + 1e-3; if (d < 0.3) { const f = (rep * 0.02 / (d * d) - (1 - rep) * 0.3) * dt; a.vx -= dx / d * f; a.vy -= dy / d * f; } }); a.vx *= 0.9; a.vy *= 0.9; a.x = Math.max(0.05, Math.min(0.95, a.x + a.vx * dt)); a.y = Math.max(0.05, Math.min(0.95, a.y + a.vy * dt)); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const settle = Math.min(1, (t % 14) / 8);
      // jars
      const jx0 = 10, jw = wd ? (W * 0.55 - 20) / 6 : (W - 20) / 6, jy = 30, jh = wd ? H * 0.38 : 110;
      DOSES.forEach((d, i) => { const x = jx0 + i * jw + 3, w = jw - 6, T = turbOf(d), clear = 1 - Math.min(1, T / 80); const tb = (1 - clear * settle); g.fillStyle = `rgba(${150},${120},${80},${0.12 + 0.6 * tb})`; g.fillRect(x, jy, w, jh); g.fillStyle = 'rgba(110,80,50,.85)'; g.fillRect(x, jy + jh - 3 - 10 * clear * settle, w, 3 + 10 * clear * settle); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.strokeRect(x, jy, w, jh); g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(d), x + w / 2, jy - 6); g.font = `8.5px ${col.font}`; g.fillStyle = col.mu; g.fillText(`${bn(Math.round(T))} NTU`, x + w / 2, jy + jh + 11); });
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('ফিটকিরি (mg L⁻¹) →', jx0, 12);
      // micro view
      const mx = wd ? W * 0.58 : 10, my = wd ? 20 : jy + jh + 26, mw = wd ? W * 0.4 : W - 20, mh = wd ? H * 0.5 : 170; g.fillStyle = col.sf; g.strokeStyle = col.line || col.mu; g.lineWidth = 1; rr(g, mx, my, mw, mh, 10); g.fill(); g.stroke();
      const z = zetaOf(dose), nAl = Math.round(dose / 6);
      cl.forEach((a, i) => { const x = mx + 10 + a.x * (mw - 20), y = my + 10 + a.y * (mh - 20); g.fillStyle = '#b08850'; g.beginPath(); g.arc(x, y, 9, 0, 7); g.fill(); g.strokeStyle = 'rgba(0,0,0,.25)'; g.stroke(); for (let k = 0; k < nAl && k < 8; k++) { const aa = k * 0.8 + i; g.fillStyle = '#c0392b'; g.beginPath(); g.arc(x + Math.cos(aa) * 10, y + Math.sin(aa) * 10, 2, 0, 7); g.fill(); } g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(z < -6 ? '−' : z > 6 ? '+' : '০', x, y + 3.5); });
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`পৃষ্ঠ চার্জ (জিটা বিভব) ≈ ${z > 0 ? '+' : ''}${bn(Math.round(z))} mV`, mx + 8, my + mh - 8);
      // curve
      const gx0 = wd ? W * 0.62 : 50, gy0 = wd ? my + mh + 24 : my + mh + 24, gw = wd ? W * 0.35 : W - 64, gh = wd ? H - gy0 - 36 : H - gy0 - 36;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 70, ymax: 80, col, xt: [0, 20, 40, 60], yt: [0, 40, 80], xl: 'ফিটকিরি (mg L⁻¹)', yl: 'NTU', ylx: 28 });
      const pts = []; for (let d = 0; d <= 70; d += 0.5) pts.push([Pl.X(d), Pl.Y(Math.min(80, turbOf(d)))]); path(g, pts, '#a8692b', 2.2); let best = 0; for (let d = 0; d <= 70; d += 0.5) if (turbOf(d) < turbOf(best)) best = d; path(g, [[Pl.X(best), gy0], [Pl.X(best), gy0 + gh]], '#2f9e44', 1, [3, 3]); ball(g, Pl.X(dose), Pl.Y(Math.min(80, turbOf(dose))), 5, '#c0392b', '#fff');
      if (!wd) { /* jars line also on wide */ }
    };
    const info = () => { q('[data-dv]').textContent = bn(dose); const z = zetaOf(dose), T = turbOf(dose); let best = 0; for (let d = 0; d <= 70; d += 0.5) if (turbOf(d) < turbOf(best)) best = d;
      out.innerHTML = `<div>${bn(dose)} mg L⁻¹ এ থিতানোর পর ঘোলাত্ব ≈ <b>${bn(T.toFixed(1))} NTU</b>; সর্বোত্তম মাত্রা ≈ ${bn(best)} mg L⁻¹।</div><div class="small" style="margin-top:4px">${z < -10 ? 'কণাগুলো এখনো ঋণাত্মক — বিকর্ষণে আলাদা থাকে, থিতায় না। আরও ফিটকিরি দরকার।' : z <= 8 ? 'চার্জ প্রায় প্রশমিত — কণা জোড়া লেগে ফ্লক তৈরি করছে, দ্রুত থিতাবে (সর্বোত্তম অঞ্চল)।' : 'অতিরিক্ত Al³⁺ — কণার চার্জ উল্টে ধনাত্মক, আবার বিকর্ষণ (পুনঃস্থিতিশীলতা); ঘোলাত্ব বাড়ছে, পানিতে Al ও অপচয়।'} শুলজে-হার্ডি নিয়ম: Al³⁺ এর জমাটকরণ ক্ষমতা Na⁺ এর প্রায় ১০০০ গুণ।</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    q('[data-d]').oninput = e => { dose = +e.target.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ক্লোরিনেশন: ব্রেকপয়েন্ট ও HOCl/OCl⁻ ======================= */
V.p2c1_chlorine = {
  t: 'ক্লোরিনেশন: ব্রেকপয়েন্ট বক্ররেখা (ক্লোরামিন গঠন ও ভাঙন) এবং pH এর সাথে HOCl/OCl⁻ এর বণ্টন', k: ['int', 'calc', '2d'],
  cap: 'বাম লেখচিত্র: পানিতে যোগ করা ক্লোরিনের বিপরীতে অবশিষ্ট ক্লোরিন। A অঞ্চলে জৈব পদার্থ ও Fe²⁺ ক্লোরিন খেয়ে ফেলে (চাহিদা); B তে NH₃ থেকে ক্লোরামিন (যুক্ত অবশিষ্ট) তৈরি হয়; C তে ক্লোরামিন জারিত হয়ে N₂ — অবশিষ্ট কমে ব্রেকপয়েন্টে পৌঁছায়; D তে সব ক্লোরিন মুক্ত অবশিষ্ট। ডান লেখচিত্র: pH এর সাথে HOCl (কার্যকর, সবুজ) ও OCl⁻ (দুর্বল, নীল) এর ভগ্নাংশ। স্লাইডারে মাত্রা, NH₃ এবং pH বদলাও — নিচে কার্যকর HOCl এর হিসাব।',
  html: () => `${X.cv('ক্লোরিনেশন')}<div class="ctl"><label class="small" style="flex:1;min-width:110px">ক্লোরিন মাত্রা = <b data-cv></b> mg L⁻¹<input type="range" min="0" max="10" step="0.1" value="6" data-c></label><label class="small" style="flex:1;min-width:110px">NH₃-N = <b data-nv></b> mg L⁻¹<input type="range" min="0" max="1" step="0.05" value="0.5" data-n></label><label class="small" style="flex:1;min-width:110px">pH = <b data-pv></b><input type="range" min="5" max="10" step="0.1" value="7.2" data-p></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 280 : 520;
    let L = X.fit(c, hf), dose = 6, N = 0.5, pH = 7.2; const D0 = 0.6;
    const resid = d => { const a = D0, b = D0 + 5 * N, bp = D0 + 7.6 * N; if (d <= a) return { comb: 0, free: 0 }; if (d <= b) return { comb: d - a, free: 0 }; if (d <= bp) { const peak = b - a; return { comb: Math.max(0.05 * N * 4, peak * (bp - d) / (bp - b)), free: 0 }; } return { comb: 0.2 * N, free: d - bp }; };
    const alpha = p => 1 / (1 + Math.pow(10, p - 7.5));
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const g1 = wd ? [50, 18, W * 0.45 - 50, H - 60] : [50, 18, W - 66, H * 0.42];
      const P1 = cplot(g, { x0: g1[0], y0: g1[1], w: g1[2], h: g1[3], xmax: 10, ymax: 6, col, xt: [0, 2, 4, 6, 8, 10], yt: [0, 2, 4, 6], xl: 'যোগ করা ক্লোরিন (mg L⁻¹)', yl: 'অবশিষ্ট (mg L⁻¹)', ylx: 30 });
      const a = D0, b = D0 + 5 * N, bp = D0 + 7.6 * N; [[0, a, 'A'], [a, b, 'B'], [b, bp, 'C'], [bp, 10, 'D']].forEach(([x1, x2, lb], i) => { if (x2 <= x1) return; g.fillStyle = ['rgba(150,150,150,.1)', 'rgba(45,111,214,.08)', 'rgba(192,57,43,.08)', 'rgba(47,158,68,.08)'][i]; g.fillRect(P1.X(x1), g1[1], P1.X(x2) - P1.X(x1), g1[3]); g.fillStyle = col.mu; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(lb, (P1.X(x1) + P1.X(x2)) / 2, g1[1] + 12); });
      const pt = [], pf = []; for (let d = 0; d <= 10; d += 0.05) { const r = resid(d); pt.push([P1.X(d), P1.Y(Math.min(6, r.comb + r.free))]); pf.push([P1.X(d), P1.Y(Math.min(6, r.free))]); } path(g, pt, '#7b3fa0', 2.4); path(g, pf, '#2f9e44', 1.6, [5, 3]);
      if (N > 0) { ball(g, P1.X(bp), P1.Y(resid(bp + 0.001).comb), 4, '#c0392b', '#fff'); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('ব্রেকপয়েন্ট', P1.X(bp) + 6, P1.Y(resid(bp + 0.001).comb) - 4); }
      const r0 = resid(dose); ball(g, P1.X(dose), P1.Y(Math.min(6, r0.comb + r0.free)), 5.5, '#7b3fa0', '#fff');
      legend(g, col, g1[0] + 4, g1[1] + 18, [['#7b3fa0', 'মোট অবশিষ্ট'], ['#2f9e44', 'মুক্ত অবশিষ্ট', [5, 3]]], false);
      const g2 = wd ? [W * 0.55 + 30, 18, W * 0.45 - 46, H - 60] : [50, H * 0.42 + 70, W - 66, H * 0.58 - 112];
      const P2c = cplot(g, { x0: g2[0], y0: g2[1], w: g2[2], h: g2[3], xmin: 5, xmax: 10, ymax: 100, col, xt: [5, 6, 7, 8, 9, 10], yt: [0, 50, 100], xl: 'pH', yl: '%', ylx: 26 });
      const ph1 = [], ph2 = []; for (let p = 5; p <= 10; p += 0.05) { ph1.push([P2c.X(p), P2c.Y(alpha(p) * 100)]); ph2.push([P2c.X(p), P2c.Y((1 - alpha(p)) * 100)]); } path(g, ph1, '#2f9e44', 2.4); path(g, ph2, '#2d6fd6', 2.4); path(g, [[P2c.X(7.5), g2[1]], [P2c.X(7.5), g2[1] + g2[3]]], col.mu, 1, [3, 3]); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('pKa ৭.৫', P2c.X(7.55), g2[1] + 10);
      ball(g, P2c.X(pH), P2c.Y(alpha(pH) * 100), 5, '#2f9e44', '#fff'); legend(g, col, g2[0] + g2[2], g2[1] + g2[3] * 0.35, [['#2f9e44', 'HOCl'], ['#2d6fd6', 'OCl⁻']], true);
    };
    const info = () => { q('[data-cv]').textContent = bn(dose.toFixed(1)); q('[data-nv]').textContent = bn(N.toFixed(2)); q('[data-pv]').textContent = bn(pH.toFixed(1)); const r = resid(dose), al = alpha(pH), bp = D0 + 7.6 * N;
      out.innerHTML = TXB(`\\alpha_{\\ce{HOCl}} = \\dfrac{1}{1+10^{${pH.toFixed(1)}-7.5}} = ${(al * 100).toFixed(0)}\\%`) + `<div class="small">মুক্ত অবশিষ্ট ক্লোরিন ${bn(r.free.toFixed(2))} mg L⁻¹ ⇒ কার্যকর HOCl ≈ <b>${bn((r.free * al).toFixed(2))} mg L⁻¹</b>; যুক্ত (ক্লোরামিন) ${bn(r.comb.toFixed(2))}। ব্রেকপয়েন্ট ≈ ${bn(bp.toFixed(1))} mg L⁻¹ (Cl₂ : NH₃-N ≈ ৭.৬ : ১, সাথে চাহিদা ${bn(D0)})। ${dose < bp ? 'এখনো ব্রেকপয়েন্টের আগে — মুক্ত ক্লোরিন নেই, জীবাণুনাশ দুর্বল।' : r.free > 0.5 ? 'মুক্ত অবশিষ্ট সুপারিশকৃত (০.২–০.৫) সীমার বেশি — স্বাদ-গন্ধ ও অপচয়।' : 'সঠিক অঞ্চল।'}</div>`; };
    [['c', v => dose = v], ['n', v => N = v], ['p', v => pH = v]].forEach(([k, s]) => { q(`[data-${k}]`).oninput = e => { s(+e.target.value); info(); draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= শিল্প বর্জ্য শোধনাগার (ETP) ======================= */
const ETPIN = { tex: ['টেক্সটাইল ডাইং', { pH: 11.5, bod: 400, cod: 1400, tss: 600, col: 1 }], tan: ['ট্যানারি', { pH: 4.0, bod: 1500, cod: 4500, tss: 2000, col: 0.6, cr: 250 }], dom: ['গৃহস্থালি পয়ঃ', { pH: 7.2, bod: 250, cod: 500, tss: 300, col: 0.2 }] };
const ETPST = [['eq', 'সমতাকরণ'], ['neu', 'প্রশমন'], ['coag', 'জমাটকরণ + প্রাথমিক থিতানো'], ['aer', 'বায়ুমিশ্রণ (সক্রিয় কাদা)'], ['sec', 'মাধ্যমিক থিতানো'], ['adv', 'ফেন্টন/ওজোন'], ['ac', 'সক্রিয় কার্বন']];
V.p2c1_etp = {
  t: 'শিল্প বর্জ্য শোধনাগার (ETP): ধাপে ধাপে pH, BOD, COD ও TSS এর পরিবর্তন এবং নির্গমন মানদণ্ডের সাথে তুলনা', k: ['anim', 'int', 'calc', '2d'],
  cap: 'উপরে ETP এর প্রবাহচিত্র — বর্জ্য বাম থেকে ডানে; বায়ুমিশ্রণ ট্যাংকে বুদবুদ, মাধ্যমিক থিতানো থেকে কাদার একটি অংশ ফেরত (বাঁকা তীর), বাকি কাদা ডাইজেস্টারে বায়োগ্যাস। নিচে প্রতিটি ধাপের পরে BOD, COD, TSS (দণ্ড) ও pH; লাল ড্যাশ নির্গমন সীমা। বর্জ্যের উৎস বদলাও এবং ধাপগুলো চালু/বন্ধ করো — যেমন প্রশমন বন্ধ করলে ক্ষারীয় টেক্সটাইল বর্জ্যে সক্রিয় কাদার ব্যাকটেরিয়া মারা যায়, BOD আর কমে না।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('src', [['tex', 'টেক্সটাইল'], ['tan', 'ট্যানারি'], ['dom', 'গৃহস্থালি']], 'tex')}</div><div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${ETPST.map(s => `<label class="small"><input type="checkbox" data-st="${s[0]}" ${s[0] === 'adv' || s[0] === 'ac' ? '' : 'checked'}> ${s[1]}</label>`).join('')}</div>${X.cv('ETP')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 360 : 540;
    let L = X.fit(c, hf), src = 'tex', t = 0; const on = { eq: 1, neu: 1, coag: 1, aer: 1, sec: 1, adv: 0, ac: 0 };
    const run = () => { const I = ETPIN[src][1]; let s = { pH: I.pH, bod: I.bod, cod: I.cod, tss: I.tss, cr: I.cr || 0 }; const R = [['আগত', { ...s }]]; let alive = true; const refr = (I.cod - I.bod) / I.cod * (src === 'dom' ? 0.6 : 1) ;
      if (on.eq) { s.pH = s.pH + (7.5 - s.pH) * 0.15; R.push(['সমতা', { ...s }]); }
      if (on.neu) { s.pH = 7.5; R.push(['প্রশমন', { ...s }]); }
      if (on.coag) { s.tss *= 0.3; s.bod *= 0.7; s.cod *= 0.65; s.cr *= 0.02; R.push(['প্রাথমিক', { ...s }]); }
      if (s.pH < 5.5 || s.pH > 9.5 || s.cr > 20) alive = false;
      if (on.aer && on.sec) { if (alive) { const bio = s.bod * 0.92; s.bod -= bio; s.cod -= bio * 1.1; s.tss = Math.max(30, s.tss * 0.25); } else { s.bod *= 0.95; s.cod *= 0.97; } R.push(['জৈবিক', { ...s }]); }
      if (on.adv) { const nb = s.cod - s.bod * 1.4; s.cod -= nb * 0.6; s.bod += nb * 0.05; R.push(['ফেন্টন', { ...s }]); if (on.aer && alive) { /* already */ } }
      if (on.ac) { s.cod *= 0.55; s.bod *= 0.8; s.tss *= 0.8; R.push(['কার্বন', { ...s }]); }
      return { R, alive, refr }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), res = run();
      // flow diagram
      const fy = 20, fh = wd ? 70 : 60, act = ETPST.filter(s => on[s[0]]); const bw = (W - 20) / Math.max(1, act.length);
      act.forEach((s, i) => { const x = 10 + i * bw + 3, w = bw - 6; const aer = s[0] === 'aer'; g.fillStyle = aer ? 'rgba(80,140,200,.35)' : s[0] === 'coag' || s[0] === 'sec' ? 'rgba(150,120,80,.3)' : s[0] === 'adv' ? 'rgba(200,120,200,.3)' : s[0] === 'ac' ? 'rgba(60,60,60,.35)' : 'rgba(120,160,200,.25)'; g.fillRect(x, fy, w, fh); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(x, fy, w, fh);
        if (aer) { for (let k = 0; k < 14; k++) { const bx = x + 4 + ((k * 0.27) % 1) * (w - 8), by = fy + fh - ((t * 30 + k * 17) % fh); g.strokeStyle = res.alive ? 'rgba(255,255,255,.85)' : 'rgba(255,255,255,.3)'; g.beginPath(); g.arc(bx, by, 2.2, 0, 7); g.stroke(); } for (let k = 0; k < 8; k++) rod(g, x + 6 + (k * 0.13 % 1) * (w - 12), fy + 10 + (k * 0.31 % 1) * (fh - 20), k + t, res.alive ? '#2f9e44' : '#888', 0.8); }
        if (s[0] === 'coag' || s[0] === 'sec') { g.fillStyle = 'rgba(110,80,50,.8)'; g.beginPath(); g.moveTo(x + 2, fy + fh - 2); g.lineTo(x + w / 2, fy + fh - 14); g.lineTo(x + w - 2, fy + fh - 2); g.fill(); }
        g.fillStyle = col.fg; g.font = `bold ${wd ? 9.5 : 8.5}px ${col.font}`; g.textAlign = 'center'; const words = s[1].split(' '); const l1 = words.slice(0, Math.ceil(words.length / 2)).join(' '), l2 = words.slice(Math.ceil(words.length / 2)).join(' '); g.fillText(l1, x + w / 2, fy + fh + 12); if (l2) g.fillText(l2, x + w / 2, fy + fh + 23);
        if (i < act.length - 1) { g.strokeStyle = col.mu; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x + w, fy + fh / 2); g.lineTo(x + w + 6, fy + fh / 2); g.stroke(); } });
      const ia = act.findIndex(s => s[0] === 'aer'), is = act.findIndex(s => s[0] === 'sec'); if (ia >= 0 && is >= 0) { const xa = 10 + ia * bw + bw / 2, xs = 10 + is * bw + bw / 2; g.strokeStyle = '#a8692b'; g.lineWidth = 1.6; g.setLineDash([4, 3]); g.beginPath(); g.moveTo(xs, fy); g.quadraticCurveTo((xa + xs) / 2, fy - 18, xa, fy); g.stroke(); g.setLineDash([]); g.fillStyle = '#a8692b'; g.font = `8.5px ${col.font}`; g.fillText('ফেরত কাদা', (xa + xs) / 2, fy - 8 < 8 ? 8 : fy - 8); }
      // parameter chart
      const gx0 = 46, gy0 = fy + fh + 40, gw = W - 60, gh = H - gy0 - 30; const R = res.R; const n = R.length, cw = gw / n;
      const ymax = Math.max(500, ...R.map(r => Math.max(r[1].cod, r[1].tss))); const Y = v => gy0 + gh - gh * Math.sqrt(Math.min(1, v / ymax));
      g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(gx0, gy0); g.lineTo(gx0, gy0 + gh); g.lineTo(gx0 + gw, gy0 + gh); g.stroke();
      [0, 50, 200, 1000, 5000].filter(v => v <= ymax).forEach(v => { g.fillStyle = col.mu; g.font = `8.5px ${col.font}`; g.textAlign = 'right'; g.fillText(bn(v), gx0 - 4, Y(v) + 3); g.globalAlpha = 0.25; g.beginPath(); g.moveTo(gx0, Y(v)); g.lineTo(gx0 + gw, Y(v)); g.stroke(); g.globalAlpha = 1; });
      [[50, '#c0392b', 'BOD সীমা'], [200, '#7b3fa0', 'COD সীমা']].forEach(([v, cc, lb]) => { path(g, [[gx0, Y(v)], [gx0 + gw, Y(v)]], cc, 1, [5, 3]); g.fillStyle = cc; g.font = `8.5px ${col.font}`; g.textAlign = 'right'; g.fillText(lb, gx0 + gw - 2, Y(v) - 3); });
      R.forEach(([nm, s], i) => { const x = gx0 + i * cw + cw * 0.12, w3 = cw * 0.76 / 3; [['bod', '#c0392b'], ['cod', '#7b3fa0'], ['tss', '#a8692b']].forEach(([k, cc], j) => { g.fillStyle = cc; g.fillRect(x + j * w3, Y(s[k]), w3 - 1, gy0 + gh - Y(s[k])); }); g.fillStyle = col.fg; g.font = `${wd ? 9.5 : 8.5}px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + cw * 0.38, gy0 + gh + 12); g.fillStyle = s.pH < 6 || s.pH > 9 ? '#c0392b' : '#2f9e44'; g.font = `bold 9px ${col.font}`; g.fillText(`pH ${bn(s.pH.toFixed(1))}`, x + cw * 0.38, gy0 - 6); });
      legend(g, col, gx0 + gw, gy0 + 2, [['#c0392b', 'BOD'], ['#7b3fa0', 'COD'], ['#a8692b', 'TSS']], true);
    };
    const info = () => { const res = run(), f = res.R[res.R.length - 1][1], I = ETPIN[src][1]; const ok = { pH: f.pH >= 6 && f.pH <= 9, bod: f.bod <= 50, cod: f.cod <= 200, tss: f.tss <= 150 };
      const tick = b => b ? '<span style="color:var(--ok)">✓</span>' : '<span style="color:var(--bad)">✗</span>';
      out.innerHTML = `<div><b>নির্গত পানি:</b> pH ${bn(f.pH.toFixed(1))} ${tick(ok.pH)} · BOD ${bn(Math.round(f.bod))} ${tick(ok.bod)} · COD ${bn(Math.round(f.cod))} ${tick(ok.cod)} · TSS ${bn(Math.round(f.tss))} ${tick(ok.tss)}${src === 'tan' ? ` · Cr ${bn(f.cr.toFixed(1))} mg L⁻¹ ${tick(f.cr <= 0.5)}` : ''}</div><div class="small" style="margin-top:4px">আগত BOD/COD = ${bn((I.bod / I.cod).toFixed(2))}। ${!res.alive && on.aer ? '<b>সক্রিয় কাদা ব্যর্থ!</b> pH বা ক্রোমিয়াম জৈবিক সীমার বাইরে — ব্যাকটেরিয়া মারা গেছে। প্রশমন ও রাসায়নিক জমাটকরণ চালু করো।' : Object.values(ok).every(Boolean) ? 'সব মানদণ্ড পূরণ — নির্গমন অনুমোদনযোগ্য।' : !ok.cod ? 'COD বেশি: জৈব-অবিয়োজ্য রং/রাসায়নিক — ফেন্টন/ওজোন বা সক্রিয় কার্বন যোগ করো।' : 'আরও শোধন প্রয়োজন।'} BOD হিসাব সরলীকৃত মডেল।</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'src', k => { src = k; info(); A.draw(); });
    el.querySelectorAll('[data-st]').forEach(cb => { cb.onchange = () => { on[cb.dataset.st] = cb.checked ? 1 : 0; info(); A.draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= সক্রিয় কাদা: অণুবীক্ষণিক দৃশ্য ও BOD হ্রাস ======================= */
V.p2c1_activated = {
  t: 'সক্রিয় কাদা পদ্ধতির ভেতরে: ব্যাকটেরিয়া জৈব পদার্থ জারিত করে, ফ্লক গঠন, DO ও বায়ুমিশ্রণ সময়ের সাথে BOD হ্রাস', k: ['anim', 'int', 'calc', '2d'],
  cap: 'বায়ুমিশ্রণ ট্যাংকের অণুবীক্ষণিক দৃশ্য: সবুজ ব্যাকটেরিয়া বাদামি জৈব কণা খেয়ে CO₂ ছাড়ে (ছোট বিন্দু) এবং সংখ্যায় বাড়ে; নিচ থেকে O₂ বুদবুদ ওঠে; ব্যাকটেরিয়া জোড়া লেগে ফ্লক তৈরি করে, যা থিতানো সহজ করে। "বায়ুমিশ্রণ" (DO) ও "কাদার ঘনত্ব" (MLSS) বদলাও — ডানের লেখচিত্রে সময়ের সাথে BOD এর হ্রাস। DO শূন্যে নামালে অবায়বীয় অবস্থা — জারণ থেমে যায়, H₂S এর গন্ধ।',
  html: () => `${X.cv('সক্রিয় কাদা')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:110px">DO = <b data-ov></b> mg L⁻¹<input type="range" min="0" max="6" step="0.1" value="2" data-o></label><label class="small" style="flex:1;min-width:110px">MLSS = <b data-mv></b> mg L⁻¹<input type="range" min="500" max="5000" step="100" value="3000" data-m></label><button class="btn sm" data-rs>নতুন ব্যাচ</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 500;
    let L = X.fit(c, hf), DO = 2, MLSS = 3000, t = 0, hr = 0, B = [], Or = [], Bub = [], Co = []; const Rn = X.rng(29); const B0 = 300;
    const kOf = () => 0.00018 * MLSS * DO / (0.5 + DO); // per hour
    const bod = h => B0 * Math.exp(-kOf() * h);
    const init = () => { hr = 0; B = Array.from({ length: Math.round(MLSS / 250) }, () => ({ x: Rn(), y: Rn(), a: Rn() * 6, v: 0.04 + Rn() * 0.05 })); Or = Array.from({ length: 40 }, () => ({ x: Rn(), y: Rn(), s: 2 + Rn() * 2.5 })); Co = []; };
    init();
    const step = dt => { t += dt; hr = Math.min(8, hr + dt * 0.35); const k = kOf(); const tgt = Math.round(40 * bod(hr) / B0); while (Or.length > tgt) { const o = Or.splice(Math.floor(Rn() * Or.length), 1)[0]; for (let i = 0; i < 2; i++) Co.push({ x: o.x, y: o.y, life: 0 }); }
      if (DO > 0.2 && Rn() < dt * 8 * DO / 3) Bub.push({ x: Rn(), y: 1.02 }); Bub.forEach(b => b.y -= dt * 0.35); Bub = Bub.filter(b => b.y > -0.05); Co.forEach(cc => { cc.y -= dt * 0.15; cc.life += dt; }); Co = Co.filter(cc => cc.life < 2.5);
      B.forEach((b, i) => { const sp = DO > 0.2 ? 1 : 0.2; b.a += (Rn() - .5) * dt * 3; b.x += Math.cos(b.a) * b.v * dt * sp; b.y += Math.sin(b.a) * b.v * dt * sp; const fl = hr / 8; const cx = 0.25 + (i % 3) * 0.25, cy = 0.35 + (i % 2) * 0.3; b.x += (cx - b.x) * dt * 0.15 * fl; b.y += (cy - b.y) * dt * 0.15 * fl; b.x = Math.max(0.02, Math.min(0.98, b.x)); b.y = Math.max(0.02, Math.min(0.98, b.y)); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const mx = wd ? 10 : 10, my = 10, mw = wd ? W * 0.5 : W - 20, mh = wd ? H - 20 : H * 0.5; const an = DO <= 0.2;
      const cg = g.createRadialGradient(mx + mw / 2, my + mh / 2, 10, mx + mw / 2, my + mh / 2, Math.max(mw, mh) / 1.4); cg.addColorStop(0, an ? 'rgba(80,80,60,.35)' : 'rgba(170,200,230,.35)'); cg.addColorStop(1, an ? 'rgba(40,40,30,.6)' : 'rgba(110,150,190,.4)'); g.fillStyle = cg; rr(g, mx, my, mw, mh, 14); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.5; rr(g, mx, my, mw, mh, 14); g.stroke();
      g.save(); rr(g, mx, my, mw, mh, 14); g.clip();
      Or.forEach(o => { g.fillStyle = '#8a5a2b'; g.beginPath(); g.arc(mx + o.x * mw, my + o.y * mh, o.s, 0, 7); g.fill(); });
      Bub.forEach(b => { g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 1.2; g.beginPath(); g.arc(mx + b.x * mw, my + b.y * mh, 3.5, 0, 7); g.stroke(); });
      Co.forEach(cc => { g.fillStyle = `rgba(80,80,80,${1 - cc.life / 2.5})`; g.beginPath(); g.arc(mx + cc.x * mw, my + cc.y * mh, 1.4, 0, 7); g.fill(); });
      B.forEach(b => rod(g, mx + b.x * mw, my + b.y * mh, b.a, an ? '#6a6a50' : '#2f9e44', 1.2));
      g.restore();
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`সময়: ${bn(hr.toFixed(1))} ঘণ্টা`, mx + 8, my + 16); if (an) { g.fillStyle = '#c0392b'; g.fillText('অবায়বীয়! H₂S গন্ধ', mx + 8, my + 30); }
      const gx0 = wd ? W * 0.58 : 50, gy0 = wd ? 20 : my + mh + 26, gw = wd ? W * 0.4 : W - 66, gh = wd ? H - 66 : H - gy0 - 40;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 8, ymax: 300, col, xt: [0, 2, 4, 6, 8], yt: [0, 50, 100, 200, 300], xl: 'বায়ুমিশ্রণ সময় (ঘণ্টা)', yl: 'BOD (mg L⁻¹)', ylx: 32 });
      path(g, [[gx0, Pl.Y(50)], [gx0 + gw, Pl.Y(50)]], '#c0392b', 1, [5, 3]); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText('নির্গমন সীমা ৫০', gx0 + gw - 2, Pl.Y(50) - 4);
      const pts = []; for (let h = 0; h <= 8; h += 0.05) pts.push([Pl.X(h), Pl.Y(bod(h))]); path(g, pts, '#2d6fd6', 2.4); ball(g, Pl.X(hr), Pl.Y(bod(hr)), 5, '#2d6fd6', '#fff');
    };
    const info = () => { q('[data-ov]').textContent = bn(DO.toFixed(1)); q('[data-mv]').textContent = bn(MLSS); const k = kOf(); const t50 = k > 0 ? Math.log(B0 / 50) / k : Infinity;
      out.innerHTML = TXB(`\\mathrm{BOD}(t) = \\mathrm{BOD}_0\\,e^{-kt}`) + TXB(`k \\propto \\mathrm{MLSS}\\cdot\\dfrac{\\mathrm{DO}}{0.5+\\mathrm{DO}} = ${k.toFixed(2)}\\ \\mathrm{h^{-1}}`) + `<div class="small">${isFinite(t50) && t50 < 50 ? `BOD ৩০০ থেকে ৫০ এ নামতে প্রায় <b>${bn(t50.toFixed(1))} ঘণ্টা</b> বায়ুমিশ্রণ লাগবে।` : 'এ অবস্থায় BOD কার্যত কমছে না।'} ${DO < 1 ? 'DO ১ এর কম — ব্যাকটেরিয়া অক্সিজেন-সীমিত; ব্লোয়ার বাড়াও।' : DO > 4 ? 'DO অনেক বেশি — হার আর তেমন বাড়ে না, অথচ বিদ্যুৎ অপচয়। সাধারণত ১.৫–২.৫ mg L⁻¹ রাখা হয়।' : 'DO উপযুক্ত সীমায়।'} (সরলীকৃত প্রথম ক্রম মডেল।)</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    q('[data-o]').oninput = e => { DO = +e.target.value; info(); A.draw(); };
    q('[data-m]').oninput = e => { MLSS = +e.target.value; init(); info(); A.draw(); };
    q('[data-rs]').onclick = () => { init(); A.draw(); };
    for (let i = 0; i < 40; i++) step(0.05);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
