/* ২য় পত্র অধ্যায় ১ visuals part 10 — ozone layer, Cl catalytic chain, ozone hole & Montreal (1.12) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const O = (g, x, y, s = 1) => ball(g, x, y, 4.6 * s, '#c0392b', '#ffb3a8');
const O2m = (g, x, y, s = 1, a = 0) => { O(g, x - 4 * s * Math.cos(a), y - 4 * s * Math.sin(a), s); O(g, x + 4 * s * Math.cos(a), y + 4 * s * Math.sin(a), s); };
const O3m = (g, x, y, s = 1) => { O(g, x - 6 * s, y + 3 * s, s); O(g, x + 6 * s, y + 3 * s, s); O(g, x, y - 2.5 * s, s); };
const Clm = (g, x, y, s = 1) => ball(g, x, y, 6 * s, '#2f9e44', '#c8f0cf');
const lbl = (g, col, t, x, y, b) => { g.fillStyle = col.fg; g.font = `${b ? 'bold ' : ''}10px ${col.font}`; g.textAlign = 'center'; g.fillText(t, x, y); };

/* ======================= ওজোন স্তর: উচ্চতা, তাপমাত্রা, UV শোষণ ======================= */
const Tprof = h => h < 12 ? 288 - 6.5 * h : h < 20 ? 216.5 : h < 32 ? 216.5 + (h - 20) : h < 47 ? 228.5 + 2.8 * (h - 32) : h < 51 ? 270.5 : 270.5 - 2.8 * (h - 51);
const O3prof = h => Math.exp(-((h - 24) ** 2) / (2 * 6.2 * 6.2)) * 1 + 0.03;
V.p2c1_ozoneLayer = {
  t: 'বায়ুমণ্ডলের স্তর, ওজোনের উচ্চতা-বণ্টন, তাপমাত্রার রেখা এবং UV-A, UV-B, UV-C এর শোষণ (চ্যাপম্যান চক্রসহ)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বাম অংশে উচ্চতা (০–৬০ km) বনাম তাপমাত্রা (লাল রেখা) ও ওজোনের ঘনত্ব (নীল আকৃতি) — স্ট্র্যাটোস্ফিয়ারে ওজোন UV শোষণ করে বলে সেখানে তাপমাত্রা উচ্চতার সাথে বাড়ে। ডানে উপর থেকে তিন ধরনের UV ফোটন নামছে: বেগুনি UV-C উপরেই থেমে যায়, UV-B বেশির ভাগ ওজোন স্তরে শোষিত হয়, UV-A ভূপৃষ্ঠে পৌঁছায়। মাঝে ওজোন স্তরে চ্যাপম্যান চক্র — O₂ ভেঙে O, O + O₂ → O₃, O₃ ভেঙে আবার O₂ + O। "মোট ওজোন" স্লাইডারে ডবসন একক কমিয়ে দেখো ভূপৃষ্ঠে UV-B কত গুণ বাড়ে (বিয়ার-ল্যাম্বার্ট সূত্র)।',
  html: () => `${X.cv('ওজোন স্তর')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:180px">মোট ওজোন = <b data-dv></b> DU<input type="range" min="100" max="450" step="5" value="300" data-d></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 380 : 520;
    let L = X.fit(c, hf), du = 300, t = 0, Ph = []; const Rn = X.rng(31);
    const SIG = { C: 9e-18, B: 2.5e-19, A: 2e-21 };
    const trans = (k, d) => Math.exp(-SIG[k] * d * 2.687e16);
    const geo = () => { const { W, H } = L, wd = wide(W); const y0 = 16, y1 = H - 26; return { wd, y0, y1, hY: h => y1 - h / 60 * (y1 - y0), lx0: wd ? 54 : 46, lx1: wd ? W * 0.5 : W * 0.5, rx0: wd ? W * 0.56 : W * 0.55, rx1: W - 8 }; };
    const absorbH = (k, d) => { // altitude at which photon is absorbed (random by optical depth)
      const tot = SIG[k] * d * 2.687e16, u = -Math.log(Math.max(1e-9, Rn())); if (u > tot) return -1; let acc = 0; const norm = (() => { let s = 0; for (let h = 0; h <= 60; h += 0.5) s += O3prof(h); return s; })(); for (let h = 60; h >= 0; h -= 0.5) { acc += O3prof(h) / norm * tot; if (acc >= u) return h; } return -1; };
    const step = dt => { t += dt; const { rx0, rx1 } = geo(); if (Rn() < dt * 6) { const r = Rn(), k = r < 0.33 ? 'C' : r < 0.66 ? 'B' : 'A'; const lane = k === 'C' ? 0.2 : k === 'B' ? 0.5 : 0.8; Ph.push({ k, x: lane + (Rn() - .5) * 0.18, h: 62, stop: k === 'C' ? 40 + Rn() * 15 : absorbH(k, du), boom: 0 }); }
      Ph.forEach(p => { if (p.boom > 0) { p.boom += dt; if (p.boom > 0.6) p.dead = true; return; } p.h -= dt * 14; if (p.h <= p.stop) { p.boom = 0.01; p.h = Math.max(0, p.stop); } if (p.h < 0) p.dead = true; }); Ph = Ph.filter(p => !p.dead); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo(), { wd, y0, y1, hY, lx0, lx1, rx0, rx1 } = G;
      // layer bands across both panels
      [[0, 12, 'ট্রপোস্ফিয়ার', 'rgba(120,180,240,.16)'], [12, 50, 'স্ট্র্যাটোস্ফিয়ার', 'rgba(160,140,230,.12)'], [50, 60, 'মেসোস্ফিয়ার', 'rgba(90,90,140,.14)']].forEach(([a, b, nm, cl]) => { g.fillStyle = cl; g.fillRect(lx0, hY(b), rx1 - lx0, hY(a) - hY(b)); g.fillStyle = col.mu; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(nm, lx0 + 4, hY(b) + 12); });
      // ozone layer glow on right panel
      for (let h = 10; h < 40; h += 1) { g.fillStyle = `rgba(80,140,255,${0.28 * O3prof(h) * du / 300})`; g.fillRect(rx0, hY(h + 1), rx1 - rx0, hY(h) - hY(h + 1) + 0.5); }
      // axes left
      g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(lx0, y0 - 4); g.lineTo(lx0, y1); g.lineTo(lx1, y1); g.stroke();
      [0, 10, 20, 30, 40, 50, 60].forEach(h => { g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText(bn(h), lx0 - 4, hY(h) + 3); });
      g.save(); g.translate(lx0 - 30, (y0 + y1) / 2); g.rotate(-Math.PI / 2); g.fillStyle = col.fg; g.font = `10.5px ${col.font}`; g.textAlign = 'center'; g.fillText('উচ্চতা (km)', 0, 0); g.restore();
      const Tx = T => lx0 + (T - 180) / (300 - 180) * (lx1 - lx0); const pts = []; for (let h = 0; h <= 60; h += 0.5) pts.push([Tx(Tprof(h)), hY(h)]); path(g, pts, '#d63a2a', 2.4);
      [200, 250, 300].forEach(T => { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(T) + ' K', Tx(T), y1 + 12); });
      const Ox = v => lx0 + v * (lx1 - lx0) * 0.75 * du / 300; g.fillStyle = 'rgba(45,111,214,.3)'; g.strokeStyle = '#2d6fd6'; g.lineWidth = 1.8; g.beginPath(); g.moveTo(lx0, hY(0)); for (let h = 0; h <= 60; h += 0.5) g.lineTo(Ox(O3prof(h)), hY(h)); g.lineTo(lx0, hY(60)); g.closePath(); g.fill(); g.stroke();
      legend(g, col, lx1, y0 + 2, [['#d63a2a', 'তাপমাত্রা'], ['#2d6fd6', 'ওজোন ঘনত্ব']], true);
      // right panel: photons
      g.fillStyle = col.mu; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; [['C', 0.2, 'UV-C'], ['B', 0.5, 'UV-B'], ['A', 0.8, 'UV-A']].forEach(([k, f, nm]) => g.fillText(wd ? nm : k, rx0 + f * (rx1 - rx0), y0 + 2));
      const PC = { C: '#8a3fd0', B: '#d04aa0', A: '#5a7de0' };
      Ph.forEach(p => { const x = rx0 + p.x * (rx1 - rx0), y = hY(p.h); if (y < y0 + 26) return; if (p.boom > 0) { g.fillStyle = `rgba(255,170,60,${1 - p.boom / 0.6})`; g.beginPath(); g.arc(x, y, 3 + p.boom * 14, 0, 7); g.fill(); return; } g.strokeStyle = PC[p.k]; g.lineWidth = 1.8; g.beginPath(); for (let s = 0; s <= 18; s += 1) { const yy = y - 18 + s, xx = x + Math.sin((s + t * 40) / (p.k === 'C' ? 1.4 : p.k === 'B' ? 2 : 2.8)) * 3; s ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.stroke(); });
      // ground
      g.fillStyle = '#6b8e4e'; g.fillRect(rx0, y1, rx1 - rx0, 6); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('ভূপৃষ্ঠ', (rx0 + rx1) / 2, y1 + 16);
      // Chapman mini-cycle near 25 km
      const cx = (rx0 + rx1) / 2, cy = hY(25), ph = (t * 0.35) % 1, s = wd ? 1 : 0.85;
      g.fillStyle = col.sf; g.globalAlpha = 0.86; rr(g, cx - 62 * s, cy - 26 * s, 124 * s, 52 * s, 10); g.fill(); g.globalAlpha = 1; g.strokeStyle = col.line || col.mu; g.lineWidth = 1; g.stroke();
      if (ph < 0.33) { const u = ph / 0.33; O2m(g, cx - 30 * s - u * 0, cy, s * 0.9); g.strokeStyle = '#8a3fd0'; g.lineWidth = 1.5; g.beginPath(); for (let k = 0; k < 14; k++) g.lineTo(cx - 54 * s + k * 2 * u, cy - 18 * s + k * 1.2 * u); g.stroke(); if (u > 0.7) { O(g, cx - 38 * s, cy - 6 * s, s * 0.9); O(g, cx - 22 * s, cy + 6 * s, s * 0.9); } lbl(g, col, 'O₂ + hν → 2O', cx, cy + 20 * s, true); }
      else if (ph < 0.66) { const u = (ph - 0.33) / 0.33; O(g, cx - 30 * s + u * 22 * s, cy, s * 0.9); O2m(g, cx + 22 * s - u * 4 * s, cy, s * 0.9); if (u > 0.8) { g.fillStyle = 'rgba(255,170,60,.5)'; g.beginPath(); g.arc(cx, cy, 14 * s, 0, 7); g.fill(); } lbl(g, col, 'O + O₂ + M → O₃ + তাপ', cx, cy + 20 * s, true); }
      else { const u = (ph - 0.66) / 0.34; O3m(g, cx, cy - 2 * s, s * 0.9); g.strokeStyle = '#d04aa0'; g.lineWidth = 1.5; g.beginPath(); for (let k = 0; k < 14; k++) g.lineTo(cx + 54 * s - k * 2 * u, cy - 18 * s + k * 1.2 * u); g.stroke(); lbl(g, col, 'O₃ + hν (UV-B) → O₂ + O', cx, cy + 20 * s, true); }
    };
    const info = () => { q('[data-dv]').textContent = bn(du); const tb = trans('B', du), t300 = trans('B', 300), mm = du / 100;
      out.innerHTML = TXB(`\\begin{aligned}\\frac{I}{I_0} &= e^{-\\sigma N}\\\\ N &= ${du}\\times2.687\\times10^{16}\\ \\mathrm{cm^{-2}}\\\\ \\frac{I}{I_0}\\Big|_{305\\,\\mathrm{nm}} &= ${(tb * 100).toFixed(1)}\\%\\end{aligned}`) + `<div class="small">${bn(du)} DU = STP তে ${bn(mm.toFixed(2))} mm পুরু স্তর। ৩০০ DU এর তুলনায় ভূপৃষ্ঠে UV-B <b>${bn((tb / t300).toFixed(2))} গুণ</b>। UV-C কার্যত শূন্য, UV-A প্রায় সম্পূর্ণ (${bn(Math.round(trans('A', du) * 100))}%)। ${du < 220 ? '<b>ওজোন গহ্বর</b> (< ২২০ DU) — ত্বকের ক্যান্সার ও ছানির ঝুঁকি উল্লেখযোগ্যভাবে বেশি।' : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    q('[data-d]').oninput = e => { du = +e.target.value; Ph = []; info(); A.draw(); };
    for (let i = 0; i < 100; i++) step(0.04);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ক্লোরিনের অনুঘটকীয় শৃঙ্খল ======================= */
V.p2c1_clchain = {
  t: 'CFC থেকে মুক্ত ক্লোরিনের অনুঘটকীয় শৃঙ্খল বিক্রিয়া: Cl• + O₃ → ClO• + O₂, ClO• + O → Cl• + O₂ (অ্যানিমেশন ও গণক)', k: ['anim', 'int', '2d'],
  cap: 'বাম থেকে একটি CF₂Cl₂ অণু UV ফোটনে ভেঙে সবুজ Cl• পরমাণু মুক্ত করে। Cl• চক্রে ঢুকে উপরের পথে একটি O₃ এর সাথে বিক্রিয়া করে ClO• ও O₂ তৈরি করে; নিচের পথে ClO• একটি পারমাণবিক O এর সাথে মিলে আবার Cl• ফেরত দেয় — চক্র চলতেই থাকে, গণকে ধ্বংসকৃত O₃ বাড়ে। "CH₄ এ আটকাও" চাপলে Cl• সংরক্ষণাগার HCl এ বন্দি হয়ে চক্র থামে; "PSC তে মুক্ত করো" চাপলে মেরু মেঘের বরফে আবার Cl₂ হয়ে সূর্যালোকে মুক্ত হয়। গতি বাড়িয়ে দেখো গণক কত দ্রুত লক্ষের ঘরে পৌঁছায়।',
  html: () => `${X.cv('ক্লোরিন চক্র')}<div class="ctl" style="flex-wrap:wrap"><button class="btn sm" data-pp></button><button class="btn sm" data-trap>CH₄ এ আটকাও (HCl)</button><button class="btn sm" data-psc>PSC তে মুক্ত করো</button><label class="small" style="flex:1;min-width:120px">গতি ×<b data-sv></b><input type="range" min="0" max="4" step="1" value="0" data-s></label><button class="btn sm" data-reset>শুরু থেকে</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 400;
    let L = X.fit(c, hf), st = 'init', ph = 0, cnt = 0, spIdx = 0, trapped = false, t = 0;
    const SPD = [1, 3, 10, 100, 1000];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const cx = wd ? W * 0.56 : W * 0.55, cy = H * 0.46, r = Math.min(wd ? 110 : 90, H * 0.3), s = wd ? 1.1 : 0.9;
      // background strat
      const bg = g.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, 'rgba(60,50,130,.18)'); bg.addColorStop(1, 'rgba(110,160,230,.12)'); g.fillStyle = bg; g.fillRect(0, 0, W, H);
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('স্ট্র্যাটোস্ফিয়ার (~২০–৪০ km)', 8, 14);
      // cycle arcs
      g.strokeStyle = col.mu; g.lineWidth = 2; g.setLineDash([5, 4]); g.beginPath(); g.arc(cx, cy, r, 0, 7); g.stroke(); g.setLineDash([]);
      const nodeL = [cx - r, cy], nodeR = [cx + r, cy];
      [[nodeL, 'Cl•', '#2f9e44'], [nodeR, 'ClO•', '#6a8e2e']].forEach(([[x, y], t2, cl]) => { g.fillStyle = col.sf; g.strokeStyle = cl; g.lineWidth = 2; g.beginPath(); g.arc(x, y, 20 * s, 0, 7); g.fill(); g.stroke(); g.fillStyle = cl; g.font = `bold ${Math.round(12 * s)}px ${col.font}`; g.textAlign = 'center'; g.fillText(t2, x, y + 4); });
      // arrows on arc
      [[-Math.PI / 2, 1], [Math.PI / 2, -1]].forEach(([a, d]) => { const x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); g.fillStyle = col.mu; g.beginPath(); g.moveTo(x + 8 * d, y); g.lineTo(x - 4 * d, y - 6); g.lineTo(x - 4 * d, y + 6); g.fill(); });
      lbl(g, col, 'Cl• + O₃ → ClO• + O₂', cx, cy - r - 30 * s, true); lbl(g, col, 'ClO• + O → Cl• + O₂', cx, cy + r + 38 * s, true);
      // init: CFC
      const fx0 = wd ? 70 : 30, fy0 = wd ? cy : 46;
      if (st === 'init') { const u = Math.min(1, ph); const mx = fx0, my = fy0; ball(g, mx, my, 8 * s, '#333', '#999'); ball(g, mx - 11 * s, my - 7 * s, 5 * s, '#e0c020', '#fff6a8'); ball(g, mx - 11 * s, my + 7 * s, 5 * s, '#e0c020', '#fff6a8'); ball(g, mx + 11 * s, my - 8 * s, 6.5 * s, '#2f9e44', '#c8f0cf'); const clx = u < 0.5 ? mx + 11 * s : mx + 11 * s + (nodeL[0] - mx - 11 * s) * (u - 0.5) / 0.5, cly = u < 0.5 ? my + 8 * s : my + 8 * s + (cy - my - 8 * s) * (u - 0.5) / 0.5; Clm(g, clx, cly, s); if (u < 0.5) { g.strokeStyle = '#8a3fd0'; g.lineWidth = 1.8; g.beginPath(); for (let k = 0; k <= 30; k++) { const xx = mx - 40 + k * 1.5 * u * 2, yy = my - 50 + k * 1.4 * u * 2 + Math.sin(k + t * 30) * 3; k ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.stroke(); } lbl(g, col, 'CF₂Cl₂ + hν', mx, my + 28 * s, false); }
      else { const my = fy0; ball(g, fx0, my, 8 * s, '#333', '#999'); ball(g, fx0 - 11 * s, my - 7 * s, 5 * s, '#e0c020', '#fff6a8'); ball(g, fx0 - 11 * s, my + 7 * s, 5 * s, '#e0c020', '#fff6a8'); ball(g, fx0 + 11 * s, my - 8 * s, 6.5 * s, '#2f9e44', '#c8f0cf'); lbl(g, col, 'CF₂Cl•', fx0 + (wd ? 0 : 6), my + 28 * s, false); }
      // cycle motion
      if (st === 'cycle') { const sp = SPD[spIdx]; if (sp <= 3) { const u = ph % 1; if (u < 0.5) { const a = Math.PI + u / 0.5 * Math.PI, x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); const tgt = [cx, cy - r]; if (u < 0.25) { Clm(g, x, y, s); O3m(g, tgt[0] + (1 - u / 0.25) * 0, tgt[1] - 40 * s * (1 - u / 0.25), s); } else { const v = (u - 0.25) / 0.25; Clm(g, x - 4 * s, y, s); O(g, x + 6 * s, y, s); O2m(g, cx + 30 * s * v, cy - r - 10 * s - 30 * s * v, s, 0.5); } }
        else { const v0 = (u - 0.5) / 0.5, a = v0 * Math.PI, x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); if (v0 < 0.5) { Clm(g, x - 4 * s, y, s); O(g, x + 6 * s, y, s); O(g, cx, cy + r + 40 * s * (1 - v0 / 0.5), s); } else { Clm(g, x, y, s); O2m(g, cx - 30 * s * (v0 - 0.5) * 2, cy + r + 12 * s + 30 * s * (v0 - 0.5) * 2, s, -0.5); } } }
        else { for (let k = 0; k < 10; k++) { const a = (ph * 2 * Math.PI + k * 0.63) % (2 * Math.PI); Clm(g, cx + r * Math.cos(a + Math.PI), cy + r * Math.sin(a + Math.PI), s * 0.6); } } }
      // reservoir box
      const bx = wd ? W - 130 : W - 112, by = H - 54, bw = wd ? 120 : 104; g.fillStyle = col.sf; g.strokeStyle = trapped ? '#c0392b' : col.mu; g.lineWidth = trapped ? 2 : 1; rr(g, bx, by, bw, 44, 8); g.fill(); g.stroke(); g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('সংরক্ষণাগার', bx + bw / 2, by + 13); if (trapped) { ball(g, bx + bw / 2 - 6, by + 30, 4, '#ddd', '#fff'); Clm(g, bx + bw / 2 + 4, by + 30, 0.8); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText('HCl', bx + bw / 2 + 28, by + 33); }
      // counter
      g.fillStyle = col.fg; g.font = `bold ${wd ? 22 : 18}px ${col.font}`; g.textAlign = 'left'; g.fillText(bn(Math.floor(cnt).toLocaleString('en-US')), 10, H - 26); g.font = `10px ${col.font}`; g.fillText('টি O₃ অণু ধ্বংস (১টি Cl দ্বারা)', 10, H - 10);
    };
    const info = () => { q('[data-sv]').textContent = bn(SPD[spIdx]); q('[data-trap]').classList.toggle('primary', trapped);
      out.innerHTML = (st === 'init' ? '<div><b>সূচনা:</b> UV-C (λ < ২২০ nm) C–Cl বন্ধন ভাঙে (C–F অটুট থাকে, কারণ C–F বন্ধন অনেক দৃঢ়)।</div>' + TXB('\\ce{CF2Cl2 ->[h\\nu] CF2Cl^{\\bullet} + Cl^{\\bullet}}')
        : trapped ? '<div><b>সমাপ্তি:</b> Cl• মিথেনের সাথে বিক্রিয়ায় HCl সংরক্ষণাগারে বন্দি — চক্র থেমেছে।</div>' + TXB('\\ce{Cl^{\\bullet} + CH4 -> HCl + CH3^{\\bullet}}') + '<div class="small">মেরু শীতে PSC এর বরফ-পৃষ্ঠে: HCl + ClONO₂ → Cl₂ + HNO₃; বসন্তের সূর্যে Cl₂ + hν → 2Cl• — চক্র আবার শুরু।</div>'
        : '<div><b>বিস্তার চক্র</b> (Cl• প্রতি চক্রে ফিরে আসে — অনুঘটক):</div>' + TXB('\\begin{aligned}\\ce{Cl^{\\bullet} + O3 &-> ClO^{\\bullet} + O2}\\\\ \\ce{ClO^{\\bullet} + O &-> Cl^{\\bullet} + O2}\\\\ \\hline \\text{নিট: }\\ce{O3 + O &-> 2O2}\\end{aligned}')) + `<div class="small">${cnt >= 1e5 ? '১ লক্ষ ছাড়িয়েছে — বাস্তবে গড়ে এ পর্যায়ে Cl সংরক্ষণাগারে চলে যায়।' : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; const sp = SPD[spIdx];
        if (st === 'init') { ph += dt * 0.5; if (ph >= 1) { st = 'cycle'; ph = 0; info(); } }
        else if (st === 'cycle' && !trapped) { const before = Math.floor(ph); ph += dt * 0.45 * sp; const n = Math.floor(ph) - before; if (n > 0) { cnt += n; if (cnt >= 1e5 && cnt - n < 1e5) info(); } } }
      draw(); }, { paused: false }); X.pp(el, A);
    q('[data-trap]').onclick = () => { if (st === 'init') return; trapped = true; info(); A.draw(); };
    q('[data-psc]').onclick = () => { trapped = false; info(); A.draw(); };
    q('[data-s]').oninput = e => { spIdx = +e.target.value; info(); };
    q('[data-reset]').onclick = () => { st = 'init'; ph = 0; cnt = 0; trapped = false; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ওজোন গহ্বর ও মন্ট্রিল প্রটোকল ======================= */
function ozRun(prot) { let B = 0.5; const o = {}; const tau = 82;
  for (let i = 0; i <= 1700; i++) { const y = 1930 + i * 0.1; let E; if (y < 1950) E = 0.1 * (y - 1930) / 20; else if (y < 1974) E = 0.1 + 0.9 * (y - 1950) / 24; else if (!prot) E = Math.pow(1.03, y - 1974); else if (y < 1988) E = 1; else if (y < 1996) E = 1 - 0.9 * (y - 1988) / 8; else E = Math.max(0.03, 0.15 * Math.exp(-(y - 1996) / 25)); B += (E - B / tau) * 0.1; o[i] = B; } return o; }
const OZP = ozRun(true), OZN = ozRun(false);
const eesc = (o, y) => o[Math.max(0, Math.min(1700, Math.round((y - 4 - 1930) * 10)))];
const OZE0 = eesc(OZP, 1972), OZK = -205 * Math.log(1 - 75 / 205) / (eesc(OZP, 1980) - OZE0);
const ozMin = (o, y) => 300 - 205 * (1 - Math.exp(-OZK * Math.max(0, eesc(o, y) - OZE0) / 205));
const duCol = d => { const st = [[100, [120, 30, 140]], [150, [60, 60, 200]], [220, [40, 150, 220]], [300, [60, 190, 90]], [380, [230, 200, 50]], [450, [220, 90, 40]]]; for (let i = 1; i < st.length; i++) if (d <= st[i][0]) { const [a, ca] = st[i - 1], [b, cb] = st[i], u = Math.max(0, (d - a) / (b - a)); return `rgb(${ca.map((v, k) => Math.round(v + (cb[k] - v) * u)).join(',')})`; } return 'rgb(220,90,40)'; };
V.p2c1_ozoneHole = {
  t: 'অ্যান্টার্কটিকার ওজোন গহ্বর ১৯৬০–২১০০: মন্ট্রিল প্রটোকল থাকলে ও না থাকলে (সরলীকৃত মডেল ও মেরু মানচিত্র)', k: ['int', 'anim', '2d', 'calc'],
  cap: 'বামে দক্ষিণ মেরুর উপর থেকে দেখা মানচিত্র — রং মোট ওজোন (DU): বেগুনি-নীল গহ্বর (< ২২০ DU), সবুজ স্বাভাবিক। বছর স্লাইডার টানো বা চালু করো: ১৯৮০ এর দশকে গহ্বর দেখা দেয়, ২০০০ এর আশেপাশে সবচেয়ে গভীর, তারপর ধীরে সেরে ওঠে। ডানের লেখচিত্রে অক্টোবরের ন্যূনতম ওজোন: সবুজ রেখা মন্ট্রিল প্রটোকলসহ, লাল ড্যাশ রেখা প্রটোকল না থাকলে (CFC নির্গমন বছরে ৩% হারে বাড়তে থাকলে)। মডেলটি সরলীকৃত — বায়ুমণ্ডলে CFC এর স্থায়িত্ব (~৮০ বছর) ও কয়েক বছরের বিলম্ব ধরে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('sc', [['p', 'মন্ট্রিল প্রটোকলসহ'], ['n', 'প্রটোকল না থাকলে']], 'p')}</div>${X.cv('ওজোন গহ্বর')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:180px">বছর = <b data-yv></b><input type="range" min="1960" max="2100" step="1" value="1960" data-y></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 560;
    let L = X.fit(c, hf), sc = 'p', yr = 2000, t = 0;
    const cur = () => sc === 'p' ? OZP : OZN;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), d = ozMin(cur(), yr);
      // polar map
      const mx = wd ? W * 0.22 : W / 2, my = wd ? H * 0.47 : 140, mr = wd ? Math.min(W * 0.19, H * 0.42) : 118;
      const img = g.createImageData ? null : null; // draw rings
      for (let rr2 = mr; rr2 > 0; rr2 -= 2) { for (let a = 0; a < Math.PI * 2; a += Math.PI / 36) { const rf = rr2 / mr, wob = 0.12 * Math.sin(3 * a + yr * 0.7) + 0.06 * Math.sin(5 * a - t * 0.5); const holeR = 0.55 + wob; const inside = Math.max(0, 1 - (rf / holeR) ** 4); const dd = d + (360 - d) * (1 - inside) * Math.min(1, rf / holeR) + (rf > holeR ? (rf - holeR) * 60 : 0); g.fillStyle = duCol(Math.min(450, dd)); g.beginPath(); g.moveTo(mx, my); g.arc(mx, my, rr2, a, a + Math.PI / 36 + 0.01); g.closePath(); g.fill(); } }
      // Antarctica outline (stylised)
      g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 1.6; g.beginPath(); for (let a = 0; a <= Math.PI * 2 + 0.01; a += 0.05) { const rad = mr * (0.36 + 0.05 * Math.sin(2 * a + 1) + 0.04 * Math.sin(5 * a) + (a > 2.4 && a < 3.4 ? 0.08 * Math.sin((a - 2.4) / 1 * Math.PI) : 0)); const x = mx + rad * Math.cos(a), y = my + rad * Math.sin(a); a ? g.lineTo(x, y) : g.moveTo(x, y); } g.closePath(); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1; g.beginPath(); g.arc(mx, my, mr, 0, 7); g.stroke();
      g.fillStyle = '#fff'; g.font = `bold ${wd ? 18 : 16}px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(Math.floor(yr)), mx, my - mr + 22); g.font = `bold 11px ${col.font}`; g.fillText(`${bn(Math.round(d))} DU`, mx, my + 4);
      // colour bar
      const cbx = mx - mr, cby = my + mr + 10, cbw = 2 * mr; for (let i = 0; i < cbw; i++) { g.fillStyle = duCol(100 + i / cbw * 350); g.fillRect(cbx + i, cby, 1.2, 8); } [100, 220, 300, 450].forEach(v => { const x = cbx + (v - 100) / 350 * cbw; g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(v), x, cby + 19); }); g.textAlign = 'left'; g.fillText('DU', cbx, cby - 3);
      // chart
      const gx0 = wd ? W * 0.5 : 54, gy0 = wd ? 18 : cby + 44, gw = wd ? W - gx0 - 16 : W - 70, gh = wd ? H - 60 : H - gy0 - 44;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: 1960, xmax: 2100, ymin: 50, ymax: 350, col, xt: wd ? [1960, 1980, 2000, 2020, 2040, 2060, 2080, 2100] : [1960, 2000, 2040, 2080], yt: [100, 150, 200, 250, 300, 350], xl: 'বছর', yl: 'অক্টোবরের ন্যূনতম ওজোন (DU)' });
      g.fillStyle = 'rgba(120,60,200,.1)'; g.fillRect(Pl.X(1960), Pl.Y(220), gw, Pl.Y(50) - Pl.Y(220)); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('গহ্বর (< ২২০ DU)', Pl.X(1962), Pl.Y(215) + 10);
      path(g, [[Pl.X(1987), gy0], [Pl.X(1987), gy0 + gh]], col.mu, 1, [3, 3]); g.fillStyle = col.mu; g.textAlign = 'left'; g.fillText('১৯৮৭: মন্ট্রিল', Pl.X(1988), gy0 + 10);
      [[OZN, '#c0392b', [5, 4]], [OZP, '#2f9e44', []]].forEach(([o, cl, ds]) => { const pts = []; for (let y = 1960; y <= 2100; y += 0.5) pts.push([Pl.X(y), Pl.Y(ozMin(o, y))]); path(g, pts, cl, cur() === o ? 2.8 : 1.6, ds); });
      ball(g, Pl.X(yr), Pl.Y(d), 6, sc === 'p' ? '#2f9e44' : '#c0392b', '#fff');
      legend(g, col, gx0 + gw, gy0 + gh * 0.55, [['#2f9e44', 'প্রটোকলসহ'], ['#c0392b', 'প্রটোকল ছাড়া', [5, 4]]], true);
    };
    const info = () => { q('[data-yv]').textContent = bn(Math.floor(yr)); const d = ozMin(cur(), yr), dp = ozMin(OZP, yr), dn = ozMin(OZN, yr);
      out.innerHTML = `<div>${bn(Math.floor(yr))} সালে অক্টোবরের ন্যূনতম ওজোন ≈ <b>${bn(Math.round(d))} DU</b> ${d < 220 ? '— ওজোন গহ্বর' : ''}</div><div class="small" style="margin-top:4px">${yr < 1975 ? 'CFC জমছে, কিন্তু স্ট্র্যাটোস্ফিয়ারের ক্লোরিন এখনো প্রাকৃতিক সীমার কাছে।' : yr < 1987 ? '১৯৮৫: ফারম্যান, গার্ডিনার ও শ্যাঙ্কলিন (ব্রিটিশ অ্যান্টার্কটিক সার্ভে) গহ্বর আবিষ্কার করেন।' : yr < 2005 ? 'প্রটোকলের পরও কয়েক বছর গহ্বর গভীর হয়েছে — আগের CFC তখনো স্ট্র্যাটোস্ফিয়ারে উঠছিল।' : sc === 'p' ? `পুনরুদ্ধার চলছে; প্রটোকল ছাড়া এ বছর হতো ~${bn(Math.round(dn))} DU (সমগ্র মেরু ওজোনশূন্যপ্রায়, মধ্য-অক্ষাংশেও বিস্তৃত)।` : `প্রটোকলসহ এ বছর হতো ~${bn(Math.round(dp))} DU।`}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; const ny = Math.min(2100, yr + dt * 6); if (Math.floor(ny) !== Math.floor(yr)) { yr = ny; info(); q('[data-y]').value = Math.floor(yr); } else yr = ny; if (yr >= 2100) yr = 1960; } draw(); }, { paused: true }); X.pp(el, A);
    const setY = v => { yr = v; info(); A.draw(); };
    q('[data-y]').oninput = e => setY(+e.target.value);
    X.onSeg(el, 'sc', k => { sc = k; info(); A.draw(); });
    yr = 2000; q('[data-y]').value = 2000; info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
