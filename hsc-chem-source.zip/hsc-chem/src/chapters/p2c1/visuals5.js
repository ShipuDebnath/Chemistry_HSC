/* ২য় পত্র অধ্যায় ১ visuals part 5 — kinetic molecular theory (1.5–1.5.2) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const Rg = 8.314;
const gauss = r => { let u = 0, v = 0; while (!u) u = r(); while (!v) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const spdCol = f => { const t = Math.max(0, Math.min(1, f)); const r = Math.round(40 + 215 * t), g = Math.round(110 + 60 * Math.sin(t * Math.PI) - 40 * t), b = Math.round(230 - 200 * t); return [`rgb(${r},${g},${b})`, `rgb(${Math.min(255, r + 70)},${Math.min(255, g + 70)},${Math.min(255, b + 70)})`]; };

/* ======================= ১.৫ গতিতত্ত্ব: অণু-সিমুলেশন ও চাপ পরিমাপ ======================= */
V.p2c1_kmt = {
  t: 'আণবিক গতিতত্ত্বের সিমুলেশন: অণুর সংঘর্ষ থেকে চাপ পরিমাপ (P ∝ NT/V)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বাক্সে গ্যাসের অণুগুলো এলোমেলো সরলরেখায় ছুটছে, পরস্পরের সাথে ও দেয়ালে পূর্ণ স্থিতিস্থাপক সংঘর্ষ করছে (রং = বেগ: নীল ধীর, লাল দ্রুত)। দেয়ালে প্রতিটি ধাক্কায় ভরবেগ পরিবর্তন 2mu গুনে প্রতি সেকেন্ডের মোট — অর্থাৎ পরিমাপকৃত চাপ — ডানের লেখচিত্রে ওঠানামা করে (লাল), আর তত্ত্বীয় মান PV = ⅓mNc² থেকে (কাটা রেখা)। অণুর সংখ্যা, তাপমাত্রা ও আয়তন (ডান দেয়াল) বদলে দেখো: চাপ N ও T এর সমানুপাতিক, V এর ব্যস্তানুপাতিক।',
  html: () => `${X.cv('আণবিক গতিতত্ত্ব সিমুলেশন')}<div class="ctl"><label class="small" style="flex:1;min-width:110px">অণু N = <b data-nv></b><input type="range" min="10" max="90" step="5" value="40" data-n></label><label class="small" style="flex:1;min-width:110px">T = <b data-tv></b> K<input type="range" min="100" max="900" step="10" value="300" data-t></label><label class="small" style="flex:1;min-width:110px">আয়তন = <b data-vv></b>%<input type="range" min="40" max="100" step="5" value="100" data-v></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 600;
    let L = X.fit(c, hf), N = 40, T = 300, Vf = 1, imp = 0, acc = 0, hist = [], t = 0;
    const R = X.rng(9), P = [];
    const sig = () => Math.sqrt(T / 300) * 0.25; // box units per s
    const spawn = k => { while (P.length < k) { P.push({ x: 0.05 + R() * 0.9 * Vf, y: 0.05 + R() * 0.9, vx: gauss(R) * sig(), vy: gauss(R) * sig() }); } P.length = k; };
    spawn(N);
    const rescale = (T0, T1) => { const f = Math.sqrt(T1 / T0); P.forEach(p => { p.vx *= f; p.vy *= f; }); };
    const rad = 0.014;
    const step = dt => {
      t += dt; const W = Vf;
      P.forEach(p => { p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.x < rad) { p.x = rad; p.vx = Math.abs(p.vx); imp += 2 * Math.abs(p.vx); } if (p.x > W - rad) { p.x = W - rad; imp += 2 * Math.abs(p.vx); p.vx = -Math.abs(p.vx); }
        if (p.y < rad) { p.y = rad; imp += 2 * Math.abs(p.vy); p.vy = Math.abs(p.vy); } if (p.y > 1 - rad) { p.y = 1 - rad; imp += 2 * Math.abs(p.vy); p.vy = -Math.abs(p.vy); } });
      for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) { const a = P[i], b = P[j], dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy; if (d2 < 4 * rad * rad && d2 > 1e-9) { const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, rv = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny; if (rv > 0) { a.vx -= rv * nx; a.vy -= rv * ny; b.vx += rv * nx; b.vy += rv * ny; } const o = (2 * rad - d) / 2; a.x -= nx * o; a.y -= ny * o; b.x += nx * o; b.y += ny * o; } }
      acc += dt; if (acc >= 0.25) { const per = 2 * (W + 1); const Pm = imp / acc / per; let ke = 0; P.forEach(p => { ke += p.vx * p.vx + p.vy * p.vy; }); const Pth = ke / (2 * W); hist.push([t, Pm, Pth]); if (hist.length > 80) hist.shift(); imp = 0; acc = 0; info(); }
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const bw = wd ? W * 0.5 : W - 40, bh = wd ? H - 50 : 260, bx = wd ? 16 : 20, by = 26, s = Math.min(bw, bh);
      const bxW = s * Vf;
      g.fillStyle = 'rgba(150,200,240,.10)'; g.fillRect(bx, by, bxW, s); g.strokeStyle = col.fg; g.lineWidth = 2; g.strokeRect(bx, by, bxW, s);
      g.fillStyle = '#8a9099'; g.fillRect(bx + bxW, by - 6, 7, s + 12); g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.strokeRect(bx, by, s, s); g.setLineDash([]);
      const vmax = sig() * 3;
      P.forEach(p => { const sp = Math.hypot(p.vx, p.vy), [c1, c2] = spdCol(sp / vmax); ball(g, bx + p.x * s, by + p.y * s, Math.max(3, rad * s), c1, c2); });
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('ধীর', bx, by + s + 16); const gr = g.createLinearGradient(bx + 24, 0, bx + 120, 0); gr.addColorStop(0, spdCol(0)[0]); gr.addColorStop(.5, spdCol(.5)[0]); gr.addColorStop(1, spdCol(1)[0]); g.fillStyle = gr; g.fillRect(bx + 24, by + s + 9, 96, 8); g.fillStyle = col.mu; g.fillText('দ্রুত', bx + 124, by + s + 16);
      // graph
      const gx0 = wd ? W * 0.58 : 56, gy0 = wd ? 36 : by + s + 60, gw = wd ? W - gx0 - 20 : W - 78, gh = wd ? H - 90 : H - gy0 - 44;
      const hs = hist.slice(2), ymax = Math.max(0.05, ...hs.map(h => Math.max(h[1], h[2]))) * 1.3;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 20, ymax, col, xt: [], yt: [], xl: 'সময় →', yl: 'চাপ', ylx: 16 });
      const X_ = i => Pl.X(i / 79 * 20);
      path(g, hist.map((h, i) => [X_(i), Pl.Y(h[2])]), col.mu, 1.6, [5, 4]); path(g, hist.map((h, i) => [X_(i), Pl.Y(h[1])]), '#c0392b', 2.2);
      legend(g, col, gx0 + gw, gy0 + 2, [['#c0392b', 'পরিমাপ (সংঘর্ষ গুনে)'], [col.mu, 'তত্ত্ব ⅓mNc²/V', [5, 4]]], true);
    };
    const info = () => {
      q('[data-nv]').textContent = bn(N); q('[data-tv]').textContent = bn(T); q('[data-vv]').textContent = bn(Math.round(Vf * 100));
      const h = hist.slice(-12), pm = h.length ? h.reduce((a, x) => a + x[1], 0) / h.length : 0, pt = h.length ? h.reduce((a, x) => a + x[2], 0) / h.length : 0;
      out.innerHTML = TXB(`P \\propto \\dfrac{NT}{V} = \\dfrac{${N}\\times${T}}{${Math.round(Vf * 100)}} `) + TXB(`\\text{আপেক্ষিক চাপ} = ${(N * T / (Vf * 100) / 120).toFixed(2)}`) + `<div class="small">পরিমাপ ও তত্ত্বের মিল: ${pt ? bn(Math.round(pm / pt * 100)) : '—'}% (ছোট নমুনায় ওঠানামা স্বাভাবিক — অণু যত বেশি, ওঠানামা তত কম)। একটি দেয়ালে প্রতিটি ধাক্কায় ভরবেগ পরিবর্তন 2mu; প্রতি সেকেন্ডের মোট ÷ ক্ষেত্রফল = চাপ।</div>`;
    };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.03)); draw(); }, { paused: false });
    q('[data-n]').oninput = e => { N = +e.target.value; spawn(N); hist = []; A.draw(); };
    q('[data-t]').oninput = e => { const T1 = +e.target.value; rescale(T, T1); T = T1; hist = []; A.draw(); };
    q('[data-v]').oninput = e => { Vf = +e.target.value / 100; P.forEach(p => { if (p.x > Vf - rad) p.x = Vf - rad - Math.random() * 0.05; }); hist = []; A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৫ PV = ⅓mNc² প্রতিপাদন: ধাপে ধাপে ======================= */
const DSTEP = [
  ['ঘনক ও অণু', 'l বাহুর ঘনকে m ভরের N টি অণু। একটি অণুর বেগ c এর তিন উপাংশ u, v, w (x, y, z বরাবর)।', 'c^2 = u^2 + v^2 + w^2'],
  ['একটি সংঘর্ষ', 'অণুটি u বেগে ডান দেয়াল (সবুজ) এ লেগে −u বেগে ফেরে; v, w অপরিবর্তিত।', '\\Delta p = mu - (-mu) = 2mu'],
  ['সংঘর্ষের হার', 'একই দেয়ালে আবার ফিরতে যেতে-আসতে 2l পথ — সময় 2l/u।', '\\text{প্রতি সেকেন্ডে সংঘর্ষ} = \\dfrac{u}{2l}'],
  ['একটি অণুর বল', 'বল = প্রতি সেকেন্ডে ভরবেগ পরিবর্তন।', 'F_1 = 2mu\\times\\dfrac{u}{2l} = \\dfrac{mu^2}{l}'],
  ['N অণুর বল', 'সব অণুর বল যোগ করি।', 'F = \\dfrac{m}{l}\\left(u_1^2 + u_2^2 + \\cdots + u_N^2\\right) = \\dfrac{mN\\overline{u^2}}{l}'],
  ['চাপ', 'চাপ = বল ÷ দেয়ালের ক্ষেত্রফল l²; l³ = V।', 'P = \\dfrac{F}{l^2} = \\dfrac{mN\\overline{u^2}}{V}'],
  ['তিন দিকে সমান', 'এলোমেলো গতিতে কোনো দিক বিশেষ নয়: ū² = v̄² = w̄² = ⅓c̄²।', 'PV = \\tfrac13 mNc^2']
];
V.p2c1_derive = {
  t: 'গতীয় গ্যাস সমীকরণ PV = ⅓mNc² এর ধাপে ধাপে অ্যানিমেটেড প্রতিপাদন', k: ['anim', 'int', '2d', '3d'],
  cap: 'তির্যক দৃষ্টিতে আঁকা l বাহুর একটি ঘনক; একটি অণু (লাল) বেগ c নিয়ে দেয়াল থেকে দেয়ালে ছুটছে। ধাপ বোতাম চাপলে প্রতিপাদনের সেই ধাপের অংশটি আলাদা করে দেখায়: বেগের তিন উপাংশ u, v, w; ডান দেয়ালে সংঘর্ষে ভরবেগের তীর (mu ভিতরে, −mu বাইরে, পরিবর্তন 2mu); যেতে-আসতে 2l পথ; বল; সব অণু; চাপ; এবং তিন অক্ষে সমান বণ্টন থেকে ⅓। নিচে প্রতিটি ধাপের সমীকরণ।',
  html: () => `${X.cv('PV = mNc²/3 প্রতিপাদন')}<div class="ctl" style="flex-wrap:wrap">${DSTEP.map((s, i) => `<button class="btn sm" data-s="${i}">${bn(i + 1)}. ${s[0]}</button>`).join('')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 320 : 360;
    let L = X.fit(c, hf), st = 0, t = 0, flash = 0;
    const m = { x: 0.3, y: 0.55, z: 0.4, u: 0.42, v: 0.27, w: 0.19 }, many = []; const R = X.rng(4); for (let i = 0; i < 14; i++) many.push({ x: R(), y: R(), z: R(), u: (R() - .5) * .6, v: (R() - .5) * .6, w: (R() - .5) * .6 });
    const mv = (p, dt, hit) => { ['x', 'y', 'z'].forEach((k, j) => { const vk = ['u', 'v', 'w'][j]; p[k] += p[vk] * dt; if (p[k] < 0.04) { p[k] = 0.04; p[vk] = Math.abs(p[vk]); } if (p[k] > 0.96) { p[k] = 0.96; if (hit && k === 'x') flash = 1; p[vk] = -Math.abs(p[vk]); } }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const s = Math.min(wd ? W * 0.42 : W * 0.6, H * 0.62), ox = wd ? 40 : (W - s * 1.45) / 2, oy = H * 0.86, dx = s * 0.42, dy = -s * 0.32;
      const P = (x, y, z) => [ox + x * s + z * dx, oy - y * s + z * dy];
      const Ln = (a, b, cl, w, d) => { const A = P(...a), B = P(...b); g.strokeStyle = cl; g.lineWidth = w || 1.4; g.setLineDash(d || []); g.beginPath(); g.moveTo(A[0], A[1]); g.lineTo(B[0], B[1]); g.stroke(); g.setLineDash([]); };
      const face = (pts, fill) => { g.fillStyle = fill; g.beginPath(); pts.forEach((p, i) => { const q = P(...p); i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1]); }); g.closePath(); g.fill(); };
      face([[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], 'rgba(150,200,240,.10)');
      if (st >= 1) face([[1, 0, 0], [1, 0, 1], [1, 1, 1], [1, 1, 0]], `rgba(47,158,68,${0.18 + 0.3 * flash})`);
      [[[0, 0, 1], [1, 0, 1]], [[0, 0, 1], [0, 1, 1]], [[0, 0, 0], [0, 0, 1]]].forEach(([a, b]) => Ln(a, b, col.mu, 1, [4, 3]));
      const pts = (st >= 4 && st <= 6) ? many : [];
      pts.forEach(p => { const q = P(p.x, p.y, p.z); ball(g, q[0], q[1], 4, '#2d6fd6', '#a9c8ff'); });
      const q = P(m.x, m.y, m.z); ball(g, q[0], q[1], 7, '#c0392b', '#ffb3a8');
      const arrow = (a, b, cl, lab) => { const A = P(...a), B = P(...b); g.strokeStyle = cl; g.fillStyle = cl; g.lineWidth = 2.2; g.beginPath(); g.moveTo(A[0], A[1]); g.lineTo(B[0], B[1]); g.stroke(); const an = Math.atan2(B[1] - A[1], B[0] - A[0]); g.beginPath(); g.moveTo(B[0], B[1]); g.lineTo(B[0] - 9 * Math.cos(an - .4), B[1] - 9 * Math.sin(an - .4)); g.lineTo(B[0] - 9 * Math.cos(an + .4), B[1] - 9 * Math.sin(an + .4)); g.fill(); if (lab) { g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(lab, B[0] + 4, B[1] - 4); } };
      if (st === 0) { const k = 0.5; arrow([m.x, m.y, m.z], [m.x + m.u * k, m.y, m.z], '#c0392b', 'u'); arrow([m.x, m.y, m.z], [m.x, m.y + m.v * k, m.z], '#2f9e44', 'v'); arrow([m.x, m.y, m.z], [m.x, m.y, m.z + m.w * k], '#2d6fd6', 'w'); arrow([m.x, m.y, m.z], [m.x + m.u * k, m.y + m.v * k, m.z + m.w * k], col.fg, 'c'); }
      if (st === 1 || st === 3) { arrow([0.55, 0.85, 0.5], [0.92, 0.85, 0.5], '#c0392b', '+mu'); arrow([0.92, 0.72, 0.5], [0.55, 0.72, 0.5], '#2d6fd6', '−mu'); const A = P(1, 0.95, 0.5); g.fillStyle = '#2f9e44'; g.font = `bold 12px ${col.font}`; g.textAlign = 'left'; g.fillText('Δp = 2mu', A[0] + 8, A[1]); }
      if (st === 2) { const y = 0.12; arrow([0.04, y, 0], [0.96, y, 0], '#d06a1e'); arrow([0.96, y - 0.06, 0], [0.04, y - 0.06, 0], '#d06a1e'); const A = P(0.5, y + 0.06, 0); g.fillStyle = '#d06a1e'; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText('যেতে-আসতে 2l', A[0], A[1]); }
      if (st === 5) { const A = P(1.02, 0.5, 0.5); g.fillStyle = '#2f9e44'; g.font = `bold 12px ${col.font}`; g.textAlign = 'left'; g.fillText('ক্ষেত্রফল l²', A[0] + 6, A[1]); }
      if (st === 6) { ['x', 'y', 'z'].forEach((a, i) => { const A = P(...[[1.08, 0, 0], [0, 1.08, 0], [0, 0, 1.12]][i]); g.fillStyle = ['#c0392b', '#2f9e44', '#2d6fd6'][i]; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(`${['ū²', 'v̄²', 'w̄²'][i]} = ⅓c̄²`, A[0], A[1]); }); }
      face([[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]], 'rgba(150,200,240,.05)');
      [[[0, 0, 0], [1, 0, 0]], [[1, 0, 0], [1, 1, 0]], [[1, 1, 0], [0, 1, 0]], [[0, 1, 0], [0, 0, 0]], [[1, 0, 0], [1, 0, 1]], [[1, 1, 0], [1, 1, 1]], [[0, 1, 0], [0, 1, 1]], [[0, 1, 1], [1, 1, 1]], [[1, 0, 1], [1, 1, 1]]].forEach(([a, b]) => Ln(a, b, col.fg, 1.5));
      const lb = P(0.5, -0.07, 0); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('l', lb[0], lb[1] + 6);
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`ধাপ ${bn(st + 1)}/৭ · ${DSTEP[st][0]}`, 10, 16);
    };
    const info = () => { el.querySelectorAll('[data-s]').forEach(b => b.classList.toggle('primary', +b.dataset.s === st)); out.innerHTML = `<div class="small" style="margin-bottom:4px">${DSTEP[st][1]}</div>` + TXB(DSTEP[st][2]); };
    const A = X.anim(el, dt => { if (dt) { t += dt; mv(m, dt, true); many.forEach(p => mv(p, dt)); flash = Math.max(0, flash - dt * 2); } draw(); }, { paused: false });
    el.querySelectorAll('[data-s]').forEach(b => { b.onclick = () => { st = +b.dataset.s; info(); A.draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৫.১ ম্যাক্সওয়েল-বোলৎজম্যান বণ্টন ======================= */
const MG = [['H2', 'H₂', 2.016, '#8a8f98'], ['He', 'He', 4.003, '#d69a1e'], ['N2', 'N₂', 28.01, '#2d6fd6'], ['O2', 'O₂', 32.00, '#c0392b'], ['CO2', 'CO₂', 44.01, '#3a3a3a']];
const fMB = (c, M, T) => { const a = M / (2 * Rg * T); return 4 * Math.PI * Math.pow(a / Math.PI, 1.5) * c * c * Math.exp(-a * c * c); };
V.p2c1_maxwell = {
  t: 'ম্যাক্সওয়েল-বোলৎজম্যান বেগ বণ্টন: c_mp, c̄ ও c_rms এবং তাপমাত্রা ও মোলার ভরের প্রভাব', k: ['int', '2d', 'calc', 'anim'],
  cap: 'অনুভূমিক অক্ষে অণুর বেগ (m s⁻¹), উল্লম্ব অক্ষে সেই বেগের অণুর ভগ্নাংশ। বেছে নেওয়া গ্যাস ও তাপমাত্রার বণ্টন রেখা (মোটা), সাথে তুলনার জন্য অন্য দুটি তাপমাত্রা বা গ্যাসের রেখা। তিনটি উল্লম্ব রেখা: c_mp (শীর্ষ), c̄ ও c_rms — সবসময় c_mp < c̄ < c_rms। "সীমা বেগ" স্লাইডারের ডানের ছায়া অংশ = তার চেয়ে দ্রুত অণুর শতাংশ (সংখ্যাগত সমাকলন)। "নমুনা জমাও" চাপলে এলোমেলো অণুর বেগ একে একে হিস্টোগ্রামে জমে তত্ত্বীয় রেখার আকৃতি নেয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('cmp', [['T', 'তাপমাত্রা তুলনা'], ['M', 'গ্যাস তুলনা']], 'T')} <select class="inp" data-g style="width:auto;display:inline-block;margin:0">${MG.map((g, i) => `<option value="${i}" ${i === 3 ? 'selected' : ''}>${g[1]}</option>`).join('')}</select></div>${X.cv('ম্যাক্সওয়েল বণ্টন')}<div class="ctl"><label class="small" style="flex:1;min-width:130px">T = <b data-tv></b> K<input type="range" min="100" max="1500" step="10" value="300" data-t></label><label class="small" style="flex:1;min-width:130px">সীমা বেগ = <b data-cv></b> m s⁻¹<input type="range" min="0" max="3000" step="10" value="800" data-c></label><button class="btn sm" data-smp>নমুনা জমাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 360;
    let L = X.fit(c, hf), gi = 3, T = 300, cth = 800, mode = 'T', smp = false, bins = new Array(60).fill(0), ns = 0;
    const R = X.rng(77);
    const cmax = () => { const M = MG[gi][2] / 1000; const lo = Math.min(...(mode === 'M' ? MG.map(x => x[2]) : [MG[gi][2]])) / 1000, Tm = mode === 'T' ? T * 2 : T; return Math.min(6000, Math.max(800, Math.ceil(Math.sqrt(2 * Rg * Tm / lo) * 2.6 / 500) * 500)); };
    const frac = (M, T_, c0) => { let s = 0, dc = 4; for (let v = c0; v < c0 + 20000; v += dc) s += fMB(v + dc / 2, M, T_) * dc; return s; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const M = MG[gi][2] / 1000, CX = cmax();
      const sets = mode === 'T' ? [[M, T, MG[gi][3], `${MG[gi][1]}, ${bn(T)} K`, 3], [M, T * 2, '#d06a1e', `${bn(T * 2)} K`, 1.6], [M, Math.max(50, T / 2), '#2d6fd6', `${bn(Math.round(T / 2))} K`, 1.6]] : MG.filter((_, i) => i === gi || i === 1 || i === 4 || i === 2).slice(0, 3).map(x => [x[2] / 1000, T, x[3], `${x[1]}, ${bn(T)} K`, x[0] === MG[gi][0] ? 3 : 1.6]);
      if (mode === 'M' && !sets.some(s => s[0] === M)) sets[0] = [M, T, MG[gi][3], `${MG[gi][1]}, ${bn(T)} K`, 3];
      const ymax = Math.max(...sets.map(([m_, t_]) => fMB(Math.sqrt(2 * Rg * t_ / m_), m_, t_))) * 1.15;
      const x0 = 56, y0 = 22, w = W - 76, h = H - 64;
      const Pl = cplot(g, { x0, y0, w, h, xmax: CX, ymax, col, xt: [0, CX / 4, CX / 2, 3 * CX / 4, CX].map(v => Math.round(v)), yt: [], xl: 'বেগ c (m s⁻¹)', yl: 'অণুর ভগ্নাংশ', ylx: 18 });
      // shaded
      const main = sets.find(s => s[4] === 3) || sets[0]; g.fillStyle = 'rgba(192,57,43,.18)'; g.beginPath(); g.moveTo(Pl.X(Math.min(cth, CX)), Pl.Y(0)); for (let v = Math.min(cth, CX); v <= CX; v += CX / 300) g.lineTo(Pl.X(v), Pl.Y(fMB(v, main[0], main[1]))); g.lineTo(Pl.X(CX), Pl.Y(0)); g.closePath(); g.fill();
      // histogram
      if (ns) { const bw = CX / bins.length, mx = Math.max(...bins); bins.forEach((b, i) => { const hh = b / ns / bw; g.fillStyle = 'rgba(123,63,160,.35)'; g.fillRect(Pl.X(i * bw) + 0.5, Pl.Y(hh), Pl.X(bw) - Pl.X(0) - 1, Pl.Y(0) - Pl.Y(hh)); }); }
      sets.slice().sort((a, b) => a[4] - b[4]).forEach(([m_, t_, cl, , lw]) => { const pts = []; for (let v = 0; v <= CX; v += CX / 300) pts.push([Pl.X(v), Pl.Y(fMB(v, m_, t_))]); path(g, pts, cl, lw); });
      const vm = Math.sqrt(2 * Rg * main[1] / main[0]), va = Math.sqrt(8 * Rg * main[1] / (Math.PI * main[0])), vr = Math.sqrt(3 * Rg * main[1] / main[0]);
      [[vm, 'c_mp', '#2f9e44'], [va, 'c̄', '#d06a1e'], [vr, 'c_rms', '#7b3fa0']].forEach(([v, n, cl], k) => { if (v > CX) return; g.strokeStyle = cl; g.lineWidth = 1.4; g.setLineDash([4, 3]); g.beginPath(); g.moveTo(Pl.X(v), Pl.Y(0)); g.lineTo(Pl.X(v), Pl.Y(fMB(v, main[0], main[1]))); g.stroke(); g.setLineDash([]); g.fillStyle = cl; g.font = `bold 10.5px ${col.font}`; g.textAlign = ['right', 'center', 'left'][k]; g.fillText(n, Pl.X(v) + [-3, 0, 3][k], Pl.Y(fMB(v, main[0], main[1])) - 8 - [0, 14, 0][k]); });
      g.strokeStyle = '#c0392b'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(Pl.X(Math.min(cth, CX)), y0); g.lineTo(Pl.X(Math.min(cth, CX)), y0 + h); g.stroke();
      legend(g, col, x0 + w, y0, sets.map(s => [s[2], s[3]]), true);
    };
    const info = () => {
      const M = MG[gi][2] / 1000, vm = Math.sqrt(2 * Rg * T / M), va = Math.sqrt(8 * Rg * T / (Math.PI * M)), vr = Math.sqrt(3 * Rg * T / M), fr = frac(M, T, cth);
      q('[data-tv]').textContent = bn(T); q('[data-cv]').textContent = bn(cth);
      out.innerHTML = TXB(`c_{mp} = \\sqrt{\\dfrac{2RT}{M}} = ${vm.toFixed(0)}\\ \\mathrm{m\\,s^{-1}}`) + TXB(`\\bar c = \\sqrt{\\dfrac{8RT}{\\pi M}} = ${va.toFixed(0)}\\ \\mathrm{m\\,s^{-1}}`) + TXB(`c_{rms} = \\sqrt{\\dfrac{3RT}{M}} = ${vr.toFixed(0)}\\ \\mathrm{m\\,s^{-1}}`) + TXB(`c_{mp} : \\bar c : c_{rms} = 1 : ${(va / vm).toFixed(3)} : ${(vr / vm).toFixed(3)}`) +
        `<div class="small">${MG[gi][1]} এর ${bn(T)} K এ <b>${fx(fr * 100, 2)}%</b> অণুর বেগ ${bn(cth)} m s⁻¹ এর বেশি।${ns ? ` নমুনা: ${bn(ns)}টি অণু।` : ''}</div>`;
    };
    const sample = () => { const M = MG[gi][2] / 1000, s = Math.sqrt(Rg * T / M), CX = cmax(); for (let k = 0; k < 25; k++) { const v = Math.sqrt(gauss(R) ** 2 + gauss(R) ** 2 + gauss(R) ** 2) * s; const i = Math.floor(v / CX * bins.length); if (i < bins.length) bins[i]++; ns++; } };
    const reset = () => { bins.fill(0); ns = 0; };
    const A = X.anim(el, dt => { if (dt && smp && ns < 8000) { sample(); if (ns % 250 < 25) info(); } draw(); }, { paused: false });
    X.onSeg(el, 'cmp', k => { mode = k; reset(); info(); A.draw(); });
    q('[data-g]').onchange = e => { gi = +e.target.value; reset(); info(); A.draw(); };
    q('[data-t]').oninput = e => { T = +e.target.value; reset(); info(); A.draw(); };
    q('[data-c]').oninput = e => { cth = +e.target.value; info(); A.draw(); };
    q('[data-smp]').onclick = () => { smp = !smp; if (smp) reset(); q('[data-smp]').textContent = smp ? 'নমুনা থামাও' : 'নমুনা জমাও'; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৫.২ গতিশক্তি বনাম তাপমাত্রা ======================= */
V.p2c1_keTemp = {
  t: 'একই তাপমাত্রায় সব গ্যাসের গড় গতিশক্তি সমান, কিন্তু বেগ ভিন্ন: E_k = (3/2)RT', k: ['anim', 'int', '2d', 'calc'],
  cap: 'পাঁচটি কক্ষে একই তাপমাত্রায় পাঁচটি গ্যাস — H₂, He, N₂, O₂, CO₂। হালকা অণুগুলো অনেক দ্রুত ছোটে, ভারীগুলো ধীরে (অ্যানিমেশনের বেগ c_rms এর সমানুপাতিক)। নিচের দুই সারি দণ্ডে c_rms (ভিন্ন ভিন্ন) এবং প্রতি মোলে গড় গতিশক্তি (সবগুলো সমান = (3/2)RT)। ডানে E_k বনাম T লেখচিত্র — মূলবিন্দুগামী সরলরেখা, সব গ্যাসের জন্য একটিই। তাপমাত্রা স্লাইডারে বদলাও এবং গ্যাসের ভর দিয়ে মোট গতিশক্তি হিসাব করো।',
  html: () => `${X.cv('গতিশক্তি ও তাপমাত্রা')}<div class="ctl"><label class="small" style="flex:1;min-width:140px">T = <b data-tv></b> K<input type="range" min="50" max="1000" step="10" value="300" data-t></label><label class="small" style="flex:1;min-width:140px">ভর <b data-mv></b> g <select class="inp" data-g style="width:auto;display:inline-block;margin:0">${MG.map((g, i) => `<option value="${i}" ${i === 3 ? 'selected' : ''}>${g[1]}</option>`).join('')}</select><input type="range" min="1" max="100" step="1" value="8" data-m></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 620;
    let L = X.fit(c, hf), T = 300, gi = 3, mass = 8;
    const R = X.rng(12), G = MG.map(() => { const a = []; for (let i = 0; i < 9; i++) { const th = R() * 6.283; a.push({ x: R(), y: R(), vx: Math.cos(th), vy: Math.sin(th) }); } return a; });
    const step = dt => { G.forEach((a, k) => { const sp = Math.sqrt(3 * Rg * T / (MG[k][2] / 1000)) / 1934 * 0.9; a.forEach(p => { p.x += p.vx * sp * dt; p.y += p.vy * sp * dt; if (p.x < .05 || p.x > .95) { p.vx *= -1; p.x = Math.max(.05, Math.min(.95, p.x)); } if (p.y < .05 || p.y > .95) { p.vy *= -1; p.y = Math.max(.05, Math.min(.95, p.y)); } }); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const aw = wd ? W * 0.56 : W - 20, cw = (aw - 10) / 5 - 6, ch = Math.min(cw * 1.1, 110), y0 = 22;
      MG.forEach(([k, nm, M, cl], i) => { const x = 10 + i * (cw + 6); g.fillStyle = 'rgba(150,200,240,.10)'; g.fillRect(x, y0, cw, ch); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(x, y0, cw, ch); G[i].forEach(p => ball(g, x + p.x * cw, y0 + p.y * ch, Math.max(2.5, 2 + Math.cbrt(M) * 0.9), cl, '#fff')); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + cw / 2, y0 - 6); });
      const cr = MG.map(([, , M]) => Math.sqrt(3 * Rg * T / (M / 1000))), rows = [['c_rms (m s⁻¹) — ভিন্ন', cr, Math.sqrt(3 * Rg * 1000 / 0.002016)], ['গড় গতিশক্তি E_k (J mol⁻¹) — সমান', MG.map(() => 1.5 * Rg * T), 1.5 * Rg * 1000]];
      rows.forEach(([lab, vals, mx], r) => { const yb = y0 + ch + 40 + r * 100, bh = 60; g.fillStyle = col.mu; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(lab, 10, yb - 4);
        vals.forEach((v, i) => { const x = 10 + i * (cw + 6), hh = Math.max(2, v / mx * bh); g.fillStyle = r ? '#2f9e44' : MG[i][3]; g.globalAlpha = .85; g.fillRect(x + cw * 0.2, yb + bh - hh, cw * 0.6, hh); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(Math.round(v)), x + cw / 2, yb + bh + 11); }); });
      const gx0 = wd ? W * 0.64 : 60, gy0 = wd ? 30 : y0 + ch + 250, gw = wd ? W - gx0 - 18 : W - 80, gh = wd ? H - 80 : H - gy0 - 46;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 1000, ymax: 13000, col, xt: [0, 500, 1000], yt: [0, 5000, 10000], xl: 'T (K)', yl: 'E_k (J mol⁻¹)', ylx: 40 });
      path(g, [[Pl.X(0), Pl.Y(0)], [Pl.X(1000), Pl.Y(1.5 * Rg * 1000)]], '#2f9e44', 2.6); ball(g, Pl.X(T), Pl.Y(1.5 * Rg * T), 6, '#c0392b', '#ffb3a8');
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('সব গ্যাসের জন্য একই রেখা', gx0 + 8, gy0 + 6);
    };
    const info = () => { q('[data-tv]').textContent = bn(T); q('[data-mv]').textContent = bn(mass); const M = MG[gi][2], n = mass / M, E = 1.5 * n * Rg * T, e1 = 1.5 * 1.381e-23 * T, cr = Math.sqrt(3 * Rg * T / (M / 1000));
      out.innerHTML = TXB(`E_k = \\tfrac32RT = \\tfrac32\\times8.314\\times${T} = ${(1.5 * Rg * T).toFixed(0)}\\ \\mathrm{J\\,mol^{-1}}`) + TXB(`\\bar\\varepsilon = \\tfrac32k_BT = ${e1.toExponential(2).replace('e-', '\\times10^{-')}}\\ \\mathrm{J}`) + TXB(`${mass}\\ \\mathrm{g}\\ \\ce{${MG[gi][0]}}:\\ n = ${n.toFixed(3)}\\ \\mathrm{mol}`) + TXB(`E_k = \\tfrac32 nRT = ${E.toFixed(1)}\\ \\mathrm{J},\\ c_{rms} = ${cr.toFixed(0)}\\ \\mathrm{m\\,s^{-1}}`); };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, .05)); draw(); }, { paused: false });
    q('[data-t]').oninput = e => { T = +e.target.value; info(); A.draw(); };
    q('[data-m]').oninput = e => { mass = +e.target.value; info(); };
    q('[data-g]').onchange = e => { gi = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
