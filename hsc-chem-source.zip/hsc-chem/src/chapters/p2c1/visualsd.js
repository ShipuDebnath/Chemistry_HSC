/* ২য় পত্র অধ্যায় ১ visuals part 13 — water quality: test dashboard, oxygen sag, BOD/COD lab, hardness, EDTA titration (1.17–1.18) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const doSat = T => 14.62 - 0.3898 * T + 0.006969 * T * T - 0.00005897 * T * T * T;

/* ======================= পানির নমুনা পরীক্ষা ড্যাশবোর্ড ======================= */
const WP = [ // key, name, unit, min, max, log, okLo, okHi, note
  ['pH', 'pH', '', 0, 14, 0, 6.5, 8.5], ['tds', 'TDS', 'mg L⁻¹', 10, 10000, 1, 0, 1000], ['do', 'DO', 'mg L⁻¹', 0, 14, 0, 5, 99], ['bod', 'BOD₅', 'mg L⁻¹', 0.05, 300, 1, 0, 0.2], ['cod', 'COD', 'mg L⁻¹', 0.5, 1000, 1, 0, 4], ['as', 'আর্সেনিক', 'mg L⁻¹', 0.001, 1, 1, 0, 0.05], ['hard', 'খরতা', 'ppm CaCO₃', 1, 1000, 1, 0, 500], ['col', 'মলবাহিত কলিফর্ম', '/১০০ mL', 0.5, 100000, 1, 0, 0.9]
];
const WS = {
  deep: ['গভীর নলকূপ', { pH: 7.3, tds: 420, do: 4.5, bod: 0.1, cod: 1.5, as: 0.004, hard: 210, col: 0 }, 'প্রায় সব মানদণ্ড পূরণ — নিরাপদ পানীয় জল। (ভূগর্ভস্থ পানিতে DO স্বাভাবিকভাবেই কম, পানের জন্য সমস্যা নয়।)'],
  shallow: ['অগভীর নলকূপ (আর্সেনিকপ্রবণ এলাকা)', { pH: 7.1, tds: 560, do: 2.5, bod: 0.15, cod: 2.5, as: 0.18, hard: 330, col: 0 }, 'স্বচ্ছ ও স্বাদে ভালো, কিন্তু আর্সেনিক বাংলাদেশের সীমার ৩.৬ গুণ, WHO সীমার ১৮ গুণ — পান অযোগ্য (১.২১ দেখো)।'],
  pond: ['গ্রামের পুকুর', { pH: 7.8, tds: 260, do: 6.5, bod: 6, cod: 25, as: 0.002, hard: 90, col: 800 }, 'মাছের জন্য DO যথেষ্ট, কিন্তু কলিফর্ম ও BOD উচ্চ — না ফুটিয়ে পান করলে ডায়রিয়া-কলেরার ঝুঁকি।'],
  river: ['বুড়িগঙ্গা (শুকনো মৌসুম)', { pH: 7.6, tds: 900, do: 0.4, bod: 60, cod: 220, as: 0.01, hard: 180, col: 40000 }, 'DO প্রায় শূন্য, BOD/COD বিপুল — মাছ বাঁচে না, তীব্র দুর্গন্ধ (H₂S)। শিল্প ও পয়ঃবর্জ্যের ফল।'],
  coastal: ['উপকূলীয় নলকূপ (লবণাক্ত)', { pH: 7.9, tds: 3800, do: 3.5, bod: 0.3, cod: 6, as: 0.03, hard: 720, col: 2 }, 'TDS ও খরতা অত্যন্ত বেশি — লবণাক্ততা; উচ্চ রক্তচাপ ও গর্ভকালীন জটিলতার ঝুঁকি। সমুদ্রপৃষ্ঠ বৃদ্ধিতে সমস্যা বাড়ছে।'],
  tannery: ['ট্যানারি বর্জ্য (অশোধিত)', { pH: 11.2, tds: 8000, do: 0.2, bod: 250, cod: 900, as: 0.02, hard: 600, col: 5000 }, 'pH, TDS, BOD, COD সবই চরম — ক্রোমিয়াম ও সালফাইডও থাকে। BOD/COD ≈ ০.২৮: জৈবিক শোধন একা যথেষ্ট নয়।'],
  bottle: ['বোতলজাত পানি', { pH: 7.0, tds: 120, do: 7.5, bod: 0.05, cod: 0.5, as: 0.001, hard: 60, col: 0 }, 'সব মানদণ্ড পূরণ।']
};
V.p2c1_waterTest = {
  t: 'পানির নমুনা পরীক্ষা: আটটি মানদণ্ডে বাংলাদেশের পানীয় জলের মানের সাথে তুলনা (ইন্টারঅ্যাকটিভ ড্যাশবোর্ড)', k: ['int', 'calc', '2d', 'info'],
  cap: 'একটি নমুনা বেছে নাও — গভীর ও অগভীর নলকূপ, পুকুর, বুড়িগঙ্গা, উপকূলীয় নলকূপ, ট্যানারি বর্জ্য বা বোতলজাত পানি। প্রতিটি মানদণ্ডের দণ্ডে সবুজ অংশ গ্রহণযোগ্য সীমা (বাংলাদেশ ECR ১৯৯৭; DO এর ক্ষেত্রে জলজ প্রাণীর জন্য ≥ ৫), কালো চিহ্ন নমুনার মান; ডানে ✓ বা ✗। TDS, BOD, COD, আর্সেনিক, খরতা ও কলিফর্ম লগারিদমিক স্কেলে। উপাত্তগুলো শিক্ষার উদ্দেশ্যে প্রতিনিধিত্বমূলক মান।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${Object.entries(WS).map(([k, v]) => `<button class="btn sm" data-ws="${k}">${v[0]}</button>`).join('')}</div>${X.cv('পানি পরীক্ষা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 330 : 420;
    let L = X.fit(c, hf), ws = 'shallow';
    const pos = (p, v) => { const [, , , mn, mx, lg] = p; if (lg) { const a = Math.log10(mn), b = Math.log10(mx); return (Math.log10(Math.max(mn, v)) - a) / (b - a); } return (v - mn) / (mx - mn); };
    const ok = (p, v) => v >= p[6] && v <= p[7];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), S = WS[ws][1];
      const lx = wd ? 150 : 92, rx = W - (wd ? 120 : 64), rowH = (H - 20) / WP.length;
      WP.forEach((p, i) => { const y = 10 + i * rowH + rowH / 2, v = S[p[0]];
        g.fillStyle = col.fg; g.font = `bold ${wd ? 11 : 10}px ${col.font}`; g.textAlign = 'right'; g.fillText(p[1], lx - 8, y + 2); if (wd) { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText(p[2], lx - 8, y + 13); }
        g.fillStyle = col.s2 || 'rgba(0,0,0,.06)'; rr(g, lx, y - 7, rx - lx, 14, 7); g.fill();
        const a = pos(p, Math.max(p[3], p[6])), b = Math.min(1, pos(p, p[7])); g.fillStyle = 'rgba(47,158,68,.35)'; g.fillRect(lx + (rx - lx) * a, y - 7, (rx - lx) * (b - a), 14);
        const xv = lx + (rx - lx) * Math.min(1, Math.max(0, pos(p, v))); const good = ok(p, v); g.fillStyle = good ? '#2f9e44' : '#c0392b'; g.beginPath(); g.moveTo(xv, y - 10); g.lineTo(xv - 6, y - 18); g.lineTo(xv + 6, y - 18); g.fill(); g.fillStyle = col.fg; g.fillRect(xv - 1.5, y - 9, 3, 18);
        g.font = `bold ${wd ? 11 : 10}px ${col.font}`; g.textAlign = 'left'; g.fillStyle = good ? '#2f9e44' : '#c0392b'; const vs = v === 0 ? '০' : v < 0.01 ? bn(v.toFixed(3)) : v < 1 ? bn(v.toFixed(2)) : v < 100 ? bn(v.toFixed(1)) : bn(Math.round(v)); g.fillText(`${good ? '✓' : '✗'} ${vs}`, rx + 8, y + 4); });
    };
    const info = () => { el.querySelectorAll('[data-ws]').forEach(b => b.classList.toggle('primary', b.dataset.ws === ws)); const S = WS[ws][1]; const fails = WP.filter(p => !ok(p, S[p[0]]) && p[0] !== 'do').map(p => p[1]);
      out.innerHTML = `<div><b>${WS[ws][0]}:</b> ${fails.length ? `<span style="color:var(--bad)">পানের অযোগ্য</span> — সীমা অতিক্রম: ${fails.join(', ')}` : '<span style="color:var(--ok)">পানযোগ্য</span>'}</div><div class="small" style="margin-top:4px">${WS[ws][2]}${S.cod > 0 && S.bod > 1 ? ` BOD/COD = ${bn((S.bod / S.cod).toFixed(2))}।` : ''}</div>`; };
    el.querySelectorAll('[data-ws]').forEach(b => { b.onclick = () => { ws = b.dataset.ws; info(); draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= নদীতে অক্সিজেন হ্রাস বক্ররেখা (স্ট্রিটার-ফেল্পস) ======================= */
V.p2c1_oxygenSag = {
  t: 'নদীতে অক্সিজেন হ্রাস বক্ররেখা: নর্দমার BOD, তাপমাত্রা ও পুনঃবায়ুমিশ্রণের প্রভাব (স্ট্রিটার-ফেল্পস মডেল)', k: ['anim', 'int', 'calc', '2d'],
  cap: 'উপরে একটি নদী — বাম থেকে ডানে প্রবাহিত; ০ km এ একটি নর্দমা মিশছে। নদীর রং DO অনুযায়ী (নীল = ভালো, বাদামি-কালো = অক্সিজেনহীন), মাছ কেবল DO ≥ ৫ এলাকায় সাঁতরায়। নিচে দূরত্বের বিপরীতে DO (নীল) ও অবশিষ্ট BOD (বাদামি ড্যাশ) — চামচ আকৃতির "স্যাগ"। নর্দমার BOD, পানির তাপমাত্রা ও নদীর গতি বদলে দেখো: গ্রীষ্মে সম্পৃক্ত DO কমে ও বিয়োজন দ্রুত হয়, তাই সর্বনিম্ন বিন্দু গভীর হয়।',
  html: () => `${X.cv('অক্সিজেন স্যাগ')}<div class="ctl"><label class="small" style="flex:1;min-width:120px">মিশ্রিত BOD = <b data-lv></b> mg L⁻¹<input type="range" min="0" max="40" step="1" value="18" data-l></label><label class="small" style="flex:1;min-width:110px">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="10" max="35" step="1" value="28" data-t></label><label class="small" style="flex:1;min-width:110px">প্রবাহ = <b data-vv></b> km/দিন<input type="range" min="5" max="60" step="1" value="20" data-v></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 400;
    let L = X.fit(c, hf), L0 = 18, T = 28, vel = 20, t = 0; const Rn = X.rng(9); const fish = Array.from({ length: 10 }, () => ({ x: Rn(), y: Rn(), d: Rn() < 0.5 ? 1 : -1 }));
    const model = () => { const kd = 0.23 * Math.pow(1.047, T - 20), kr = 0.45 * Math.pow(1.024, T - 20) * Math.sqrt(vel / 20), Ds = doSat(T), D0 = 0.08 * Ds; const DO = x => { const tt = x / vel; const D = kd * L0 / (kr - kd) * (Math.exp(-kd * tt) - Math.exp(-kr * tt)) + D0 * Math.exp(-kr * tt); return Math.max(0, Ds - D); }; const BOD = x => L0 * Math.exp(-kd * x / vel); let mn = 99, xm = 0; for (let x = 0; x <= 300; x += 1) { const v = DO(x); if (v < mn) { mn = v; xm = x; } } return { kd, kr, Ds, DO, BOD, mn, xm }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), M = model(); const XM = 200;
      // river strip
      const ry = 14, rh = 46, x0 = 50, x1 = W - 14; for (let i = 0; i < x1 - x0; i += 2) { const km = -20 + (XM + 20) * i / (x1 - x0); const d = km < 0 ? M.Ds * 0.92 : M.DO(km); const f = Math.max(0, Math.min(1, d / 8)); g.fillStyle = `rgb(${Math.round(90 - 50 * f + 60 * (1 - f))},${Math.round(70 + 90 * f)},${Math.round(50 + 170 * f)})`; g.fillRect(x0 + i, ry, 2.2, rh); }
      const kmX = km => x0 + (km + 20) / (XM + 20) * (x1 - x0);
      // flow streaks
      g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1; for (let k = 0; k < 18; k++) { const xx = x0 + ((k * 53 + t * 40) % (x1 - x0)), yy = ry + 6 + (k * 17) % (rh - 12); g.beginPath(); g.moveTo(xx, yy); g.lineTo(xx + 12, yy); g.stroke(); }
      // sewer
      const sx = kmX(0); g.fillStyle = '#6b4a2b'; g.fillRect(sx - 6, ry - 12, 12, 14); g.fillStyle = 'rgba(90,60,30,.7)'; g.beginPath(); g.ellipse(sx + 10, ry + 8, 14, 6, 0, 0, 7); g.fill(); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('নর্দমা', sx, ry - 15 < 8 ? ry + rh + 10 : ry - 15);
      // fish
      fish.forEach(f => { const km = -20 + f.x * (XM + 20); const d = km < 0 ? M.Ds : M.DO(km); if (d < 5) return; const x = kmX(km), y = ry + 8 + f.y * (rh - 16); g.fillStyle = '#ffb347'; g.beginPath(); g.ellipse(x, y, 6, 3, 0, 0, 7); g.fill(); g.beginPath(); g.moveTo(x - 6 * f.d, y); g.lineTo(x - 10 * f.d, y - 3); g.lineTo(x - 10 * f.d, y + 3); g.fill(); });
      // chart
      const gx0 = 50, gy0 = ry + rh + 22, gw = W - 64, gh = H - gy0 - 34;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: -20, xmax: XM, ymax: 14, col, xt: [0, 50, 100, 150, 200], yt: [0, 2, 5, 8, 11, 14], xl: 'নর্দমা থেকে দূরত্ব (km)', yl: 'mg L⁻¹' });
      g.fillStyle = 'rgba(192,57,43,.08)'; g.fillRect(gx0, Pl.Y(5), gw, Pl.Y(0) - Pl.Y(5)); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText('মাছের জন্য বিপজ্জনক (< ৫)', gx0 + gw - 4, Pl.Y(5) + 11);
      path(g, [[Pl.X(-20), Pl.Y(M.Ds)], [Pl.X(XM), Pl.Y(M.Ds)]], col.mu, 1, [4, 3]); g.fillStyle = col.mu; g.textAlign = 'left'; g.fillText(`সম্পৃক্ত DO ${bn(M.Ds.toFixed(1))}`, Pl.X(-18), Pl.Y(M.Ds) - 4);
      const pd = [[Pl.X(-20), Pl.Y(M.Ds * 0.92)], [Pl.X(0), Pl.Y(M.Ds * 0.92)]]; for (let x = 0; x <= XM; x += 1) pd.push([Pl.X(x), Pl.Y(M.DO(x))]); path(g, pd, '#2d6fd6', 2.6);
      const pb = []; for (let x = 0; x <= XM; x += 2) pb.push([Pl.X(x), Pl.Y(Math.min(14, M.BOD(x)))]); path(g, pb, '#a8692b', 1.8, [5, 3]);
      if (M.xm < XM) { ball(g, Pl.X(M.xm), Pl.Y(M.mn), 5, '#c0392b', '#fff'); g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(`সর্বনিম্ন ${bn(M.mn.toFixed(1))}`, Pl.X(M.xm), Pl.Y(M.mn) + 16); }
      legend(g, col, gx0 + gw, gy0 + 2, [['#2d6fd6', 'DO'], ['#a8692b', 'অবশিষ্ট BOD', [5, 3]]], true);
    };
    const info = () => { q('[data-lv]').textContent = bn(L0); q('[data-tv]').textContent = bn(T); q('[data-vv]').textContent = bn(vel); const M = model(); let bad = 0; for (let x = 0; x <= 300; x++) if (M.DO(x) < 5) bad++;
      out.innerHTML = TXB(`D(t) = \\dfrac{k_d L_0}{k_r - k_d}\\left(e^{-k_d t} - e^{-k_r t}\\right) + D_0 e^{-k_r t}`) + `<div class="small">k<sub>d</sub> = ${bn(M.kd.toFixed(2))} দিন⁻¹ (বিয়োজন), k<sub>r</sub> = ${bn(M.kr.toFixed(2))} দিন⁻¹ (পুনঃবায়ুমিশ্রণ)। সর্বনিম্ন DO <b>${bn(M.mn.toFixed(1))} mg L⁻¹</b>, নর্দমা থেকে ${bn(M.xm)} km ভাটিতে। ${bad ? `প্রায় ${bn(bad)} km নদী মাছের জন্য বিপজ্জনক।` : 'পুরো নদীতে DO ≥ ৫ — মাছ নিরাপদ।'} D = সম্পৃক্ত DO থেকে ঘাটতি, t = দূরত্ব/প্রবাহ।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; fish.forEach(f => { f.x += f.d * dt * 0.01; if (f.x < 0 || f.x > 1) f.d *= -1; }); } draw(); }, { paused: false });
    [['l', v => L0 = v], ['t', v => T = v], ['v', v => vel = v]].forEach(([k, s]) => { q(`[data-${k}]`).oninput = e => { s(+e.target.value); info(); A.draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= BOD ও COD ল্যাব ======================= */
V.p2c1_bodcod = {
  t: 'BOD₅ ও COD নির্ণয়ের ভার্চুয়াল ল্যাব: BOD বোতলে ৫ দিনের DO হ্রাস এবং ডাইক্রোমেট রিফ্লাক্স ও Fe²⁺ পশ্চাৎ-টাইট্রেশন', k: ['int', 'calc', '2d', 'anim'],
  cap: '"BOD" দৃশ্যে ৩০০ mL বোতলে কত mL বর্জ্যপানি নেবে আর বর্জ্যের প্রকৃত BOD কত তা ঠিক করো; দিন স্লাইডারে ০ থেকে ৫ দিন এগোলে DO মিটার নামে। পরীক্ষা বৈধ হতে DO হ্রাস ≥ ২ ও অবশিষ্ট ≥ ১ mg L⁻¹ হতে হবে — অতিরিক্ত নমুনা নিলে ৫ দিনের আগেই অক্সিজেন শেষ। "COD" দৃশ্যে কমলা ডাইক্রোমেটের একটি অংশ নমুনার জৈব পদার্থ জারিত করে সবুজ Cr³⁺ হয়; অবশিষ্ট ডাইক্রোমেট Fe²⁺ দিয়ে টাইট্রেট করা হয় — ব্ল্যাংক ও নমুনার টাইটারের পার্থক্য থেকে COD।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('bc', [['bod', 'BOD₅'], ['cod', 'COD']], 'bod')}</div>${X.cv('BOD COD ল্যাব')}<div class="ctl" data-bodc><label class="small" style="flex:1;min-width:110px">নমুনা = <b data-sv></b> mL<input type="range" min="1" max="60" step="1" value="6" data-s></label><label class="small" style="flex:1;min-width:110px">প্রকৃত BOD₅ = <b data-bv></b> mg L⁻¹<input type="range" min="10" max="600" step="10" value="230" data-b></label><label class="small" style="flex:1;min-width:110px">দিন = <b data-dv></b><input type="range" min="0" max="5" step="0.1" value="5" data-d></label></div><div class="ctl" data-codc style="display:none"><label class="small" style="flex:1;min-width:110px">প্রকৃত COD = <b data-cv></b> mg L⁻¹<input type="range" min="50" max="900" step="10" value="480" data-c></label><label class="small" style="flex:1;min-width:110px">যোগ করা Fe²⁺ = <b data-fv></b> mL<input type="range" min="0" max="30" step="0.1" value="0" data-f></label><button class="btn sm" data-blank>ব্ল্যাংক</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 360;
    let L = X.fit(c, hf), md = 'bod', sv = 6, B5 = 230, day = 5, CODt = 480, fe = 0, blank = false; const D1 = 8.8, VS = 20, MFe = 0.1, VCr = 10, MCr = 0.04167; // 10 mL 0.04167 M dichromate (0.25 N)
    const bodD2 = () => Math.max(0, D1 - B5 * (sv / 300) * (1 - Math.exp(-0.23 * day)) / (1 - Math.exp(-0.23 * 5)));
    const crLeft = () => { const nCr = VCr * MCr / 1000; const used = blank ? 0 : CODt * VS / 1000 / 8000 / 6 * 1; /* mol Cr2O7 used = eq O2/6 */ const eqO = blank ? 0 : CODt / 1000 * VS / 1000 / 8; return Math.max(0, nCr - eqO / 6); };
    const endFe = () => crLeft() * 6 / MFe * 1000; // mL Fe2+ to endpoint
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 'bod') { const D2 = bodD2(); const bottle = (cx, lab, dv, dd) => { const bw = wd ? 70 : 56, bh = wd ? 150 : 120, by = 40; g.fillStyle = 'rgba(140,90,40,.35)'; rr(g, cx - bw / 2, by + 30, bw, bh, 12); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 2; rr(g, cx - bw / 2, by + 30, bw, bh, 12); g.stroke(); g.fillStyle = '#555'; g.fillRect(cx - 9, by + 4, 18, 28); g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(lab, cx, by - 4);
          // meter
          const mx = cx, my = by + bh + 70, mr = 26; g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.arc(mx, my, mr, Math.PI, 0); g.closePath(); g.fill(); g.stroke(); const a = Math.PI + Math.PI * Math.min(1, dv / 10); g.strokeStyle = dv < 1 ? '#c0392b' : '#2d6fd6'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(mx, my); g.lineTo(mx + Math.cos(a) * mr * 0.85, my + Math.sin(a) * mr * 0.85); g.stroke(); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.fillText(`DO ${bn(dv.toFixed(1))}`, mx, my + 14);
          // bacteria
          const Rn = X.rng(3); const nb = Math.round(8 + dd * 12); for (let k = 0; k < nb; k++) { const x = cx - bw / 2 + 8 + Rn() * (bw - 16), y = by + 40 + Rn() * (bh - 20); g.fillStyle = '#6a8e2e'; g.beginPath(); g.ellipse(x, y, 3, 1.6, Rn() * 3, 0, 7); g.fill(); } };
        const c1 = wd ? W * 0.18 : W * 0.25, c2 = wd ? W * 0.42 : W * 0.75; bottle(c1, 'দিন ০ (D₁)', D1, 0); bottle(c2, `দিন ${bn(day.toFixed(1))} (D₂)`, D2, day / 5);
        if (wd) { const gx0 = W * 0.58, gy0 = 30, gw = W - gx0 - 16, gh = H - 80; const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 5, ymax: 10, col, xt: [0, 1, 2, 3, 4, 5], yt: [0, 2, 4, 6, 8, 10], xl: 'দিন', yl: 'DO (mg L⁻¹)' }); const pts = []; for (let d = 0; d <= 5.001; d += 0.05) { const save = day; day = d; pts.push([Pl.X(d), Pl.Y(bodD2())]); day = save; } path(g, pts, '#2d6fd6', 2.4); ball(g, Pl.X(day), Pl.Y(D2), 5, '#2d6fd6', '#fff'); path(g, [[gx0, Pl.Y(1)], [gx0 + gw, Pl.Y(1)]], '#c0392b', 1, [4, 3]); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText('ন্যূনতম অবশিষ্ট ১', gx0 + gw - 4, Pl.Y(1) - 4); }
      } else { const left = crLeft(), endV = endFe(), frac = Math.min(1, fe / Math.max(0.01, endV)); const nCr = VCr * MCr / 1000; const usedFrac = 1 - left / nCr;
        // reflux flask
        const fx0 = wd ? W * 0.22 : W * 0.28, fy = H * 0.62, fr = wd ? 60 : 46; const remCr = left * (1 - Math.min(1, fe / Math.max(0.01, endV)));
        const orange = remCr / nCr; const green = 1 - orange; const cr = Math.round(230 * orange + 60 * green), cg = Math.round(120 * orange + 150 * green), cb2 = Math.round(30 * orange + 70 * green);
        const over = fe > endV + 0.05; g.fillStyle = over ? 'rgb(170,60,50)' : `rgb(${cr},${cg},${cb2})`; g.beginPath(); g.arc(fx0, fy, fr, 0, 7); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.arc(fx0, fy, fr, 0, 7); g.stroke(); g.fillStyle = col.bg; g.fillRect(fx0 - 10, fy - fr - 50, 20, 52); g.strokeRect(fx0 - 10, fy - fr - 50, 20, 52);
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(blank ? 'ব্ল্যাংক (নমুনা নেই)' : `নমুনা ${bn(VS)} mL + K₂Cr₂O₇`, fx0, fy + fr + 18);
        // burette
        const bx = wd ? W * 0.44 : W * 0.72, by0 = 20, bh = H * 0.55; g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.5; g.fillRect(bx - 8, by0, 16, bh); g.strokeRect(bx - 8, by0, 16, bh); const lvl = fe / 30; g.fillStyle = 'rgba(150,200,120,.7)'; g.fillRect(bx - 7, by0 + bh * lvl, 14, bh * (1 - lvl)); for (let k = 0; k <= 30; k += 5) { const y = by0 + bh * k / 30; g.fillStyle = col.fg; g.fillRect(bx + 8, y, 5, 1); g.font = `8px ${col.font}`; g.textAlign = 'left'; g.fillText(bn(k), bx + 15, y + 3); } g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('Fe²⁺ ০.১ M', bx, by0 + bh + 26);
        if (wd) { g.fillStyle = col.fg; g.font = `11px ${col.font}`; g.textAlign = 'left'; const tx = W * 0.58; [`ডাইক্রোমেট নেওয়া: ${bn((nCr * 1e3).toFixed(3))} mmol`, `নমুনা জারণে খরচ: ${bn((usedFrac * 100).toFixed(0))}%`, `অবশিষ্ট: ${bn((left * 1e3).toFixed(3))} mmol`, `শেষবিন্দুর জন্য Fe²⁺: ${bn(endV.toFixed(1))} mL`, fe >= endV - 0.05 ? (over ? 'শেষবিন্দু পেরিয়ে গেছে (লালচে-বাদামি)' : 'শেষবিন্দু! ফেরোইন: নীল-সবুজ → লালচে-বাদামি') : 'টাইট্রেশন চলছে…'].forEach((s, i) => g.fillText(s, tx, 50 + i * 22)); }
      }
    };
    const info = () => { q('[data-sv]').textContent = bn(sv); q('[data-bv]').textContent = bn(B5); q('[data-dv]').textContent = bn(day.toFixed(1)); q('[data-cv]').textContent = bn(CODt); q('[data-fv]').textContent = bn(fe.toFixed(1)); q('[data-blank]').classList.toggle('primary', blank);
      q('[data-bodc]').style.display = md === 'bod' ? '' : 'none'; q('[data-codc]').style.display = md === 'cod' ? '' : 'none';
      if (md === 'bod') { const D2 = bodD2(), P = sv / 300, dep = D1 - D2, valid = dep >= 2 && D2 >= 1; out.innerHTML = TXB(`P = \\dfrac{${sv}}{300} = ${P.toFixed(4)};\\quad \\mathrm{BOD} = \\dfrac{${D1} - ${D2.toFixed(2)}}{${P.toFixed(4)}} = ${(dep / P).toFixed(0)}\\ \\mathrm{mg\\,L^{-1}}`) + `<div class="small">${day < 5 ? `এখনো ${bn((5 - day).toFixed(1))} দিন বাকি — BOD₅ এর জন্য পুরো ৫ দিন লাগবে।` : valid ? '<b>বৈধ পরীক্ষা</b>: DO হ্রাস ≥ ২ ও অবশিষ্ট ≥ ১ mg L⁻¹।' : D2 < 1 ? '<b>অবৈধ</b>: DO প্রায় শেষ — নমুনা কম নিয়ে (বেশি পাতলা করে) আবার করো।' : '<b>অবৈধ</b>: DO হ্রাস ২ এর কম — বেশি নমুনা নাও।'}</div>`; }
      else { const endV = endFe(); const Ablank = (VCr * MCr / 1000) * 6 / MFe * 1000; out.innerHTML = TXB('\\ce{Cr2O7^2- + 6Fe^2+ + 14H+}') + TXB('\\ce{-> 2Cr^3+ + 6Fe^3+ + 7H2O}') + TXB(`\\begin{aligned}\\mathrm{COD} &= \\dfrac{(A - B)\\times0.1\\times8000}{${VS}}\\\\ &= \\dfrac{(${Ablank.toFixed(1)} - ${(blank ? Ablank : endFe()).toFixed(1)})\\times800}{${VS}} = ${blank ? 0 : (((Ablank - endV) * 800) / VS).toFixed(0)}\\ \\mathrm{mg\\,L^{-1}}\\end{aligned}`) + `<div class="small">ব্ল্যাংকে (A) সব ডাইক্রোমেট অবশিষ্ট, তাই বেশি Fe²⁺ লাগে; নমুনায় (B) কম। Fe²⁺ স্লাইডার টেনে শেষবিন্দু খুঁজে নাও।</div>`; } };
    const A = X.anim(el, dt => { draw(); }, { paused: true });
    X.onSeg(el, 'bc', k => { md = k; info(); draw(); });
    [['s', v => sv = v], ['b', v => B5 = v], ['d', v => day = v], ['c', v => CODt = v], ['f', v => fe = v]].forEach(([k, s]) => { q(`[data-${k}]`).oninput = e => { s(+e.target.value); info(); draw(); }; });
    q('[data-blank]').onclick = () => { blank = !blank; fe = 0; q('[data-f]').value = 0; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= খরতা: সাবান পরীক্ষা, ফুটানো, আয়ন বিনিময় ======================= */
V.p2c1_hardness = {
  t: 'পানির খরতা: সাবান পরীক্ষা, ফুটালে অস্থায়ী খরতা দূর (স্কেল গঠন) এবং আয়ন বিনিময় কলামে Ca²⁺ ⇄ Na⁺ (অ্যানিমেশন)', k: ['anim', 'int', '2d'],
  cap: '"সাবান" দৃশ্যে মৃদু ও খর পানির দুটি টেস্টটিউবে একই সাবান যোগ হচ্ছে — খর পানিতে প্রথমে সাদা গাদ (ক্যালসিয়াম স্টিয়ারেট) পড়ে, Ca²⁺ শেষ হলে তবেই ফেনা। "ফুটানো" দৃশ্যে Ca²⁺ (সবুজ) ও HCO₃⁻ (নীল) তাপে CaCO₃ হয়ে তলায় সাদা স্কেল জমায়, কিন্তু স্থায়ী খরতার Ca²⁺–SO₄²⁻ (হলুদ) দ্রবণে থেকে যায়। "আয়ন বিনিময়" দৃশ্যে খর পানি রেজিন কলামে ঢোকে, Ca²⁺ রেজিনে আটকে Na⁺ (বেগুনি) বেরিয়ে যায়; রেজিন নিঃশেষ হলে "লবণ পানিতে পুনরুজ্জীবন" চাপো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('hm', [['soap', 'সাবান পরীক্ষা'], ['boil', 'ফুটানো'], ['ion', 'আয়ন বিনিময়']], 'soap')}</div>${X.cv('খরতা')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:140px" data-hl>খরতা = <b data-hv></b> ppm<input type="range" min="50" max="500" step="10" value="250" data-h></label><button class="btn sm" data-regen style="display:none">লবণ পানিতে পুনরুজ্জীবন</button><button class="btn sm" data-rs>আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 380;
    let L = X.fit(c, hf), md = 'soap', hard = 250, t = 0, soap = 0, heat = 0, P = [], resin = 0, scale = 0, fresh = 0; const Rn = X.rng(17);
    const init = () => { t = 0; soap = 0; heat = 0; scale = 0; resin = 0; fresh = 0; P = [];
      if (md === 'boil') { const nt = Math.round(hard / 25), np = Math.round(hard / 60); for (let i = 0; i < nt; i++) P.push({ k: 'T', x: Rn(), y: Rn(), vx: 0, vy: 0 }); for (let i = 0; i < np; i++) P.push({ k: 'P', x: Rn(), y: Rn(), vx: 0, vy: 0 }); }
      if (md === 'ion') { for (let i = 0; i < 60; i++) P.push({ k: 'bead', x: 0.15 + (i % 6) * 0.14, y: 0.25 + Math.floor(i / 6) * 0.06, ca: 0 }); } };
    init();
    const step = dt => { t += dt;
      if (md === 'soap') soap = Math.min(1, soap + dt * 0.08);
      if (md === 'boil') { heat = Math.min(1, heat + dt * 0.12); P.forEach(p => { const sp = 0.3 + heat; p.vx += (Rn() - .5) * dt * sp; p.vy += (Rn() - .5) * dt * sp - (heat > 0.2 ? dt * 0.1 : 0); p.vx *= 0.95; p.vy *= 0.95; p.x = Math.max(0.03, Math.min(0.97, p.x + p.vx * dt)); p.y = Math.max(0.05, Math.min(0.95, p.y + p.vy * dt)); if (p.k === 'T' && heat > 0.3 && Rn() < dt * 0.6 * heat) { p.k = 'S'; scale++; } if (p.k === 'S') { p.y = Math.min(0.97, p.y + dt * 0.5); p.vx = 0; } }); }
      if (md === 'ion') { if (Rn() < dt * 3) { const r = Rn(); P.push({ k: 'Ca', x: 0.3 + Rn() * 0.4, y: -0.05 }); } P.forEach(p => { if (p.k === 'Ca' || p.k === 'Na') { p.y += dt * 0.12; p.x += (Rn() - .5) * dt * 0.05; if (p.k === 'Ca' && p.y > 0.25 && p.y < 0.85) { const free = P.filter(b => b.k === 'bead' && b.ca === 0 && Math.abs(b.y - p.y) < 0.06); if (free.length) { const b = free[0]; b.ca = 1; resin++; p.k = 'Na'; p.x = b.x; } } if (p.y > 1.05) { p.dead = true; if (p.k === 'Na') fresh++; } } }); P = P.filter(p => !p.dead); } };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 'soap') { const tube = (cx, lab, hd) => { const tw = wd ? 70 : 60, th = H * 0.62, ty = 40; const need = hd / 500; const scumF = Math.min(soap, need) / Math.max(need, 1e-6) * (hd > 0 ? 1 : 0), foamF = Math.max(0, soap - need) / Math.max(0.01, 1 - need);
          g.fillStyle = 'rgba(150,200,240,.35)'; rr(g, cx - tw / 2, ty + 40, tw, th - 40, tw / 2); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(cx - tw / 2, ty); g.lineTo(cx - tw / 2, ty + th - tw / 2); g.arc(cx, ty + th - tw / 2, tw / 2, Math.PI, 0, true); g.lineTo(cx + tw / 2, ty); g.stroke();
          const Rr = X.rng(cx | 0); const ns = Math.round(scumF * hd / 8); for (let k = 0; k < ns; k++) { const x = cx - tw / 2 + 6 + Rr() * (tw - 12), y = ty + 50 + Rr() * (th - 70) * 0.5 + Math.sin(t * 2 + k) * 2; g.fillStyle = 'rgba(245,245,240,.95)'; g.beginPath(); g.ellipse(x, y, 4, 2.4, Rr(), 0, 7); g.fill(); g.strokeStyle = 'rgba(150,150,150,.6)'; g.lineWidth = .6; g.stroke(); }
          const fh = foamF * 50; for (let k = 0; k < fh * 1.4; k++) { const x = cx - tw / 2 + 5 + Rr() * (tw - 10), y = ty + 40 - Rr() * fh; g.strokeStyle = 'rgba(200,220,255,.9)'; g.fillStyle = 'rgba(255,255,255,.75)'; g.beginPath(); g.arc(x, y, 3 + Rr() * 3, 0, 7); g.fill(); g.stroke(); }
          g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(lab, cx, ty + th + 18); g.font = `9.5px ${col.font}`; g.fillText(foamF > 0.05 ? 'ফেনা ✓' : hd > 0 ? 'গাদ, ফেনা নেই' : '', cx, ty + th + 32); };
        tube(W * 0.3, 'মৃদু পানি', 0); tube(W * 0.7, `খর পানি (${bn(hard)} ppm)`, hard);
        const dx = W / 2, dy = 30 + Math.sin(t * 3) * 3; g.fillStyle = '#e8d8a0'; g.beginPath(); g.ellipse(dx, dy, 6, 9, 0, 0, 7); g.fill(); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.fillText(`সাবান যোগ: ${bn(Math.round(soap * 100))}%`, dx, 14); }
      else if (md === 'boil') { const kx = wd ? W * 0.32 : W / 2, kw = wd ? W * 0.46 : W * 0.8, ky = 30, kh = H * 0.66; const bx0 = kx - kw / 2;
        g.fillStyle = `rgba(150,200,240,${0.3 + 0.1 * heat})`; g.fillRect(bx0, ky, kw, kh); g.strokeStyle = col.fg; g.lineWidth = 2; g.strokeRect(bx0, ky, kw, kh);
        for (let k = 0; k < 7; k++) { const fx2 = bx0 + kw * (k + 0.5) / 7, fh = 10 + heat * 14 * (1 + 0.3 * Math.sin(t * 9 + k)); const gg = g.createLinearGradient(0, ky + kh + 4 + fh, 0, ky + kh + 4); gg.addColorStop(0, 'rgba(255,120,0,0)'); gg.addColorStop(1, 'rgba(255,150,30,.9)'); g.fillStyle = gg; g.beginPath(); g.ellipse(fx2, ky + kh + 4 + fh / 2, 5, fh / 2, 0, 0, 7); g.fill(); }
        if (heat > 0.5) for (let k = 0; k < 12; k++) { const x = bx0 + ((k * 0.083 + t * 0.05) % 1) * kw, y = ky + kh - ((t * 40 + k * 23) % kh); g.strokeStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.arc(x, y, 2.5, 0, 7); g.stroke(); }
        const sc = P.filter(p => p.k === 'S').length; g.fillStyle = 'rgba(240,240,232,.95)'; g.fillRect(bx0 + 1, ky + kh - Math.min(10, sc * 0.6), kw - 2, Math.min(10, sc * 0.6));
        P.forEach(p => { const x = bx0 + 6 + p.x * (kw - 12), y = ky + 6 + p.y * (kh - 12); if (p.k === 'T') { ball(g, x - 4, y, 4, '#2f9e44', '#c8f0cf'); ball(g, x + 4, y - 3, 3, '#2d6fd6', '#a9c8ff'); ball(g, x + 4, y + 4, 3, '#2d6fd6', '#a9c8ff'); } else if (p.k === 'P') { ball(g, x - 3, y, 4, '#2f9e44', '#c8f0cf'); ball(g, x + 4, y, 4, '#d6b21e', '#fff2a8'); } else { g.fillStyle = '#fff'; g.strokeStyle = '#999'; g.fillRect(x - 3, y - 3, 6, 6); g.strokeRect(x - 3, y - 3, 6, 6); } });
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(heat < 0.3 ? 'গরম হচ্ছে…' : 'ফুটছে — CO₂ বেরিয়ে যাচ্ছে', kx, ky - 8);
        if (wd) { const lx = W * 0.62; [['#2f9e44', '#2d6fd6', 'Ca²⁺ + 2HCO₃⁻ (অস্থায়ী)'], ['#2f9e44', '#d6b21e', 'Ca²⁺ + SO₄²⁻ (স্থায়ী)'], ['#fff', '#999', 'CaCO₃ (স্কেল)']].forEach(([a, b, s], i) => { ball(g, lx, 50 + i * 26, 5, a, '#fff'); ball(g, lx + 11, 50 + i * 26, 4, b, '#fff'); g.fillStyle = col.fg; g.font = `10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(s, lx + 22, 54 + i * 26); }); const T0 = P.filter(p => p.k === 'T').length, S0 = P.filter(p => p.k === 'S').length, P0 = P.filter(p => p.k === 'P').length; g.fillText(`অবশিষ্ট অস্থায়ী: ${bn(T0)} · স্কেল: ${bn(S0)} · স্থায়ী: ${bn(P0)}`, lx, 140); } }
      else { const cx = wd ? W * 0.32 : W / 2, cw = wd ? W * 0.3 : W * 0.6, cy0 = 20, ch = H - 40; const X_ = x => cx - cw / 2 + x * cw, Y_ = y => cy0 + y * ch;
        g.fillStyle = col.s2 || 'rgba(0,0,0,.04)'; g.fillRect(cx - cw / 2, cy0, cw, ch); g.strokeStyle = col.fg; g.lineWidth = 2; g.strokeRect(cx - cw / 2, Y_(0.2), cw, ch * 0.68);
        P.forEach(p => { if (p.k === 'bead') { const x = X_(p.x), y = Y_(p.y); ball(g, x, y, wd ? 9 : 7, p.ca ? '#2f9e44' : '#d6c08a', p.ca ? '#c8f0cf' : '#fff6d8'); g.fillStyle = '#333'; g.font = `bold ${wd ? 7 : 6}px ${col.font}`; g.textAlign = 'center'; g.fillText(p.ca ? 'Ca' : 'Na₂', x, y + 2.5); } });
        P.forEach(p => { if (p.k === 'Ca') ball(g, X_(p.x), Y_(p.y), 4.5, '#2f9e44', '#c8f0cf'); else if (p.k === 'Na') { ball(g, X_(p.x) - 3, Y_(p.y), 3.5, '#7b3fa0', '#e0c8f0'); ball(g, X_(p.x) + 4, Y_(p.y) + 3, 3.5, '#7b3fa0', '#e0c8f0'); } });
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('খর পানি ↓ (Ca²⁺)', cx, 14); g.fillText('মৃদু পানি ↓ (Na⁺)', cx, H - 6);
        const cap = resin / 60; const bx = wd ? W * 0.62 : 6, by = wd ? 40 : H - 30, bw = wd ? W * 0.32 : 0; if (wd) { g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('রেজিনের ব্যবহৃত ক্ষমতা', bx, by); g.strokeStyle = col.fg; g.strokeRect(bx, by + 8, bw, 14); g.fillStyle = cap > 0.85 ? '#c0392b' : '#e0a020'; g.fillRect(bx, by + 8, bw * cap, 14); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText(`${bn(Math.round(cap * 100))}% — ${cap > 0.95 ? 'নিঃশেষ! Ca²⁺ আর আটকাচ্ছে না' : 'Ca²⁺ আটকানো হচ্ছে'}`, bx, by + 40); g.fillText(`মৃদু পানিতে Na⁺ বের হয়েছে: ${bn(fresh)} জোড়া`, bx, by + 60); } }
    };
    const info = () => { q('[data-hv]').textContent = bn(hard); q('[data-hl]').style.display = md === 'ion' ? 'none' : ''; q('[data-regen]').style.display = md === 'ion' ? '' : 'none';
      out.innerHTML = md === 'soap' ? TXB('\\ce{2C17H35COO- + Ca^2+ -> (C17H35COO)2Ca v}') + `<div class="small">খর পানিতে সব Ca²⁺/Mg²⁺ অধঃক্ষিপ্ত না হওয়া পর্যন্ত সাবান নষ্ট হয়; খরতা যত বেশি, ফেনার আগে তত বেশি সাবান লাগে।</div>`
        : md === 'boil' ? TXB('\\ce{Ca(HCO3)2 ->[\\Delta] CaCO3 v + H2O + CO2 ^}') + '<div class="small">ফুটালে কেবল অস্থায়ী (বাইকার্বনেট) খরতা দূর হয়; CaSO₄, CaCl₂ এর স্থায়ী খরতা থেকে যায় — সোডা বা আয়ন বিনিময় লাগবে।</div>'
        : TXB('\\ce{Na2Z + Ca^2+ -> CaZ + 2Na+}') + TXB('\\ce{CaZ + 2NaCl -> Na2Z + CaCl2}\\ (\\text{পুনরুজ্জীবন})') + '<div class="small">প্রতিটি Ca²⁺ এর বদলে দুটি Na⁺ — পানি মৃদু হয় কিন্তু Na⁺ বাড়ে।</div>'; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'hm', k => { md = k; init(); info(); A.draw(); });
    q('[data-h]').oninput = e => { hard = +e.target.value; init(); info(); A.draw(); };
    q('[data-rs]').onclick = () => { init(); A.draw(); };
    q('[data-regen]').onclick = () => { P.forEach(p => { if (p.k === 'bead') p.ca = 0; }); resin = 0; A.draw(); };
    for (let i = 0; i < 60; i++) step(0.05);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= EDTA টাইট্রেশন ======================= */
V.p2c1_edta = {
  t: 'EDTA টাইট্রেশনে পানির খরতা নির্ণয়: EBT নির্দেশক, pH ১০ বাফার, মদ-লাল থেকে নীল শেষবিন্দু (ভার্চুয়াল টাইট্রেশন)', k: ['int', 'calc', '2d', 'anim'],
  cap: 'কনিক্যাল ফ্লাস্কে ৫০ mL নমুনা + NH₃/NH₄Cl বাফার + EBT — মদ-লাল রং (Ca/Mg–EBT জটিল)। বুরেট থেকে ০.০১ M EDTA ফোঁটায় ফোঁটায় যোগ করো (বোতাম বা স্লাইডার)। শেষবিন্দুর কাছে রং বেগুনি হয়ে তারপর স্পষ্ট নীল। একটি "অজানা" নমুনা বেছে নিয়ে টাইটার থেকে নিজে খরতা বের করো; "ফুটানো নমুনা" দিয়ে স্থায়ী খরতা মেপে অস্থায়ী খরতা নির্ণয় করো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('es', [['a', 'নমুনা A'], ['b', 'নমুনা B'], ['c', 'নমুনা C']], 'a')}<label class="small"><input type="checkbox" data-boil> ফুটানো নমুনা</label></div>${X.cv('EDTA টাইট্রেশন')}<div class="ctl"><button class="btn sm" data-add1>+১ ফোঁটা (০.০৫ mL)</button><button class="btn sm" data-add10>+১ mL</button><label class="small" style="flex:1;min-width:140px">EDTA = <b data-vv></b> mL<input type="range" min="0" max="30" step="0.05" value="0" data-v></label><button class="btn sm" data-rs>খালি করো</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 360;
    let L = X.fit(c, hf), smp = 'a', boil = false, v = 0, t = 0, drip = 0;
    const SM = { a: [240, 150], b: [130, 40], c: [380, 300] }; // total, permanent ppm
    const hardOf = () => SM[smp][boil ? 1 : 0];
    const endV = () => hardOf() * 50 / (0.01 * 1e5); // mL
    const color = () => { const e = endV(); const u = Math.max(0, Math.min(1, (v - (e - 0.35)) / 0.35)); const wine = [150, 30, 70], blue = [40, 80, 200]; return wine.map((w, k) => Math.round(w + (blue[k] - w) * u)); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const cx = wd ? W * 0.3 : W * 0.4, by0 = 12, bh = H * 0.5, fy = H - 20;
      // burette
      g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.5; g.fillRect(cx - 7, by0, 14, bh); g.strokeRect(cx - 7, by0, 14, bh); const lv = v / 30; g.fillStyle = 'rgba(200,220,255,.8)'; g.fillRect(cx - 6, by0 + bh * lv, 12, bh * (1 - lv)); for (let k = 0; k <= 30; k += 5) { const y = by0 + bh * k / 30; g.fillStyle = col.fg; g.fillRect(cx + 7, y, 5, 1); g.font = `8px ${col.font}`; g.textAlign = 'left'; g.fillText(bn(k), cx + 14, y + 3); } g.fillRect(cx - 2, by0 + bh, 4, 16); g.fillStyle = '#555'; g.fillRect(cx - 9, by0 + bh + 4, 18, 5);
      if (drip > 0) { const dy = by0 + bh + 20 + (1 - drip) * 30; g.fillStyle = 'rgba(200,220,255,.9)'; g.beginPath(); g.arc(cx, dy, 2.5, 0, 7); g.fill(); }
      // flask
      const fw = wd ? 120 : 100, fh = wd ? 100 : 86, ftop = fy - fh; const [r, gg, b] = color(); g.fillStyle = `rgb(${r},${gg},${b})`; g.beginPath(); g.moveTo(cx - 12, ftop); g.lineTo(cx - fw / 2, fy); g.lineTo(cx + fw / 2, fy); g.lineTo(cx + 12, ftop); g.closePath(); g.save(); g.clip(); g.fillRect(cx - fw / 2, ftop + fh * 0.35, fw, fh); g.restore(); g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(cx - 12, ftop - 12); g.lineTo(cx - 12, ftop); g.lineTo(cx - fw / 2, fy); g.lineTo(cx + fw / 2, fy); g.lineTo(cx + 12, ftop); g.lineTo(cx + 12, ftop - 12); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`৫০ mL ${boil ? 'ফুটানো ' : ''}নমুনা ${smp.toUpperCase()}`, cx, fy + 14);
      // molecular inset
      if (wd) { const ix = W * 0.55, iy = 20, iw = W * 0.42, ih = H - 40; g.fillStyle = col.sf; g.strokeStyle = col.line || col.mu; g.lineWidth = 1; rr(g, ix, iy, iw, ih, 10); g.fill(); g.stroke(); g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('আণবিক দৃশ্য', ix + 10, iy + 16);
        const e = endV(), fr = Math.min(1, v / e); const N = 12, Rr = X.rng(5);
        for (let k = 0; k < N; k++) { const x = ix + 20 + Rr() * (iw - 40), y = iy + 30 + Rr() * (ih - 50), bound = k < Math.round(fr * N); if (bound) { ball(g, x, y, 6, '#2f9e44', '#c8f0cf'); g.strokeStyle = '#2d6fd6'; g.lineWidth = 2; g.beginPath(); for (let a = 0; a < 6; a++) { const aa = a * Math.PI / 3 + t; g.lineTo(x + Math.cos(aa) * 11, y + Math.sin(aa) * 11); } g.closePath(); g.stroke(); } else { ball(g, x, y, 6, '#2f9e44', '#c8f0cf'); g.fillStyle = '#a0204a'; g.beginPath(); g.arc(x + 9, y - 2, 4, 0, 7); g.fill(); } }
        g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.fillText('সবুজ = Ca²⁺/Mg²⁺; লাল বিন্দু = EBT জটিল (মদ-লাল)', ix + 10, iy + ih - 22); g.fillText('নীল ষড়ভুজ = EDTA জটিল (MY²⁻)', ix + 10, iy + ih - 8); }
    };
    const info = () => { q('[data-vv]').textContent = bn(v.toFixed(2)); q('[data-v]').value = v; const e = endV(), at = Math.abs(v - e) <= 0.1, past = v > e + 0.1;
      out.innerHTML = `<div>${at ? '<b>শেষবিন্দু!</b> রং স্পষ্ট নীল।' : past ? 'শেষবিন্দু পেরিয়ে গেছে — নীল রং আর বদলাবে না; আবার শুরু করো।' : v > e - 0.6 ? 'রং বেগুনি হচ্ছে — শেষবিন্দু কাছে, এখন ফোঁটায় ফোঁটায় দাও।' : 'মদ-লাল — এখনো মুক্ত Ca²⁺/Mg²⁺ আছে।'}</div>` + (at || past ? TXB(`\\text{খরতা} = \\dfrac{${v.toFixed(2)}\\times0.01\\times10^5}{50} = ${(v * 0.01 * 1e5 / 50).toFixed(0)}\\ \\text{ppm CaCO}_3`) + `<div class="small">${boil ? `এটি স্থায়ী খরতা। নমুনা ${smp.toUpperCase()} এর মোট খরতা ${bn(SM[smp][0])} ppm হলে অস্থায়ী = ${bn(SM[smp][0] - SM[smp][1])} ppm।` : 'এটি মোট খরতা। "ফুটানো নমুনা" চেক করে স্থায়ী খরতা মাপো।'}</div>` : TXB('\\ce{M^2+ + H2Y^2- -> MY^2- + 2H+}\\quad (\\text{১:১})')); };
    const A = X.anim(el, dt => { if (dt) { t += dt; drip = Math.max(0, drip - dt * 3); } draw(); }, { paused: false });
    const add = d => { v = Math.min(30, +(v + d).toFixed(2)); drip = 1; info(); A.draw(); };
    q('[data-add1]').onclick = () => add(0.05); q('[data-add10]').onclick = () => add(1);
    q('[data-v]').oninput = e => { v = +e.target.value; info(); A.draw(); };
    q('[data-rs]').onclick = () => { v = 0; info(); A.draw(); };
    q('[data-boil]').onchange = e => { boil = e.target.checked; v = 0; info(); A.draw(); };
    X.onSeg(el, 'es', k => { smp = k; v = 0; info(); A.draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
