/* ২য় পত্র অধ্যায় ১ visuals part 17 — solutions: concentration units, Henry's law, soda & diving (1.23) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const SUPM = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sciB = v => { if (v === 0) return '০'; const e = Math.floor(Math.log10(Math.abs(v))); if (e >= -2 && e <= 3) return bn((+v.toPrecision(3)).toString()); const m = v / Math.pow(10, e); return `${bn(m.toFixed(2))} × ১০${String(e).split('').map(ch => SUPM[ch]).join('')}`; };
const sci = v => { if (v === 0) return '0'; const e = Math.floor(Math.log10(Math.abs(v))); if (e >= -2 && e <= 3) return (+v.toPrecision(3)).toString(); const m = v / Math.pow(10, e); return `${m.toFixed(2)}\\times10^{${e}}`; };

/* ======================= ঘনত্বের একক রূপান্তরক ======================= */
const SOL = { nacl: ['NaCl', 58.5, 'লবণ'], h2so4: ['H₂SO₄', 98, 'সালফিউরিক এসিড'], glu: ['C₆H₁₂O₆', 180, 'গ্লুকোজ'], as: ['As', 74.9, 'আর্সেনিক (দূষক)'], naoh: ['NaOH', 40, 'কস্টিক সোডা'] };
V.p2c1_concUnits = {
  t: 'দ্রবণের ঘনত্বের একক রূপান্তরক: % (w/w, w/v), মোলারিটি, মোলালিটি, মোল ভগ্নাংশ, ppm ও ppb — একই দ্রবণ সাত এককে', k: ['int', 'calc', '2d'],
  cap: 'দ্রাব বেছে নাও, তারপর দ্রাবের ভর, পানির (দ্রাবকের) ভর এবং দ্রবণের ঘনত্ব ঠিক করো। বিকারের ছবিতে দ্রাব (রঙিন বিন্দু) ও দ্রাবক অণুর অনুপাত দেখায়, আর ডানে একই দ্রবণের ঘনত্ব সাতটি এককে — সাথে ধাপে ধাপে রূপান্তর। আর্সেনিকের মতো অতি লঘু দ্রবণে দেখো ppm ও mg L⁻¹ প্রায় সমান কিন্তু ঘন H₂SO₄ এ নয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('sl', Object.entries(SOL).map(([k, v]) => [k, v[0]]), 'nacl')}</div>${X.cv('একক রূপান্তর')}<div class="ctl"><label class="small" style="flex:1;min-width:120px">দ্রাব = <b data-av></b> g<input type="range" min="-5" max="3" step="0.05" value="1" data-a></label><label class="small" style="flex:1;min-width:120px">পানি = <b data-bv></b> g<input type="range" min="10" max="1000" step="10" value="500" data-b></label><label class="small" style="flex:1;min-width:120px">ঘনত্ব ρ = <b data-dv></b> g mL⁻¹<input type="range" min="0.95" max="1.9" step="0.01" value="1.01" data-d></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 280 : 470;
    let L = X.fit(c, hf), sl = 'nacl', la = 1, wb = 500, rho = 1.01;
    const calc = () => { const S = SOL[sl], m = Math.pow(10, la), n = m / S[1], ms = m + wb, V = ms / rho / 1000, nw = wb / 18.02; return { m, n, ms, V, ww: m / ms * 100, wv: m / (V * 1000) * 100, M: n / V, mol: n / (wb / 1000), x: n / (n + nw), ppm: m / ms * 1e6, mgL: m * 1000 / V }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), R = calc(), S = SOL[sl];
      const bx = wd ? W * 0.17 : W / 2, by = 30, bw = wd ? 150 : 140, bh = wd ? H - 60 : 170;
      g.fillStyle = 'rgba(140,190,240,.3)'; g.fillRect(bx - bw / 2, by + 16, bw, bh - 16); g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(bx - bw / 2 - 4, by); g.lineTo(bx - bw / 2, by + bh); g.lineTo(bx + bw / 2, by + bh); g.lineTo(bx + bw / 2 + 4, by); g.stroke();
      const Rn = X.rng(3), NW = 70; for (let k = 0; k < NW; k++) { const x = bx - bw / 2 + 6 + Rn() * (bw - 12), y = by + 22 + Rn() * (bh - 30); g.fillStyle = 'rgba(80,140,220,.5)'; g.beginPath(); g.arc(x, y, 2.4, 0, 7); g.fill(); }
      const ns = Math.max(0, Math.min(60, Math.round(R.x * NW * (R.x > 0.01 ? 1 : 300)))); const Rn2 = X.rng(9); for (let k = 0; k < ns; k++) { const x = bx - bw / 2 + 6 + Rn2() * (bw - 12), y = by + 22 + Rn2() * (bh - 30); g.fillStyle = '#c0392b'; g.beginPath(); g.arc(x, y, 3, 0, 7); g.fill(); }
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`${S[0]} (${S[2]})`, bx, by + bh + 16); if (R.x < 0.01) { g.font = `9px ${col.font}`; g.fillStyle = col.mu; g.fillText('দ্রাব বিন্দু অতিরঞ্জিত', bx, by + bh + 28); }
      // table
      const tx = wd ? W * 0.36 : 12, ty = wd ? 22 : by + bh + 44, tw = wd ? W * 0.62 : W - 24; const rows = [['% (w/w)', R.ww], ['% (w/v)', R.wv], ['মোলারিটি (mol L⁻¹)', R.M], ['মোলালিটি (mol kg⁻¹)', R.mol], ['মোল ভগ্নাংশ', R.x], ['ppm (ভর)', R.ppm], ['mg L⁻¹', R.mgL], ['ppb (ভর)', R.ppm * 1000]]; const rh = wd ? (H - 40) / rows.length : 22;
      rows.forEach(([nm, v], i) => { const y = ty + i * rh; if (i % 2) { g.fillStyle = col.s2 || 'rgba(0,0,0,.04)'; g.fillRect(tx, y, tw, rh); } g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(nm, tx + 8, y + rh / 2 + 4); g.font = `11px ${col.mono || col.font}`; g.textAlign = 'right'; g.fillText(sciB(v), tx + tw - 8, y + rh / 2 + 4); });
    };
    const info = () => { const R = calc(), S = SOL[sl]; q('[data-av]').textContent = bn(R.m < 0.01 ? R.m.toExponential(1) : (+R.m.toPrecision(3)).toString()); q('[data-bv]').textContent = bn(wb); q('[data-dv]').textContent = bn(rho.toFixed(2));
      out.innerHTML = TXB(`\\begin{aligned}n &= \\frac{${sci(R.m)}}{${S[1]}} = ${sci(R.n)}\\ \\mathrm{mol}\\\\ V &= \\frac{${sci(R.ms)}}{${rho.toFixed(2)}} = ${sci(R.V * 1000)}\\ \\mathrm{mL}\\\\ M &= \\frac{n}{V} = ${sci(R.M)}\\ \\mathrm{M}\\\\ m &= \\frac{n}{${(wb / 1000).toFixed(2)}\\ \\mathrm{kg}} = ${sci(R.mol)}\\ \\mathrm{mol\\,kg^{-1}}\\end{aligned}`) + `<div class="small">${R.ww < 0.1 ? `অতি লঘু দ্রবণ: ppm (${bn((+R.ppm.toPrecision(3)).toString())}) ≈ mg L⁻¹ (${bn((+R.mgL.toPrecision(3)).toString())}), মোলারিটি ≈ মোলালিটি।` : `ঘন দ্রবণ: ppm ও mg L⁻¹ এর পার্থক্য ${bn(Math.abs((R.mgL / R.ppm - 1) * 100).toFixed(1))}% — ঘনত্ব ১ নয় বলে; মোলারিটি ও মোলালিটিও আলাদা।`} বাস্তব ঘনত্ব দ্রাব ও ঘনত্বের উপর নির্ভর করে — স্লাইডারে আনুমানিক মান দাও।</div>`; };
    X.onSeg(el, 'sl', k => { sl = k; if (k === 'as') { la = -4.3; wb = 1000; rho = 1.0; } else if (k === 'h2so4') { la = 2.69; wb = 10; rho = 1.84; } else { la = 1; wb = 500; rho = 1.01; } q('[data-a]').value = la; q('[data-b]').value = wb; q('[data-d]').value = rho; info(); draw(); });
    [['a', v => la = v], ['b', v => wb = v], ['d', v => rho = v]].forEach(([k, s]) => { q(`[data-${k}]`).oninput = e => { s(+e.target.value); info(); draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= হেনরির সূত্র: পিস্টন ও দ্রাব্যতা ======================= */
const GAS = { o2: ['O₂', 1.3e-3, 1700, 32, '#c0392b'], n2: ['N₂', 6.1e-4, 1300, 28, '#2d6fd6'], co2: ['CO₂', 3.4e-2, 2400, 44, '#555'], he: ['He', 3.7e-4, 230, 4, '#d6a01e'] };
const KH = (g, T) => GAS[g][1] * Math.exp(GAS[g][2] * (1 / T - 1 / 298.15));
V.p2c1_henry = {
  t: 'হেনরির সূত্র: পিস্টনের চাপ বাড়ালে তরলে দ্রবীভূত গ্যাসের পরিমাণ সমানুপাতে বাড়ে; তাপমাত্রা বাড়ালে কমে (অ্যানিমেশন ও লেখচিত্র)', k: ['anim', 'int', 'calc', '2d'],
  cap: 'একটি আবদ্ধ পাত্রে পানির উপরে গ্যাস ও একটি পিস্টন। গ্যাস অণু পানির তলে আঘাত করে কিছু দ্রবীভূত হয় (পানিতে ঢোকা বিন্দু), কিছু বেরিয়ে আসে — সাম্যাবস্থায় দ্রবীভূত সংখ্যা স্থির। চাপ স্লাইডারে পিস্টন নামাও: গ্যাস ঘন হয়, বেশি অণু দ্রবীভূত হয়। ডানে C বনাম p সরলরেখা (ঢাল = K_H); তাপমাত্রা বাড়ালে ঢাল কমে। চারটি গ্যাস তুলনা করো — CO₂ এর ঢাল অনেক বেশি।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('gs', Object.entries(GAS).map(([k, v]) => [k, v[0]]), 'co2')}</div>${X.cv('হেনরির সূত্র')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:120px">আংশিক চাপ p = <b data-pv></b> atm<input type="range" min="0.2" max="5" step="0.1" value="1" data-p></label><label class="small" style="flex:1;min-width:120px">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="0" max="60" step="1" value="25" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 520;
    let L = X.fit(c, hf), gs = 'co2', p = 1, Tc = 25, t = 0; const Rn = X.rng(66); let G = [], D = [];
    const target = () => { const kh = KH(gs, Tc + 273.15); const maxC = KH('co2', 273.15) * 5; return Math.round(70 * kh * p / maxC * (gs === 'co2' ? 1 : 25)); };
    const geo = () => { const { W, H } = L, wd = wide(W); const vx = wd ? 30 : W * 0.15, vw = wd ? W * 0.38 : W * 0.7, vy = 20, vh = wd ? H - 40 : 260; const lev = vy + vh * 0.6; const pis = vy + (vh * 0.55) * (1 - 1 / p) * 0.85 + 6; return { wd, vx, vw, vy, vh, lev, pis }; };
    const step = dt => { t += dt; const { vx, vw, lev, pis } = geo(); const nG = Math.round(16 * p); while (G.length < nG) G.push({ x: Rn(), y: Rn(), vx: (Rn() - .5), vy: (Rn() - .5) }); while (G.length > nG) G.pop(); const tg = target(); if (D.length < tg && Rn() < dt * 6) D.push({ x: Rn(), y: 0.02, vx: 0, vy: 0.2 }); if (D.length > tg && Rn() < dt * 6) { D.shift(); } G.forEach(m => { m.x += m.vx * dt * 0.6; m.y += m.vy * dt * 0.6; if (m.x < 0 || m.x > 1) { m.vx *= -1; m.x = Math.max(0, Math.min(1, m.x)); } if (m.y < 0 || m.y > 1) { m.vy *= -1; m.y = Math.max(0, Math.min(1, m.y)); } }); D.forEach(m => { m.x += (Rn() - .5) * dt * 0.08; m.y += (m.vy * dt) * (m.y < 0.2 ? 1 : 0.1) + (Rn() - .5) * dt * 0.05; m.x = Math.max(0.02, Math.min(0.98, m.x)); m.y = Math.max(0.02, Math.min(0.97, m.y)); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const { wd, vx, vw, vy, vh, lev, pis } = geo(), Gc = GAS[gs];
      g.fillStyle = 'rgba(120,170,230,.35)'; g.fillRect(vx, lev, vw, vy + vh - lev); g.strokeStyle = col.fg; g.lineWidth = 2; g.strokeRect(vx, vy, vw, vh);
      g.fillStyle = '#8a9099'; g.fillRect(vx + 2, pis - 8, vw - 4, 10); g.fillRect(vx + vw / 2 - 5, vy - 14, 10, pis - vy + 4); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`p = ${bn(p.toFixed(1))} atm`, vx + vw / 2, pis - 12 < vy ? pis + 18 : pis - 12);
      G.forEach(m => { const x = vx + 6 + m.x * (vw - 12), y = pis + 8 + m.y * (lev - pis - 14); ball(g, x, y, 3.2, Gc[4], '#fff'); });
      D.forEach(m => { const x = vx + 6 + m.x * (vw - 12), y = lev + 4 + m.y * (vy + vh - lev - 8); ball(g, x, y, 2.8, Gc[4], '#fff'); });
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`পানি, ${bn(Tc)} °C`, vx + 6, vy + vh - 6);
      const gx0 = wd ? W * 0.52 : 50, gy0 = wd ? 20 : vy + vh + 26, gw = wd ? W * 0.45 : W - 66, gh = wd ? H - 60 : H - gy0 - 40; const kh = KH(gs, Tc + 273.15), ymax = Math.max(KH(gs, 273.15) * 5, 1e-4);
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 5, ymax: ymax * 1000, col, xt: [0, 1, 2, 3, 4, 5], yt: [0, 0.5, 1].map(f => +(f * ymax * 1000).toPrecision(2)), xl: 'আংশিক চাপ p (atm)', yl: 'C (mmol L⁻¹)', fy: v => bn(v), ylx: 40 });
      [[0, 'rgba(45,111,214,.6)', [4, 3]], [60, 'rgba(192,57,43,.6)', [4, 3]]].forEach(([T2, cc, ds]) => { const k2 = KH(gs, T2 + 273.15); path(g, [[Pl.X(0), Pl.Y(0)], [Pl.X(5), Pl.Y(k2 * 5 * 1000)]], cc, 1.2, ds); });
      path(g, [[Pl.X(0), Pl.Y(0)], [Pl.X(5), Pl.Y(kh * 5 * 1000)]], Gc[4], 2.6); ball(g, Pl.X(p), Pl.Y(kh * p * 1000), 5.5, Gc[4], '#fff');
      legend(g, col, gx0 + 6, gy0 + 2, [[Gc[4], `${bn(Tc)} °C`], ['rgba(45,111,214,.8)', '০ °C', [4, 3]], ['rgba(192,57,43,.8)', '৬০ °C', [4, 3]]], false);
    };
    const info = () => { q('[data-pv]').textContent = bn(p.toFixed(1)); q('[data-tv]').textContent = bn(Tc); const Gc = GAS[gs], kh = KH(gs, Tc + 273.15), C = kh * p;
      out.innerHTML = TXB(`C = K_H\\,p = ${sci(kh)}\\times${p.toFixed(1)}`) + TXB(`= ${sci(C)}\\ \\mathrm{mol\\,L^{-1}} = ${sci(C * Gc[3] * 1000)}\\ \\mathrm{mg\\,L^{-1}}`) + `<div class="small">${Gc[0]} এর K_H: ২৫ °C এ ${sciB(Gc[1])}, ${bn(Tc)} °C এ ${sciB(kh)} mol L⁻¹ atm⁻¹ (${Tc > 25 ? 'তাপমাত্রা বাড়ায় কম' : Tc < 25 ? 'ঠান্ডায় বেশি' : 'প্রমিত'})। চাপ দ্বিগুণ ⇒ দ্রাব্যতা দ্বিগুণ (সরলরেখা মূলবিন্দুগামী)।${gs === 'co2' ? ' CO₂ পানির সাথে আংশিক বিক্রিয়া করে বলে উচ্চ চাপে আদর্শ রেখা থেকে সামান্য বিচ্যুত হয়।' : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'gs', k => { gs = k; D = []; info(); A.draw(); });
    q('[data-p]').oninput = e => { p = +e.target.value; info(); A.draw(); };
    q('[data-t]').oninput = e => { Tc = +e.target.value; info(); A.draw(); };
    for (let i = 0; i < 300; i++) step(0.05);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= কোমল পানীয় ও ডুবুরি ======================= */
V.p2c1_soda = {
  t: 'হেনরির সূত্রের প্রয়োগ: কোমল পানীয়ের বোতল খোলা (তাপমাত্রার প্রভাব) এবং ডুবুরির রক্তে N₂ ও ডিকম্প্রেশন রোগ (অ্যানিমেশন)', k: ['anim', 'int', 'calc', '2d'],
  cap: '"কোমল পানীয়" দৃশ্যে সিল করা বোতলে উচ্চ চাপের CO₂ — "খোলো" চাপলে উপরের চাপ হঠাৎ বায়ুর মাত্রায় নামে, দ্রবণ অতিসম্পৃক্ত হয়ে বুদবুদ ওঠে; গরম বোতলে (কম K_H, বেশি চাপ) ফেনা উপচে পড়ে। "ডুবুরি" দৃশ্যে গভীরতা বদলাও: চাপ বাড়ার সাথে রক্তে দ্রবীভূত N₂ (নীল বিন্দু) বাড়ে; "দ্রুত ওঠো" বনাম "ধীরে ওঠো" — দ্রুত উঠলে রক্তে বুদবুদ (লাল সতর্কতা), ধীরে উঠলে N₂ শ্বাসে বেরিয়ে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('sd', [['soda', 'কোমল পানীয়'], ['dive', 'ডুবুরি']], 'soda')}</div>${X.cv('প্রয়োগ')}<div class="ctl" data-c1><label class="small" style="flex:1;min-width:120px">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="2" max="45" step="1" value="5" data-t></label><button class="btn sm" data-open>খোলো</button><button class="btn sm" data-reset>নতুন বোতল</button></div><div class="ctl" data-c2 style="display:none"><label class="small" style="flex:1;min-width:120px">গভীরতা = <b data-dv></b> m<input type="range" min="0" max="50" step="1" value="30" data-d></label><button class="btn sm" data-fast>দ্রুত ওঠো</button><button class="btn sm" data-slow>ধীরে ওঠো</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 420;
    let L = X.fit(c, hf), md = 'soda', Tc = 5, opened = false, ot = 0, B = [], foam = 0, depth = 30, tissue = 4.0, asc = 0, ascRate = 0, bub = 0, t = 0; const Rn = X.rng(77);
    const nCO2 = 0.136 * 0.5; // mol (filled at 25 °C, 4 atm)
    const sealedP = T => { const kh = KH('co2', T + 273.15); return nCO2 / (kh * 0.5 + 0.03 / (0.0821 * (T + 273.15))); }; // headspace 30 mL
    const step = dt => { t += dt;
      if (md === 'soda') { const kh = KH('co2', Tc + 273.15), P0 = sealedP(Tc); if (opened) { ot += dt; const sup = Math.max(0, (P0 * Math.exp(-ot * 0.15)) - 0.01); const rate = sup * (1 + (P0 - 2) * 0.5) * 6; if (Rn() < dt * rate) for (let k = 0; k < 3; k++) B.push({ x: 0.2 + Rn() * 0.6, y: 1, v: 0.3 + Rn() * 0.4, r: 1.5 + Rn() * 2 }); foam = Math.max(0, Math.min(1.4, foam + dt * (P0 > 4 && ot < 2 ? 1.2 : -0.4))); } B.forEach(b => { b.y -= b.v * dt; b.r += dt * 0.6; }); B = B.filter(b => b.y > 0); }
      else { const P = 1 + depth / 10; if (asc) { depth = Math.max(0, depth - ascRate * dt); q('[data-d]').value = depth; if (depth === 0) asc = 0; } const target = 0.79 * (1 + depth / 10); tissue += (target - tissue) * dt * 0.25; const super_ = tissue / (0.79 * (1 + depth / 10)); bub = Math.max(0, Math.min(1, bub + dt * (super_ > 1.8 ? (super_ - 1.8) * 0.8 : -0.3))); } };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 'soda') { const bx = wd ? W * 0.25 : W / 2, bw = 90, by = 40, bh = H - 80; const P0 = sealedP(Tc);
        g.fillStyle = 'rgba(120,60,20,.75)'; rr(g, bx - bw / 2, by + 40, bw, bh - 40, 14); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(bx - 12, by); g.lineTo(bx - 12, by + 20); g.quadraticCurveTo(bx - bw / 2, by + 28, bx - bw / 2, by + 50); g.lineTo(bx - bw / 2, by + bh); g.lineTo(bx + bw / 2, by + bh); g.lineTo(bx + bw / 2, by + 50); g.quadraticCurveTo(bx + bw / 2, by + 28, bx + 12, by + 20); g.lineTo(bx + 12, by); g.stroke();
        if (!opened) { g.fillStyle = '#c0392b'; g.fillRect(bx - 14, by - 8, 28, 10); } else { g.fillStyle = '#c0392b'; g.save(); g.translate(bx + 30, by - 20); g.rotate(0.6); g.fillRect(-14, -5, 28, 10); g.restore(); }
        const Rr = X.rng(4); for (let k = 0; k < 40; k++) { const x = bx - bw / 2 + 8 + Rr() * (bw - 16), y = by + 60 + Rr() * (bh - 70); g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.arc(x, y, 1.6, 0, 7); g.fill(); }
        B.forEach(b => { const x = bx - bw / 2 + 6 + b.x * (bw - 12), y = by + 40 + b.y * (bh - 40); g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 1; g.beginPath(); g.arc(x, y, b.r, 0, 7); g.stroke(); });
        if (foam > 0.05) { g.fillStyle = 'rgba(245,230,210,.95)'; for (let k = 0; k < 30 * foam; k++) { const x = bx - 14 + Rr() * 28 + Math.sin(t * 5 + k) * 3, y = by - foam * 60 * Rr(); g.beginPath(); g.arc(x, y, 4 + Rr() * 3, 0, 7); g.fill(); } if (foam > 0.9) { g.beginPath(); g.ellipse(bx + 28, by + 40, 8, 30 * (foam - 0.8), 0, 0, 7); g.fill(); } }
        g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(opened ? 'খোলা' : `সিল করা: CO₂ ${bn(P0.toFixed(1))} atm`, bx, by + bh + 18);
        if (wd) { const gx0 = W * 0.5, gy0 = 20, gw = W * 0.46, gh = H - 64; const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin: 0, xmax: 45, ymax: 8, col, xt: [0, 15, 30, 45], yt: [0, 2, 4, 6, 8], xl: 'তাপমাত্রা (°C)', yl: 'বোতলের ভেতরের চাপ (atm)' }); const pts = []; for (let T = 0; T <= 45; T += 0.5) pts.push([Pl.X(T), Pl.Y(sealedP(T))]); path(g, pts, '#c0392b', 2.4); ball(g, Pl.X(Tc), Pl.Y(P0), 5.5, '#c0392b', '#fff'); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('একই মোট CO₂ (২৫ °C, ৪ atm এ ভরা)', gx0 + 6, gy0 + 10); } }
      else { const P = 1 + depth / 10; const sx = wd ? 10 : 10, sw = wd ? W * 0.45 : W - 20, sh = wd ? H - 20 : 220; const dY = d => 10 + d / 50 * (sh - 20);
        const sea = g.createLinearGradient(0, 10, 0, sh); sea.addColorStop(0, '#5fb0e0'); sea.addColorStop(1, '#0b3a66'); g.fillStyle = sea; g.fillRect(sx, 10, sw, sh - 10); g.fillStyle = 'rgba(255,255,255,.6)'; g.font = `9px ${col.font}`; g.textAlign = 'left'; [0, 10, 20, 30, 40, 50].forEach(d => g.fillText(`${bn(d)} m — ${bn(1 + d / 10)} atm`, sx + 4, dY(d) + 3));
        const dx = sx + sw * 0.6, dy = dY(depth); g.fillStyle = '#222'; g.beginPath(); g.ellipse(dx, dy, 18, 7, 0, 0, 7); g.fill(); g.fillStyle = '#e0a020'; g.fillRect(dx - 10, dy - 12, 16, 6); g.fillStyle = '#ffcc99'; g.beginPath(); g.arc(dx + 18, dy - 2, 5, 0, 7); g.fill(); for (let k = 0; k < 4; k++) { const by2 = dy - 10 - ((t * 30 + k * 12) % 40); g.strokeStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.arc(dx + 22 + Math.sin(t + k) * 3, by2, 2, 0, 7); g.stroke(); }
        // blood vessel inset
        const ix = wd ? W * 0.5 : 10, iy = wd ? 16 : sh + 20, iw = wd ? W * 0.47 : W - 20, ih = wd ? 120 : 90; g.fillStyle = col.sf; g.strokeStyle = col.line || col.mu; rr(g, ix, iy, iw, ih, 10); g.fill(); g.stroke(); g.fillStyle = 'rgba(200,40,40,.25)'; rr(g, ix + 10, iy + 28, iw - 20, ih - 44, 18); g.fill(); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('রক্তনালি (অণুবীক্ষণিক)', ix + 10, iy + 18);
        const nN = Math.round(tissue * 8); const Rr = X.rng(8); for (let k = 0; k < nN; k++) { const x = ix + 16 + ((Rr() + t * 0.05) % 1) * (iw - 32), y = iy + 34 + Rr() * (ih - 56); g.fillStyle = '#2d6fd6'; g.beginPath(); g.arc(x, y, 2, 0, 7); g.fill(); } if (bub > 0.05) { for (let k = 0; k < 8 * bub; k++) { const x = ix + 30 + Rr() * (iw - 60), y = iy + 40 + Rr() * (ih - 70); g.strokeStyle = '#c0392b'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, 4 + 4 * bub, 0, 7); g.stroke(); } g.fillStyle = '#c0392b'; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText('⚠ N₂ বুদবুদ!', ix + iw - 10, iy + 18); }
        if (wd) { const gx0 = W * 0.55, gy0 = iy + ih + 30, gw = W * 0.4, gh = H - gy0 - 34; const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 50, ymax: 5, col, xt: [0, 25, 50], yt: [0, 2.5, 5], xl: 'গভীরতা (m)', yl: 'p(N₂) atm', ylx: 26 }); path(g, [[Pl.X(0), Pl.Y(0.79)], [Pl.X(50), Pl.Y(0.79 * 6)]], '#2d6fd6', 2); ball(g, Pl.X(depth), Pl.Y(0.79 * P), 5, '#2d6fd6', '#fff'); ball(g, Pl.X(depth), Pl.Y(Math.min(5, tissue)), 4, '#c0392b', '#fff'); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('লাল = টিস্যুতে N₂', gx0 + 6, gy0 + 10); } }
    };
    const info = () => { q('[data-tv]').textContent = bn(Tc); q('[data-dv]').textContent = bn(Math.round(depth)); q('[data-c1]').style.display = md === 'soda' ? '' : 'none'; q('[data-c2]').style.display = md === 'dive' ? '' : 'none';
      if (md === 'soda') { const kh = KH('co2', Tc + 273.15), P0 = sealedP(Tc); out.innerHTML = TXB(`K_H(${Tc}\\,^\\circ\\mathrm{C}) = ${sci(kh)};\\quad p_{\\text{বোতল}} = ${P0.toFixed(1)}\\ \\mathrm{atm}`) + `<div class="small">${opened ? (P0 > 4.5 ? 'গরম বোতল: উপরের চাপ বেশি ও K_H কম — খোলামাত্র প্রবল অতিসম্পৃক্তি, ফেনা উপচে পড়ছে!' : 'ঠান্ডা বোতল: K_H বেশি, চাপের পতন কম — মৃদু ফস, বুদবুদ ধীরে ওঠে, ঝাঁঝ বেশি সময় থাকে।') : 'সিল করা অবস্থায় মোট CO₂ একই, কিন্তু গরমে কম দ্রবীভূত থাকে ⇒ উপরের ফাঁকা অংশে চাপ বেশি (লেখচিত্র)।'} খোলার পর সাম্যে C = K_H × ৪.২ × ১০⁻⁴ atm — প্রায় সব CO₂ বেরিয়ে যাবে।</div>`; }
      else { const P = 1 + depth / 10; out.innerHTML = TXB(`P = 1 + \\dfrac{${Math.round(depth)}}{10} = ${P.toFixed(1)}\\ \\mathrm{atm}`) + TXB(`p_{\\ce{N2}} = 0.79\\times${P.toFixed(1)} = ${(0.79 * P).toFixed(2)}\\ \\mathrm{atm}`) + `<div class="small">টিস্যুতে N₂ এর কার্যকর চাপ ${bn(tissue.toFixed(2))} atm (ধীরে সাম্যে পৌঁছায়)। ${bub > 0.3 ? '<b>ডিকম্প্রেশন রোগ:</b> চাপ দ্রুত কমেছে, টিস্যুর N₂ অতিসম্পৃক্ত হয়ে বুদবুদ — হাইপারবারিক চেম্বার দরকার।' : asc && ascRate < 3 ? 'ধীরে উঠছে — অতিরিক্ত N₂ রক্ত হয়ে ফুসফুসে শ্বাসের সাথে বেরিয়ে যাচ্ছে।' : 'গভীরে থাকলে রক্ত-টিস্যুতে N₂ হেনরির সূত্র অনুযায়ী জমতে থাকে।'}</div>`; } };
    const A = X.anim(el, dt => { if (dt) { step(Math.min(dt, 0.05)); if (Math.floor(t * 3) !== Math.floor((t - dt) * 3)) info(); } draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'sd', k => { md = k; info(); A.draw(); });
    q('[data-t]').oninput = e => { Tc = +e.target.value; info(); };
    q('[data-open]').onclick = () => { opened = true; ot = 0; info(); };
    q('[data-reset]').onclick = () => { opened = false; B = []; foam = 0; info(); };
    q('[data-d]').oninput = e => { depth = +e.target.value; asc = 0; info(); };
    q('[data-fast]').onclick = () => { asc = 1; ascRate = 25; info(); };
    q('[data-slow]').onclick = () => { asc = 1; ascRate = 1.2; info(); };
    for (let i = 0; i < 100; i++) step(0.05);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
