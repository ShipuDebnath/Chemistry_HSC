/* ২য় পত্র অধ্যায় ১ visuals part 12 — acid-base theories: Arrhenius, Brønsted-Lowry, strength ladder, Lewis 3D (1.14–1.16) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ion = (g, x, y, r, c1, c2, t, col) => { ball(g, x, y, r, c1, c2); g.fillStyle = '#fff'; g.font = `bold ${Math.round(r * 0.75)}px ${col.font}`; g.textAlign = 'center'; g.fillText(t, x, y + r * 0.28); };

/* ======================= ১.১৪ আরহেনিয়াস: বিয়োজন, পরিবাহিতা, প্রশমন ======================= */
const ARR = {
  hcl: { nm: 'HCl (তীব্র এসিড)', a: 0.99, ion: [['H₃O⁺', '#c0392b', '#ffb3a8', '+'], ['Cl⁻', '#2f9e44', '#c8f0cf', '−']], mol: ['HCl', '#888', '#ddd'], eq: '\\ce{HCl + H2O -> H3O+ + Cl-}', note: 'প্রায় ১০০% বিয়োজিত — দ্রবণ ভরা আয়নে, বাল্ব উজ্জ্বল।' },
  ac: { nm: 'CH₃COOH (মৃদু এসিড)', a: 0.06, ion: [['H₃O⁺', '#c0392b', '#ffb3a8', '+'], ['A⁻', '#7b3fa0', '#e0c8f0', '−']], mol: ['AcOH', '#8a6a43', '#e8d8b8'], eq: '\\ce{CH3COOH + H2O <=> H3O+ + CH3COO-}', note: '০.১ M এ মাত্র ~১.৩% বিয়োজিত (চিত্রে বোঝার সুবিধায় একটু বেশি দেখানো) — অধিকাংশ অণু অক্ষত, বাল্ব ক্ষীণ।' },
  naoh: { nm: 'NaOH (তীব্র ক্ষারক)', a: 0.99, ion: [['Na⁺', '#7d8590', '#d8dce2', '+'], ['OH⁻', '#2d6fd6', '#a9c8ff', '−']], mol: ['NaOH', '#666', '#ccc'], eq: '\\ce{NaOH -> Na+ + OH-}', note: 'সম্পূর্ণ বিয়োজিত আয়নিক যৌগ — OH⁻ প্রদান করে বলে আরহেনিয়াস ক্ষারক।' },
  nh3: { nm: 'NH₃ (?)', a: 0.06, ion: [['NH₄⁺', '#d69a1e', '#fff0b8', '+'], ['OH⁻', '#2d6fd6', '#a9c8ff', '−']], mol: ['NH₃', '#2d6fd6', '#a9c8ff'], eq: '\\ce{NH3 + H2O <=> NH4+ + OH-}', note: 'NH₃ এ নিজের কোনো OH নেই — OH⁻ আসে পানি থেকে। আরহেনিয়াস তত্ত্বে একে ক্ষারক বলা যায় না: এটি তত্ত্বের সীমাবদ্ধতা (ব্রনস্টেড তত্ত্বে প্রোটন গ্রাহক)।' }
};
V.p2c1_arrhenius = {
  t: 'আরহেনিয়াস তত্ত্ব: জলীয় দ্রবণে বিয়োজন, তীব্র-মৃদু এসিডের পরিবাহিতা এবং H⁺ + OH⁻ → H₂O প্রশমন (অ্যানিমেশন)', k: ['anim', 'int', '2d'],
  cap: 'একটি বিকারে ০.১ M দ্রবণ ও দুটি তড়িৎদ্বারযুক্ত বাল্ব-সার্কিট। দ্রবণ বদলাও: HCl ও NaOH প্রায় সম্পূর্ণ আয়নে ভাঙে — বাল্ব উজ্জ্বল; CH₃COOH ও NH₃ এর বেশির ভাগ অণু অক্ষত (জোড়া বল) — বাল্ব ক্ষীণ। আয়নগুলো বিপরীত চার্জের তড়িৎদ্বারের দিকে ধীরে সরে। "প্রশমন" দৃশ্যে HCl এর H₃O⁺ (লাল) ও NaOH এর OH⁻ (নীল) মিলিত হয়ে পানি তৈরি করে, ঝলক দেয় এবং থার্মোমিটারে তাপমাত্রা বাড়ে; Na⁺ ও Cl⁻ দর্শক আয়ন হিসেবে থেকে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('as', [['hcl', 'HCl'], ['ac', 'CH₃COOH'], ['naoh', 'NaOH'], ['nh3', 'NH₃'], ['mix', 'প্রশমন']], 'hcl')}</div>${X.cv('আরহেনিয়াস')}<div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-rs>আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 320 : 360;
    let L = X.fit(c, hf), md = 'hcl', P = [], t = 0, dT = 0, flashes = [], made = 0; const Rn = X.rng(12);
    const init = () => { P = []; t = 0; dT = 0; made = 0; flashes = [];
      if (md === 'mix') { for (let i = 0; i < 14; i++) { P.push({ k: 'H', x: 0.05 + Rn() * 0.4, y: Rn(), vx: 0, vy: 0 }); P.push({ k: 'Cl', x: 0.05 + Rn() * 0.4, y: Rn(), vx: 0, vy: 0 }); P.push({ k: 'OH', x: 0.55 + Rn() * 0.4, y: Rn(), vx: 0, vy: 0 }); P.push({ k: 'Na', x: 0.55 + Rn() * 0.4, y: Rn(), vx: 0, vy: 0 }); } return; }
      const S = ARR[md]; for (let i = 0; i < 18; i++) { if (Rn() < S.a) { P.push({ k: 'i0', x: Rn(), y: Rn(), vx: 0, vy: 0 }); P.push({ k: 'i1', x: Rn(), y: Rn(), vx: 0, vy: 0 }); } else P.push({ k: 'm', x: Rn(), y: Rn(), vx: 0, vy: 0, a: Rn() * 6 }); } };
    init();
    const step = dt => { t += dt; P.forEach(p => { p.vx += (Rn() - .5) * dt * 1.2; p.vy += (Rn() - .5) * dt * 1.2; p.vx *= 0.96; p.vy *= 0.96; if (md !== 'mix') { const q = p.k === 'i0' ? 1 : p.k === 'i1' ? -1 : 0; p.vx += q * dt * 0.03 * (md === 'mix' ? 0 : 1); } p.x += p.vx * dt; p.y += p.vy * dt; if (p.x < 0.02) { p.x = 0.02; p.vx *= -1; } if (p.x > 0.98) { p.x = 0.98; p.vx *= -1; } if (p.y < 0.03) { p.y = 0.03; p.vy *= -1; } if (p.y > 0.97) { p.y = 0.97; p.vy *= -1; } });
      if (md === 'mix') { P.forEach(p => { if (p.k === 'H' || p.k === 'OH') p.vx += (p.k === 'H' ? 1 : -1) * dt * 0.06; }); const H = P.filter(p => p.k === 'H'), O = P.filter(p => p.k === 'OH'); H.forEach(h => { if (h.dead) return; const o = O.find(o => !o.dead && Math.hypot(o.x - h.x, (o.y - h.y) * 0.7) < 0.05); if (o) { h.dead = o.dead = true; P.push({ k: 'W', x: (h.x + o.x) / 2, y: (h.y + o.y) / 2, vx: 0, vy: 0, a: Rn() * 6 }); flashes.push({ x: (h.x + o.x) / 2, y: (h.y + o.y) / 2, t: 0 }); made++; dT = made * 0.49; } }); P = P.filter(p => !p.dead); flashes.forEach(f => f.t += dt); flashes = flashes.filter(f => f.t < 0.6); } };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const bx = wd ? 40 : 16, by = 60, bw = wd ? W * 0.62 : W - 70, bh = H - by - 16;
      // beaker
      g.fillStyle = 'rgba(120,180,240,.18)'; g.fillRect(bx, by + 10, bw, bh - 10); g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(bx - 4, by); g.lineTo(bx, by + bh); g.lineTo(bx + bw, by + bh); g.lineTo(bx + bw + 4, by); g.stroke();
      const ions = md === 'mix' ? P.filter(p => p.k !== 'W').length : P.filter(p => p.k !== 'm').length, glow = Math.min(1, ions / 36);
      if (md !== 'mix') { // electrodes + circuit + bulb
        const e1 = bx + bw * 0.12, e2 = bx + bw * 0.88; g.fillStyle = '#555'; g.fillRect(e1 - 4, by - 30, 8, bh - 10); g.fillRect(e2 - 4, by - 30, 8, bh - 10); g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText('−', e1, by - 36); g.fillText('+', e2, by - 36);
        g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(e1, by - 30); g.lineTo(e1, by - 46); g.lineTo(e2, by - 46); g.lineTo(e2, by - 30); g.stroke(); const lbx = (e1 + e2) / 2; const gg = g.createRadialGradient(lbx, by - 46, 2, lbx, by - 46, 30); gg.addColorStop(0, `rgba(255,230,120,${glow})`); gg.addColorStop(1, 'rgba(255,230,120,0)'); g.fillStyle = gg; g.beginPath(); g.arc(lbx, by - 46, 30, 0, 7); g.fill(); g.fillStyle = `rgba(255,${200 + 40 * glow},${80 + 80 * glow},${0.4 + 0.6 * glow})`; g.strokeStyle = col.fg; g.beginPath(); g.arc(lbx, by - 46, 10, 0, 7); g.fill(); g.stroke(); }
      const X_ = p => bx + 6 + p.x * (bw - 12), Y_ = p => by + 16 + p.y * (bh - 26);
      const S = ARR[md];
      P.forEach(p => { const x = X_(p), y = Y_(p);
        if (md === 'mix') { if (p.k === 'H') ion(g, x, y, 9, '#c0392b', '#ffb3a8', 'H₃O⁺', col); else if (p.k === 'OH') ion(g, x, y, 9, '#2d6fd6', '#a9c8ff', 'OH⁻', col); else if (p.k === 'Na') ion(g, x, y, 7, '#7d8590', '#d8dce2', 'Na⁺', col); else if (p.k === 'Cl') ion(g, x, y, 8, '#2f9e44', '#c8f0cf', 'Cl⁻', col); else { ball(g, x, y, 5.5, '#c0392b', '#ffb3a8'); ball(g, x - 5, y + 4, 3.2, '#ddd', '#fff'); ball(g, x + 5, y + 4, 3.2, '#ddd', '#fff'); } }
        else if (p.k === 'm') { const [, c1, c2] = S.mol; ball(g, x - 5 * Math.cos(p.a), y - 5 * Math.sin(p.a), 6, c1, c2); ball(g, x + 5 * Math.cos(p.a), y + 5 * Math.sin(p.a), 5, c1, c2); }
        else { const [tx, c1, c2] = S.ion[p.k === 'i0' ? 0 : 1]; ion(g, x, y, 9, c1, c2, tx, col); } });
      flashes.forEach(f => { g.fillStyle = `rgba(255,200,60,${0.7 * (1 - f.t / 0.6)})`; g.beginPath(); g.arc(X_(f), Y_(f), 8 + f.t * 30, 0, 7); g.fill(); });
      // thermometer / meter
      const tx = wd ? bx + bw + 40 : W - 26; if (md === 'mix') { const ty0 = by, ty1 = by + bh - 18, T = 25 + dT, tY = v => ty1 - (v - 20) / 20 * (ty1 - ty0); g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.2; rr(g, tx - 5, ty0, 10, ty1 - ty0 + 6, 5); g.fill(); g.stroke(); g.fillStyle = '#d63a2a'; g.beginPath(); g.arc(tx, ty1 + 10, 9, 0, 7); g.fill(); g.fillRect(tx - 2.5, tY(T), 5, ty1 + 4 - tY(T)); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`${bn(T.toFixed(1))}°C`, tx, by - 8); }
      else if (wd) { g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('আয়ন', tx - 16, by + 6); const bh2 = bh - 30; g.strokeStyle = col.fg; g.strokeRect(tx - 10, by + 14, 20, bh2); g.fillStyle = '#e0a020'; g.fillRect(tx - 10, by + 14 + bh2 * (1 - glow), 20, bh2 * glow); }
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = wd ? 'right' : 'left'; g.fillText(md === 'mix' ? `HCl + NaOH — পানির অণু তৈরি: ${bn(made)}` : S.nm, wd ? W - 8 : bx, wd ? 16 : H - 4);
    };
    const info = () => { if (md === 'mix') { out.innerHTML = TXB('\\ce{H3O+ + OH- -> 2H2O}') + TXB('\\Delta H = -57.3\\ \\mathrm{kJ\\,mol^{-1}}') + '<div class="small">Na⁺ ও Cl⁻ বিক্রিয়ায় অংশ নেয় না (দর্শক আয়ন)। যেকোনো তীব্র এসিড ও তীব্র ক্ষারকের প্রশমনে নিট বিক্রিয়া এটিই — তাই প্রশমন তাপ সবসময় −৫৭.৩ kJ mol⁻¹।</div>'; return; } const S = ARR[md]; out.innerHTML = TXB(S.eq) + `<div class="small">${S.note}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    X.onSeg(el, 'as', k => { md = k; init(); info(); A.draw(); });
    el.querySelector('[data-rs]').onclick = () => { init(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.১৫ ব্রনস্টেড-লাউরি: প্রোটন স্থানান্তর ও অনুবন্ধী যুগল ======================= */
const BR = [
  ['HCl + H₂O', ['HCl', 'H₂O', 'H₃O⁺', 'Cl⁻'], '→', '\\ce{HCl + H2O -> H3O+ + Cl-}', 'HCl তীব্র এসিড — প্রোটন প্রায় পুরোপুরি পানিতে চলে যায়; Cl⁻ অত্যন্ত দুর্বল অনুবন্ধী ক্ষারক।', 0],
  ['NH₃ + H₂O', ['H₂O', 'NH₃', 'NH₄⁺', 'OH⁻'], '⇌', '\\ce{NH3 + H2O <=> NH4+ + OH-}', 'এখানে পানি এসিড (প্রোটন দেয়), NH₃ ক্ষারক — N এর নিঃসঙ্গ জোড় প্রোটন ধরে।', 0],
  ['CH₃COOH + H₂O', ['CH₃COOH', 'H₂O', 'H₃O⁺', 'CH₃COO⁻'], '⇌', '\\ce{CH3COOH + H2O <=> H3O+ + CH3COO-}', 'মৃদু এসিড — সাম্য বামে; CH₃COO⁻ তুলনামূলক শক্তিশালী অনুবন্ধী ক্ষারক।', 0],
  ['HCO₃⁻ ক্ষারক রূপে', ['H₃O⁺', 'HCO₃⁻', 'H₂CO₃', 'H₂O'], '→', '\\ce{HCO3- + H3O+ -> H2CO3 + H2O}', 'এসিডের সাথে HCO₃⁻ প্রোটন গ্রহণ করে — ক্ষারক।', 0],
  ['HCO₃⁻ এসিড রূপে', ['HCO₃⁻', 'OH⁻', 'H₂O', 'CO₃²⁻'], '→', '\\ce{HCO3- + OH- -> CO3^2- + H2O}', 'ক্ষারকের সাথে একই HCO₃⁻ প্রোটন দান করে — এসিড। তাই HCO₃⁻ উভধর্মী।', 0],
  ['H₂O + H₂O', ['H₂O', 'H₂O', 'H₃O⁺', 'OH⁻'], '⇌', '\\ce{H2O + H2O <=> H3O+ + OH-}\\quad K_w = 1.0\\times10^{-14}', 'পানির স্বতঃআয়নীকরণ — একটি পানির অণু এসিড, অন্যটি ক্ষারক।', 0],
  ['HCl(g) + NH₃(g)', ['HCl', 'NH₃', 'NH₄⁺', 'Cl⁻'], '→', '\\ce{HCl(g) + NH3(g) -> NH4Cl(s)}', 'পানি নেই, তবুও প্রোটন স্থানান্তর — ব্রনস্টেড এসিড-ক্ষারক বিক্রিয়া (সাদা ধোঁয়া)। আরহেনিয়াস তত্ত্ব এটি ব্যাখ্যা করতে পারে না।', 1]
];
V.p2c1_bronsted = {
  t: 'ব্রনস্টেড-লাউরি তত্ত্ব: প্রোটন স্থানান্তরের অ্যানিমেশন ও অনুবন্ধী এসিড-ক্ষারক যুগলের রঙিন চিহ্ন', k: ['anim', 'int', '2d'],
  cap: 'উপরের তালিকা থেকে একটি বিক্রিয়া বেছে নাও। এসিড (প্রোটন দাতা) থেকে লাল H⁺ বলটি বাঁকা পথে ক্ষারকের (প্রোটন গ্রাহক) নিঃসঙ্গ জোড়ে (দুটি বিন্দু) গিয়ে বসে; ফলে ডানে অনুবন্ধী এসিড ও অনুবন্ধী ক্ষারক তৈরি হয়। নিচের নীল বন্ধনী যুগল ১ (এসিড₁/ক্ষারক₁) ও কমলা বন্ধনী যুগল ২ (ক্ষারক₂/এসিড₂) — প্রতিটি যুগলের পার্থক্য ঠিক একটি H⁺। HCO₃⁻ এর দুটি বিক্রিয়া পাশাপাশি দেখে উভধর্মিতা বুঝে নাও।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${BR.map((r, i) => `<button class="btn sm" data-br="${i}">${r[0]}</button>`).join('')}</div>${X.cv('প্রোটন স্থানান্তর')}<div class="ctl"><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 260 : 330;
    let L = X.fit(c, hf), ri = 0, ph = 0;
    const pill = (g, col, x, y, txt, cl, w, lp) => { g.font = `bold ${w > 80 ? 15 : 13}px ${col.font}`; const tw = Math.max(w, g.measureText(txt).width + 18); g.fillStyle = col.sf; g.strokeStyle = cl; g.lineWidth = 2.2; rr(g, x - tw / 2, y - 18, tw, 36, 12); g.fill(); g.stroke(); g.fillStyle = col.fg; g.textAlign = 'center'; g.fillText(txt, x, y + 5); if (lp) { g.fillStyle = cl; g.beginPath(); g.arc(x - 5, y - 24, 2.4, 0, 7); g.arc(x + 5, y - 24, 2.4, 0, 7); g.fill(); } return tw; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), R = BR[ri], [a1, b2, a2, b1] = R[1];
      const u = ph % 1, mv = Math.min(1, Math.max(0, (u - 0.1) / 0.45)), done = u > 0.58;
      const C1 = '#2d6fd6', C2 = '#e07a20';
      if (wd) { const y = H * 0.38, xs = [W * 0.12, W * 0.32, W * 0.68, W * 0.88]; const w = 92;
        g.globalAlpha = done ? 0.35 : 1; pill(g, col, xs[0], y, a1, C1, w); pill(g, col, xs[1], y, b2, C2, w, !done); g.globalAlpha = 1;
        g.fillStyle = col.fg; g.font = `bold 20px ${col.font}`; g.textAlign = 'center'; g.fillText('+', (xs[0] + xs[1]) / 2, y + 7); g.fillText(R[2], W / 2, y + 7);
        g.globalAlpha = done ? 1 : 0.25; pill(g, col, xs[2], y, a2, C2, w); g.fillStyle = col.fg; g.font = `bold 20px ${col.font}`; g.fillText('+', (xs[2] + xs[3]) / 2, y + 7); pill(g, col, xs[3], y, b1, C1, w); g.globalAlpha = 1;
        // roles
        [[xs[0], 'এসিড₁', C1], [xs[1], 'ক্ষারক₂', C2], [xs[2], 'এসিড₂', C2], [xs[3], 'ক্ষারক₁', C1]].forEach(([x, t2, cl]) => { g.fillStyle = cl; g.font = `bold 10.5px ${col.font}`; g.fillText(t2, x, y + 34); });
        // brackets
        const br = (x1, x2, yy, cl, lab) => { g.strokeStyle = cl; g.lineWidth = 2; g.beginPath(); g.moveTo(x1, yy - 8); g.lineTo(x1, yy); g.lineTo(x2, yy); g.lineTo(x2, yy - 8); g.stroke(); g.fillStyle = cl; g.font = `10px ${col.font}`; g.fillText(lab, (x1 + x2) / 2, yy + 13); };
        br(xs[0], xs[3], y + 58, C1, `যুগল ১: ${a1} / ${b1}`); br(xs[1], xs[2], y + 84, C2, `যুগল ২: ${a2} / ${b2}`);
        // proton
        if (!done) { const x0 = xs[0] + 20, x1 = xs[1], px = x0 + (x1 - x0) * mv, py = y - 22 - Math.sin(Math.PI * mv) * 40; ball(g, px, py, 8, '#c0392b', '#ffb3a8'); g.fillStyle = '#fff'; g.font = `bold 8px ${col.font}`; g.fillText('H⁺', px, py + 3); }
        else { ball(g, xs[2] + 30, y - 20, 6, '#c0392b', '#ffb3a8'); }
      } else { const y1 = 46, y2 = 168, xs = [W * 0.27, W * 0.73]; const w = 84;
        g.globalAlpha = done ? 0.35 : 1; pill(g, col, xs[0], y1, a1, C1, w); pill(g, col, xs[1], y1, b2, C2, w, !done); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `bold 18px ${col.font}`; g.textAlign = 'center'; g.fillText('+', W / 2, y1 + 6); g.fillText(R[2] === '→' ? '↓' : '⇅', W / 2, (y1 + y2) / 2 + 6);
        g.globalAlpha = done ? 1 : 0.25; pill(g, col, xs[0], y2, b1, C1, w); pill(g, col, xs[1], y2, a2, C2, w); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `bold 18px ${col.font}`; g.fillText('+', W / 2, y2 + 6);
        [[xs[0], y1, 'এসিড₁', C1], [xs[1], y1, 'ক্ষারক₂', C2], [xs[0], y2, 'ক্ষারক₁', C1], [xs[1], y2, 'এসিড₂', C2]].forEach(([x, yy, t2, cl]) => { g.fillStyle = cl; g.font = `bold 10px ${col.font}`; g.fillText(t2, x, yy + 32); });
        g.strokeStyle = C1; g.lineWidth = 2; g.setLineDash([4, 3]); g.beginPath(); g.moveTo(xs[0] - 50, y1); g.lineTo(xs[0] - 58, y1); g.lineTo(xs[0] - 58, y2); g.lineTo(xs[0] - 50, y2); g.stroke(); g.strokeStyle = C2; g.beginPath(); g.moveTo(xs[1] + 50, y1); g.lineTo(xs[1] + 58, y1); g.lineTo(xs[1] + 58, y2); g.lineTo(xs[1] + 50, y2); g.stroke(); g.setLineDash([]);
        g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText('নীল ও কমলা রেখা = অনুবন্ধী যুগল', W / 2, H - 10);
        if (!done) { const x0 = xs[0] + 18, x1 = xs[1] - 10, px = x0 + (x1 - x0) * mv, py = y1 - 20 - Math.sin(Math.PI * mv) * 18; ball(g, px, py, 7, '#c0392b', '#ffb3a8'); g.fillStyle = '#fff'; g.font = `bold 7px ${col.font}`; g.fillText('H⁺', px, py + 2.5); } }
      if (R[6] && done) { g.fillStyle = 'rgba(240,240,240,.6)'; for (let k = 0; k < 20; k++) { g.beginPath(); g.arc(W * 0.5 + Math.sin(k * 7 + ph * 2) * W * 0.2, H * 0.15 + (k * 13 % 40), 6, 0, 7); g.fill(); } }
    };
    const info = () => { const R = BR[ri]; el.querySelectorAll('[data-br]').forEach(b => b.classList.toggle('primary', +b.dataset.br === ri)); out.innerHTML = TXB(R[3]) + `<div class="small">${R[4]}</div><div class="small" style="margin-top:4px">যুগল ১: <b>${R[1][0]}</b> (এসিড) / <b>${R[1][3]}</b> (অনুবন্ধী ক্ষারক) · যুগল ২: <b>${R[1][2]}</b> (অনুবন্ধী এসিড) / <b>${R[1][1]}</b> (ক্ষারক)</div>`; };
    const A = X.anim(el, dt => { if (dt) ph += dt / 3.2; draw(); }, { paused: false }); X.pp(el, A);
    el.querySelectorAll('[data-br]').forEach(b => { b.onclick = () => { ri = +b.dataset.br; ph = 0; info(); A.draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.১৫ এসিড-ক্ষারকের আপেক্ষিক শক্তির মই ======================= */
const LAD = [['HClO₄', 'ClO₄⁻', -10], ['HCl', 'Cl⁻', -7], ['H₂SO₄', 'HSO₄⁻', -3], ['H₃O⁺', 'H₂O', 0], ['HSO₄⁻', 'SO₄²⁻', 1.99], ['H₃PO₄', 'H₂PO₄⁻', 2.15], ['HF', 'F⁻', 3.17], ['CH₃COOH', 'CH₃COO⁻', 4.76], ['H₂CO₃', 'HCO₃⁻', 6.35], ['NH₄⁺', 'NH₃', 9.25], ['HCN', 'CN⁻', 9.21], ['HCO₃⁻', 'CO₃²⁻', 10.33], ['H₂O', 'OH⁻', 14.0], ['NH₃', 'NH₂⁻', 38]];
V.p2c1_acidStrength = {
  t: 'অনুবন্ধী এসিড-ক্ষারকের আপেক্ষিক শক্তির মই (pKa): তীব্র এসিডের অনুবন্ধী ক্ষারক দুর্বল, সাম্যের দিক নির্ণয়', k: ['int', 'calc', '2d'],
  cap: 'বাম স্তম্ভে এসিড উপর থেকে নিচে ক্রমশ দুর্বল (pKa বাড়ে), ডানে একই সারিতে তাদের অনুবন্ধী ক্ষারক — উপর থেকে নিচে ক্রমশ তীব্র। পটভূমির তীর দুটি বিপরীতমুখী। বাম থেকে একটি এসিড ও ডান থেকে একটি ক্ষারক ট্যাপ করো: তাদের বিক্রিয়ার সমীকরণ, সাম্যধ্রুবক K = ১০^(pKa₂ − pKa₁) এবং সাম্য কোন দিকে তা দেখাবে — নিয়ম: উপরের-বামের এসিড নিচের-ডানের ক্ষারকের সাথে স্বতঃস্ফূর্তভাবে বিক্রিয়া করে।',
  html: () => `${X.cv('শক্তির মই')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => 14 * 25 + 60;
    let L = X.fit(c, hf), sa = 7, sb = 9;
    const geo = () => { const { W } = L, wd = wide(W); const top = 40, rh = 25, xa = wd ? W * 0.3 : W * 0.24, xb = wd ? W * 0.7 : W * 0.76, xp = W / 2; return { wd, top, rh, xa, xb, xp }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const { wd, top, rh, xa, xb, xp } = geo();
      // arrows
      const ag = (x, up, cl, lab) => { g.fillStyle = cl; g.globalAlpha = 0.18; g.beginPath(); if (up) { g.moveTo(x, top - 4); g.lineTo(x - 12, top + 14); g.lineTo(x - 5, top + 14); g.lineTo(x - 5, top + LAD.length * rh); g.lineTo(x + 5, top + LAD.length * rh); g.lineTo(x + 5, top + 14); g.lineTo(x + 12, top + 14); } else { const yb = top + LAD.length * rh; g.moveTo(x, yb + 4); g.lineTo(x - 12, yb - 14); g.lineTo(x - 5, yb - 14); g.lineTo(x - 5, top); g.lineTo(x + 5, top); g.lineTo(x + 5, yb - 14); g.lineTo(x + 12, yb - 14); } g.fill(); g.globalAlpha = 1; g.fillStyle = cl; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(lab, x, top - 12); };
      ag(wd ? xa - 80 : 12, true, '#c0392b', wd ? 'এসিড তীব্রতর ↑' : ''); ag(wd ? xb + 80 : W - 12, false, '#2d6fd6', wd ? 'ক্ষারক তীব্রতর ↓' : '');
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('এসিড', xa, 22); g.fillText('pKa', xp, 22); g.fillText('অনুবন্ধী ক্ষারক', xb, 22);
      LAD.forEach(([a, b, pk], i) => { const y = top + i * rh + rh / 2; const sel1 = i === sa, sel2 = i === sb; if (i % 2) { g.fillStyle = col.s2 || 'rgba(0,0,0,.03)'; g.fillRect(wd ? xa - 60 : 26, y - rh / 2, wd ? xb - xa + 120 : W - 52, rh); }
        const pill = (x, t2, on, cl) => { g.font = `${on ? 'bold ' : ''}12px ${col.font}`; const tw = g.measureText(t2).width + 16; if (on) { g.fillStyle = cl; rr(g, x - tw / 2, y - 10, tw, 20, 8); g.fill(); g.fillStyle = '#fff'; } else g.fillStyle = col.fg; g.textAlign = 'center'; g.fillText(t2, x, y + 4); };
        pill(xa, a, sel1, '#c0392b'); pill(xb, b, sel2, '#2d6fd6'); g.fillStyle = col.mu; g.font = `10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(pk <= -3 ? (pk === -3 ? '−৩' : `≈ ${bn(pk)}`.replace('-', '−')) : bn(pk.toFixed(pk % 1 ? 2 : 0)), xp, y + 4); });
      // connector
      const ya = top + sa * rh + rh / 2, yb = top + sb * rh + rh / 2; const K = LAD[sb][2] - LAD[sa][2]; g.strokeStyle = K > 0 ? '#2f9e44' : '#c0392b'; g.lineWidth = 2.4; g.setLineDash([5, 3]); g.beginPath(); g.moveTo(xa + 44, ya); g.bezierCurveTo(xp, ya, xp, yb, xb - 44, yb); g.stroke(); g.setLineDash([]);
    };
    const info = () => { const [a, ca, pa] = LAD[sa], [cb, b, pb] = LAD[sb]; const lk = pb - pa; const K = lk;
      if (sa === sb) { out.innerHTML = `<div class="small">একই যুগলের এসিড ও তার অনুবন্ধী ক্ষারক — বিক্রিয়া করলে কেবল প্রোটন বিনিময় (K = ১)। অন্য সারির ক্ষারক বেছে নাও।</div>`; return; }
      const sci = v => { if (!isFinite(v) || v > 1e30) return '10^{' + K.toFixed(0) + '}'; if (v < 1e-30) return '10^{' + K.toFixed(0) + '}'; const e = Math.floor(Math.log10(v)), m = v / Math.pow(10, e); return Math.abs(e) <= 2 ? v.toPrecision(3) : `${m.toFixed(2)}\\times10^{${e}}`; }; const Ks = Math.abs(K) > 30 ? (K > 0 ? '10^{' + K.toFixed(0) + '}' : '10^{' + K.toFixed(0) + '}') : `10^{${K.toFixed(2)}}`;
      out.innerHTML = `<div><b>${a}</b> + <b>${b}</b> ⇌ <b>${ca}</b> + <b>${cb}</b></div>` + TXB(`\\begin{aligned}K &= 10^{\\,\\mathrm{p}K_a(\\text{${cb}}) - \\mathrm{p}K_a(\\text{${a}})}\\\\ &= 10^{${K.toFixed(2)}} = ${sci(Math.pow(10, K))}\\end{aligned}`) + `<div class="small">${K > 0 ? `K > ১ ⇒ সাম্য <b>ডানে</b>: ${a} তীব্রতর এসিড, তাই প্রোটন ${b} এর কাছে যায়; উৎপন্ন ${cb} দুর্বলতর এসিড।` : `K < ১ ⇒ সাম্য <b>বামে</b>: ${cb} তীব্রতর এসিড — তাই প্রায় কোনো বিক্রিয়া হয় না।`} নিয়ম: সাম্য সবসময় দুর্বলতর এসিড ও দুর্বলতর ক্ষারকের দিকে।</div>`; };
    c.addEventListener('pointerdown', e => { const rc = c.getBoundingClientRect(), x = e.clientX - rc.left, y = e.clientY - rc.top, { top, rh, xp } = geo(); const i = Math.floor((y - top) / rh); if (i < 0 || i >= LAD.length) return; if (x < xp) sa = i; else sb = i; info(); draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= ১.১৬ লুইস এসিড-ক্ষারক (ত্রিমাত্রিক) ======================= */
const LCOL = { B: ['#e08a50', '#ffd8b8'], F: ['#7fc24a', '#d8f5c0'], N: ['#2d6fd6', '#a9c8ff'], H: ['#bbb', '#fff'], Ag: ['#a8a8b8', '#f0f0f8'], Cu: ['#2a9aa8', '#b8f0f0'], Fe: ['#b8602a', '#f0c8a8'], O: ['#c0392b', '#ffb3a8'], Al: ['#9aa2ad', '#e8ecf0'], Cl: ['#2f9e44', '#c8f0cf'] };
const nh3 = (pos, dir, u) => { const [dx, dy, dz] = dir, L2 = Math.hypot(dx, dy, dz), d = [dx / L2, dy / L2, dz / L2]; const a = Math.abs(d[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0]; const p1 = [d[1] * a[2] - d[2] * a[1], d[2] * a[0] - d[0] * a[2], d[0] * a[1] - d[1] * a[0]], l1 = Math.hypot(...p1); const e1 = p1.map(v => v / l1), e2 = [d[1] * e1[2] - d[2] * e1[1], d[2] * e1[0] - d[0] * e1[2], d[0] * e1[1] - d[1] * e1[0]]; const hs = [0, 1, 2].map(k => { const th = k * 2 * Math.PI / 3; return [0, 1, 2].map(j => pos[j] + d[j] * 0.36 + (e1[j] * Math.cos(th) + e2[j] * Math.sin(th)) * 0.94); }); return hs; };
const LSC = {
  bf3: { nm: 'BF₃ + NH₃ → F₃B←NH₃', build: u => { const at = [['B', 0, 0, 0, 0.42]]; const pyr = -0.42 * u; for (let k = 0; k < 3; k++) { const th = k * 2 * Math.PI / 3; at.push(['F', 1.3 * Math.cos(th) * (1 - 0.06 * u), 1.3 * Math.sin(th) * (1 - 0.06 * u), pyr, 0.38]); } const zN = 4.2 - 2.6 * u; at.push(['N', 0, 0, zN, 0.4]); nh3([0, 0, zN], [0, 0, 1], u).forEach(h => at.push(['H', ...h, 0.22])); const b = [[0, 1], [0, 2], [0, 3], [4, 5], [4, 6], [4, 7]]; return { at, b, dat: [[4, 0]], acc: [0, [0, 0, 1]], lp: [[4, [0, 0, -1]]] }; }, acid: 'BF₃ (B: ৬ ইলেকট্রন, খালি 2p)', base: 'NH₃ (N এর নিঃসঙ্গ জোড়)', geo: 'B: sp² ত্রিকোণীয় সমতলীয় → sp³ চতুস্তলকীয়' },
  ag: { nm: 'Ag⁺ + 2NH₃ → [Ag(NH₃)₂]⁺', build: u => { const at = [['Ag', 0, 0, 0, 0.55]]; const r = 4 - 1.9 * u; const b = [], lp = [], dat = []; [[1, 0, 0], [-1, 0, 0]].forEach(d => { const i = at.length; at.push(['N', d[0] * r, d[1] * r, d[2] * r, 0.4]); nh3([d[0] * r, 0, 0], d, u).forEach(h => { b.push([i, at.length]); at.push(['H', ...h, 0.22]); }); lp.push([i, d.map(v => -v)]); dat.push([i, 0]); }); return { at, b, dat, lp }; }, acid: 'Ag⁺ (খালি 5s, 5p)', base: '২টি NH₃', geo: 'sp — রৈখিক (১৮০°)' },
  cu: { nm: 'Cu²⁺ + 4NH₃ → [Cu(NH₃)₄]²⁺', build: u => { const at = [['Cu', 0, 0, 0, 0.55]]; const r = 4 - 1.95 * u; const b = [], lp = [], dat = []; [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0]].forEach(d => { const i = at.length; const p = d.map(v => v * r); at.push(['N', ...p, 0.4]); nh3(p, d, u).forEach(h => { b.push([i, at.length]); at.push(['H', ...h, 0.22]); }); lp.push([i, d.map(v => -v)]); dat.push([i, 0]); }); return { at, b, dat, lp, tint: 'rgba(40,60,200,' }; }, acid: 'Cu²⁺ (3d⁹, খালি 4s, 4p)', base: '৪টি NH₃', geo: 'বর্গাকার সমতলীয় (গাঢ় নীল-বেগুনি)' },
  fe: { nm: 'Fe³⁺ + 6H₂O → [Fe(H₂O)₆]³⁺', build: u => { const at = [['Fe', 0, 0, 0, 0.55]]; const r = 4 - 1.95 * u; const b = [], lp = [], dat = []; [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]].forEach(d => { const i = at.length; const p = d.map(v => v * r); at.push(['O', ...p, 0.38]); const hs = nh3(p, d, u).slice(0, 2); hs.forEach(h => { b.push([i, at.length]); at.push(['H', ...h, 0.22]); }); lp.push([i, d.map(v => -v)]); dat.push([i, 0]); }); return { at, b, dat, lp, tint: 'rgba(200,150,40,' }; }, acid: 'Fe³⁺ (3d⁵, খালি 4s, 4p, 4d)', base: '৬টি H₂O (O এর নিঃসঙ্গ জোড়)', geo: 'অষ্টতলকীয় (হালকা বেগুনি-হলুদ)' },
  alcl: { nm: 'AlCl₃ + Cl⁻ → AlCl₄⁻', build: u => { const at = [['Al', 0, 0, 0, 0.48]]; const pyr = -0.45 * u; for (let k = 0; k < 3; k++) { const th = k * 2 * Math.PI / 3; at.push(['Cl', 2.0 * Math.cos(th) * (1 - 0.05 * u), 2.0 * Math.sin(th) * (1 - 0.05 * u), pyr * 1.5, 0.48]); } at.push(['Cl', 0, 0, 4.8 - 2.7 * u, 0.5]); return { at, b: [[0, 1], [0, 2], [0, 3]], dat: [[4, 0]], acc: [0, [0, 0, 1]], lp: [[4, [0, 0, -1]]] }; }, acid: 'AlCl₃ (Al: ৬ ইলেকট্রন)', base: 'Cl⁻', geo: 'ত্রিকোণীয় সমতলীয় → চতুস্তলকীয়; ফ্রিডেল-ক্রাফটস অনুঘটকের মূল' }
};
V.p2c1_lewis3d = {
  t: 'লুইস এসিড-ক্ষারক (ত্রিমাত্রিক): খালি অরবিটালে নিঃসঙ্গ জোড় দান, সন্নিবেশ বন্ধন ও জ্যামিতির পরিবর্তন — BF₃·NH₃, [Ag(NH₃)₂]⁺, [Cu(NH₃)₄]²⁺, [Fe(H₂O)₆]³⁺, AlCl₄⁻', k: ['3d', 'anim', 'int'],
  cap: 'একটি বিক্রিয়া বেছে নাও এবং "অগ্রগতি" স্লাইডার টানো (বা চালু করো)। লুইস এসিডের খালি অরবিটাল স্বচ্ছ কমলা লোব আর ক্ষারকের নিঃসঙ্গ জোড় স্বচ্ছ নীল লোব হিসেবে দেখানো আছে। দুটি কাছে এলে লোব মিশে যায় এবং সবুজ তীর (দাতা → গ্রাহক) দিয়ে সন্নিবেশ বন্ধন আঁকা হয়। BF₃ ও AlCl₃ এ কেন্দ্রীয় পরমাণুর চারপাশের পরমাণু সমতল থেকে পিরামিডের দিকে বাঁকে (sp² → sp³)। অণুটি টেনে যেকোনো দিকে ঘোরাও।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('lw', [['bf3', 'BF₃·NH₃'], ['ag', '[Ag(NH₃)₂]⁺'], ['cu', '[Cu(NH₃)₄]²⁺'], ['fe', '[Fe(H₂O)₆]³⁺'], ['alcl', 'AlCl₄⁻']], 'bf3')}</div>${X.cv('লুইস ত্রিমাত্রিক')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:160px">অগ্রগতি = <b data-uv></b>%<input type="range" min="0" max="100" step="1" value="0" data-u></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 380;
    let L = X.fit(c, hf), sc = 'bf3', u = 0, dir = 1, t = 0; const view = { yaw: 0.6, pitch: 0.45, user: false };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const S = LSC[sc], M = S.build(u);
      if (!view.user) view.yaw += 0.003;
      const cy = Math.cos(view.yaw), sy = Math.sin(view.yaw), cp = Math.cos(view.pitch), sp = Math.sin(view.pitch); const sc2 = Math.min(W, H) / (sc === 'fe' ? 9.5 : 8.6);
      const ctr = sc === 'bf3' || sc === 'alcl' ? [0, 0, 1.4 * (1 - u * 0.5)] : [0, 0, 0];
      const proj = p => { const x = p[0] - ctr[0], y = p[1] - ctr[1], z = p[2] - ctr[2]; const x1 = x * cy + y * sy, y1 = -x * sy + y * cy; const yv = -z * cp + y1 * sp, zv = z * sp + y1 * cp; return [W / 2 + x1 * sc2, H / 2 + yv * sc2, zv]; };
      if (M.tint) { g.fillStyle = M.tint + (0.06 + 0.14 * u) + ')'; g.fillRect(0, 0, W, H); }
      const P = M.at.map(a => proj([a[1], a[2], a[3]]));
      const items = [];
      M.b.forEach(([i, j]) => items.push({ z: (P[i][2] + P[j][2]) / 2, f: () => { g.strokeStyle = col.mu; g.lineWidth = 3; g.beginPath(); g.moveTo(P[i][0], P[i][1]); g.lineTo(P[j][0], P[j][1]); g.stroke(); } }));
      M.at.forEach((a, i) => items.push({ z: P[i][2], f: () => { const r = a[4] * sc2; ball(g, P[i][0], P[i][1], r, ...LCOL[a[0]]); if (r > 9) { g.fillStyle = a[0] === 'H' ? '#333' : '#fff'; g.font = `bold ${Math.round(r * 0.62)}px ${col.font}`; g.textAlign = 'center'; g.fillText(a[0], P[i][0], P[i][1] + r * 0.22); } } }));
      // orbital lobes
      const lobe = (p0, d, len, cl, al) => { const a = proj([p0[0] + d[0] * len, p0[1] + d[1] * len, p0[2] + d[2] * len]); const b0 = proj(p0); const mx = (a[0] + b0[0]) / 2, my = (a[1] + b0[1]) / 2, ang = Math.atan2(a[1] - b0[1], a[0] - b0[0]), lp = Math.max(6, Math.hypot(a[0] - b0[0], a[1] - b0[1]) / 2); const gr = g.createRadialGradient(mx, my, 1, mx, my, Math.max(lp, 12)); gr.addColorStop(0, cl + al + ')'); gr.addColorStop(1, cl + '0)'); g.fillStyle = gr; g.beginPath(); g.ellipse(mx, my, Math.max(lp, 10), 0.42 * sc2, ang, 0, 7); g.fill(); return (a[2] + b0[2]) / 2; };
      if (M.acc) { const [i, d] = M.acc, a = M.at[i], p0 = [a[1], a[2], a[3]]; const al = Math.max(0, 0.55 * (1 - u)); items.push({ z: 99, f: () => { lobe(p0, d, 1.4, 'rgba(240,140,40,', al); lobe(p0, d.map(v => -v), 1.4, 'rgba(240,140,40,', al * 0.8); } }); }
      else { const a = M.at[0], al = 0.35 * (1 - u); items.push({ z: -99, f: () => { const p = proj([a[1], a[2], a[3]]); const gr = g.createRadialGradient(p[0], p[1], 2, p[0], p[1], sc2 * 1.6); gr.addColorStop(0, `rgba(240,140,40,${al})`); gr.addColorStop(1, 'rgba(240,140,40,0)'); g.fillStyle = gr; g.beginPath(); g.arc(p[0], p[1], sc2 * 1.6, 0, 7); g.fill(); } }); }
      M.lp.forEach(([i, d]) => { const a = M.at[i], p0 = [a[1], a[2], a[3]]; items.push({ z: 98, f: () => lobe(p0, d, 0.9 + 0.3 * (1 - u), 'rgba(45,111,214,', 0.55) }); });
      // dative bonds
      M.dat.forEach(([i, j]) => { const pa = P[i], pb = P[j]; const prog = Math.max(0, (u - 0.6) / 0.4); if (prog <= 0) { g.globalAlpha = 0.5; } items.push({ z: (pa[2] + pb[2]) / 2 + 0.01, f: () => { const ra = M.at[i][4] * sc2, rb = M.at[j][4] * sc2, ang = Math.atan2(pb[1] - pa[1], pb[0] - pa[0]); const sx = pa[0] + Math.cos(ang) * ra, sy2 = pa[1] + Math.sin(ang) * ra, ex = pb[0] - Math.cos(ang) * rb, ey = pb[1] - Math.sin(ang) * rb; if (prog > 0) { g.strokeStyle = '#2f9e44'; g.fillStyle = '#2f9e44'; g.lineWidth = 3; g.globalAlpha = prog; g.beginPath(); g.moveTo(sx, sy2); g.lineTo(ex, ey); g.stroke(); g.beginPath(); g.moveTo(ex, ey); g.lineTo(ex - 9 * Math.cos(ang - .45), ey - 9 * Math.sin(ang - .45)); g.lineTo(ex - 9 * Math.cos(ang + .45), ey - 9 * Math.sin(ang + .45)); g.fill(); g.globalAlpha = 1; } else { g.strokeStyle = col.mu; g.lineWidth = 1; g.setLineDash([3, 4]); g.beginPath(); g.moveTo(sx, sy2); g.lineTo(ex, ey); g.stroke(); g.setLineDash([]); } } }); g.globalAlpha = 1; });
      items.sort((a, b) => a.z - b.z).forEach(it => it.f());
      g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'left'; g.fillText(S.nm, 10, 18); g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.fillText('টেনে ঘোরাও', 10, H - 8);
    };
    const info = () => { const S = LSC[sc]; q('[data-uv]').textContent = bn(Math.round(u * 100)); q('[data-u]').value = Math.round(u * 100);
      out.innerHTML = `<div><b>লুইস এসিড:</b> ${S.acid} · <b>লুইস ক্ষারক:</b> ${S.base}</div><div class="small" style="margin-top:4px"><b>জ্যামিতি:</b> ${S.geo}। ${u < 0.6 ? 'ক্ষারক এগিয়ে আসছে — নিঃসঙ্গ জোড়ের লোব খালি অরবিটালের দিকে মুখ করে।' : u < 1 ? 'অরবিটাল অধিক্রমণ শুরু — সন্নিবেশ বন্ধন তৈরি হচ্ছে।' : 'আডাক্ট/জটিল আয়ন সম্পূর্ণ — প্রতিটি সবুজ তীর দাতা থেকে গ্রাহকের দিকে একটি সন্নিবেশ বন্ধন।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; u += dir * dt * 0.25; if (u >= 1) { u = 1; dir = -1; t = -1.5; } if (u <= 0) { u = 0; dir = 1; } if (t < 0) u = 1; info(); } draw(); }, { paused: true }); X.pp(el, A);
    q('[data-u]').oninput = e => { u = +e.target.value / 100; info(); A.draw(); };
    X.onSeg(el, 'lw', k => { sc = k; info(); A.draw(); });
    C4.drag3d(c, view, () => A.draw());
    u = 0.55; info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
