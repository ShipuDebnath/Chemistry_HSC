/* ২য় পত্র অধ্যায় ১ visuals part 9 — greenhouse effect, IR vibrations, Keeling curve, carbon footprint (1.11) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const wave = (g, x1, y1, x2, y2, amp, wl, cl, w = 1.8, ph = 0) => { const L = Math.hypot(x2 - x1, y2 - y1), ux = (x2 - x1) / L, uy = (y2 - y1) / L; g.strokeStyle = cl; g.lineWidth = w; g.beginPath(); for (let s = 0; s <= L; s += 1.5) { const o = Math.sin(s / wl * 2 * Math.PI + ph) * amp; const x = x1 + ux * s - uy * o, y = y1 + uy * s + ux * o; s ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); g.fillStyle = cl; const a = Math.atan2(uy, ux); g.beginPath(); g.moveTo(x2, y2); g.lineTo(x2 - 6 * Math.cos(a - .5), y2 - 6 * Math.sin(a - .5)); g.lineTo(x2 - 6 * Math.cos(a + .5), y2 - 6 * Math.sin(a + .5)); g.fill(); };

/* ======================= গ্রিনহাউস প্রভাব: ফোটন অ্যানিমেশন ও শক্তি-ভারসাম্য ======================= */
const TE = 255, TAU0 = 0.836, KT = 0.133;
const tauOf = ppm => ppm <= 0 ? 0 : Math.max(0, TAU0 + KT * Math.log(ppm / 280));
const TsOf = ppm => TE * Math.pow(1 + 0.75 * tauOf(ppm), 0.25);
V.p2c1_greenhouse = {
  t: 'গ্রিনহাউস প্রভাব: সূর্যের দৃশ্যমান আলো প্রবেশ, ভূপৃষ্ঠের অবলোহিত বিকিরণ শোষণ ও পুনর্বিকিরণ (ফোটন অ্যানিমেশন)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'হলুদ ছোট-তরঙ্গ ফোটন (দৃশ্যমান আলো) বায়ুমণ্ডল ভেদ করে ভূপৃষ্ঠে পড়ে — কিছু মেঘ ও বরফে প্রতিফলিত হয় (অ্যালবেডো ৩০%)। উত্তপ্ত ভূপৃষ্ঠ লাল দীর্ঘ-তরঙ্গ IR ফোটন বিকিরণ করে; বায়ুমণ্ডলের CO₂ অণু (ধূসর-লাল) সেগুলো শোষণ করে যেকোনো দিকে পুনর্বিকিরণ করে — অনেকগুলো আবার নিচে ফেরে। N₂ ও O₂ (ফ্যাকাশে) IR কে উপেক্ষা করে। CO₂ স্লাইডার বাড়ালে বেশি IR আটকে যায় এবং ডানের থার্মোমিটারে সাম্য তাপমাত্রা বাড়ে; "গ্রিনহাউস গ্যাস নেই" বোতামে পৃথিবী −১৮ °C।',
  html: () => `${X.cv('গ্রিনহাউস প্রভাব')}<div class="ctl"><button class="btn sm" data-pp></button><label class="small" style="flex:1;min-width:160px">CO₂ = <b data-cv></b> ppm<input type="range" min="180" max="1120" step="10" value="420" data-c></label><button class="btn sm" data-none>গ্রিনহাউস গ্যাস নেই</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 400;
    let L = X.fit(c, hf), ppm = 420, none = false, t = 0, Ph = [], esc = 0, back = 0; const Rn = X.rng(21);
    let mols = [];
    const setMols = () => { const n = none ? 0 : Math.round(6 + ppm / 30); mols = Array.from({ length: n }, () => ({ x: Rn(), y: 0.18 + Rn() * 0.42, ph: Rn() * 6, hit: 0 })); };
    const air = Array.from({ length: 40 }, () => ({ x: Rn(), y: 0.15 + Rn() * 0.5, k: Rn() < 0.79 ? 'N' : 'O', ph: Rn() * 6 }));
    setMols();
    const geo = () => { const { W, H } = L, wd = wide(W); return { sw: wd ? W * 0.84 : W - 54, gy: H * 0.8, top: H * 0.1 }; };
    const step = dt => { t += dt; const { sw, gy, top } = geo(), H = L.H;
      if (Rn() < dt * 6) Ph.push({ k: 'sun', x: 0.1 + Rn() * 0.8, y: top - 10, dx: 0.15, dy: 1, life: 0 });
      Ph.forEach(p => { p.life += dt; const sp = p.k === 'sun' ? 120 : 75; p.x += p.dx * sp * dt / sw; p.y += p.dy * sp * dt;
        if (p.k === 'sun' && p.y > gy - 4) { if (Rn() < 0.3) { p.k = 'ref'; p.dy = -1; p.dx = 0.15; } else { p.dead = true; Ph.push({ k: 'ir', x: p.x + (Rn() - .5) * 0.05, y: gy - 4, dx: (Rn() - .5) * 0.6, dy: -1, life: 0, absorbed: 0 }); } }
        if (p.k === 'ir') { mols.forEach(m => { if (p.absorbed > 3) return; const mx = m.x * sw, my = m.y * H; if (Math.abs(p.x * sw - mx) < 9 && Math.abs(p.y - my) < 9 && p.life > 0.15) { m.hit = 1; p.absorbed++; p.life = 0; const a = Rn() * Math.PI * 2; p.dx = Math.cos(a); p.dy = Math.sin(a); p.x = m.x + p.dx * 12 / sw; p.y = my + p.dy * 12; } });
          if (p.y > gy) { p.dead = true; back++; } if (p.y < top - 10) { p.dead = true; esc++; } }
        if (p.k === 'ref' && p.y < top - 10) p.dead = true; if (p.x < -0.05 || p.x > 1.05) p.dead = true; });
      Ph = Ph.filter(p => !p.dead); mols.forEach(m => { m.hit = Math.max(0, m.hit - dt * 2.5); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), { sw, gy, top } = geo();
      const Ts = none ? TE : TsOf(ppm), heat = Math.min(1, Math.max(0, (Ts - 250) / 50));
      const sky = g.createLinearGradient(0, 0, 0, gy); sky.addColorStop(0, '#0d1530'); sky.addColorStop(0.12, '#1d3a70'); sky.addColorStop(1, '#8ec0ea'); g.fillStyle = sky; g.fillRect(0, 0, sw, gy);
      g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(0, top, sw, gy - top); g.fillStyle = 'rgba(255,255,255,.7)'; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('বায়ুমণ্ডল', sw - 6, top + 12); g.textAlign = 'left'; g.fillText('মহাশূন্য', 6, 12);
      // sun
      const sg = g.createRadialGradient(18, 18, 2, 18, 18, 40); sg.addColorStop(0, '#fff6b0'); sg.addColorStop(1, 'rgba(255,200,60,0)'); g.fillStyle = sg; g.beginPath(); g.arc(18, 18, 40, 0, 7); g.fill();
      // cloud
      g.fillStyle = 'rgba(255,255,255,.85)'; [[0.72, 0.3, 14], [0.76, 0.28, 18], [0.8, 0.31, 13]].forEach(([x, y, r]) => { g.beginPath(); g.arc(x * sw, y * H, r, 0, 7); g.fill(); });
      // ground
      const gg = g.createLinearGradient(0, gy, 0, H); gg.addColorStop(0, `rgb(${90 + 80 * heat},${120 - 20 * heat},${60 - 20 * heat})`); gg.addColorStop(1, `rgb(${60 + 60 * heat},${70},${40})`); g.fillStyle = gg; g.fillRect(0, gy, sw, H - gy);
      g.fillStyle = '#2d6fd6'; g.fillRect(sw * 0.62, gy, sw * 0.38, H - gy); g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('ভূপৃষ্ঠ', 6, H - 8); g.textAlign = 'right'; g.fillText('সমুদ্র', sw - 6, H - 8);
      // molecules
      air.forEach(m => { const x = m.x * sw + Math.sin(t + m.ph) * 4, y = m.y * H; g.globalAlpha = 0.35; const cc = m.k === 'N' ? ['#2d6fd6', '#a9c8ff'] : ['#c0392b', '#ffb3a8']; ball(g, x - 2.5, y, 2.6, ...cc); ball(g, x + 2.5, y, 2.6, ...cc); g.globalAlpha = 1; });
      mols.forEach(m => { const x = m.x * sw + Math.sin(t * 1.3 + m.ph) * 3, y = m.y * H, b = m.hit; if (b > 0) { g.fillStyle = `rgba(255,90,60,${0.5 * b})`; g.beginPath(); g.arc(x, y, 9, 0, 7); g.fill(); } const bend = Math.sin(t * 12 + m.ph) * (1 + 2 * b); ball(g, x - 5, y + bend, 2.8, '#c0392b', '#ffb3a8'); ball(g, x + 5, y + bend, 2.8, '#c0392b', '#ffb3a8'); ball(g, x, y - bend, 3.2, '#333', '#888'); });
      // photons
      Ph.forEach(p => { const x = p.x * sw, y = p.y; const len = p.k === 'ir' ? 20 : 16; const a = Math.atan2(p.dy, p.dx * 1); const x0 = x - Math.cos(a) * len, y0 = y - Math.sin(a) * len;
        if (p.k === 'sun' || p.k === 'ref') wave(g, x0, y0, x, y, 2, 5, p.k === 'sun' ? '#ffd23a' : 'rgba(255,240,170,.7)', 1.6, t * 30); else wave(g, x0, y0, x, y, 3.2, 12, '#ff4a2a', 2, t * 14); });
      // thermometer
      const tx = wd ? sw + (W - sw) / 2 : W - 26, ty0 = 24, ty1 = gy - 6, Tmin = 250, Tmax = 300, tY = T => ty1 - (T - Tmin) / (Tmax - Tmin) * (ty1 - ty0);
      g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.2; rr(g, tx - 6, ty0 - 6, 12, ty1 - ty0 + 12, 6); g.fill(); g.stroke(); g.beginPath(); g.arc(tx, ty1 + 12, 11, 0, 7); g.fillStyle = '#d63a2a'; g.fill(); g.stroke(); g.fillStyle = '#d63a2a'; g.fillRect(tx - 3, tY(Ts), 6, ty1 + 4 - tY(Ts));
      [255, 270, 288, 300].forEach(T => { g.strokeStyle = col.mu; g.lineWidth = 1; g.beginPath(); g.moveTo(tx - 10, tY(T)); g.lineTo(tx - 6, tY(T)); g.stroke(); g.fillStyle = col.mu; g.font = `8.5px ${col.font}`; g.textAlign = 'right'; g.fillText(`${bn(Math.round(T - 273))}°`, tx - 11, tY(T) + 3); });
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`${bn((Ts - 273.15).toFixed(1))} °C`, tx - (wd ? 0 : 6), H - 4);
    };
    const info = () => { q('[data-cv]').textContent = bn(ppm); q('[data-none]').classList.toggle('primary', none); const Ts = none ? TE : TsOf(ppm), dF = 5.35 * Math.log(ppm / 280), tot = esc + back;
      out.innerHTML = none ? TXB('T_e = \\left(\\dfrac{S(1-\\alpha)}{4\\sigma}\\right)^{1/4} = 255\\ \\mathrm{K} = -18\\ ^\\circ\\mathrm{C}') + '<div class="small">কোনো গ্রিনহাউস গ্যাস নেই — ভূপৃষ্ঠের সব IR সরাসরি মহাশূন্যে চলে যায়; সমুদ্র জমে বরফ হতো।</div>'
        : TXB(`\\Delta F = 5.35\\ln\\dfrac{${ppm}}{280} = ${dF.toFixed(2)}\\ \\mathrm{W\\,m^{-2}}`) + `<div class="small">সাম্য ভূপৃষ্ঠ তাপমাত্রা ≈ <b>${bn((Ts - 273.15).toFixed(1))} °C</b> (প্রাক-শিল্প ২৮০ ppm এ ${bn((TsOf(280) - 273.15).toFixed(1))} °C; পার্থক্য ${bn((Ts - TsOf(280)).toFixed(1))} K)। সরল ধূসর-বায়ুমণ্ডল মডেল, জলীয় বাষ্পের প্রতিক্রিয়াসহ।${tot > 20 ? ` অ্যানিমেশনে IR ফোটনের ${bn(Math.round(back / tot * 100))}% ভূপৃষ্ঠে ফিরেছে।` : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.05)); draw(); }, { paused: false }); X.pp(el, A);
    q('[data-c]').oninput = e => { ppm = +e.target.value; none = false; esc = back = 0; setMols(); info(); A.draw(); };
    q('[data-none]').onclick = () => { none = !none; esc = back = 0; setMols(); info(); A.draw(); };
    for (let i = 0; i < 120; i++) step(0.03);
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= আণবিক কম্পন ও IR সক্রিয়তা (ত্রিমাত্রিক) ======================= */
const MOLS = {
  co2: { nm: 'CO₂', at: [['C', 0, 0, 0, 12, 0.7], ['O', -1.16, 0, 0, 16, -0.35], ['O', 1.16, 0, 0, 16, -0.35]], b: [[0, 1, 2], [0, 2, 2]], modes: [
    ['প্রতিসম প্রসারণ', [[0, 0, 0], [-1, 0, 0], [1, 0, 0]], '~১৩৩৩ cm⁻¹ (৭.৫ µm)'], ['অপ্রতিসম প্রসারণ', [[-2.67, 0, 0], [1, 0, 0], [1, 0, 0]], '২৩৪৯ cm⁻¹ (৪.৩ µm)'], ['বাঁকানো', [[0, 2.67, 0], [0, -1, 0], [0, -1, 0]], '৬৬৭ cm⁻¹ (১৫ µm)']] },
  h2o: { nm: 'H₂O', at: [['O', 0, -0.07, 0, 16, -0.66], ['H', -0.76, 0.52, 0, 1, 0.33], ['H', 0.76, 0.52, 0, 1, 0.33]], b: [[0, 1, 1], [0, 2, 1]], modes: [
    ['প্রতিসম প্রসারণ', [[0, -0.07, 0], [-0.82, 0.57, 0], [0.82, 0.57, 0]], '৩৬৫৭ cm⁻¹ (২.৭ µm)'], ['অপ্রতিসম প্রসারণ', [[0.07, 0, 0], [-0.82, 0.57, 0], [-0.82, -0.57, 0]], '৩৭৫৬ cm⁻¹ (২.৭ µm)'], ['বাঁকানো', [[0, 0.07, 0], [0.57, 0.82, 0], [-0.57, 0.82, 0]], '১৫৯৫ cm⁻¹ (৬.৩ µm)']] },
  n2: { nm: 'N₂', at: [['N', -0.55, 0, 0, 14, 0], ['N', 0.55, 0, 0, 14, 0]], b: [[0, 1, 3]], modes: [['প্রসারণ', [[-1, 0, 0], [1, 0, 0]], '২৩৩০ cm⁻¹ (IR এ অদৃশ্য)']] }
};
const ACOL = { C: ['#333', '#999'], O: ['#c0392b', '#ffb3a8'], H: ['#bbb', '#fff'], N: ['#2d6fd6', '#a9c8ff'] };
V.p2c1_irvib = {
  t: 'আণবিক কম্পন ও IR সক্রিয়তা: CO₂, H₂O ও N₂ এর কম্পনে দ্বিপোল ভ্রামকের পরিবর্তন (ত্রিমাত্রিক)', k: ['3d', 'anim', 'int'],
  cap: 'অণু ও কম্পন বেছে নাও; ত্রিমাত্রিক অণুটি টেনে ঘোরানো যায়। পরমাণুর রঙিন আভা আংশিক চার্জ (লাল δ−, নীল δ+), সবুজ তীর মোট দ্বিপোল ভ্রামক। ডানে দ্বিপোলের সময়-লেখ: যে কম্পনে দ্বিপোল দোলে সেটি IR সক্রিয় — বাঁ দিক থেকে আসা IR তরঙ্গ শোষিত হয়ে ক্ষীণ হয়; যেখানে দ্বিপোল সবসময় শূন্য (CO₂ এর প্রতিসম প্রসারণ, N₂) সেখানে তরঙ্গ অক্ষত বেরিয়ে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('ml', [['co2', 'CO₂'], ['h2o', 'H₂O'], ['n2', 'N₂']], 'co2')}<span data-modes style="display:flex;gap:4px;flex-wrap:wrap"></span></div>${X.cv('আণবিক কম্পন')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), mbox = el.querySelector('[data-modes]');
    const hf = w => wide(w) ? 300 : 420;
    let L = X.fit(c, hf), ml = 'co2', md = 2, t = 0; const view = { yaw: 0.5, pitch: 0.35, user: false };
    const dip = (M, s) => { let mx = 0, my = 0, mz = 0; M.at.forEach((a, i) => { const d = M.modes[md][1][i]; const x = a[1] + d[0] * s * 0.18, y = a[2] + d[1] * s * 0.18, z = a[3] + d[2] * s * 0.18; mx += a[5] * x; my += a[5] * y; mz += a[5] * z; }); return [mx, my, mz]; };
    const active = M => { const a = dip(M, 1), b = dip(M, -1); return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) > 0.02; };
    const modesUI = () => { const M = MOLS[ml]; mbox.innerHTML = M.modes.map((m, i) => `<button class="btn sm${i === md ? ' primary' : ''}" data-md="${i}">${m[0]}</button>`).join(''); mbox.querySelectorAll('[data-md]').forEach(b => { b.onclick = () => { md = +b.dataset.md; modesUI(); info(); }; }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), M = MOLS[ml], s = Math.sin(t * 5), act = active(M);
      const cx = wd ? W * 0.3 : W / 2, cy = wd ? H * 0.5 : 120, sc = wd ? Math.min(W * 0.11, 70) : 60;
      if (!view.user) view.yaw += 0.004;
      const cyw = Math.cos(view.yaw), syw = Math.sin(view.yaw), cp = Math.cos(view.pitch), sp = Math.sin(view.pitch);
      const proj = ([x, y, z]) => { const x1 = x * cyw + z * syw, z1 = -x * syw + z * cyw; const y1 = y * cp - z1 * sp, z2 = y * sp + z1 * cp; return [cx + x1 * sc, cy + y1 * sc, z2]; };
      const pos = M.at.map((a, i) => { const d = M.modes[md][1][i]; return [a[1] + d[0] * s * 0.18, a[2] + d[1] * s * 0.18, a[3] + d[2] * s * 0.18]; });
      const P = pos.map(proj);
      // IR wave
      const wy = wd ? cy : cy, absorbed = act; const x0 = 8, x1 = wd ? W * 0.56 : W - 8; for (let k = 0; k < 2; k++) { g.strokeStyle = k ? '#ff4a2a' : 'rgba(255,74,42,.25)'; g.lineWidth = k ? 1.8 : 4; g.beginPath(); for (let x = x0; x <= x1; x += 2) { const f = x < cx ? 1 : absorbed ? Math.max(0.12, 1 - (x - cx) / 60) : 1; const y = wy + sc * 1.6 + Math.sin(x / 9 - t * 9) * 7 * f; x === x0 ? g.moveTo(x, y) : g.lineTo(x, y); } g.stroke(); }
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('IR রশ্মি →', x0, wy + sc * 1.6 - 12);
      // bonds
      M.b.forEach(([i, j, n]) => { const [xa, ya] = P[i], [xb, yb] = P[j], dx = xb - xa, dy = yb - ya, l = Math.hypot(dx, dy) || 1, nx = -dy / l, ny = dx / l; for (let k = 0; k < n; k++) { const o = (k - (n - 1) / 2) * 4; g.strokeStyle = col.mu; g.lineWidth = 2.2; g.beginPath(); g.moveTo(xa + nx * o, ya + ny * o); g.lineTo(xb + nx * o, yb + ny * o); g.stroke(); } });
      // atoms sorted by depth
      M.at.map((a, i) => [a, P[i]]).sort((u, v) => u[1][2] - v[1][2]).forEach(([a, p]) => { const r = (a[4] === 1 ? 0.28 : 0.45) * sc; if (Math.abs(a[5]) > 0.01) { const gl = g.createRadialGradient(p[0], p[1], r * 0.6, p[0], p[1], r * 1.6); gl.addColorStop(0, a[5] < 0 ? 'rgba(220,40,40,.35)' : 'rgba(40,90,220,.35)'); gl.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gl; g.beginPath(); g.arc(p[0], p[1], r * 1.6, 0, 7); g.fill(); } ball(g, p[0], p[1], r, ...ACOL[a[0]]); g.fillStyle = a[0] === 'H' ? '#333' : '#fff'; g.font = `bold ${Math.round(r * 0.7)}px ${col.font}`; g.textAlign = 'center'; g.fillText(a[0], p[0], p[1] + r * 0.25); });
      // displacement arrows (faint)
      M.at.forEach((a, i) => { const d = M.modes[md][1][i]; if (Math.hypot(...d) < 0.01) return; const p0 = proj([a[1], a[2], a[3]]), p1 = proj([a[1] + d[0] * 0.5, a[2] + d[1] * 0.5, a[3] + d[2] * 0.5]); g.globalAlpha = 0.5; P2.tag ? 0 : 0; g.strokeStyle = col.acc; g.lineWidth = 1.4; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(p0[0], p0[1]); g.lineTo(p1[0], p1[1]); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; });
      // dipole vector
      const D = dip(M, s), base0 = dip(M, 0), dp = proj([0, 0, 0]), dpe = proj([D[0] * 2.2, D[1] * 2.2, D[2] * 2.2]); if (Math.hypot(...D) > 0.01) { g.strokeStyle = '#2f9e44'; g.fillStyle = '#2f9e44'; g.lineWidth = 3; g.beginPath(); g.moveTo(dp[0], dp[1]); g.lineTo(dpe[0], dpe[1]); g.stroke(); const a = Math.atan2(dpe[1] - dp[1], dpe[0] - dp[0]); g.beginPath(); g.moveTo(dpe[0], dpe[1]); g.lineTo(dpe[0] - 8 * Math.cos(a - .45), dpe[1] - 8 * Math.sin(a - .45)); g.lineTo(dpe[0] - 8 * Math.cos(a + .45), dpe[1] - 8 * Math.sin(a + .45)); g.fill(); g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText('μ', dpe[0] + 4, dpe[1] - 4); }
      // dipole-time graph
      const gx0 = wd ? W * 0.62 : 50, gy0 = wd ? 30 : 250, gw = wd ? W - gx0 - 16 : W - 66, gh = wd ? H - 80 : H - gy0 - 44;
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmax: 2, ymin: -1, ymax: 1, col, xt: [0, 1, 2], yt: [-1, 0, 1], xl: 'সময় (কম্পন চক্র)', yl: 'দ্বিপোল ভ্রামক μ', fy: v => v === 0 ? '০' : v > 0 ? '+' : '−', ylx: 22 });
      const amp = Math.hypot(...dip(M, 1).map((v, k) => v - base0[k])); const pts = []; for (let u = 0; u <= 2; u += 0.02) pts.push([Pl.X(u), Pl.Y(amp > 0.01 ? 0.85 * Math.sin(u * 2 * Math.PI) : 0)]); path(g, pts, act ? '#2f9e44' : col.mu, 2.4);
      const un = ((t * 5) / (2 * Math.PI)) % 2; ball(g, Pl.X(un), Pl.Y(amp > 0.01 ? 0.85 * Math.sin(un * 2 * Math.PI) : 0), 5, act ? '#2f9e44' : '#888', '#fff');
      g.fillStyle = act ? '#2f9e44' : '#c0392b'; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(act ? 'IR সক্রিয় ✓' : 'IR নিষ্ক্রিয় ✗', gx0 + gw / 2, gy0 - 8);
    };
    const info = () => { const M = MOLS[ml], m = M.modes[md], act = active(M); const nv = ml === 'n2' ? '৩ × ২ − ৫ = ১' : ml === 'co2' ? '৩ × ৩ − ৫ = ৪ (বাঁকানো কম্পন দুটি, সমশক্তির)' : '৩ × ৩ − ৬ = ৩';
      out.innerHTML = `<div><b>${M.nm} — ${m[0]}</b> (${m[2]}): ${act ? 'কম্পনের সময় দ্বিপোল ভ্রামক পর্যায়ক্রমে বদলায় ⇒ IR রশ্মির দোলায়মান তড়িৎক্ষেত্রের সাথে শক্তি বিনিময় ⇒ <b>IR সক্রিয়</b>।' : 'কম্পনের পুরো সময় প্রতিসাম্য বজায় থাকে, দ্বিপোল সবসময় শূন্য ⇒ <b>IR নিষ্ক্রিয়</b>।'}</div><div class="small" style="margin-top:4px">কম্পন সংখ্যা: ${nv}। ${ml === 'co2' && md === 2 ? '১৫ µm শোষণ পৃথিবীর বিকিরণ শীর্ষের (~১০ µm) খুব কাছে — CO₂ এর গ্রিনহাউস ক্ষমতার মূল উৎস।' : ml === 'n2' ? 'বায়ুর ৭৮% N₂ ও ২১% O₂ এ কারণেই গ্রিনহাউস গ্যাস নয়।' : ml === 'h2o' ? 'H₂O অরৈখিক ও পোলার — তিনটি কম্পনই IR সক্রিয়; সবচেয়ে বড় গ্রিনহাউস গ্যাস।' : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'ml', k => { ml = k; md = MOLS[k].modes.length > 2 ? 2 : 0; if (k === 'h2o') md = 0; modesUI(); info(); });
    C4.drag3d(c, view, () => A.draw());
    modesUI(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= কিলিং বক্ররেখা ও উষ্ণতার প্রক্ষেপণ ======================= */
const KD = [[1959, 315.98], [1960, 316.91], [1965, 320.04], [1970, 325.68], [1975, 331.11], [1980, 338.75], [1985, 346.12], [1990, 354.39], [1995, 360.82], [2000, 369.71], [2005, 379.98], [2010, 389.90], [2015, 401.01], [2020, 414.24], [2023, 421.08], [2024, 424.61]];
const kAnn = y => { if (y <= KD[0][0]) return KD[0][1]; for (let i = 1; i < KD.length; i++) if (y <= KD[i][0]) { const [y0, c0] = KD[i - 1], [y1, c1] = KD[i]; return c0 + (c1 - c0) * (y - y0) / (y1 - y0); } return KD[KD.length - 1][1]; };
V.p2c1_keeling = {
  t: 'কিলিং বক্ররেখা (মাউনা লোয়া CO₂, ১৯৫৯–২০২৪) এবং ২১০০ সাল পর্যন্ত বিকিরণ চাপ ও তাপমাত্রার প্রক্ষেপণ', k: ['int', 'calc', '2d', 'anim'],
  cap: 'কালো রেখা: মাউনা লোয়ায় মাপা বায়ুর CO₂ (বার্ষিক গড়ের উপর আনুমানিক মৌসুমি ওঠানামা — প্রতি মে মাসে চূড়া, অক্টোবরে খাদ)। ২০২৪ এর পর বাদামি ড্যাশ রেখা তোমার বেছে নেওয়া পথ: বার্ষিক বৃদ্ধির হার স্লাইডারে বদলাও (ঋণাত্মক মানে নির্গমন কমিয়ে CO₂ কমানো)। ডানে ২১০০ সালের ঘনত্বে বিকিরণ চাপ ΔF = ৫.৩৫ ln(C/২৮০) ও সাম্য উষ্ণতা ΔT ≈ ০.৮ΔF; প্যারিস চুক্তির ১.৫ °C ও ২ °C রেখা চিহ্নিত।',
  html: () => `${X.cv('কিলিং বক্ররেখা')}<div class="ctl"><label class="small" style="flex:1;min-width:180px">২০২৫–২১০০ বার্ষিক বৃদ্ধি = <b data-rv></b> ppm/বছর<input type="range" min="-1" max="5" step="0.1" value="2.5" data-r></label><label class="small" style="flex:1;min-width:140px"><input type="checkbox" data-zoom> শেষ ৫ বছর বড় করে দেখাও</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 390;
    let L = X.fit(c, hf), rate = 2.5, zoom = false;
    const cAt = y => y <= 2024.9 ? kAnn(y) + 3.1 * Math.cos(2 * Math.PI * ((y % 1) - 0.37)) : Math.max(280, kAnn(2024.5) + rate * (y - 2024.5));
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W); const C2100 = cAt(2100), dT = 0.8 * 5.35 * Math.log(C2100 / 280);
      const gx0 = 52, gy0 = 14, gw = wd ? W * 0.66 - gx0 : W - 66, gh = wd ? H - 56 : H * 0.55 - 30;
      const xmin = zoom ? 2019 : 1955, xmax = zoom ? 2025 : 2100, ymin = zoom ? 405 : 260, ymax = zoom ? 430 : Math.max(500, Math.ceil(C2100 / 50) * 50);
      const Pl = cplot(g, { x0: gx0, y0: gy0, w: gw, h: gh, xmin, xmax, ymin, ymax, col, xt: zoom ? [2019, 2021, 2023, 2025] : wd ? [1960, 1980, 2000, 2020, 2040, 2060, 2080, 2100] : [1960, 2000, 2040, 2080], yt: zoom ? [405, 410, 415, 420, 425, 430] : Array.from({ length: 6 }, (_, i) => Math.round(ymin + (ymax - ymin) * i / 5)), xl: 'বছর', yl: 'CO₂ (ppm)', fx: v => bn(String(v).slice(zoom ? 0 : 0)) });
      if (!zoom) { path(g, [[Pl.X(xmin), Pl.Y(280)], [Pl.X(xmax), Pl.Y(280)]], col.mu, 1, [4, 3]); }
      const pts = []; for (let y = Math.max(1959, xmin); y <= 2024.9; y += zoom ? 0.01 : 0.04) pts.push([Pl.X(y), Pl.Y(cAt(y))]); path(g, pts, col.fg, zoom ? 2 : 1.4);
      if (!zoom) { const pp = []; for (let y = 2024.5; y <= 2100; y += 0.5) pp.push([Pl.X(y), Pl.Y(Math.min(ymax, cAt(y)))]); path(g, pp, '#d06a1e', 2.4, [6, 4]); ball(g, Pl.X(2100), Pl.Y(Math.min(ymax, C2100)), 5, '#d06a1e', '#ffd2a8');
        [[2 * 280, '২ × প্রাক-শিল্প']].forEach(([v, lb]) => { if (v < ymax) { path(g, [[Pl.X(xmin), Pl.Y(v)], [Pl.X(xmax), Pl.Y(v)]], '#c0392b', 1, [2, 3]); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText(lb, Pl.X(1960), Pl.Y(v) - 3); } });
        g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('প্রাক-শিল্প ২৮০ ppm', Pl.X(1960), Pl.Y(280) - 3); }
      else { g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('প্রতি বছর মে মাসে চূড়া, অক্টোবরে খাদ', Pl.X(2019.2), Pl.Y(428)); }
      // ΔT bar
      const bx = wd ? W * 0.74 : 70, by = wd ? 30 : gy0 + gh + 64, bw = wd ? 40 : W - 100, bh = wd ? H - 80 : 26;
      const tMax = 5, f = v => Math.min(1, Math.max(0, v / tMax));
      if (wd) { const tg = g.createLinearGradient(0, by + bh, 0, by); tg.addColorStop(0, '#2d6fd6'); tg.addColorStop(0.3, '#e0c020'); tg.addColorStop(0.6, '#d0402b'); tg.addColorStop(1, '#7e2a8e'); g.fillStyle = tg; g.globalAlpha = 0.25; g.fillRect(bx, by, bw, bh); g.globalAlpha = 1; g.fillStyle = tg; g.fillRect(bx, by + bh * (1 - f(dT)), bw, bh * f(dT)); g.strokeStyle = col.fg; g.strokeRect(bx, by, bw, bh);
        [[1.5, '১.৫ °C'], [2, '২ °C'], [3, '৩ °C'], [4, '৪ °C']].forEach(([v, lb]) => { const y = by + bh * (1 - f(v)); g.strokeStyle = col.fg; g.setLineDash(v <= 2 ? [4, 2] : []); g.beginPath(); g.moveTo(bx - 4, y); g.lineTo(bx + bw + 4, y); g.stroke(); g.setLineDash([]); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(lb, bx + bw + 7, y + 3); });
        g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText('২১০০ সালে ΔT', bx + bw / 2, by - 10); g.fillText(`${bn(dT.toFixed(1))} °C`, bx + bw / 2, by + bh + 16); }
      else { const tg = g.createLinearGradient(bx, 0, bx + bw, 0); tg.addColorStop(0, '#2d6fd6'); tg.addColorStop(0.3, '#e0c020'); tg.addColorStop(0.6, '#d0402b'); tg.addColorStop(1, '#7e2a8e'); g.fillStyle = tg; g.globalAlpha = 0.25; g.fillRect(bx, by, bw, bh); g.globalAlpha = 1; g.fillStyle = tg; g.fillRect(bx, by, bw * f(dT), bh); g.strokeStyle = col.fg; g.strokeRect(bx, by, bw, bh);
        [[1.5, '১.৫'], [2, '২'], [3, '৩'], [4, '৪']].forEach(([v, lb]) => { const x = bx + bw * f(v); g.strokeStyle = col.fg; g.beginPath(); g.moveTo(x, by - 3); g.lineTo(x, by + bh + 3); g.stroke(); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(lb + '°', x, by + bh + 14); });
        g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`২১০০ সালে সাম্য ΔT ≈ ${bn(dT.toFixed(1))} °C`, bx, by - 8); }
    };
    const info = () => { q('[data-rv]').textContent = bn(rate.toFixed(1)); const C2 = cAt(2100), dF = 5.35 * Math.log(C2 / 280), dT = 0.8 * dF;
      out.innerHTML = TXB(`\\begin{aligned}C_{2100} &= ${C2.toFixed(0)}\\ \\mathrm{ppm}\\\\ \\Delta F &= 5.35\\ln\\frac{${C2.toFixed(0)}}{280} = ${dF.toFixed(2)}\\ \\mathrm{W\\,m^{-2}}\\\\ \\Delta T &\\approx 0.8\\times${dF.toFixed(2)} = ${dT.toFixed(1)}\\ \\mathrm{K}\\end{aligned}`) + `<div class="small">${dT <= 1.5 ? 'প্যারিস চুক্তির ১.৫ °C লক্ষ্যের মধ্যে — এর জন্য নির্গমন দ্রুত শূন্যে নামাতে হবে।' : dT <= 2 ? '১.৫ °C ছাড়িয়েছে কিন্তু ২ °C এর মধ্যে।' : dT <= 3 ? '২ °C ছাড়িয়ে গেছে — বাংলাদেশের উপকূলে মারাত্মক প্লাবন ও লবণাক্ততার ঝুঁকি।' : 'চরম উষ্ণতা — বহু ব-দ্বীপ অঞ্চল বসবাসের অযোগ্য হওয়ার আশঙ্কা।'} (সরল মডেল: কেবল CO₂, সাম্যাবস্থা; বাস্তবে বিলম্ব ও অন্য গ্যাসের প্রভাব আছে।)</div>`; };
    q('[data-r]').oninput = e => { rate = +e.target.value; info(); draw(); };
    q('[data-zoom]').onchange = e => { zoom = e.target.checked; draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};

/* ======================= কার্বন ফুটপ্রিন্ট ক্যালকুলেটর (স্টয়কিওমেট্রি) ======================= */
const FUEL = [
  ['gas', 'প্রাকৃতিক গ্যাস (রান্না)', 'm³ / মাস', 20, 0, 100, 1, '\\ce{CH4 + 2O2 -> CO2 + 2H2O}', v => v * 1000 / 22.4 * 44 / 1000, v => `n = \\dfrac{${v}\\times1000}{22.4} = ${(v * 1000 / 22.4).toFixed(0)}\\ \\mathrm{mol} \\Rightarrow m_{\\ce{CO2}} = n\\times44`, '#2d6fd6'],
  ['pet', 'পেট্রোল (মোটরসাইকেল/গাড়ি)', 'L / মাস', 30, 0, 200, 1, '\\ce{2C8H18 + 25O2 -> 16CO2 + 18H2O}', v => v * 0.74 * 8 * 44 / 114, v => `n = \\dfrac{${v}\\times740}{114} = ${(v * 740 / 114).toFixed(0)}\\ \\mathrm{mol} \\Rightarrow m_{\\ce{CO2}} = 8n\\times44`, '#d06a1e'],
  ['lpg', 'LPG সিলিন্ডার', 'kg / মাস', 12, 0, 50, 1, '\\ce{C3H8 + 5O2 -> 3CO2 + 4H2O}', v => v * (0.3 * 3 * 44 / 44 + 0.7 * 4 * 44 / 58), v => `\\text{প্রোপেন ৩০\\%: } \\times\\dfrac{3\\times44}{44};\\ \\text{বিউটেন ৭০\\%: } \\times\\dfrac{4\\times44}{58}`, '#c0392b'],
  ['elec', 'বিদ্যুৎ (গ্রিড)', 'kWh / মাস', 100, 0, 600, 5, '\\text{গ্যাস কেন্দ্র, দক্ষতা ৪০\\%}', v => v * 3600 / 0.4 / 890 * 44 / 1000, v => `n_{\\ce{CH4}} = \\dfrac{${v}\\times3600}{0.40\\times890} = ${(v * 3600 / 0.4 / 890).toFixed(0)}\\ \\mathrm{mol}`, '#e0a020'],
  ['coal', 'কয়লা/কাঠকয়লা', 'kg / মাস', 0, 0, 100, 1, '\\ce{C + O2 -> CO2}\\ (80\\%\\ \\ce{C})', v => v * 0.8 * 44 / 12, v => `m_{\\ce{C}} = 0.8\\times${v}\\ \\mathrm{kg} \\Rightarrow \\times\\dfrac{44}{12}`, '#555']
];
V.p2c1_footprint = {
  t: 'পরিবারের কার্বন ফুটপ্রিন্ট ক্যালকুলেটর: জ্বালানি দহনের স্টয়কিওমেট্রি থেকে মাসিক ও বার্ষিক CO₂', k: ['int', 'calc', '2d'],
  cap: 'একটি পরিবারের মাসিক জ্বালানি ব্যবহার স্লাইডারে দাও। প্রতিটি জ্বালানির সমতাকৃত দহন সমীকরণ থেকে CO₂ এর ভর হিসাব হয় (কোনো সারিতে ক্লিক করলে তার বিস্তারিত হিসাব নিচে আসে)। ডানে রঙিন স্তম্ভে উৎস অনুযায়ী মাসিক CO₂, আর নীল গোলকে বছরের সমস্ত CO₂ এর STP আয়তন — একটি ফুটবল মাঠের তুলনায়। শেষে দেখাও কতগুলো গাছ (প্রতিটি বছরে ~২২ kg CO₂ শোষণ) এই নির্গমন শুষে নিতে পারবে।',
  html: () => `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:4px 12px;margin:0 0 6px">${FUEL.map(f => `<label class="small" data-row="${f[0]}" style="cursor:pointer">${f[1]} = <b data-v="${f[0]}"></b> ${f[2]}<input type="range" min="${f[4]}" max="${f[5]}" step="${f[6]}" value="${f[3]}" data-r="${f[0]}"></label>`).join('')}</div>${X.cv('কার্বন ফুটপ্রিন্ট')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 250 : 380;
    let L = X.fit(c, hf), sel = 'pet'; const U = {}; FUEL.forEach(f => { U[f[0]] = f[3]; });
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const kg = FUEL.map(f => f[8](U[f[0]])), tot = kg.reduce((a, b) => a + b, 0), yr = tot * 12;
      // stacked bar
      const bx = 60, by = 16, bw = wd ? W * 0.5 : W - 80, bh = wd ? H - 60 : 150, sc = v => bh * v / Math.max(300, Math.ceil(tot / 100) * 100);
      let y = by + bh; FUEL.forEach((f, i) => { const h = sc(kg[i]); g.fillStyle = f[10]; g.globalAlpha = f[0] === sel ? 1 : 0.75; g.fillRect(bx, y - h, bw * 0.35, h); g.globalAlpha = 1; if (h > 13) { g.fillStyle = '#fff'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(kg[i].toFixed(0)), bx + bw * 0.175, y - h / 2 + 3); } y -= h; });
      g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(bx, by - 4); g.lineTo(bx, by + bh); g.lineTo(bx + bw * 0.5, by + bh); g.stroke();
      const ymx = Math.max(300, Math.ceil(tot / 100) * 100); [0, 0.5, 1].forEach(fr => { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText(bn(Math.round(ymx * fr)), bx - 4, by + bh - bh * fr + 3); });
      g.save(); g.translate(16, by + bh / 2); g.rotate(-Math.PI / 2); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('মাসিক CO₂ (kg)', 0, 0); g.restore();
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.textAlign = 'center'; g.fillText(`মোট ${bn(tot.toFixed(0))} kg/মাস`, bx + bw * 0.175, by + bh - sc(tot) - 6);
      FUEL.forEach((f, i) => { const ly = by + 10 + i * 15; g.fillStyle = f[10]; g.fillRect(bx + bw * 0.4, ly + (wd ? 14 : 14), 9, 9); g.fillStyle = col.fg; g.font = `${f[0] === sel ? 'bold ' : ''}9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(f[1].split(' (')[0], bx + bw * 0.4 + 13, ly + 22); });
      // sphere of yearly CO2
      const vol = yr / 44 * 22.4; const sx = wd ? W * 0.8 : W / 2, sy = wd ? H * 0.45 : by + bh + 100, rmax = wd ? Math.min(W * 0.16, H * 0.38) : 70; const rad = rmax * Math.cbrt(Math.min(1, vol / 8000)) ;
      const sg = g.createRadialGradient(sx - rad * 0.35, sy - rad * 0.35, rad * 0.1, sx, sy, rad); sg.addColorStop(0, 'rgba(190,220,255,.95)'); sg.addColorStop(1, 'rgba(45,111,214,.75)'); g.fillStyle = sg; g.beginPath(); g.arc(sx, sy, Math.max(4, rad), 0, 7); g.fill();
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(`বছরে ${bn((yr / 1000).toFixed(2))} টন CO₂`, sx, sy + rmax + 16); g.font = `9.5px ${col.font}`; g.fillText(`STP তে ${bn(Math.round(vol))} m³ (ব্যাস ${bn((2 * Math.cbrt(3 * vol / (4 * Math.PI))).toFixed(1))} m গোলক)`, sx, sy + rmax + 30);
    };
    const info = () => { FUEL.forEach(f => { el.querySelector(`[data-v="${f[0]}"]`).textContent = bn(U[f[0]]); el.querySelector(`[data-row="${f[0]}"]`).style.fontWeight = f[0] === sel ? '700' : ''; });
      const f = FUEL.find(x => x[0] === sel), v = U[sel], m = f[8](v), tot = FUEL.reduce((a, x) => a + x[8](U[x[0]]), 0), yr = tot * 12;
      out.innerHTML = `<div class="small"><b>${f[1]}</b>: ${bn(v)} ${f[2]}</div>` + TXB(f[7]) + TXB(f[9](v)) + TXB(`m_{\\ce{CO2}} = ${m.toFixed(1)}\\ \\mathrm{kg}`) + `<div class="small">বার্ষিক মোট ${bn((yr / 1000).toFixed(2))} টন CO₂ — শোষণে প্রায় <b>${bn(Math.round(yr / 22))}টি</b> পূর্ণবয়স্ক গাছ লাগবে। (বাংলাদেশে মাথাপিছু বার্ষিক নির্গমন ~০.৭ টন, বৈশ্বিক গড় ~৪.৭ টন।)</div>`; };
    el.querySelectorAll('[data-r]').forEach(r => { r.oninput = e => { U[e.target.dataset.r] = +e.target.value; sel = e.target.dataset.r; info(); draw(); }; });
    el.querySelectorAll('[data-row]').forEach(r => { r.addEventListener('click', () => { sel = r.dataset.row; info(); draw(); }); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => un();
  }
};
})();
