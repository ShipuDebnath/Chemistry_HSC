/* ২য় পত্র অধ্যায় ১ visuals part 6 — ideal vs real gases, Amagat, Z, Boyle temperature, van der Waals (1.6–1.7.3) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, path = C4.path, cplot = C4.cplot, fx = P2.fx, wide = P2.wide, legend = P2.legend;
const R = 0.0821;
/* [key, name, a (atm L² mol⁻²), b (L mol⁻¹), colour] */
const VG = [['He', 'He', 0.034, 0.0237, '#d69a1e'], ['H2', 'H₂', 0.244, 0.0266, '#8a8f98'], ['N2', 'N₂', 1.39, 0.0391, '#2d6fd6'], ['O2', 'O₂', 1.36, 0.0318, '#c0392b'], ['CH4', 'CH₄', 2.25, 0.0428, '#2f9e44'], ['CO2', 'CO₂', 3.59, 0.0427, '#3a3a3a'], ['NH3', 'NH₃', 4.17, 0.0371, '#7b3fa0']];
const gOf = k => VG.find(g => g[0] === k);
const Pvdw = (Vm, T, a, b) => R * T / (Vm - b) - a / (Vm * Vm);
/* gas-branch molar volume at (P, T) — largest real root via Newton from the ideal value */
function Vm(P, T, a, b) { let v = R * T / P + b; for (let i = 0; i < 60; i++) { const f = P * v * v * v - (P * b + R * T) * v * v + a * v - a * b, d = 3 * P * v * v - 2 * (P * b + R * T) * v + a; const nv = v - f / d; if (!isFinite(nv) || nv <= b) { v = (v + b) / 2 + 1e-6; continue; } if (Math.abs(nv - v) < 1e-10) { v = nv; break; } v = nv; } return v; }
const Zof = (P, T, a, b) => P * Vm(P, T, a, b) / (R * T);
const Tc = (a, b) => 8 * a / (27 * R * b), TB = (a, b) => a / (R * b);
const gasSel = (on, attr) => `<select class="inp" ${attr} style="width:auto;display:inline-block;margin:0">${VG.map(g => `<option value="${g[0]}" ${g[0] === on ? 'selected' : ''}>${g[1]}</option>`).join('')}</select>`;

/* ======================= ১.৬ আদর্শ বনাম বাস্তব: কণা-চিত্র ======================= */
V.p2c1_idealReal = {
  t: 'আদর্শ বনাম বাস্তব গ্যাস: বিন্দুকণা বনাম আয়তন ও আকর্ষণযুক্ত অণু (সংকোচনে পার্থক্য)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে আদর্শ গ্যাস — অণুগুলো আয়তনহীন বিন্দু, একে অপরকে টানে না। ডানে বাস্তব গ্যাস — অণুর নিজস্ব আকার আছে (চারপাশের হালকা বলয় = বর্জিত আয়তন) এবং কাছাকাছি অণুর মধ্যে আকর্ষণ (সরু রেখা)। পিস্টন স্লাইডারে দুটি পাত্রকে একই আয়তনে সংকুচিত করো: বাস্তব পাত্রে মুক্ত জায়গা দ্রুত ফুরায়; দেয়ালের পাশের অণু পেছনের দিকে টান খায় (তীর)। নিচে বেছে নেওয়া গ্যাসের জন্য ভ্যানডার ওয়ালস হিসাবে Z।',
  html: () => `${X.cv('আদর্শ বনাম বাস্তব গ্যাস')}<div class="ctl"><label class="small" style="flex:1;min-width:150px">আয়তন (সংকোচন) <b data-vv></b>%<input type="range" min="20" max="100" step="2" value="100" data-v></label><span class="small">গ্যাস ${gasSel('CO2', 'data-g')}</span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 280 : 560;
    let L = X.fit(c, hf), vf = 1, gk = 'CO2';
    const Rn = X.rng(3), N = 26; const mk = () => Array.from({ length: N }, () => ({ x: Rn(), y: Rn(), vx: Rn() - .5, vy: Rn() - .5 }));
    const A0 = mk(), B0 = mk(); const rr = 0.035;
    const step = (P, dt, real) => { P.forEach(p => { p.x += p.vx * dt * .5; p.y += p.vy * dt * .5; if (p.x < .03 || p.x > .97) { p.vx *= -1; p.x = Math.max(.03, Math.min(.97, p.x)); } if (p.y < .03 || p.y > .97) { p.vy *= -1; p.y = Math.max(.03, Math.min(.97, p.y)); } });
      if (real) for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) { const a = P[i], b = P[j], dx = (b.x - a.x), dy = (b.y - a.y) * vf, d = Math.hypot(dx, dy); if (d < 2 * rr && d > 1e-6) { const nx = dx / d, ny = dy / d, rv = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny; if (rv > 0) { a.vx -= rv * nx; a.vy -= rv * ny; b.vx += rv * nx; b.vy += rv * ny; } } else if (d < 5 * rr) { const f = 0.02 * dt; a.vx += dx * f; a.vy += dy * f; b.vx -= dx * f; b.vy -= dy * f; } } };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const s = wd ? Math.min((W - 60) / 2, H - 50) : Math.min(W - 40, (H - 90) / 2), boxes = wd ? [[20, 28], [40 + s, 28]] : [[20, 26], [20, 56 + s]];
      [[A0, 'আদর্শ গ্যাস', false], [B0, 'বাস্তব গ্যাস', true]].forEach(([P, nm, real], k) => {
        const [bx, by] = boxes[k], hh = s * vf;
        g.fillStyle = 'rgba(150,200,240,.10)'; g.fillRect(bx, by + s - hh, s, hh); g.strokeStyle = col.fg; g.lineWidth = 1.8; g.strokeRect(bx, by, s, s);
        g.fillStyle = '#8a9099'; g.fillRect(bx - 4, by + s - hh - 8, s + 8, 8);
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, bx + s / 2, by - 8);
        const pos = p => [bx + p.x * s, by + s - hh + p.y * hh];
        if (real) { for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) { const [x1, y1] = pos(P[i]), [x2, y2] = pos(P[j]), d = Math.hypot(x2 - x1, y2 - y1); if (d < 5 * rr * s && d > 2 * rr * s) { g.strokeStyle = `rgba(123,63,160,${0.5 * (1 - d / (5 * rr * s))})`; g.lineWidth = 1; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); } }
          P.forEach(p => { const [x, y] = pos(p); g.fillStyle = 'rgba(192,57,43,.10)'; g.beginPath(); g.arc(x, y, 2 * rr * s, 0, 7); g.fill(); ball(g, x, y, rr * s, '#c0392b', '#ffb3a8'); if (p.x > .9) { g.strokeStyle = '#7b3fa0'; g.fillStyle = '#7b3fa0'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x, y); g.lineTo(x - 14, y); g.stroke(); g.beginPath(); g.moveTo(x - 14, y); g.lineTo(x - 9, y - 3); g.lineTo(x - 9, y + 3); g.fill(); } }); }
        else P.forEach(p => { const [x, y] = pos(p); ball(g, x, y, 2.4, '#2d6fd6', '#a9c8ff'); });
        const occ = real ? Math.min(0.95, N * Math.PI * (2 * rr) ** 2 / 4 / vf) : 0;
        g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.fillText(real ? `অণুর দখল ≈ ${bn(Math.round(occ * 100))}% · মুক্ত ${bn(Math.round((1 - occ) * 100))}%` : 'অণুর দখল ০% · মুক্ত ১০০%', bx + s / 2, by + s + 14);
      });
    };
    const info = () => { q('[data-vv]').textContent = bn(Math.round(vf * 100)); const G = gOf(gk); const Vl = Math.max(G[3] * 1.3, vf * 1.0); const Pi = R * 300 / Vl, Pv = Pvdw(Vl, 300, G[2], G[3]);
      out.innerHTML = TXB(`1\\ \\mathrm{mol}\\ \\ce{${G[0]}},\\ 300\\ \\mathrm{K},\\ V = ${Vl.toFixed(2)}\\ \\mathrm{L}`) + TXB(`P_{\\text{আদর্শ}} = ${Pi.toFixed(1)},\\ P_{\\text{vdW}} = ${Pv.toFixed(1)}\\ \\mathrm{atm}`) + TXB(`Z = \\dfrac{P_{\\text{vdW}}}{P_{\\text{আদর্শ}}} = ${(Pv / Pi).toFixed(3)}`) + `<div class="small">${Pv / Pi < 0.98 ? 'Z < ১ — আকর্ষণ প্রাধান্য পাচ্ছে।' : Pv / Pi > 1.02 ? 'Z > ১ — অণুর নিজস্ব আয়তন প্রাধান্য পাচ্ছে।' : 'Z ≈ ১ — প্রায় আদর্শ আচরণ।'} আয়তন যত কমাবে, বিচ্যুতি তত বাড়বে।</div>`; };
    const A = X.anim(el, dt => { if (dt) { step(A0, dt, false); step(B0, dt, true); } draw(); }, { paused: false });
    q('[data-v]').oninput = e => { vf = +e.target.value / 100; info(); A.draw(); };
    q('[data-g]').onchange = e => { gk = e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ১.৭ অ্যামাগার PV–P লেখচিত্র ======================= */
const AM = { gases: [['H2', 273], ['He', 273], ['N2', 273], ['CH4', 273], ['CO2', 313]], n2: [['N2', 150], ['N2', 200], ['N2', 273], ['N2', 433], ['N2', 673]], co2: [['CO2', 313], ['CO2', 373], ['CO2', 473], ['CO2', 673], ['CO2', 1024]] };
V.p2c1_amagat = {
  t: 'অ্যামাগার পরীক্ষা: বিভিন্ন গ্যাসের PV বনাম P লেখচিত্র (আদর্শ রেখা থেকে বিচ্যুতি ও খাঁজ)', k: ['int', '2d', 'calc', 'info'],
  cap: 'উল্লম্ব অক্ষে PV কে আদর্শ মান (RT) দিয়ে ভাগ করা হয়েছে (= Z), অনুভূমিক অক্ষে চাপ ০–১০০০ atm। কাটা অনুভূমিক রেখা = আদর্শ গ্যাস (বয়েলের সূত্র)। "বিভিন্ন গ্যাস" দৃশ্যে ০ °C এ H₂ ও He শুরু থেকেই উপরে ওঠে, N₂ ও CH₄ এ অগভীর খাঁজ, CO₂ (৪০ °C) এ গভীর খাঁজ। "N₂ / CO₂ বিভিন্ন তাপমাত্রায়" দৃশ্যে দেখো — তাপমাত্রা বাড়ালে খাঁজ অগভীর হয়ে বয়েল তাপমাত্রার উপরে মিলিয়ে যায়। চাপ স্লাইডারে লাল রেখা বরাবর প্রতিটি রেখার মান পড়ো (ভ্যানডার ওয়ালস সমীকরণে গণনা)। বামের ছোট চিত্রে অ্যামাগার খনি-সুড়ঙ্গের লম্বা পারদ স্তম্ভের নকশা।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('am', [['gases', 'বিভিন্ন গ্যাস'], ['n2', 'N₂ বিভিন্ন T'], ['co2', 'CO₂ বিভিন্ন T']], 'gases')}</div>${X.cv('অ্যামাগার লেখচিত্র')}<label class="small" style="display:block;margin-top:6px">চাপ P = <b data-pv></b> atm<input type="range" min="1" max="1000" step="1" value="200" data-p></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 440;
    let L = X.fit(c, hf), md = 'gases', P = 200;
    const cols = ['#2d6fd6', '#2f9e44', '#d06a1e', '#7b3fa0', '#c0392b'];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      let gx0 = 56;
      if (wd) { // schematic
        const sx = 24, top = 24, bot = H - 40; g.fillStyle = 'rgba(120,100,80,.15)'; g.fillRect(sx - 14, top, 50, bot - top); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(sx, top + 10, 10, bot - top - 30);
        const hg = g.createLinearGradient(sx, 0, sx + 10, 0); hg.addColorStop(0, '#8c939c'); hg.addColorStop(.5, '#e4e8ee'); hg.addColorStop(1, '#7c838c'); g.fillStyle = hg; g.fillRect(sx + 1, top + 40, 8, bot - top - 60);
        g.fillStyle = 'rgba(150,200,240,.5)'; g.fillRect(sx + 1, bot - 26, 8, 6); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.save(); g.translate(sx + 26, (top + bot) / 2); g.rotate(-Math.PI / 2); g.fillText('৪০০ m খনি-সুড়ঙ্গে পারদ স্তম্ভ', 0, 0); g.restore(); g.fillText('গ্যাস', sx + 5, bot - 6); gx0 = 118;
      }
      const gw = W - gx0 - 18, gh = H - 64, y0 = 24, ymax = 2.4, ymin = 0.2;
      const Pl = cplot(g, { x0: gx0, y0, w: gw, h: gh, xmax: 1000, ymin, ymax, col, xt: [0, 200, 400, 600, 800, 1000], yt: [0.2, 0.6, 1, 1.4, 1.8, 2.2], fy: v => bn(v.toFixed(1)), xl: 'P (atm)', yl: 'PV/RT (= Z)', ylx: 38 });
      path(g, [[Pl.X(0), Pl.Y(1)], [Pl.X(1000), Pl.Y(1)]], col.mu, 1.4, [6, 4]); g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'right'; g.fillText('আদর্শ গ্যাস', Pl.X(990), Pl.Y(1) - 5);
      const set = AM[md];
      set.forEach(([k, T], i) => { const G = gOf(k), pts = []; for (let p = 1; p <= 1000; p += 5) { const z = Zof(p, T, G[2], G[3]); if (z >= ymin && z <= ymax) pts.push([Pl.X(p), Pl.Y(z)]); } path(g, pts, md === 'gases' ? G[4] : cols[i], 2.4); });
      g.strokeStyle = '#c0392b'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(Pl.X(P), y0); g.lineTo(Pl.X(P), y0 + gh); g.stroke();
      set.forEach(([k, T], i) => { const G = gOf(k), z = Zof(P, T, G[2], G[3]); if (z >= ymin && z <= ymax) ball(g, Pl.X(P), Pl.Y(z), 4.5, md === 'gases' ? G[4] : cols[i], '#fff'); });
      legend(g, col, gx0 + 8, y0 + 2, set.map(([k, T], i) => [md === 'gases' ? gOf(k)[4] : cols[i], `${gOf(k)[1]}, ${bn(T)} K${T === 433 || T === 1024 ? ' (vdW T_B)' : ''}`]));
    };
    const info = () => { q('[data-pv]').textContent = bn(P); const set = AM[md];
      out.innerHTML = `<div class="table-wrap"><table class="t"><thead><tr><th>গ্যাস, T</th><th>Z (P = ${bn(P)} atm)</th><th>প্রাধান্য</th></tr></thead><tbody>${set.map(([k, T]) => { const G = gOf(k), z = Zof(P, T, G[2], G[3]); return `<tr><td>${G[1]}, ${bn(T)} K</td><td>${fx(z, 3)}</td><td>${z < 0.99 ? 'আকর্ষণ' : z > 1.01 ? 'আয়তন' : 'প্রায় আদর্শ'}</td></tr>`; }).join('')}</tbody></table></div><div class="small">${md === 'gases' ? 'H₂ ও He এর আকর্ষণ দুর্বল (ছোট a) — ০ °C তাদের বয়েল তাপমাত্রার অনেক উপরে, তাই খাঁজ নেই।' : 'তাপমাত্রা বাড়ার সাথে খাঁজ অগভীর হয়; বয়েল তাপমাত্রায় নিম্ন চাপের অংশ প্রায় অনুভূমিক।'} মান ভ্যানডার ওয়ালস সমীকরণে গণনা — গুণগত ধারা পরীক্ষার সাথে মেলে, সংখ্যায় সামান্য ভিন্নতা থাকে।</div>`; };
    X.onSeg(el, 'am', k => { md = k; info(); draw(); });
    q('[data-p]').oninput = e => { P = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ১.৭.১ Z বনাম P ======================= */
V.p2c1_zfactor = {
  t: 'সংকোচনশীলতা গুণাঙ্ক Z = PV/nRT: যেকোনো গ্যাস, তাপমাত্রা ও চাপে বাস্তব বনাম আদর্শ আয়তন', k: ['int', '2d', 'calc'],
  cap: 'একটি গ্যাস ও তাপমাত্রা বেছে নাও — লেখচিত্রে Z বনাম P (০–৮০০ atm)। নীল ছায়া Z < ১ অঞ্চল (আকর্ষণ প্রাধান্য, গ্যাস আদর্শের চেয়ে সহজে সংকুচিত হয়), কমলা ছায়া Z > ১ (আয়তন প্রাধান্য)। চাপ স্লাইডারের বিন্দুতে ১ মোলের বাস্তব ও আদর্শ আয়তন পাশাপাশি দুটি সিলিন্ডারে আঁকা। তাপমাত্রা বয়েল তাপমাত্রার (T_B) উপরে নিলে খাঁজ মিলিয়ে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><span class="small">গ্যাস ${gasSel('CH4', 'data-g')}</span></div>${X.cv('Z বনাম P')}<div class="ctl"><label class="small" style="flex:1;min-width:140px">T = <b data-tv></b> K<input type="range" min="0" max="100" step="1" value="10" data-t></label><label class="small" style="flex:1;min-width:140px">P = <b data-pv></b> atm<input type="range" min="1" max="800" step="1" value="100" data-p></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 480;
    let L = X.fit(c, hf), gk = 'CH4', tu = 10, P = 100;
    const Tof = () => { const G = gOf(gk), lo = Math.max(150, Tc(G[2], G[3]) * 1.08), hi = Math.max(lo + 200, 1500); return Math.round(lo + (hi - lo) * tu / 100); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), G = gOf(gk), T = Tof();
      const gx0 = 56, gw = wd ? W * 0.68 - gx0 : W - 76, y0 = 22, gh = wd ? H - 64 : H - 170, ymin = 0.2, ymax = 2.2;
      const Pl = cplot(g, { x0: gx0, y0, w: gw, h: gh, xmax: 800, ymin, ymax, col, xt: [0, 200, 400, 600, 800], yt: [0.2, 0.6, 1, 1.4, 1.8, 2.2], fy: v => bn(v.toFixed(1)), xl: 'P (atm)', yl: 'Z', ylx: 30 });
      g.fillStyle = 'rgba(45,111,214,.08)'; g.fillRect(gx0, Pl.Y(1), gw, Pl.Y(ymin) - Pl.Y(1)); g.fillStyle = 'rgba(208,106,30,.08)'; g.fillRect(gx0, y0, gw, Pl.Y(1) - y0);
      g.fillStyle = '#2d6fd6'; g.font = `10px ${col.font}`; g.textAlign = 'right'; g.fillText('Z < ১: আকর্ষণ প্রাধান্য', gx0 + gw - 4, Pl.Y(ymin) - 6); g.fillStyle = '#d06a1e'; g.fillText('Z > ১: আয়তন প্রাধান্য', gx0 + gw - 4, y0 + 12);
      path(g, [[Pl.X(0), Pl.Y(1)], [Pl.X(800), Pl.Y(1)]], col.mu, 1.3, [6, 4]);
      const pts = []; for (let p = 1; p <= 800; p += 4) { const z = Zof(p, T, G[2], G[3]); if (z >= ymin && z <= ymax) pts.push([Pl.X(p), Pl.Y(z)]); } path(g, pts, G[4], 2.8);
      const z = Zof(P, T, G[2], G[3]); ball(g, Pl.X(P), Pl.Y(Math.max(ymin, Math.min(ymax, z))), 6, '#c0392b', '#ffb3a8');
      // cylinders
      const vR = z * R * T / P, vI = R * T / P, mx = Math.max(vR, vI);
      const cx = wd ? W * 0.74 : 70, cy = wd ? 40 : y0 + gh + 50, ch = wd ? H - 100 : 80, cw = 34;
      [[vI, 'আদর্শ', col.mu], [vR, 'বাস্তব', G[4]]].forEach(([v, nm, cl], i) => { const x = cx + i * (cw + 30), hh = v / mx * ch; g.strokeStyle = col.fg; g.lineWidth = 1.4; g.strokeRect(x, cy, cw, ch); g.fillStyle = cl; g.globalAlpha = .55; g.fillRect(x + 1, cy + ch - hh, cw - 2, hh); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + cw / 2, cy + ch + 14); g.font = `9.5px ${col.font}`; g.fillText(`${fx(v * 1000, 0)} mL`, x + cw / 2, cy + ch + 27); });
    };
    const info = () => { const G = gOf(gk), T = Tof(), z = Zof(P, T, G[2], G[3]); q('[data-tv]').textContent = bn(T); q('[data-pv]').textContent = bn(P);
      out.innerHTML = TXB(`Z = \\dfrac{PV_m}{RT} = \\dfrac{${P}\\times${(z * R * T / P).toFixed(4)}}{0.0821\\times${T}} = ${z.toFixed(3)}`) + `<div class="small">${G[1]}: T_B (vdW) = ${bn(Math.round(TB(G[2], G[3])))} K, T_c = ${bn(Math.round(Tc(G[2], G[3])))} K। এখন T ${T < TB(G[2], G[3]) ? 'বয়েল তাপমাত্রার নিচে — নিম্ন চাপে খাঁজ (Z < ১)।' : 'বয়েল তাপমাত্রার উপরে — সব চাপে Z > ১।'} বাস্তব আয়তন আদর্শের ${p2pct(z)}।</div>`; };
    const p2pct = z => (z >= 1 ? bn(((z - 1) * 100).toFixed(2)) + '% বেশি' : bn(((1 - z) * 100).toFixed(2)) + '% কম');
    q('[data-g]').onchange = e => { gk = e.target.value; info(); draw(); };
    q('[data-t]').oninput = e => { tu = +e.target.value; info(); draw(); };
    q('[data-p]').oninput = e => { P = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ১.৭.২ বয়েল তাপমাত্রা ======================= */
V.p2c1_boyleTemp = {
  t: 'বয়েল তাপমাত্রা: T < T_B, T = T_B ও T > T_B তে Z–P লেখচিত্র এবং প্রাথমিক ঢাল (b − a/RT)', k: ['int', '2d', 'calc'],
  cap: 'বামে বেছে নেওয়া গ্যাসের তিনটি সমোষ্ণ Z–P রেখা: বয়েল তাপমাত্রার অর্ধেক (নীল, গভীর খাঁজ), ঠিক বয়েল তাপমাত্রায় (সবুজ, নিম্ন-মধ্যম চাপে প্রায় অনুভূমিক — বয়েলের সূত্র মানে) এবং দ্বিগুণে (কমলা, শুরু থেকেই উপরে)। ডানে নিম্ন চাপে Z রেখার ঢাল (b − a/RT) বনাম তাপমাত্রা — যেখানে এটি শূন্য রেখা ছেদ করে সেটিই T_B = a/Rb। তাপমাত্রা স্লাইডারে লাল রেখা ও বিন্দু সরিয়ে দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><span class="small">গ্যাস ${gasSel('N2', 'data-g')}</span></div>${X.cv('বয়েল তাপমাত্রা')}<label class="small" style="display:block;margin-top:6px">T = <b data-tv></b> K<input type="range" min="0" max="100" step="1" value="40" data-t></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 560;
    let L = X.fit(c, hf), gk = 'N2', tu = 40;
    const Tsel = () => { const G = gOf(gk), tb = TB(G[2], G[3]); return Math.round(Math.max(Tc(G[2], G[3]) * 1.05, tb * 0.3) + (tb * 2.5 - Math.max(Tc(G[2], G[3]) * 1.05, tb * 0.3)) * tu / 100); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), G = gOf(gk), tb = TB(G[2], G[3]), T = Tsel();
      const pw = wd ? (W - 40) / 2 : W - 20, ph = wd ? H - 60 : (H - 100) / 2;
      const P1 = cplot(g, { x0: 50, y0: 22, w: pw - 50, h: ph, xmax: 600, ymin: 0.4, ymax: 1.8, col, xt: [0, 200, 400, 600], yt: [0.4, 0.8, 1.2, 1.6], fy: v => bn(v.toFixed(1)), xl: 'P (atm)', yl: 'Z', ylx: 30 });
      path(g, [[P1.X(0), P1.Y(1)], [P1.X(600), P1.Y(1)]], col.mu, 1.2, [5, 4]);
      const fam = [[Math.max(Tc(G[2], G[3]) * 1.05, tb * 0.5), '#2d6fd6', 'T < T_B'], [tb, '#2f9e44', 'T = T_B'], [tb * 2, '#d06a1e', 'T > T_B'], [T, '#c0392b', 'বেছে নেওয়া T']];
      fam.forEach(([t, cl, , ], i) => { const pts = []; for (let p = 1; p <= 600; p += 4) { const z = Zof(p, t, G[2], G[3]); if (z >= .4 && z <= 1.8) pts.push([P1.X(p), P1.Y(z)]); } path(g, pts, cl, i === 3 ? 1.6 : 2.4, i === 3 ? [4, 3] : []); });
      legend(g, col, 50 + pw - 50, 24, fam.map(([t, cl, n]) => [cl, `${n} (${bn(Math.round(t))} K)`]), true);
      const ox = wd ? pw + 40 : 10, oy = wd ? 22 : ph + 80;
      const Tmax = tb * 3, sl = t => G[3] - G[2] / (R * t), smin = sl(Math.max(tb * 0.3, 30)), smax = sl(Tmax);
      const P2_ = cplot(g, { x0: ox + 50, y0: oy, w: pw - 60, h: ph, xmin: 0, xmax: Tmax, ymin: Math.min(smin, -0.01), ymax: Math.max(smax * 1.2, 0.01), col, xt: [0, Math.round(tb), Math.round(Tmax)], yt: [], xl: 'T (K)', yl: 'ঢাল b − a/RT', ylx: 30 });
      path(g, [[P2_.X(0), P2_.Y(0)], [P2_.X(Tmax), P2_.Y(0)]], col.mu, 1.2, [5, 4]);
      const pts = []; for (let t = Math.max(tb * 0.3, 30); t <= Tmax; t += Tmax / 200) pts.push([P2_.X(t), P2_.Y(sl(t))]); path(g, pts, '#7b3fa0', 2.6);
      ball(g, P2_.X(tb), P2_.Y(0), 5.5, '#2f9e44', '#fff'); g.fillStyle = '#2f9e44'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`T_B = ${bn(Math.round(tb))} K`, P2_.X(tb) + 6, P2_.Y(0) - 8);
      ball(g, P2_.X(T), P2_.Y(sl(T)), 5.5, '#c0392b', '#ffb3a8');
    };
    const info = () => { const G = gOf(gk), T = Tsel(), tb = TB(G[2], G[3]), s = G[3] - G[2] / (R * T); q('[data-tv]').textContent = bn(T);
      out.innerHTML = TXB(`T_B = \\dfrac{a}{Rb} = \\dfrac{${G[2]}}{0.0821\\times${G[3]}} = ${tb.toFixed(0)}\\ \\mathrm{K}`) + TXB(`b - \\dfrac{a}{RT} = ${G[3]} - \\dfrac{${G[2]}}{0.0821\\times${T}} = ${s.toFixed(4)}\\ \\mathrm{L\\,mol^{-1}}`) + `<div class="small">${s < 0 ? 'ঢাল ঋণাত্মক — নিম্ন চাপে Z কমে (আকর্ষণ প্রাধান্য)।' : 'ঢাল ধনাত্মক — শুরু থেকেই Z বাড়ে (আয়তন প্রাধান্য)।'} (vdW এর মান পরিমাপকৃত বয়েল তাপমাত্রার চেয়ে কিছুটা বেশি আসে।)</div>`; };
    q('[data-g]').onchange = e => { gk = e.target.value; info(); draw(); };
    q('[data-t]').oninput = e => { tu = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ১.৭.৩ ভ্যানডার ওয়ালস ======================= */
function maxwellPsat(T, a, b) {
  // local extrema of the vdW loop
  let vmin = null, vmax = null, prev = null, prevV = null; for (let v = b * 1.05; v < 2; v *= 1.002) { const p = Pvdw(v, T, a, b); if (prev != null) { const d = p - prev; if (prevV && prevV.d < 0 && d > 0 && vmin == null) vmin = v; if (prevV && prevV.d > 0 && d < 0 && vmin != null && vmax == null) vmax = v; prevV = { d }; } else prevV = { d: 0 }; prev = p; }
  if (vmin == null || vmax == null) return null;
  const pmin = Math.max(Pvdw(vmin, T, a, b), 0.01), pmax = Pvdw(vmax, T, a, b);
  const root = (P, lo, hi) => { for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2, f = Pvdw(m, T, a, b) - P, fl = Pvdw(lo, T, a, b) - P; if ((f > 0) === (fl > 0)) lo = m; else hi = m; } return (lo + hi) / 2; };
  let lo = pmin, hi = pmax, res = null;
  for (let it = 0; it < 60; it++) { const Ps = (lo + hi) / 2, v1 = root(Ps, b * 1.0001, vmin), v3 = root(Ps, vmax, 50); const area = R * T * Math.log((v3 - b) / (v1 - b)) + a * (1 / v3 - 1 / v1) - Ps * (v3 - v1); res = [Ps, v1, v3]; if (area > 0) lo = Ps; else hi = Ps; }
  return res;
}
V.p2c1_vdw = {
  t: 'ভ্যানডার ওয়ালস সমীকরণ: চাপ ও আয়তন সংশোধনের আণবিক চিত্র, CO₂ এর সমোষ্ণ রেখা ও সংকট বিন্দু, এবং বাস্তব চাপ ক্যালকুলেটর', k: ['int', '2d', 'calc', 'anim'],
  cap: '"সংশোধন" দৃশ্যে: বামে বর্জিত আয়তন — দুটি r ব্যাসার্ধের অণুর কেন্দ্র 2r এর কাছে আসতে পারে না (কাটা বৃত্ত = 2r ব্যাসার্ধের বর্জিত গোলক), তাই b = ৪ × অণুর প্রকৃত আয়তন; ডানে পাত্রের ভিতরের অণু চারদিক থেকে সমান টান পায় (নিট শূন্য), কিন্তু দেয়ালের পাশের অণু কেবল ভিতরের দিকে টান খায় — দেয়ালে ধাক্কা দুর্বল, চাপ কম। "সমোষ্ণ রেখা" দৃশ্যে: CO₂ এর vdW সমোষ্ণ রেখা (P–V_m); সংকট তাপমাত্রার (৩০৪ K) নিচে রেখায় ঢেউ (vdW লুপ) — বাস্তবে সেখানে তরল ও বাষ্প সহাবস্থান করে, অনুভূমিক রেখা (ম্যাক্সওয়েলের সমক্ষেত্রফল নিয়মে); সংকট বিন্দু লাল। নিচের স্লাইডারে যেকোনো গ্যাসের বাস্তব চাপ আদর্শের সাথে তুলনা করো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('vm', [['corr', 'সংশোধন'], ['iso', 'সমোষ্ণ রেখা (CO₂)']], 'corr')}</div>${X.cv('ভ্যানডার ওয়ালস')}<div class="ctl"><span class="small">গ্যাস ${gasSel('CO2', 'data-g')}</span><label class="small" style="flex:1;min-width:100px">n = <b data-nv></b> mol<input type="range" min="0.5" max="5" step="0.5" value="1" data-n></label><label class="small" style="flex:1;min-width:100px">V = <b data-vv></b> L<input type="range" min="0" max="100" step="1" value="40" data-v></label><label class="small" style="flex:1;min-width:100px">T = <b data-tv></b> K<input type="range" min="200" max="700" step="5" value="300" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 520;
    let L = X.fit(c, hf), md = 'corr', gk = 'CO2', n = 1, vu = 40, T = 300, t = 0;
    const Vof = () => +(0.1 * Math.pow(100, vu / 100)).toFixed(2);
    const drawCorr = (g, W, H, col) => {
      const wd = wide(W), r = 22;
      const ax = wd ? W * 0.22 : W / 2, ay = wd ? H / 2 : 120;
      g.strokeStyle = '#c0392b'; g.setLineDash([5, 4]); g.lineWidth = 1.5; g.beginPath(); g.arc(ax - r, ay, 2 * r, 0, 7); g.stroke(); g.setLineDash([]);
      g.fillStyle = 'rgba(192,57,43,.08)'; g.beginPath(); g.arc(ax - r, ay, 2 * r, 0, 7); g.fill();
      ball(g, ax - r, ay, r, '#c0392b', '#ffb3a8'); ball(g, ax + r + Math.max(0, Math.sin(t * 2)) * 14, ay, r, '#2d6fd6', '#a9c8ff');
      g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(ax - r, ay); g.lineTo(ax - r, ay - r); g.stroke(); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('r', ax - r + 7, ay - r / 2);
      g.beginPath(); g.moveTo(ax - r, ay + 4); g.lineTo(ax + r, ay + 4); g.stroke(); g.fillText('2r', ax, ay + 16);
      g.font = `bold 11px ${col.font}`; g.fillText('বর্জিত আয়তন', ax - r, ay - 2 * r - 22); g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.fillText('জোড়ায় (4/3)π(2r)³ = ৮ × অণুর আয়তন', ax - r, ay + 2 * r + 18); g.fillText('প্রতি অণুতে ৪ গুণ ⇒ b = 4N_A·(4/3)πr³', ax - r, ay + 2 * r + 32);
      // wall picture
      const bx = wd ? W * 0.5 : 24, by = wd ? 30 : ay + 2 * r + 60, bw = wd ? W * 0.46 : W - 48, bh = wd ? H - 60 : H - by - 20;
      g.fillStyle = 'rgba(150,200,240,.08)'; g.fillRect(bx, by, bw, bh); g.fillStyle = '#8a9099'; g.fillRect(bx + bw - 6, by, 8, bh); g.strokeStyle = col.fg; g.lineWidth = 1.4; g.strokeRect(bx, by, bw, bh);
      const Rn = X.rng(8); const ms = []; for (let i = 0; i < 22; i++) ms.push([bx + 14 + Rn() * (bw - 40), by + 14 + Rn() * (bh - 28)]);
      ms.forEach(([x, y]) => ball(g, x + Math.sin(t * 3 + x) * 1.5, y + Math.cos(t * 3 + y) * 1.5, 6, '#2d6fd6', '#a9c8ff'));
      const ar = (x, y, dx, dy, cl) => { g.strokeStyle = cl; g.fillStyle = cl; g.lineWidth = 1.8; g.beginPath(); g.moveTo(x, y); g.lineTo(x + dx, y + dy); g.stroke(); const an = Math.atan2(dy, dx); g.beginPath(); g.moveTo(x + dx, y + dy); g.lineTo(x + dx - 7 * Math.cos(an - .45), y + dy - 7 * Math.sin(an - .45)); g.lineTo(x + dx - 7 * Math.cos(an + .45), y + dy - 7 * Math.sin(an + .45)); g.fill(); };
      const ix = bx + bw * 0.42, iy = by + bh / 2; ball(g, ix, iy, 8, '#2f9e44', '#c8f0cf'); [[1, 0], [-1, 0], [0, 1], [0, -1], [.7, .7], [-.7, -.7], [.7, -.7], [-.7, .7]].forEach(([dx, dy]) => ar(ix, iy, dx * 22, dy * 22, '#2f9e44'));
      const wx = bx + bw - 18, wy = by + bh * 0.3; ball(g, wx, wy, 8, '#c0392b', '#ffb3a8'); [[-1, 0], [-.7, .7], [-.7, -.7], [0, 1], [0, -1]].forEach(([dx, dy]) => ar(wx, wy, dx * 22, dy * 22, '#c0392b')); ar(wx - 2, wy + 28, -36, 0, '#7b3fa0');
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('নিট টান শূন্য', ix, iy + 38); g.textAlign = 'right'; g.fillText('নিট টান ভিতরে ⇒ চাপ কম', wx - 4, wy + 48);
      g.textAlign = 'center'; g.fillText('দেয়াল', bx + bw - 2, by - 6);
    };
    const drawIso = (g, W, H, col) => {
      const G = gOf('CO2'), a = G[2], b = G[3], tc = Tc(a, b), vc = 3 * b, pc = a / (27 * b * b);
      const Pl = cplot(g, { x0: 56, y0: 22, w: W - 76, h: H - 64, xmin: 0.04, xmax: 0.6, ymin: 0, ymax: 120, col, xt: [0.1, 0.2, 0.3, 0.4, 0.5, 0.6], yt: [0, 30, 60, 90, 120], fx: v => bn(v.toFixed(1)), xl: 'V_m (L mol⁻¹)', yl: 'P (atm)', ylx: 30 });
      const Ts = [270, 285, 297, Math.round(tc * 10) / 10, 320, 350], cl = ['#2d6fd6', '#2f9e44', '#d06a1e', '#c0392b', '#7b3fa0', '#8a8f98'];
      // two-phase dome
      const dome = []; for (let tt = 250; tt < tc - 0.2; tt += 1.5) { const m = maxwellPsat(tt, a, b); if (m) dome.push(m); }
      if (dome.length) { g.fillStyle = 'rgba(45,111,214,.08)'; g.beginPath(); dome.forEach(([p, v1], i) => { const X_ = Pl.X(v1), Y_ = Pl.Y(p); i ? g.lineTo(X_, Y_) : g.moveTo(X_, Y_); }); g.lineTo(Pl.X(vc), Pl.Y(pc)); dome.slice().reverse().forEach(([p, , v3]) => g.lineTo(Pl.X(Math.min(0.6, v3)), Pl.Y(p))); g.closePath(); g.fill(); g.fillStyle = '#2d6fd6'; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('তরল + বাষ্প', Pl.X(0.17), Pl.Y(48)); }
      Ts.forEach((tt, i) => { const pts = [], dash = []; const m = tt < tc ? maxwellPsat(tt, a, b) : null;
        for (let v = 0.045; v <= 0.6; v += 0.002) { const p = Pvdw(v, tt, a, b); if (p < 0 || p > 125) continue; if (m && v > m[1] && v < m[2]) dash.push([Pl.X(v), Pl.Y(p)]); else pts.push([v, p]); }
        if (m) { const left = pts.filter(x => x[0] <= m[1]), right = pts.filter(x => x[0] >= m[2]); path(g, left.map(([v, p]) => [Pl.X(v), Pl.Y(p)]), cl[i], 2.2); path(g, right.map(([v, p]) => [Pl.X(v), Pl.Y(p)]), cl[i], 2.2); path(g, dash, cl[i], 1.1, [3, 3]); path(g, [[Pl.X(m[1]), Pl.Y(m[0])], [Pl.X(m[2]), Pl.Y(m[0])]], cl[i], 2.2); }
        else path(g, pts.map(([v, p]) => [Pl.X(v), Pl.Y(p)]), cl[i], 2.2);
      });
      ball(g, Pl.X(vc), Pl.Y(pc), 5.5, '#c0392b', '#ffb3a8'); g.fillStyle = '#c0392b'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`সংকট বিন্দু (${bn(Math.round(tc))} K, ${bn(Math.round(pc))} atm)`, Pl.X(vc) + 8, Pl.Y(pc) - 6);
      legend(g, col, W - 20, 24, Ts.map((tt, i) => [cl[i], `${bn(Math.round(tt))} K${i === 3 ? ' (T_c)' : ''}`]), true);
    };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); if (md === 'corr') drawCorr(g, W, H, col); else drawIso(g, W, H, col); };
    const info = () => { const G = gOf(gk), Vl = Vof(), a = G[2], b = G[3]; q('[data-nv]').textContent = fx(n, 1); q('[data-vv]').textContent = fx(Vl, 2); q('[data-tv]').textContent = bn(T);
      if (Vl <= n * b * 1.05) { out.innerHTML = '<div class="small">আয়তন বর্জিত আয়তনের (nb) চেয়ে প্রায় কম — বাস্তবে অসম্ভব; আয়তন বাড়াও।</div>'; return; }
      const Pi = n * R * T / Vl, t1 = n * R * T / (Vl - n * b), t2 = a * n * n / (Vl * Vl), Pv = t1 - t2;
      out.innerHTML = TXB(`P_{\\text{আদর্শ}} = \\dfrac{nRT}{V} = \\dfrac{${n}\\times0.0821\\times${T}}{${Vl}} = ${Pi.toFixed(2)}\\ \\mathrm{atm}`) + TXB(`P_{\\text{vdW}} = \\dfrac{nRT}{V - nb} - \\dfrac{an^2}{V^2} = ${t1.toFixed(2)} - ${t2.toFixed(2)} = ${Pv.toFixed(2)}\\ \\mathrm{atm}`) + TXB(`Z = ${(Pv / Pi).toFixed(3)}`) +
        `<div class="small">আয়তন সংশোধন চাপ ${fx(t1 - Pi, 2)} atm বাড়ায়, আকর্ষণ সংশোধন ${fx(t2, 2)} atm কমায় — ${t2 > t1 - Pi ? 'আকর্ষণ জেতে (Z < ১)' : 'আয়তন জেতে (Z > ১)'}। ${T < Tc(a, b) && Pv > 0 ? `সতর্কতা: T সংকট তাপমাত্রার (${bn(Math.round(Tc(a, b)))} K) নিচে — যথেষ্ট চাপে গ্যাসটি তরল হতে পারে।` : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'vm', k => { md = k; A.draw(); });
    q('[data-g]').onchange = e => { gk = e.target.value; info(); };
    q('[data-n]').oninput = e => { n = +e.target.value; info(); };
    q('[data-v]').oninput = e => { vu = +e.target.value; info(); };
    q('[data-t]').oninput = e => { T = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
