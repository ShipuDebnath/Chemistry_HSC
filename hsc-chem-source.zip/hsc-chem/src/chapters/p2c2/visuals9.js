/* ২য় পত্র অধ্যায় ২ visuals part 9 — 2.12 functional-group identification lab (unknown compound game + systematic flowchart), 2.13 IR spectroscopy (spectra with 3D bond vibration, Hooke's-law calculator, spectrum quiz) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };

/* ======================= ২.১২ অজানা যৌগ শনাক্তকরণ ল্যাব ======================= */
const UK = [
  ['hexane', 'হেক্সেন', 'C₆H₁₄', 'অ্যালকেন'], ['hexene', 'হেক্স-১-ইন', 'C₆H₁₂', 'অ্যালকিন'], ['pentyne', 'পেন্ট-১-আইন', 'C₅H₈', 'প্রান্তীয় অ্যালকাইন'],
  ['bromoethane', 'ব্রোমোইথেন', 'C₂H₅Br', 'অ্যালকাইল হ্যালাইড'], ['ethanol', 'ইথানল', 'C₂H₅OH', '১° অ্যালকোহল'], ['tbuoh', '২-মিথাইলপ্রোপান-২-অল', '(CH₃)₃COH', '৩° অ্যালকোহল'],
  ['phenol', 'ফেনল', 'C₆H₅OH', 'ফেনল'], ['ethanal', 'ইথান্যাল', 'CH₃CHO', 'অ্যালিফেটিক অ্যালডিহাইড'], ['benzal', 'বেনজালডিহাইড', 'C₆H₅CHO', 'অ্যারোমেটিক অ্যালডিহাইড'],
  ['propanone', 'প্রোপানোন', 'CH₃COCH₃', 'কিটোন'], ['acid', 'ইথানয়িক এসিড', 'CH₃COOH', 'কার্বক্সিলিক এসিড'], ['ester', 'ইথাইল ইথানয়েট', 'CH₃COOC₂H₅', 'এস্টার'],
  ['amide', 'ইথানামাইড', 'CH₃CONH₂', 'অ্যামাইড'], ['amine', 'ইথানামিন', 'C₂H₅NH₂', '১° অ্যামিন']
];
/* result: [type, colour, text]; type: bub | ppt | col | mirror | cloud | gas | smell */
const TS = {
  hco3: ['NaHCO₃ দ্রবণ', 'rgba(230,240,250,.45)', { acid: ['bub', '#fff', 'তীব্র বুদবুদ — CO₂ (চুনের পানি ঘোলা করে)'] }, 'RCOOH + NaHCO3 -> RCOONa + CO2 ^ + H2O'],
  fecl3: ['নিরপেক্ষ FeCl₃', 'rgba(230,190,60,.55)', { phenol: ['col', 'rgba(120,40,160,.85)', 'বেগুনি বর্ণ — ফেনলীয় –OH'], acid: ['col', 'rgba(170,70,30,.7)', 'লালচে-বাদামি (অ্যাসিটেট আয়ন, প্রশমিত দ্রবণে)'] }, '6C6H5OH + FeCl3 -> [Fe(OC6H5)6]^3- + 3H+ + 3HCl'],
  dnp: ['২,৪-DNP', 'rgba(245,170,60,.35)', { ethanal: ['ppt', '#f0a020', 'হলুদ-কমলা অধঃক্ষেপ'], benzal: ['ppt', '#e07010', 'কমলা-লাল অধঃক্ষেপ'], propanone: ['ppt', '#f0b020', 'হলুদ অধঃক্ষেপ'] }, 'R2C=O + H2NNHC6H3(NO2)2 -> R2C=NNHC6H3(NO2)2 v + H2O'],
  tol: ['টলেন্স বিকারক (উত্তপ্ত)', 'rgba(230,230,235,.4)', { ethanal: ['mirror', '#ddd', 'রুপালি আয়না'], benzal: ['mirror', '#ddd', 'রুপালি আয়না'], pentyne: ['ppt', '#f5f5f5', 'সাদা অধঃক্ষেপ (সিলভার অ্যাসিটাইলাইড)'] }, 'RCHO + 2[Ag(NH3)2]+ + 3OH- -> RCOO- + 2Ag v + 4NH3 + 2H2O'],
  feh: ['ফেলিং দ্রবণ (উত্তপ্ত)', 'rgba(40,90,220,.6)', { ethanal: ['ppt', '#b03a2e', 'ইটের মতো লাল Cu₂O'] }, 'RCHO + 2Cu^2+ + 5OH- -> RCOO- + Cu2O v + 3H2O'],
  br2: ['ব্রোমিন পানি', 'rgba(200,90,20,.7)', { hexene: ['col', 'rgba(250,250,250,.15)', 'লাল-বাদামি বর্ণ বিলুপ্ত'], pentyne: ['col', 'rgba(250,250,250,.15)', 'লাল-বাদামি বর্ণ বিলুপ্ত'], phenol: ['ppt', '#fafafa', 'বর্ণ বিলুপ্ত ও সাদা অধঃক্ষেপ (২,৪,৬-ট্রাইব্রোমোফেনল)'], ethanal: ['col', 'rgba(230,170,90,.35)', 'ধীরে বিবর্ণ (জারণ)'], benzal: ['col', 'rgba(230,170,90,.4)', 'ধীরে বিবর্ণ'], amine: ['col', 'rgba(230,170,90,.4)', 'বিবর্ণ'] }, 'CH2=CHR + Br2 -> BrCH2-CHBrR'],
  na: ['ধাতব Na (শুষ্ক যৌগে)', 'rgba(240,240,240,.25)', { ethanol: ['bub', '#fff', 'H₂ এর বুদবুদ (দ্রুত)'], tbuoh: ['bub', '#fff', 'H₂ এর বুদবুদ (ধীরে)'], phenol: ['bub', '#fff', 'H₂ এর বুদবুদ'], acid: ['bub', '#fff', 'তীব্র H₂ বুদবুদ'], pentyne: ['bub', '#fff', 'ধীরে H₂ (প্রান্তীয় ≡C–H)'] }, '2ROH + 2Na -> 2RONa + H2 ^'],
  lucas: ['লুকাস বিকারক', 'rgba(240,240,240,.25)', { tbuoh: ['cloud', '#fff', 'তাৎক্ষণিক ঘোলা — ৩°'], ethanol: ['none', '', 'কক্ষ তাপমাত্রায় পরিষ্কার — ১°'] }, 'R3C-OH + HCl ->[ZnCl2] R3C-Cl + H2O'],
  cr: ['অম্লীয় K₂Cr₂O₇ (উত্তপ্ত)', 'rgba(235,120,20,.75)', { ethanol: ['col', 'rgba(40,160,70,.75)', 'কমলা → সবুজ'], ethanal: ['col', 'rgba(40,160,70,.75)', 'কমলা → সবুজ'], benzal: ['col', 'rgba(80,150,70,.75)', 'কমলা → সবুজ'] }, 'Cr2O7^2- + 14H+ + 6e- -> 2Cr^3+ + 7H2O'],
  iod: ['I₂ + NaOH (আয়োডোফর্ম)', 'rgba(160,90,30,.55)', { ethanol: ['ppt', '#f4d03f', 'হলুদ CHI₃ অধঃক্ষেপ'], ethanal: ['ppt', '#f4d03f', 'হলুদ CHI₃ অধঃক্ষেপ'], propanone: ['ppt', '#f4d03f', 'হলুদ CHI₃ অধঃক্ষেপ'] }, 'CH3COR + 3I2 + 4NaOH -> CHI3 v + RCOONa + 3NaI + 3H2O'],
  carb: ['CHCl₃ + অ্যালকোহলীয় KOH (উত্তপ্ত)', 'rgba(240,240,240,.25)', { amine: ['smell', '', 'অত্যন্ত দুর্গন্ধ — আইসোসায়ানাইড (১° অ্যামিন)'] }, 'RNH2 + CHCl3 + 3KOH -> RNC + 3KCl + 3H2O'],
  naoh: ['NaOH দিয়ে ফুটানো (মুখে আর্দ্র লাল লিটমাস)', 'rgba(240,240,240,.25)', { amide: ['gas', '#3d6fd6', 'NH₃ গ্যাস — লাল লিটমাস নীল'], ester: ['smell', '', 'ফলের গন্ধ ধীরে মিলিয়ে যায়, স্তর এক হয় (সাবানীকরণ)'], bromoethane: ['none', '', 'Br⁻ আয়ন তৈরি হয় (পরের AgNO₃ পরীক্ষায় দেখা যাবে)'] }, 'RCONH2 + NaOH -> RCOONa + NH3 ^'],
  ag: ['NaOH এর পর HNO₃ + AgNO₃', 'rgba(240,240,240,.25)', { bromoethane: ['ppt', '#f2eba0', 'হালকা হলুদ AgBr অধঃক্ষেপ'] }, 'R-Br + OH- -> R-OH + Br- ;\\ Ag+ + Br- -> AgBr v'],
  smell: ['গন্ধ পরীক্ষা (সাবধানে হাত নেড়ে)', 'rgba(240,240,240,.18)', { ester: ['smell', '', 'মিষ্টি ফলের মতো গন্ধ'], acid: ['smell', '', 'ঝাঁঝালো ভিনেগারের গন্ধ'], amine: ['smell', '', 'অ্যামোনিয়া/মাছের মতো গন্ধ'], benzal: ['smell', '', 'কাঠবাদামের গন্ধ'], propanone: ['smell', '', 'মিষ্টি দ্রাবকের গন্ধ (নেইল পলিশ রিমুভার)'], phenol: ['smell', '', 'কার্বলিক গন্ধ'] }, '']
};
const FLOW = [
  ['hco3', 'NaHCO₃ দিলে CO₂?', 'কার্বক্সিলিক এসিড', ['acid']],
  ['fecl3', 'নিরপেক্ষ FeCl₃ এ বেগুনি?', 'ফেনল', ['phenol']],
  ['dnp', '২,৪-DNP অধঃক্ষেপ?', 'কার্বনিল → টলেন্স: আয়না = অ্যালডিহাইড (ফেলিং লাল = অ্যালিফেটিক); না = কিটোন', ['ethanal', 'benzal', 'propanone']],
  ['br2', 'ব্রোমিন পানি বিবর্ণ?', 'অসম্পৃক্ত → অ্যামোনিয়াযুক্ত AgNO₃ এ সাদা = প্রান্তীয় অ্যালকাইন; না = অ্যালকিন', ['hexene', 'pentyne']],
  ['na', 'Na দিলে H₂?', 'অ্যালকোহল → লুকাস: তাৎক্ষণিক ৩°, ৫ মি ২°, না ১°', ['ethanol', 'tbuoh']],
  ['carb', 'কার্বিলঅ্যামিন দুর্গন্ধ?', '১° অ্যামিন', ['amine']],
  ['naoh', 'NaOH দিয়ে ফুটালে NH₃?', 'অ্যামাইড', ['amide']],
  ['ag', 'NaOH-HNO₃-AgNO₃ এ অধঃক্ষেপ?', 'অ্যালকাইল হ্যালাইড (সাদা Cl, হালকা হলুদ Br, হলুদ I)', ['bromoethane']],
  ['smell', 'ফলের গন্ধ?', 'এস্টার', ['ester']]
];
V.p2c2_fgLab = {
  t: 'অজানা জৈব যৌগ শনাক্তকরণ ল্যাব: ১৪টি যৌগ × ১৪টি পরীক্ষা — পরীক্ষানলে পর্যবেক্ষণ, পর্যবেক্ষণ খাতা, সিদ্ধান্ত এবং পদ্ধতিগত শনাক্তকরণ ফ্লোচার্ট', k: ['anim', 'int', '2d'],
  cap: '"অজানা যৌগ" মোডে একটি লেবেলহীন বোতল দেওয়া হয়। উপরের যেকোনো পরীক্ষায় চাপ দিলে পরীক্ষানলে বিকারক ও নমুনা মিশে ফলাফল অ্যানিমেশনে দেখায় (বুদবুদ, অধঃক্ষেপ, বর্ণ পরিবর্তন, রুপালি আয়না, ঘোলা হওয়া, গ্যাস, গন্ধ) এবং পর্যবেক্ষণ খাতায় লেখা হয়। যথেষ্ট তথ্য পেলে নিচ থেকে যৌগটি বেছে "সিদ্ধান্ত" দাও — কম পরীক্ষায় সঠিক উত্তরে বেশি তারা। "ফ্লোচার্ট" মোডে পরীক্ষাগারের পদ্ধতিগত ক্রম: এসিড → ফেনল → কার্বনিল → অসম্পৃক্ততা → অ্যালকোহল → অ্যামিন → অ্যামাইড → হ্যালাইড → এস্টার → অ্যালকেন; অজানা যৌগের পথ রঙিন করে দেখায়। ক্রমটি গুরুত্বপূর্ণ: যেমন ফেনলও Na ও Br₂ পানির সাথে বিক্রিয়া করে, তাই আগে FeCl₃ দিয়ে ফেনল বাদ দিতে হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['lab', 'অজানা যৌগ'], ['flow', 'ফ্লোচার্ট']], 'lab')}<button class="btn sm" data-new>নতুন বোতল</button></div><div data-tests style="display:flex;flex-wrap:wrap;gap:4px;margin:0 0 6px">${Object.entries(TS).map(([k, v]) => `<button class="btn sm" data-t="${k}" style="font-size:12px;padding:3px 8px;min-height:30px">${v[0].split(' (')[0]}</button>`).join('')}</div>${X.cv('শনাক্তকরণ ল্যাব')}<div class="ctl" data-guessrow style="flex-wrap:wrap"><select data-g style="flex:1;min-width:160px;padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit"><option value="">— যৌগটি কী? —</option>${UK.map(u => `<option value="${u[0]}">${u[1]} (${u[2]}) — ${u[3]}</option>`).join('')}</select><button class="btn sm primary" data-ok>সিদ্ধান্ত</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? (md === 'flow' ? 440 : 330) : (md === 'flow' ? 560 : 440);
    let md = 'lab', L = null, uk = null, log = [], curT = null, p = 0, t = 0, done = false, verdict = '';
    const pickUK = () => { uk = UK[Math.floor(Math.random() * UK.length)][0]; log = []; curT = null; p = 0; done = false; verdict = ''; q('[data-g]').value = ''; el.querySelectorAll('[data-t]').forEach(b => b.classList.remove('on')); info(); };
    const res = (tk, u) => TS[tk][2][u] || ['none', '', 'কোনো দৃশ্যমান পরিবর্তন নেই'];
    const drawTube = (g, col, tx, ty, TL, tw) => {
      if (!curT) { M3.tube(g, tx, ty, TL, tw, 0, 'rgba(230,235,245,.3)', 0.4, col); g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('একটি পরীক্ষা বেছে নাও', tx, ty + TL + 18); return; }
      const T = TS[curT], r = res(curT, uk), k = Math.min(1, p), f = Math.max(0, (k - 0.25) / 0.75);
      let fill = T[1]; if (r[0] === 'col' && f > 0) { const m = s => s.match(/[\d.]+/g).map(Number), a = m(T[1]), b = m(r[1]); fill = `rgba(${a.slice(0, 4).map((v, i) => i < 3 ? Math.round(v + (b[i] - v) * f) : (v + (b[i] - v) * f).toFixed(2)).join(',')})`; }
      if (r[0] === 'cloud' && f > 0) fill = `rgba(245,245,245,${0.25 + 0.65 * f})`;
      M3.tube(g, tx, ty, TL, tw, 0, fill, 0.6, col);
      // dropper
      if (k < 0.3) { const dy = ty - 30 + k * 60; g.fillStyle = col.mu; g.fillRect(tx - 3, ty - 46, 6, 26); g.fillStyle = 'rgba(120,160,220,.8)'; g.beginPath(); g.arc(tx, dy + 6, 3, 0, 7); g.fill(); }
      if (r[0] === 'bub' && k > 0.2) for (let i = 0; i < 14; i++) { const u = (t * 1.1 + i / 14) % 1; g.strokeStyle = col.mu; g.fillStyle = 'rgba(255,255,255,.75)'; g.lineWidth = 0.7; g.beginPath(); g.arc(tx - tw / 2 + 6 + (i * 13 % (tw - 12)), ty + TL - 10 - u * TL * 0.55, 2 + (i % 3), 0, 7); g.fill(); g.stroke(); }
      if (r[0] === 'ppt' && f > 0) for (let i = 0; i < 70 * f; i++) { g.fillStyle = r[1]; g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 0.4; g.beginPath(); g.arc(tx - tw / 2 + 5 + (i * 23 % (tw - 10)), ty + TL - 10 - (i % 6) * 2.4 - Math.floor(i / 24) * 3, 2.1, 0, 7); g.fill(); g.stroke(); }
      if (r[0] === 'mirror' && f > 0) { const gr = g.createLinearGradient(tx - tw / 2, 0, tx + tw / 2, 0); gr.addColorStop(0, `rgba(150,150,160,${f})`); gr.addColorStop(0.35, `rgba(250,250,255,${f})`); gr.addColorStop(0.7, `rgba(140,140,150,${f})`); gr.addColorStop(1, `rgba(215,215,225,${f})`); g.fillStyle = gr; g.fillRect(tx - tw / 2 + 2, ty + TL * 0.4, tw - 4, TL * 0.6 - tw / 2); }
      if (r[0] === 'gas' && f > 0) { g.fillStyle = `rgba(220,60,60,${1 - f})`; g.fillRect(tx + tw / 2 + 4, ty - 30, 8, 26); g.fillStyle = `rgba(60,100,220,${f})`; g.fillRect(tx + tw / 2 + 4, ty - 30, 8, 26); for (let i = 0; i < 5; i++) { const u = (t * 0.6 + i / 5) % 1; g.fillStyle = 'rgba(160,160,200,.35)'; g.beginPath(); g.arc(tx - 6 + i * 3, ty - u * 40, 4 + u * 4, 0, 7); g.fill(); } }
      if (r[0] === 'smell' && f > 0) { g.strokeStyle = col.mu; g.lineWidth = 1.4; for (let i = 0; i < 3; i++) { g.beginPath(); for (let y = 0; y < 40; y += 2) { const x = tx - 10 + i * 10 + Math.sin(y / 5 + t * 3 + i) * 3; y ? g.lineTo(x, ty - 6 - y) : g.moveTo(x, ty - 6 - y); } g.stroke(); } }
      if (curT === 'tol' || curT === 'feh' || curT === 'cr' || curT === 'carb' || curT === 'naoh') { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('উত্তপ্ত পানির পাত্রে', tx, ty + TL + 30); }
      g.fillStyle = k > 0.85 ? (r[0] === 'none' ? col.mu : '#2f9e44') : col.mu; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center';
      const txt = k > 0.85 ? r[2] : 'মিশ্রণ…'; const words = txt.split(' '), lines = []; let ln = ''; g.font = `bold 10px ${col.font}`; words.forEach(w2 => { if (g.measureText(ln + ' ' + w2).width > 150 && ln) { lines.push(ln); ln = w2; } else ln = ln ? ln + ' ' + w2 : w2; }); lines.push(ln); lines.forEach((s2, i) => g.fillText(s2, tx, ty + TL + 16 + i * 13));
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 'lab') {
        const tx = wd ? 110 : W / 2, ty = 60, TL = wd ? 170 : 180, tw = 42;
        // bottle
        const bx = wd ? 26 : 22, by = 22; g.fillStyle = 'rgba(140,90,40,.25)'; g.strokeStyle = col.fg; g.lineWidth = 1.3; rr(g, bx, by + 14, 34, 50, 6); g.fill(); g.stroke(); g.fillRect(bx + 10, by, 14, 14); g.strokeRect(bx + 10, by, 14, 14); g.fillStyle = col.sf; g.fillRect(bx + 4, by + 30, 26, 16); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(done ? '✓' : '?', bx + 17, by + 42);
        drawTube(g, col, tx, ty, TL, tw);
        const lx = wd ? 230 : 14, ly = wd ? 26 : ty + TL + 70, lw = wd ? W - 244 : W - 28; g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`পর্যবেক্ষণ খাতা (${bn(log.length)}টি পরীক্ষা)`, lx, ly);
        const lineH = 17; log.slice(-(wd ? 15 : Math.floor((H - ly - 10) / lineH))).forEach((tk, i) => { const r = res(tk, uk), y = ly + 18 + i * lineH; g.fillStyle = r[0] === 'none' ? col.mu : '#2f9e44'; g.font = `10px ${col.font}`; const s = `${r[0] === 'none' ? '✗' : '✓'} ${TS[tk][0].split(' (')[0]}: ${r[2]}`; let s2 = s; while (g.measureText(s2).width > lw && s2.length > 10) s2 = s2.slice(0, -2); g.fillText(s2 === s ? s : s2 + '…', lx, y); });
        if (verdict) { g.fillStyle = verdict.startsWith('✓') ? '#2f9e44' : '#c0392b'; g.font = `bold 12px ${col.font}`; g.textAlign = 'left'; g.fillText(verdict, lx, H - 10); }
      } else {
        const n = FLOW.length, x0 = 12, rowH = (H - 40) / (n + 1), qw = wd ? W * 0.36 : W * 0.53, path2 = []; let stop = n;
        FLOW.forEach((f, i) => { if (stop === n && f[3].includes(uk)) stop = i; });
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(done ? `পথ: ${UK.find(u => u[0] === uk)[1]}` : 'পরীক্ষার পদ্ধতিগত ক্রম ("সিদ্ধান্ত" দেওয়ার পর পথ রঙিন হবে)', x0, 16);
        FLOW.forEach((f, i) => { const y = 30 + i * rowH, on = done && i <= stop, hit = done && i === stop; g.fillStyle = hit ? '#2f9e44' : on ? col.acc : col.sf; g.strokeStyle = on ? col.acc : col.mu; g.lineWidth = 1.3; rr(g, x0, y, qw, rowH - 10, 7); g.fill(); g.stroke(); g.fillStyle = on ? '#fff' : col.fg; g.font = `${wd ? 10.5 : 8.5}px ${col.font}`; g.textAlign = 'left'; g.save(); g.beginPath(); g.rect(x0, y, qw - 3, rowH - 10); g.clip(); g.fillText(`${bn(i + 1)}. ${f[1]}`, x0 + 5, y + (rowH - 10) / 2 + 4); g.restore();
          g.strokeStyle = hit ? '#2f9e44' : col.mu; g.lineWidth = hit ? 2.2 : 1; g.beginPath(); g.moveTo(x0 + qw, y + (rowH - 10) / 2); g.lineTo(x0 + qw + 18, y + (rowH - 10) / 2); g.stroke(); g.fillStyle = hit ? '#2f9e44' : col.mu; g.font = `bold 9px ${col.font}`; g.fillText('হ্যাঁ', x0 + qw + 2, y + (rowH - 10) / 2 - 4);
          const ax = x0 + qw + 22, aw = W - ax - 8; g.font = `${hit ? 'bold ' : ''}${wd ? 10 : 8.5}px ${col.font}`; g.fillStyle = hit ? '#2f9e44' : col.fg; const words = f[2].split(' '); let ln = '', li = 0; const lines = []; words.forEach(w2 => { if (g.measureText(ln + ' ' + w2).width > aw && ln) { lines.push(ln); ln = w2; } else ln = ln ? ln + ' ' + w2 : w2; }); lines.push(ln); lines.slice(0, 3).forEach((s2, j) => g.fillText(s2, ax, y + (rowH - 10) / 2 + 4 + (j - (Math.min(3, lines.length) - 1) / 2) * 11)); void li;
          if (i < n - 1) { g.strokeStyle = on && i < stop ? col.acc : col.mu; g.lineWidth = on && i < stop ? 2 : 1; g.beginPath(); g.moveTo(x0 + 20, y + rowH - 10); g.lineTo(x0 + 20, y + rowH); g.stroke(); g.fillStyle = col.mu; g.font = `8.5px ${col.font}`; g.fillText('না', x0 + 24, y + rowH - 2); } });
        const y = 30 + n * rowH, hit = done && stop === n; g.fillStyle = hit ? '#2f9e44' : col.sf; g.strokeStyle = col.mu; rr(g, x0, y, qw, rowH - 10, 7); g.fill(); g.stroke(); g.fillStyle = hit ? '#fff' : col.fg; g.font = `${wd ? 10.5 : 9.5}px ${col.font}`; g.fillText('সব ঋণাত্মক → অ্যালকেন', x0 + 6, y + (rowH - 10) / 2 + 4); void path2;
      }
    };
    const info = () => { if (md === 'flow') { out.innerHTML = `<div>ফ্লোচার্টে প্রতিটি ধাপে একটি পরীক্ষা কয়েকটি শ্রেণিকে আলাদা করে। ক্রম ঠিক রাখা জরুরি — আগের ধাপে "না" হলেই পরের ধাপে যাও। নিশ্চিতকরণের জন্য সবসময় একটি দ্বিতীয় পরীক্ষা করো (যেমন অ্যালডিহাইডে টলেন্সের পর ফেলিং, অ্যালকোহলে Na এর পর লুকাস)।</div>`; return; }
      out.innerHTML = curT ? `<div><b>${TS[curT][0]}:</b> ${res(curT, uk)[2]}।</div>${TS[curT][3] && res(curT, uk)[0] !== 'none' ? TXB(`\\ce{${TS[curT][3]}}`) : ''}` : '<div>বোতলে একটি অজানা জৈব যৌগ। পরীক্ষা চালিয়ে পর্যবেক্ষণ থেকে কার্যকরী মূলক ও যৌগ শনাক্ত করো।</div>'; };
    el.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { if (md !== 'lab') { md = 'lab'; el.querySelectorAll('[data-seg=md] button, [data-k=md] button').forEach(x => x.classList.toggle('on', x.dataset.v === 'lab')); } curT = b.dataset.t; p = 0; if (!log.includes(curT)) log.push(curT); b.classList.add('on'); info(); });
    q('[data-ok]').onclick = () => { const v = q('[data-g]').value; if (!v) return; const u = UK.find(x => x[0] === uk), ok = v === uk, star = log.length <= 3 ? '★★★' : log.length <= 5 ? '★★' : '★'; done = ok || done; verdict = ok ? `✓ সঠিক! ${u[1]} (${u[3]}) — ${bn(log.length)}টি পরীক্ষায় ${star}` : `✗ হয়নি — আরও পরীক্ষা করো`; A.draw(); };
    q('[data-new]').onclick = () => { pickUK(); };
    X.onSeg(el, 'md', v => { md = v; L = X.fit(c, hf); info(); });
    const A = X.anim(el, dt => { if (dt) { t += dt; if (curT && p < 1) p = Math.min(1, p + dt * 0.45); } draw(); }, { paused: false });
    L = X.fit(c, hf); pickUK(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১৩ IR বর্ণালি ======================= */
/* bands: [wavenumber, depth(0..1 absorbance), half-width, label, bondKey] */
const findB = (m, e1, e2, o) => { for (const b of m.b) { const A = m.a[b.i].el, B = m.a[b.j].el; if ((o == null || Math.round(b.o) === o) && ((A === e1 && B === e2) || (A === e2 && B === e1))) return A === e1 ? [b.i, b.j] : [b.j, b.i]; } return null; };
const findOH = (m, el = 'O') => { for (const b of m.b) { const A = m.a[b.i].el, B = m.a[b.j].el; if (A === el && B === 'H') return [b.i, b.j]; if (B === el && A === 'H') return [b.j, b.i]; } return null; };
const findCH = (m, aldehyde) => { for (const b of m.b) { const A = m.a[b.i], B = m.a[b.j]; const [ci, hi] = A.el === 'C' && B.el === 'H' ? [b.i, b.j] : B.el === 'C' && A.el === 'H' ? [b.j, b.i] : [-1, -1]; if (ci < 0) continue; const hasO = m.b.some(bb => (bb.i === ci || bb.j === ci) && Math.round(bb.o) === 2 && m.a[bb.i === ci ? bb.j : bb.i].el === 'O'); if (!!aldehyde === hasO) return [ci, hi]; } return null; };
const ester = () => M3.relax(M3.tree([['C', -1], ['C', 0], ['O', 1, 2], ['O', 1], ['C', 3], ['C', 4]], { name: 'ইথাইল ইথানয়েট' }));
const IRC = {
  ethanol: ['ইথানল', () => M3.LIB.ethanol(), [[3350, 0.9, 170, 'O–H প্রসারণ (H বন্ধনযুক্ত, চওড়া)', 'OH'], [2975, 0.75, 30, 'C–H প্রসারণ (sp³)', 'CH'], [2930, 0.5, 25, '', 'CH'], [2885, 0.45, 25, '', 'CH'], [1450, 0.35, 25, 'C–H বাঁকন', ''], [1380, 0.3, 20, '', ''], [1090, 0.5, 25, 'C–O প্রসারণ', 'CO1'], [1050, 0.85, 25, 'C–O প্রসারণ', 'CO1'], [880, 0.45, 20, '', '']], 'চওড়া O–H (৩৩৫০) + C–O (১০৫০); কোনো C=O নেই → অ্যালকোহল'],
  ethanal: ['ইথান্যাল', () => M3.LIB.acetaldehyde(), [[2970, 0.4, 30, 'C–H প্রসারণ (sp³)', 'CH'], [2820, 0.45, 18, 'অ্যালডিহাইড C–H (ফার্মি দ্বিত্ব)', 'CHO'], [2720, 0.45, 18, 'অ্যালডিহাইড C–H (ফার্মি দ্বিত্ব)', 'CHO'], [1730, 0.98, 30, 'C=O প্রসারণ (অ্যালডিহাইড)', 'CO2'], [1430, 0.35, 25, '', ''], [1350, 0.4, 20, '', ''], [1120, 0.4, 25, '', '']], 'তীক্ষ্ণ তীব্র C=O (১৭৩০) + ২৭২০ ও ২৮২০ এর জোড়া C–H → অ্যালডিহাইড'],
  propanone: ['প্রোপানোন', () => M3.LIB.acetone(), [[3005, 0.3, 30, 'C–H প্রসারণ', 'CH'], [2925, 0.25, 30, '', 'CH'], [1715, 0.98, 28, 'C=O প্রসারণ (কিটোন)', 'CO2'], [1420, 0.45, 25, 'C–H বাঁকন', ''], [1365, 0.6, 18, '', ''], [1220, 0.7, 25, 'C–C(=O)–C প্রসারণ', ''], [1090, 0.3, 20, '', '']], 'তীব্র C=O (১৭১৫), O–H নেই, অ্যালডিহাইড C–H জোড়া নেই → কিটোন'],
  acid: ['ইথানয়িক এসিড', () => M3.LIB.aceticAcid(), [[3000, 0.85, 380, 'O–H প্রসারণ (কার্বক্সিলিক, অত্যন্ত চওড়া ২৫০০–৩৩০০)', 'OH'], [1710, 0.98, 30, 'C=O প্রসারণ (এসিড ডাইমার)', 'CO2'], [1410, 0.5, 25, '', ''], [1290, 0.75, 30, 'C–O প্রসারণ', 'CO1'], [940, 0.5, 45, 'O–H বাঁকন (তলবহির্ভূত)', '']], 'অত্যন্ত চওড়া O–H (২৫০০–৩৩০০, C–H এর উপর চাপা) + C=O (১৭১০) → কার্বক্সিলিক এসিড'],
  ester: ['ইথাইল ইথানয়েট', ester, [[2985, 0.4, 30, 'C–H প্রসারণ', 'CH'], [1742, 0.98, 28, 'C=O প্রসারণ (এস্টার)', 'CO2'], [1373, 0.55, 18, '', ''], [1240, 0.95, 35, 'C–O প্রসারণ (অ্যাসাইল–O)', 'CO1'], [1047, 0.7, 25, 'C–O প্রসারণ (O–অ্যালকাইল)', '']], 'C=O (১৭৪০, কিটোনের চেয়ে বেশি) + দুটি তীব্র C–O (১২৪০, ১০৪৭), O–H নেই → এস্টার'],
  amine: ['মিথানামিন', () => M3.LIB.methylamine(), [[3370, 0.45, 35, 'N–H প্রসারণ (অপ্রতিসম)', 'NH'], [3290, 0.4, 35, 'N–H প্রসারণ (প্রতিসম)', 'NH'], [2960, 0.6, 30, 'C–H প্রসারণ', 'CH'], [2870, 0.45, 25, '', 'CH'], [1610, 0.45, 35, 'N–H বাঁকন', ''], [1080, 0.35, 25, 'C–N প্রসারণ', '']], 'দুটি মাঝারি N–H শৃঙ্গ (৩৩০০–৩৪০০) → ১° অ্যামিন (২° এ একটি, ৩° এ নেই); O–H এর চেয়ে সরু'],
  hexane: ['হেক্সেন', () => M3.LIB.hexane(), [[2960, 0.85, 22, 'C–H প্রসারণ (CH₃)', 'CH'], [2925, 0.95, 22, 'C–H প্রসারণ (CH₂)', 'CH'], [2860, 0.75, 20, '', 'CH'], [1465, 0.5, 20, 'C–H বাঁকন', ''], [1380, 0.35, 15, '', ''], [725, 0.3, 15, '–(CH₂)ₙ– দোলন', '']], 'কেবল C–H প্রসারণ (৩০০০ এর নিচে) ও বাঁকন — O–H বা C=O নেই → অ্যালকেন'],
  phenol: ['ফেনল', () => M3.arene({ 0: 'OH' }, 'ফেনল'), [[3350, 0.85, 160, 'O–H প্রসারণ (চওড়া)', 'OH'], [3045, 0.35, 25, '=C–H প্রসারণ (অ্যারোমেটিক, ৩০০০ এর উপরে)', 'CH'], [1600, 0.55, 18, 'C=C বলয় প্রসারণ', ''], [1500, 0.6, 18, 'C=C বলয় প্রসারণ', ''], [1230, 0.75, 30, 'C–O প্রসারণ', 'CO1'], [755, 0.7, 15, 'C–H তলবহির্ভূত বাঁকন (একপ্রতিস্থাপিত)', ''], [690, 0.6, 15, '', '']], 'চওড়া O–H + ৩০০০ এর উপরে =C–H + ১৬০০/১৫০০ বলয় শৃঙ্গ → ফেনল (অ্যারোমেটিক অ্যালকোহল)']
};
const KEYB = { OH: m => findOH(m, 'O'), NH: m => findOH(m, 'N'), CH: m => findCH(m, false), CHO: m => findCH(m, true), CO2: m => findB(m, 'C', 'O', 2), CO1: m => findB(m, 'C', 'O', 1) };
const REGIONS = [[3200, 3650, 'O–H', '#c0392b'], [3300, 3500, 'N–H', '#2980b9'], [2850, 3100, 'C–H', '#7f8c8d'], [2100, 2260, 'C≡C, C≡N', '#8e44ad'], [1680, 1800, 'C=O', '#e67e22'], [1600, 1680, 'C=C', '#27ae60'], [1000, 1300, 'C–O', '#d35400'], [400, 1500, 'অঙ্গুলিছাপ অঞ্চল', '#95a5a6']];
V.p2c2_irSpec = {
  t: 'IR বর্ণালি: ৮টি যৌগের বর্ণালি (ট্রান্সমিট্যান্স বনাম তরঙ্গসংখ্যা) — –OH ও >C=O শোষণ ব্যান্ড শনাক্তকরণ, শৃঙ্গে চাপ দিলে ত্রিমাত্রিক অণুতে সংশ্লিষ্ট বন্ধনের কম্পন, এবং "বর্ণালি দেখে যৌগ চেনো" কুইজ', k: ['3d', 'anim', 'int'],
  cap: 'উপরে যৌগ বেছে নাও। লেখচিত্রের x অক্ষে তরঙ্গসংখ্যা (cm⁻¹) — রীতি অনুযায়ী ৪০০০ বাঁ দিকে থেকে ৪০০ ডানে কমে; y অক্ষে ট্রান্সমিট্যান্স (%) — নিচে নামা শৃঙ্গ মানে শোষণ। যেকোনো শৃঙ্গে চাপ দিলে তার নাম দেখায় এবং ডানের ত্রিমাত্রিক মডেলে সেই বন্ধনটি প্রসারণ কম্পনে দুলতে থাকে (উজ্জ্বল)। "অঞ্চল" চালু করলে বৈশিষ্ট্যসূচক অঞ্চলগুলো রঙিন হয়। লক্ষ করো: অ্যালকোহলের O–H চওড়া ও গোলাকার (হাইড্রোজেন বন্ধন), এসিডের O–H আরও চওড়া (২৫০০–৩৩০০); C=O সবসময় ১৭০০–১৭৫০ এর কাছে তীক্ষ্ণ ও সবচেয়ে গভীর। "কুইজ" মোডে নাম লুকানো থাকে — বর্ণালি দেখে শ্রেণি বলো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap"><select data-c style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${Object.entries(IRC).map(([k, v]) => `<option value="${k}">${v[0]}</option>`).join('')}</select><label class="small"><input type="checkbox" data-rg> অঞ্চল</label>${X.seg('md', [['learn', 'শেখো'], ['quiz', 'কুইজ']], 'learn')}</div>${X.cv('IR বর্ণালি')}<div class="ctl" data-qrow style="display:none;flex-wrap:wrap;gap:4px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), qrow = q('[data-qrow]');
    const hf = w => wide(w) ? 330 : 560;
    let L = X.fit(c, hf), ck = 'ethanol', m = null, sel = 0, rg = false, md = 'learn', t = 0, qa = null, qmsg = ''; const cam = M3.cam({ yaw: 0.5, pitch: 0.35 }); let PL = null, plotBox = null;
    C4.drag3d(c, cam, () => A.draw());
    const build = () => { m = IRC[ck][1](); sel = IRC[ck][2].findIndex(b => b[4] === 'OH' || b[4] === 'CO2'); if (sel < 0) sel = 0; info(); };
    const T = (x, bands) => { let a = 0; bands.forEach(([w0, d, hw]) => { a += d * 1.6 / (1 + ((x - w0) / hw) ** 2); }); return 100 * Math.exp(-a) * 0.96 + 2; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), bands = IRC[ck][2];
      const px = 46, py = 18, pw = wd ? W * 0.6 - 60 : W - 64, ph = wd ? H - 60 : 230; plotBox = [px, py, pw, ph];
      PL = cplot(g, { x0: px, y0: py, w: pw, h: ph, xmin: 4000, xmax: 400, ymin: 0, ymax: 100, col, xt: [4000, 3000, 2000, 1500, 1000, 500], yt: [0, 50, 100], xl: 'তরঙ্গসংখ্যা (cm⁻¹)', yl: 'ট্রান্সমিট্যান্স (%)', ylx: 32 });
      if (rg) REGIONS.forEach(([a, b, nm, cc], i) => { const x1 = PL.X(b), x2 = PL.X(a); g.fillStyle = cc; g.globalAlpha = i === REGIONS.length - 1 ? 0.07 : 0.14; g.fillRect(x1, py, x2 - x1, ph); g.globalAlpha = 1; g.fillStyle = cc; g.font = `bold 8.5px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, (x1 + x2) / 2, py + 10 + (i % 3) * 10); });
      const pts = []; for (let x = 4000; x >= 400; x -= 4) pts.push([PL.X(x), PL.Y(T(x, bands))]); path(g, pts, col.acc, 1.6);
      bands.forEach((b, i) => { if (!b[3] && i !== sel) return; const x = PL.X(b[0]), y = PL.Y(T(b[0], bands)); const on = i === sel; g.fillStyle = on ? '#e74c3c' : col.mu; g.beginPath(); g.arc(x, y, on ? 5 : 3, 0, 7); g.fill(); if (on || md === 'learn') { g.font = `${on ? 'bold ' : ''}9px ${col.font}`; g.textAlign = 'center'; g.fillStyle = on ? '#e74c3c' : col.mu; g.fillText(bn(b[0]), x, Math.min(py + ph - 4, y + 14)); } });
      // 3D
      const x0 = wd ? W * 0.6 : 0, w0 = wd ? W * 0.4 : W, y0 = wd ? 0 : py + ph + 40, h0 = wd ? H : H - y0; const b = bands[sel], kf = b && KEYB[b[4]], pair = kf ? kf(m) : null;
      const mm = M3.clone(m); if (pair) { const [i0, i1] = pair, d = sub(mm.a[i1].p, mm.a[i0].p), amp = 0.16 * Math.sin(t * 9), mi = mm.a[i0].el === 'H' ? 1 : 0.3; mm.a[i1].p = add(mm.a[i1].p, mul(norm(d), amp * (mm.a[i1].el === 'H' ? 1 : 0.6))); mm.a[i0].p = sub(mm.a[i0].p, mul(norm(d), amp * mi * 0.4)); }
      cam.cx = x0 + w0 / 2; cam.cy = y0 + h0 / 2 + 6; M3.fit(m, cam, w0, h0 - 30, 0.9); if (!cam.user) cam.yaw += 0.004; const hl = {}; if (pair) { hl[pair[0]] = '#f1c40f'; hl[pair[1]] = '#f1c40f'; }
      if (md === 'quiz' && !qa) { g.fillStyle = col.mu; g.font = `bold 40px ${col.font}`; g.textAlign = 'center'; g.fillText('?', cam.cx, cam.cy + 14); return; }
      M3.render(g, mm, cam, { mode: 'bs', col, hl, labels: 'hetero' });
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(md === 'quiz' && !qa ? 'অজানা যৌগ' : `${IRC[ck][0]} (${M3.formula(m)})`, cam.cx, y0 + 14); if (pair) { g.fillStyle = '#b7950b'; g.font = `10px ${col.font}`; g.fillText(`${b[3] || ''} — ${bn(b[0])} cm⁻¹`, cam.cx, y0 + h0 - 6); }
    };
    const info = () => { const b = IRC[ck][2][sel]; if (md === 'quiz') { out.innerHTML = qa ? `<div><b>${qmsg}</b></div><div class="small">${IRC[ck][3]}</div>` : '<div>বর্ণালির শৃঙ্গগুলো লক্ষ করো (চাপ দিয়ে তরঙ্গসংখ্যা দেখো), তারপর নিচ থেকে শ্রেণি বেছে নাও।</div>'; return; }
      out.innerHTML = `<div><b>${IRC[ck][0]}:</b> ${IRC[ck][3]}।</div><div class="small" style="margin-top:4px">${b ? `নির্বাচিত শৃঙ্গ: ${bn(b[0])} cm⁻¹ — ${b[3] || 'অঙ্গুলিছাপ অঞ্চলের শৃঙ্গ'}।` : ''} অণুর কোনো বন্ধনের কম্পাঙ্কের সমান কম্পাঙ্কের IR বিকিরণ শোষিত হয়, তবে কেবল সেই কম্পনে যাতে ডাইপোল মোমেন্ট পরিবর্তিত হয় — তাই পোলার O–H ও C=O তীব্র শৃঙ্গ দেয়।</div>`; };
    const quizNew = () => { const ks = Object.keys(IRC); let k; do { k = ks[Math.floor(Math.random() * ks.length)]; } while (k === ck && ks.length > 1); ck = k; q('[data-c]').value = k; qa = null; build(); const cls = { ethanol: 'অ্যালকোহল', ethanal: 'অ্যালডিহাইড', propanone: 'কিটোন', acid: 'কার্বক্সিলিক এসিড', ester: 'এস্টার', amine: 'অ্যামিন', hexane: 'অ্যালকেন', phenol: 'ফেনল' }; qrow.innerHTML = Object.entries(cls).map(([kk, v]) => `<button class="btn sm" data-a="${kk}">${v}</button>`).join('') + '<button class="btn sm primary" data-nq>পরেরটি</button>'; qrow.querySelectorAll('[data-a]').forEach(bt => bt.onclick = () => { if (qa) return; qa = bt.dataset.a; const ok = qa === ck; qmsg = ok ? `✓ সঠিক — ${IRC[ck][0]} (${cls[ck]})` : `✗ এটি ${IRC[ck][0]} (${cls[ck]}), তুমি বলেছ ${cls[qa]}`; bt.classList.add(ok ? 'primary' : 'bad'); info(); }); qrow.querySelector('[data-nq]').onclick = quizNew; info(); };
    c.addEventListener('click', e => { if (!PL) return; const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, [px, py, pw, ph] = plotBox; if (x < px || x > px + pw || y < py || y > py + ph + 10) return; let best = -1, bd = 1e9; IRC[ck][2].forEach((b, i) => { const d = Math.abs(PL.X(b[0]) - x); if (d < bd) { bd = d; best = i; } }); if (bd < 22) { sel = best; info(); } });
    q('[data-c]').onchange = e => { ck = e.target.value; qa = null; build(); }; q('[data-rg]').onchange = e => { rg = e.target.checked; };
    X.onSeg(el, 'md', v => { md = v; qrow.style.display = v === 'quiz' ? 'flex' : 'none'; q('[data-c]').style.visibility = v === 'quiz' ? 'hidden' : ''; if (v === 'quiz') quizNew(); else { qa = null; info(); } });
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    build(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১৩ হুকের সূত্রে কম্পন তরঙ্গসংখ্যা ======================= */
const BONDS = [['O–H', 16, 1, 780, '#c0392b'], ['N–H', 14, 1, 640, '#2980b9'], ['C–H', 12, 1, 500, '#7f8c8d'], ['O–D', 16, 2, 780, '#e74c3c'], ['C≡N', 12, 14, 1860, '#8e44ad'], ['C≡C', 12, 12, 1560, '#9b59b6'], ['C=O', 12, 16, 1200, '#e67e22'], ['C=C', 12, 12, 960, '#27ae60'], ['C–O', 12, 16, 500, '#d35400'], ['C–C', 12, 12, 450, '#34495e']];
V.p2c2_irHooke = {
  t: 'বন্ধন একটি স্প্রিং: হুকের সূত্রে কম্পনের তরঙ্গসংখ্যা ν̃ = (১/২πc)√(k/μ) — বল ধ্রুবক k (বন্ধন ক্রম) ও হ্রাসকৃত ভর μ কীভাবে শোষণ অবস্থান ঠিক করে; O–H বনাম O–D আইসোটোপ প্রভাব', k: ['anim', 'int', 'calc'],
  cap: 'তালিকা থেকে বন্ধন বেছে নাও বা স্লাইডারে বল ধ্রুবক (k) ও দুই পরমাণুর ভর বদলাও। দুটি বল স্প্রিংয়ে দুলছে — দোলনের গতি তরঙ্গসংখ্যার আনুপাতিক। নিচের স্কেলে হিসাবকৃত তরঙ্গসংখ্যা বসে যায়। দেখো: (১) হালকা H যুক্ত বন্ধন (O–H, N–H, C–H) সবচেয়ে উপরে, ২৮০০–৩৮০০ cm⁻¹, কারণ μ ছোট; (২) একই পরমাণু জোড়ায় বন্ধন ক্রম বাড়লে k বাড়ে: C–O (~১১০০) < C=O (~১৭২০); C–C < C=C < C≡C; (৩) H কে D দিয়ে বদলালে μ প্রায় দ্বিগুণ — শৃঙ্গ √২ গুণ কমে (O–H ~৩৭০০ → O–D ~২৭০০)।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('bd', BONDS.map((b, i) => [String(i), b[0]]), '0')}</div>${X.cv('হুকের সূত্র')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:120px">k = <b data-kv></b> N/m<input type="range" min="300" max="2000" step="10" value="780" data-k></label><label class="small" style="flex:1;min-width:100px">m₁ = <b data-av></b> u<input type="range" min="1" max="35" step="1" value="16" data-a></label><label class="small" style="flex:1;min-width:100px">m₂ = <b data-bv></b> u<input type="range" min="1" max="35" step="1" value="1" data-b></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    let L = X.fit(c, () => 250), k = 780, m1 = 16, m2 = 1, t = 0, nm = 'O–H', bc = '#c0392b';
    const nu = (kk, a, b) => { const mu = a * b / (a + b) * 1.66054e-27; return Math.sqrt(kk / mu) / (2 * Math.PI * 2.99792e10); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const v = nu(k, m1, m2), mu = m1 * m2 / (m1 + m2);
      const cx = W / 2, cy = 70, r1 = 8 + Math.cbrt(m1) * 5, r2 = 8 + Math.cbrt(m2) * 5, L0 = 120, amp = 14, ph = Math.sin(t * v / 300), d1 = amp * ph * m2 / (m1 + m2), d2 = amp * ph * m1 / (m1 + m2);
      const xa = cx - L0 / 2 - d1, xb = cx + L0 / 2 + d2; g.strokeStyle = col.mu; g.lineWidth = 1.6; g.beginPath(); const nC = 12; for (let i = 0; i <= nC * 4; i++) { const f = i / (nC * 4), x = xa + r1 + (xb - r2 - xa - r1) * f, y = cy + Math.sin(f * nC * 2 * Math.PI) * (4 + k / 300); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke();
      M3.sphere(g, xa, cy, r1, '#555', '#bbb'); M3.sphere(g, xb, cy, r2, m2 <= 2 ? '#ddd' : '#555', '#fff'); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${bn(m1)} u`, xa, cy + r1 + 16); g.fillText(`${bn(m2)} u`, xb, cy + r2 + 16); g.fillText(nm, cx, 22);
      const sx = 30, sw = W - 60, sy = 170; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(sx, sy); g.lineTo(sx + sw, sy); g.stroke(); const Xs = w => sx + (4000 - w) / 3600 * sw; g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; [4000, 3000, 2000, 1000, 400].forEach(w => { g.fillText(bn(w), Xs(w), sy + 14); g.beginPath(); g.moveTo(Xs(w), sy - 3); g.lineTo(Xs(w), sy + 3); g.stroke(); }); g.fillText('cm⁻¹', sx + sw, sy + 26);
      BONDS.slice().sort((a, b) => nu(b[3], b[1], b[2]) - nu(a[3], a[1], a[2])).forEach((b, i) => { const w = nu(b[3], b[1], b[2]), x = Xs(w); g.fillStyle = b[4]; g.globalAlpha = 0.55; g.beginPath(); g.arc(x, sy, 3.5, 0, 7); g.fill(); g.globalAlpha = 1; g.font = `8.5px ${col.font}`; g.textAlign = 'center'; g.fillText(b[0], x, i % 2 ? sy + 38 : sy + 48); });
      const xv = Xs(Math.max(400, Math.min(4000, v))); g.fillStyle = bc; g.beginPath(); g.moveTo(xv, sy - 4); g.lineTo(xv - 7, sy - 18); g.lineTo(xv + 7, sy - 18); g.fill(); g.font = `bold 12px ${col.font}`; g.fillText(`${bn(Math.round(v))} cm⁻¹`, xv, sy - 24);
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`μ = ${bn(mu.toFixed(3))} u`, 12, H - 10);
    };
    const info = () => { const v = nu(k, m1, m2), mu = m1 * m2 / (m1 + m2); q('[data-kv]').textContent = bn(k); q('[data-av]').textContent = bn(m1); q('[data-bv]').textContent = bn(m2); out.innerHTML = `${TXB(`\\tilde{\\nu} = \\dfrac{1}{2\\pi c}\\sqrt{\\dfrac{k}{\\mu}},\\quad \\mu = \\dfrac{m_1 m_2}{m_1 + m_2} = ${mu.toFixed(3)}\\ \\text{u} \\;\\Rightarrow\\; \\tilde{\\nu} \\approx ${Math.round(v)}\\ \\text{cm}^{-1}`, true)}<div class="small">এটি একটি সরল মডেল (দুই পরমাণুর সরল ছন্দিত স্পন্দক); প্রকৃত অণুতে পাশের পরমাণু ও হাইড্রোজেন বন্ধন শৃঙ্গ কিছুটা সরায় — যেমন H বন্ধনে O–H দুর্বল হয়ে ৩৬০০ থেকে ৩৩০০ এ নামে ও চওড়া হয়।</div>`; };
    X.onSeg(el, 'bd', v => { const b = BONDS[+v]; [nm, m1, m2, k, bc] = [b[0], b[1], b[2], b[3], b[4]]; q('[data-k]').value = k; q('[data-a]').value = m1; q('[data-b]').value = m2; info(); });
    q('[data-k]').oninput = e => { k = +e.target.value; nm = 'নিজস্ব বন্ধন'; info(); }; q('[data-a]').oninput = e => { m1 = +e.target.value; nm = 'নিজস্ব বন্ধন'; info(); }; q('[data-b]').oninput = e => { m2 = +e.target.value; nm = 'নিজস্ব বন্ধন'; info(); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, () => 250); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
