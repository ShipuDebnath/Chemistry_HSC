/* ২য় পত্র অধ্যায় ২ visuals part 3 — 2.1: classification tree, Lewis electron-dot, orbital overlap (σ/π, LCAO density), hybridisation, ethane/ethene/ethyne 3D */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm, cross, dot } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = M3.ease;

/* ---------- extra molecules ---------- */
const ring = (n, R, els, bo, opt = {}) => { const a = [], b = []; for (let k = 0; k < n; k++) { const t = Math.PI / 2 + k * 2 * Math.PI / n; a.push([els[k], R * Math.cos(t), R * Math.sin(t), 0, Object.assign({ pn: [0, 0, 1] }, (opt.at || {})[k] || {})]); b.push([k, (k + 1) % n, bo[k]]); } return { a, b }; };
const LIB = M3.LIB;
LIB.propene = () => M3.mol({ name: 'প্রোপিন', a: [['C', 0, 0, 0], ['C', 1.34, 0, 0], ['C', 2.09, 1.30, 0]], b: [[0, 1, 2], [1, 2, 1]] });
LIB.propyne = () => M3.mol({ name: 'প্রোপাইন', a: [['C', 0, 0, 0], ['C', 1.20, 0, 0], ['C', 2.66, 0, 0]], b: [[0, 1, 3], [1, 2, 1]] });
LIB.cyclopropane = () => { const s = ring(3, 1.51 / Math.sqrt(3), ['C', 'C', 'C'], [1, 1, 1]); s.a.forEach(r => { delete r[4].pn; }); return M3.mol(Object.assign({ name: 'সাইক্লোপ্রোপেন' }, s)); };
LIB.pyridine = () => { const s = ring(6, 1.39, ['N', 'C', 'C', 'C', 'C', 'C'], [2, 1, 2, 1, 2, 1]); const m = M3.mol(Object.assign({ name: 'পিরিডিন' }, s)); return m; };
LIB.furan = () => { const s = ring(5, 1.17, ['O', 'C', 'C', 'C', 'C'], [1, 2, 1, 2, 1], { at: { 0: { geo: 'tri' } } }); return M3.mol(Object.assign({ name: 'ফিউরান' }, s)); };
LIB.thiophene = () => { const s = ring(5, 1.30, ['S', 'C', 'C', 'C', 'C'], [1, 2, 1, 2, 1], { at: { 0: { geo: 'tri' } } }); return M3.mol(Object.assign({ name: 'থায়োফিন' }, s)); };
LIB.pyrrole = () => { const s = ring(5, 1.18, ['N', 'C', 'C', 'C', 'C'], [1, 2, 1, 2, 1], { at: { 0: { geo: 'tri', lp: 1 } } }); return M3.mol(Object.assign({ name: 'পাইরোল' }, s)); };
LIB.naphthalene = () => { const h = 1.40 * Math.sqrt(3) / 2, a = [['C', 0, 0.70, 0], ['C', 0, -0.70, 0], ['C', h, 1.40, 0], ['C', 2 * h, 0.70, 0], ['C', 2 * h, -0.70, 0], ['C', h, -1.40, 0], ['C', -h, 1.40, 0], ['C', -2 * h, 0.70, 0], ['C', -2 * h, -0.70, 0], ['C', -h, -1.40, 0]].map(r => r.concat([{ pn: [0, 0, 1] }])); return M3.mol({ name: 'ন্যাপথালিন', a, b: [[0, 1, 1], [0, 2, 2], [2, 3, 1], [3, 4, 2], [4, 5, 1], [5, 1, 2], [0, 6, 1], [6, 7, 2], [7, 8, 1], [8, 9, 2], [9, 1, 1]] }); };
LIB.cyclohexene = () => { const s = ring(6, 1.45, ['C', 'C', 'C', 'C', 'C', 'C'], [2, 1, 1, 1, 1, 1]); s.a.forEach((r, k) => { r[3] = k > 1 ? (k % 2 ? 0.3 : -0.3) : 0; delete r[4].pn; }); return M3.mol(Object.assign({ name: 'সাইক্লোহেক্সিন' }, s)); };

/* ======================= ২.১ জৈব যৌগের শ্রেণিবিভাগ: বৃক্ষচিত্র ======================= */
const TREE = [
  ['root', 'জৈব যৌগ', null, '', null],
  ['acy', 'অচাক্রিক (মুক্ত শিকল / অ্যালিফেটিক)', 'root', 'কার্বন শিকলের প্রান্ত খোলা — সরল বা শাখান্বিত।', null],
  ['cyc', 'চাক্রিক (বদ্ধ শিকল)', 'root', 'কার্বন (বা অন্য) পরমাণু বলয় গঠন করে।', null],
  ['sat', 'সম্পৃক্ত', 'acy', 'কেবল C–C একক বন্ধন: অ্যালকেন CₙH₂ₙ₊₂।', 'butane'],
  ['uns', 'অসম্পৃক্ত', 'acy', 'অন্তত একটি C=C বা C≡C: অ্যালকিন CₙH₂ₙ, অ্যালকাইন CₙH₂ₙ₋₂।', 'propene'],
  ['homo', 'সমচাক্রিক (কার্বোসাইক্লিক)', 'cyc', 'বলয়ের সব পরমাণু কার্বন।', null],
  ['het', 'বিষমচাক্রিক (হেটেরোসাইক্লিক)', 'cyc', 'বলয়ে কার্বন ছাড়াও N, O বা S (হেটেরো পরমাণু)।', 'pyridine'],
  ['ali', 'অ্যালিসাইক্লিক', 'homo', 'বলয়যুক্ত কিন্তু ধর্মে অ্যালিফেটিকের মতো — সাইক্লোপ্রোপেন, সাইক্লোহেক্সেন।', 'cyclohexane'],
  ['aro', 'অ্যারোমেটিক (বেনজিনয়েড)', 'homo', 'বেনজিন বলয়যুক্ত: সমতলীয়, (4n+2) π ইলেকট্রন — বেনজিন, ন্যাপথালিন।', 'benzene']
];
const LEAF = { butane: ['বিউটেন', 'sat'], propene: ['প্রোপিন', 'uns'], propyne: ['প্রোপাইন', 'uns'], cyclopropane: ['সাইক্লোপ্রোপেন', 'ali'], cyclohexane: ['সাইক্লোহেক্সেন', 'ali'], cyclohexene: ['সাইক্লোহেক্সিন', 'ali'], benzene: ['বেনজিন', 'aro'], naphthalene: ['ন্যাপথালিন', 'aro'], pyridine: ['পিরিডিন', 'het'], furan: ['ফিউরান', 'het'], thiophene: ['থায়োফিন', 'het'], pyrrole: ['পাইরোল', 'het'] };
V.p2c2_classTree = {
  t: 'জৈব যৌগের শ্রেণিবিভাগ: অচাক্রিক ও চাক্রিক → সম্পৃক্ত, অসম্পৃক্ত, অ্যালিসাইক্লিক, অ্যারোমেটিক ও বিষমচাক্রিক — প্রতিটি শাখার ত্রিমাত্রিক উদাহরণ', k: ['3d', 'int'],
  cap: 'বৃক্ষচিত্রের যেকোনো শাখা বা নিচের উদাহরণ যৌগে চাপ দাও — ডানে সেই যৌগের ত্রিমাত্রিক মডেল আসে (টেনে ঘোরাও), শাখার পথ উজ্জ্বল হয়। বিষমচাক্রিক যৌগে হেটেরো পরমাণু (N নীল, O লাল, S হলুদ) বলয়ের অংশ। লক্ষ করো: সাইক্লোহেক্সেন ভাঁজ করা (চেয়ার), কিন্তু বেনজিন, পিরিডিন, ফিউরান সমতলীয় — অ্যারোমেটিক বলয়ের বৈশিষ্ট্য।',
  html: () => `${X.cv('জৈব যৌগের শ্রেণিবিভাগ')}<div class="ctl" style="flex-wrap:wrap;gap:4px" data-leaf></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), lf = el.querySelector('[data-leaf]');
    const hf = w => wide(w) ? 380 : 620;
    let L = X.fit(c, hf), sel = 'benzene', m = LIB.benzene(), t = 0; const cam = M3.cam({ yaw: 0.4, pitch: 0.6 });
    const pathTo = k => { const s = new Set(); let n = LEAF[k] ? LEAF[k][1] : k; while (n) { s.add(n); const r = TREE.find(z => z[0] === n); n = r ? r[2] : null; } return s; };
    lf.innerHTML = Object.entries(LEAF).map(([k, v]) => `<button class="btn sm" data-k="${k}">${v[0]}</button>`).join('');
    const choose = k => { sel = k; m = LIB[k](); cam.user = false; lf.querySelectorAll('[data-k]').forEach(b => b.classList.toggle('primary', b.dataset.k === k)); const node = TREE.find(z => z[0] === LEAF[k][1]); out.innerHTML = `<div><b>${LEAF[k][0]}</b> (${M3.formula(m)}) — শ্রেণি: <b>${node[1]}</b></div><div class="small">${node[3]}</div>`; };
    lf.querySelectorAll('[data-k]').forEach(b => { b.onclick = () => choose(b.dataset.k); });
    let boxes = [];
    C4.drag3d(c, cam, () => A.draw());
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), on = pathTo(sel);
      const tw = wd ? W * 0.56 : W, th = wd ? H : H * 0.52;
      const POS = { root: [0.5, 0.08], acy: [0.24, 0.30], cyc: [0.72, 0.30], sat: [0.12, 0.55], uns: [0.36, 0.55], homo: [0.6, 0.55], het: [0.88, 0.55], ali: [0.48, 0.82], aro: [0.74, 0.82] };
      const P = k => [10 + POS[k][0] * (tw - 20), 14 + POS[k][1] * (th - 28)];
      TREE.forEach(r => { if (!r[2]) return; const [x1, y1] = P(r[2]), [x2, y2] = P(r[0]), hot = on.has(r[0]); g.strokeStyle = hot ? col.acc : col.mu; g.lineWidth = hot ? 2.6 : 1.2; g.globalAlpha = hot ? 1 : 0.6; g.beginPath(); g.moveTo(x1, y1 + 10); g.bezierCurveTo(x1, (y1 + y2) / 2, x2, (y1 + y2) / 2, x2, y2 - 10); g.stroke(); g.globalAlpha = 1; });
      boxes = [];
      TREE.forEach(r => { const [x, y] = P(r[0]), hot = on.has(r[0]) || r[0] === 'root'; const lab = wd ? r[1] : r[1].replace(/ \(.*\)/, ''); g.font = `${hot ? 'bold ' : ''}${wd ? 10 : 9.5}px ${col.font}`; const w = Math.min(tw * (wd ? 0.4 : 0.3), g.measureText(lab).width + 14); g.fillStyle = hot ? col.acc : col.sf; g.strokeStyle = hot ? col.acc : col.mu; g.lineWidth = 1.2; rr(g, x - w / 2, y - 11, w, 22, 8); g.fill(); g.stroke(); g.fillStyle = hot ? '#fff' : col.fg; g.textAlign = 'center'; g.save(); g.beginPath(); g.rect(x - w / 2 + 2, y - 11, w - 4, 22); g.clip(); g.fillText(lab, x, y + 4); g.restore(); boxes.push([x - w / 2, y - 11, w, 22, r[0]]); });
      // 3D
      const mx = wd ? W * 0.78 : W / 2, my = wd ? H * 0.5 : th + (H - th) / 2, mw = wd ? W * 0.42 : W, mh = wd ? H : H - th;
      cam.cx = mx; cam.cy = my; M3.fit(m, cam, mw, mh - 30, 0.9); if (!cam.user) cam.yaw += 0.005;
      M3.render(g, m, cam, { mode: 'bs', col });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${LEAF[sel][0]} · ${M3.formula(m)}`, mx, my - mh / 2 + 18);
    };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, b = boxes.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (b) { const k = Object.keys(LEAF).find(z => LEAF[z][1] === b[4]); if (k) choose(k); } });
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    choose('benzene'); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১.২ সমযোজী বন্ধনের ইলেকট্রনীয় তত্ত্ব: লুইস ডট গঠন ======================= */
/* atoms: [el, x, y, valence e⁻, colour]; bonds [i, j, order] (layout units) */
const LD = {
  ch4: ['CH₄ (মিথেন)', [['C', 0, 0, 4, '#555'], ['H', 0, -1, 1, '#2d6fd6'], ['H', 1, 0, 1, '#2d6fd6'], ['H', 0, 1, 1, '#2d6fd6'], ['H', -1, 0, 1, '#2d6fd6']], [[0, 1, 1], [0, 2, 1], [0, 3, 1], [0, 4, 1]]],
  c2h6: ['C₂H₆ (ইথেন)', [['C', -0.6, 0, 4, '#555'], ['C', 0.6, 0, 4, '#8a5a2a'], ['H', -0.6, -1, 1, '#2d6fd6'], ['H', -1.6, 0, 1, '#2d6fd6'], ['H', -0.6, 1, 1, '#2d6fd6'], ['H', 0.6, -1, 1, '#2d6fd6'], ['H', 1.6, 0, 1, '#2d6fd6'], ['H', 0.6, 1, 1, '#2d6fd6']], [[0, 1, 1], [0, 2, 1], [0, 3, 1], [0, 4, 1], [1, 5, 1], [1, 6, 1], [1, 7, 1]]],
  c2h4: ['C₂H₄ (ইথিন)', [['C', -0.6, 0, 4, '#555'], ['C', 0.6, 0, 4, '#8a5a2a'], ['H', -1.3, -0.9, 1, '#2d6fd6'], ['H', -1.3, 0.9, 1, '#2d6fd6'], ['H', 1.3, -0.9, 1, '#2d6fd6'], ['H', 1.3, 0.9, 1, '#2d6fd6']], [[0, 1, 2], [0, 2, 1], [0, 3, 1], [1, 4, 1], [1, 5, 1]]],
  c2h2: ['C₂H₂ (ইথাইন)', [['C', -0.6, 0, 4, '#555'], ['C', 0.6, 0, 4, '#8a5a2a'], ['H', -1.6, 0, 1, '#2d6fd6'], ['H', 1.6, 0, 1, '#2d6fd6']], [[0, 1, 3], [0, 2, 1], [1, 3, 1]]],
  h2o: ['H₂O (পানি)', [['O', 0, 0, 6, '#cc2418'], ['H', -0.85, 0.75, 1, '#2d6fd6'], ['H', 0.85, 0.75, 1, '#2d6fd6']], [[0, 1, 1], [0, 2, 1]]],
  nh3: ['NH₃ (অ্যামোনিয়া)', [['N', 0, 0, 5, '#2a4fc4'], ['H', -1, 0.4, 1, '#888'], ['H', 1, 0.4, 1, '#888'], ['H', 0, 1.05, 1, '#888']], [[0, 1, 1], [0, 2, 1], [0, 3, 1]]],
  co2: ['CO₂ (কার্বন ডাইঅক্সাইড)', [['C', 0, 0, 4, '#555'], ['O', -1.2, 0, 6, '#cc2418'], ['O', 1.2, 0, 6, '#cc2418']], [[0, 1, 2], [0, 2, 2]]],
  ch3oh: ['CH₃OH (মিথানল)', [['C', -0.6, 0, 4, '#555'], ['O', 0.6, 0, 6, '#cc2418'], ['H', -0.6, -1, 1, '#2d6fd6'], ['H', -1.6, 0, 1, '#2d6fd6'], ['H', -0.6, 1, 1, '#2d6fd6'], ['H', 1.4, 0.7, 1, '#2d6fd6']], [[0, 1, 1], [0, 2, 1], [0, 3, 1], [0, 4, 1], [1, 5, 1]]]
};
V.p2c2_lewisDot = {
  t: 'সমযোজী বন্ধনের ইলেকট্রনীয় তত্ত্ব (লুইস-ল্যাংমুয়ার): ইলেকট্রন শেয়ার করে অষ্টক পূরণ — ডট-ক্রস গঠনের অ্যানিমেশন', k: ['anim', 'int', '2d'],
  cap: 'অণু বেছে নাও ও স্লাইডার টানো (বা চালাও)। শুরুতে প্রতিটি পরমাণু নিজের যোজ্যতা ইলেকট্রন নিয়ে আলাদা (প্রতিটি পরমাণুর ইলেকট্রন আলাদা রঙে)। কাছে আসার সাথে সাথে প্রতিটি পরমাণু একটি করে ইলেকট্রন দিয়ে বন্ধন জোড় তৈরি করে — একক বন্ধনে এক জোড়া, দ্বিবন্ধনে দুই জোড়া, ত্রিবন্ধনে তিন জোড়া। শেষে বিন্দু-রেখার বৃত্ত দেখায় প্রতিটি পরমাণুর চারপাশে ইলেকট্রন সংখ্যা: H এর ২ (ডুপ্লেট), অন্যদের ৮ (অষ্টক)। নিঃসঙ্গ জোড় (বন্ধনে অংশ নেয় না) আলাদা দেখায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ml', Object.entries(LD).map(([k, v]) => [k, v[0].split(' ')[0]]), 'ch4')}</div>${X.cv('লুইস ডট গঠন')}<div class="ctl"><label class="small" style="flex:1">বন্ধন গঠন <input type="range" min="0" max="1" step="0.01" value="1" data-s></label><button class="btn sm primary" data-play>▶ চালাও</button><label class="small"><input type="checkbox" data-oct checked> অষ্টক বৃত্ত</label><label class="small"><input type="checkbox" data-line> রেখা সংকেত</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 320;
    let L = X.fit(c, hf), ml = 'ch4', s = 1, play = false, oct = true, line = false;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const D = LD[ml], at = D[1], bd = D[2];
      const sc = Math.min(W / 4.4, H / 3.0, 90), cx = W / 2, cy = H / 2 + 4, k = ease(s), spread = 1 + 0.9 * (1 - k);
      const pos = at.map(a => [cx + a[1] * sc * spread, cy + a[2] * sc * spread]);
      // per-atom remaining electrons (for lone pairs) and bond pairs
      const used = at.map(() => 0); bd.forEach(([i, j, o]) => { used[i] += o; used[j] += o; });
      // bonds: electron pairs
      bd.forEach(([i, j, o]) => { const [x1, y1] = pos[i], [x2, y2] = pos[j], dx = x2 - x1, dy = y2 - y1, l = Math.hypot(dx, dy), ux = dx / l, uy = dy / l, nx = -uy, ny = ux;
        if (line && k > 0.95) { g.strokeStyle = col.fg; g.lineWidth = 2; for (let p = 0; p < o; p++) { const off = (p - (o - 1) / 2) * 6; g.beginPath(); g.moveTo(x1 + ux * 16 + nx * off, y1 + uy * 16 + ny * off); g.lineTo(x2 - ux * 16 + nx * off, y2 - uy * 16 + ny * off); g.stroke(); } return; }
        for (let p = 0; p < o; p++) { const off = (p - (o - 1) / 2) * 11, mx = (x1 + x2) / 2 + nx * off, my = (y1 + y2) / 2 + ny * off;
          // electron from atom i and atom j
          [[i, -1], [j, 1]].forEach(([a, sgn]) => { const [ax, ay] = pos[a]; const home = [ax + (sgn < 0 ? ux : -ux) * 22 + nx * off, ay + (sgn < 0 ? uy : -uy) * 22 + ny * off]; const fin = [mx + ux * sgn * 3.5, my + uy * sgn * 3.5]; const ex = home[0] + (fin[0] - home[0]) * k, ey = home[1] + (fin[1] - home[1]) * k; const ccol = at[a][4]; if (at[a][0] === 'H' || a % 2 === 0) { g.fillStyle = ccol; g.beginPath(); g.arc(ex, ey, 3.4, 0, 7); g.fill(); } else { g.strokeStyle = ccol; g.lineWidth = 2; g.beginPath(); g.moveTo(ex - 3, ey - 3); g.lineTo(ex + 3, ey + 3); g.moveTo(ex + 3, ey - 3); g.lineTo(ex - 3, ey + 3); g.stroke(); } });
          if (k > 0.9) { g.strokeStyle = col.acc; g.globalAlpha = (k - 0.9) * 6; g.lineWidth = 1; g.beginPath(); g.ellipse(mx, my, 9, 6, Math.atan2(uy, ux), 0, 7); g.stroke(); g.globalAlpha = 1; } } });
      // atoms + lone pairs
      at.forEach((a, i) => { const [x, y] = pos[i]; g.fillStyle = col.fg; g.font = `bold 20px ${col.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(a[0], x, y); g.textBaseline = 'alphabetic';
        const lone = a[3] - used[i]; if (lone > 0 && !(line && k > 0.95 && false)) { const dirs = []; const bdirs = bd.filter(b => b[0] === i || b[1] === i).map(b => { const o = b[0] === i ? b[1] : b[0]; return Math.atan2(pos[o][1] - y, pos[o][0] - x); }); for (let t = 0; t < 8; t++) { const an = t * Math.PI / 4 - Math.PI / 2; if (bdirs.every(b => Math.abs(Math.atan2(Math.sin(an - b), Math.cos(an - b))) > 0.7)) dirs.push(an); } const np = Math.floor(lone / 2); const pick = []; for (let t = 0; t < np && dirs.length; t++) { let best = 0, bs = -1; dirs.forEach((d, di) => { const sc2 = Math.min(...bdirs.concat(pick).map(b => Math.abs(Math.atan2(Math.sin(d - b), Math.cos(d - b)))), 9); if (sc2 > bs) { bs = sc2; best = di; } }); pick.push(dirs.splice(best, 1)[0]); } pick.forEach(an => { const r = 22, px = x + Math.cos(an) * r, py = y + Math.sin(an) * r, nx = -Math.sin(an), ny = Math.cos(an); [-1, 1].forEach(sg => { if (i % 2 === 0) { g.fillStyle = a[4]; g.beginPath(); g.arc(px + nx * 4 * sg, py + ny * 4 * sg, 3.4, 0, 7); g.fill(); } else { const ex = px + nx * 4 * sg, ey = py + ny * 4 * sg; g.strokeStyle = a[4]; g.lineWidth = 2; g.beginPath(); g.moveTo(ex - 3, ey - 3); g.lineTo(ex + 3, ey + 3); g.moveTo(ex + 3, ey - 3); g.lineTo(ex - 3, ey + 3); g.stroke(); } }); }); }
        if (oct && k > 0.97) { const ne = (a[0] === 'H' ? 0 : lone) + 2 * used[i]; const target = a[0] === 'H' ? 2 : 8; g.strokeStyle = ne === target ? '#2f9e44' : '#c0392b'; g.setLineDash([3, 3]); g.lineWidth = 1.2; g.beginPath(); g.arc(x, y, a[0] === 'H' ? 30 : 38, 0, 7); g.stroke(); g.setLineDash([]); g.fillStyle = ne === target ? '#2f9e44' : '#c0392b'; g.font = `bold 9.5px ${col.font}`; g.fillText(`${bn(ne)}e⁻`, x + (a[0] === 'H' ? 0 : 30), y - (a[0] === 'H' ? 33 : 34)); }
      });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(D[0], 10, 16);
    };
    const info = () => { const D = LD[ml], bd = D[2], tot = D[1].reduce((t, a) => t + a[3], 0), bp = bd.reduce((t, b) => t + b[2], 0), lp = (tot - 2 * bp) / 2; out.innerHTML = `<div><b>${D[0]}:</b> মোট যোজ্যতা ইলেকট্রন ${bn(tot)} · বন্ধন জোড় ${bn(bp)} · নিঃসঙ্গ জোড় ${bn(lp)}</div><div class="small">${bd.some(b => b[2] === 3) ? 'দুটি কার্বন তিন জোড়া ইলেকট্রন শেয়ার করে ত্রিবন্ধন (C≡C) গঠন করে।' : bd.some(b => b[2] === 2) ? 'দুই জোড়া ইলেকট্রন শেয়ার = দ্বিবন্ধন।' : 'প্রতিটি বন্ধনে দুটি পরমাণু একটি করে ইলেকট্রন দিয়ে একটি ইলেকট্রন জোড় শেয়ার করে।'} লুইস তত্ত্ব বন্ধনের সংখ্যা ব্যাখ্যা করে, কিন্তু অণুর ত্রিমাত্রিক আকৃতি বা বন্ধন কোণ ব্যাখ্যা করতে পারে না — তার জন্য অরবিটাল অধিক্রমণ ও সংকরণ তত্ত্ব লাগে।</div>`; };
    const A = X.anim(el, dt => { if (dt && play) { s = Math.min(1, s + dt * 0.4); q('[data-s]').value = s; if (s >= 1) play = false; } draw(); }, { paused: false });
    X.onSeg(el, 'ml', v => { ml = v; info(); });
    q('[data-s]').oninput = e => { s = +e.target.value; play = false; };
    q('[data-play]').onclick = () => { s = 0; play = true; };
    q('[data-oct]').onchange = e => { oct = e.target.checked; }; q('[data-line]').onchange = e => { line = e.target.checked; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১.৩ অরবিটাল অধিক্রমণ: σ ও π বন্ধন (LCAO তরঙ্গ অপেক্ষক মানচিত্র) ======================= */
/* modes: [label, ψA type, ψB type, re (Å), De (kJ/mol), a (Å⁻¹), example, ζ] */
const OV = {
  ss: ['s–s (σ)', 's', 's', 0.74, 436, 1.94, 'H₂: H(1s) + H(1s)', 1.24],
  sp: ['s–p (σ)', 's', 'px', 1.27, 431, 1.87, 'HCl: H(1s) + Cl(3p)', 1.1],
  pp: ['p–p মুখোমুখি (σ)', 'px', 'px', 1.99, 242, 2.0, 'Cl₂: Cl(3p) + Cl(3p)', 1.0],
  pi: ['p–p পাশাপাশি (π)', 'py', 'py', 1.34, 266, 2.3, 'ইথিনের C=C এর π অংশ (৬১৪ − ৩৪৮)', 1.6]
};
V.p2c2_overlap = {
  t: 'অরবিটাল অধিক্রমণ মতবাদ: s–s, s–p ও p–p মুখোমুখি অধিক্রমণে σ বন্ধন এবং পাশাপাশি অধিক্রমণে π বন্ধন — তরঙ্গ অপেক্ষকের মানচিত্র ও স্থিতিশক্তি লেখ', k: ['int', 'calc', '2d', 'anim'],
  cap: 'অধিক্রমণের ধরন বেছে নাও, তারপর স্লাইডারে দুই নিউক্লিয়াসের দূরত্ব বদলাও। মানচিত্রে রং তরঙ্গ অপেক্ষক ψ এর চিহ্ন দেখায় (নীল = +, লাল = −) আর উজ্জ্বলতা দেখায় তার মান কত বড়; সাদা রেখাগুলো সমান ইলেকট্রন ঘনত্বের রেখা। একই চিহ্নের অংশ মিললে (সম-দশা) নিউক্লিয়াস দুটির মাঝে ইলেকট্রন ঘনত্ব বাড়ে → বন্ধনী অরবিটাল; "বিপরীত দশা" বাছলে মাঝখানে নোড (শূন্য ঘনত্ব) হয় → প্রতিবন্ধনী অরবিটাল। σ বন্ধনে ঘনত্ব আন্তঃনিউক্লীয় অক্ষ বরাবর থাকে, অক্ষটিকে ঘিরে প্রতিসম। π বন্ধনে অক্ষের উপরে ও নিচে দুটি অংশ থাকে, আর অক্ষ বরাবর একটি নোডাল তল থাকে — তাই π বন্ধন দুর্বল। ডানের লেখচিত্র মোর্স বিভব: সবচেয়ে কম শক্তির বিন্দুতে বন্ধন দৈর্ঘ্য r₀, আর কূপের গভীরতা বন্ধন শক্তি।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', Object.entries(OV).map(([k, v]) => [k, v[0]]), 'ss')}${X.seg('ph', [['b', 'সম-দশা (বন্ধনী)'], ['a', 'বিপরীত দশা (প্রতিবন্ধনী)']], 'b')}</div>${X.cv('অরবিটাল অধিক্রমণ')}<div class="ctl"><label class="small" style="flex:1">আন্তঃনিউক্লীয় দূরত্ব r = <b data-rv></b> pm<input type="range" min="0" max="1" step="0.005" value="0.35" data-r></label><button class="btn sm" data-eq>r₀ এ নাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 520;
    let L = X.fit(c, hf), md = 'ss', ph = 'b', u = 0.35, img = null, key = '', t = 0;
    const rOf = () => { const o = OV[md], lo = o[3] * 0.55, hi = o[3] * 3.2; return lo + (hi - lo) * u; };
    const morse = (r, o) => o[4] * (Math.pow(1 - Math.exp(-o[5] * (r - o[3])), 2) - 1);
    const psi = (type, x, y, z_) => { const r = Math.hypot(x, y), o = OV[md], zt = o[7]; if (type === 's') return Math.exp(-zt * r * 1.6); if (type === 'px') return x * Math.exp(-zt * r * 1.1) * 1.3; return y * Math.exp(-zt * r * 1.1) * 1.3; void z_; };
    const field = (w, h, xs, ys) => { const o = OV[md], r = rOf(), xa = -r / 2, xb = r / 2, data = new Float32Array(w * h); let mx = 0; for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const x = (i / (w - 1) - 0.5) * xs, y = (0.5 - j / (h - 1)) * ys; const A = psi(o[1], x - xa, y), Bt = o[2] === 'px' && o[1] === 'px' ? -psi('px', x - xb, y) : o[2] === 'px' ? -psi('px', x - xb, y) : psi(o[2], x - xb, y); const v = A + (ph === 'b' ? 1 : -1) * Bt; data[j * w + i] = v; mx = Math.max(mx, Math.abs(v)); } return { data, mx }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), o = OV[md], r = rOf();
      const fw = wd ? W * 0.58 : W - 16, fh = wd ? H - 40 : 250, fx0 = 8, fy0 = 26, xs = Math.max(3.2, o[3] * 3.4 + 1.6), ys = xs * fh / fw;
      const gw = Math.round(fw / 3), gh = Math.round(fh / 3), k2 = `${md}${ph}${u.toFixed(3)}${gw}${gh}`;
      if (k2 !== key) { key = k2; const F = field(gw, gh, xs, ys); const id = new ImageData(gw, gh); for (let p = 0; p < gw * gh; p++) { const v = F.data[p] / F.mx, a = Math.min(1, Math.abs(v) * 1.15); const rgb = v >= 0 ? [40, 110, 235] : [225, 50, 45]; id.data[p * 4] = rgb[0]; id.data[p * 4 + 1] = rgb[1]; id.data[p * 4 + 2] = rgb[2]; id.data[p * 4 + 3] = Math.round(255 * Math.pow(a, 0.75)); } img = { id, F, gw, gh }; }
      const oc = document.createElement('canvas'); oc.width = img.gw; oc.height = img.gh; oc.getContext('2d').putImageData(img.id, 0, 0);
      g.fillStyle = col.s2 || col.sf; g.fillRect(fx0, fy0, fw, fh); g.imageSmoothingEnabled = true; g.drawImage(oc, fx0, fy0, fw, fh);
      // density contours (|ψ|² levels) via marching squares-lite (point sampling)
      g.fillStyle = 'rgba(255,255,255,.75)'; const lv = [0.08, 0.25, 0.5]; for (let j = 1; j < img.gh - 1; j++) for (let i = 1; i < img.gw - 1; i++) { const v = Math.pow(img.F.data[j * img.gw + i] / img.F.mx, 2), vr = Math.pow(img.F.data[j * img.gw + i + 1] / img.F.mx, 2), vd = Math.pow(img.F.data[(j + 1) * img.gw + i] / img.F.mx, 2); lv.forEach(l => { if ((v - l) * (vr - l) < 0 || (v - l) * (vd - l) < 0) g.fillRect(fx0 + i * fw / img.gw, fy0 + j * fh / img.gh, 1.3, 1.3); }); }
      // nuclei
      const X_ = x => fx0 + (x / xs + 0.5) * fw, Y_ = y => fy0 + (0.5 - y / ys) * fh; const nm = { ss: ['H', 'H'], sp: ['H', 'Cl'], pp: ['Cl', 'Cl'], pi: ['C', 'C'] }[md];
      [[-r / 2, nm[0]], [r / 2, nm[1]]].forEach(([x, n]) => { M3.sphere(g, X_(x), Y_(0), n === 'H' ? 6 : 8, n === 'H' ? '#bbbbbb' : n === 'Cl' ? '#1c9a1c' : '#333', '#fff'); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(n, X_(x), Y_(0) + 22); });
      g.strokeStyle = 'rgba(255,255,255,.5)'; g.setLineDash([3, 4]); g.beginPath(); g.moveTo(fx0, Y_(0)); g.lineTo(fx0 + fw, Y_(0)); g.stroke(); g.setLineDash([]);
      if (md === 'pi') { g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('নোডাল তল (অক্ষ বরাবর)', fx0 + 6, Y_(0) - 4); }
      if (ph === 'a') { g.strokeStyle = '#ffd43b'; g.lineWidth = 1.5; g.setLineDash([5, 3]); g.beginPath(); g.moveTo(X_(0), fy0); g.lineTo(X_(0), fy0 + fh); g.stroke(); g.setLineDash([]); g.fillStyle = '#ffd43b'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('নোড', X_(0), fy0 + 12); }
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`${o[0]} — ${o[6]}`, fx0, 16);
      // Morse plot
      const px0 = wd ? W * 0.66 : 56, py0 = wd ? 30 : fy0 + fh + 30, pw = wd ? W * 0.31 : W - 76, ph2 = wd ? H - 80 : H - py0 - 44, De = o[4];
      const rmin = o[3] * 0.55, rmax = o[3] * 3.2;
      const Pl = cplot(g, { x0: px0, y0: py0, w: pw, h: ph2, xmin: rmin * 100, xmax: rmax * 100, ymin: -De * 1.15, ymax: De * 0.9, col, xt: [Math.round(rmin * 100), Math.round(o[3] * 100), Math.round(rmax * 100)], yt: [-De, 0], xl: 'r (pm)', yl: 'E (kJ mol⁻¹)', fy: v => bn(Math.round(v)), ylx: 34 });
      const pts = []; for (let rr2 = rmin; rr2 <= rmax; rr2 += (rmax - rmin) / 120) { const e = ph === 'b' ? morse(rr2, o) : De * 0.9 * Math.exp(-1.6 * (rr2 - o[3])) - 0.0; pts.push([Pl.X(rr2 * 100), Pl.Y(Math.max(-De * 1.15, Math.min(De * 0.9, e)))]); } path(g, pts, ph === 'b' ? '#2f9e44' : '#c0392b', 2.4);
      const e = ph === 'b' ? morse(r, o) : De * 0.9 * Math.exp(-1.6 * (r - o[3])); M3.sphere(g, Pl.X(r * 100), Pl.Y(Math.max(-De * 1.15, Math.min(De * 0.9, e))), 6, '#f39c12', '#ffe0a0');
      if (ph === 'b') { g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(Pl.X(o[3] * 100), Pl.Y(-De)); g.lineTo(Pl.X(o[3] * 100), Pl.Y(0)); g.stroke(); g.setLineDash([]); g.fillStyle = col.acc; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`De = ${bn(De)}`, Pl.X(o[3] * 100) + 4, Pl.Y(-De / 2)); }
    };
    const info = () => { const o = OV[md], r = rOf(), e = ph === 'b' ? morse(r, o) : null; q('[data-rv]').textContent = bn(Math.round(r * 100)); out.innerHTML = `<div><b>${o[0]}</b>: বন্ধন দৈর্ঘ্য r₀ = ${bn(Math.round(o[3] * 100))} pm, বন্ধন শক্তি ≈ ${bn(o[4])} kJ mol⁻¹। ${ph === 'b' ? `বর্তমান দূরত্বে স্থিতিশক্তি ${bn(Math.round(e))} kJ mol⁻¹ — ${r < o[3] * 0.92 ? 'খুব কাছে: নিউক্লিয়াস-নিউক্লিয়াস বিকর্ষণে শক্তি দ্রুত বাড়ে।' : r > o[3] * 1.1 ? 'দূরে: অধিক্রমণ কম, আকর্ষণ দুর্বল।' : 'সর্বোত্তম অধিক্রমণ — ন্যূনতম শক্তি।'}` : 'প্রতিবন্ধনী অবস্থা: নিউক্লিয়াস দুটির মাঝে নোড, ঘনত্ব বাইরের দিকে ঠেলে দেওয়া — শক্তি সব দূরত্বেই বেশি, বন্ধন গঠিত হয় না।'}</div><div class="small" style="margin-top:4px">${md === 'pi' ? 'π বন্ধনে পার্শ্বিক অধিক্রমণ কম, তাই এটি σ এর চেয়ে দুর্বল (ইথিনে π ≈ ২৬৬ বনাম σ ≈ ৩৪৮ kJ mol⁻¹) এবং বেশি সক্রিয় — অ্যালকিন সংযোজন বিক্রিয়া দেয়। π বন্ধন থাকলে C=C অক্ষে ঘূর্ণন সম্ভব নয়।' : 'σ বন্ধন আন্তঃনিউক্লীয় অক্ষ বরাবর মুখোমুখি অধিক্রমণে তৈরি — অক্ষের চারদিকে প্রতিসম, তাই σ বন্ধনের চারদিকে মুক্ত ঘূর্ণন সম্ভব।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: true });
    X.onSeg(el, 'md', v => { md = v; info(); A.draw(); }); X.onSeg(el, 'ph', v => { ph = v; info(); A.draw(); });
    const ri = q('[data-r]'); ri.oninput = () => { u = +ri.value; info(); A.draw(); };
    q('[data-eq]').onclick = () => { const o = OV[md]; u = (o[3] - o[3] * 0.55) / (o[3] * 3.2 - o[3] * 0.55); ri.value = u; info(); A.draw(); };
    q('[data-eq]').click();
    const un = X.onResize(el, () => { L = X.fit(c, hf); key = ''; A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১.৪–২.১.৭ সংকরণ: sp³, sp², sp ======================= */
const HY = {
  sp3: { nm: 'sp³', n: 4, s: 25, ang: '১০৯.৫°', shape: 'চতুস্তলকীয়', dirs: (() => { const s = 1 / Math.sqrt(3); return [[s, s, s], [-s, -s, s], [-s, s, -s], [s, -s, -s]]; })(), p: [], ex: 'CH₄' },
  sp2: { nm: 'sp²', n: 3, s: 33.3, ang: '১২০°', shape: 'ত্রিকোণাকার সমতলীয়', dirs: [[1, 0, 0], [-0.5, 0.866, 0], [-0.5, -0.866, 0]], p: [[0, 0, 1]], ex: 'C₂H₄' },
  sp: { nm: 'sp', n: 2, s: 50, ang: '১৮০°', shape: 'রৈখিক', dirs: [[1, 0, 0], [-1, 0, 0]], p: [[0, 1, 0], [0, 0, 1]], ex: 'C₂H₂' }
};
const STG = ['ভূমি অবস্থা', 'উত্তেজিত অবস্থা', 'সংকরণ (মিশ্রণ)', 'সংকর অরবিটাল', 'বন্ধন গঠন'];
V.p2c2_hybrid = {
  t: 'কার্বনের অরবিটাল সংকরণ: ভূমি অবস্থা → উত্তেজিত অবস্থা → sp³, sp² ও sp সংকর অরবিটাল → CH₄, C₂H₄, C₂H₂ এ বন্ধন গঠন (ত্রিমাত্রিক অরবিটাল)', k: ['3d', 'anim', 'int'],
  cap: 'সংকরণের ধরন বেছে নাও এবং ধাপ এগিয়ে নাও (বা চালাও)। বাঁয়ে শক্তিস্তর চিত্রে ইলেকট্রন (তীর) কীভাবে সরে: ভূমি অবস্থায় 2s² 2p² (মাত্র দুটি অযুগ্ম ইলেকট্রন), উত্তেজিত অবস্থায় একটি 2s ইলেকট্রন খালি 2p তে উঠে চারটি অযুগ্ম ইলেকট্রন, তারপর s ও p মিশে সমশক্তির সংকর অরবিটাল। ডানে ত্রিমাত্রিক অরবিটাল (টেনে ঘোরাও): গোলাকার s ও ডাম্বেল আকৃতির p অরবিটাল থেকে সংকর লোব তৈরি হয় — বড় সামনের লোব ও ছোট পেছনের লোব। শেষ ধাপে H এর 1s (ও দ্বিতীয় কার্বন) এসে σ বন্ধন গঠন করে; sp² ও sp তে অসংকরিত p অরবিটাল পাশাপাশি মিলে π বন্ধন হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('hy', [['sp3', 'sp³'], ['sp2', 'sp²'], ['sp', 'sp']], 'sp3')}<button class="btn sm" data-pv>◀</button><button class="btn sm" data-nx>পরের ধাপ ▶</button><button class="btn sm primary" data-play>▶ চালাও</button></div>${X.cv('কার্বনের সংকরণ')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 380 : 620;
    let L = X.fit(c, hf), hy = 'sp3', st = 0, sv = 0, play = false, t = 0, lastInfo = ''; const cam = M3.cam({ yaw: 0.6, pitch: 0.35 });
    C4.drag3d(c, cam, () => A.draw());
    const levels = (g, x0, y0, w, h, col) => {
      const Hd = HY[hy], k = Math.min(4, Math.floor(sv)), f = sv - k, box = Math.min(26, w / 7);
      const yS = y0 + h * 0.78, yP = y0 + h * 0.38, yH = y0 + h * 0.56;
      const arrow = (x, y, up, a = 1) => { g.save(); g.globalAlpha = a; g.strokeStyle = col.acc; g.fillStyle = col.acc; g.lineWidth = 1.8; const dx = up ? -4 : 4, l = box * 0.62; g.beginPath(); g.moveTo(x + dx, y + (up ? l / 2 : -l / 2)); g.lineTo(x + dx, y + (up ? -l / 2 : l / 2)); g.stroke(); g.beginPath(); g.moveTo(x + dx, y + (up ? -l / 2 - 3 : l / 2 + 3)); g.lineTo(x + dx - 3, y + (up ? -l / 2 + 3 : l / 2 - 3)); g.lineTo(x + dx + 3, y + (up ? -l / 2 + 3 : l / 2 - 3)); g.fill(); g.restore(); };
      const boxAt = (x, y, lab) => { g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(x - box / 2, y - box / 2, box, box); if (lab) { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(lab, x, y + box / 2 + 11); } };
      const cx = x0 + w / 2;
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('শক্তি ↑', x0, y0 + 10);
      if (k <= 1) {
        // s box and 3 p boxes
        const mv = k === 0 ? (f > 0 ? ease(f) : 0) : 1; // electron promotion progress during stage 0→1
        boxAt(cx - box * 2, yS, '2s'); [0, 1, 2].forEach(i => boxAt(cx - box * 0.5 + i * box * 1.15, yP, ['2pₓ', '2pᵧ', '2p_z'][i]));
        arrow(cx - box * 2, yS, true); arrow(cx - box * 0.5, yP, true); arrow(cx - box * 0.5 + box * 1.15, yP, true);
        // second s electron moves to pz
        const sx = cx - box * 2, sy = yS, ex = cx - box * 0.5 + 2 * box * 1.15, ey = yP, p = k === 1 ? 1 : mv; arrow(sx + (ex - sx) * p + (p > 0 && p < 1 ? 0 : 0), sy + (ey - sy) * p, p > 0.5);
        if (k === 0 && f > 0.05 || k === 1) { g.fillStyle = '#e67e22'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('উত্তেজনা (≈৪০৬ kJ mol⁻¹)', cx, (yS + yP) / 2 + 2); }
      } else {
        const n = Hd.n, np = 4 - n, mix = k === 2 ? ease(f) : 1;
        for (let i = 0; i < n; i++) { const x = cx - (n + np - 1) * box * 0.6 + i * box * 1.2; boxAt(x, yS + (yH - yS) * mix * 1 + (yP - yS) * 0 * mix, k >= 3 ? Hd.nm : ''); arrow(x, yS + (yH - yS) * mix, true); }
        for (let i = 0; i < np; i++) { const x = cx - (n + np - 1) * box * 0.6 + (n + i) * box * 1.2; boxAt(x, yP, '2p'); arrow(x, yP, true); }
        if (k >= 3) { g.fillStyle = col.acc; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(`${bn(n)}টি সমশক্তির ${Hd.nm} (s-বৈশিষ্ট্য ${bn(Hd.s)}%)`, cx, yS + 6); }
      }
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(STG[Math.round(Math.min(4, sv))], cx, y0 + 12);
    };
    const orbitals = (g, cx, cy, sc, col) => {
      const Hd = HY[hy], k = Math.min(4, Math.floor(sv)), f = sv - k; cam.cx = cx; cam.cy = cy; cam.sc = sc; cam.D = 30; if (!cam.user) { if (sv > 3.001 && hy !== 'sp3') { cam.yaw = 0.3 * Math.sin(t * 0.35); cam.pitch += (0.95 - cam.pitch) * 0.05; } else { cam.yaw += 0.004; cam.pitch += (0.35 - cam.pitch) * 0.05; } }
      const P = M3.projector(cam, [0, 0, 0]), lobes = [], extra = []; let ctr = [0, 0, 0];
      const pAx = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
      const S = k <= 1 ? 1 : k === 2 ? 1 - ease(f) : 0;
      const pW = 0.7;
      if (k <= 2) {
        // s orbital sphere + 3 p dumbbells (fading in stage 2)
        if (S > 0.01) extra.push({ z: 0, draw: (g2, P2_) => { const p = P2_([0, 0, 0]), r = 0.75 * sc * p[3]; g2.save(); g2.globalAlpha = 0.45 * S; const gr = g2.createRadialGradient(p[0] - r * 0.3, p[1] - r * 0.3, r * 0.1, p[0], p[1], r); gr.addColorStop(0, '#bfe0ff'); gr.addColorStop(1, '#3d7fd9'); g2.fillStyle = gr; g2.beginPath(); g2.arc(p[0], p[1], r, 0, 7); g2.fill(); g2.restore(); } });
        pAx.forEach((ax, i) => { const keep = k === 2 && i >= Hd.n - 1 ? 1 : S; [1, -1].forEach(sg => lobes.push({ o: [0, 0, 0], d: mul(ax, sg), len: 1.25, w: pW, col: sg > 0 ? '#3d7fd9' : '#d9433d', a: 0.55 * keep, stroke: 'rgba(0,0,0,.25)' })); });
        if (k === 2) { const mix = ease(f); Hd.dirs.forEach(d => { lobes.push({ o: [0, 0, 0], d, len: 1.55 * mix, w: 0.85 * mix + 0.01, col: '#7b4fd6', a: 0.7 * mix, stroke: 'rgba(0,0,0,.3)' }); lobes.push({ o: [0, 0, 0], d: mul(d, -1), len: 0.4 * mix, w: 0.4 * mix + 0.01, col: '#d9433d', a: 0.6 * mix }); }); }
      } else {
        // hybrid orbitals (+ unhybridised p) on one or two carbons
        const bond = ease(Math.max(0, Math.min(1, sv - 3))), bonding = sv > 3.001, two = bonding && hy !== 'sp3';
        const blen = hy === 'sp2' ? 1.34 : 1.20, sep = 4.4 + (blen * 1.45 - 4.4) * bond;
        const Cs = two ? [{ o: [-sep / 2 * bond, 0, 0], m: 1 }, { o: [-sep / 2 * bond + sep, 0, 0], m: -1 }] : [{ o: [0, 0, 0], m: 1 }]; if (two) ctr = [(Cs[0].o[0] + Cs[1].o[0]) / 2, 0, 0];
        const hydro = (pos) => extra.push({ z3: pos, draw: (g2, P2_) => { const p = P2_(pos), r = 0.62 * sc * p[3]; g2.save(); g2.globalAlpha = 0.5; const gr = g2.createRadialGradient(p[0] - r * 0.3, p[1] - r * 0.3, 1, p[0], p[1], r); gr.addColorStop(0, '#d7ecff'); gr.addColorStop(1, '#3d7fd9'); g2.fillStyle = gr; g2.beginPath(); g2.arc(p[0], p[1], r, 0, 7); g2.fill(); g2.restore(); M3.sphere(g2, p[0], p[1], 0.16 * sc * p[3], '#cfcfcf', '#fff'); g2.fillStyle = col.fg; g2.font = `bold 9px ${col.font}`; g2.textAlign = 'center'; g2.fillText('H', p[0], p[1] - r - 3); } });
        Cs.forEach(C => {
          const D = Hd.dirs.map(d => [d[0] * C.m, d[1], d[2]]);
          D.forEach(d => { lobes.push({ o: C.o, d, len: 1.55, w: 0.85, col: '#7b4fd6', a: 0.62, stroke: 'rgba(0,0,0,.3)' }); lobes.push({ o: C.o, d: mul(d, -1), len: 0.4, w: 0.4, col: '#d9433d', a: 0.5 }); });
          Hd.p.forEach(ax => [1, -1].forEach(sg => lobes.push({ o: C.o, d: mul(ax, sg), len: 1.25, w: pW + (two ? 0.25 * bond : 0), col: sg > 0 ? '#3d7fd9' : '#d9433d', a: 0.5, stroke: 'rgba(0,0,0,.25)' })));
          extra.push({ z3: C.o, draw: (g2, P2_) => { const p = P2_(C.o); M3.sphere(g2, p[0], p[1], 0.3 * sc * p[3], '#303030', '#9a9a9a'); } });
          if (bonding) D.forEach((d, i) => { if (two && i === 0) return; hydro(add(C.o, mul(d, 4.0 + (1.09 * 1.45 - 4.0) * bond))); });
        });
        if (two && bond > 0.95) extra.push({ z: 9, draw: (g2) => { g2.fillStyle = '#2f6fd6'; g2.font = `bold 11px ${col.font}`; g2.textAlign = 'center'; g2.fillText(hy === 'sp2' ? 'p–p পাশাপাশি অধিক্রমণ → ১টি π বন্ধন' : 'দুই জোড়া p → ২টি π বন্ধন (পরস্পর লম্ব)', cx, cy - sc * 2.7); } });
      }
      if (k <= 2) extra.push({ z: 0.01, draw: (g2, P2_) => { const p = P2_([0, 0, 0]); M3.sphere(g2, p[0], p[1], 0.3 * sc * p[3], '#303030', '#9a9a9a'); } });
      M3.render(g, { a: [], b: [], c: ctr }, cam, { lobes, extra, col });
      // angle annotation on hybrid stage
      if (k === 3 && f < 0.02) { const d0 = Hd.dirs[0], d1 = Hd.dirs[1]; const arc = []; for (let s2 = 0; s2 <= 1.0001; s2 += 0.1) arc.push(P(mul(norm(add(mul(d0, 1 - s2), mul(d1, s2))), 0.9))); g.strokeStyle = '#f39c12'; g.lineWidth = 2; g.beginPath(); arc.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.stroke(); const mp = P(mul(norm(add(d0, d1)), hy === 'sp' ? 0.0 : 1.25)); g.fillStyle = '#f39c12'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(Hd.ang, hy === 'sp' ? mp[0] : mp[0], hy === 'sp' ? mp[1] - sc * 1.2 : mp[1]); }
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (wd) { levels(g, 10, 10, W * 0.36, H - 20, col); orbitals(g, W * 0.7, H * 0.54, Math.min(W * 0.085, H * 0.15), col); }
      else { levels(g, 10, 10, W - 20, 220, col); orbitals(g, W / 2, 230 + (H - 230) / 2, Math.min(W * 0.12, 54), col); }
      const lab = `${hy}${Math.round(Math.min(4, sv))}`; if (lab !== lastInfo) { lastInfo = lab; info(); }
    };
    const info = () => { const Hd = HY[hy], k = Math.round(Math.min(4, sv)); const T = [
      'কার্বনের ভূমি অবস্থার বিন্যাস 1s² 2s² 2p¹ₓ 2p¹ᵧ — মাত্র দুটি অযুগ্ম ইলেকট্রন, অর্থাৎ দ্বিযোজী হওয়ার কথা। কিন্তু কার্বন প্রায় সবসময় চতুর্যোজী।',
      'একটি 2s ইলেকট্রন খালি 2p_z অরবিটালে উন্নীত হয়: 1s² 2s¹ 2p¹ₓ 2p¹ᵧ 2p¹_z — চারটি অযুগ্ম ইলেকট্রন। দুটি অতিরিক্ত বন্ধন গঠনে যে শক্তি নির্গত হয়, তা উত্তেজনার শক্তির চেয়ে বেশি।',
      `${Hd.nm} সংকরণে একটি 2s ও ${bn(Hd.n - 1)}টি 2p অরবিটাল মিশে ${bn(Hd.n)}টি সমশক্তি ও সমআকৃতির নতুন অরবিটাল তৈরি হয়। ${Hd.p.length ? `বাকি ${bn(Hd.p.length)}টি p অরবিটাল অসংকরিত থাকে।` : ''}`,
      `${bn(Hd.n)}টি ${Hd.nm} অরবিটাল পরস্পর থেকে যতদূর সম্ভব দূরে থাকে: ${Hd.shape}, কোণ ${Hd.ang}। প্রতিটির s-বৈশিষ্ট্য ${bn(Hd.s)}%। সংকর অরবিটালের একদিকে বড় লোব থাকে, তাই এটি সাধারণ p অরবিটালের চেয়ে ভালো অধিক্রমণ করে।`,
      hy === 'sp3' ? 'চারটি sp³ অরবিটাল চারটি H এর 1s এর সাথে মুখোমুখি অধিক্রমণে চারটি সমান C–H σ বন্ধন তৈরি করে → CH₄ (চতুস্তলকীয়, H–C–H ১০৯.৫°, C–H ১০৯ pm)।' : hy === 'sp2' ? 'প্রতিটি C এর দুটি sp² দুটি H এর সাথে, তৃতীয়টি অন্য C এর sp² এর সাথে σ বন্ধন করে; অসংকরিত p_z দুটি পাশাপাশি অধিক্রমণে π বন্ধন তৈরি করে → C₂H₄ এর C=C (১σ + ১π), সমতলীয় অণু।' : 'প্রতিটি C এর একটি sp একটি H এর সাথে, অন্যটি অন্য C এর sp এর সাথে σ বন্ধন করে; দুই জোড়া অসংকরিত p (pᵧ, p_z) পাশাপাশি অধিক্রমণে দুটি পরস্পর লম্ব π বন্ধন → C₂H₂ এর C≡C (১σ + ২π), রৈখিক অণু।'][k];
      out.innerHTML = `<div><b>${STG[k]} · ${Hd.nm}:</b> ${T}</div><div class="small" style="margin-top:4px">${Hd.nm}: ${Hd.shape} · কোণ ${Hd.ang} · s-বৈশিষ্ট্য ${bn(Hd.s)}% · উদাহরণ ${Hd.ex}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (play) { st = Math.min(4, st + dt * 0.4); if (st >= 4) play = false; } sv += (st - sv) * Math.min(1, dt * 3); if (Math.abs(st - sv) < 0.01) sv = st; } draw(); }, { paused: false });
    X.onSeg(el, 'hy', v => { hy = v; st = sv = 0; play = false; lastInfo = ''; });
    q('[data-nx]').onclick = () => { play = false; st = Math.min(4, Math.round(st) + 1); };
    q('[data-pv]').onclick = () => { play = false; st = Math.max(0, Math.round(st) - 1); sv = st; };
    q('[data-play]').onclick = () => { st = sv = 0; play = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১.৮ ইথেন, ইথিন ও ইথাইন: ত্রিমাত্রিক গঠন, বন্ধন কোণ, দৈর্ঘ্য ও ঘূর্ণন ======================= */
const rad = d => d * Math.PI / 180;
const HCX = {
  methane: () => { const s = 1 / Math.sqrt(3), d = 1.087, D = [[s, s, s], [-s, -s, s], [-s, s, -s], [s, -s, -s]]; return M3.mol({ name: 'মিথেন', a: [['C', 0, 0, 0]].concat(D.map(v => ['H', v[0] * d, v[1] * d, v[2] * d])), b: [[0, 1], [0, 2], [0, 3], [0, 4]], H: false }); },
  ethane: () => { const cc = 1.535, ch = 1.094, a = rad(111.2), x = cc / 2, at = [['C', -x, 0, 0], ['C', x, 0, 0]], b = [[0, 1]]; [90, 210, 330].forEach(f => { at.push(['H', -x + ch * Math.cos(a), ch * Math.sin(a) * Math.cos(rad(f)), ch * Math.sin(a) * Math.sin(rad(f))]); b.push([0, at.length - 1]); }); [30, 150, 270].forEach(f => { at.push(['H', x - ch * Math.cos(a), ch * Math.sin(a) * Math.cos(rad(f)), ch * Math.sin(a) * Math.sin(rad(f))]); b.push([1, at.length - 1]); }); return M3.mol({ name: 'ইথেন', a: at, b, H: false }); },
  ethene: () => { const cc = 1.339, ch = 1.086, a = rad(121.3), x = cc / 2, at = [['C', -x, 0, 0], ['C', x, 0, 0]]; [1, -1].forEach(sg => at.push(['H', -x + ch * Math.cos(a), sg * ch * Math.sin(a), 0])); [1, -1].forEach(sg => at.push(['H', x - ch * Math.cos(a), sg * ch * Math.sin(a), 0])); return M3.mol({ name: 'ইথিন', a: at, b: [[0, 1, 2], [0, 2], [0, 3], [1, 4], [1, 5]], H: false }); },
  ethyne: () => { const x = 1.203 / 2, ch = 1.063; return M3.mol({ name: 'ইথাইন', a: [['C', -x, 0, 0], ['C', x, 0, 0], ['H', -x - ch, 0, 0], ['H', x + ch, 0, 0]], b: [[0, 1, 3], [0, 2], [1, 3]], H: false }); }
};
const HCD = {
  methane: { nm: 'মিথেন CH₄', hyb: 'sp³', cc: '—', ch: '১০৮.৭', ang: 'H–C–H ১০৯.৫°', be: '—', pka: '৪৮–৫০', meas: [[0, 1], [1, 0, 2]], bar: 0 },
  ethane: { nm: 'ইথেন C₂H₆', hyb: 'sp³', cc: '১৫৪', ch: '১০৯.৪', ang: 'H–C–H ১০৭.৭°, H–C–C ১১১.২°', be: '৩৪৮', pka: '৫০', meas: [[0, 1], [1, 5], [2, 0, 3], [6, 1, 0]], bar: 12 },
  ethene: { nm: 'ইথিন C₂H₄', hyb: 'sp²', cc: '১৩৪', ch: '১০৮.৬', ang: 'H–C–H ১১৭.৪°, H–C–C ১২১.৩°', be: '৬১৪', pka: '৪৪', meas: [[0, 1], [1, 5], [2, 0, 3], [4, 1, 0]], bar: 264 },
  ethyne: { nm: 'ইথাইন C₂H₂', hyb: 'sp', cc: '১২০', ch: '১০৬.৩', ang: 'H–C–C ১৮০°', be: '৮৩৯', pka: '২৫', meas: [[0, 1], [1, 3], [2, 0, 1]], bar: 0 }
};
V.p2c2_hc3d = {
  t: 'মিথেন, ইথেন, ইথিন ও ইথাইনের ত্রিমাত্রিক গঠন: পরীক্ষালব্ধ বন্ধন দৈর্ঘ্য ও কোণ পরিমাপ, π ইলেকট্রন মেঘ এবং C–C অক্ষে ঘূর্ণন (মুক্ত বনাম বাধাপ্রাপ্ত)', k: ['3d', 'int', 'calc'],
  cap: 'অণু বেছে নাও; মডেল টেনে ঘোরাও। "পরিমাপ" চালু থাকলে পরীক্ষালব্ধ জ্যামিতি থেকে বন্ধন দৈর্ঘ্য (pm) ও কোণ সরাসরি মাপা হয়। "π মেঘ" দেখায় ইথিনের আণবিক তলের উপরে-নিচে একটি π মেঘ আর ইথাইনের C≡C অক্ষ ঘিরে দুটি লম্ব π মেঘ (মিলে একটি সিলিন্ডারের মতো)। "C–C ঘূর্ণন" স্লাইডার একটি কার্বনের অংশকে C–C অক্ষে ঘোরায়: ইথেনে শক্তি বাধা মাত্র ~১২ kJ mol⁻¹, তাই সাধারণ তাপমাত্রায় মুক্ত ঘূর্ণন চলে; ইথিনে ঘোরালে p অরবিটাল দুটি সমান্তরাল থাকে না, π অধিক্রমণ ভেঙে যায় (৯০° তে শূন্য) — বাধা ~২৬৪ kJ mol⁻¹, তাই C=C অক্ষে ঘূর্ণন বাধাপ্রাপ্ত। এখান থেকেই জ্যামিতিক সমাণুতার জন্ম।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ml', [['methane', 'মিথেন'], ['ethane', 'ইথেন'], ['ethene', 'ইথিন'], ['ethyne', 'ইথাইন']], 'ethene')}${X.seg('md', [['bs', 'বল-স্টিক'], ['sf', 'স্থান-পূরক']], 'bs')}</div>${X.cv('হাইড্রোকার্বনের ত্রিমাত্রিক গঠন')}<div class="ctl" style="flex-wrap:wrap"><label class="small"><input type="checkbox" data-ms checked> পরিমাপ</label><label class="small"><input type="checkbox" data-pi checked> π মেঘ</label><label class="small" style="flex:1;min-width:150px" data-rotw>C–C ঘূর্ণন θ = <b data-thv>০</b>°<input type="range" min="0" max="180" step="1" value="0" data-th></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 560;
    let L = X.fit(c, hf), ml = 'ethene', mode = 'bs', ms = true, pi = true, th = 0, t = 0, base = HCX.ethene(); const cam = M3.cam({ yaw: 0.5, pitch: 0.45 });
    C4.drag3d(c, cam, () => A.draw());
    const cur = () => { const m = M3.clone(base); if ((ml === 'ethane' || ml === 'ethene') && th) { const side = M3.side(m, 0, 1).filter(k => k !== 0); M3.rotateAbout(m, 0, 1, side.filter(k => m.a[k].el === 'H'), rad(th)); M3.offsets(m); } return m; };
    const energy = th2 => ml === 'ethane' ? 12 * (1 - Math.cos(rad(3 * th2))) / 2 : ml === 'ethene' ? 264 * Math.pow(Math.sin(rad(th2)), 2) : 0;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), m = cur();
      const mw = wd ? W * 0.62 : W, mh = wd ? H : H * 0.62; cam.cx = mw / 2; cam.cy = mh / 2 + 6; M3.fit(m, cam, mw, mh - 20, 0.92); if (!cam.user) cam.yaw += 0.003;
      const lobes = [];
      if (pi && ml === 'ethene') { const ov = Math.abs(Math.cos(rad(th))); [0, 1].forEach(ci => { const ax = ci === 1 && th ? [0, -Math.sin(rad(th)), Math.cos(rad(th))] : [0, 0, 1]; [1, -1].forEach(sg => lobes.push({ o: m.a[ci].p, d: mul(ax, sg), len: 1.15, w: 0.85 + 0.25 * ov, col: sg > 0 ? '#3d7fd9' : '#d9433d', a: 0.42 })); }); }
      if (pi && ml === 'ethyne') { [[0, 1, 0], [0, 0, 1]].forEach((ax, j) => [1, -1].forEach(sg => { [0, 1].forEach(ci => lobes.push({ o: m.a[ci].p, d: mul(ax, sg), len: 1.0, w: 0.9, col: j ? (sg > 0 ? '#3d7fd9' : '#d9433d') : (sg > 0 ? '#22a67a' : '#e08a1e'), a: 0.33 })); })); }
      M3.render(g, m, cam, { mode, col, lobes, measure: ms && mode === 'bs' ? HCD[ml].meas : [] });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${HCD[ml].nm} · ${HCD[ml].hyb}`, mw / 2, 16);
      // side panel: energy vs rotation (ethane/ethene) or comparison bars
      const px = wd ? W * 0.68 : 56, py = wd ? 36 : mh + 22, pw = wd ? W * 0.29 : W - 76, ph = wd ? H * 0.42 : H - mh - 64;
      if (ml === 'ethane' || ml === 'ethene') {
        const top = ml === 'ethane' ? 14 : 290; const Pl = cplot(g, { x0: px, y0: py, w: pw, h: ph, xmax: 180, ymax: top, col, xt: [0, 60, 120, 180], yt: ml === 'ethane' ? [0, 6, 12] : [0, 132, 264], xl: 'ঘূর্ণন কোণ θ (°)', yl: 'শক্তি (kJ mol⁻¹)', ylx: 30 }); const pts = []; for (let a = 0; a <= 180; a += 2) pts.push([Pl.X(a), Pl.Y(energy(a))]); path(g, pts, ml === 'ethane' ? '#2f9e44' : '#c0392b', 2.2); M3.sphere(g, Pl.X(th), Pl.Y(energy(th)), 6, '#f39c12', '#ffe0a0');
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(ml === 'ethane' ? 'মুক্ত ঘূর্ণন (নিম্ন বাধা)' : 'বাধাপ্রাপ্ত ঘূর্ণন (π ভাঙে)', px + pw / 2, py - 10);
        if (wd) { g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(ml === 'ethane' ? (Math.round(th) % 120 === 60 ? 'ইক্লিপসড (সর্বোচ্চ শক্তি)' : Math.round(th) % 120 === 0 ? 'স্ট্যাগার্ড (সর্বনিম্ন শক্তি)' : '') : `π অধিক্রমণ ∝ cos²θ = ${bn(Math.pow(Math.cos(rad(th)), 2).toFixed(2))}`, px, py + ph + 44); }
      } else {
        const rows = [['C–C/C≡C দৈর্ঘ্য (pm)', [0, 154, 134, 120], 160], ['C–C বন্ধন শক্তি (kJ mol⁻¹)', [0, 348, 614, 839], 900], ['s-বৈশিষ্ট্য (%)', [25, 25, 33, 50], 55]]; const idx = { methane: 0, ethane: 1, ethene: 2, ethyne: 3 }[ml];
        rows.forEach(([nm, v, mx], r) => { const y = py + r * (ph / 3); g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(nm, px - (wd ? 0 : 40), y + 8); ['CH₄', 'C₂H₆', 'C₂H₄', 'C₂H₂'].forEach((lb, k) => { const bw = (pw - 40) * v[k] / mx, yy = y + 14 + k * 9; g.fillStyle = k === idx ? col.acc : col.mu; g.globalAlpha = k === idx ? 1 : 0.5; g.fillRect(px + 34 - (wd ? 0 : 40), yy, bw, 7); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `8.5px ${col.font}`; g.textAlign = 'right'; g.fillText(lb, px + 30 - (wd ? 0 : 40), yy + 7); }); });
      }
    };
    const info = () => { const d = HCD[ml]; q('[data-rotw]').style.display = ml === 'ethane' || ml === 'ethene' ? '' : 'none'; out.innerHTML = `<div class="table-wrap"><table class="t"><tbody><tr><th>সংকরণ</th><td>${d.hyb}</td><th>C–C</th><td>${d.cc} pm</td></tr><tr><th>C–H</th><td>${d.ch} pm</td><th>বন্ধন শক্তি (C–C)</th><td>${d.be} kJ mol⁻¹</td></tr><tr><th>কোণ</th><td colspan="3">${d.ang}</td></tr><tr><th>pKa (C–H অম্লত্ব)</th><td colspan="3">${d.pka}</td></tr></tbody></table></div><div class="small">${ml === 'ethyne' ? 'sp কার্বনের ৫০% s-বৈশিষ্ট্য — ইলেকট্রন নিউক্লিয়াসের কাছে থাকে, তড়িৎঋণাত্মকতা বেশি, C–H ছোট (১০৬ pm) ও তুলনামূলক অম্লীয়: ইথাইন Na বা অ্যামোনিয়াকাল AgNO₃ এর সাথে বিক্রিয়া করে।' : ml === 'ethene' ? 'আদর্শ sp² কোণ ১২০°; পরীক্ষালব্ধ H–C–H ১১৭.৪° কারণ C=C এর বেশি ইলেকট্রন ঘনত্ব C–H বন্ধনগুলোকে একটু ঠেলে দেয়। সব ছয়টি পরমাণু এক তলে।' : ml === 'ethane' ? 'প্রতিটি C sp³; স্ট্যাগার্ড রূপ সবচেয়ে স্থিতিশীল। পরীক্ষালব্ধ কোণ আদর্শ ১০৯.৫° এর খুব কাছে।' : 'নিখুঁত চতুস্তলক — চারটি C–H সমান, সব H–C–H কোণ ১০৯.৫°।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'ml', v => { ml = v; base = HCX[v](); th = 0; q('[data-th]').value = 0; q('[data-thv]').textContent = '০'; cam.user = false; info(); });
    X.onSeg(el, 'md', v => { mode = v; });
    q('[data-ms]').onchange = e => { ms = e.target.checked; }; q('[data-pi]').onchange = e => { pi = e.target.checked; };
    q('[data-th]').oninput = e => { th = +e.target.value; q('[data-thv]').textContent = bn(th); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
