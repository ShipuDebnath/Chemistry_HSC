/* ২য় পত্র অধ্যায় ২ visuals part b (11) — 2.16–2.17 melting/boiling point (capillary & Thiele tube, purity, mixed m.p., Siwoloboff b.p., trends), 2.18–2.19 polymers (addition chain mechanism, condensation, thermoplastic vs thermoset), 2.20 glycosidic & peptide bonds */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = M3.ease;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };

/* ======================= ২.১৬–২.১৭ গলনাঙ্ক ও স্ফুটনাঙ্ক নির্ণয় ======================= */
const SMP = {
  pure: ['বিশুদ্ধ বেনজয়িক এসিড', 122, 123, 'তীক্ষ্ণ গলনাঙ্ক (১২২–১২৩ °C) — বিশুদ্ধ'],
  imp: ['অশুদ্ধ বেনজয়িক এসিড (~১০% ভেজাল)', 112, 119, 'গলনাঙ্ক কমেছে ও পরিসর চওড়া (১১২–১১৯ °C) — অশুদ্ধ'],
  mixs: ['মিশ্র গলনাঙ্ক: নমুনা + বিশুদ্ধ বেনজয়িক এসিড', 122, 123, 'গলনাঙ্ক অপরিবর্তিত — নমুনাটি বেনজয়িক এসিডই'],
  mixd: ['মিশ্র গলনাঙ্ক: নমুনা (সিনামিক এসিড, গ. ১৩৩) + ইউরিয়া (গ. ১৩৩)', 105, 118, 'দুটির গলনাঙ্ক একই হলেও মিশ্রণের গলনাঙ্ক অনেক কমেছে — নমুনা ইউরিয়া নয়']
};
V.p2c2_mpbp = {
  t: 'গলনাঙ্ক ও স্ফুটনাঙ্ক নির্ণয়: থিলে নলে কৈশিক নল পদ্ধতিতে গলনাঙ্ক (বিশুদ্ধ বনাম অশুদ্ধ, মিশ্র গলনাঙ্ক পরীক্ষা) এবং সিওলোবফ পদ্ধতিতে স্ফুটনাঙ্ক — অ্যানিমেশন ও থার্মোমিটার পাঠ', k: ['anim', 'int', '2d'],
  cap: '"গলনাঙ্ক" মোডে নমুনা বেছে "উত্তপ্ত করো" চাপো। থিলে নলের প্যারাফিন তেলে পরিচলন স্রোত সমভাবে তাপ ছড়ায়; থার্মোমিটারের বাল্বের পাশে বাঁধা কৈশিক নলে গুঁড়া নমুনা। প্রথম তরল ফোঁটা দেখা দেওয়ার তাপমাত্রা ও সম্পূর্ণ স্বচ্ছ তরল হওয়ার তাপমাত্রা লিপিবদ্ধ হয় — এটিই গলনাঙ্কের পরিসর। বিশুদ্ধ যৌগে পরিসর ১ °C এর মধ্যে; ভেজালে গলনাঙ্ক কমে ও পরিসর চওড়া হয়। "স্ফুটনাঙ্ক" মোডে জ্বলন নলে তরল নমুনা ও উল্টানো কৈশিক নল: উত্তাপে বুদবুদের দ্রুত ধারা, তারপর উত্তাপ বন্ধ — যে মুহূর্তে বুদবুদ থেমে তরল কৈশিক নলে ঢুকতে শুরু করে, সেই তাপমাত্রাই স্ফুটনাঙ্ক (তখন বাষ্পচাপ = বায়ুমণ্ডলীয় চাপ)।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['mp', 'গলনাঙ্ক'], ['bp', 'স্ফুটনাঙ্ক']], 'mp')}<select data-s style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${Object.entries(SMP).map(([k, v]) => `<option value="${k}">${v[0]}</option>`).join('')}</select><button class="btn sm primary" data-go>▶ উত্তপ্ত করো</button></div>${X.cv('গলনাঙ্ক ও স্ফুটনাঙ্ক')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 540;
    let L = X.fit(c, hf), md = 'mp', sk = 'pure', Tm = 95, run = false, t = 0, onset = null, clear = null, bpPhase = 0, bpRead = null; const BP = 78.4;
    const reset = () => { Tm = md === 'mp' ? SMP[sk][1] - 25 : 55; run = false; onset = clear = null; bpPhase = 0; bpRead = null; info(); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const cx = wd ? W * 0.3 : W * 0.36, top = 20, th = wd ? H - 50 : H - 190;
      // Thiele tube
      g.strokeStyle = col.fg; g.lineWidth = 2; const tx = cx - 30, ty = top + 60, tw = 40, tl = th - 110;
      g.fillStyle = 'rgba(240,210,120,.35)'; g.fillRect(tx - tw / 2 + 2, ty + 20, tw - 4, tl - 20);
      g.strokeRect(tx - tw / 2, ty, tw, tl); // main tube
      g.beginPath(); g.moveTo(tx + tw / 2, ty + tl * 0.25); g.lineTo(tx + tw / 2 + 50, ty + tl * 0.45); g.lineTo(tx + tw / 2 + 50, ty + tl * 0.8); g.lineTo(tx + tw / 2, ty + tl * 0.95); g.stroke(); // side arm
      g.fillStyle = 'rgba(240,210,120,.35)'; g.beginPath(); g.moveTo(tx + tw / 2, ty + tl * 0.3); g.lineTo(tx + tw / 2 + 46, ty + tl * 0.47); g.lineTo(tx + tw / 2 + 46, ty + tl * 0.78); g.lineTo(tx + tw / 2, ty + tl * 0.9); g.fill();
      if (run) { M3.flame(g, tx + tw / 2 + 50, ty + tl * 0.86 + 34, 16, t); g.strokeStyle = 'rgba(230,120,30,.6)'; g.lineWidth = 1.2; for (let i = 0; i < 4; i++) { const u = (t * 0.5 + i / 4) % 1; const px = tx + tw / 2 + 25, py = ty + tl * (0.85 - u * 0.5); g.beginPath(); g.arc(px + Math.sin(u * 6) * 6, py, 2, 0, 7); g.stroke(); } }
      T(g, 'থিলে নল (প্যারাফিন তেল)', tx, ty + tl + 16, col, { s: 9, c: col.mu });
      // thermometer
      const thx = tx, thy = top, thl = ty + tl * 0.62 - top; g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.3; rr(g, thx - 5, thy, 10, thl, 5); g.fill(); g.stroke(); M3.sphere(g, thx, thy + thl, 8, '#c0392b', '#ff9a8a');
      const Tmin = 20, Tmax = md === 'mp' ? 160 : 110, fr = (Tm - Tmin) / (Tmax - Tmin); g.fillStyle = '#c0392b'; g.fillRect(thx - 2, thy + thl - fr * (thl - 10), 4, fr * (thl - 10));
      // sample capillary / fusion tube
      if (md === 'mp') { const kx = thx + 12, ky = thy + thl - 60; g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(kx, ky, 6, 62); const s = SMP[sk]; const f = Tm < s[1] ? 0 : Tm >= s[2] ? 1 : (Tm - s[1]) / (s[2] - s[1]); for (let i = 0; i < 14; i++) { const yy = ky + 50 + (i % 4) * 2.5, xx = kx + 1 + (i * 7 % 5); g.fillStyle = f >= 1 ? 'rgba(200,220,255,.0)' : `rgba(250,250,250,${1 - f})`; g.fillRect(xx, yy - f * 3, 1.6, 1.6); } if (f > 0) { g.fillStyle = `rgba(190,215,255,${0.3 + 0.6 * f})`; g.fillRect(kx + 0.5, ky + 62 - 10 * f, 5, 10 * f); } }
      else { const fx = thx + 14, fy = thy + thl - 70; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(fx, fy, 12, 72); g.fillStyle = 'rgba(180,210,250,.5)'; g.fillRect(fx + 1, fy + 40, 10, 31); g.strokeRect(fx + 4, fy + 20, 4, 48); // inverted capillary
        const liq = bpPhase === 3 ? Math.min(1, (BP + 1 - Tm) / 3) : 0; if (liq > 0) { g.fillStyle = 'rgba(80,130,220,.7)'; g.fillRect(fx + 4.5, fy + 68 - 20 * liq, 3, 20 * liq); }
        if (bpPhase === 1 || bpPhase === 2) { const rate = bpPhase === 2 ? 8 : Math.max(0.5, (Tm - 60) / 3); for (let i = 0; i < Math.min(8, rate); i++) { const u = (t * rate * 0.25 + i / 8) % 1; g.fillStyle = 'rgba(255,255,255,.9)'; g.strokeStyle = col.mu; g.beginPath(); g.arc(fx + 6, fy + 68 - u * 28, 1.6, 0, 7); g.fill(); g.stroke(); } } }
      // magnified capillary inset
      if (md === 'mp') { const s0 = SMP[sk], f = Tm < s0[1] ? 0 : Tm >= s0[2] ? 1 : (Tm - s0[1]) / (s0[2] - s0[1]), ix = wd ? W * 0.58 : W * 0.74, iy = wd ? 150 : 60, iw = wd ? 46 : 36, ih = wd ? 120 : 110; g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(thx + 18, thy + thl - 8); g.lineTo(ix, iy + ih); g.stroke(); g.setLineDash([]); g.fillStyle = 'rgba(240,210,120,.18)'; rr(g, ix - 8, iy - 18, iw + 16, ih + 30, 8); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.4; g.strokeRect(ix + iw * 0.3, iy, iw * 0.4, ih); for (let i = 0; i < 26; i++) { const cx2 = ix + iw * 0.33 + (i * 37 % 10) / 10 * iw * 0.34, cy2 = iy + ih - 6 - Math.floor(i / 3) * 5; g.fillStyle = `rgba(250,250,250,${Math.max(0, 1 - f * 1.3 + (i % 5) * 0.05)})`; g.strokeStyle = `rgba(120,120,120,${Math.max(0, 1 - f)})`; g.lineWidth = 0.6; g.beginPath(); g.rect(cx2, cy2, 4, 4); g.fill(); g.stroke(); } if (f > 0) { const hh = 44 * Math.min(1, f + 0.2); g.fillStyle = `rgba(150,190,250,${0.3 + 0.5 * f})`; g.fillRect(ix + iw * 0.3 + 1, iy + ih - hh, iw * 0.4 - 2, hh); } T(g, 'বিবর্ধিত', ix + iw / 2, iy - 6, col, { s: 8.5, c: col.mu }); }
      // reading panel
      const px = wd ? W * 0.58 + 70 : 12, py = wd ? 40 : H - 110; T(g, `তাপমাত্রা: ${bn(Tm.toFixed(1))} °C`, px, py, col, { b: true, s: 14, a: 'left' });
      if (md === 'mp') { const s = SMP[sk]; T(g, onset != null ? `প্রথম তরল ফোঁটা: ${bn(onset.toFixed(1))} °C` : 'প্রথম তরল ফোঁটা: —', px, py + 22, col, { a: 'left' }); T(g, clear != null ? `সম্পূর্ণ স্বচ্ছ তরল: ${bn(clear.toFixed(1))} °C` : 'সম্পূর্ণ স্বচ্ছ তরল: —', px, py + 40, col, { a: 'left' }); if (clear != null) { T(g, `গলনাঙ্কের পরিসর: ${bn((clear - onset).toFixed(1))} °C`, px, py + 62, col, { b: true, a: 'left', c: clear - onset <= 1.2 ? '#2f9e44' : '#c0392b' }); T(g, s[3], px, py + 80, col, { s: 9.5, a: 'left', c: col.mu }); }
        if (wd) { const bx = px, by = py + 120, bw = W - px - 20; for (let v = 100; v <= 140; v += 10) { const xx = bx + (v - 100) / 40 * bw; T(g, bn(v), xx, by + 34, col, { s: 9, c: col.mu }); } g.strokeStyle = col.mu; g.beginPath(); g.moveTo(bx, by + 22); g.lineTo(bx + bw, by + 22); g.stroke(); Object.values(SMP).forEach((v2, i) => { const x1 = bx + (v2[1] - 100) / 40 * bw, x2 = bx + (v2[2] - 100) / 40 * bw; g.fillStyle = ['#2f9e44', '#c0392b', '#2980b9', '#e67e22'][i]; g.globalAlpha = v2 === s ? 1 : 0.3; g.fillRect(x1, by + 4 + i * 4, Math.max(3, x2 - x1), 3); g.globalAlpha = 1; }); T(g, 'গলনের পরিসর তুলনা (°C)', bx, by - 2, col, { s: 9, a: 'left', c: col.mu }); } }
      else { T(g, ['ধীরে উত্তপ্ত করো…', 'বুদবুদ বাড়ছে (কৈশিক নলের বায়ু প্রসারিত হচ্ছে)', 'দ্রুত অবিচ্ছিন্ন বুদবুদ — এখন উত্তাপ বন্ধ', 'ঠান্ডা হচ্ছে… বুদবুদ থেমে তরল কৈশিক নলে ঢুকছে'][bpPhase], px, py + 22, col, { a: 'left', s: 10 }); if (bpRead != null) T(g, `স্ফুটনাঙ্ক = ${bn(bpRead.toFixed(1))} °C (ইথানল, প্রকৃত ৭৮.৪ °C)`, px, py + 44, col, { b: true, a: 'left', c: '#2f9e44' }); }
    };
    const info = () => { out.innerHTML = md === 'mp' ? `<div><b>${SMP[sk][0]}:</b> ${SMP[sk][3]}।</div><div class="small">ভেজাল কেলাস জালিকাকে বিঘ্নিত করে (দ্রবীভূত দ্রব হিসেবে কাজ করে) — গলনাঙ্ক অবনমন একটি কলিগেটিভ ধর্ম। মিশ্র গলনাঙ্ক পরীক্ষায় অজানা নমুনার সাথে পরিচিত বিশুদ্ধ যৌগ মিশিয়ে গলনাঙ্ক মাপা হয়: অপরিবর্তিত থাকলে দুটি একই যৌগ, কমে গেলে ভিন্ন।</div>` : `<div>সিওলোবফ পদ্ধতি: অল্প নমুনায় (কয়েক ফোঁটা) স্ফুটনাঙ্ক নির্ণয়। স্ফুটনাঙ্কে তরলের বাষ্পচাপ বায়ুমণ্ডলীয় চাপের সমান হয়; ঠান্ডা করার সময় কৈশিক নলের ভেতরের বাষ্পচাপ বাইরের চাপের নিচে নামামাত্র তরল ভেতরে ঢোকে — সেটিই সঠিক পাঠ। চাপ কমলে স্ফুটনাঙ্ক কমে; ভেজাল (অনুদ্বায়ী) থাকলে স্ফুটনাঙ্ক বাড়ে।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (md === 'mp' && run) { Tm += dt * (Tm < SMP[sk][1] - 8 ? 6 : 1.2); const s = SMP[sk]; if (onset == null && Tm >= s[1]) onset = s[1] + (Math.random() - 0.5) * 0.2; if (clear == null && Tm >= s[2]) { clear = s[2] + (Math.random() - 0.5) * 0.2; } if (Tm > s[2] + 4) run = false; }
      if (md === 'bp' && run) { if (bpPhase < 2) { Tm += dt * 4; bpPhase = Tm > 70 ? 1 : 0; if (Tm >= BP + 3) bpPhase = 2; } else if (bpPhase === 2) { bpPhase = 3; } else { Tm -= dt * 1.2; if (bpRead == null && Tm <= BP) bpRead = BP; if (Tm < BP - 4) run = false; } } } draw(); }, { paused: false });
    X.onSeg(el, 'md', v => { md = v; q('[data-s]').style.display = v === 'mp' ? '' : 'none'; reset(); });
    q('[data-s]').onchange = e => { sk = e.target.value; reset(); }; q('[data-go]').onclick = () => { reset(); run = true; };
    reset(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১৬ স্ফুটনাঙ্কের প্রবণতা ======================= */
const SER = [['অ্যালকেন', '#7f8c8d', [-162, -89, -42, -0.5, 36, 69, 98, 126]], ['অ্যালডিহাইড', '#e67e22', [-19, 20, 49, 75, 103, 131, 153, 171]], ['অ্যালকোহল', '#c0392b', [65, 78, 97, 117, 138, 157, 176, 195]], ['কার্বক্সিলিক এসিড', '#8e44ad', [101, 118, 141, 164, 186, 205, 223, 239]]];
const ISO = [['n-পেন্টেন', 36, 'সোজা শিকল — সর্বোচ্চ পৃষ্ঠতল সংস্পর্শ'], ['২-মিথাইলবিউটেন', 28, 'একটি শাখা'], ['২,২-ডাইমিথাইলপ্রোপেন', 9.5, 'প্রায় গোলাকার — সংস্পর্শ সবচেয়ে কম']];
V.p2c2_bpTrend = {
  t: 'স্ফুটনাঙ্কের প্রবণতা: সমগোত্রীয় শ্রেণিতে কার্বন সংখ্যার সাথে বৃদ্ধি, কার্যকরী মূলকের প্রভাব (হাইড্রোজেন বন্ধন ও ডাইপোল) এবং শাখার প্রভাব — লেখচিত্র ও আন্তঃআণবিক বল', k: ['int', '2d'],
  cap: 'লেখচিত্রে চারটি সমগোত্রীয় শ্রেণির স্ফুটনাঙ্ক (C₁–C₈)। শ্রেণির নামে চাপ দিয়ে দেখাও/লুকাও, যেকোনো বিন্দুতে চাপ দিলে মান দেখায়। প্রতি CH₂ যোগে স্ফুটনাঙ্ক প্রায় ২০–৩০ °C বাড়ে (লন্ডন বল বাড়ে)। একই কার্বন সংখ্যায় ক্রম: অ্যালকেন < অ্যালডিহাইড < অ্যালকোহল < কার্বক্সিলিক এসিড — শুধু লন্ডন বল → ডাইপোল-ডাইপোল → হাইড্রোজেন বন্ধন → দ্বৈত হাইড্রোজেন বন্ধনে ডাইমার। নিচে পেন্টেনের তিন সমাণু: শাখা বাড়লে অণু গোলাকার হয়, পৃষ্ঠতল সংস্পর্শ কমে, স্ফুটনাঙ্ক কমে।',
  html: () => `<div data-leg style="display:flex;flex-wrap:wrap;gap:4px;margin:0 0 6px">${SER.map((s, i) => `<button class="btn sm on" data-i="${i}" style="border-color:${s[1]};color:${s[1]}">${s[0]}</button>`).join('')}</div>${X.cv('স্ফুটনাঙ্কের প্রবণতা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 340 : 520;
    let L = X.fit(c, hf), on = [1, 1, 1, 1], selP = null, PL = null;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const pw = wd ? W * 0.5 - 50 : W - 110, ph = wd ? H - 60 : 260;
      PL = cplot(g, { x0: 46, y0: 14, w: pw, h: ph, xmin: 0.5, xmax: 8.5, ymin: -180, ymax: 260, col, xt: [1, 2, 3, 4, 5, 6, 7, 8], yt: [-150, -100, -50, 0, 50, 100, 150, 200, 250], xl: 'কার্বন সংখ্যা', yl: 'স্ফুটনাঙ্ক (°C)', ylx: 36 });
      SER.forEach((s, i) => { if (!on[i]) return; path(g, s[2].map((v, j) => [PL.X(j + 1), PL.Y(v)]), s[1], 2); s[2].forEach((v, j) => { g.fillStyle = s[1]; g.beginPath(); g.arc(PL.X(j + 1), PL.Y(v), selP && selP[0] === i && selP[1] === j ? 5 : 3, 0, 7); g.fill(); }); T(g, s[0], PL.X(8) + 4, PL.Y(s[2][7]) + 3, col, { s: 9, a: 'left', c: s[1] }); });
      if (selP) { const [i, j] = selP, v = SER[i][2][j]; T(g, `${SER[i][0]} C${j + 1}: ${bn(v)} °C`, PL.X(j + 1), PL.Y(v) - 10, col, { b: true, s: 10, c: SER[i][1] }); }
      // isomers
      const ix = wd ? W * 0.64 : 20, iy = wd ? 30 : ph + 60, iw = wd ? W * 0.34 : W - 40; T(g, 'C₅H₁₂ সমাণু: শাখার প্রভাব', ix, iy, col, { b: true, a: 'left', s: 10.5 });
      ISO.forEach((r, i) => { const y = iy + 18 + i * (wd ? 74 : 56), cxm = ix + 30; // little molecule glyph
        const pts = i === 0 ? [[-24, 0], [-12, -6], [0, 0], [12, -6], [24, 0]] : i === 1 ? [[-18, 0], [-6, -6], [6, 0], [18, -6], [-6, -18]] : [[0, 0], [-13, 0], [13, 0], [0, -13], [0, 13]];
        const bonds = i === 0 ? [[0, 1], [1, 2], [2, 3], [3, 4]] : i === 1 ? [[0, 1], [1, 2], [2, 3], [1, 4]] : [[0, 1], [0, 2], [0, 3], [0, 4]];
        g.strokeStyle = col.mu; g.lineWidth = 1.5; bonds.forEach(([a, b]) => { g.beginPath(); g.moveTo(cxm + pts[a][0], y + 22 + pts[a][1]); g.lineTo(cxm + pts[b][0], y + 22 + pts[b][1]); g.stroke(); }); pts.forEach(p => M3.sphere(g, cxm + p[0], y + 22 + p[1], 4.5, '#333', '#999'));
        const bw = (iw - 80) * Math.max(0.03, r[1] / 40); g.fillStyle = '#7f8c8d'; g.fillRect(ix + 70, y + 12, bw, 12); T(g, `${r[0]} — ${bn(r[1])} °C`, ix + 70, y + 8, col, { s: 9.5, a: 'left' }); T(g, r[2], ix + 70, y + 36, col, { s: 8.5, a: 'left', c: col.mu }); });
    };
    const info = () => { out.innerHTML = `<div>স্ফুটনাঙ্ক নির্ভর করে আন্তঃআণবিক আকর্ষণের শক্তির উপর: (১) <b>আণবিক আকার</b> — ইলেকট্রন বেশি, লন্ডন বল বেশি; (২) <b>পোলারিটি</b> — C=O এর ডাইপোল-ডাইপোল আকর্ষণ; (৩) <b>হাইড্রোজেন বন্ধন</b> — –OH, –NH₂, –COOH; (৪) <b>আকৃতি</b> — শাখা কম হলে সংস্পর্শ বেশি। প্রোপান-১-অল (M = ৬০) ৯৭ °C, অথচ প্রায় সমান ভরের বিউটেন (M = ৫৮) −০.৫ °C ও প্রোপান্যাল (M = ৫৮) ৪৯ °C — একই ভরে H বন্ধনের প্রভাব স্পষ্ট।</div>`; };
    el.querySelectorAll('[data-leg] button').forEach(b => b.onclick = () => { const i = +b.dataset.i; on[i] = 1 - on[i]; b.classList.toggle('on', !!on[i]); b.style.opacity = on[i] ? 1 : 0.4; draw(); });
    c.addEventListener('click', e => { if (!PL) return; const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; let best = null, bd = 14; SER.forEach((s, i) => { if (!on[i]) return; s[2].forEach((v, j) => { const d = Math.hypot(PL.X(j + 1) - x, PL.Y(v) - y); if (d < bd) { bd = d; best = [i, j]; } }); }); selP = best; draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ২.১৮–২.১৯ পলিমার ======================= */
const MONO = {
  pe: ['ইথিন', 'পলিথিন (PE)', 'H', 'H', '#7f8c8d', 'n CH2=CH2 ->[\\text{প্রভাবক/চাপ}] (-CH2-CH2-)_n', 'ব্যাগ, বোতল, পাইপ, ফিল্ম'],
  pp: ['প্রোপিন', 'পলিপ্রোপিন (PP)', 'H', 'CH₃', '#16a085', 'n CH2=CH-CH3 -> (-CH2-CH(CH3)-)_n', 'দড়ি, পাত্র, গাড়ির যন্ত্রাংশ, কার্পেট'],
  pvc: ['ভিনাইল ক্লোরাইড', 'পলিভিনাইল ক্লোরাইড (PVC)', 'H', 'Cl', '#27ae60', 'n CH2=CHCl -> (-CH2-CHCl-)_n', 'পানির পাইপ, তারের আবরণ, মেঝের টাইলস'],
  ps: ['স্টাইরিন', 'পলিস্টাইরিন (PS)', 'H', 'C₆H₅', '#8e44ad', 'n CH2=CH-C6H5 -> (-CH2-CH(C6H5)-)_n', 'থার্মোকল (ফোম), ডিসপোজেবল কাপ, প্যাকেজিং'],
  ptfe: ['টেট্রাফ্লুরোইথিন', 'টেফলন (PTFE)', 'F', 'F', '#2980b9', 'n CF2=CF2 -> (-CF2-CF2-)_n', 'ননস্টিক তাওয়া, রাসায়নিক-প্রতিরোধী আস্তরণ']
};
const COND = {
  nylon: ['নাইলন-৬,৬', ['হেক্সেনডায়োয়িক এসিড', 'HOOC–(CH₂)₄–COOH', '#c0392b'], ['হেক্সেন-১,৬-ডাইঅ্যামিন', 'H₂N–(CH₂)₆–NH₂', '#2980b9'], '–CO–NH– (অ্যামাইড/পেপটাইড)', 'n HOOC(CH2)4COOH + n H2N(CH2)6NH2 -> [-OC(CH2)4CO-NH(CH2)6NH-]_n + 2n H2O', 'কাপড়, মোজা, দড়ি, মাছ ধরার জাল, প্যারাস্যুট'],
  pet: ['টেরিলিন (PET, ডেক্রন)', ['বেনজিন-১,৪-ডাইকার্বক্সিলিক এসিড', 'HOOC–C₆H₄–COOH', '#c0392b'], ['ইথেন-১,২-ডাইঅল', 'HO–CH₂CH₂–OH', '#e67e22'], '–CO–O– (এস্টার)', 'n HOOC-C6H4-COOH + n HOCH2CH2OH -> [-OC-C6H4-CO-OCH2CH2O-]_n + 2n H2O', 'পলিয়েস্টার কাপড়, পানীয়ের বোতল'],
  bake: ['বেকেলাইট', ['ফেনল', 'C₆H₅OH', '#c0392b'], ['মিথান্যাল', 'HCHO', '#7f8c8d'], '–CH₂– সেতু (ত্রিমাত্রিক জাল)', 'n C6H5OH + n HCHO -> [-C6H3(OH)-CH2-]_n + n H2O', 'বৈদ্যুতিক সুইচ, হাতল, প্লাগ (তাপস্থাপক)']
};
V.p2c2_polymer = {
  t: 'পলিমারকরণ: সংযোজন পলিমারকরণের মুক্তমূলক শৃঙ্খল কৌশল (সূচনা, বিস্তার, সমাপ্তি) — ৫টি মনোমার; ঘনীভবন পলিমারকরণ (নাইলন-৬,৬, টেরিলিন, বেকেলাইট) — পানি অপসারণ; এবং তাপনম্য বনাম তাপস্থাপক প্লাস্টিক', k: ['anim', 'int', '2d'],
  cap: '"সংযোজন" মোডে মনোমার বেছে "শুরু" চাপো: পারক্সাইড ভেঙে মুক্তমূলক (•) তৈরি হয় (সূচনা); মুক্তমূলক একটি মনোমারের π বন্ধন খুলে যুক্ত হয় এবং অযুগ্ম ইলেকট্রন শিকলের প্রান্তে চলে যায় (বিস্তার) — শিকল দ্রুত লম্বা হয়; দুটি মুক্তমূলক প্রান্ত মিলে গেলে থামে (সমাপ্তি)। কোনো অণু বের হয় না — পলিমারের সংকেত মনোমারের n গুণ। "ঘনীভবন" মোডে দুই ধরনের দ্বিকার্যকরী মনোমার পর্যায়ক্রমে যুক্ত হয় এবং প্রতিটি সংযোগে একটি H₂O (নীল) বেরিয়ে যায়। "প্লাস্টিসিটি" মোডে তাপমাত্রা বাড়াও: তাপনম্য প্লাস্টিকের (PE, PVC) পৃথক শিকল পিছলে যায় — নরম হয়, পুনরায় ছাঁচে ঢালা যায়; তাপস্থাপক (বেকেলাইট) এর আড়াআড়ি বন্ধনের জাল নড়ে না — নরম না হয়ে পুড়ে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['add', 'সংযোজন'], ['cond', 'ঘনীভবন'], ['plas', 'প্লাস্টিসিটি']], 'add')}<select data-m style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${Object.entries(MONO).map(([k, v]) => `<option value="${k}">${v[0]} → ${v[1]}</option>`).join('')}</select><select data-c style="display:none;padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${Object.entries(COND).map(([k, v]) => `<option value="${k}">${v[0]}</option>`).join('')}</select><button class="btn sm primary" data-go>▶ শুরু</button></div>${X.cv('পলিমারকরণ')}<div class="ctl" data-trow style="display:none"><label class="small" style="flex:1">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="20" max="300" value="20" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 420;
    let L = X.fit(c, hf), md = 'add', mk = 'pe', ck = 'nylon', p = 0, run = true, t = 0, Tp = 20;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 'add') {
        const M = MONO[mk], k = Math.min(1, p), nU = Math.floor(k * 9), step = wd ? 62 : 40, y0 = H / 2 + 10, x0 = 30;
        const stage = k < 0.08 ? 'সূচনা: RO–OR → 2RO• (তাপ বা আলোতে)' : k < 0.9 ? `বিস্তার: RO–(CH₂–C)ₙ• + মনোমার → শিকল বাড়ছে (n = ${bn(nU)})` : 'সমাপ্তি: দুটি মুক্তমূলক প্রান্ত মিলে স্থিতিশীল পলিমার';
        T(g, stage, W / 2, 16, col, { b: true, s: 10.5 });
        // initiator
        T(g, 'RO', x0, y0 + 4, col, { b: true, c: '#c0392b' });
        for (let i = 0; i < nU; i++) { const xa = x0 + 16 + i * step, xb = xa + step / 2; g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(xa - 8, y0); g.lineTo(xa, y0); g.lineTo(xb, y0); g.lineTo(xa + step - 8, y0); g.stroke(); M3.sphere(g, xa, y0, 6, '#333', '#999'); M3.sphere(g, xb, y0, 6, '#333', '#999'); const su = (s, x, up) => { g.strokeStyle = col.mu; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x, y0); g.lineTo(x, y0 + (up ? -16 : 16)); g.stroke(); T(g, s, x, y0 + (up ? -20 : 27), col, { s: 9, c: s === 'H' ? col.mu : M[4], b: s !== 'H' }); }; su(M[2] === 'F' ? 'F' : 'H', xa, true); su(M[2] === 'F' ? 'F' : 'H', xa, false); su(M[2] === 'F' ? 'F' : 'H', xb, false); su(M[3], xb, true); }
        const ex = x0 + 16 + nU * step - 2; if (k < 0.9) { g.fillStyle = '#e74c3c'; g.beginPath(); g.arc(ex + 2, y0 - 9, 4, 0, 7); g.fill(); const ax = ex + step * (1 - (k * 9 % 1)) + 10; if (ax < W - 20) { g.strokeStyle = M[4]; g.lineWidth = 2; g.beginPath(); g.moveTo(ax, y0 - 4); g.lineTo(ax + step / 2, y0 - 4); g.moveTo(ax, y0 + 4); g.lineTo(ax + step / 2, y0 + 4); g.stroke(); M3.sphere(g, ax, y0, 6, '#333', '#999'); M3.sphere(g, ax + step / 2, y0, 6, '#333', '#999'); T(g, M[0], ax + step / 4, y0 + 34, col, { s: 9, c: M[4] }); } }
        else T(g, '–OR', ex + 14, y0 + 4, col, { b: true, c: '#c0392b' });
        T(g, `${M[0]} → ${M[1]}`, W / 2, H - 14, col, { s: 10.5, b: true, c: M[4] });
      } else if (md === 'cond') {
        const C = COND[ck], k = Math.min(1, p), n = Math.floor(k * 6), bw = Math.min(84, (W - 40) / 6 - 6), y0 = H / 2;
        T(g, `${C[1][0]} + ${C[2][0]} → ${C[0]} + পানি`, W / 2, 16, col, { b: true, s: 10.5 });
        for (let i = 0; i < 6; i++) { const x = 20 + i * (bw + 6), cc = i % 2 ? C[2][2] : C[1][2]; const joined = i < n; const yy = joined ? y0 : y0 + (i % 2 ? 40 : -40); g.fillStyle = cc; g.globalAlpha = joined ? 0.9 : 0.45; rr(g, x, yy - 14, bw, 28, 8); g.fill(); g.globalAlpha = 1; T(g, i % 2 ? C[2][1].split('–')[0] + '…' : C[1][1].split('–')[0] + '…', x + bw / 2, yy + 4, col, { s: wd ? 9 : 7.5, c: '#fff', b: true });
          if (joined && i > 0) { g.fillStyle = col.fg; g.fillRect(x - 6, y0 - 2, 6, 4); const wy = y0 - 30 - ((k * 6 - i) % 1) * 40; if (k * 6 - i < 1.5) { M3.sphere(g, x - 3, wy, 7, '#2471a3', '#85c1e9'); T(g, 'H₂O', x - 3, wy - 10, col, { s: 8.5, c: '#2471a3', b: true }); } } }
        T(g, `সংযোগ: ${C[3]}`, W / 2, H - 30, col, { s: 10 }); T(g, `প্রতি সংযোগে একটি H₂O অপসারিত — অপসারিত পানি: ${bn(Math.max(0, n - 1))} অণু`, W / 2, H - 12, col, { s: 9.5, c: col.mu });
      } else {
        const soft = Math.max(0, Math.min(1, (Tp - 110) / 80)), burn = Tp > 260; const half = W / 2;
        T(g, 'তাপনম্য (থার্মোপ্লাস্টিক) — PE, PVC', half / 2, 16, col, { b: true, s: 10 }); T(g, 'তাপস্থাপক (থার্মোসেট) — বেকেলাইট', half + half / 2, 16, col, { b: true, s: 10 });
        for (let ch = 0; ch < 6; ch++) { g.strokeStyle = ['#7f8c8d', '#27ae60', '#2980b9', '#8e44ad', '#16a085', '#c0392b'][ch]; g.lineWidth = 2; g.beginPath(); for (let i = 0; i <= 20; i++) { const x = 16 + i * (half - 40) / 20 + soft * Math.sin(t * 1.5 + ch) * 18, y = 40 + ch * (H - 80) / 6 + Math.sin(i * 0.9 + ch * 2 + soft * t * 2) * (6 + soft * 10); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); }
        T(g, soft > 0.5 ? 'শিকল পিছলে যাচ্ছে — নরম, ছাঁচে ঢালা যায়' : 'শিকল পাশাপাশি, কেবল দুর্বল আন্তঃআণবিক বল', half / 2, H - 10, col, { s: 9, c: soft > 0.5 ? '#e67e22' : col.mu });
        const gx = half + 20, gw = half - 40, gy = 40, gh = H - 80, N = 6; for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) { const x = gx + i * gw / (N - 1), y = gy + j * gh / (N - 1), jit = Math.sin(t * 6 + i + j) * (Tp / 300) * 2; if (i < N - 1) { g.strokeStyle = burn ? '#5d4037' : '#c0392b'; g.lineWidth = 2; g.beginPath(); g.moveTo(x + jit, y); g.lineTo(x + gw / (N - 1) + jit, y); g.stroke(); } if (j < N - 1) { g.strokeStyle = burn ? '#5d4037' : '#e67e22'; g.lineWidth = 1.5; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(x, y + jit); g.lineTo(x, y + gh / (N - 1) + jit); g.stroke(); g.setLineDash([]); } M3.sphere(g, x + jit, y + jit, 3.5, burn ? '#3e2723' : '#555', '#aaa'); }
        T(g, burn ? 'নরম হয় না — পুড়ে কালো হয়ে বিয়োজিত' : 'আড়াআড়ি বন্ধন (– – –) জাল ধরে রাখে — শক্ত', half + half / 2, H - 10, col, { s: 9, c: burn ? '#5d4037' : col.mu });
        if (burn) { g.fillStyle = 'rgba(60,40,30,.25)'; g.fillRect(half + 10, 30, half - 20, H - 60); }
      }
    };
    const info = () => { if (md === 'add') { const M = MONO[mk]; out.innerHTML = `<div><b>${M[1]}:</b> ব্যবহার — ${M[6]}।</div>${TXB(`\\ce{${M[5]}}`)}<div class="small">সংযোজন পলিমারকরণে অসম্পৃক্ত (C=C যুক্ত) মনোমার কোনো উপজাত ছাড়াই যুক্ত হয়; পলিমারের স্থূল সংকেত মনোমারের সমান। সূচনা: R–O–O–R → 2RO•; বিস্তার: RO• + CH₂=CH₂ → RO–CH₂–CH₂•; সমাপ্তি: দুটি মুক্তমূলক মিলন।</div>`; return; }
      if (md === 'cond') { const C = COND[ck]; out.innerHTML = `<div><b>${C[0]}:</b> ${C[1][0]} (${C[1][1]}) ও ${C[2][0]} (${C[2][1]}); সংযোগ ${C[3]}। ব্যবহার — ${C[5]}।</div>${TXB(`\\ce{${C[4]}}`)}<div class="small">ঘনীভবন পলিমারকরণে দুটি কার্যকরী মূলকযুক্ত মনোমার পরস্পরের সাথে বিক্রিয়া করে এবং প্রতিটি সংযোগে ছোট অণু (H₂O, HCl, CH₃OH) অপসারিত হয়; তাই পলিমারের ভর মনোমারগুলোর মোট ভরের চেয়ে কম।</div>`; return; }
      q('[data-tv]').textContent = bn(Tp); out.innerHTML = `<div><b>প্লাস্টিসিটি:</b> তাপ ও চাপে নরম হয়ে স্থায়ীভাবে আকৃতি নেওয়ার ধর্ম। তাপনম্য প্লাস্টিকে রৈখিক/অল্প শাখাযুক্ত শিকল কেবল দুর্বল ভ্যান্ডারওয়ালস বলে যুক্ত — বারবার গলিয়ে পুনর্ব্যবহারযোগ্য। তাপস্থাপক প্লাস্টিকে শিকলগুলো সমযোজী আড়াআড়ি বন্ধনে ত্রিমাত্রিক জাল — একবার শক্ত হলে আর গলে না, পুনর্ব্যবহার কঠিন।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run && md !== 'plas') { p = Math.min(1, p + dt * 0.12); if (p >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'md', v => { md = v; q('[data-m]').style.display = v === 'add' ? '' : 'none'; q('[data-c]').style.display = v === 'cond' ? '' : 'none'; q('[data-trow]').style.display = v === 'plas' ? '' : 'none'; q('[data-go]').style.display = v === 'plas' ? 'none' : ''; p = 0; run = true; info(); });
    q('[data-m]').onchange = e => { mk = e.target.value; p = 0; run = true; info(); }; q('[data-c]').onchange = e => { ck = e.target.value; p = 0; run = true; info(); };
    q('[data-go]').onclick = () => { p = 0; run = true; }; q('[data-t]').oninput = e => { Tp = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.২০ গ্লাইকোসাইড ও পেপটাইড বন্ধন ======================= */
/* Haworth ring: pts in order C1(right), C2, C3, C4(left), C5, O(ring) */
const haworth = (g, cx, cy, s, col, sub, hl) => {
  const P = [[1, 0], [0.5, 0.42], [-0.5, 0.42], [-1, 0], [-0.5, -0.42], [0.5, -0.42]].map(([x, y]) => [cx + x * s, cy + y * s]);
  g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); P.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.stroke();
  g.lineWidth = 4; g.beginPath(); g.moveTo(P[1][0], P[1][1]); g.lineTo(P[2][0], P[2][1]); g.stroke(); // bold front edge
  T(g, 'O', P[5][0] + 2, P[5][1] - 3, col, { b: true, s: 11, c: '#cc2418' });
  // substituents: sub[i] = [up, down] labels for C1..C5
  sub.forEach(([up, dn], i) => { const p = P[i]; const L2 = s * 0.38; g.strokeStyle = col.mu; g.lineWidth = 1.3; if (up) { g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(p[0], p[1] - L2); g.stroke(); T(g, up, p[0], p[1] - L2 - 3, col, { s: 9.5, b: up !== 'H', c: hl && hl[i] === 'u' ? '#e67e22' : up === 'H' ? col.mu : '#cc2418' }); } if (dn) { g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(p[0], p[1] + L2); g.stroke(); T(g, dn, p[0], p[1] + L2 + 10, col, { s: 9.5, b: dn !== 'H', c: hl && hl[i] === 'd' ? '#e67e22' : dn === 'H' ? col.mu : '#cc2418' }); } });
  return P;
};
const GLU = { a: [['H', 'OH'], ['H', 'OH'], ['OH', 'H'], ['H', 'OH'], ['CH₂OH', '']], b: [['OH', 'H'], ['H', 'OH'], ['OH', 'H'], ['H', 'OH'], ['CH₂OH', '']] };
const glyGly = () => M3.relax(M3.tree([['N', -1], ['C', 0], ['C', 1], ['O', 2, 2], ['N', 2], ['C', 4], ['C', 5], ['O', 6, 2], ['O', 6], ['C', 5]], { name: 'গ্লাইসিলঅ্যালানিন (Gly-Ala)' }), 400);
V.p2c2_biobonds = {
  t: 'পলিমার অণুতে গ্লাইকোসাইড ও পেপটাইড বন্ধন: দুটি গ্লুকোজ থেকে পানি অপসারণে α(১→৪) গ্লাইকোসাইড বন্ধন (মল্টোজ, স্টার্চ) ও β(১→৪) বন্ধন (সেলুলোজ) — হাওয়ার্থ অ্যানিমেশন; দুটি অ্যামিনো এসিড থেকে পেপটাইড বন্ধন ও ত্রিমাত্রিক ডাইপেপটাইড', k: ['anim', 'int', '3d'],
  cap: '"গ্লাইকোসাইড" মোডে α বা β গ্লুকোজ বেছে "যুক্ত করো" চাপো: প্রথম অণুর C1 এর –OH (কমলা) ও দ্বিতীয় অণুর C4 এর –OH থেকে একটি H₂O বেরিয়ে যায়, দুই বলয় একটি O সেতুতে যুক্ত হয়। α তে C1 এর –OH বলয়ের নিচে — তাই সংযোগটি নিচ দিয়ে (α(১→৪), মল্টোজ → স্টার্চ, প্যাঁচানো শিকল); β তে উপরে — প্রতিটি পরের একক উল্টে যুক্ত হয় (β(১→৪), সেলোবায়োজ → সেলুলোজ, সোজা তন্তু)। "পেপটাইড" মোডে গ্লাইসিনের –COOH ও অ্যালানিনের –NH₂ থেকে পানি বের হয়ে –CO–NH– পেপটাইড বন্ধন; ডানে ত্রিমাত্রিক Gly-Ala — পেপটাইড বন্ধন (উজ্জ্বল) রেজোন্যান্সে আংশিক দ্বিবন্ধন, তাই ঘুরতে পারে না।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['gly', 'গ্লাইকোসাইড'], ['pep', 'পেপটাইড']], 'gly')}${X.seg('an', [['a', 'α-গ্লুকোজ'], ['b', 'β-গ্লুকোজ']], 'a')}<button class="btn sm primary" data-go>▶ যুক্ত করো</button></div>${X.cv('গ্লাইকোসাইড ও পেপটাইড বন্ধন')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 460;
    let L = X.fit(c, hf), md = 'gly', an = 'a', p = 0, run = true, t = 0, pm = glyGly(); const cam = M3.cam({ yaw: 0.4, pitch: 0.4 });
    C4.drag3d(c, cam, () => A.draw());
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), k = ease(Math.min(1, p));
      if (md === 'gly') {
        const s = Math.min(W / 6.5, 70), cy = H / 2 + 6, gap = (1 - k) * s * 0.9, x1 = W / 2 - s * 1.25 - gap, x2 = W / 2 + s * 1.25 + gap; const flip = an === 'b';
        T(g, k < 0.95 ? `${an === 'a' ? 'α' : 'β'}-গ্লুকোজ + ${an === 'a' ? 'α' : 'β'}-গ্লুকোজ` : an === 'a' ? 'মল্টোজ — α(১→৪) গ্লাইকোসাইড বন্ধন' : 'সেলোবায়োজ — β(১→৪) গ্লাইকোসাইড বন্ধন', W / 2, 16, col, { b: true, s: 11 });
        const s1 = GLU[an].map(r => r.slice()); if (k > 0.6) s1[0] = an === 'a' ? ['H', ''] : ['', 'H'];
        const P1 = haworth(g, x1, cy, s, col, s1, { 0: an === 'a' ? 'd' : 'u' });
        let s2 = GLU[an].map(r => r.slice()); if (k > 0.6) s2[3] = flip ? ['', 'H'] : ['H', ''];
        if (flip) { g.save(); g.translate(x2, cy); g.scale(1, -1); g.translate(-x2, -cy); }
        const P2 = haworth(g, x2, cy, s, col, flip ? s2.map(([u, d]) => [d, u]) : s2, { 3: flip ? 'u' : 'd' });
        if (flip) g.restore();
        void P2;
        // bridge
        if (k > 0.6) { const a1 = P1[0], b4 = [x2 - s, cy]; const by = an === 'a' ? cy + s * 0.55 : cy - s * 0.55; g.strokeStyle = '#cc2418'; g.lineWidth = 2.2; g.beginPath(); g.moveTo(a1[0], a1[1]); g.lineTo((a1[0] + b4[0]) / 2, by); g.lineTo(b4[0], b4[1]); g.stroke(); T(g, 'O', (a1[0] + b4[0]) / 2, by + (an === 'a' ? 12 : -4), col, { b: true, s: 12, c: '#cc2418' }); T(g, an === 'a' ? 'α(১→৪)' : 'β(১→৪)', (a1[0] + b4[0]) / 2, by + (an === 'a' ? 26 : -18), col, { s: 9.5, b: true, c: '#e67e22' }); }
        if (k > 0.3 && k < 1) { const wy = cy - s * 0.8 - (k - 0.3) * s * 1.6; M3.sphere(g, W / 2, wy, 9, '#2471a3', '#85c1e9'); T(g, 'H₂O', W / 2, wy - 13, col, { b: true, s: 10, c: '#2471a3' }); }
        T(g, '১', x1 + s + 6, cy + 12, col, { s: 8.5, c: col.mu }); T(g, '৪', x2 - s - 8, cy + 12, col, { s: 8.5, c: col.mu });
      } else {
        const x0 = wd ? 0 : 0, w0 = wd ? W * 0.55 : W, cy = wd ? H / 2 : 110; const fs = wd ? 12 : 9;
        T(g, k < 0.95 ? 'গ্লাইসিন + অ্যালানিন' : 'গ্লাইসিলঅ্যালানিন (Gly-Ala) + H₂O', w0 / 2, 16, col, { b: true, s: 11 });
        const gx = w0 * (wd ? 0.3 : 0.37) - (1 - k) * 14, ax = w0 * (wd ? 0.66 : 0.6) + (1 - k) * 14;
        T(g, 'H₂N–CH₂–C', gx - 10, cy + 4, col, { b: true, s: fs, a: 'right' }); T(g, 'O', gx - 16, cy - 20, col, { b: true, s: fs, c: '#cc2418' }); g.strokeStyle = '#cc2418'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(gx - 19, cy - 16); g.lineTo(gx - 19, cy - 6); g.moveTo(gx - 15, cy - 16); g.lineTo(gx - 15, cy - 6); g.stroke();
        if (k < 0.6) T(g, '–OH', gx - 8, cy + 4, col, { b: true, s: fs, a: 'left', c: '#e67e22' }); if (k < 0.6) T(g, 'H–', ax - 10, cy + 4, col, { b: true, s: fs, a: 'right', c: '#e67e22' });
        T(g, 'N(H)–CH(CH₃)–COOH', ax - 8, cy + 4, col, { b: true, s: fs, a: 'left' });
        if (k >= 0.6) { g.fillStyle = 'rgba(241,196,15,.3)'; rr(g, gx - 26, cy - 30, ax - gx + 50, 44, 8); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(gx - 8, cy); g.lineTo(ax - 10, cy); g.stroke(); T(g, 'পেপটাইড বন্ধন (–CO–NH–)', (gx + ax) / 2, cy + 30, col, { b: true, s: 9.5, c: '#b7950b' }); }
        if (k > 0.3 && k < 1) { const wy = cy - 30 - (k - 0.3) * 60; M3.sphere(g, (gx + ax) / 2, wy, 8, '#2471a3', '#85c1e9'); T(g, 'H₂O', (gx + ax) / 2, wy - 12, col, { b: true, s: 9.5, c: '#2471a3' }); }
        // resonance note
        T(g, 'O=C–N ↔ ⁻O–C=N⁺ : C–N আংশিক দ্বিবন্ধন (১৩২ pm), সমতলীয়', w0 / 2, cy + 56, col, { s: 9, c: col.mu });
        const x1 = wd ? W * 0.55 : 0, w1 = wd ? W * 0.45 : W, y1 = wd ? 0 : cy + 70, h1 = wd ? H : H - y1; cam.cx = x1 + w1 / 2; cam.cy = y1 + h1 / 2 + 8; M3.fit(pm, cam, w1, h1 - 24, 0.88); if (!cam.user) cam.yaw += 0.004;
        const hl = {}; hl[2] = '#f1c40f'; hl[4] = '#f1c40f'; M3.render(g, pm, cam, { mode: 'bs', col, hl, labels: 'hetero' }); T(g, 'Gly-Ala (৩D)', cam.cx, y1 + 14, col, { s: 10, b: true });
      }
    };
    const info = () => { out.innerHTML = md === 'gly' ? `${TXB('\\ce{C6H12O6 + C6H12O6 -> C12H22O11 + H2O}')}<div class="small">গ্লাইকোসাইড বন্ধন: একটি মনোস্যাকারাইডের অ্যানোমেরিক কার্বনের (C1) –OH ও অন্য অণুর –OH থেকে পানি অপসারণে তৈরি C–O–C সংযোগ। মল্টোজ (α-১,৪), সুক্রোজ (α-গ্লুকোজ C1 – β-ফ্রুক্টোজ C2, ১→২), ল্যাকটোজ (β-১,৪ গ্যালাক্টোজ-গ্লুকোজ)। স্টার্চ (অ্যামাইলোজ: α-১,৪; অ্যামাইলোপেকটিন: শাখায় α-১,৬) ও গ্লাইকোজেন আমাদের এনজাইমে পরিপাক হয়; সেলুলোজের β-১,৪ বন্ধন ভাঙার এনজাইম মানুষের নেই — গবাদিপশুর পাকস্থলীর অণুজীব পারে। আর্দ্রবিশ্লেষণে (H⁺ বা এনজাইম) বন্ধন ভেঙে আবার মনোস্যাকারাইড।</div>` : `${TXB('\\ce{H2NCH2COOH + H2NCH(CH3)COOH -> H2NCH2CO-NHCH(CH3)COOH + H2O}')}<div class="small">পেপটাইড বন্ধন: একটি অ্যামিনো এসিডের –COOH ও অন্যটির –NH₂ এর ঘনীভবনে তৈরি –CO–NH– (অ্যামাইড) বন্ধন। n টি অ্যামিনো এসিডে (n − ১) টি পেপটাইড বন্ধন ও (n − ১) অণু পানি অপসারিত। ৫০ এর বেশি অ্যামিনো এসিডের পলিপেপটাইডকে প্রোটিন বলা হয়। প্রোটিনের গঠনস্তর: প্রাথমিক (অ্যামিনো এসিডের ক্রম), গৌণ (α-হেলিক্স, β-শিট — H বন্ধন), তৃতীয় (ত্রিমাত্রিক ভাঁজ), চতুর্থ (একাধিক শিকলের সমাবেশ, যেমন হিমোগ্লোবিন)। নাইলন-৬,৬ এও একই অ্যামাইড বন্ধন।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.3); if (p >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'md', v => { md = v; el.querySelector('[data-seg=an], [data-k=an]') && 0; el.querySelectorAll('.seg')[1].style.display = v === 'gly' ? '' : 'none'; p = 0; run = true; info(); });
    X.onSeg(el, 'an', v => { an = v; p = 0; run = true; });
    q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
