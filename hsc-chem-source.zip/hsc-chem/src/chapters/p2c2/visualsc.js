/* ২য় পত্র অধ্যায় ২ visuals part c (12) — 2.21–2.23 organic compounds in daily life (3D gallery), environmental impact (greenhouse, ozone, plastics, biomagnification), polythene & formalin pros/cons balance + formalin test, and chapter-2 concept map */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const tr = (L, name) => M3.relax(M3.tree(L, { name }));
const chainC = (n, name) => tr(Array.from({ length: n }, (_, i) => ['C', i - 1]), name);

/* ======================= ২.২১ দৈনন্দিন জীবনে জৈব যৌগ ======================= */
const CATS = [['food', 'খাদ্য', '#e67e22'], ['fuel', 'জ্বালানি', '#c0392b'], ['med', 'ওষুধ', '#2980b9'], ['cloth', 'বস্ত্র ও প্লাস্টিক', '#8e44ad'], ['clean', 'পরিচ্ছন্নতা', '#16a085'], ['agri', 'কৃষি', '#27ae60'], ['cos', 'প্রসাধনী', '#d35400']];
const ITEMS = [
  ['food', 'গ্লুকোজ', 'C₆H₁₂O₆', '–CHO, –OH (অ্যালডোহেক্সোজ)', 'শ্বসনে শক্তির প্রধান উৎস; স্টার্চ ও সেলুলোজের একক; স্যালাইনে', () => tr([['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 3], ['C', 4], ['O', 0, 2], ['O', 1], ['O', 2], ['O', 3], ['O', 4], ['O', 5]], 'গ্লুকোজ (খোলা শিকল)')],
  ['food', 'ইথানয়িক এসিড (ভিনেগার)', 'CH₃COOH', '–COOH', 'আচার ও খাদ্য সংরক্ষণ (৪–৮% দ্রবণ), সস', () => M3.LIB.aceticAcid()],
  ['food', 'ইথাইল বিউটানয়েট', 'C₃H₇COOC₂H₅', '–COO– (এস্টার)', 'আনারসের কৃত্রিম সুগন্ধি; খাদ্য ও পানীয়ে ফ্লেভার', () => tr([['C', -1], ['C', 0], ['C', 1], ['C', 2], ['O', 3, 2], ['O', 3], ['C', 5], ['C', 6]], 'ইথাইল বিউটানয়েট')],
  ['fuel', 'মিথেন', 'CH₄', 'অ্যালকেন', 'প্রাকৃতিক গ্যাস (~৯৫%), বায়োগ্যাস; রান্না, বিদ্যুৎ, সার কারখানা', () => M3.LIB.methane()],
  ['fuel', 'বিউটেন', 'C₄H₁₀', 'অ্যালকেন', 'LPG সিলিন্ডারের প্রধান উপাদান (প্রোপেনসহ)', () => M3.LIB.butane()],
  ['fuel', 'অকটেন', 'C₈H₁₈', 'অ্যালকেন', 'পেট্রলের উপাদান; ২,২,৪-ট্রাইমিথাইলপেন্টেন দিয়ে অকটেন সংখ্যা মাপা হয়', () => chainC(8, 'অকটেন')],
  ['med', 'প্যারাসিটামল', 'C₈H₉NO₂', 'ফেনলীয় –OH, অ্যামাইড', 'জ্বর ও ব্যথানাশক', () => M3.areneX({ 0: 'OH', 3: 'NHCOCH3' }, 'প্যারাসিটামল')],
  ['med', 'অ্যাসপিরিন', 'C₉H₈O₄', '–COOH, এস্টার', 'ব্যথা, প্রদাহ ও জ্বরনাশক; হৃদরোগ প্রতিরোধ', () => M3.areneX({ 0: 'OCOCH3', 1: 'COOH' }, 'অ্যাসপিরিন')],
  ['cloth', 'ভিনাইল ক্লোরাইড', 'CH₂=CHCl', 'C=C, –Cl', 'PVC পাইপ, তারের আবরণের মনোমার', () => tr([['C', -1], ['C', 0, 2], ['Cl', 1]], 'ভিনাইল ক্লোরাইড')],
  ['cloth', 'ইথিন', 'CH₂=CH₂', 'C=C', 'পলিথিনের মনোমার; ফল পাকানোর হরমোন', () => M3.LIB.ethene()],
  ['clean', 'ইথানল', 'C₂H₅OH', '–OH', 'হ্যান্ড স্যানিটাইজার (৭০%), দ্রাবক, জ্বালানি', () => M3.LIB.ethanol()],
  ['clean', 'ক্লোরোজাইলেনল', 'C₈H₉ClO', 'ফেনলীয় –OH, –Cl', 'ডেটলের সক্রিয় উপাদান — জীবাণুনাশক', () => M3.areneX({ 0: 'OH', 2: 'CH3', 3: 'Cl', 4: 'CH3' }, 'ক্লোরোজাইলেনল')],
  ['agri', 'ইউরিয়া', 'CO(NH₂)₂', 'অ্যামাইড (কার্বামাইড)', 'নাইট্রোজেন সার (৪৬% N) — বাংলাদেশে সবচেয়ে বেশি ব্যবহৃত সার', () => M3.LIB.urea()],
  ['cos', 'গ্লিসারিন', 'C₃H₈O₃', '৩টি –OH', 'লোশন, সাবান ও টুথপেস্টে আর্দ্রতা রক্ষাকারী', () => tr([['C', -1], ['C', 0], ['C', 1], ['O', 0], ['O', 1], ['O', 2]], 'গ্লিসারিন')],
  ['cos', 'প্রোপানোন (অ্যাসিটোন)', 'CH₃COCH₃', '>C=O (কিটোন)', 'নেইল পলিশ রিমুভার, দ্রাবক', () => M3.LIB.acetone()]
];
V.p2c2_dailyOrg = {
  t: 'দৈনন্দিন জীবনে জৈব যৌগ: খাদ্য, জ্বালানি, ওষুধ, বস্ত্র-প্লাস্টিক, পরিচ্ছন্নতা, কৃষি ও প্রসাধনীর ১৫টি যৌগ — ত্রিমাত্রিক মডেল, সংকেত, কার্যকরী মূলক ও ব্যবহার', k: ['3d', 'int'],
  cap: 'উপরে একটি ক্ষেত্র বেছে নাও, তারপর নিচের তালিকা থেকে যৌগ। ত্রিমাত্রিক মডেল ঘোরে (টেনে ঘোরানো যায়); কার্যকরী মূলকের পরমাণুগুলো লেবেলযুক্ত। লক্ষ করো, আগের অংশে শেখা প্রায় প্রতিটি কার্যকরী মূলক — অ্যালকেন, অ্যালকিন, অ্যালকোহল, কিটোন, এসিড, এস্টার, অ্যামাইড, ফেনল — আমাদের রান্নাঘর, ওষুধের বাক্স আর বাথরুমেই আছে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('cat', CATS.map(c => [c[0], c[1]]), 'food')}</div><div data-list style="display:flex;flex-wrap:wrap;gap:4px;margin:0 0 6px"></div>${X.cv('দৈনন্দিন জৈব যৌগ')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), list = el.querySelector('[data-list]');
    const hf = w => wide(w) ? 300 : 340;
    let L = X.fit(c, hf), cat = 'food', idx = 0, m = null; const cam = M3.cam({ yaw: 0.4, pitch: 0.35 }); let t = 0;
    C4.drag3d(c, cam, () => A.draw());
    const items = () => ITEMS.map((it, i) => [it, i]).filter(([it]) => it[0] === cat);
    const pick = i => { idx = i; m = ITEMS[i][5](); const it = ITEMS[i]; out.innerHTML = `<div><b>${it[1]}</b> (${it[2]}) — কার্যকরী মূলক: ${it[3]}।</div><div class="small" style="margin-top:4px">ব্যবহার: ${it[4]}।</div>`; list.querySelectorAll('button').forEach(b => b.classList.toggle('primary', +b.dataset.i === i)); };
    const fill = () => { const its = items(); list.innerHTML = its.map(([it, i]) => `<button class="btn sm" data-i="${i}">${it[1]}</button>`).join(''); list.querySelectorAll('button').forEach(b => b.onclick = () => pick(+b.dataset.i)); pick(its[0][1]); };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); if (!m) return; const cc = CATS.find(z => z[0] === cat)[2]; g.fillStyle = cc; g.globalAlpha = 0.07; rr(g, 4, 4, W - 8, H - 8, 14); g.fill(); g.globalAlpha = 1; cam.cx = W / 2; cam.cy = H / 2 + 10; M3.fit(m, cam, W, H - 40, 0.85); if (!cam.user) cam.yaw += 0.006; M3.render(g, m, cam, { mode: 'bs', col, labels: 'hetero' }); const it = ITEMS[idx]; T(g, `${it[1]} — ${it[2]}`, W / 2, 20, col, { b: true, s: 12, c: cc }); };
    X.onSeg(el, 'cat', v => { cat = v; fill(); });
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    fill(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.২২ পরিবেশে জৈব যৌগের প্রভাব ======================= */
const GHG = [['CO₂', 1, 'শত-হাজার বছর', '#7f8c8d'], ['CH₄', 28, '১২ বছর', '#e67e22'], ['N₂O', 265, '১২১ বছর', '#16a085'], ['HFC-134a', 1300, '১৩ বছর', '#2980b9'], ['CFC-11', 4660, '৪৫ বছর', '#8e44ad'], ['CFC-12', 10200, '১০০ বছর', '#c0392b']];
const DEG = [['কলার খোসা', 0.08], ['কাগজের ব্যাগ', 0.1], ['সুতি কাপড়', 0.4], ['পাটের ব্যাগ', 1.5], ['পলিথিন ব্যাগ', 20], ['ফোম (পলিস্টাইরিন) কাপ', 50], ['PET বোতল', 450]];
const BIO = [['পানি', 0.000003, '#5dade2'], ['প্ল্যাংকটন', 0.04, '#58d68d'], ['ছোট মাছ', 0.5, '#f4d03f'], ['বড় মাছ', 2, '#eb984e'], ['মাছখেকো পাখি', 25, '#cb4335']];
V.p2c2_env = {
  t: 'পরিবেশে জৈব যৌগের প্রভাব: গ্রিনহাউস গ্যাসের বৈশ্বিক উষ্ণায়ন সম্ভাবনা, CFC দিয়ে ওজোন স্তর ক্ষয়ের মুক্তমূলক শৃঙ্খল (অ্যানিমেশন), প্লাস্টিকের বিয়োজন সময় এবং DDT এর জৈব বিবর্ধন', k: ['anim', 'int', '2d'],
  cap: 'চারটি ট্যাব: (১) "গ্রিনহাউস" — CO₂ কে ১ ধরে ১০০ বছরে প্রতি কেজি গ্যাসের উষ্ণায়ন ক্ষমতা (GWP, লগ স্কেল): মিথেন ২৮ গুণ, CFC-12 দশ হাজার গুণেরও বেশি। (২) "ওজোন" — স্ট্র্যাটোস্ফিয়ারে UV তে CFC ভেঙে Cl• মুক্ত হয়; Cl• একটি O₃ ভেঙে ClO• হয়, ClO• একটি O পরমাণুর সাথে বিক্রিয়ায় আবার Cl• ফিরে পায় — চক্র চলতে থাকে, একটি Cl• প্রায় এক লক্ষ O₃ অণু ধ্বংস করে; গণনা দেখো। (৩) "প্লাস্টিক" — বিভিন্ন বর্জ্যের আনুমানিক বিয়োজন সময় (লগ স্কেল)। (৪) "জৈব বিবর্ধন" — অবিয়োজ্য, চর্বিতে দ্রবণীয় DDT খাদ্যশিকলের প্রতিটি ধাপে ঘনীভূত হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('tb', [['ghg', 'গ্রিনহাউস'], ['oz', 'ওজোন'], ['pl', 'প্লাস্টিক'], ['bio', 'জৈব বিবর্ধন']], 'ghg')}</div>${X.cv('পরিবেশে জৈব যৌগ')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 320 : 400;
    let L = X.fit(c, hf), tb = 'ghg', t = 0, cyc = 0;
    const logBars = (g, col, rows, vmin, vmax, unit, W, H) => { const lx = wide(W) ? 150 : 110, lw = W - lx - 70, n = rows.length, bh = (H - 50) / n - 8; rows.forEach((r, i) => { const y = 30 + i * (bh + 8), f = (Math.log10(r[1]) - Math.log10(vmin)) / (Math.log10(vmax) - Math.log10(vmin)); T(g, r[0], lx - 6, y + bh * 0.65, col, { a: 'right', s: 10 }); g.fillStyle = r[3] || '#7f8c8d'; g.fillRect(lx, y, Math.max(3, lw * f), bh); T(g, bn(r[1]) + unit, lx + Math.max(3, lw * f) + 4, y + bh * 0.65, col, { a: 'left', s: 9.5 }); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      if (tb === 'ghg') { T(g, 'বৈশ্বিক উষ্ণায়ন সম্ভাবনা (GWP₁₀₀, CO₂ = ১, লগ স্কেল)', W / 2, 16, col, { b: true, s: 10.5 }); logBars(g, col, GHG, 0.5, 20000, '', W, H); }
      else if (tb === 'pl') { T(g, 'আনুমানিক বিয়োজন সময় (বছর, লগ স্কেল; পরিবেশভেদে ভিন্ন)', W / 2, 16, col, { b: true, s: 10.5 }); logBars(g, col, DEG.map((d, i) => [d[0], d[1], '', i < 4 ? '#27ae60' : '#c0392b']), 0.03, 1000, ' বছর', W, H); }
      else if (tb === 'bio') { T(g, 'DDT এর জৈব বিবর্ধন (ppm) — খাদ্যশিকলের ধাপে ধাপে', W / 2, 16, col, { b: true, s: 10.5 }); const n = BIO.length; BIO.forEach((b, i) => { const lv = n - 1 - i, y = 30 + lv * (H - 50) / n, lbl = `${b[0]}: ${bn(b[1])} ppm`, w2 = Math.max((g.font = `bold 10.5px ${col.font}`, g.measureText(lbl).width + 24), (W - 60) * (0.25 + 0.75 * (i + 1) / n) * 0.9), x = W / 2 - w2 / 2; g.fillStyle = b[2]; g.globalAlpha = 0.85; rr(g, x, y, w2, (H - 50) / n - 6, 8); g.fill(); g.globalAlpha = 1; T(g, lbl, W / 2, y + ((H - 50) / n - 6) / 2 + 4, col, { b: true, s: 10.5, c: '#1c1c1c' }); }); T(g, 'পানি থেকে পাখিতে প্রায় ৮০ লক্ষ গুণ ঘনীভবন', W / 2, H - 6, col, { s: 9.5, c: col.mu }); }
      else {
        const k = (t * 0.35) % 1, step = Math.floor(k * 3), f = (k * 3) % 1; T(g, 'স্ট্র্যাটোস্ফিয়ারে ওজোন ক্ষয়: Cl• মুক্তমূলক শৃঙ্খল', W / 2, 16, col, { b: true, s: 10.5 });
        const cx = W / 2, cy = H / 2 + 6, R = Math.min(W, H) * 0.27; const pos = [[cx, cy - R], [cx + R * 0.87, cy + R * 0.5], [cx - R * 0.87, cy + R * 0.5]];
        const lab = ['Cl• + O₃ → ClO• + O₂', 'ClO• + O → Cl• + O₂', 'নিট: O₃ + O → 2O₂ (Cl• অপরিবর্তিত)'];
        g.strokeStyle = col.mu; g.lineWidth = 1.5; g.beginPath(); g.arc(cx, cy, R, 0, 7); g.stroke();
        pos.forEach((p, i) => { const on = i === step; g.fillStyle = on ? (i === 2 ? '#2f9e44' : '#c0392b') : col.sf; g.strokeStyle = col.mu; rr(g, p[0] - 78, p[1] - 14, 156, 28, 10); g.fill(); g.stroke(); T(g, lab[i], p[0], p[1] + 4, col, { s: 9.5, b: on, c: on ? '#fff' : col.fg }); });
        const a = -Math.PI / 2 + (step + f) * 2 * Math.PI / 3; M3.sphere(g, cx + R * Math.cos(a), cy + R * Math.sin(a), 8, '#27ae60', '#a9dfbf'); T(g, 'Cl•', cx + R * Math.cos(a), cy + R * Math.sin(a) - 12, col, { b: true, s: 9.5, c: '#27ae60' });
        T(g, `ধ্বংসপ্রাপ্ত O₃ অণু: ${bn(Math.floor(cyc))}`, cx, cy + 4, col, { b: true, s: 12, c: '#c0392b' }); T(g, 'CF₂Cl₂ —(UV)→ CF₂Cl• + Cl•', cx, H - 8, col, { s: 9.5, c: col.mu });
      }
    };
    const info = () => { out.innerHTML = { ghg: `<div>গ্রিনহাউস গ্যাস পৃথিবী থেকে বিকিরিত অবলোহিত রশ্মি শোষণ করে (IR সক্রিয় কম্পন) — বায়ুমণ্ডল উষ্ণ হয়। মিথেনের উৎস: ধানক্ষেত, গবাদিপশু, ময়লার ভাগাড়, গ্যাস লিক। CFC নিষিদ্ধ হওয়ার পর বিকল্প HFC ওজোন ক্ষয় করে না কিন্তু শক্তিশালী গ্রিনহাউস গ্যাস — কিগালি সংশোধনীতে (২০১৬) এগুলোও কমানো হচ্ছে।</div>`, oz: `<div>CFC (ফ্রিয়ন) অত্যন্ত স্থিতিশীল বলে নিম্ন বায়ুমণ্ডলে না ভেঙে স্ট্র্যাটোস্ফিয়ারে পৌঁছায়; সেখানে তীব্র UV তে C–Cl বন্ধন ভাঙে।</div>${TXB('\\ce{CF2Cl2 ->[h\\nu] CF2Cl^{\\bullet} + Cl^{\\bullet}}')}${TXB('\\ce{Cl^{\\bullet} + O3 -> ClO^{\\bullet} + O2}')}${TXB('\\ce{ClO^{\\bullet} + O -> Cl^{\\bullet} + O2}')}<div class="small">ওজোন স্তর সূর্যের ক্ষতিকর UV-B শোষণ করে; ক্ষয়ে ত্বকের ক্যান্সার ও চোখে ছানি বাড়ে। মন্ট্রিয়ল প্রোটোকলে (১৯৮৭) CFC নিষিদ্ধ — ওজোন স্তর ধীরে পুনরুদ্ধার হচ্ছে।</div>`, pl: `<div>পলিথিন ও অন্যান্য প্লাস্টিকে কেবল শক্তিশালী C–C ও C–H বন্ধন, কোনো আর্দ্রবিশ্লেষণযোগ্য মূলক নেই এবং জলভীরু — অণুজীবের এনজাইম আক্রমণ করতে পারে না। সূর্যালোকে ভেঙে মাইক্রোপ্লাস্টিক হয়ে মাছ ও মানুষের শরীরে ঢোকে; নর্দমা বন্ধ করে জলাবদ্ধতা ঘটায়; পোড়ালে (বিশেষত PVC) HCl ও ডাইঅক্সিন। সমাধান: কম ব্যবহার, পুনর্ব্যবহার, পাট ও কাগজের বিকল্প, জৈব-বিয়োজ্য পলিমার (PLA)।</div>`, bio: `<div>DDT (ডাইক্লোরোডাইফিনাইলট্রাইক্লোরোইথেন) একসময় ম্যালেরিয়ার মশা নিধনে ব্যাপক ব্যবহৃত হতো। এটি রাসায়নিকভাবে স্থিতিশীল (বিয়োজিত হয় না) এবং চর্বিতে দ্রবণীয় (পানিতে নয়) — তাই প্রাণীর চর্বিতে জমে, মলমূত্রে বের হয় না; প্রতিটি শিকারী অনেক শিকার খায়, তাই ঘনমাত্রা ধাপে ধাপে বাড়ে। পাখির ডিমের খোসা পাতলা হয়ে বংশবৃদ্ধি কমে যায় (রাচেল কারসন, "সাইলেন্ট স্প্রিং", ১৯৬২)। স্টকহোম কনভেনশনে (২০০১) কৃষিতে নিষিদ্ধ।</div>` }[tb]; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (tb === 'oz') cyc += dt * 0.35 * 3 * 5 * (1 + cyc / 400); } draw(); }, { paused: false });
    X.onSeg(el, 'tb', v => { tb = v; cyc = 0; t = 0; info(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.২৩ পলিথিন ও ফরমালিন: দাঁড়িপাল্লা ও ফরমালিন পরীক্ষা ======================= */
const PC = {
  poly: ['পলিথিন', [['সস্তা ও হালকা', 2], ['পানিরোধী, টেকসই', 2], ['খাদ্য সংরক্ষণে স্বাস্থ্যসম্মত মোড়ক', 2], ['চিকিৎসা সামগ্রী (স্যালাইন ব্যাগ, গ্লাভস)', 3], ['তাপনম্য — পুনর্ব্যবহারযোগ্য', 1]], [['শত বছরেও পচে না', 3], ['নর্দমা বন্ধ — জলাবদ্ধতা ও বন্যা', 3], ['মাইক্রোপ্লাস্টিক — মাছ ও মানুষের শরীরে', 3], ['পোড়ালে বিষাক্ত ধোঁয়া', 2], ['মাটির উর্বরতা কমায়, পশু খেয়ে মারা যায়', 2]], 'বাংলাদেশে ২০০২ সাল থেকে পাতলা পলিথিন ব্যাগ উৎপাদন ও ব্যবহার নিষিদ্ধ (পরিবেশ সংরক্ষণ আইন)। বিকল্প: পাট, কাপড়, কাগজের ব্যাগ; পাটের সেলুলোজ থেকে "সোনালি ব্যাগ"।'],
  form: ['ফরমালিন', [['জীববিজ্ঞানের নমুনা ও মৃতদেহ সংরক্ষণ', 3], ['হাসপাতালে জীবাণুমুক্তকরণ', 2], ['প্লাস্টিক ও রেজিন শিল্প (বেকেলাইট, মেলামাইন)', 2], ['টিকা তৈরিতে জীবাণু নিষ্ক্রিয়করণ', 2]], [['খাদ্যে ভেজাল — মাছ, ফল, দুধে অবৈধ প্রয়োগ', 3], ['ক্যান্সারজনক (IARC গ্রুপ ১)', 3], ['চোখ, নাক ও শ্বাসনালিতে জ্বালা, হাঁপানি', 2], ['যকৃৎ ও বৃক্কের ক্ষতি', 2]], 'ফরমালিন = ৩৭–৪০% HCHO এর জলীয় দ্রবণ (মিথানলসহ স্থিতিশীলকারী)। HCHO প্রোটিনের –NH₂ গ্রুপের সাথে বিক্রিয়ায় আড়াআড়ি বন্ধন তৈরি করে প্রোটিন শক্ত করে ও অণুজীব মারে — তাই সংরক্ষক, আবার একই কারণে মানবকোষের জন্য বিষাক্ত। খাদ্যে ফরমালিন মেশানো নিরাপদ খাদ্য আইন, ২০১৩ এ দণ্ডনীয়।']
};
V.p2c2_polyForm = {
  t: 'শিক্ষার্থীর কাজ: পলিথিন ও ফরমালিনের সুবিধা-অসুবিধা — ইন্টারঅ্যাকটিভ দাঁড়িপাল্লা এবং মাছে ফরমালিন শনাক্তকরণ কিট পরীক্ষার অনুকরণ (বর্ণ তীব্রতা বনাম ঘনমাত্রা)', k: ['anim', 'int', '2d'],
  cap: '"দাঁড়িপাল্লা" মোডে পলিথিন বা ফরমালিন বেছে নাও; সুবিধা (বাঁ পাল্লা, সবুজ) ও অসুবিধা (ডান পাল্লা, লাল) এর প্রতিটি বিষয়ে চাপ দিলে সেটি পাল্লায় ওঠে — গুরুত্ব অনুযায়ী ভার আলাদা। নিজে বিচার করো কোন দিক ভারী। "ফরমালিন পরীক্ষা" মোডে মাছের নমুনায় ফরমালিনের ঘনমাত্রা স্লাইডারে ঠিক করো ও "পরীক্ষা করো" চাপো: কিটের বিকারক HCHO এর সাথে বিক্রিয়ায় বেগুনি বর্ণ দেয়, ঘনমাত্রা যত বেশি বর্ণ তত গাঢ়। তাজা মাছেও প্রাকৃতিকভাবে সামান্য ফরমালডিহাইড থাকে (প্রায় ১–২ ppm পর্যন্ত, পচনের সাথে বাড়ে) — তাই কেবল সীমার বেশি হলেই ভেজাল ধরা হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['bal', 'দাঁড়িপাল্লা'], ['kit', 'ফরমালিন পরীক্ষা']], 'bal')}${X.seg('it', [['poly', 'পলিথিন'], ['form', 'ফরমালিন']], 'poly')}</div><div data-pros style="display:flex;flex-wrap:wrap;gap:4px;margin:0 0 6px"></div>${X.cv('পলিথিন ও ফরমালিন')}<div class="ctl" data-kitrow style="display:none;flex-wrap:wrap"><label class="small" style="flex:1;min-width:160px">নমুনায় ফরমালডিহাইড = <b data-cv></b> ppm<input type="range" min="0" max="60" step="0.5" value="1" data-c></label><button class="btn sm primary" data-go>▶ পরীক্ষা করো</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), pros = q('[data-pros]');
    const hf = w => wide(w) ? 300 : 360;
    let L = X.fit(c, hf), md = 'bal', it = 'poly', sel = new Set(), ang = 0, t = 0, conc = 1, p = 1, run = false;
    const fillPros = () => { const d = PC[it]; pros.innerHTML = d[1].map((x, i) => `<button class="btn sm" data-k="p${i}" style="border-color:#2f9e44">＋ ${x[0]}</button>`).join('') + d[2].map((x, i) => `<button class="btn sm" data-k="c${i}" style="border-color:#c0392b">－ ${x[0]}</button>`).join(''); pros.querySelectorAll('button').forEach(b => b.onclick = () => { const k = b.dataset.k; sel.has(k) ? sel.delete(k) : sel.add(k); b.classList.toggle('primary', sel.has(k)); info(); }); };
    const wts = () => { const d = PC[it]; let a = 0, b = 0; sel.forEach(k => { const i = +k.slice(1); if (k[0] === 'p') a += d[1][i][1]; else b += d[2][i][1]; }); return [a, b]; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      if (md === 'bal') { const [a, b] = wts(), target = Math.max(-0.35, Math.min(0.35, (b - a) * 0.05)); ang += (target - ang) * 0.08; const cx = W / 2, cy = 70, arm = Math.min(W * 0.36, 230);
        g.fillStyle = col.mu; g.fillRect(cx - 4, cy, 8, H - cy - 20); g.fillRect(cx - 40, H - 22, 80, 8); M3.sphere(g, cx, cy, 7, '#555', '#bbb');
        const lx = cx - arm * Math.cos(ang), ly = cy - arm * Math.sin(ang), rx = cx + arm * Math.cos(ang), ry = cy + arm * Math.sin(ang); g.strokeStyle = col.fg; g.lineWidth = 4; g.beginPath(); g.moveTo(lx, ly); g.lineTo(rx, ry); g.stroke();
        const pan = (x, y, cc, items, label) => { g.strokeStyle = col.mu; g.lineWidth = 1; g.beginPath(); g.moveTo(x, y); g.lineTo(x - 50, y + 60); g.moveTo(x, y); g.lineTo(x + 50, y + 60); g.stroke(); g.fillStyle = cc; g.globalAlpha = 0.25; g.beginPath(); g.ellipse(x, y + 62, 58, 10, 0, 0, 7); g.fill(); g.globalAlpha = 1; items.forEach((s, i) => { const bx = x - 50 + (i % 3) * 34, by = y + 50 - Math.floor(i / 3) * 16; g.fillStyle = cc; rr(g, bx, by, 32, 13, 4); g.fill(); T(g, bn(s[1]), bx + 16, by + 10, col, { s: 9, b: true, c: '#fff' }); }); T(g, label, x, y + 90, col, { b: true, s: 11, c: cc }); };
        const d = PC[it]; const pi = [], ci = []; sel.forEach(k => { const i = +k.slice(1); (k[0] === 'p' ? pi : ci).push(k[0] === 'p' ? d[1][i] : d[2][i]); });
        pan(lx, ly, '#2f9e44', pi, `সুবিধা (${bn(a)})`); pan(rx, ry, '#c0392b', ci, `অসুবিধা (${bn(b)})`); T(g, `${d[0]}: ${sel.size ? (a > b ? 'সুবিধার দিক ভারী' : b > a ? 'অসুবিধার দিক ভারী' : 'সমান') : 'বিষয়গুলো পাল্লায় তোলো'}`, cx, 22, col, { b: true, s: 12 });
      } else {
        const k = Math.min(1, p), tx = W * 0.3, ty = 40, TL = H - 100; const inten = Math.min(1, conc / 30) * k; M3.tube(g, tx, ty, TL, 44, 0, `rgba(${Math.round(240 - 110 * inten)},${Math.round(235 - 190 * inten)},${Math.round(245 - 60 * inten)},0.75)`, 0.55, col); T(g, 'নমুনা + কিট বিকারক', tx, ty - 10, col, { s: 10, b: true });
        // reference chart
        const rx0 = W * 0.52, rw = W * 0.42; T(g, 'রং তুলনা চার্ট (ppm)', rx0 + rw / 2, 30, col, { b: true, s: 10 }); [0, 2, 5, 10, 20, 40].forEach((v, i) => { const x = rx0 + i * rw / 6, ii = Math.min(1, v / 30); g.fillStyle = `rgb(${Math.round(240 - 110 * ii)},${Math.round(235 - 190 * ii)},${Math.round(245 - 60 * ii)})`; rr(g, x + 2, 42, rw / 6 - 6, 34, 6); g.fill(); g.strokeStyle = col.mu; g.stroke(); T(g, bn(v), x + rw / 12, 92, col, { s: 9.5 }); });
        if (k >= 1) { const ok = conc <= 2; T(g, ok ? 'স্বাভাবিক সীমার মধ্যে — ভেজাল নয়' : conc <= 5 ? 'সন্দেহজনক — পুনরায় পরীক্ষা প্রয়োজন' : 'ফরমালিন মেশানো হয়েছে — খাওয়ার অনুপযুক্ত', rx0 + rw / 2, 130, col, { b: true, s: 11.5, c: ok ? '#2f9e44' : conc <= 5 ? '#e67e22' : '#c0392b' }); }
        T(g, 'সতর্কতা: দ্রুত কিট কেবল প্রাথমিক স্ক্রিনিং; নিশ্চিতকরণ পরীক্ষাগারে বর্ণালিমাপক (স্পেকট্রোফটোমিটার) দিয়ে।', W / 2, H - 10, col, { s: 9, c: col.mu });
      }
    };
    const info = () => { if (md === 'kit') { q('[data-cv]').textContent = bn(conc); out.innerHTML = `<div>বেশিরভাগ দ্রুত শনাক্তকরণ কিট বর্ণমিতিক: ক্রোমোট্রপিক এসিড, শিফ বা অনুরূপ বিকারক ফরমালডিহাইডের সাথে বিক্রিয়া করে বেগুনি-গোলাপি বর্ণ দেয়, বর্ণের তীব্রতা ঘনমাত্রার সমানুপাতিক (বিয়ার-ল্যাম্বার্ট সূত্র)। মনে রাখো: মাছ ও কিছু ফলে প্রাকৃতিকভাবে অল্প ফরমালডিহাইড থাকে; ফরমালিন মেশানো মাছ শক্ত, আঁশটে গন্ধহীন, মাছি বসে না এবং চোখ ঘোলা ও লালচে হয় না।</div>`; return; }
      const d = PC[it], [a, b] = wts(); out.innerHTML = `<div><b>${d[0]}:</b> ${d[3]}</div><div class="small" style="margin-top:4px">তোমার মূল্যায়ন — সুবিধা ${bn(a)}, অসুবিধা ${bn(b)}। ${it === 'poly' ? 'সিদ্ধান্ত: পলিথিন নিজে ক্ষতিকর নয় — সমস্যা একবার-ব্যবহার্য ব্যবহার ও অব্যবস্থাপিত বর্জ্য। চিকিৎসা ও দীর্ঘস্থায়ী কাজে ব্যবহার যুক্তিসংগত; বাজারের ব্যাগে বিকল্প জরুরি।' : 'সিদ্ধান্ত: ফরমালিন নিয়ন্ত্রিত ক্ষেত্রে (পরীক্ষাগার, শিল্প, চিকিৎসা) অপরিহার্য; কিন্তু খাদ্যে প্রয়োগ সম্পূর্ণ অগ্রহণযোগ্য ও শাস্তিযোগ্য অপরাধ।'}</div>`; };
    X.onSeg(el, 'md', v => { md = v; q('[data-kitrow]').style.display = v === 'kit' ? 'flex' : 'none'; pros.style.display = v === 'bal' ? 'flex' : 'none'; el.querySelectorAll('.seg')[1].style.display = v === 'bal' ? '' : 'none'; info(); });
    X.onSeg(el, 'it', v => { it = v; sel = new Set(); fillPros(); info(); });
    q('[data-c]').oninput = e => { conc = +e.target.value; p = 0; info(); }; q('[data-go]').onclick = () => { p = 0; run = true; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.5); if (p >= 1) run = false; } } draw(); }, { paused: false });
    fillPros(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= অধ্যায় ২ ধারণা মানচিত্র ======================= */
const CG = [['A', 'মৌলিক ধারণা ও নামকরণ', '#2d6fd6'], ['B', 'সমাণুতা ও অ্যারোমেটিসিটি', '#8e44ad'], ['C', 'বিক্রিয়া, শনাক্তকরণ ও বর্ণালি', '#c0392b'], ['D', 'প্রয়োগ, পলিমার ও পরিবেশ', '#27ae60']];
const CN = [
  ['s0', '২.০ জৈব যৌগ ও ক্যাটিনেশন', 'A', 'উহলারের ইউরিয়া (১৮২৮) প্রাণশক্তি মতবাদ ভাঙে; কার্বনের চতুর্যোজ্যতা ও ক্যাটিনেশন', 'p2c2s0a'],
  ['s1', '২.১ বন্ধন ও সংকরণ', 'A', 'sp³ (১০৯.৫°), sp² (১২০°), sp (১৮০°); σ ও π বন্ধন', 'p2c2s1a'],
  ['s2', '২.২–২.৩ সমগোত্রীয় শ্রেণি ও কার্যকরী মূলক', 'A', 'CₙH₂ₙ₊₂; ক্রমিক সদস্যে –CH₂– পার্থক্য; কার্যকরী মূলক ধর্ম ঠিক করে', 'p2c2s2a'],
  ['s5', '২.৪–২.৫ শ্রেণি চিহ্নিতকরণ ও IUPAC নামকরণ', 'A', 'দীর্ঘতম শিকল, ক্ষুদ্রতম অবস্থান সংখ্যা, অগ্রাধিকার ক্রম', 'p2c2s5a'],
  ['s6', '২.৬–২.৭ সমাণুতা', 'B', 'গাঠনিক (শিকল, অবস্থান, মূলক, মেটামারিজম, টটোমারিজম) ও স্টেরিও (সিস-ট্রান্স, আলোক); ২ⁿ আলোক সমাণু', 'p2c2s6a'],
  ['s8', '২.৮–২.৯ অ্যারোমেটিক হাইড্রোকার্বন', 'B', 'বেনজিন: বিস্থানীকৃত ৬π, হাকেল (৪n + ২); ইলেকট্রোফিলিক প্রতিস্থাপন', 'p2c2s8a'],
  ['s10', '২.১০ বিক্রিয়ার কৌশল', 'C', 'সংযোজন (মারকনিকভ), প্রতিস্থাপন (SN1/SN2), অপসারণ (E1/E2), অরিয়েন্টেশন', 'p2c2s10a'],
  ['s11', '২.১১ শ্রেণিভিত্তিক প্রস্তুতি ও রূপান্তর', 'C', 'অ্যালকেন → অ্যামাইড; কার্বন বাড়ানো (KCN, গ্রিগনার্ড) ও কমানো (হফম্যান, সোডালাইম)', 'p2c2s11a'],
  ['s12', '২.১২ কার্যকরী মূলক শনাক্তকরণ', 'C', 'NaHCO₃, FeCl₃, ২,৪-DNP, টলেন্স, ফেলিং, আয়োডোফর্ম, লুকাস, কার্বিলঅ্যামিন', 'p2c2s12a'],
  ['s13', '২.১৩ IR বর্ণালি', 'C', 'O–H ৩২০০–৩৫৫০ (চওড়া), C=O ১৬৫০–১৮০০ (তীক্ষ্ণ); হুকের সূত্র', 'p2c2s13a'],
  ['s14', '২.১৪ গ্লিসারিন ও ফেনল', 'D', 'সাবানীকরণে গ্লিসারিন; ফেনলের অম্লত্ব (রেজোন্যান্স), কিউমিন পদ্ধতি', 'p2c2s14a'],
  ['s15', '২.১৫ বিস্ফোরক ও ওষুধ', 'D', 'নাইট্রোগ্লিসারিন, TNT, ডেটল, প্যারাসিটামল, অ্যাসপিরিন', 'p2c2s15a'],
  ['s16', '২.১৬–২.১৭ গলনাঙ্ক ও স্ফুটনাঙ্ক', 'D', 'তীক্ষ্ণ গলনাঙ্ক = বিশুদ্ধ; মিশ্র গলনাঙ্ক; থিলে নল; সিওলোবফ', 'p2c2s16a'],
  ['s17', '২.১৮–২.১৯ পলিমার', 'D', 'সংযোজন (PE, PVC, টেফলন) ও ঘনীভবন (নাইলন, টেরিলিন, বেকেলাইট); তাপনম্য বনাম তাপস্থাপক', 'p2c2s17a'],
  ['s18', '২.২০ গ্লাইকোসাইড ও পেপটাইড বন্ধন', 'D', 'α/β(১→৪) — স্টার্চ বনাম সেলুলোজ; –CO–NH– ও প্রোটিন', 'p2c2s18a'],
  ['s19', '২.২১–২.২৩ জীবন, পরিবেশ ও সমাজ', 'D', 'খাদ্য, জ্বালানি, ওষুধ; গ্রিনহাউস, ওজোন, প্লাস্টিক; পলিথিন ও ফরমালিন', 'p2c2s19a']
];
const CE = [['s0', 's1', 'কার্বনের বন্ধন'], ['s1', 's2', 'কাঠামো'], ['s2', 's5', 'নাম'], ['s5', 's6', 'একই সংকেত, ভিন্ন গঠন'], ['s1', 's8', 'sp² ও বিস্থানীকরণ'], ['s8', 's10', 'প্রতিস্থাপন'], ['s2', 's10', 'মূলকের সক্রিয়তা'], ['s10', 's11', 'কৌশল → সংশ্লেষণ'], ['s11', 's12', 'উৎপাদ যাচাই'], ['s12', 's13', 'যন্ত্রে নিশ্চিতকরণ'], ['s11', 's14', 'অ্যালকোহল ও ফেনল'], ['s14', 's15', 'নাইট্রেশন'], ['s12', 's16', 'বিশুদ্ধতা'], ['s10', 's17', 'সংযোজন/ঘনীভবন'], ['s17', 's18', 'প্রাকৃতিক পলিমার'], ['s17', 's19', 'প্লাস্টিক দূষণ'], ['s15', 's19', 'ওষুধ']];
V.p2c2_conceptMap = {
  t: 'অধ্যায় ২ (জৈব রসায়ন) এর ধারণা মানচিত্র: ১৬টি মূল ধারণা চারটি স্তম্ভে — মৌলিক ধারণা, সমাণুতা ও অ্যারোমেটিসিটি, বিক্রিয়া-শনাক্তকরণ-বর্ণালি, এবং প্রয়োগ-পলিমার-পরিবেশ — ও তাদের সংযোগ', k: ['int', '2d'],
  cap: 'যেকোনো ধারণায় চাপ দাও: সেটির সাথে যুক্ত রেখাগুলো ও সংযোগের কারণ উজ্জ্বল হয়; নিচে মূল তথ্য এবং সরাসরি সেই পাঠে যাওয়ার বোতাম। চারটি রঙিন স্তম্ভ অধ্যায়ের চারটি বড় অংশ। পুরো অধ্যায়ের যুক্তি: কার্বনের বন্ধন → কাঠামো ও নাম → একই সংকেতে ভিন্ন গঠন → বিক্রিয়ার কৌশল → শ্রেণিগুলোর রূপান্তর → উৎপাদ শনাক্তকরণ → বাস্তব প্রয়োগ।',
  html: () => `${X.cv('অধ্যায় ২ এর ধারণা মানচিত্র')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 470 : 760;
    let L = X.fit(c, hf), sel = 's11', boxes = [];
    const layout = () => { const { W, H } = L, wd = wide(W), P = {}; CG.forEach(([gid], gi) => { const ns = CN.filter(n => n[2] === gid); ns.forEach((n, j) => { if (wd) { const cw = (W - 20) / 4; P[n[0]] = [10 + cw * (gi + 0.5), 56 + j * ((H - 70) / Math.max(4, ns.length))]; } else { const rowsBefore = CG.slice(0, gi).reduce((a, [g2]) => a + Math.ceil(CN.filter(z => z[2] === g2).length / 2), 0); const r = rowsBefore + Math.floor(j / 2); P[n[0]] = [W * (j % 2 ? 0.74 : 0.26), 50 + gi * 30 + r * 64]; } }); }); return P; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), P = layout(); boxes = [];
      if (wd) CG.forEach(([gid, nm, cc], gi) => { const cw = (W - 20) / 4; g.fillStyle = cc; g.globalAlpha = 0.07; rr(g, 12 + cw * gi, 6, cw - 4, H - 12, 12); g.fill(); g.globalAlpha = 1; T(g, nm, 10 + cw * (gi + 0.5), 24, col, { b: true, s: 10, c: cc }); });
      else CG.forEach(([gid, nm, cc], gi) => { const ns = CN.filter(n => n[2] === gid), y0 = P[ns[0][0]][1] - 34; T(g, nm, W / 2, y0 + 4, col, { b: true, s: 10, c: cc }); });
      CE.forEach(([a, b, lab]) => { const on = a === sel || b === sel, pa = P[a], pb = P[b]; g.strokeStyle = on ? col.acc : col.mu; g.globalAlpha = on ? 1 : 0.25; g.lineWidth = on ? 2 : 1; g.beginPath(); g.moveTo(pa[0], pa[1]); g.bezierCurveTo(pa[0] + (pb[0] - pa[0]) * 0.5, pa[1], pa[0] + (pb[0] - pa[0]) * 0.5, pb[1], pb[0], pb[1]); g.stroke(); g.globalAlpha = 1; if (on) { const mx = (pa[0] + pb[0]) / 2, my = (pa[1] + pb[1]) / 2; g.font = `9px ${col.font}`; const tw = g.measureText(lab).width + 8; g.fillStyle = col.sf; rr(g, mx - tw / 2, my - 8, tw, 14, 5); g.fill(); T(g, lab, mx, my + 3, col, { s: 9, c: col.acc }); } });
      CN.forEach(n => { const [x, y] = P[n[0]], cc = CG.find(z => z[0] === n[2])[2], on = n[0] === sel; g.font = `${on ? 'bold ' : ''}${wd ? 9.5 : 9}px ${col.font}`; const words = n[1].split(' '), lines = []; let ln = ''; const mw = wd ? (W - 20) / 4 - 20 : W * 0.44; words.forEach(w2 => { if (g.measureText(ln + ' ' + w2).width > mw - 12 && ln) { lines.push(ln); ln = w2; } else ln = ln ? ln + ' ' + w2 : w2; }); lines.push(ln); const bw = Math.min(mw, Math.max(...lines.map(s => g.measureText(s).width)) + 14), bh = lines.length * 12 + 10; g.fillStyle = on ? cc : col.sf; g.strokeStyle = cc; g.lineWidth = on ? 2 : 1.2; rr(g, x - bw / 2, y - bh / 2, bw, bh, 8); g.fill(); g.stroke(); lines.forEach((s, i) => T(g, s, x, y - bh / 2 + 15 + i * 12, col, { s: wd ? 9.5 : 9, b: on, c: on ? '#fff' : col.fg })); boxes.push([x - bw / 2, y - bh / 2, bw, bh, n[0]]); });
    };
    const info = () => { const n = CN.find(z => z[0] === sel), links = CE.filter(([a, b]) => a === sel || b === sel).map(([a, b, lab]) => { const o = CN.find(z => z[0] === (a === sel ? b : a)); return `${o[1]} (${lab})`; }); out.innerHTML = `<div><b>${n[1]}:</b> ${n[3]}।</div><div class="small" style="margin-top:4px">সংযোগ: ${links.join('; ')}।</div><div style="margin-top:6px"><button class="btn sm" data-act="lesson" data-id="${n[4]}">এই পাঠে যাও →</button></div>`; };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, b = boxes.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (b) { sel = b[4]; info(); draw(); } });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};
})();
