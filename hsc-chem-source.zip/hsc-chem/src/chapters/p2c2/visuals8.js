/* ২য় পত্র অধ্যায় ২ visuals part 8 — 2.11: functional-group interconversion map & puzzle, alcohol oxidation/Lucas, carbonyl tests, nucleophilic addition (3D), acid/base strength ladder, esterification equilibrium */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm, cross, dot, len } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = M3.ease;

/* ======================= ২.১১ জৈব রূপান্তর মানচিত্র ও ধাঁধা ======================= */
const RN = {
  alkane: ['অ্যালকেন', 'C₂H₆', 0.07, 0.42, '#7f8c8d'], alkene: ['অ্যালকিন', 'C₂H₄', 0.24, 0.14, '#2d6fd6'], alkyne: ['অ্যালকাইন', 'C₂H₂', 0.46, 0.05, '#8e44ad'],
  halide: ['হ্যালাইড', 'C₂H₅Br', 0.24, 0.62, '#16a085'], grig: ['গ্রিগনার্ড', 'C₂H₅MgBr', 0.07, 0.86, '#27ae60'], alcohol: ['অ্যালকোহল', 'C₂H₅OH', 0.46, 0.42, '#c0392b'],
  ether: ['ইথার', 'C₂H₅OC₂H₅', 0.36, 0.95, '#d35400'], aldehyde: ['অ্যালডিহাইড', 'CH₃CHO', 0.66, 0.2, '#e67e22'], ketone: ['কিটোন', 'CH₃COCH₃', 0.66, 0.58, '#f39c12'],
  acid: ['এসিড', 'CH₃COOH', 0.84, 0.34, '#e74c3c'], ester: ['এস্টার', 'CH₃COOC₂H₅', 0.95, 0.1, '#9b59b6'], amide: ['অ্যামাইড', 'CH₃CONH₂', 0.95, 0.62, '#2980b9'],
  amine: ['অ্যামিন', 'CH₃NH₂', 0.8, 0.9, '#1f618d'], nitrile: ['নাইট্রাইল', 'C₂H₅CN', 0.56, 0.86, '#117a65']
};
const RE = [
  ['alkene', 'alkane', 'H₂/Ni', 'CH2=CH2 + H2 ->[\\text{Ni},\\ 300\\ ^\\circ\\mathrm{C}] CH3CH3', 'সংযোজন (হাইড্রোজেনেশন)'],
  ['alkyne', 'alkene', 'H₂/Pd-BaSO₄', 'HC#CH + H2 ->[\\text{Pd/BaSO}_4] CH2=CH2', 'আংশিক হাইড্রোজেনেশন (লিন্ডলার প্রভাবক)'],
  ['alkane', 'halide', 'Br₂/hν', 'CH3CH3 + Br2 ->[h\\nu] CH3CH2Br + HBr', 'মুক্তমূলক প্রতিস্থাপন'],
  ['alkene', 'halide', 'HBr', 'CH2=CH2 + HBr -> CH3CH2Br', 'ইলেকট্রোফিলিক সংযোজন'],
  ['halide', 'alkene', 'KOH (অ্যালকোহলীয়)', 'CH3CH2Br + KOH ->[\\text{অ্যালকোহল},\\ \\Delta] CH2=CH2 + KBr + H2O', 'অপসারণ (E2)'],
  ['halide', 'alcohol', 'KOH (জলীয়)', 'CH3CH2Br + KOH(aq) -> CH3CH2OH + KBr', 'নিউক্লিওফিলিক প্রতিস্থাপন (SN2)'],
  ['alcohol', 'halide', 'PBr₃ বা HBr', '3C2H5OH + PBr3 -> 3C2H5Br + H3PO3', 'প্রতিস্থাপন'],
  ['alkene', 'alcohol', 'H₂O/H₂SO₄', 'CH2=CH2 + H2O ->[\\text{H}_3\\text{PO}_4\\text{ বা H}_2\\text{SO}_4] CH3CH2OH', 'জলযোজন (মারকনিকভ)'],
  ['alcohol', 'alkene', 'গাঢ় H₂SO₄, ১৭০ °C', 'CH3CH2OH ->[\\text{গাঢ় H}_2\\text{SO}_4,\\ 170\\ ^\\circ\\mathrm{C}] CH2=CH2 + H2O', 'নিরুদন (অপসারণ)'],
  ['alkene', 'alkyne', 'Br₂; তারপর KOH (অ্যালকোহলীয়)', 'CH2=CH2 ->[\\text{Br}_2] BrCH2CH2Br ->[2\\text{KOH (অ্যালকোহল)}] HC#CH', 'সংযোজন + দ্বৈত অপসারণ'],
  ['alkyne', 'aldehyde', 'H₂O/HgSO₄', 'HC#CH + H2O ->[\\text{HgSO}_4/\\text{H}_2\\text{SO}_4,\\ 60\\ ^\\circ\\mathrm{C}] CH3CHO', 'জলযোজন + টটোমারকরণ'],
  ['alkyne', 'ketone', 'H₂O/HgSO₄ (প্রোপাইন)', 'CH3C#CH + H2O ->[\\text{HgSO}_4/\\text{H}_2\\text{SO}_4] CH3COCH3', 'মারকনিকভ জলযোজন'],
  ['alkene', 'aldehyde', 'O₃; Zn/H₂O', 'CH3CH=CHCH3 ->[1)\\ \\text{O}_3\\ 2)\\ \\text{Zn/H}_2\\text{O}] 2CH3CHO', 'ওজোনোলাইসিস'],
  ['halide', 'ether', 'C₂H₅ONa', 'C2H5Br + C2H5ONa -> C2H5OC2H5 + NaBr', 'উইলিয়ামসন সংশ্লেষণ (SN2)'],
  ['alcohol', 'aldehyde', 'K₂Cr₂O₇/H⁺ (পাতন)', 'CH3CH2OH + [O] ->[\\text{K}_2\\text{Cr}_2\\text{O}_7/\\text{H}^+] CH3CHO + H2O', 'জারণ (১° অ্যালকোহল)'],
  ['alcohol', 'ketone', 'K₂Cr₂O₇/H⁺ (২° অ্যালকোহল)', 'CH3CH(OH)CH3 + [O] -> CH3COCH3 + H2O', 'জারণ'],
  ['aldehyde', 'acid', 'K₂Cr₂O₇/H⁺ বা টলেন্স', 'CH3CHO + [O] -> CH3COOH', 'জারণ'],
  ['aldehyde', 'alcohol', 'NaBH₄ বা H₂/Ni', 'CH3CHO + 2[H] -> CH3CH2OH', 'বিজারণ'],
  ['ketone', 'alcohol', 'NaBH₄', 'CH3COCH3 + 2[H] -> CH3CH(OH)CH3', 'বিজারণ (২° অ্যালকোহল)'],
  ['acid', 'alcohol', 'LiAlH₄', 'CH3COOH + 4[H] ->[\\text{LiAlH}_4] CH3CH2OH + H2O', 'বিজারণ'],
  ['acid', 'ester', 'C₂H₅OH/H⁺', 'CH3COOH + C2H5OH <=>[\\text{গাঢ় H}_2\\text{SO}_4] CH3COOC2H5 + H2O', 'এস্টারীকরণ'],
  ['ester', 'acid', 'H₃O⁺ / NaOH', 'CH3COOC2H5 + H2O <=>[\\text{H}^+] CH3COOH + C2H5OH', 'আর্দ্রবিশ্লেষণ'],
  ['acid', 'amide', 'NH₃, তাপ', 'CH3COOH + NH3 -> CH3COONH4 ->[\\Delta] CH3CONH2 + H2O', 'অ্যামাইড গঠন'],
  ['amide', 'amine', 'Br₂/NaOH', 'CH3CONH2 + Br2 + 4NaOH -> CH3NH2 + Na2CO3 + 2NaBr + 2H2O', 'হফম্যান অবনমন (এক C কমে)'],
  ['amide', 'acid', 'H₃O⁺, তাপ', 'CH3CONH2 + H2O + H+ -> CH3COOH + NH4+', 'আর্দ্রবিশ্লেষণ'],
  ['halide', 'nitrile', 'KCN', 'CH3CH2Br + KCN -> CH3CH2CN + KBr', 'প্রতিস্থাপন (এক C বাড়ে)'],
  ['nitrile', 'acid', 'H₃O⁺, তাপ', 'CH3CH2CN + 2H2O + H+ -> CH3CH2COOH + NH4+', 'আর্দ্রবিশ্লেষণ'],
  ['nitrile', 'amine', 'LiAlH₄ বা H₂/Ni', 'CH3CH2CN + 4[H] -> CH3CH2CH2NH2', 'বিজারণ'],
  ['halide', 'amine', 'NH₃ (অতিরিক্ত)', 'C2H5Br + 2NH3 -> C2H5NH2 + NH4Br', 'অ্যামোনোলাইসিস'],
  ['halide', 'alkane', 'Na, শুষ্ক ইথার (উর্টজ)', '2CH3Br + 2Na ->[\\text{শুষ্ক ইথার}] CH3CH3 + 2NaBr', 'উর্টজ বিক্রিয়া'],
  ['acid', 'alkane', 'NaOH/CaO (Na লবণ)', 'CH3COONa + NaOH ->[\\text{CaO},\\ \\Delta] CH4 + Na2CO3', 'ডিকার্বক্সিলেশন (এক C কমে)'],
  ['halide', 'grig', 'Mg, শুষ্ক ইথার', 'CH3CH2Br + Mg ->[\\text{শুষ্ক ইথার}] CH3CH2MgBr', 'গ্রিগনার্ড বিকারক'],
  ['grig', 'alcohol', 'HCHO; H₃O⁺', 'C2H5MgBr + HCHO -> C2H5CH2OMgBr ->[\\text{H}_3\\text{O}^+] C2H5CH2OH', 'নিউক্লিওফিলিক সংযোজন'],
  ['grig', 'acid', 'CO₂; H₃O⁺', 'C2H5MgBr + CO2 -> C2H5COOMgBr ->[\\text{H}_3\\text{O}^+] C2H5COOH', 'কার্বক্সিলেশন'],
  ['grig', 'alkane', 'H₂O', 'C2H5MgBr + H2O -> C2H6 + Mg(OH)Br', 'প্রোটনীকরণ']
];
V.p2c2_rxnMap = {
  t: 'জৈব যৌগের পারস্পরিক রূপান্তর মানচিত্র: ১৪টি শ্রেণি ও ৩৫টি বিক্রিয়া (বিকারক, শর্ত ও সমীকরণ) — এবং "A থেকে B" সংশ্লেষণ ধাঁধা', k: ['int', '2d'],
  cap: '"মানচিত্র" মোডে যেকোনো শ্রেণিতে চাপ দাও — সেখান থেকে বের হওয়া সব রূপান্তর তীর উজ্জ্বল হয়, তীরের উপর বিকারক লেখা থাকে; বিকারকে চাপ দিলে নিচে পূর্ণ সমীকরণ ও বিক্রিয়ার ধরন। "ধাঁধা" মোডে একটি শুরুর ও একটি লক্ষ্য যৌগ দেওয়া হয়: বর্তমান যৌগ থেকে বের হওয়া বিকারকগুলোর একটি একটি করে বেছে লক্ষ্যে পৌঁছাও। ন্যূনতম ধাপের সাথে তোমার ধাপ তুলনা হয়। এক কার্বন বাড়ানোর (KCN, গ্রিগনার্ড + CO₂) ও কমানোর (হফম্যান, ডিকার্বক্সিলেশন) পথগুলো বিশেষভাবে লক্ষ করো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['map', 'মানচিত্র'], ['pz', 'ধাঁধা: A থেকে B']], 'map')}<button class="btn sm" data-new style="display:none">নতুন ধাঁধা</button></div>${X.cv('রূপান্তর মানচিত্র')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 440 : 620;
    let L = X.fit(c, hf), md = 'map', sel = 'alcohol', selE = null, boxes = [], labs = [], pz = null, t = 0;
    const adj = id => RE.map((e, i) => [e, i]).filter(([e]) => e[0] === id);
    const bfs = (a, b) => { const prev = { [a]: null }, qq = [a]; while (qq.length) { const u = qq.shift(); if (u === b) break; adj(u).forEach(([e]) => { if (!(e[1] in prev)) { prev[e[1]] = u; qq.push(e[1]); } }); } if (!(b in prev)) return null; let n = 0, u = b; while (prev[u]) { u = prev[u]; n++; } return n; };
    const newPz = () => { const ids = Object.keys(RN); let a, b, d; do { a = ids[Math.floor(Math.random() * ids.length)]; b = ids[Math.floor(Math.random() * ids.length)]; d = a !== b ? bfs(a, b) : null; } while (!d || d < 2 || d > 4); pz = { a, b, cur: a, steps: [], best: d }; sel = a; selE = null; info(); };
    const P = id => { const { W, H } = L, n = RN[id]; return [30 + n[2] * (W - 60), 24 + n[3] * (H - 48)]; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W); boxes = []; labs = [];
      const focus = md === 'pz' ? pz.cur : sel;
      RE.forEach((e, i) => { const [x1, y1] = P(e[0]), [x2, y2] = P(e[1]), on = e[0] === focus, done = md === 'pz' && pz.steps.includes(i); const dx = x2 - x1, dy = y2 - y1, l = Math.hypot(dx, dy), ux = dx / l, uy = dy / l, off = 4; const sx = x1 + ux * 30 - uy * off, sy = y1 + uy * 16 - ux * -off, ex = x2 - ux * 34 - uy * off, ey = y2 - uy * 18 + ux * off; g.strokeStyle = done ? '#2f9e44' : on ? RN[e[0]][4] : col.mu; g.globalAlpha = on || done ? 1 : (md === 'pz' ? 0.12 : 0.22); g.lineWidth = on || done ? 2.2 : 1; g.beginPath(); g.moveTo(sx, sy); g.lineTo(ex, ey); g.stroke(); const a = Math.atan2(ey - sy, ex - sx); g.fillStyle = g.strokeStyle; g.beginPath(); g.moveTo(ex, ey); g.lineTo(ex - 7 * Math.cos(a - 0.4), ey - 7 * Math.sin(a - 0.4)); g.lineTo(ex - 7 * Math.cos(a + 0.4), ey - 7 * Math.sin(a + 0.4)); g.fill(); g.globalAlpha = 1;
        if (on) { const mx = sx + (ex - sx) * 0.55, my = sy + (ey - sy) * 0.55; g.font = `${selE === i ? 'bold ' : ''}${wd ? 9.5 : 8.5}px ${col.font}`; const s = e[2], tw = g.measureText(s).width + 8; g.fillStyle = selE === i ? RN[e[0]][4] : col.sf; g.strokeStyle = RN[e[0]][4]; g.lineWidth = 1; rr(g, mx - tw / 2, my - 8, tw, 15, 5); g.fill(); g.stroke(); g.fillStyle = selE === i ? '#fff' : col.fg; g.textAlign = 'center'; g.fillText(s, mx, my + 3); labs.push([mx - tw / 2, my - 8, tw, 15, i]); } });
      Object.entries(RN).forEach(([id, n]) => { const [x, y] = P(id), on = id === focus, tgt = md === 'pz' && id === pz.b, st = md === 'pz' && id === pz.a; g.font = `bold ${wd ? 10.5 : 9.5}px ${col.font}`; const w2 = Math.max(g.measureText(n[0]).width, g.measureText(n[1]).width) + 14; g.fillStyle = on ? n[4] : col.sf; g.strokeStyle = tgt ? '#f1c40f' : n[4]; g.lineWidth = tgt ? 3.5 : on ? 2 : 1.4; rr(g, x - w2 / 2, y - 16, w2, 32, 9); g.fill(); g.stroke(); g.fillStyle = on ? '#fff' : n[4]; g.textAlign = 'center'; g.fillText(n[0], x, y - 3); g.font = `${wd ? 9 : 8}px ${col.font}`; g.fillStyle = on ? '#fff' : col.fg; g.fillText(n[1], x, y + 10); if (tgt) { g.fillStyle = '#b7950b'; g.font = `bold 9px ${col.font}`; g.fillText('লক্ষ্য', x, y - 21); } if (st && !on) { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText('শুরু', x, y - 21); } boxes.push([x - w2 / 2, y - 16, w2, 32, id]); });
    };
    const info = () => { if (md === 'pz') { const done = pz.cur === pz.b; out.innerHTML = `<div><b>ধাঁধা:</b> ${RN[pz.a][0]} (${RN[pz.a][1]}) থেকে <b>${RN[pz.b][0]} (${RN[pz.b][1]})</b> তৈরি করো। ন্যূনতম ধাপ: ${bn(pz.best)}।</div><div class="small" style="margin-top:4px">${pz.steps.length ? 'তোমার পথ: ' + pz.steps.map(i => `${RN[RE[i][0]][0]} →(${RE[i][2]}) ${RN[RE[i][1]][0]}`).join(' ; ') : `বর্তমান: ${RN[pz.cur][0]} — উজ্জ্বল বিকারকগুলোর একটি বেছে নাও।`}</div>${done ? `<div style="font-weight:700;color:var(--ok);margin-top:4px">✓ লক্ষ্যে পৌঁছেছ — ${bn(pz.steps.length)} ধাপে${pz.steps.length === pz.best ? ' (সর্বোত্তম!)' : ` (ন্যূনতম ${bn(pz.best)})`}</div>` : ''}${selE != null ? TXB(`\\ce{${RE[selE][3]}}`) : ''}`; return; }
      const n = RN[sel], outs = adj(sel), ins = RE.filter(e => e[1] === sel); out.innerHTML = selE != null ? `<div><b>${RN[RE[selE][0]][0]} → ${RN[RE[selE][1]][0]}</b> <span class="small">(${RE[selE][4]})</span></div>${TXB(`\\ce{${RE[selE][3]}}`)}` : `<div><b>${n[0]}</b> (উদাহরণ ${n[1]}): এখান থেকে ${bn(outs.length)}টি রূপান্তর, এখানে আসার ${bn(ins.length)}টি পথ। তীরের বিকারকে চাপ দিয়ে সমীকরণ দেখো।</div>`; };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; const lb = labs.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (lb) { selE = lb[4]; if (md === 'pz' && pz.cur !== pz.b) { pz.steps.push(lb[4]); pz.cur = RE[lb[4]][1]; } info(); draw(); return; } const b = boxes.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (b && md === 'map') { sel = b[4]; selE = null; info(); draw(); } });
    X.onSeg(el, 'md', v => { md = v; q('[data-new]').style.display = v === 'pz' ? '' : 'none'; if (v === 'pz') newPz(); else { selE = null; info(); } draw(); });
    q('[data-new]').onclick = () => { newPz(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ২.১১.৪ অ্যালকোহলের জারণ ও লুকাস পরীক্ষা ======================= */
const ALC = {
  p: ['১° — ইথানল', () => M3.LIB.ethanol(), () => M3.LIB.acetaldehyde(), () => M3.LIB.aceticAcid(), 'CH3CH2OH ->[{[O]}] CH3CHO ->[{[O]}] CH3COOH', 'পাতন করে সরিয়ে নিলে অ্যালডিহাইড; রিফ্লাক্সে আরও জারিত হয়ে কার্বক্সিলিক এসিড', 0],
  s: ['২° — প্রোপান-২-অল', () => M3.relax(M3.tree([['C', -1], ['C', 0], ['C', 1], ['O', 1]], { name: 'প্রোপান-২-অল' })), () => M3.LIB.acetone(), null, 'CH3CH(OH)CH3 ->[{[O]}] CH3COCH3', 'কিটোন; কিটোন আর সহজে জারিত হয় না (C–C ভাঙতে হবে)', 300],
  t: ['৩° — ২-মিথাইলপ্রোপান-২-অল', () => M3.relax(M3.tree([['C', -1], ['C', 0], ['C', 1], ['C', 1], ['O', 1]], { name: '২-মিথাইলপ্রোপান-২-অল' })), null, null, '(CH3)3COH ->[{[O]}] \\text{বিক্রিয়া নেই}', 'কার্বিনল কার্বনে H নেই — সাধারণ অবস্থায় জারিত হয় না', 5]
};
V.p2c2_alcOx = {
  t: '১°, ২° ও ৩° অ্যালকোহলের পার্থক্য: অম্লীয় K₂Cr₂O₇ দিয়ে জারণে বর্ণ পরিবর্তন (কমলা → সবুজ) ও উৎপাদ, এবং লুকাস পরীক্ষায় ঘোলা হওয়ার সময়', k: ['anim', 'int', '3d'],
  cap: 'অ্যালকোহল ও পরীক্ষা বেছে নিয়ে "শুরু" চাপো। জারণে কমলা ডাইক্রোমেট (Cr₂O₇²⁻, Cr +৬) বিজারিত হয়ে সবুজ Cr³⁺ হলে বুঝতে হবে অ্যালকোহল জারিত হয়েছে — ১° ও ২° এ হয়, ৩° এ হয় না (–OH যুক্ত কার্বনে H নেই)। ডানে ত্রিমাত্রিক মডেলে অ্যালকোহল → উৎপাদ। লুকাস বিকারকে (অনার্দ্র ZnCl₂ + গাঢ় HCl) অ্যালকোহল অ্যালকাইল ক্লোরাইডে পরিণত হয়, যা অদ্রবণীয় বলে দ্রবণ ঘোলা হয়; কার্বোক্যাটায়নের স্থিতিশীলতা অনুযায়ী ৩° তাৎক্ষণিক, ২° প্রায় ৫ মিনিটে, ১° কক্ষ তাপমাত্রায় ঘোলা হয় না।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('al', [['p', '১°'], ['s', '২°'], ['t', '৩°']], 'p')}${X.seg('ts', [['ox', 'K₂Cr₂O₇/H⁺ জারণ'], ['lu', 'লুকাস পরীক্ষা']], 'ox')}<button class="btn sm primary" data-go>▶ শুরু</button></div>${X.cv('অ্যালকোহলের পরীক্ষা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 520;
    let L = X.fit(c, hf), al = 'p', ts = 'ox', p = 0, run = false, t = 0, mols = []; const cam = M3.cam({ yaw: 0.4, pitch: 0.3 });
    C4.drag3d(c, cam, () => A.draw());
    const build = () => { const d = ALC[al]; mols = [d[1](), d[2] ? d[2]() : null, d[3] ? d[3]() : null]; info(); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), d = ALC[al], k = Math.min(1, p);
      const tx = wd ? W * 0.15 : W * 0.2, ty = 40, TL = wd ? H - 90 : 260;
      if (ts === 'ox') { const ok = al !== 't', f = ok ? Math.min(1, k * 1.4) : 0; const cr = [Math.round(230 - 180 * f), Math.round(110 + 60 * f), Math.round(20 + 40 * f)]; M3.tube(g, tx, ty, TL, 34, 0, `rgba(${cr.join(',')},0.8)`, 0.6, col); if (run && ok) for (let i = 0; i < 6; i++) { const u = (t * 0.6 + i / 6) % 1; g.fillStyle = 'rgba(255,255,255,.6)'; g.beginPath(); g.arc(tx - 8 + (i * 5) % 16, ty + TL - 10 - u * TL * 0.5, 2, 0, 7); g.fill(); } g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(f > 0.6 ? 'সবুজ (Cr³⁺) ✓' : k > 0.6 && !ok ? 'কমলা থাকে ✗' : 'কমলা (Cr₂O₇²⁻)', tx, ty + TL + 18); }
      else { const tm = d[6], el2 = p * 600, turb = tm === 0 ? 0 : Math.max(0, Math.min(1, (el2 - tm) / 40)); M3.tube(g, tx, ty, TL, 34, 0, `rgba(240,240,240,${0.15 + 0.75 * turb})`, 0.6, col); if (turb > 0.05) for (let i = 0; i < 40 * turb; i++) { g.fillStyle = 'rgba(255,255,255,.9)'; g.beginPath(); g.arc(tx - 13 + (i * 37 % 26), ty + TL * 0.45 + (i * 53 % (TL * 0.5)), 1.4, 0, 7); g.fill(); } g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`সময়: ${bn(Math.floor(el2 / 60))} মি ${bn(Math.round(el2 % 60))} সে`, tx, ty + TL + 18); g.fillText(turb > 0.5 ? 'ঘোলা ✓' : tm === 0 && p > 0.9 ? 'পরিষ্কার (কক্ষ তাপমাত্রায়)' : '', tx, ty + TL + 34); }
      // 3D
      const x0 = wd ? W * 0.3 : W * 0.4, w0 = wd ? W * 0.7 : W * 0.6, y0 = 0, h0 = H; const list = ts === 'ox' ? mols.filter(Boolean) : [mols[0]]; const show = ts === 'ox' ? (k < 0.4 ? [0] : k < 0.8 || !mols[2] ? [0, 1] : [0, 1, 2]).filter(i => mols[i]) : [0];
      const n = show.length, vert = !wd, cw = vert ? w0 : w0 / Math.max(1, n), chh = vert ? h0 / Math.max(1, n) : h0; void list;
      show.forEach((mi, j) => { const m = mols[mi], c2 = M3.cam(cam); c2.cx = vert ? x0 + cw / 2 : x0 + cw * (j + 0.5); c2.cy = vert ? y0 + chh * (j + 0.5) + 8 : y0 + h0 / 2 + 6; c2.sc = Math.min(cw * 0.95, chh - 40) / 2 / (m.R + 0.2) * 1.15; c2.D = 40; if (!cam.user) cam.yaw += 0.0015; M3.render(g, m, c2, { mode: 'bs', col, labels: 'hetero' }); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`${m.name} (${M3.formula(m)})`, c2.cx, vert ? y0 + chh * j + 14 : y0 + 16); if (j < n - 1) { g.fillStyle = col.acc; g.font = `bold 16px ${col.font}`; if (vert) g.fillText('↓', c2.cx + cw * 0.38, y0 + chh * (j + 1)); else g.fillText('→', x0 + cw * (j + 1), c2.cy); } });
      if (ts === 'ox' && al === 't' && k > 0.5) { g.fillStyle = '#c0392b'; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText('কার্বিনল কার্বনে H নেই — জারণ হয় না', x0 + w0 / 2, y0 + h0 - 10); }
    };
    const info = () => { const d = ALC[al]; out.innerHTML = ts === 'ox' ? `<div><b>${d[0]}:</b> ${d[5]}।</div>${TXB(`\\ce{${d[4]}}`)}<div class="small">জারক: অম্লীয় K₂Cr₂O₇ — Cr₂O₇²⁻ + 14H⁺ + 6e⁻ → 2Cr³⁺ + 7H₂O; শ্বাস পরীক্ষায় (ব্রেথালাইজার) এই কমলা → সবুজ পরিবর্তনই ব্যবহৃত হতো।</div>` : `<div><b>লুকাস পরীক্ষা — ${d[0]}:</b> ${al === 't' ? 'তাৎক্ষণিক ঘোলা (৩° কার্বোক্যাটায়ন অত্যন্ত স্থিতিশীল, SN1 দ্রুত)' : al === 's' ? 'প্রায় ৫ মিনিটে ঘোলা (২° কার্বোক্যাটায়ন)' : 'কক্ষ তাপমাত্রায় ঘোলা হয় না, উত্তপ্ত করলে ধীরে'}।</div>${TXB('\\ce{R-OH + HCl ->[\\text{অনার্দ্র ZnCl}_2] R-Cl + H2O}')}<div class="small">ZnCl₂ লুইস এসিড হিসেবে –OH এর O এর সাথে যুক্ত হয়ে একে ভালো বিদায়ী গ্রুপ বানায়। উৎপন্ন অ্যালকাইল ক্লোরাইড জলীয় বিকারকে অদ্রবণীয় — তাই ঘোলা দেখায়। (C₆ পর্যন্ত অ্যালকোহলের জন্য প্রযোজ্য।)</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.25); if (p >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'al', v => { al = v; p = 0; run = false; build(); }); X.onSeg(el, 'ts', v => { ts = v; p = 0; run = false; info(); });
    q('[data-go]').onclick = () => { p = 0; run = true; };
    build(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১১.৭ অ্যালডিহাইড ও কিটোনের শনাক্তকরণ পরীক্ষা ======================= */
const CS = [['methanal', 'মিথান্যাল HCHO'], ['ethanal', 'ইথান্যাল CH₃CHO'], ['propanal', 'প্রোপান্যাল C₂H₅CHO'], ['benzal', 'বেনজালডিহাইড C₆H₅CHO'], ['propanone', 'প্রোপানোন CH₃COCH₃'], ['butanone', 'বিউটানোন CH₃COC₂H₅'], ['ethanol', 'ইথানল C₂H₅OH'], ['ipa', 'প্রোপান-২-অল']];
const CT = {
  dnp: ['২,৪-DNP (ব্র্যাডির বিকারক)', { methanal: 1, ethanal: 1, propanal: 1, benzal: 1, propanone: 1, butanone: 1 }, '#f39c12', 'হলুদ-কমলা অধঃক্ষেপ (২,৪-ডাইনাইট্রোফিনাইলহাইড্রাজোন) — সব অ্যালডিহাইড ও কিটোন (>C=O)', 'R2C=O + H2NNHC6H3(NO2)2 -> R2C=NNHC6H3(NO2)2 v + H2O'],
  tol: ['টলেন্স বিকারক', { methanal: 1, ethanal: 1, propanal: 1, benzal: 1 }, '#bdc3c7', 'রুপালি আয়না (Ag) — সব অ্যালডিহাইড; কিটোন নয়', 'RCHO + 2[Ag(NH3)2]+ + 3OH- -> RCOO- + 2Ag v + 4NH3 + 2H2O'],
  feh: ['ফেলিং দ্রবণ', { methanal: 1, ethanal: 1, propanal: 1 }, '#c0392b', 'নীল → ইটের মতো লাল Cu₂O অধঃক্ষেপ — অ্যালিফেটিক অ্যালডিহাইড; অ্যারোমেটিক অ্যালডিহাইড ও কিটোন নয়', 'RCHO + 2Cu^2+ + 5OH- -> RCOO- + Cu2O v + 3H2O'],
  iod: ['আয়োডোফর্ম পরীক্ষা (I₂/NaOH)', { ethanal: 1, propanone: 1, butanone: 1, ethanol: 1, ipa: 1 }, '#f1c40f', 'হলুদ CHI₃ অধঃক্ষেপ, অ্যান্টিসেপ্টিক গন্ধ — CH₃CO– বা CH₃CH(OH)– যুক্ত যৌগ', 'CH3COR + 3I2 + 4NaOH -> CHI3 v + RCOONa + 3NaI + 3H2O'],
  sch: ['শিফ বিকারক', { methanal: 1, ethanal: 1, propanal: 1, benzal: 1 }, '#c2185b', 'বর্ণহীন বিকারক গোলাপি-বেগুনি — অ্যালডিহাইড', 'RCHO + \\text{শিফ বিকারক} -> \\text{গোলাপি-বেগুনি যৌগ}']
};
V.p2c2_carbonylTests = {
  t: 'অ্যালডিহাইড ও কিটোন শনাক্তকরণ: ২,৪-DNP, টলেন্স (রুপালি আয়না), ফেলিং (লাল Cu₂O), আয়োডোফর্ম ও শিফ পরীক্ষা — ৮টি যৌগের ফলাফল সারণি ও অ্যানিমেটেড পরীক্ষানল', k: ['anim', 'int', '2d'],
  cap: 'নিচের সারণির যেকোনো ঘরে চাপ দাও (বা উপরে পরীক্ষা ও যৌগ বেছে "শুরু")। পরীক্ষানলে ফলাফল অ্যানিমেশনে দেখায়: টলেন্সে নলের ভেতরের দেয়ালে রুপালি আয়না জমে, ফেলিংয়ে গাঢ় নীল দ্রবণে ইটের মতো লাল অধঃক্ষেপ, ২,৪-DNP তে হলুদ-কমলা কেলাস, আয়োডোফর্মে হলুদ অধঃক্ষেপ। সারণি দেখায় কোন পরীক্ষা দিয়ে কোন জোড়া আলাদা করা যায়: অ্যালডিহাইড বনাম কিটোন (টলেন্স/ফেলিং), অ্যালিফেটিক বনাম অ্যারোমেটিক অ্যালডিহাইড (ফেলিং), মিথাইল কিটোন/ইথানল (আয়োডোফর্ম)।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ts', Object.entries(CT).map(([k, v]) => [k, v[0].split(' ')[0]]), 'tol')}<select data-sm style="padding:5px;border-radius:8px;border:1px solid var(--line);background:var(--sf);color:var(--fg);font:inherit">${CS.map(s => `<option value="${s[0]}">${s[1]}</option>`).join('')}</select><button class="btn sm primary" data-go>▶ শুরু</button></div>${X.cv('কার্বনিল পরীক্ষা', 240)}<div data-tbl style="overflow-x:auto;margin:6px 0"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), tbl = q('[data-tbl]');
    let L = X.fit(c, () => 240), ts = 'tol', sm = 'ethanal', p = 0, run = false, t = 0;
    const tab = () => { tbl.innerHTML = `<table class="t" style="font-size:12px;min-width:560px"><thead><tr><th>যৌগ</th>${Object.entries(CT).map(([k, v]) => `<th>${v[0].split(' (')[0]}</th>`).join('')}</tr></thead><tbody>${CS.map(s => `<tr><td>${s[1]}</td>${Object.keys(CT).map(k => `<td data-c="${k}|${s[0]}" style="cursor:pointer;text-align:center;${k === ts && s[0] === sm ? 'outline:2px solid var(--acc);' : ''}">${CT[k][1][s[0]] ? '<b style="color:var(--ok)">✓</b>' : '<span style="color:var(--bad)">✗</span>'}</td>`).join('')}</tr>`).join('')}</tbody></table>`; tbl.querySelectorAll('[data-c]').forEach(td => { td.onclick = () => { const [a, b] = td.dataset.c.split('|'); ts = a; sm = b; q('[data-sm]').value = b; el.querySelectorAll('[data-seg=ts] button').forEach(bt => bt.classList.toggle('on', bt.dataset.v === a)); p = 0; run = true; tab(); info(); }; }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const d = CT[ts], pos = !!d[1][sm], k = Math.min(1, p), tx = W / 2, ty = 26, TL = H - 70;
      const base = { tol: 'rgba(230,230,235,.5)', feh: 'rgba(40,90,220,.6)', dnp: 'rgba(240,140,30,.35)', iod: 'rgba(160,90,30,.55)', sch: 'rgba(240,240,240,.3)' }[ts];
      let fill = base; if (pos) { if (ts === 'feh') fill = `rgba(${Math.round(40 + 120 * k)},${Math.round(90 - 30 * k)},${Math.round(220 - 160 * k)},0.6)`; if (ts === 'iod') fill = `rgba(${Math.round(160 + 80 * k)},${Math.round(90 + 120 * k)},${Math.round(30 + 0 * k)},0.55)`; if (ts === 'sch') fill = `rgba(194,24,91,${0.15 + 0.6 * k})`; if (ts === 'dnp') fill = `rgba(240,160,30,${0.35 + 0.3 * k})`; }
      M3.tube(g, tx, ty, TL, 40, 0, fill, 0.6, col);
      if (pos && k > 0.2) { const f = (k - 0.2) / 0.8; if (ts === 'tol') { const gr = g.createLinearGradient(tx - 20, 0, tx + 20, 0); gr.addColorStop(0, `rgba(160,160,170,${f})`); gr.addColorStop(0.3, `rgba(250,250,255,${f})`); gr.addColorStop(0.6, `rgba(150,150,160,${f})`); gr.addColorStop(1, `rgba(220,220,230,${f})`); g.fillStyle = gr; g.fillRect(tx - 20, ty + TL * 0.4, 5, TL * 0.55); g.fillRect(tx + 15, ty + TL * 0.4, 5, TL * 0.55); g.globalAlpha = f * 0.6; g.fillRect(tx - 15, ty + TL * 0.4, 30, TL * 0.55); g.globalAlpha = 1; }
        if (ts === 'feh' || ts === 'iod' || ts === 'dnp') { const cc = ts === 'feh' ? '#b03a2e' : ts === 'iod' ? '#f4d03f' : '#e67e22'; for (let i = 0; i < 60 * f; i++) { g.fillStyle = cc; g.beginPath(); g.arc(tx - 16 + (i * 29 % 32), ty + TL - 14 - (i % 5) * 3 - Math.floor(i / 20) * 3, 2.2, 0, 7); g.fill(); } } }
      if (ts === 'tol' || ts === 'feh') { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('গরম পানিতে উত্তপ্ত', tx + 30, ty + TL - 10); }
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${d[0]} + ${CS.find(s => s[0] === sm)[1]}`, tx, 14); g.fillStyle = k > 0.8 ? (pos ? '#2f9e44' : '#c0392b') : col.mu; g.fillText(k > 0.8 ? (pos ? 'ধনাত্মক ✓' : 'ঋণাত্মক ✗ (কোনো পরিবর্তন নেই)') : '', tx, H - 12);
    };
    const info = () => { const d = CT[ts]; out.innerHTML = `<div><b>${d[0]}:</b> ${d[3]}।</div>${TXB(`\\ce{${d[4]}}`)}`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.4); if (p >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'ts', v => { ts = v; p = 0; tab(); info(); }); q('[data-sm]').onchange = e => { sm = e.target.value; p = 0; tab(); };
    q('[data-go]').onclick = () => { p = 0; run = true; };
    q('[data-sm]').value = sm; tab(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, () => 240); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১১.৭ কার্বনিলে নিউক্লিওফিলিক সংযোজন (ত্রিমাত্রিক) ======================= */
const nucMol = (s, face) => { // ethanal + CN⁻ → cyanohydrin; s: 0..0.6 attack, 0.6..1 protonation
  const k = ease(Math.min(1, s / 0.6)), kp = ease(Math.max(0, (s - 0.6) / 0.4)), zf = face;
  const u0 = { O: [1, 0, 0], H: [-0.5, 0.866, 0], Me: [-0.5, -0.866, 0] };
  const pyr = d => norm(add(d, [0, 0, -0.354 * k * zf])); const dO = pyr(u0.O), dH = pyr(u0.H), dMe = pyr(u0.Me);
  const a = [], b = []; const at = (el, p, o) => { a.push([el, ...p, Object.assign({ noH: true }, o || {})]); return a.length - 1; };
  const C = at('C', [0, 0, 0]); const O = at('O', mul(dO, 1.22 + 0.21 * k), { q: k > 0.6 && kp < 0.5 ? -1 : 0 }); const H1 = at('H', mul(dH, 1.10)); const Cm = at('C', mul(dMe, 1.51));
  const p = norm(cross(dMe, [0, 0, 1])), q2 = cross(dMe, p); [0, 1, 2].forEach(j => { const f = j * 2 * Math.PI / 3 + 0.4, h = add(mul(dMe, 1 / 3), mul(add(mul(p, Math.cos(f)), mul(q2, Math.sin(f))), Math.sqrt(8 / 9))); b.push([Cm, at('H', add(a[Cm].slice(1, 4), mul(h, 1.09)))]); });
  const bd = 107 * Math.PI / 180, dNu0 = [Math.cos(bd), 0, Math.sin(bd) * zf], dNuF = norm(mul(add(add(dO, dH), dMe), -1)); const dNu = norm(add(mul(dNu0, 1 - k), mul(dNuF, k))); const rNu = 3.6 - (3.6 - 1.47) * k;
  const Cn = at('C', mul(dNu, rNu), { q: k < 0.5 ? -1 : 0 }); const N = at('N', mul(dNu, rNu + 1.16));
  b.push([C, O, k < 0.6 ? 2 : 1]); b.push([C, H1]); b.push([C, Cm]); b.push([Cn, N, 3]); if (k > 0.25 && k < 0.7) b.push([C, Cn, 1, 'dash']); else if (k >= 0.7) b.push([C, Cn, 1]);
  // proton from H–CN approaching O
  const hd = norm(add(dO, [0, 0, -0.6 * zf])), hp = add(a[O].slice(1, 4), mul(hd, 0.96 + 2.4 * (1 - kp))); const Hp = at('H', hp); if (kp > 0.6) b.push([O, Hp]); else if (kp > 0.2) b.push([O, Hp, 1, 'dash']);
  const m = M3.mol({ a, b, H: false }); m.idx = { C, O, H1, Cm, Cn }; return m;
};
V.p2c2_nucAdd = {
  t: 'কার্বনিল যৌগে নিউক্লিওফিলিক সংযোজন: ইথান্যালে CN⁻ এর আক্রমণ (বার্গি-ডুনিৎজ কোণ ~১০৭°) — সমতলীয় sp² থেকে চতুস্তলকীয় sp³, অ্যালকক্সাইড ও প্রোটনীকরণে সায়ানোহাইড্রিন (ত্রিমাত্রিক)', k: ['3d', 'anim', 'int'],
  cap: 'চালাও। ইথান্যালের C=O সমতলীয় ও পোলার — কার্বন আংশিক ধনাত্মক। CN⁻ (নীল N, কালো C) তলের উপর থেকে প্রায় ১০৭° কোণে (C=O অক্ষের সাপেক্ষে) কার্বনের দিকে আসে; π বন্ধনের ইলেকট্রন O তে চলে যায় (ঋণাত্মক অ্যালকক্সাইড), কার্বন sp³ হয় — তিনটি গ্রুপ ছাতার মতো নিচে বেঁকে যায়। শেষে HCN থেকে H⁺ এসে O তে যুক্ত হয় — ২-হাইড্রক্সিপ্রোপেননাইট্রাইল (সায়ানোহাইড্রিন)। "নিচ থেকে আক্রমণ" বাছলে অপর এনানসিওমার পাওয়া যায় — দুই দিক থেকে সমান সম্ভাবনা, তাই উৎপাদ রেসেমিক।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('fc', [['1', 'উপর থেকে আক্রমণ'], ['-1', 'নিচ থেকে আক্রমণ']], '1')}<button class="btn sm primary" data-play>▶ চালাও</button></div>${X.cv('নিউক্লিওফিলিক সংযোজন')}<div class="ctl"><label class="small" style="flex:1">অগ্রগতি<input type="range" min="0" max="1" step="0.005" value="0" data-s></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 420;
    let L = X.fit(c, hf), s = 0, face = 1, play = false, t = 0; const cam = M3.cam({ yaw: 0.6, pitch: 0.35 });
    C4.drag3d(c, cam, () => A.draw());
    const chir = m => { const i = m.idx, c0 = m.a[i.C].p, v = [i.O, i.Cn, i.Cm].map(j => sub(m.a[j].p, c0)); return dot(v[0], cross(v[1], v[2])) < 0 ? 'R' : 'S'; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const m = nucMol(s, face); cam.cx = W / 2; cam.cy = H / 2 + 8; cam.sc = Math.min(W / 9, H / 7.5); cam.D = 40; if (!cam.user) cam.yaw = 0.6 + 0.3 * Math.sin(t * 0.3);
      const hl = {}; hl[m.idx.C] = '#f1c40f'; const charges = {}; if (s < 0.35) { charges[m.idx.C] = 1; charges[m.idx.O] = -1; }
      M3.render(g, m, cam, { mode: 'bs', col, hl, charges, labels: 'hetero', center: [0, 0, 0], measure: s < 0.02 ? [] : s < 0.35 ? [[m.idx.O, m.idx.C, m.idx.Cn]] : [] });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(s < 0.1 ? 'CH₃CHO (sp², সমতলীয়) + CN⁻' : s < 0.6 ? 'CN⁻ আক্রমণ: C=O এর π ইলেকট্রন O তে → অ্যালকক্সাইড (sp³)' : s < 0.95 ? 'HCN থেকে প্রোটন O তে' : `সায়ানোহাইড্রিন: (${chir(m)})-২-হাইড্রক্সিপ্রোপেননাইট্রাইল`, W / 2, 16);
    };
    const info = () => { out.innerHTML = `<div>কার্বনিল গ্রুপে C=O পোলার (O বেশি তড়িৎঋণাত্মক) — কার্বন ইলেকট্রোফিলিক, তাই নিউক্লিওফাইল (CN⁻, HSO₃⁻, H⁻, R⁻ গ্রিগনার্ড, NH₂–Z) কার্বনকে আক্রমণ করে। অ্যালডিহাইড কিটোনের চেয়ে বেশি সক্রিয়: একটি মাত্র অ্যালকাইল গ্রুপ — স্থানিক বাধা কম ও +I প্রভাব কম (কার্বন বেশি ধনাত্মক)।</div>${TXB('\\ce{CH3CHO + HCN ->[\\text{CN}^-] CH3CH(OH)CN}')}<div class="small">অন্যান্য নিউক্লিওফিলিক সংযোজন: NaHSO₃ (সাদা কেলাসিত বাইসালফাইট যুক্ত যৌগ), গ্রিগনার্ড বিকারক (অ্যালকোহল), NaBH₄/LiAlH₄ (বিজারণ); NH₂OH, NH₂NH₂, ২,৪-DNP এর ক্ষেত্রে সংযোজনের পর পানি অপসারণ (ঘনীভবন)।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (play) { s = Math.min(1, s + dt * 0.2); q('[data-s]').value = s; if (s >= 1) play = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'fc', v => { face = +v; s = 0; play = true; }); q('[data-s]').oninput = e => { s = +e.target.value; play = false; }; q('[data-play]').onclick = () => { s = 0; play = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১১.৮ এসিড ও ক্ষারকের শক্তি: pKa / pKb সিঁড়ি ======================= */
const ACIDS = [
  ['Cl₃CCOOH', 0.65, 'তিনটি Cl এর প্রবল −I'], ['Cl₂CHCOOH', 1.29, 'দুটি Cl'], ['FCH₂COOH', 2.59, 'F এর −I সবচেয়ে বেশি'], ['ClCH₂COOH', 2.86, 'একটি Cl'], ['BrCH₂COOH', 2.90, ''], ['ICH₂COOH', 3.18, ''], ['HCOOH', 3.75, 'অ্যালকাইল গ্রুপ নেই — সবচেয়ে শক্তিশালী সরল এসিড'], ['C₆H₅COOH', 4.20, 'ফিনাইল গ্রুপ'], ['CH₃CH₂CHClCOOH', 2.86, '২-ক্লোরো (Cl কাছে)'], ['CH₃CHClCH₂COOH', 4.05, '৩-ক্লোরো'], ['ClCH₂CH₂CH₂COOH', 4.52, '৪-ক্লোরো (Cl দূরে — প্রভাব কম)'], ['CH₃COOH', 4.76, 'CH₃ এর +I'], ['CH₃CH₂COOH', 4.87, 'C₂H₅ এর +I বেশি'], ['H₂CO₃', 6.35, 'কার্বনিক এসিড'], ['C₆H₅OH', 9.95, 'ফেনল — ফিনক্সাইড রেজোন্যান্সে স্থিতিশীল'], ['H₂O', 15.7, ''], ['C₂H₅OH', 16, 'অ্যালকোহল — অ্যালকক্সাইড স্থিতিশীল নয়'], ['HC≡CH', 25, 'ইথাইন']
];
const BASES = [
  ['(CH₃)₂NH', 3.27, '২° অ্যামিন — দুটি +I গ্রুপ'], ['CH₃NH₂', 3.36, '১° অ্যামিন'], ['C₂H₅NH₂', 3.25, ''], ['(CH₃)₃N', 4.20, '৩° — জলে দ্রাবণ কম ও স্থানিক বাধা'], ['NH₃', 4.75, 'অ্যামোনিয়া'], ['C₆H₅NH₂', 9.38, 'অ্যানিলিন — N এর জোড় বলয়ে বিস্থানীকৃত'], ['CH₃CONH₂', 15.5, 'অ্যামাইড — কার্যত নিরপেক্ষ (জোড় C=O এর সাথে রেজোন্যান্সে)']
];
V.p2c2_acidBase = {
  t: 'কার্বক্সিলিক এসিড ও অ্যামিনের শক্তি: pKa ও pKb সিঁড়ি — আবেশীয় প্রভাব (সংখ্যা, তড়িৎঋণাত্মকতা ও দূরত্ব), রেজোন্যান্স এবং ০.১ M দ্রবণের pH হিসাব', k: ['int', 'calc', '2d'],
  cap: '"এসিড" বা "ক্ষারক" বেছে নাও; সিঁড়িতে যেকোনো যৌগে চাপ দাও। pKa যত কম, এসিড তত শক্তিশালী (Ka = ১০^−pKa)। নিচে ০.১ M জলীয় দ্রবণের pH ও আয়নন মাত্রা হিসাব হয়। লক্ষ করো: (১) Cl এর সংখ্যা বাড়লে এসিড শক্তিশালী; (২) F > Cl > Br > I (তড়িৎঋণাত্মকতা); (৩) Cl যত দূরে, প্রভাব তত কম (২-, ৩-, ৪-ক্লোরোবিউটানয়িক এসিড); (৪) অ্যালকাইল গ্রুপের +I এসিড দুর্বল করে; (৫) কার্বক্সিলেট আয়ন দুটি সমতুল্য রেজোন্যান্স রূপে স্থিতিশীল — তাই অ্যালকোহলের চেয়ে প্রায় ১০¹¹ গুণ শক্তিশালী। ক্ষারকে অ্যালকাইল গ্রুপ ক্ষারকত্ব বাড়ায়, অ্যারাইল ও অ্যাসাইল কমায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['a', 'এসিড (pKa)'], ['b', 'ক্ষারক (pKb)']], 'a')}</div>${X.cv('এসিড-ক্ষারক শক্তি')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 380 : 620;
    let L = X.fit(c, hf), md = 'a', sel = 11, boxes = [];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), list = md === 'a' ? ACIDS : BASES, mx = md === 'a' ? 26 : 16;
      const ax = wd ? 60 : 50, aw = wd ? W * 0.6 - 60 : W - 70, ay = 26, ah = wd ? H - 50 : H * 0.62, brk = 6; const Y = v => ay + ah * (v <= brk ? 0.62 * v / brk : 0.62 + 0.38 * (v - brk) / (mx - brk));
      g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(ax, ay); g.lineTo(ax, ay + ah); g.stroke(); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; const tk = []; for (let v = 0; v <= brk; v++) tk.push(v); for (let v = brk + (md === 'a' ? 4 : 2); v <= mx; v += md === 'a' ? 4 : 2) tk.push(v); tk.forEach(v => { g.fillText(bn(v), ax - 4, Y(v) + 3); g.globalAlpha = 0.15; g.beginPath(); g.moveTo(ax, Y(v)); g.lineTo(ax + aw, Y(v)); g.stroke(); g.globalAlpha = 1; }); { const yb = Y(brk) + 6; g.fillStyle = col.bg || col.sf; g.fillRect(ax - 5, yb - 3, 10, 7); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(ax - 5, yb - 1); g.lineTo(ax + 5, yb - 4); g.moveTo(ax - 5, yb + 4); g.lineTo(ax + 5, yb + 1); g.stroke(); }
      g.save(); g.translate(ax - 32, ay + ah / 2); g.rotate(-Math.PI / 2); g.textAlign = 'center'; g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.fillText(md === 'a' ? 'pKa (নিচে নামলে দুর্বল এসিড)' : 'pKb (নিচে নামলে দুর্বল ক্ষারক)', 0, 0); g.restore();
      boxes = []; const used = [], ncol = wd ? 3 : 2, cwid = (aw - 14) / ncol; list.forEach((r, i) => { const y = Y(r[1]); let col2 = 0; while (col2 < ncol - 1 && used.some(u => Math.abs(u[0] - y) < 17 && u[1] === col2)) col2++; used.push([y, col2]); const x = ax + 14 + col2 * cwid; const on = i === sel; g.font = `${on ? 'bold ' : ''}${wd ? 9.5 : 8.5}px ${col.font}`; const lab = `${r[0]} ${bn(r[1])}`, tw = Math.min(cwid - 4, g.measureText(lab).width + 10); g.fillStyle = on ? col.acc : col.sf; g.strokeStyle = col.acc; g.lineWidth = 1; rr(g, x, y - 8, tw, 16, 6); g.fill(); g.stroke(); g.fillStyle = on ? '#fff' : col.fg; g.textAlign = 'left'; g.save(); g.beginPath(); g.rect(x, y - 8, tw, 16); g.clip(); g.fillText(lab, x + 5, y + 4); g.restore(); g.strokeStyle = col.mu; g.globalAlpha = 0.5; g.beginPath(); g.moveTo(ax, y); g.lineTo(x, y); g.stroke(); g.globalAlpha = 1; boxes.push([x, y - 8, tw, 16, i]); });
      // conjugate base resonance drawing (acids) / pH calc panel
      const px = wd ? W * 0.66 : 20, py = wd ? 40 : ay + ah + 30; const r = list[sel], K = Math.pow(10, -r[1]), C = 0.1; const x = (-K + Math.sqrt(K * K + 4 * K * C)) / 2;
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`${r[0]} — ০.১ M দ্রবণ`, px, py);
      const pv = md === 'a' ? -Math.log10(x) : 14 + Math.log10(x); const alpha = x / C * 100;
      g.font = `10.5px ${col.font}`; const ex = K.toExponential(2).split('e'), sup = String(+ex[1]).split('').map(ch => '⁻⁰¹²³⁴⁵⁶⁷⁸⁹'['-0123456789'.indexOf(ch)]).join(''); g.fillText(`${md === 'a' ? 'Ka' : 'Kb'} = ${bn(ex[0])} × ১০${sup}`, px, py + 20); g.fillText(`pH ≈ ${bn(Math.min(14, Math.max(0, pv)).toFixed(2))}`, px, py + 38); g.fillText(`আয়নন মাত্রা ≈ ${bn(alpha < 0.01 ? alpha.toExponential(1) : alpha.toFixed(2))}%`, px, py + 56);
      if (md === 'a' && r[0].includes('COOH')) { const cx = wd ? px + 70 : W / 2, cy = py + 120, s2 = 26; [[-1, 0], [1, 1]].forEach(([dx, k2]) => { const ox = cx + dx * 70; g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(ox - s2, cy); g.lineTo(ox, cy); g.stroke(); const o1 = [ox + s2 * 0.6, cy - s2 * 0.8], o2 = [ox + s2 * 0.6, cy + s2 * 0.8]; g.beginPath(); g.moveTo(ox, cy); g.lineTo(o1[0], o1[1]); g.moveTo(ox, cy); g.lineTo(o2[0], o2[1]); g.stroke(); const dbl = k2 ? o2 : o1; g.beginPath(); g.moveTo(ox + 4, cy + (k2 ? 3 : -3)); g.lineTo(dbl[0] + 4, dbl[1] + (k2 ? 0 : 0)); g.stroke(); g.fillStyle = '#cc2418'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('O', o1[0] + 6, o1[1]); g.fillText('O', o2[0] + 6, o2[1] + 8); g.fillStyle = '#c0392b'; g.fillText('−', (k2 ? o1 : o2)[0] + 16, (k2 ? o1 : o2)[1] + (k2 ? -2 : 6)); g.fillStyle = col.fg; g.fillText('R', ox - s2 - 6, cy + 4); }); g.fillStyle = col.acc; g.font = `bold 15px ${col.font}`; g.fillText('↔', cx, cy + 4); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText('কার্বক্সিলেট আয়ন: দুটি সমতুল্য রেজোন্যান্স রূপ', cx, cy + 46); g.fillText('(উভয় C–O দৈর্ঘ্য সমান, ১২৭ pm)', cx, cy + 58); }
    };
    const info = () => { const list = md === 'a' ? ACIDS : BASES, r = list[sel]; out.innerHTML = `<div><b>${r[0]}</b>: ${md === 'a' ? 'pKa' : 'pKb'} = ${bn(r[1])}${r[2] ? ' — ' + r[2] : ''}।</div><div class="small" style="margin-top:4px">${md === 'a' ? 'আবেশীয় প্রভাব: ইলেকট্রন-আকর্ষী গ্রুপ (−I) কার্বক্সিলেট আয়নের ঋণাত্মক চার্জ ছড়িয়ে স্থিতিশীল করে → এসিড শক্তিশালী; ইলেকট্রনদাতা গ্রুপ (+I) চার্জ ঘনীভূত করে → এসিড দুর্বল। প্রভাব দূরত্বের সাথে দ্রুত কমে।' : 'অ্যালকাইল গ্রুপের +I প্রভাব N এর ইলেকট্রন ঘনত্ব বাড়ায় → ক্ষারকত্ব বেশি; জলীয় দ্রবণে দ্রাবণের প্রভাবে ক্রম: ২° > ১° > ৩° > NH₃। অ্যানিলিনে N এর জোড় বেনজিন বলয়ে বিস্থানীকৃত, অ্যামাইডে C=O এর সাথে — তাই দুর্বল।'}</div>`; };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, b = boxes.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (b) { sel = b[4]; info(); draw(); } });
    X.onSeg(el, 'md', v => { md = v; sel = v === 'a' ? 11 : 4; info(); draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ২.১১.৯ এস্টারীকরণ সাম্যাবস্থা ======================= */
V.p2c2_esterify = {
  t: 'এস্টারীকরণ সাম্যাবস্থা: CH₃COOH + C₂H₅OH ⇌ CH₃COOC₂H₅ + H₂O (K ≈ ৪) — প্রাথমিক মোল বদলে উৎপাদন হিসাব, অতিরিক্ত অ্যালকোহল ও পানি অপসারণের প্রভাব এবং ¹⁸O চিহ্নিতকরণ', k: ['int', 'calc', '2d'],
  cap: 'স্লাইডারে এসিড, অ্যালকোহল ও প্রাথমিক পানির মোল বদলাও। সাম্যাবস্থায় চারটি পদার্থের মোল দণ্ডলেখে এবং এস্টারের শতকরা উৎপাদন দেখায় (K = [এস্টার][পানি]/[এসিড][অ্যালকোহল] = ৪ থেকে দ্বিঘাত সমীকরণ সমাধান করে)। সমমোলার মিশ্রণে উৎপাদন মাত্র ৬৬.৭%; অ্যালকোহল বাড়ালে বা পানি সরিয়ে নিলে (ডিন-স্টার্ক যন্ত্র, গাঢ় H₂SO₄ এর জলশোষণ) লা-শাতেলিয়ার নীতি অনুযায়ী উৎপাদন বাড়ে। ডানের লেখচিত্রে অ্যালকোহল : এসিড অনুপাতের সাথে উৎপাদন।',
  html: () => `${X.cv('এস্টারীকরণ')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:120px">এসিড = <b data-av></b> mol<input type="range" min="0.5" max="3" step="0.1" value="1" data-a></label><label class="small" style="flex:1;min-width:120px">অ্যালকোহল = <b data-bv></b> mol<input type="range" min="0.5" max="6" step="0.1" value="1" data-b></label><label class="small" style="flex:1;min-width:120px">প্রাথমিক পানি = <b data-wv></b> mol<input type="range" min="0" max="3" step="0.1" value="0" data-w></label><label class="small"><input type="checkbox" data-rm> পানি অপসারণ</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 480;
    let L = X.fit(c, hf), a = 1, b = 1, w = 0, rm = false; const K = 4;
    const solve = (a2, b2, w2) => { const A2 = 1 - K, B2 = w2 + K * (a2 + b2), C2 = -K * a2 * b2; let x; if (Math.abs(A2) < 1e-9) x = -C2 / B2; else { const D = B2 * B2 - 4 * A2 * C2, r1 = (-B2 + Math.sqrt(D)) / (2 * A2), r2 = (-B2 - Math.sqrt(D)) / (2 * A2); x = [r1, r2].find(v => v >= 0 && v <= Math.min(a2, b2) + 1e-9); } return x; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W); const x = rm ? Math.min(a, b) * 0.99 : solve(a, b, w); const vals = [['এসিড', a - x, '#e74c3c'], ['অ্যালকোহল', b - x, '#c0392b'], ['এস্টার', x, '#9b59b6'], ['পানি', rm ? 0 : w + x, '#3498db']];
      const bx = 50, by = 30, bw = wd ? W * 0.45 : W - 70, bh = wd ? H - 80 : 190, mx = Math.max(3, ...vals.map(v => v[1]));
      g.strokeStyle = col.fg; g.beginPath(); g.moveTo(bx, by); g.lineTo(bx, by + bh); g.lineTo(bx + bw, by + bh); g.stroke(); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; [0, mx / 2, mx].forEach(v => g.fillText(bn(v.toFixed(1)), bx - 4, by + bh - v / mx * bh + 3));
      vals.forEach(([nm, v, cc], i) => { const x0 = bx + 10 + i * (bw - 10) / 4, w2 = (bw - 10) / 4 - 14, h = v / mx * bh; g.fillStyle = cc; g.fillRect(x0, by + bh - h, w2, h); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(v.toFixed(2)), x0 + w2 / 2, by + bh - h - 4); g.font = `9.5px ${col.font}`; g.fillText(nm, x0 + w2 / 2, by + bh + 13); });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText('সাম্যাবস্থায় মোল সংখ্যা', bx, 16);
      // yield vs ratio
      const px = wd ? W * 0.6 : 50, py = wd ? 30 : by + bh + 40, pw = wd ? W * 0.36 : W - 70, ph = wd ? H - 80 : H - py - 40;
      const Pl = cplot(g, { x0: px, y0: py, w: pw, h: ph, xmin: 0, xmax: 10, ymin: 0, ymax: 100, col, xt: [0, 2, 4, 6, 8, 10], yt: [0, 50, 100], xl: 'অ্যালকোহল : এসিড', yl: 'উৎপাদন (%)', ylx: 28 });
      const pts = []; for (let r = 0.2; r <= 10; r += 0.1) pts.push([Pl.X(r), Pl.Y(solve(1, r, 0) * 100)]); path(g, pts, '#9b59b6', 2.2); const yv = (rm ? 99 : x / Math.min(a, b) * 100); M3.sphere(g, Pl.X(Math.min(10, b / a)), Pl.Y(rm ? 99 : (w === 0 ? solve(1, b / a, 0) * 100 : yv)), 6, '#f39c12', '#ffe0a0');
    };
    const info = () => { const x = rm ? Math.min(a, b) * 0.99 : solve(a, b, w); q('[data-av]').textContent = bn(a.toFixed(1)); q('[data-bv]').textContent = bn(b.toFixed(1)); q('[data-wv]').textContent = bn(w.toFixed(1)); out.innerHTML = `<div>সাম্যাবস্থায় এস্টার = ${bn(x.toFixed(2))} mol; সীমিত বিক্রিয়কের সাপেক্ষে উৎপাদন = <b>${bn((x / Math.min(a, b) * 100).toFixed(1))}%</b>${rm ? ' (পানি ক্রমাগত অপসারিত — সাম্য প্রায় সম্পূর্ণ ডানে)' : ''}।</div>${TXB('\\ce{CH3CO-OH + H-^{18}OC2H5 <=>[\\text{গাঢ় H}_2\\text{SO}_4] CH3CO-^{18}OC2H5 + H2O}')}<div class="small">¹⁸O চিহ্নিত ইথানল ব্যবহার করলে ¹⁸O এস্টারে পাওয়া যায়, পানিতে নয় — প্রমাণ করে এসিড থেকে –OH ও অ্যালকোহল থেকে –H বের হয় (অ্যাসাইল–অক্সিজেন বন্ধন ভাঙে)। গাঢ় H₂SO₄ প্রভাবক (কার্বনিল O কে প্রোটনযুক্ত করে) ও জলশোষক। ক্ষারীয় আর্দ্রবিশ্লেষণ (সাবানীকরণ) একমুখী: CH₃COOC₂H₅ + NaOH → CH₃COONa + C₂H₅OH।</div>`; };
    q('[data-a]').oninput = e => { a = +e.target.value; info(); draw(); }; q('[data-b]').oninput = e => { b = +e.target.value; info(); draw(); }; q('[data-w]').oninput = e => { w = +e.target.value; info(); draw(); }; q('[data-rm]').onchange = e => { rm = e.target.checked; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};
/* ======================= ২.১১.১–২.১১.২ অসম্পৃক্ততা ও প্রান্তীয় অ্যালকাইন শনাক্তকরণ ======================= */
const HCS = [['ethane', 'ইথেন CH₃–CH₃', 0], ['ethene', 'ইথিন CH₂=CH₂', 1], ['ethyne', 'ইথাইন HC≡CH', 2], ['propyne', 'প্রোপাইন CH₃C≡CH', 2], ['but2yne', 'বিউট-২-আইন CH₃C≡CCH₃', 3]];
const HCT = {
  br: ['Br₂ দ্রবণ (CCl₄ বা পানিতে)', [0, 1, 1, 1, 1], [200, 90, 20], 'লাল-বাদামি বর্ণ বিলুপ্ত — C=C বা C≡C উপস্থিত (সংযোজন)', ['CH2=CH2 + Br2 -> BrCH2-CH2Br', 'HC#CH + 2Br2 -> Br2CH-CHBr2']],
  ba: ['বেয়ার বিকারক (শীতল লঘু ক্ষারীয় KMnO₄)', [0, 1, 1, 1, 1], [130, 30, 150], 'বেগুনি বর্ণ বিলুপ্ত, বাদামি MnO₂ অধঃক্ষেপ — অসম্পৃক্ততা', ['3CH2=CH2 + 2KMnO4 + 4H2O -> 3HOCH2-CH2OH + 2MnO2 v + 2KOH', '']],
  ag: ['অ্যামোনিয়াযুক্ত AgNO₃ (টলেন্স)', [0, 0, 1, 1, 0], [235, 235, 240], 'সাদা অধঃক্ষেপ (সিলভার অ্যাসিটাইলাইড) — কেবল প্রান্তীয় ≡C–H', ['HC#CH + 2[Ag(NH3)2]+ -> AgC#CAg v + 2NH4+ + 2NH3', 'CH3C#CH + [Ag(NH3)2]+ -> CH3C#CAg v + NH4+ + NH3']],
  cu: ['অ্যামোনিয়াযুক্ত Cu₂Cl₂', [0, 0, 1, 1, 0], [120, 170, 230], 'লাল-বাদামি অধঃক্ষেপ (কিউপ্রাস অ্যাসিটাইলাইড) — কেবল প্রান্তীয় ≡C–H', ['HC#CH + Cu2Cl2 + 2NH3 -> CuC#CCu v + 2NH4Cl', '']]
};
V.p2c2_hcTests = {
  t: 'হাইড্রোকার্বন শনাক্তকরণ: Br₂ দ্রবণ ও বেয়ার পরীক্ষায় অসম্পৃক্ততা, অ্যামোনিয়াযুক্ত AgNO₃ ও Cu₂Cl₂ দিয়ে প্রান্তীয় অ্যালকাইন — গ্যাস চালনার অ্যানিমেশন ও sp কার্বনের অম্লত্ব', k: ['anim', 'int', '2d'],
  cap: 'একটি হাইড্রোকার্বন ও একটি বিকারক বেছে "গ্যাস চালনা" চাপো — নির্গম নল দিয়ে গ্যাস বুদবুদ আকারে বিকারকের মধ্যে যায়। Br₂ এর লাল-বাদামি ও KMnO₄ এর বেগুনি বর্ণ কেবল অসম্পৃক্ত যৌগে (অ্যালকিন, অ্যালকাইন) বিলুপ্ত হয়; অ্যালকেন কোনো পরিবর্তন দেখায় না। অ্যালকিন ও অ্যালকাইন আলাদা করতে অ্যামোনিয়াযুক্ত AgNO₃ বা Cu₂Cl₂ — কেবল প্রান্তীয় অ্যালকাইন (≡C–H আছে) অধঃক্ষেপ দেয়; বিউট-২-আইন (অভ্যন্তরীণ) দেয় না। ডানের দণ্ডলেখ s-বৈশিষ্ট্য বনাম pKa: sp কার্বনে ৫০% s চরিত্র — ইলেকট্রন নিউক্লিয়াসের কাছে থাকে, তাই ≡C–H দুর্বল এসিড (pKa ২৫)।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('hc', HCS.map(h => [h[0], h[1].split(' ')[0]]), 'ethyne')}</div><div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('rg', Object.entries(HCT).map(([k, v]) => [k, v[0].split(' (')[0]]), 'br')}<button class="btn sm primary" data-go>▶ গ্যাস চালনা</button></div>${X.cv('হাইড্রোকার্বন পরীক্ষা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 500;
    let L = X.fit(c, hf), hc = 'ethyne', rg = 'br', p = 0, run = false, t = 0;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), d = HCT[rg], hi = HCS.findIndex(h => h[0] === hc), pos = d[1][hi], k = Math.min(1, p);
      const fx = wd ? 70 : 60, fy = 190, tx = wd ? W * 0.3 : W * 0.62, ty = 70, TL = 160;
      // generator flask
      g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.arc(fx, fy, 34, -Math.PI / 2 + 0.27, 1.5 * Math.PI - 0.27, false); g.stroke(); g.beginPath(); g.moveTo(fx - 9, fy - 33); g.lineTo(fx - 9, fy - 70); g.moveTo(fx + 9, fy - 33); g.lineTo(fx + 9, fy - 70); g.stroke(); g.fillStyle = 'rgba(180,200,230,.35)'; g.beginPath(); g.arc(fx, fy, 32, 0.15 * Math.PI, 0.85 * Math.PI); g.fill(); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(hc === 'ethyne' ? 'CaC₂ + H₂O' : hc === 'ethene' ? 'C₂H₅OH + গাঢ় H₂SO₄' : 'গ্যাস উৎস', fx, fy + 48);
      // delivery tube
      g.strokeStyle = col.fg; g.lineWidth = 3; g.beginPath(); g.moveTo(fx, fy - 70); g.lineTo(fx, fy - 100); g.lineTo(tx, fy - 100 - 0); g.lineTo(tx, ty + TL - 20); g.stroke(); g.strokeStyle = col.sf; g.lineWidth = 1.2; g.stroke();
      if (run) for (let i = 0; i < 8; i++) { const u = (t * 0.9 + i / 8) % 1; g.fillStyle = 'rgba(200,210,230,.9)'; g.strokeStyle = col.mu; g.lineWidth = 0.6; g.beginPath(); g.arc(tx + Math.sin(i * 2 + t * 3) * 4, ty + TL - 22 - u * TL * 0.45, 2.6, 0, 7); g.fill(); g.stroke(); }
      const c0 = d[2], f = pos ? k : 0; let fill; if (rg === 'br' || rg === 'ba') fill = `rgba(${c0.join(',')},${0.8 * (1 - f) + 0.08})`; else fill = `rgba(${c0.join(',')},0.35)`;
      M3.tube(g, tx, ty, TL, 40, 0, fill, 0.6, col);
      if (pos && k > 0.25) { const ff = (k - 0.25) / 0.75, cc = rg === 'ba' ? '#6d4c41' : rg === 'ag' ? '#f5f5f5' : rg === 'cu' ? '#a93226' : null; if (cc) for (let i = 0; i < 70 * ff; i++) { g.fillStyle = cc; g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 0.4; g.beginPath(); g.arc(tx - 16 + (i * 29 % 32), ty + TL - 12 - (i % 6) * 2.6 - Math.floor(i / 24) * 3, 2.2, 0, 7); g.fill(); g.stroke(); } }
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(d[0].split(' (')[0], tx, ty - 8); g.fillStyle = k > 0.85 ? (pos ? '#2f9e44' : '#c0392b') : col.mu; g.fillText(k > 0.85 ? (pos ? 'ধনাত্মক ✓' : 'কোনো পরিবর্তন নেই ✗') : run ? 'গ্যাস চালনা চলছে…' : '', tx, ty + TL + 18);
      // s-character vs pKa
      const px = wd ? W * 0.5 : 30, py = wd ? 30 : 290, pw = wd ? W * 0.46 : W - 50, ph = wd ? H - 70 : H - py - 40; const rows = [['C₂H₆ (sp³)', 25, 50, '#7f8c8d'], ['C₂H₄ (sp²)', 33, 44, '#2d6fd6'], ['C₂H₂ (sp)', 50, 25, '#8e44ad']];
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('C–H এর অম্লত্ব: s-বৈশিষ্ট্য বাড়লে pKa কমে', px, py);
      rows.forEach((r, i) => { const y = py + 20 + i * (ph - 20) / 3, bw = pw - 110, bh = (ph - 20) / 3 - 14; g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText(r[0], px, y + 12); g.fillStyle = r[3]; g.globalAlpha = 0.85; g.fillRect(px + 90, y, bw * r[1] / 50, bh * 0.42); g.globalAlpha = 0.4; g.fillRect(px + 90, y + bh * 0.5, bw * (60 - r[2]) / 60, bh * 0.42); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText(`s = ${bn(r[1])}%`, px + 94 + bw * r[1] / 50, y + bh * 0.36); g.fillText(`pKa ≈ ${bn(r[2])}`, px + 94 + bw * (60 - r[2]) / 60, y + bh * 0.86); });
    };
    const info = () => { const d = HCT[rg]; out.innerHTML = `<div><b>${d[0]}:</b> ${d[3]}।</div>${TXB(`\\ce{${d[4][0]}}`)}${d[4][1] ? TXB(`\\ce{${d[4][1]}}`) : ''}<div class="small">${rg === 'ag' || rg === 'cu' ? 'শুষ্ক সিলভার/কপার অ্যাসিটাইলাইড আঘাতে বিস্ফোরক — পরীক্ষার পর লঘু HNO₃ দিয়ে নষ্ট করতে হয়। লঘু HCl/HNO₃ দিলে আবার অ্যালকাইন মুক্ত হয় — প্রান্তীয় অ্যালকাইন পৃথকীকরণে ব্যবহৃত।' : 'অ্যালকেন এসব বিকারকে নিষ্ক্রিয় (সম্পৃক্ত, কেবল σ বন্ধন); তাই এই পরীক্ষায় সম্পৃক্ত ও অসম্পৃক্ত হাইড্রোকার্বন পৃথক হয়।'}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.3); if (p >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'hc', v => { hc = v; p = 0; run = false; }); X.onSeg(el, 'rg', v => { rg = v; p = 0; run = false; info(); });
    q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১১.৩ অ্যালকাইল বনাম অ্যারাইল হ্যালাইড: AgNO₃ পরীক্ষা ======================= */
const HAL = [
  ['etcl', 'ইথাইল ক্লোরাইড C₂H₅Cl', 'Cl', 240, '১°: উত্তপ্ত করলে ধীরে সাদা AgCl'],
  ['etbr', 'ইথাইল ব্রোমাইড C₂H₅Br', 'Br', 90, '১°: হালকা হলুদ AgBr (Cl এর চেয়ে দ্রুত — C–Br দুর্বল)'],
  ['eti', 'ইথাইল আয়োডাইড C₂H₅I', 'I', 30, '১°: হলুদ AgI, দ্রুততম (C–I দুর্বলতম)'],
  ['tbu', 'টারশিয়ারি বিউটাইল ক্লোরাইড (CH₃)₃CCl', 'Cl', 3, '৩°: তাৎক্ষণিক সাদা AgCl (স্থিতিশীল ৩° কার্বোক্যাটায়ন, SN1)'],
  ['bzl', 'বেনজাইল ক্লোরাইড C₆H₅CH₂Cl', 'Cl', 5, 'বেনজাইল: প্রায় তাৎক্ষণিক (বেনজাইল কার্বোক্যাটায়ন রেজোন্যান্সে স্থিতিশীল)'],
  ['phcl', 'ক্লোরোবেনজিন C₆H₅Cl', 'Cl', 0, 'অ্যারাইল: কোনো অধঃক্ষেপ নেই — C–Cl বন্ধন আংশিক দ্বিবন্ধন'],
  ['vin', 'ভিনাইল ক্লোরাইড CH₂=CHCl', 'Cl', 0, 'ভিনাইল: কোনো অধঃক্ষেপ নেই (একই কারণে)']
];
const PPT = { Cl: ['#f8f9f9', 'সাদা AgCl'], Br: ['#f7f1b5', 'হালকা হলুদ AgBr'], I: ['#f4d03f', 'হলুদ AgI'] };
V.p2c2_halideAg = {
  t: 'অ্যালকাইল হ্যালাইড বনাম অ্যারাইল হ্যালাইড: অ্যালকোহলীয় AgNO₃ পরীক্ষায় অধঃক্ষেপের বর্ণ ও সময় — এবং ক্লোরোবেনজিনে C–Cl বন্ধনের আংশিক দ্বিবন্ধন চরিত্র (রেজোন্যান্স ও বন্ধন দৈর্ঘ্য)', k: ['anim', 'int', '2d'],
  cap: 'সাতটি হ্যালাইড একসাথে অ্যালকোহলীয় AgNO₃ এ রেখে "শুরু" চাপো; ঘড়ি এগোয়, প্রতিটি নলে অধঃক্ষেপ পড়ার সময় আলাদা। হ্যালাইড আয়ন বের হলেই Ag⁺ এর সাথে অধঃক্ষেপ: AgCl সাদা, AgBr হালকা হলুদ, AgI হলুদ। দ্রুততা নির্ভর করে C–X বন্ধন ভাঙার সহজতা ও কার্বোক্যাটায়নের স্থিতিশীলতার উপর: ৩° ও বেনজাইল তাৎক্ষণিক, ১° উত্তাপে ধীরে, আর অ্যারাইল ও ভিনাইল হ্যালাইড কোনো অধঃক্ষেপ দেয় না। কারণ নিচে: Cl এর নিঃসঙ্গ জোড় বেনজিন বলয়ের π ব্যবস্থার সাথে রেজোন্যান্সে অংশ নেয় — C–Cl বন্ধন ছোট (১৬৯ pm বনাম ১৭৭ pm) ও শক্তিশালী, আর কার্বন sp²।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><button class="btn sm primary" data-go>▶ শুরু</button><label class="small" style="flex:1">সময়<input type="range" min="0" max="300" step="1" value="0" data-t></label></div>${X.cv('AgNO₃ পরীক্ষা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 400 : 470;
    let L = X.fit(c, hf), T = 0, run = false, sel = 5, boxes = [];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), n = HAL.length, cw = (W - 20) / n, ty = 34, TL = wd ? 150 : 130, tw = Math.min(30, cw * 0.55); boxes = [];
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`সময়: ${bn(Math.floor(T / 60))} মি ${bn(Math.round(T % 60))} সে`, 10, 16);
      HAL.forEach((h, i) => { const x = 10 + cw * (i + 0.5), tm = h[3], f = tm === 0 ? 0 : Math.max(0, Math.min(1, (T - tm) / Math.max(8, tm * 0.3))); M3.tube(g, x, ty, TL, tw, 0, `rgba(235,240,250,${0.25 + 0.5 * f})`, 0.6, col); if (f > 0) { const pc = PPT[h[2]][0]; for (let j = 0; j < 30 * f; j++) { g.fillStyle = pc; g.strokeStyle = 'rgba(0,0,0,.3)'; g.lineWidth = 0.4; g.beginPath(); g.arc(x - tw / 2 + 4 + (j * 17 % (tw - 8)), ty + TL - 9 - (j % 4) * 2.4 - Math.floor(j / 12) * 3, 1.9, 0, 7); g.fill(); g.stroke(); } }
        if (i === sel) { g.strokeStyle = col.acc; g.lineWidth = 2; rr(g, x - cw / 2 + 2, ty - 6, cw - 4, TL + 46, 8); g.stroke(); }
        g.fillStyle = col.fg; g.font = `bold ${wd ? 9.5 : 8}px ${col.font}`; g.textAlign = 'center'; const nm = h[1].split(' ').slice(-1)[0], dy = !wd && i % 2 ? 11 : 0; g.fillText(nm, x, ty + TL + 12 + dy); g.font = `${wd ? 9 : 7.5}px ${col.font}`; g.fillStyle = f > 0.5 ? '#2f9e44' : col.mu; g.fillText(f > 0.5 ? PPT[h[2]][1].split(' ').slice(-1)[0] + ' ✓' : tm === 0 ? '—' : '', x, ty + TL + (wd ? 28 : 36)); boxes.push([x - cw / 2, ty, cw, TL + 40, i]); });
      // resonance + bond lengths
      const ry = ty + TL + (wd ? 50 : 58), rh = H - ry - 6; const bx = wd ? 20 : 10, bw = wd ? W * 0.55 : W - 20;
      const hexA = (cx, cy, r, k) => { const P2 = [0, 1, 2, 3, 4, 5].map(j => [cx + r * Math.cos(Math.PI / 6 + j * Math.PI / 3 - Math.PI / 2 - Math.PI / 6), cy + r * Math.sin(Math.PI / 6 + j * Math.PI / 3 - Math.PI / 2 - Math.PI / 6)]); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); P2.forEach((pt, j) => j ? g.lineTo(pt[0], pt[1]) : g.moveTo(pt[0], pt[1])); g.closePath(); g.stroke(); const dbl = k === 0 ? [[1, 2], [3, 4], [5, 0]] : k === 1 ? [[2, 3], [4, 5]] : k === 3 ? [[1, 2], [3, 4]] : [[1, 2], [4, 5]]; dbl.forEach(([a2, b2]) => { const m2 = [(P2[a2][0] + P2[b2][0]) / 2, (P2[a2][1] + P2[b2][1]) / 2], s2 = 0.75; const A2 = [cx + (P2[a2][0] - cx) * s2 + (P2[a2][0] - m2[0]) * 0, cy + (P2[a2][1] - cy) * s2], B2 = [cx + (P2[b2][0] - cx) * s2, cy + (P2[b2][1] - cy) * s2]; g.beginPath(); g.moveTo(A2[0], A2[1]); g.lineTo(B2[0], B2[1]); g.stroke(); }); return P2; };
      const rs = Math.min(bw / 4 / 2.6, rh / 3.4, 26), cyR = ry + rh * 0.58; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('ক্লোরোবেনজিনের রেজোন্যান্স: Cl এর নিঃসঙ্গ জোড় বলয়ে বিস্থানীকৃত', bx, ry + 6);
      [0, 1, 2, 3].forEach(k2 => { const cx = bx + bw * (k2 + 0.5) / 4, P2 = hexA(cx, cyR, rs, k2); const top = P2[0]; g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(top[0], top[1]); g.lineTo(top[0], top[1] - rs * 0.7); g.stroke(); if (k2 > 0) { g.beginPath(); g.moveTo(top[0] + 3, top[1]); g.lineTo(top[0] + 3, top[1] - rs * 0.7); g.stroke(); } g.fillStyle = '#16a085'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(k2 ? 'Cl⁺' : 'Cl', top[0], top[1] - rs * 0.7 - 4); if (k2) { const mi = k2 === 1 ? 1 : k2 === 2 ? 3 : 5, pm = P2[mi]; g.fillStyle = '#c0392b'; g.fillText('⊖', pm[0] + (pm[0] - cx) * 0.35, pm[1] + (pm[1] - cyR) * 0.35 + 4); } if (k2 < 3) { g.fillStyle = col.acc; g.font = `bold 13px ${col.font}`; g.fillText('↔', bx + bw * (k2 + 1) / 4, cyR + 4); } });
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('ঋণাত্মক চার্জ অর্থো ও প্যারা অবস্থানে → C–Cl এ আংশিক দ্বিবন্ধন চরিত্র', bx + bw / 2, cyR + rs + 18);
      if (wd) { const px = W * 0.62, pw = W * 0.35, rows = [['CH₃CH₂–Cl (sp³)', 177, 338], ['CH₂=CH–Cl (sp²)', 172, 368], ['C₆H₅–Cl (sp²)', 169, 400]]; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('C–Cl বন্ধন দৈর্ঘ্য ও বিয়োজন শক্তি', px, ry + 6); rows.forEach((r, i) => { const y = ry + 22 + i * (rh - 24) / 3; g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.fillText(r[0], px, y + 9); g.fillStyle = '#16a085'; g.fillRect(px, y + 14, pw * (r[1] - 150) / 35, 7); g.fillStyle = '#e67e22'; g.fillRect(px, y + 24, pw * (r[2] - 300) / 150, 7); g.fillStyle = col.fg; g.font = `8.5px ${col.font}`; g.fillText(`${bn(r[1])} pm`, px + pw * (r[1] - 150) / 35 + 4, y + 21); g.fillText(`≈${bn(r[2])} kJ/mol`, px + pw * (r[2] - 300) / 150 + 4, y + 31); }); }
    };
    const info = () => { const h = HAL[sel]; out.innerHTML = `<div><b>${h[1]}:</b> ${h[4]}।</div>${TXB(h[3] ? `\\ce{R-${h[2]} + AgNO3 ->[\\text{C}_2\\text{H}_5\\text{OH}] Ag${h[2]} v + RONO2}` : `\\ce{C6H5-Cl + AgNO3 -> \\text{বিক্রিয়া নেই}}`)}<div class="small">অ্যারাইল হ্যালাইড নিউক্লিওফিলিক প্রতিস্থাপনে অত্যন্ত নিষ্ক্রিয়: (১) C–Cl এ আংশিক দ্বিবন্ধন, (২) sp² কার্বন বেশি তড়িৎঋণাত্মক — বন্ধন ছোট ও শক্ত, (৩) ফিনাইল ক্যাটায়ন অস্থিতিশীল (SN1 অসম্ভব), (৪) বলয়ের π মেঘ পেছন থেকে আক্রমণে বাধা দেয় (SN2 অসম্ভব)। কঠোর শর্তে (NaOH, ৩৫০ °C, ২০০ atm — ডাও প্রক্রিয়া) ফেনল হয়; o/p-তে –NO₂ থাকলে সহজ হয়।</div>`; };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, b = boxes.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (b) { sel = b[4]; info(); A.draw(); } });
    const A = X.anim(el, dt => { if (dt && run) { T = Math.min(300, T + dt * 40); q('[data-t]').value = T; if (T >= 300) run = false; } draw(); }, { paused: false });
    q('[data-go]').onclick = () => { T = 0; run = true; }; q('[data-t]').oninput = e => { T = +e.target.value; run = false; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
