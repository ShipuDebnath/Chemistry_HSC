/* ২য় পত্র অধ্যায় ২ visuals part a (10) — 2.14 glycerol (saponification & micelle animation, 3D H-bond network), phenol (acidity & resonance, reactions with 3D products), 2.15 nitroglycerin, TNT, dettol, paracetamol, aspirin (3D + synthesis stepper) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const { add, mul } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = M3.ease;

/* extended arene builder: adds NHCOCH3 (acetamido) and OCOCH3 (acetoxy) to the M3.arene group set */
const areneX = (subs = {}, name = '') => {
  const a = [], b = [];
  for (let k = 0; k < 6; k++) { const t = Math.PI / 2 + k * Math.PI / 3; a.push(['C', 1.39 * Math.cos(t), 1.39 * Math.sin(t), 0, { pn: [0, 0, 1] }]); b.push([k, (k + 1) % 6, 1.5]); }
  const at = (el, pos, opt) => { a.push([el, ...pos, opt || {}]); return a.length - 1; };
  Object.entries(subs).forEach(([ks, gk]) => {
    const k = +ks, t = Math.PI / 2 + k * Math.PI / 3, u = [Math.cos(t), Math.sin(t), 0], p = [-u[1], u[0], 0], base = a[k].slice(1, 4);
    const dir = ang => add(mul(u, Math.cos(ang)), mul(p, Math.sin(ang))), P = i => a[i].slice(1, 4), tri = { geo: 'tri', pn: [0, 0, 1] };
    if (gk === 'NHCOCH3' || gk === 'OCOCH3') { const x = at(gk[0], add(base, mul(u, gk[0] === 'N' ? 1.41 : 1.39)), tri); b.push([k, x]); const c = at('C', add(P(x), mul(dir(-Math.PI / 3), gk[0] === 'N' ? 1.36 : 1.36)), tri); b.push([x, c]); b.push([c, at('O', add(P(c), mul(dir(-2 * Math.PI / 3), 1.22))), 2]); b.push([c, at('C', add(P(c), mul(dir(0), 1.50)))]); return; }
    if (gk === 'CH3') { b.push([k, at('C', add(base, mul(u, 1.51)))]); return; }
    if (gk === 'OH') { b.push([k, at('O', add(base, mul(u, 1.36)), tri)]); return; }
    if (gk === 'O-') { b.push([k, at('O', add(base, mul(u, 1.30)), { q: -1, noH: true })]); return; }
    if (gk === 'NH2') { b.push([k, at('N', add(base, mul(u, 1.40)), tri)]); return; }
    if (gk === 'Cl' || gk === 'Br') { b.push([k, at(gk, add(base, mul(u, gk === 'Cl' ? 1.74 : 1.89)))]); return; }
    if (gk === 'NO2') { const n = at('N', add(base, mul(u, 1.47)), { q: 1 }); b.push([k, n]); b.push([n, at('O', add(P(n), mul(dir(Math.PI / 3), 1.22))), 2]); b.push([n, at('O', add(P(n), mul(dir(-Math.PI / 3), 1.22)), { q: -1 })]); return; }
    if (gk === 'COOH') { const c = at('C', add(base, mul(u, 1.48)), tri); b.push([k, c]); b.push([c, at('O', add(P(c), mul(dir(Math.PI / 3), 1.22))), 2]); b.push([c, at('O', add(P(c), mul(dir(-Math.PI / 3), 1.34)), tri)]); return; }
  });
  const m = M3.mol({ name, a, b }); M3.offsets(m); return m;
};
M3.areneX = areneX;
const glycerol = () => M3.relax(M3.tree([['C', -1], ['C', 0], ['C', 1], ['O', 0], ['O', 1], ['O', 2]], { name: 'গ্লিসারল' }));
const ngly = () => { const tri = { geo: 'tri' }; const m = M3.tree([['C', -1], ['C', 0], ['C', 1], ['O', 0], ['O', 1], ['O', 2], ['N', 3, 1, 0, { q: 1, geo: 'tri' }], ['N', 4, 1, 0, { q: 1, geo: 'tri' }], ['N', 5, 1, 0, { q: 1, geo: 'tri' }], ['O', 6, 2], ['O', 6, 1, 1, { q: -1 }], ['O', 7, 2], ['O', 7, 1, 1, { q: -1 }], ['O', 8, 2], ['O', 8, 1, 1, { q: -1 }]], { name: 'নাইট্রোগ্লিসারিন' }); void tri; return M3.relax(m, 400); };

/* ======================= ২.১৪.১ গ্লিসারিন: সাবানীকরণ ও মিসেল ======================= */
V.p2c2_glycerol = {
  t: 'গ্লিসারিন: চর্বির (ট্রাইগ্লিসারাইড) সাবানীকরণে গ্লিসারল ও সাবান — ধাপে ধাপে অ্যানিমেশন, সাবানের মিসেলে তেল আটকে পরিষ্কারের কৌশল, এবং গ্লিসারল অণুর ত্রিমাত্রিক হাইড্রোজেন বন্ধন জাল (উচ্চ স্ফুটনাঙ্ক ও সান্দ্রতা)', k: ['anim', 'int', '3d'],
  cap: '"সাবানীকরণ" ধাপে একটি ট্রাইগ্লিসারাইড (গ্লিসারলের তিনটি –OH তিনটি দীর্ঘ শিকল ফ্যাটি এসিডের সাথে এস্টার বন্ধনে যুক্ত) তিনটি OH⁻ এর আক্রমণে ভেঙে যায় — তিনটি সোডিয়াম স্টিয়ারেট (সাবান) ও একটি গ্লিসারল তৈরি হয়। "মিসেল" ধাপে সাবান আয়নের লম্বা অপোলার লেজ তেলের ফোঁটায় ঢুকে যায় আর ঋণাত্মক মাথা পানির দিকে থাকে — তেল ঘিরে গোলাকার মিসেল তৈরি হয়, যা পানিতে ধুয়ে যায়। "গ্লিসারল" ধাপে ত্রিমাত্রিক অণু ও পাশের অণুর সাথে হাইড্রোজেন বন্ধন (ড্যাশ রেখা): প্রতি অণুতে তিনটি –OH থাকায় বিস্তৃত H বন্ধন জাল — স্ফুটনাঙ্ক ২৯০ °C, ঘন সিরাপের মতো সান্দ্র, পানিতে সব অনুপাতে মিশ্রণীয়, আর্দ্রতাগ্রাহী।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('st', [['sap', 'সাবানীকরণ'], ['mic', 'মিসেল'], ['gly', 'গ্লিসারল (৩D)']], 'sap')}<button class="btn sm primary" data-play>▶ চালাও</button></div>${X.cv('গ্লিসারিন')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 440;
    let L = X.fit(c, hf), st = 'sap', p = 0, play = true, t = 0, gm = glycerol(); const cam = M3.cam({ yaw: 0.5, pitch: 0.35 });
    C4.drag3d(c, cam, () => A.draw());
    const chain = (g, x, y, n, dx, col, amp = 5) => { g.strokeStyle = col; g.lineWidth = 2; g.beginPath(); for (let i = 0; i <= n; i++) { const xx = x + i * dx, yy = y + (i % 2 ? -amp : amp); i ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.stroke(); return [x + n * dx, y]; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (st === 'sap') {
        const k = ease(Math.min(1, p)), gx = wd ? W * 0.16 : W * 0.14, gy = H * 0.5, sp = wd ? 70 : 62, dx = wd ? 16 : 11, n = wd ? 17 : 15;
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(k < 0.05 ? 'ট্রাইগ্লিসারাইড (গ্লিসারিল ট্রাইস্টিয়ারেট) + 3NaOH' : k < 0.95 ? 'OH⁻ এস্টার বন্ধনের কার্বনিল কার্বনে আক্রমণ করছে…' : 'গ্লিসারল + ৩টি সোডিয়াম স্টিয়ারেট (সাবান)', W / 2, 16);
        [-1, 0, 1].forEach((j, i) => { const y = gy + j * sp; // glycerol carbon
          g.fillStyle = '#c0392b'; g.strokeStyle = col.fg; g.lineWidth = 2; const cX = gx, oX = gx + 26, coX = gx + 52 + k * (wd ? 70 : 44);
          // backbone
          if (i < 2) { g.beginPath(); g.moveTo(cX, y); g.lineTo(cX, y + sp); g.stroke(); }
          g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.fillText(i === 1 ? 'CH' : 'CH₂', cX - 18, y + 4);
          g.beginPath(); g.moveTo(cX, y); g.lineTo(oX, y); g.stroke(); g.fillStyle = '#cc2418'; g.fillText('O', oX + 5, y + 4);
          if (k > 0.5) { g.fillStyle = '#cc2418'; g.fillText('H', oX + 18, y + 4); }
          if (k < 0.5) { g.strokeStyle = col.fg; g.beginPath(); g.moveTo(oX + 12, y); g.lineTo(coX, y); g.stroke(); }
          // carbonyl + chain
          g.fillStyle = col.fg; g.fillText('C', coX + 5, y + 4); g.strokeStyle = '#cc2418'; g.beginPath(); g.moveTo(coX + 5, y - 6); g.lineTo(coX + 5, y - 18); g.moveTo(coX + 9, y - 6); g.lineTo(coX + 9, y - 18); g.stroke(); g.fillStyle = '#cc2418'; g.fillText('O', coX + 7, y - 21);
          if (k > 0.5) { g.fillStyle = '#cc2418'; g.fillText('O⁻', coX - 9, y + 4); g.fillStyle = '#8e44ad'; g.fillText('Na⁺', coX - 9, y + 20); }
          chain(g, coX + 14, y, n, dx, col.mu); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('C₁₇H₃₅', coX + 14 + n * dx + 4, y + 3); g.textAlign = 'center';
          // incoming OH-
          if (k < 0.5) { const f = k / 0.5, hx = coX + 5 + (1 - f) * 40, hy = y + 26 - f * 18; g.fillStyle = '#2980b9'; g.font = `bold 11px ${col.font}`; g.fillText('OH⁻', hx, hy); if (f > 0.2) { M3.curly(g, [hx - 8, hy - 6], [coX + 4, y + 6], 12, '#2980b9', 1.4); } }
        });
        if (k > 0.95) { g.fillStyle = '#2f9e44'; g.font = `bold 10px ${col.font}`; g.fillText('গ্লিসারল', gx - 4, gy + sp + 26); g.fillText('সাবান (RCOO⁻Na⁺)', gx + (wd ? 200 : 140), gy + sp + 26); }
      } else if (st === 'mic') {
        const k = ease(Math.min(1, p)), cx = W / 2, cy = H / 2 + 6, R = Math.min(W, H) * 0.22, N = 22;
        g.fillStyle = 'rgba(60,130,220,.10)'; g.fillRect(0, 24, W, H - 24); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(k < 0.95 ? 'সাবান আয়ন তেলের ফোঁটা ঘিরে ধরছে…' : 'মিসেল: অপোলার লেজ ভেতরে (তেলে), ঋণাত্মক মাথা বাইরে (পানিতে)', W / 2, 16);
        const rOil = R * (0.75 - 0.08 * k); g.fillStyle = 'rgba(230,170,40,.75)'; g.beginPath(); for (let i = 0; i <= 40; i++) { const a = i / 40 * Math.PI * 2, rr2 = rOil * (1 + 0.06 * Math.sin(a * 5 + t)); i ? g.lineTo(cx + rr2 * Math.cos(a), cy + rr2 * Math.sin(a)) : g.moveTo(cx + rr2 * Math.cos(a), cy + rr2 * Math.sin(a)); } g.fill(); g.fillStyle = '#7d5a00'; g.font = `bold 10px ${col.font}`; g.fillText('তেল/ময়লা', cx, cy + 4);
        for (let i = 0; i < N; i++) { const a = i / N * Math.PI * 2 + 0.1, far = R * 2.2 + (i % 3) * 18, rHead = R * (1 + 0.02 * Math.sin(t * 2 + i)) * k + far * (1 - k), hx = cx + rHead * Math.cos(a + (1 - k) * 0.6), hy = cy + rHead * Math.sin(a + (1 - k) * 0.6), ta = a + (1 - k) * (1.3 + i); const tl = R * 0.62; g.strokeStyle = col.mu; g.lineWidth = 1.6; g.beginPath(); for (let j = 0; j <= 8; j++) { const f = j / 8, xx = hx - Math.cos(ta) * tl * f + Math.sin(ta) * (j % 2 ? 2.5 : -2.5), yy = hy - Math.sin(ta) * tl * f - Math.cos(ta) * (j % 2 ? 2.5 : -2.5); j ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.stroke(); M3.sphere(g, hx, hy, 5, '#c0392b', '#ff9a8a'); g.fillStyle = '#fff'; g.font = `bold 7px ${col.font}`; g.fillText('−', hx, hy + 2.5); if (k > 0.9 && i % 2 === 0) { g.fillStyle = '#8e44ad'; g.font = `bold 8px ${col.font}`; g.fillText('Na⁺', cx + (rHead + 16) * Math.cos(a + 0.12), cy + (rHead + 16) * Math.sin(a + 0.12)); } }
        g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('পানি', 8, H - 8);
      } else {
        cam.cx = W / 2; cam.cy = H / 2 + 6; M3.fit(gm, cam, W * 0.6, H - 40, 0.75); if (!cam.user) cam.yaw += 0.005;
        const R = M3.render(g, gm, cam, { mode: 'bs', col, labels: 'hetero' });
        // neighbour waters / glycerol O—H···O hints
        const Os = gm.a.map((a, i) => [a, i]).filter(([a]) => a.el === 'O');
        Os.forEach(([a, ii], j) => { const p0 = R.S[ii], d = [Math.cos(j * 2.1 + 0.4), Math.sin(j * 2.1 + 0.4)], L2 = 46; const q2 = [p0[0] + d[0] * L2, p0[1] + d[1] * L2]; g.setLineDash([3, 3]); g.strokeStyle = '#2980b9'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(p0[0] + d[0] * 10, p0[1] + d[1] * 10); g.lineTo(q2[0], q2[1]); g.stroke(); g.setLineDash([]); M3.sphere(g, q2[0], q2[1], 6, '#cc2418', '#ff9a8a'); g.fillStyle = '#2980b9'; g.font = `8.5px ${col.font}`; g.textAlign = 'center'; g.fillText('H বন্ধন', (p0[0] + q2[0]) / 2 + 12, (p0[1] + q2[1]) / 2 - 3); });
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('গ্লিসারল HOCH₂–CH(OH)–CH₂OH (প্রোপেন-১,২,৩-ট্রাইঅল)', W / 2, 16);
      }
    };
    const info = () => { out.innerHTML = st === 'sap' ? `${TXB('\\ce{(C17H35COO)3C3H5 + 3NaOH ->[\\Delta] C3H5(OH)3 + 3C17H35COONa}')}<div class="small">ক্ষারীয় আর্দ্রবিশ্লেষণ একমুখী — উৎপন্ন কার্বক্সিলেট আয়ন আর অ্যালকোহলের সাথে বিক্রিয়া করে না। সাবান কারখানায় লবণ (NaCl) যোগ করে সাবান আলাদা করা হয় (লবণ ঘনীভবন); অবশিষ্ট দ্রবণ থেকে পাতনে গ্লিসারিন পুনরুদ্ধার। KOH দিলে নরম (তরল) সাবান।</div>` : st === 'mic' ? `<div>সাবান আয়ন উভপ্রিয় (amphiphilic): –COO⁻ মাথা জলপ্রিয়, C₁₇H₃₅ লেজ জলভীরু/তেলপ্রিয়। পানিতে নির্দিষ্ট ঘনমাত্রার (CMC) উপরে আয়নগুলো মিসেল গঠন করে। ঋণাত্মক পৃষ্ঠের মিসেলগুলো পরস্পরকে বিকর্ষণ করে — তেল আবার জমাট বাঁধে না, পানির সাথে ধুয়ে যায়। খর পানিতে Ca²⁺/Mg²⁺ সাবানের সাথে অদ্রবণীয় ময়লা (স্কাম) তৈরি করে: {2C₁₇H₃₅COO⁻ + Ca²⁺ → (C₁₇H₃₅COO)₂Ca↓}।</div>` : `<div>গ্লিসারল: বর্ণহীন, গন্ধহীন, মিষ্টি স্বাদের সান্দ্র তরল; স্ফুটনাঙ্ক ২৯০ °C (বিয়োজনসহ), ঘনত্ব ১.২৬ g/cm³। তিনটি –OH দিয়ে প্রতিটি অণু একাধিক প্রতিবেশীর সাথে H বন্ধন গঠন করে। ব্যবহার: প্রসাধনী ও লোশনে আর্দ্রতা রক্ষাকারী, ওষুধ ও কফ সিরাপে, খাদ্যে মিষ্টিকারক (E422), ছাপার কালি, প্রতিহিমায়ক এবং নাইট্রোগ্লিসারিন উৎপাদনে।</div>`.replace(/\{|\}/g, ''); };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (play && st !== 'gly') { p = Math.min(1, p + dt * 0.22); if (p >= 1) play = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'st', v => { st = v; p = 0; play = true; info(); }); q('[data-play]').onclick = () => { p = 0; play = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১৪.২ ফেনল: অম্লত্ব ও বিক্রিয়া ======================= */
const PKA = [['ইথানল', 16, '#7f8c8d'], ['পানি', 15.7, '#3498db'], ['p-ক্রেসল', 10.26, '#95a5a6'], ['ফেনল', 9.95, '#c0392b'], ['p-ক্লোরোফেনল', 9.38, '#16a085'], ['p-নাইট্রোফেনল', 7.15, '#e67e22'], ['কার্বনিক এসিড', 6.35, '#8e44ad'], ['ইথানয়িক এসিড', 4.76, '#d35400'], ['পিক্রিক এসিড', 0.38, '#f1c40f']];
const PRX = {
  naoh: ['NaOH (জলীয়)', () => areneX({ 0: 'O-' }, 'সোডিয়াম ফিনক্সাইড'), 'C6H5OH + NaOH -> C6H5O^-Na+ + H2O', 'ফেনল অম্লধর্মী — ক্ষারে লবণ তৈরি করে দ্রবীভূত হয় (কিন্তু NaHCO₃ এর সাথে CO₂ দেয় না)।'],
  br2: ['ব্রোমিন পানি', () => areneX({ 0: 'OH', 1: 'Br', 3: 'Br', 5: 'Br' }, '২,৪,৬-ট্রাইব্রোমোফেনল'), 'C6H5OH + 3Br2(aq) -> C6H2Br3OH v + 3HBr', '–OH প্রবল সক্রিয়কারী ও অর্থো-প্যারা নির্দেশক — প্রভাবক ছাড়াই তিনটি অবস্থানে প্রতিস্থাপন, সাদা অধঃক্ষেপ। (CS₂ তে ব্রোমিন দিলে প্রধানত p-ব্রোমোফেনল।)'],
  dno3: ['লঘু HNO₃ (কক্ষ তাপমাত্রা)', () => areneX({ 0: 'OH', 3: 'NO2' }, '৪-নাইট্রোফেনল'), 'C6H5OH + HNO3(dil) -> o-/p-O2NC6H4OH + H2O', 'o- ও p-নাইট্রোফেনলের মিশ্রণ; o-নাইট্রোফেনলে অন্তঃআণবিক H বন্ধন — উদ্বায়ী, বাষ্প পাতনে আলাদা হয়।'],
  cno3: ['গাঢ় HNO₃ + গাঢ় H₂SO₄', () => areneX({ 0: 'OH', 1: 'NO2', 3: 'NO2', 5: 'NO2' }, 'পিক্রিক এসিড'), 'C6H5OH + 3HNO3 ->[\\text{গাঢ় H}_2\\text{SO}_4] C6H2(NO2)3OH + 3H2O', '২,৪,৬-ট্রাইনাইট্রোফেনল (পিক্রিক এসিড) — তিনটি –NO₂ এর −I ও −R প্রভাবে অত্যন্ত শক্তিশালী এসিড (pKa ০.৩৮), হলুদ কেলাস।'],
  kolbe: ['কোলবে-শ্মিট (NaOH; CO₂, চাপ; H⁺)', () => areneX({ 0: 'OH', 1: 'COOH' }, 'স্যালিসাইলিক এসিড'), 'C6H5ONa + CO2 ->[125\\ ^\\circ\\text{C},\\ 5\\ \\text{atm}] o-HOC6H4COONa ->[\\text{H}^+] o-HOC6H4COOH', 'ফিনক্সাইড আয়নের বলয় (অর্থো অবস্থান) দুর্বল ইলেকট্রোফাইল CO₂ কে আক্রমণ করে — স্যালিসাইলিক এসিড, অ্যাসপিরিন তৈরির কাঁচামাল।'],
  acet: ['অ্যাসিটাইলেশন (স্যালিসাইলিক এসিড + (CH₃CO)₂O)', () => areneX({ 0: 'OCOCH3', 1: 'COOH' }, 'অ্যাসপিরিন'), 'o-HOC6H4COOH + (CH3CO)2O -> o-CH3COOC6H4COOH + CH3COOH', 'ফেনলীয় –OH এস্টারে পরিণত হয় — অ্যাসিটাইলস্যালিসাইলিক এসিড (অ্যাসপিরিন), ব্যথানাশক ও জ্বরনাশক।'],
  zn: ['Zn চূর্ণ, তাপ', () => M3.LIB.benzene(), 'C6H5OH + Zn ->[\\Delta] C6H6 + ZnO', 'ফেনলকে বেনজিনে বিজারণ — ফেনলের গঠনে বেনজিন বলয়ের প্রমাণ।'],
  fecl3: ['নিরপেক্ষ FeCl₃', () => areneX({ 0: 'OH' }, 'ফেনল'), '6C6H5OH + FeCl3 -> [Fe(OC6H5)6]^3- + 3H+ + 3HCl', 'বেগুনি জটিল যৌগ — ফেনলের শনাক্তকরণ পরীক্ষা।']
};
V.p2c2_phenol = {
  t: 'ফেনল: ফিনক্সাইড আয়নের রেজোন্যান্স ও অম্লত্বের তুলনা (pKa সিঁড়ি, প্রতিস্থাপকের প্রভাব), এবং ফেনলের ৮টি বিক্রিয়া — উৎপাদের ত্রিমাত্রিক মডেলসহ', k: ['int', '3d', '2d'],
  cap: '"অম্লত্ব" ট্যাবে ফিনক্সাইড আয়নের রেজোন্যান্স কাঠামো (O এর ঋণাত্মক চার্জ বলয়ের অর্থো ও প্যারা কার্বনে বিস্থানীকৃত) এবং pKa সিঁড়ি: ফেনল অ্যালকোহলের চেয়ে ~১০⁶ গুণ শক্তিশালী এসিড কিন্তু কার্বনিক ও কার্বক্সিলিক এসিডের চেয়ে দুর্বল। ইলেকট্রন-আকর্ষী গ্রুপ (–NO₂, –Cl) অম্লত্ব বাড়ায়, ইলেকট্রনদাতা (–CH₃) কমায়। "বিক্রিয়া" ট্যাবে একটি বিকারক বেছে নাও — ডানে উৎপাদের ত্রিমাত্রিক মডেল (ঘোরাতে টানো), নিচে সমীকরণ ও ব্যাখ্যা।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('tb', [['acid', 'অম্লত্ব'], ['rx', 'বিক্রিয়া']], 'acid')}<select data-r style="display:none;padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${Object.entries(PRX).map(([k, v]) => `<option value="${k}">${v[0]}</option>`).join('')}</select></div>${X.cv('ফেনল')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 520;
    let L = X.fit(c, hf), tb = 'acid', rk = 'br2', m = null, ph = areneX({ 0: 'OH' }, 'ফেনল'), t = 0; const cam = M3.cam({ yaw: 0.3, pitch: 0.5 });
    C4.drag3d(c, cam, () => A.draw());
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (tb === 'acid') {
        // resonance row
        const rw = wd ? W * 0.6 : W, r = Math.min(rw / 5 / 2.6, 22), cy = 70; g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('ফিনক্সাইড আয়নের রেজোন্যান্স কাঠামো', 10, 16);
        const forms = [{ dbl: [0, 2, 4], oneg: true }, { dbl: [2, 4], exo: true, neg: 1 }, { dbl: [1, 4], exo: true, neg: 3 }, { dbl: [1, 3], exo: true, neg: 5 }];
        forms.forEach((f, i) => { const cx = rw * (i + 0.5) / 4, pts = M3.hex(g, cx, cy, r, col, { dbl: f.dbl }); const top = pts[0]; g.strokeStyle = col.fg; g.lineWidth = 1.8; g.beginPath(); g.moveTo(top[0], top[1]); g.lineTo(top[0], top[1] - r * 0.8); g.stroke(); if (f.exo) { g.beginPath(); g.moveTo(top[0] + 3.5, top[1]); g.lineTo(top[0] + 3.5, top[1] - r * 0.8); g.stroke(); } g.fillStyle = '#cc2418'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(f.oneg ? 'O⁻' : 'O', top[0] + 1, top[1] - r * 0.8 - 4); if (f.neg != null) { const pn = pts[f.neg]; g.fillStyle = '#c0392b'; g.fillText('⊖', pn[0] + (pn[0] - cx) * 0.45, pn[1] + (pn[1] - cy) * 0.45 + 4); } if (i < 3) { g.fillStyle = col.acc; g.font = `bold 13px ${col.font}`; g.fillText('↔', rw * (i + 1) / 4, cy + 4); } });
        g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('ঋণাত্মক চার্জ O ও দুই অর্থো + এক প্যারা কার্বনে ছড়ানো → ফিনক্সাইড স্থিতিশীল', rw / 2, cy + r + 26);
        // pKa ladder
        const lx = wd ? W * 0.62 : 20, ly = wd ? 30 : cy + r + 50, lw = wd ? W * 0.36 : W - 40, lh = wd ? H - 50 : H - ly - 20, n = PKA.length, bh = lh / n - 5;
        g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('pKa (ছোট দণ্ড = শক্তিশালী এসিড)', lx, ly - 8);
        PKA.forEach(([nm, v, cc], i) => { const y = ly + i * (lh / n), w = lw * 0.55 * v / 16; g.fillStyle = col.fg; g.font = `${nm === 'ফেনল' ? 'bold ' : ''}9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(nm, lx, y + bh * 0.7); g.fillStyle = cc; g.fillRect(lx + lw * 0.4, y, Math.max(2, w), bh); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText(bn(v), lx + lw * 0.4 + Math.max(2, w) + 4, y + bh * 0.75); });
        if (!wd) return;
        const c2 = M3.cam(cam); c2.cx = W * 0.3; c2.cy = H * 0.7; M3.fit(ph, c2, W * 0.5, H * 0.45, 0.85); if (!cam.user) cam.yaw = 0.45 * Math.sin(t * 0.5); M3.render(g, ph, c2, { mode: 'bs', col, labels: 'hetero' });
      } else {
        const d = PRX[rk]; const x0 = wd ? 0 : 0, w0 = wd ? W * 0.45 : W, w1 = wd ? W * 0.55 : W, y1 = wd ? 0 : H * 0.42, h1 = wd ? H : H - y1;
        const c1 = M3.cam(cam); c1.cx = x0 + w0 / 2; c1.cy = (wd ? H : y1) / 2 + 10; M3.fit(ph, c1, w0, (wd ? H : y1) - 30, 0.8); M3.render(g, ph, c1, { mode: 'bs', col, labels: 'hetero' });
        g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(rk === 'acet' ? 'স্যালিসাইলিক এসিড থেকে' : 'ফেনল', c1.cx, 16);
        g.fillStyle = col.acc; g.font = `bold 18px ${col.font}`; g.fillText(wd ? '→' : '↓', wd ? w0 : W / 2, wd ? H / 2 : y1); g.font = `9.5px ${col.font}`; g.fillText(d[0].split(' (')[0], wd ? w0 : W / 2 + 70, wd ? H / 2 + 18 : y1 + 4);
        const c3 = M3.cam(cam); c3.cx = (wd ? w0 : 0) + w1 / 2; c3.cy = y1 + h1 / 2 + 10; M3.fit(m, c3, w1, h1 - 30, 0.8); if (!cam.user) cam.yaw = 0.45 * Math.sin(t * 0.5); M3.render(g, m, c3, { mode: 'bs', col, labels: 'hetero' });
        g.fillStyle = '#2f9e44'; g.font = `bold 10.5px ${col.font}`; g.fillText(m.name, c3.cx, y1 + 16);
      }
    };
    const info = () => { if (tb === 'acid') { out.innerHTML = `<div>ফেনল (pKa ৯.৯৫) অ্যালকোহলের (pKa ~১৬) চেয়ে প্রায় দশ লক্ষ গুণ শক্তিশালী এসিড: ফিনক্সাইড আয়নের চার্জ রেজোন্যান্সে বলয়ে ছড়িয়ে পড়ে, অ্যালকক্সাইডে চার্জ একটি O তে আটকে থাকে। তবে কার্বক্সিলেটে চার্জ দুটি সমতুল্য তড়িৎঋণাত্মক O তে ছড়ায়, আর ফিনক্সাইডে চার্জ কম তড়িৎঋণাত্মক কার্বনে যায় — তাই ফেনল কার্বক্সিলিক এসিডের চেয়ে দুর্বল।</div>${TXB('\\ce{C6H5OH + H2O <=> C6H5O- + H3O+}\\quad K_a = 1.1\\times10^{-10}')}`; return; }
      const d = PRX[rk]; out.innerHTML = `<div><b>${d[0]}:</b> ${d[3]}</div>${TXB(`\\ce{${d[2]}}`)}`; };
    const setR = () => { m = PRX[rk][1](); ph = rk === 'acet' ? areneX({ 0: 'OH', 1: 'COOH' }, 'স্যালিসাইলিক এসিড') : areneX({ 0: 'OH' }, 'ফেনল'); info(); };
    q('[data-r]').onchange = e => { rk = e.target.value; setR(); }; q('[data-r]').value = rk;
    X.onSeg(el, 'tb', v => { tb = v; q('[data-r]').style.display = v === 'rx' ? '' : 'none'; if (v === 'rx') setR(); else { ph = areneX({ 0: 'OH' }, 'ফেনল'); info(); } });
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১৫ নাইট্রোগ্লিসারিন, TNT, ডেটল, প্যারাসিটামল, অ্যাসপিরিন ======================= */
const MED = {
  ngly: ['নাইট্রোগ্লিসারিন', 'প্রোপেন-১,২,৩-ট্রাইইল ট্রাইনাইট্রেট', [['গ্লিসারল', glycerol, ''], ['নাইট্রোগ্লিসারিন', ngly, 'C3H5(OH)3 + 3HNO3 ->[\\text{গাঢ় H}_2\\text{SO}_4] C3H5(ONO2)3 + 3H2O']], 'নাইট্রেট এস্টার (–O–NO₂) × ৩', 'বর্ণহীন তৈলাক্ত তরল, আঘাত বা ঝাঁকুনিতে বিস্ফোরিত হয়: 4C₃H₅(ONO₂)₃ → 12CO₂ + 10H₂O + 6N₂ + O₂ — কঠিন/তরল থেকে বিপুল আয়তনের গ্যাস ও তাপ। আলফ্রেড নোবেল কিসেলগুরে শোষিত করে নিরাপদ ডিনামাইট (১৮৬৭) উদ্ভাবন করেন। চিকিৎসায় (জিহ্বার নিচে ট্যাবলেট/স্প্রে) এনজাইনার বুকের ব্যথা উপশমে — শরীরে NO মুক্ত করে রক্তনালি প্রসারিত করে।'],
  tnt: ['TNT', '২-মিথাইল-১,৩,৫-ট্রাইনাইট্রোবেনজিন (২,৪,৬-ট্রাইনাইট্রোটলুইন)', [['টলুইন', () => areneX({ 0: 'CH3' }, 'টলুইন'), ''], ['৪-নাইট্রোটলুইন', () => areneX({ 0: 'CH3', 3: 'NO2' }, '৪-নাইট্রোটলুইন'), 'C6H5CH3 + HNO3 ->[\\text{H}_2\\text{SO}_4] p-O2NC6H4CH3 + H2O'], ['২,৪-ডাইনাইট্রোটলুইন', () => areneX({ 0: 'CH3', 1: 'NO2', 3: 'NO2' }, '২,৪-ডাইনাইট্রোটলুইন'), 'O2NC6H4CH3 + HNO3 -> (O2N)2C6H3CH3 + H2O'], ['TNT', () => areneX({ 0: 'CH3', 1: 'NO2', 3: 'NO2', 5: 'NO2' }, '২,৪,৬-ট্রাইনাইট্রোটলুইন'), '(O2N)2C6H3CH3 + HNO3 -> (O2N)3C6H2CH3 + H2O']], 'অ্যারোমেটিক নাইট্রো (–NO₂) × ৩, মিথাইল', '–CH₃ অর্থো-প্যারা নির্দেশক, তাই নাইট্রো গ্রুপ ২, ৪ ও ৬ অবস্থানে বসে। প্রতিটি –NO₂ বলয়কে নিষ্ক্রিয় করে — তাই পরের নাইট্রেশন ক্রমশ কঠিন (ইলেকট্রোফিলিক প্রতিস্থাপনের আদর্শ উদাহরণ)। হলুদ কেলাসিত কঠিন (গলনাঙ্ক ৮১ °C), তুলনামূলকভাবে আঘাতে অসংবেদী — খনি, নির্মাণ ও সামরিক কাজে বিস্ফোরক; বিস্ফোরকের শক্তি "টন TNT" এককে মাপা হয়। বিয়োজন: 2C₇H₅N₃O₆ → 3N₂ + 5H₂O + 7CO + 7C (অক্সিজেনের ঘাটতি — কালো ধোঁয়া)।'],
  dettol: ['ডেটল (PCMX)', '৪-ক্লোরো-৩,৫-ডাইমিথাইলফেনল (ক্লোরোজাইলেনল)', [['৩,৫-ডাইমিথাইলফেনল', () => areneX({ 0: 'OH', 2: 'CH3', 4: 'CH3' }, '৩,৫-ডাইমিথাইলফেনল'), ''], ['ক্লোরোজাইলেনল', () => areneX({ 0: 'OH', 2: 'CH3', 3: 'Cl', 4: 'CH3' }, '৪-ক্লোরো-৩,৫-ডাইমিথাইলফেনল'), '(CH3)2C6H3OH + Cl2 -> (CH3)2ClC6H2OH + HCl']], 'ফেনলীয় –OH, Cl, দুটি –CH₃', 'ডেটলের সক্রিয় উপাদান ক্লোরোজাইলেনল (~৪.৮%), সাথে পাইন তেল, আইসোপ্রোপাইল অ্যালকোহল, ক্যাস্টর তেলের সাবান ও পানি। পানিতে মেশালে সাদা দুধের মতো ইমালশন হয়। ফেনলীয় জীবাণুনাশক — ব্যাকটেরিয়ার কোষঝিল্লি নষ্ট করে ও প্রোটিন জমাট বাঁধায়; ফেনলের চেয়ে কম বিষাক্ত ও ত্বকে কম ক্ষতিকর। ক্ষত পরিষ্কার, প্রসূতি পরিচর্যা ও মেঝে জীবাণুমুক্তকরণে ব্যবহৃত।'],
  para: ['প্যারাসিটামল', 'N-(৪-হাইড্রক্সিফিনাইল)ইথানামাইড (অ্যাসিটামিনোফেন)', [['ফেনল', () => areneX({ 0: 'OH' }, 'ফেনল'), ''], ['৪-নাইট্রোফেনল', () => areneX({ 0: 'OH', 3: 'NO2' }, '৪-নাইট্রোফেনল'), 'C6H5OH + HNO3(dil) -> p-O2NC6H4OH + H2O'], ['৪-অ্যামিনোফেনল', () => areneX({ 0: 'OH', 3: 'NH2' }, '৪-অ্যামিনোফেনল'), 'p-O2NC6H4OH + 6[H] ->[\\text{Sn/HCl বা H}_2/\\text{Ni}] p-H2NC6H4OH + 2H2O'], ['প্যারাসিটামল', () => areneX({ 0: 'OH', 3: 'NHCOCH3' }, 'প্যারাসিটামল'), 'p-H2NC6H4OH + (CH3CO)2O -> p-CH3CONHC6H4OH + CH3COOH']], 'ফেনলীয় –OH, অ্যামাইড (–NHCOCH₃)', 'বেদনানাশক ও জ্বরনাশক (প্রদাহনাশক নয়)। শেষ ধাপে অ্যাসিটিক অ্যানহাইড্রাইড বেছে বেছে –NH₂ কে অ্যাসিটাইলেট করে (N, O এর চেয়ে বেশি নিউক্লিওফিলিক)। নিরাপদ মাত্রা প্রাপ্তবয়স্কে দিনে সর্বোচ্চ ~৪ g; অতিমাত্রায় যকৃতের মারাত্মক ক্ষতি করে — বিপাকে বিষাক্ত NAPQI তৈরি হয়।'],
  aspirin: ['অ্যাসপিরিন', '২-অ্যাসিটক্সিবেনজয়িক এসিড (অ্যাসিটাইলস্যালিসাইলিক এসিড)', [['ফেনল', () => areneX({ 0: 'OH' }, 'ফেনল'), ''], ['স্যালিসাইলিক এসিড', () => areneX({ 0: 'OH', 1: 'COOH' }, 'স্যালিসাইলিক এসিড'), 'C6H5ONa + CO2 -> o-HOC6H4COONa ->[\\text{H}^+] o-HOC6H4COOH'], ['অ্যাসপিরিন', () => areneX({ 0: 'OCOCH3', 1: 'COOH' }, 'অ্যাসপিরিন'), 'o-HOC6H4COOH + (CH3CO)2O -> o-CH3COOC6H4COOH + CH3COOH']], 'কার্বক্সিলিক এসিড, এস্টার', 'ব্যথা, জ্বর ও প্রদাহনাশক; কম মাত্রায় রক্ত জমাট বাঁধা প্রতিরোধে (হৃদরোগ)। স্যালিসাইলিক এসিড নিজে পাকস্থলীতে বেশি জ্বালা করে — ফেনলীয় –OH কে এস্টার বানিয়ে সহনীয় করা হয়েছে। আর্দ্র বাতাসে পুরনো অ্যাসপিরিনে ভিনেগারের গন্ধ — এস্টার আর্দ্রবিশ্লেষিত হয়ে অ্যাসিটিক এসিড।']
};
V.p2c2_medchem = {
  t: 'নাইট্রোগ্লিসারিন, TNT, ডেটল, প্যারাসিটামল ও অ্যাসপিরিন: ত্রিমাত্রিক গঠন, কার্যকরী মূলক চিহ্নিতকরণ এবং কাঁচামাল থেকে ধাপে ধাপে প্রস্তুতি (প্রতিটি মধ্যবর্তী যৌগের ৩D মডেল)', k: ['3d', 'int'],
  cap: 'উপরে যৌগ বেছে নাও, তারপর নিচের ধাপ বোতামে (বা ◀ ▶) চাপ দিয়ে প্রস্তুতির পথ ধরে এগোও — প্রতিটি ধাপে মধ্যবর্তী যৌগের ত্রিমাত্রিক মডেল ও সমীকরণ। নতুন যুক্ত পরমাণুগুলো উজ্জ্বল হয়। মডেল টেনে ঘোরাও। লক্ষ করো: TNT তে –CH₃ এর অর্থো-প্যারা নির্দেশনায় ২, ৪, ৬ অবস্থান; প্যারাসিটামলে –OH ও –NHCOCH₃ পরস্পর প্যারা; অ্যাসপিরিনে –COOH ও এস্টার পরস্পর অর্থো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('cp', Object.entries(MED).map(([k, v]) => [k, v[0]]), 'para')}</div>${X.cv('ওষুধ ও বিস্ফোরক')}<div class="ctl" data-steps style="flex-wrap:wrap;gap:4px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), sb = q('[data-steps]');
    const hf = w => wide(w) ? 340 : 420;
    let L = X.fit(c, hf), cp = 'para', si = 0, mols = [], t = 0; const cam = M3.cam({ yaw: 0.2, pitch: 0.45 });
    C4.drag3d(c, cam, () => A.draw());
    const build = () => { mols = MED[cp][2].map(s => s[1]()); si = mols.length - 1; steps(); info(); };
    const steps = () => { const S = MED[cp][2]; sb.innerHTML = `<button class="btn sm" data-d="-1" ${si ? '' : 'disabled'}>◀</button>` + S.map((s, i) => `<button class="btn sm ${i === si ? 'primary' : ''}" data-i="${i}">${bn(i + 1)}. ${s[0]}</button>`).join('') + `<button class="btn sm" data-d="1" ${si < S.length - 1 ? '' : 'disabled'}>▶</button>`; sb.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { si = +b.dataset.i; steps(); info(); }); sb.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { si = Math.max(0, Math.min(S.length - 1, si + +b.dataset.d)); steps(); info(); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const m = mols[si], prev = si ? mols[si - 1] : null;
      cam.cx = W / 2; cam.cy = H / 2 + 10; M3.fit(m, cam, W, H - 40, 0.85); if (!cam.user) cam.yaw = 0.45 * Math.sin(t * 0.5);
      const hl = {}; if (prev) { const cnt = {}; prev.a.forEach(a => { cnt[a.el] = (cnt[a.el] || 0) + 1; }); const seen = {}; m.a.forEach((a, i) => { seen[a.el] = (seen[a.el] || 0) + 1; if (a.el !== 'H' && seen[a.el] > (cnt[a.el] || 0)) hl[i] = '#f1c40f'; }); }
      M3.render(g, m, cam, { mode: 'bs', col, hl, labels: 'hetero' });
      g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(`${m.name} — ${M3.formula(m)}`, W / 2, 18); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(`ধাপ ${bn(si + 1)}/${bn(mols.length)} · M = ${bn(M3.mass(m).toFixed(1))} g/mol`, W / 2, 33);
    };
    const info = () => { const d = MED[cp], s = d[2][si]; out.innerHTML = `<div><b>${d[0]}</b> — ${d[1]}। <span class="small">কার্যকরী মূলক: ${d[3]}</span></div>${s[2] ? TXB(`\\ce{${s[2]}}`) : '<div class="small" style="margin:6px 0">কাঁচামাল — পরের ধাপে যাও (▶)।</div>'}${si === d[2].length - 1 ? `<div class="small">${d[4]}</div>` : ''}`; };
    X.onSeg(el, 'cp', v => { cp = v; build(); });
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    build(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
