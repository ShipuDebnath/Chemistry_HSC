/* ২য় পত্র অধ্যায় ২ visuals part 5 — 2.6–2.7 isomerism: relaxer, types of isomerism, cis/trans builder, chirality & R/S, polarimeter, 2ⁿ stereoisomers (Fischer), structural isomer enumeration */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm, cross, dot, len } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = M3.ease;

/* ---------- geometry relaxer (bond lengths, VSEPR angles, non-bonded repulsion, C=C planarity) ---------- */
M3.relax = (m, iters = 220) => {
  const n = m.a.length, nb = Array.from({ length: n }, () => []);
  m.b.forEach(b => { if (b.st === 'dash') return; nb[b.i].push(b.j); nb[b.j].push(b.i); });
  const bo = (i, j) => { const b = m.b.find(z => (z.i === i && z.j === j) || (z.i === j && z.j === i)); return b ? b.o : 0; };
  const cons = [];
  m.b.forEach(b => { if (b.st !== 'dash') cons.push([b.i, b.j, M3.bondLen(m.a[b.i].el, m.a[b.j].el, b.o), 1]); });
  m.a.forEach((A, j) => {
    const N = nb[j]; if (N.length < 2) return; const os = N.map(k => bo(j, k));
    let th = A.geo === 'lin' || os.includes(3) || os.filter(o => o === 2).length >= 2 ? 180 : A.geo === 'tri' || os.includes(2) || os.includes(1.5) || (A.el === 'C' && (A.q > 0 || A.rad)) ? 120 : (A.el === 'O' ? 106 : A.el === 'N' && N.length === 3 ? 107.5 : 109.47);
    if (A.ring3) th = 60;
    for (let p = 0; p < N.length; p++) for (let q = p + 1; q < N.length; q++) { const a = M3.bondLen(A.el, m.a[N[p]].el, bo(j, N[p])), c = M3.bondLen(A.el, m.a[N[q]].el, bo(j, N[q])); cons.push([N[p], N[q], Math.sqrt(a * a + c * c - 2 * a * c * Math.cos(th * Math.PI / 180)), 0.6]); }
  });
  // topological distance
  const D = Array.from({ length: n }, () => new Array(n).fill(99)); for (let s = 0; s < n; s++) { D[s][s] = 0; const qq = [s]; while (qq.length) { const u = qq.shift(); nb[u].forEach(v => { if (D[s][v] > D[s][u] + 1) { D[s][v] = D[s][u] + 1; qq.push(v); } }); } }
  const far = []; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (D[i][j] >= 3) far.push([i, j, m.a[i].el === 'H' && m.a[j].el === 'H' ? 2.2 : m.a[i].el === 'H' || m.a[j].el === 'H' ? 2.6 : 3.0]);
  const dbl = m.b.filter(b => b.o === 2 && nb[b.i].length > 1 && nb[b.j].length > 1 && !m.ring);
  const P = m.a.map(a => a.p);
  for (let it = 0; it < iters; it++) {
    cons.forEach(([i, j, d0, k]) => { const d = sub(P[j], P[i]), l = len(d) || 1e-6, c = (l - d0) / l * 0.5 * k; P[i] = add(P[i], mul(d, c)); P[j] = sub(P[j], mul(d, c)); });
    far.forEach(([i, j, dmin]) => { const d = sub(P[j], P[i]), l = len(d) || 1e-6; if (l < dmin) { const c = (l - dmin) / l * 0.12; P[i] = add(P[i], mul(d, c)); P[j] = sub(P[j], mul(d, c)); } });
    if (it % 8 === 0) { m.a.forEach((a, k) => { a.p = P[k]; }); dbl.forEach(b => { const a1 = nb[b.i].find(k => k !== b.j), b1 = nb[b.j].find(k => k !== b.i); if (a1 == null || b1 == null) return; const p0 = P[a1], p1 = P[b.i], p2 = P[b.j], p3 = P[b1]; const v1 = sub(p1, p0), v2 = sub(p2, p1), v3 = sub(p3, p2), n1 = cross(v1, v2), n2 = cross(v2, v3), mm = cross(n1, norm(v2)); const ang = Math.atan2(dot(mm, n2), dot(n1, n2)); const tgt = Math.abs(ang) < Math.PI / 2 ? 0 : (ang > 0 ? Math.PI : -Math.PI); const side = M3.side(m, b.i, b.j).filter(k => k !== b.i); M3.rotateAbout(m, b.i, b.j, side, -(ang - tgt) * 0.7); side.forEach(k => { P[k] = m.a[k].p; }); }); }
  }
  m.a.forEach((a, k) => { a.p = P[k]; });
  M3.offsets(m); M3.center(m); return m;
};
const T = (list, name, opt) => { const m = M3.tree(list, { name }); return opt === false ? m : M3.relax(m); };

/* ---------- quaternion helpers ---------- */
const Q = {
  fromMat: R => { const tr = R[0][0] + R[1][1] + R[2][2]; let w, x, y, z; if (tr > 0) { const s = Math.sqrt(tr + 1) * 2; w = s / 4; x = (R[2][1] - R[1][2]) / s; y = (R[0][2] - R[2][0]) / s; z = (R[1][0] - R[0][1]) / s; } else if (R[0][0] > R[1][1] && R[0][0] > R[2][2]) { const s = Math.sqrt(1 + R[0][0] - R[1][1] - R[2][2]) * 2; w = (R[2][1] - R[1][2]) / s; x = s / 4; y = (R[0][1] + R[1][0]) / s; z = (R[0][2] + R[2][0]) / s; } else if (R[1][1] > R[2][2]) { const s = Math.sqrt(1 + R[1][1] - R[0][0] - R[2][2]) * 2; w = (R[0][2] - R[2][0]) / s; x = (R[0][1] + R[1][0]) / s; y = s / 4; z = (R[1][2] + R[2][1]) / s; } else { const s = Math.sqrt(1 + R[2][2] - R[0][0] - R[1][1]) * 2; w = (R[1][0] - R[0][1]) / s; x = (R[0][2] + R[2][0]) / s; y = (R[1][2] + R[2][1]) / s; z = s / 4; } return [w, x, y, z]; },
  slerp: (a, b, t) => { let d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]; if (d < 0) { b = b.map(v => -v); d = -d; } if (d > 0.9995) { const r = a.map((v, i) => v + (b[i] - v) * t), l = Math.hypot(...r); return r.map(v => v / l); } const th = Math.acos(d), s = Math.sin(th); return a.map((v, i) => (v * Math.sin((1 - t) * th) + b[i] * Math.sin(t * th)) / s); },
  rot: (q, v) => { const [w, x, y, z] = q, ix = w * v[0] + y * v[2] - z * v[1], iy = w * v[1] + z * v[0] - x * v[2], iz = w * v[2] + x * v[1] - y * v[0], iw = -x * v[0] - y * v[1] - z * v[2]; return [ix * w + iw * -x + iy * -z - iz * -y, iy * w + iw * -y + iz * -x - ix * -z, iz * w + iw * -z + ix * -y - iy * -x]; }
};
const frame = (a, b) => { const e1 = norm(a), e2 = norm(sub(b, mul(e1, dot(b, e1)))), e3 = cross(e1, e2); return [e1, e2, e3]; };
const alignMat = (sa, sb, ta, tb) => { const S = frame(sa, sb), Tt = frame(ta, tb), R = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]; for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) for (let k = 0; k < 3; k++) R[i][j] += Tt[k][i] * S[k][j]; return R; };
const mirrorX = m => { const o = M3.clone(m); o.a.forEach(a => { a.p = [-a.p[0], a.p[1], a.p[2]]; }); M3.offsets(o); M3.center(o); return o; };
M3.mirrorX = mirrorX;

/* ======================= ২.৬ সমাণুতার প্রকারভেদ ======================= */
const ketoEnol = () => {
  const k = T([['C', -1], ['C', 0], ['C', 1], ['O', 1, 2]], 'প্রোপানোন (কিটো)');
  const hOn0 = M3.nbrs(k, 0).filter(j => k.a[j].el === 'H')[0];
  const e = M3.clone(k); e.b = e.b.filter(b => !((b.i === 0 && b.j === hOn0) || (b.j === 0 && b.i === hOn0))); e.b.push({ i: 3, j: hOn0, o: 1 }); e.b.forEach(b => { if ((b.i === 0 && b.j === 1) || (b.i === 1 && b.j === 0)) b.o = 2; if ((b.i === 1 && b.j === 3) || (b.i === 3 && b.j === 1)) b.o = 1; });
  e.a[hOn0].p = add(e.a[3].p, mul(norm(sub(e.a[3].p, e.a[1].p)), 0.96)); M3.relax(e, 400); e.name = 'প্রপ-১-ইন-২-অল (ইনল)';
  // align enol onto keto frame (C1→C2, C2→C3)
  return { k, e, h: hOn0 };
};
const ISO_T = {
  chain: ['শিকল সমাণুতা', 'কার্বন শিকলের গঠন (সরল/শাখান্বিত) ভিন্ন', () => [T([['C', -1], ['C', 0], ['C', 1], ['C', 2]], 'বিউটেন'), T([['C', -1], ['C', 0], ['C', 1], ['C', 1]], '২-মিথাইলপ্রোপেন')], 'C₄H₁₀: বিউটেন (স্ফু. −০.৫ °C) ও ২-মিথাইলপ্রোপেন (স্ফু. −১১.৭ °C)', 'গাঠনিক'],
  pos: ['অবস্থান সমাণুতা', 'একই শিকলে কার্যকরী মূলক বা বহুবন্ধনের অবস্থান ভিন্ন', () => [T([['C', -1], ['C', 0], ['C', 1], ['O', 2]], 'প্রোপান-১-অল'), T([['C', -1], ['C', 0], ['C', 1], ['O', 1]], 'প্রোপান-২-অল')], 'C₃H₈O: প্রোপান-১-অল (১° অ্যালকোহল) ও প্রোপান-২-অল (২° অ্যালকোহল)', 'গাঠনিক'],
  func: ['কার্যকরী মূলক সমাণুতা', 'কার্যকরী মূলক ভিন্ন', () => [T([['C', -1], ['C', 0], ['O', 1]], 'ইথানল'), T([['C', -1], ['O', 0], ['C', 1]], 'মিথক্সিমিথেন')], 'C₂H₆O: ইথানল (অ্যালকোহল, স্ফু. ৭৮ °C) ও মিথক্সিমিথেন (ইথার, স্ফু. −২৪ °C)', 'গাঠনিক'],
  meta: ['মেটামারিজম', 'একই কার্যকরী মূলকের দুই পাশে ভিন্ন অ্যালকাইল মূলক', () => [T([['C', -1], ['C', 0], ['O', 1], ['C', 2], ['C', 3]], 'ইথক্সিইথেন'), T([['C', -1], ['O', 0], ['C', 1], ['C', 2], ['C', 3]], '১-মিথক্সিপ্রোপেন')], 'C₄H₁₀O: ডাইইথাইল ইথার (C₂H₅–O–C₂H₅) ও মিথাইল প্রোপাইল ইথার (CH₃–O–C₃H₇)', 'গাঠনিক'],
  taut: ['টটোমারিজম', 'H পরমাণুর স্থানান্তরে দুটি রূপ সাম্যাবস্থায় থাকে (কিটো ⇌ ইনল)', null, 'প্রোপানোন (কিটো, ~৯৯.৯৯৯৯%) ⇌ প্রপ-১-ইন-২-অল (ইনল) — α-H এর স্থানান্তর', 'গাঠনিক (গতিশীল)'],
  geo: ['জ্যামিতিক সমাণুতা', 'C=C এ ঘূর্ণন বাধাপ্রাপ্ত — গ্রুপের স্থানিক বিন্যাস (cis/trans) ভিন্ন', null, 'বিউট-২-ইন: cis (একই পাশে CH₃) ও trans (বিপরীত পাশে CH₃)', 'স্টেরিও'],
  opt: ['আলোক সমাণুতা', 'অপ্রতিসম কার্বন — পরস্পরের অনধিস্থাপনযোগ্য দর্পণ প্রতিবিম্ব', null, 'ল্যাকটিক এসিড: (R) ও (S) — এনানসিওমার', 'স্টেরিও']
};
const butene = (cis, sub2 = ['C', 1.50]) => { const x = 0.67, a = 125 * Math.PI / 180; const at = [['C', -x, 0, 0], ['C', x, 0, 0], [sub2[0], -x + sub2[1] * Math.cos(a), sub2[1] * Math.sin(a), 0], [sub2[0], x - sub2[1] * Math.cos(a), (cis ? 1 : -1) * sub2[1] * Math.sin(a), 0]]; return M3.mol({ name: cis ? 'cis-বিউট-২-ইন' : 'trans-বিউট-২-ইন', a: at.map(r => r.concat([{ pn: [0, 0, 1] }])), b: [[0, 1, 2], [0, 2], [1, 3]] }); };
const lactic = () => T([['C', -1], ['O', 0], ['C', 0], ['C', 0], ['O', 3, 2], ['O', 3]], 'ল্যাকটিক এসিড');
V.p2c2_isoTypes = {
  t: 'সমাণুতার প্রকারভেদ: গাঠনিক (শিকল, অবস্থান, কার্যকরী মূলক, মেটামারিজম, টটোমারিজম) ও স্টেরিও (জ্যামিতিক, আলোক) — প্রতিটির ত্রিমাত্রিক জোড়া', k: ['3d', 'int', 'anim'],
  cap: 'উপরে সমাণুতার ধরন বেছে নাও — একই আণবিক সংকেতের দুটি সমাণু পাশাপাশি ত্রিমাত্রিকভাবে আসে (টেনে দুটিই একসাথে ঘোরাও)। গাঠনিক সমাণুতায় পরমাণুগুলোর সংযোগের ক্রমই ভিন্ন; স্টেরিও সমাণুতায় সংযোগ একই, কেবল ত্রিমাত্রিক বিন্যাস ভিন্ন। টটোমারিজমে একটি H পরমাণু α-কার্বন থেকে O তে সরে কিটো রূপ ইনল রূপে বদলায় — অ্যানিমেশনে দেখো; আলোক সমাণুতায় দুটি অণুর মাঝে দর্পণ।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ty', Object.entries(ISO_T).map(([k, v]) => [k, v[0].replace(' সমাণুতা', '')]), 'chain')}</div>${X.cv('সমাণুতার প্রকারভেদ')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 320 : 460;
    let L = X.fit(c, hf), ty = 'chain', pair = ISO_T.chain[2](), KE = null, t = 0; const cam = M3.cam({ yaw: 0.3, pitch: 0.35 });
    C4.drag3d(c, cam, () => A.draw());
    const set = k => { ty = k; cam.user = false; if (k === 'taut') { KE = KE || ketoEnol(); pair = null; } else if (k === 'geo') pair = [butene(true), butene(false)]; else if (k === 'opt') { const l = lactic(); pair = [l, mirrorX(l)]; } else pair = ISO_T[k][2](); const d = ISO_T[k]; out.innerHTML = `<div><span class="small" style="color:var(--acc);font-weight:700">${d[4]} সমাণুতা ›</span> <b>${d[0]}:</b> ${d[1]}।</div><div class="small" style="margin-top:4px">উদাহরণ — ${d[3]}।</div>`; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W); if (!cam.user) cam.yaw += 0.005;
      if (ty === 'taut') {
        const s = (Math.sin(t * 0.9) + 1) / 2, f = ease(Math.min(1, Math.max(0, (s - 0.15) / 0.7))); const mm = M3.clone(KE.k); mm.a.forEach((a, i) => { a.p = add(mul(KE.k.a[i].p, 1 - f), mul(KE.e.a[i].p, f)); }); mm.b = (f > 0.5 ? KE.e.b : KE.k.b).map(b => Object.assign({}, b)); M3.offsets(mm); M3.center(mm);
        cam.cx = W / 2; cam.cy = H / 2 + 6; M3.fit(KE.k, cam, W * 0.7, H - 40, 0.9); const hl = {}; hl[KE.h] = '#f1c40f'; M3.render(g, mm, cam, { mode: 'bs', col, hl, center: KE.k.c, labels: 'hetero' });
        g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(f < 0.5 ? 'কিটো রূপ: CH₃–CO–CH₃' : 'ইনল রূপ: CH₂=C(OH)–CH₃', W / 2, 18); g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.fillText('হলুদ আভার H পরমাণুটি C থেকে O তে সরে — দ্রুত সাম্যাবস্থা', W / 2, H - 8); return;
      }
      const [m1, m2] = pair, w2 = wd ? W / 2 : W, h2 = wd ? H : H / 2;
      [[m1, 0], [m2, 1]].forEach(([m, k]) => { const c2 = M3.cam(cam); c2.cx = wd ? w2 * (k + 0.5) : W / 2; c2.cy = wd ? H / 2 + 8 : h2 * (k + 0.5) + 6; M3.fit(m1.R > m2.R ? m1 : m2, c2, w2, h2 - 36, 0.92); if (ty === 'opt' && k === 1) c2.yaw = -cam.yaw; M3.render(g, m, c2, { mode: 'bs', col, labels: 'hetero' }); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${m.name} · ${M3.formula(m)}`, c2.cx, wd ? 18 : h2 * k + 16); });
      g.strokeStyle = ty === 'opt' ? '#5dade2' : col.mu; g.lineWidth = ty === 'opt' ? 3 : 1; g.setLineDash(ty === 'opt' ? [] : [4, 4]); g.beginPath(); if (wd) { g.moveTo(W / 2, 30); g.lineTo(W / 2, H - 10); } else { g.moveTo(10, H / 2); g.lineTo(W - 10, H / 2); } g.stroke(); g.setLineDash([]); if (ty === 'opt') { g.fillStyle = '#5dade2'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('দর্পণ', wd ? W / 2 : 30, wd ? H - 2 : H / 2 - 4); }
    };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'ty', set);
    set('chain'); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৬.১–২.৬.২ জ্যামিতিক সমাণুতা: cis/trans ও E/Z নির্মাতা ======================= */
const GRPS = { H: ['H', 0, 1], CH3: ['CH₃', 1, 6], C2H5: ['C₂H₅', 2, 6], COOH: ['COOH', 3, 6], Cl: ['Cl', 4, 17], Br: ['Br', 5, 35] };
const alkene = (a, b, c, d) => { // a (C1 up), b (C1 down), c (C2 up), d (C2 down)
  const x = 0.67, at = [['C', -x, 0, 0, { pn: [0, 0, 1] }], ['C', x, 0, 0, { pn: [0, 0, 1] }]], bd = [[0, 1, 2]];
  const put = (gk, ci, up) => { const sgx = ci ? 1 : -1, ang = (up ? 1 : -1) * (180 - 122) * Math.PI / 180, u = [sgx * Math.cos(ang), Math.sin(ang) * 1, 0]; u[1] = (up ? 1 : -1) * Math.abs(Math.sin(ang)); u[0] = sgx * Math.abs(Math.cos(ang)); const base = at[ci].slice(1, 4);
    if (gk === 'H') { at.push(['H', ...add(base, mul(u, 1.08))]); bd.push([ci, at.length - 1]); return; }
    if (gk === 'Cl' || gk === 'Br') { at.push([gk, ...add(base, mul(u, gk === 'Cl' ? 1.73 : 1.89))]); bd.push([ci, at.length - 1]); return; }
    const p = add(base, mul(u, gk === 'COOH' ? 1.48 : 1.50)); at.push(['C', ...p, gk === 'COOH' ? { geo: 'tri', pn: [0, 0, 1] } : {}]); const k = at.length - 1; bd.push([ci, k]);
    const v = norm([-u[1] * sgx * 0 + 0, 0, 0]); void v; const perpIn = [-u[1], u[0], 0], away = dot(perpIn, [0, up ? 1 : -1, 0]) >= 0 ? perpIn : mul(perpIn, -1);
    if (gk === 'C2H5') { at.push(['C', ...add(p, mul(add(mul(u, 0.333), mul([0, 0, 1], 0.943)), 1.54))]); bd.push([k, at.length - 1]); }
    if (gk === 'COOH') { const r = ang2 => add(mul(u, Math.cos(ang2)), mul(away, Math.sin(ang2))); at.push(['O', ...add(p, mul(r(Math.PI / 3), 1.21))]); bd.push([k, at.length - 1, 2]); at.push(['O', ...add(p, mul(r(-Math.PI / 3), 1.34)), { geo: 'tri', pn: [0, 0, 1] }]); bd.push([k, at.length - 1]); }
  };
  put(a, 0, true); put(b, 0, false); put(c, 1, true); put(d, 1, false);
  const m = M3.mol({ a: at, b: bd }); return m;
};
const GEX = [
  ['বিউট-২-ইন', ['CH3', 'H', 'CH3', 'H'], 'cis: স্ফু. ৩.৭ °C, গ. −১৩৯ °C, μ = ০.৩৩ D · trans: স্ফু. ০.৯ °C, গ. −১০৬ °C, μ = ০'],
  ['১,২-ডাইক্লোরোইথিন', ['Cl', 'H', 'Cl', 'H'], 'cis: স্ফু. ৬০.৩ °C, μ = ১.৯ D · trans: স্ফু. ৪৭.৫ °C, μ = ০ (C–Cl দ্বিপোল দুটি বিপরীতমুখী ও সমান)'],
  ['বিউটিনডাইওয়িক এসিড', ['COOH', 'H', 'COOH', 'H'], 'cis = ম্যালেয়িক এসিড: গ. ১৩৫ °C, পানিতে খুব দ্রবণীয়, তাপে অ্যানহাইড্রাইড গঠন করে (–COOH দুটি কাছাকাছি) · trans = ফিউমারিক এসিড: গ. ~২৮৭ °C (বদ্ধ নলে), কম দ্রবণীয়, অ্যানহাইড্রাইড দেয় না']
];
V.p2c2_cisTrans = {
  t: 'জ্যামিতিক সমাণুতা: C=C এ বাধাপ্রাপ্ত ঘূর্ণনের ফলে cis ও trans (Z ও E) রূপ — তিনটি উদাহরণ ও নিজের অ্যালকিন তৈরির নির্মাতা (দ্বিপোল ভ্রামকসহ)', k: ['3d', 'int'],
  cap: '"উদাহরণ" মোডে তিনটি পরিচিত জোড়া — প্রতিটির cis (বাঁয়ে) ও trans (ডানে) রূপ ত্রিমাত্রিকভাবে, সবুজ তীরে মোট দ্বিপোল ভ্রামক এবং নিচে পরীক্ষালব্ধ ধর্ম। "নির্মাতা" মোডে দ্বিবন্ধনের দুই কার্বনের চারটি অবস্থানে গ্রুপ বসাও: যদি কোনো কার্বনে দুটি একই গ্রুপ থাকে (যেমন H, H), জ্যামিতিক সমাণুতা সম্ভব নয় — দুটি "রূপ" আসলে একই অণু। নাহলে cis/trans (একই গ্রুপ থাকলে) এবং CIP অগ্রাধিকার দিয়ে E/Z নাম স্বয়ংক্রিয়ভাবে নির্ধারিত হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['ex', 'উদাহরণ'], ['bd', 'নির্মাতা']], 'ex')}<span data-exw>${X.seg('ex', GEX.map((e, i) => [String(i), e[0]]), '0')}</span></div><div class="ctl" data-bdw style="display:none;flex-wrap:wrap;gap:6px">${['a', 'b', 'c', 'd'].map((k, i) => `<label class="small">${['C₁ উপরে', 'C₁ নিচে', 'C₂ উপরে', 'C₂ নিচে'][i]} <select data-g="${k}" style="padding:4px;border-radius:6px;border:1px solid var(--line);background:var(--sf);color:var(--fg);font:inherit">${Object.entries(GRPS).map(([g2, v]) => `<option value="${g2}">${v[0]}</option>`).join('')}</select></label>`).join('')}</div>${X.cv('জ্যামিতিক সমাণুতা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 480;
    let L = X.fit(c, hf), md = 'ex', ex = 0, G = { a: 'CH3', b: 'H', c: 'Cl', d: 'H' }, pair = [], ok = true, t = 0, labs = ['', '']; const cam = M3.cam({ yaw: 0.25, pitch: 0.3 });
    C4.drag3d(c, cam, () => A.draw());
    const dip = (gk) => ({ Cl: 1.0, Br: 0.95, COOH: 0.6, CH3: -0.25, C2H5: -0.25, H: 0 })[gk];
    const netDip = (s) => { const v = [0, 0, 0]; [[s[0], -1, 1], [s[1], -1, -1], [s[2], 1, 1], [s[3], 1, -1]].forEach(([gk, sx, sy]) => { const u = [sx * 0.53, sy * 0.85, 0]; const k = dip(gk); v[0] += u[0] * k; v[1] += u[1] * k; }); return v; };
    const rebuild = () => {
      let s1, s2; if (md === 'ex') { const e = GEX[ex][1]; s1 = e; s2 = [e[0], e[1], e[3], e[2]]; } else { s1 = [G.a, G.b, G.c, G.d]; s2 = [G.a, G.b, G.d, G.c]; }
      ok = s1[0] !== s1[1] && s1[2] !== s1[3];
      pair = [[alkene(...s1), s1], [alkene(...s2), s2]];
      const name = s => { const sameSide = (s[0] === s[2] && s[0] !== 'H') || (s[1] === s[3] && s[1] !== 'H') || (s[0] === s[2]) || (s[1] === s[3]); const opp = s[0] === s[3] || s[1] === s[2]; const ct = s[0] === s[2] || s[1] === s[3] ? 'cis' : opp ? 'trans' : '—'; const h1 = GRPS[s[0]][1] > GRPS[s[1]][1] ? 'up' : 'down', h2 = GRPS[s[2]][1] > GRPS[s[3]][1] ? 'up' : 'down'; void sameSide; return [ct, h1 === h2 ? 'Z' : 'E']; };
      labs = pair.map(p => { const [ct, ez] = name(p[1]); return ok ? `${ct !== '—' ? ct + ' · ' : ''}(${ez})` : 'একই অণু'; });
      out.innerHTML = md === 'ex' ? `<div><b>${GEX[ex][0]}</b>: ${GEX[ex][2]}</div><div class="small" style="margin-top:4px">শর্ত: দ্বিবন্ধনের প্রতিটি কার্বনে দুটি ভিন্ন গ্রুপ থাকতে হবে। cis এ একই গ্রুপ একই পাশে; trans এ বিপরীত পাশে। trans রূপ সাধারণত বেশি স্থিতিশীল (গ্রুপগুলোর মধ্যে বিকর্ষণ কম) ও বেশি প্রতিসম — কেলাসে ভালোভাবে সাজে, গলনাঙ্ক বেশি; cis রূপ পোলার হলে স্ফুটনাঙ্ক বেশি।</div>` : (ok ? `<div><b>জ্যামিতিক সমাণুতা সম্ভব ✓</b> — প্রতিটি কার্বনে দুটি ভিন্ন গ্রুপ। বাঁয়ে ${labs[0]}, ডানে ${labs[1]}।</div><div class="small" style="margin-top:4px">E/Z নিয়ম: প্রতিটি কার্বনে পারমাণবিক সংখ্যা অনুযায়ী উচ্চ অগ্রাধিকারের গ্রুপ খোঁজো (Br > Cl > COOH > C₂H₅ > CH₃ > H)। দুটি উচ্চ অগ্রাধিকারের গ্রুপ একই পাশে হলে Z (জার্মান zusammen = একসাথে), বিপরীত পাশে E (entgegen = বিপরীত)। cis/trans কেবল একই গ্রুপ থাকলে প্রযোজ্য; E/Z সব ক্ষেত্রে।</div>` : `<div><b>জ্যামিতিক সমাণুতা সম্ভব নয় ✗</b> — একটি কার্বনে দুটি একই গ্রুপ (${GRPS[s1[0] === s1[1] ? s1[0] : s1[2]][0]})। দুটি রূপকে ঘুরিয়ে মেলানো যায় — এরা একই অণু।</div>`);
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W); if (!cam.user) cam.yaw = 0.25 + 0.35 * Math.sin(t * 0.5);
      const w2 = wd ? W / 2 : W, h2 = wd ? H : H / 2, R = Math.max(pair[0][0].R, pair[1][0].R);
      pair.forEach(([m, s], k) => { const c2 = M3.cam(cam); c2.cx = wd ? w2 * (k + 0.5) : W / 2; c2.cy = wd ? H / 2 + 6 : h2 * (k + 0.5) + 4; c2.sc = Math.min(w2, h2 - 40) / 2 / (R + 0.4) * 0.92; c2.D = 40; const r = M3.render(g, m, c2, { mode: 'bs', col, labels: 'hetero', center: [0, 0, 0] });
        const v = netDip(s), mag = Math.hypot(v[0], v[1]); const P = M3.projector(c2, [0, 0, 0]); if (mag > 0.05) { const p0 = P([0, 0, 0]), p1 = P([v[0] * 2.2, v[1] * 2.2, 0]); g.strokeStyle = '#2f9e44'; g.fillStyle = '#2f9e44'; g.lineWidth = 3; g.beginPath(); g.moveTo(p0[0], p0[1]); g.lineTo(p1[0], p1[1]); g.stroke(); const an = Math.atan2(p1[1] - p0[1], p1[0] - p0[0]); g.beginPath(); g.moveTo(p1[0], p1[1]); g.lineTo(p1[0] - 9 * Math.cos(an - 0.4), p1[1] - 9 * Math.sin(an - 0.4)); g.lineTo(p1[0] - 9 * Math.cos(an + 0.4), p1[1] - 9 * Math.sin(an + 0.4)); g.fill(); g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText('μ', p1[0] + 4, p1[1]); }
        else { g.fillStyle = '#2f9e44'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('μ ≈ ০', c2.cx, c2.cy + c2.sc * 2.2); }
        void r; g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(labs[k], c2.cx, wd ? 18 : h2 * k + 16); });
      g.strokeStyle = col.mu; g.setLineDash([4, 4]); g.lineWidth = 1; g.beginPath(); if (wd) { g.moveTo(W / 2, 28); g.lineTo(W / 2, H - 8); } else { g.moveTo(10, H / 2); g.lineTo(W - 10, H / 2); } g.stroke(); g.setLineDash([]);
    };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'md', v => { md = v; q('[data-exw]').style.display = v === 'ex' ? '' : 'none'; q('[data-bdw]').style.display = v === 'bd' ? 'flex' : 'none'; rebuild(); });
    X.onSeg(el, 'ex', v => { ex = +v; rebuild(); });
    el.querySelectorAll('[data-g]').forEach(s => { s.value = G[s.dataset.g]; s.onchange = () => { G[s.dataset.g] = s.value; rebuild(); }; });
    rebuild(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৬.৩–২.৬.৪ আলোক সমাণুতা: অপ্রতিসম কার্বন, এনানসিওমার ও R/S ======================= */
/* each: tree list, priorities for [idx of 4 neighbours of C0 in order of priority 1..3] (4th = H), name */
const CHI = {
  lactic: { nm: 'ল্যাকটিক এসিড', L: [['C', -1], ['O', 0], ['C', 0], ['C', 0], ['O', 3, 2], ['O', 3]], pr: [1, 3, 2], lab: ['OH', 'COOH', 'CH₃'], rot: [3.8, 'L-(+)-ল্যাকটিক এসিড = (S); পেশিতে তৈরি হয়'], f: 'CH₃CH(OH)COOH' },
  butanol: { nm: 'বিউটান-২-অল', L: [['C', -1], ['O', 0], ['C', 0], ['C', 0], ['C', 3]], pr: [1, 3, 2], lab: ['OH', 'C₂H₅', 'CH₃'], rot: [13.5, '(S)-(+)-বিউটান-২-অল'], f: 'CH₃CH(OH)CH₂CH₃' },
  chlorobutane: { nm: '২-ক্লোরোবিউটেন', L: [['C', -1], ['Cl', 0], ['C', 0], ['C', 0], ['C', 3]], pr: [1, 3, 2], lab: ['Cl', 'C₂H₅', 'CH₃'], rot: [36, '(S)-(+)-২-ক্লোরোবিউটেন'], f: 'CH₃CHClCH₂CH₃' },
  glyceraldehyde: { nm: 'গ্লিসারালডিহাইড', L: [['C', -1], ['O', 0], ['C', 0], ['C', 0], ['O', 2, 2], ['O', 3]], pr: [1, 2, 3], lab: ['OH', 'CHO', 'CH₂OH'], rot: [8.7, 'D-(+)-গ্লিসারালডিহাইড = (R)'], f: 'HOCH₂CH(OH)CHO' }
};
const chir = (m, pr) => { const c0 = m.a[0].p, v = pr.map(i => sub(m.a[i].p, c0)); const s = dot(v[0], cross(v[1], v[2])); return s < 0 ? 'R' : 'S'; };
V.p2c2_chiral = {
  t: 'আলোক সমাণুতা: অপ্রতিসম (কাইরাল) কার্বন, দর্পণ প্রতিবিম্ব এনানসিওমার, অধিস্থাপনের চেষ্টা এবং CIP নিয়মে R/S নির্ধারণ (ত্রিমাত্রিক)', k: ['3d', 'int', 'anim'],
  cap: 'যৌগ বেছে নাও। বাঁয়ে অণু, মাঝে নীল দর্পণ, ডানে তার দর্পণ প্রতিবিম্ব; অপ্রতিসম কার্বনের চারটি ভিন্ন গ্রুপ অগ্রাধিকার অনুযায়ী নম্বর পায় (১ সর্বোচ্চ … ৪ = H)। "অধিস্থাপনের চেষ্টা" চাপলে প্রতিবিম্বটি ঘুরে এসে মূল অণুর উপর বসে — দুটি গ্রুপ মেলে, কিন্তু বাকি দুটি অদলবদল থেকে যায় (লাল বৃত্ত): অধিস্থাপন অসম্ভব — এরাই এনানসিওমার। "R/S দেখাও" চাপলে অণুটি এমনভাবে ঘোরে যাতে H (৪) পেছনে যায়, আর ১→২→৩ ঘড়ির কাঁটার দিকে হলে R, বিপরীতে হলে S।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('cp', Object.entries(CHI).map(([k, v]) => [k, v.nm]), 'lactic')}</div>${X.cv('আলোক সমাণুতা')}<div class="ctl" style="flex-wrap:wrap"><button class="btn sm primary" data-sup>অধিস্থাপনের চেষ্টা</button><button class="btn sm" data-rs>R/S দেখাও</button><button class="btn sm" data-rst>পুনরায়</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 480;
    let L = X.fit(c, hf), cp = 'lactic', m1, m2, hIdx, mode = 0, ph = 0, t = 0, q0, q1, rsQ = null; const cam = M3.cam({ yaw: 0.15, pitch: 0.25 });
    C4.drag3d(c, cam, () => A.draw());
    const build = () => { const d = CHI[cp]; m1 = M3.relax(M3.tree(d.L, { name: d.nm })); m1.a.forEach(a => { a.p = sub(a.p, m1.a[0].p); }); M3.center(m1); hIdx = M3.nbrs(m1, 0).find(j => m1.a[j].el === 'H'); m2 = mirrorX(m1); m2.c = [0, 0, 0]; m1.c = [0, 0, 0];
      // rotation aligning mirror's H and priority-1 onto the original's
      const Rm = alignMat(m2.a[hIdx].p, m2.a[d.pr[0]].p, m1.a[hIdx].p, m1.a[d.pr[0]].p); q0 = [1, 0, 0, 0]; q1 = Q.fromMat(Rm);
      const c1 = chir(m1, d.pr), c2 = chir(m2, d.pr);
      // rotation to put H away from viewer (−z) for R/S view
      const hv = norm(m1.a[hIdx].p), p1 = m1.a[d.pr[0]].p; rsQ = Q.fromMat(alignMat(hv, p1, [0, 0, -1], [0, 1, 0]));
      mode = 0; ph = 0;
      out.innerHTML = `<div><b>${d.nm}</b> (${d.f}): অপ্রতিসম কার্বনে চারটি ভিন্ন গ্রুপ — ${d.lab.map((l, i) => `${bn(i + 1)}) ${l}`).join(', ')}, ৪) H।</div><div class="small" style="margin-top:4px">বাঁয়ের অণু <b>(${c1})</b>, ডানের প্রতিবিম্ব <b>(${c2})</b>। আপেক্ষিক আবর্তন: একটি ${d.rot[0] ? `+${bn(d.rot[0])}°` : ''}, অন্যটি −${bn(d.rot[0])}° (সমান মান, বিপরীত দিক)। ${d.rot[1]}। অন্য সব ভৌত ধর্ম (গলনাঙ্ক, স্ফুটনাঙ্ক, দ্রাব্যতা) অভিন্ন।</div>`; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), d = CHI[cp];
      if (!cam.user && mode === 0) cam.yaw = 0.15 + 0.5 * Math.sin(t * 0.4);
      const sc = Math.min(wd ? W / 2 : W, wd ? H : H / 2) / 2 / (m1.R + 0.5) * 0.9;
      const labelPr = (S, mm, cx2, cy2) => { d.pr.forEach((ai, k) => { const p = S[ai]; g.fillStyle = ['#c0392b', '#e67e22', '#2d6fd6'][k]; g.beginPath(); g.arc(p[0] + 12, p[1] - 12, 8, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(k + 1), p[0] + 12, p[1] - 8.5); }); const p = S[hIdx]; g.fillStyle = '#7f8c8d'; g.beginPath(); g.arc(p[0] + 10, p[1] - 10, 7, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 9px ${col.font}`; g.fillText('৪', p[0] + 10, p[1] - 7); void mm; void cx2; void cy2; };
      if (mode === 2) { // R/S view of the original
        const k = ease(Math.min(1, ph)), qq = Q.slerp([1, 0, 0, 0], rsQ, k), mm = M3.clone(m1); mm.a.forEach(a => { a.p = Q.rot(qq, a.p); }); M3.offsets(mm); const c2 = M3.cam({ yaw: 0, pitch: 0, sc: sc * 1.2, cx: W / 2, cy: H / 2 + 8, D: 30 }); const r = M3.render(g, mm, c2, { mode: 'bs', col, labels: 'hetero', center: [0, 0, 0] }); labelPr(r.S);
        if (k > 0.98) { const pts = d.pr.map(i => r.S[i]); const cx2 = (pts[0][0] + pts[1][0] + pts[2][0]) / 3, cy2 = (pts[0][1] + pts[1][1] + pts[2][1]) / 3, rad = 0.75 * Math.max(...pts.map(p => Math.hypot(p[0] - cx2, p[1] - cy2))); const a = pts.map(p => Math.atan2(p[1] - cy2, p[0] - cx2)); const cw = chir(m1, d.pr) === 'R'; g.strokeStyle = cw ? '#c0392b' : '#2d6fd6'; g.lineWidth = 3; g.beginPath(); const a0 = a[0], a2 = cw ? (a[2] > a0 ? a[2] : a[2] + 2 * Math.PI) : (a[2] < a0 ? a[2] : a[2] - 2 * Math.PI); g.arc(cx2, cy2, rad, a0, a2, !cw); g.stroke(); const ex = cx2 + rad * Math.cos(a2), ey = cy2 + rad * Math.sin(a2), tg = a2 + (cw ? Math.PI / 2 : -Math.PI / 2); g.fillStyle = g.strokeStyle; g.beginPath(); g.moveTo(ex + 9 * Math.cos(tg), ey + 9 * Math.sin(tg)); g.lineTo(ex + 7 * Math.cos(tg + 2.4), ey + 7 * Math.sin(tg + 2.4)); g.lineTo(ex + 7 * Math.cos(tg - 2.4), ey + 7 * Math.sin(tg - 2.4)); g.fill(); g.font = `bold 26px ${col.font}`; g.textAlign = 'center'; g.fillText(cw ? 'R' : 'S', W - 40, 44); g.font = `11px ${col.font}`; g.fillStyle = col.fg; g.fillText(cw ? 'ঘড়ির কাঁটার দিকে → R (rectus)' : 'ঘড়ির কাঁটার বিপরীতে → S (sinister)', W / 2, H - 10); }
        g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('H (৪) দর্শক থেকে দূরে (পেছনে)', W / 2, 16); return;
      }
      const w2 = wd ? W / 2 : W, h2 = wd ? H : H / 2;
      const ca = M3.cam(cam); ca.sc = sc; ca.cx = wd ? w2 * 0.5 : W / 2; ca.cy = wd ? H / 2 + 8 : h2 * 0.5 + 6; ca.D = 30;
      let mm2 = m2, cb = M3.cam(cam); cb.sc = sc; cb.D = 30; cb.yaw = -cam.yaw; cb.cx = wd ? w2 * 1.5 : W / 2; cb.cy = wd ? H / 2 + 8 : h2 * 1.5 + 6;
      if (mode === 1) { const k = ease(Math.min(1, ph)), qq = Q.slerp(q0, q1, k); mm2 = M3.clone(m2); mm2.a.forEach(a => { a.p = Q.rot(qq, a.p); }); M3.offsets(mm2); cb = M3.cam(cam); cb.sc = sc; cb.D = 30; cb.yaw = cam.yaw * k + (-cam.yaw) * (1 - k); cb.cx = ca.cx + ((wd ? w2 * 1.5 : W / 2) - ca.cx) * (1 - k); cb.cy = ca.cy + ((wd ? H / 2 + 8 : h2 * 1.5 + 6) - ca.cy) * (1 - k); }
      const r1 = M3.render(g, m1, ca, { mode: 'bs', col, labels: 'hetero', center: [0, 0, 0] }); labelPr(r1.S);
      if (mode !== 1 || ph < 1) { g.strokeStyle = '#5dade2'; g.lineWidth = 3; g.globalAlpha = mode === 1 ? 1 - Math.min(1, ph) : 1; g.beginPath(); if (wd) { g.moveTo(W / 2, 30); g.lineTo(W / 2, H - 10); } else { g.moveTo(10, H / 2); g.lineTo(W - 10, H / 2); } g.stroke(); g.globalAlpha = 1; }
      const alpha = {}; if (mode === 1) mm2.a.forEach((a, i) => { alpha[i] = 0.55; });
      const r2 = M3.render(g, mm2, cb, { mode: 'bs', col, labels: 'hetero', center: [0, 0, 0], alpha }); if (mode !== 1) labelPr(r2.S);
      if (mode === 1 && ph >= 1) { d.pr.slice(1).forEach(ai => { const p1 = r1.S[ai], p2 = r2.S[ai]; [p1, p2].forEach(p => { g.strokeStyle = '#e74c3c'; g.lineWidth = 2.5; g.beginPath(); g.arc(p[0], p[1], 16, 0, 7); g.stroke(); }); }); g.fillStyle = '#e74c3c'; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(`H ও ${d.lab[0]} মেলে, কিন্তু ${d.lab[1]} ও ${d.lab[2]} অদলবদল — অধিস্থাপন অসম্ভব!`, W / 2, H - 10); }
      if (mode === 0) { g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`মূল (${chir(m1, d.pr)})`, ca.cx, wd ? 18 : 14); g.fillText(`দর্পণ প্রতিবিম্ব (${chir(m2, d.pr)})`, wd ? w2 * 1.5 : W / 2, wd ? 18 : h2 + 14); }
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (mode) ph = Math.min(1.2, ph + dt * 0.6); } draw(); }, { paused: false });
    X.onSeg(el, 'cp', v => { cp = v; build(); });
    q('[data-sup]').onclick = () => { mode = 1; ph = 0; cam.user = false; cam.yaw = 0.2; };
    q('[data-rs]').onclick = () => { mode = 2; ph = 0; };
    q('[data-rst]').onclick = () => { mode = 0; ph = 0; };
    build(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৬.৫ পোলারিমিটার ======================= */
const SMP = { suc: ['সুক্রোজ', 66.5], glu: ['D-গ্লুকোজ (সাম্যাবস্থা)', 52.7], fru: ['D-ফ্রুক্টোজ', -92.4], sb: ['(S)-বিউটান-২-অল', 13.5], rb: ['(R)-বিউটান-২-অল', -13.5], rac: ['রেসেমিক মিশ্রণ (±)', 0], wat: ['পানি (আলোক নিষ্ক্রিয়)', 0] };
V.p2c2_polarimeter = {
  t: 'পোলারিমিটার: সমতল সমবর্তিত আলোর তলের আবর্তন — নমুনা, ঘনত্ব ও নলের দৈর্ঘ্য বদলে পর্যবেক্ষিত আবর্তন α মাপো ও আপেক্ষিক আবর্তন [α] নির্ণয় করো', k: ['anim', 'int', 'calc', '3d'],
  cap: 'বাঁয়ে সোডিয়াম বাতির (৫৮৯ nm) অসমবর্তিত আলো সব দিকে কাঁপে; পোলারাইজার (নিকল প্রিজম) পার হলে কেবল একটি তলে কাঁপে। নমুনা নলে আলোক সক্রিয় অণু থাকলে কম্পন তল ধীরে ধীরে ঘোরে — ঘূর্ণন নলের দৈর্ঘ্য ও ঘনত্বের সমানুপাতিক। শেষে বিশ্লেষক (অ্যানালাইজার) ঘুরিয়ে আলো সবচেয়ে উজ্জ্বল হলে তার কোণই পর্যবেক্ষিত আবর্তন α। ডানাবর্তী (+, ঘড়ির কাঁটার দিকে) বা বামাবর্তী (−)। রেসেমিক মিশ্রণে দুই এনানসিওমারের প্রভাব কাটাকাটি — α = ০।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap"><select data-s style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--sf);color:var(--fg);font:inherit">${Object.entries(SMP).map(([k, v]) => `<option value="${k}">${v[0]}</option>`).join('')}</select></div>${X.cv('পোলারিমিটার')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:130px">ঘনত্ব c = <b data-cv></b> g mL⁻¹<input type="range" min="0.02" max="0.5" step="0.01" value="0.2" data-c></label><label class="small" style="flex:1;min-width:130px">নলের দৈর্ঘ্য l = <b data-lv></b> dm<input type="range" min="0.5" max="2" step="0.5" value="1" data-l></label><label class="small" style="flex:1;min-width:130px">বিশ্লেষক কোণ = <b data-av></b>°<input type="range" min="-90" max="90" step="0.5" value="0" data-a></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 360;
    let L = X.fit(c, hf), sm = 'suc', cc = 0.2, ll = 1, an = 0, t = 0;
    const alpha = () => SMP[sm][1] * ll * cc;
    const wrap = a => { let x = ((a + 90) % 180 + 180) % 180 - 90; return x; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const a = alpha(), cy = H * 0.45, x0 = 20, x1 = W - 20;
      const xs = { lamp: x0 + 18, pol: x0 + (x1 - x0) * 0.18, t0: x0 + (x1 - x0) * 0.28, t1: x0 + (x1 - x0) * (0.28 + 0.38 * ll / 2), ana: x0 + (x1 - x0) * 0.8, eye: x1 - 10 };
      // lamp
      const gl = g.createRadialGradient(xs.lamp, cy, 2, xs.lamp, cy, 26); gl.addColorStop(0, '#fff7c2'); gl.addColorStop(1, 'rgba(255,200,40,0)'); g.fillStyle = gl; g.beginPath(); g.arc(xs.lamp, cy, 26, 0, 7); g.fill(); M3.sphere(g, xs.lamp, cy, 9, '#f5b301', '#fff4b0');
      // tube
      g.fillStyle = sm === 'wat' ? 'rgba(160,200,255,.25)' : 'rgba(255,220,150,.35)'; rr(g, xs.t0, cy - 18, xs.t1 - xs.t0, 36, 8); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.4; g.stroke(); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(`নমুনা নল (${bn(ll)} dm)`, (xs.t0 + xs.t1) / 2, cy + 32);
      // polarizer & analyzer discs (perspective ellipses with slit)
      const disc = (x, ang, lab) => { g.fillStyle = 'rgba(120,140,170,.35)'; g.strokeStyle = col.fg; g.beginPath(); g.ellipse(x, cy, 8, 30, 0, 0, 7); g.fill(); g.stroke(); const r = ang * Math.PI / 180; g.strokeStyle = '#2d6fd6'; g.lineWidth = 3; g.beginPath(); g.moveTo(x - 8 * Math.sin(r) * 0.3, cy - 26 * Math.cos(r)); g.lineTo(x + 8 * Math.sin(r) * 0.3, cy + 26 * Math.cos(r)); g.stroke(); g.lineWidth = 1; g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.fillText(lab, x, cy + 46); };
      disc(xs.pol, 0, 'পোলারাইজার'); disc(xs.ana, an, 'বিশ্লেষক');
      // wave: oscillation direction at position x: angle phi(x)
      const phi = x => x < xs.pol ? null : x < xs.t0 ? 0 : x < xs.t1 ? a * (x - xs.t0) / (xs.t1 - xs.t0) : a;
      const I = Math.pow(Math.cos((an - a) * Math.PI / 180), 2);
      for (let x = x0 + 30; x < xs.eye - 14; x += 3) { const p = phi(x); const ph2 = Math.sin(x / 7 - t * 8); if (p === null) { for (let k = 0; k < 3; k++) { const ang = k * Math.PI / 3 + t * 0.7; g.strokeStyle = 'rgba(245,179,1,.35)'; g.beginPath(); g.moveTo(x, cy); g.lineTo(x + Math.sin(ang) * ph2 * 3, cy - Math.cos(ang) * ph2 * 18); g.stroke(); } continue; } const amp = x > xs.ana ? Math.sqrt(I) : 1, r = p * Math.PI / 180; g.strokeStyle = x > xs.ana ? `rgba(245,179,1,${0.3 + 0.7 * I})` : '#f5b301'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x, cy); g.lineTo(x + Math.sin(r) * ph2 * 6 * amp, cy - Math.cos(r) * ph2 * 18 * amp); g.stroke(); }
      // eye / detector
      const eg = g.createRadialGradient(xs.eye, cy, 1, xs.eye, cy, 20); eg.addColorStop(0, `rgba(255,240,150,${I})`); eg.addColorStop(1, 'rgba(255,240,150,0)'); g.fillStyle = eg; g.beginPath(); g.arc(xs.eye, cy, 20, 0, 7); g.fill(); g.strokeStyle = col.fg; g.beginPath(); g.arc(xs.eye, cy, 9, 0, 7); g.stroke(); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.fillText(`উজ্জ্বলতা ${bn(Math.round(I * 100))}%`, xs.eye - 10, cy - 30);
      // dial
      const dx = W / 2, dy = H - 46, dr = 34; g.strokeStyle = col.mu; g.lineWidth = 1; g.beginPath(); g.arc(dx, dy, dr, Math.PI, 2 * Math.PI); g.stroke(); for (let k = -90; k <= 90; k += 15) { const r = (k - 90) * Math.PI / 180; g.beginPath(); g.moveTo(dx + Math.cos(r) * dr, dy + Math.sin(r) * dr); g.lineTo(dx + Math.cos(r) * (dr - 5), dy + Math.sin(r) * (dr - 5)); g.stroke(); }
      const nd = (ang, cl, w) => { const r = (ang - 90) * Math.PI / 180; g.strokeStyle = cl; g.lineWidth = w; g.beginPath(); g.moveTo(dx, dy); g.lineTo(dx + Math.cos(r) * (dr - 2), dy + Math.sin(r) * (dr - 2)); g.stroke(); };
      nd(an, '#2d6fd6', 2.5); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`বিশ্লেষক ${bn(an.toFixed(1))}°`, dx, dy + 14);
    };
    const info = () => { const a = alpha(), I = Math.pow(Math.cos((an - a) * Math.PI / 180), 2); q('[data-cv]').textContent = bn(cc.toFixed(2)); q('[data-lv]').textContent = bn(ll); q('[data-av]').textContent = bn(an.toFixed(1)); const found = I > 0.995; out.innerHTML = `<div>${found ? `<b style="color:var(--ok)">✓ সর্বোচ্চ উজ্জ্বলতা!</b> পর্যবেক্ষিত আবর্তন α = ${bn(an.toFixed(1))}°` : 'বিশ্লেষক ঘুরিয়ে সবচেয়ে উজ্জ্বল অবস্থান খোঁজো।'}</div>${found ? TXB(`[\\alpha]_D^{20} = \\dfrac{\\alpha}{l\\,c} = \\dfrac{${an.toFixed(1)}}{${ll}\\times${cc.toFixed(2)}} = ${(an / (ll * cc)).toFixed(1)}^\\circ`) : ''}<div class="small">${SMP[sm][1] === 0 ? (sm === 'rac' ? 'রেসেমিক মিশ্রণে সমান পরিমাণ (+) ও (−) এনানসিওমার — আবর্তন বাতিল হয়ে যায় (বাহ্যিক প্রশমন)।' : 'পানি আলোক নিষ্ক্রিয় — এর অণুতে অপ্রতিসম কেন্দ্র নেই।') : `${SMP[sm][0]} এর প্রকৃত [α]D = ${SMP[sm][1] > 0 ? '+' : ''}${bn(SMP[sm][1])}° — ${SMP[sm][1] > 0 ? 'ডানাবর্তী (d বা +)' : 'বামাবর্তী (l বা −)'}।`} সূত্র: α = [α] × l (dm) × c (g mL⁻¹)।</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    q('[data-s]').onchange = e => { sm = e.target.value; info(); };
    q('[data-c]').oninput = e => { cc = +e.target.value; info(); }; q('[data-l]').oninput = e => { ll = +e.target.value; info(); }; q('[data-a]').oninput = e => { an = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৬.৬ অপ্রতিসম কার্বনের সংখ্যা ও স্টেরিও সমাণু (২ⁿ, মেসো) — ফিশার অভিক্ষেপ ======================= */
/* centres: [left/right substituent label, priority map {up, down, X, H}] ; Fischer: top, centres (X on right if bit 0), bottom */
const FS = {
  but2ol: { nm: 'বিউটান-২-অল', top: 'CH₃', bot: 'C₂H₅', X: ['OH'], pr: [{ X: 1, down: 2, up: 3 }], meso: false, n: 1 },
  bromo: { nm: '৩-ব্রোমোবিউটান-২-অল', top: 'CH₃', bot: 'CH₃', X: ['OH', 'Br'], pr: [{ X: 1, down: 2, up: 3 }, { X: 1, up: 2, down: 3 }], meso: false, n: 2 },
  tart: { nm: 'টারটারিক এসিড', top: 'COOH', bot: 'COOH', X: ['OH', 'OH'], pr: [{ X: 1, up: 2, down: 3 }, { X: 1, down: 2, up: 3 }], meso: true, n: 2 },
  glucose: { nm: 'D-গ্লুকোজ (মুক্ত শিকল)', top: 'CHO', bot: 'CH₂OH', X: ['OH', 'OH', 'OH', 'OH'], side: [1, 0, 1, 1], pr: [{ X: 1, up: 2, down: 3 }, { X: 1, up: 2, down: 3 }, { X: 1, up: 2, down: 3 }, { X: 1, up: 2, down: 3 }], n: 4 }
};
const rsOf = (pr, xRight) => { const pos = { up: [0, -1], down: [0, 1], X: xRight ? [1, 0] : [-1, 0] }; const byP = {}; Object.entries(pr).forEach(([k, v]) => { byP[v] = pos[k]; }); const p1 = byP[1], p2 = byP[2], p3 = byP[3]; const cr = (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0]); const cw = cr > 0; return cw ? 'S' : 'R'; /* H on horizontal → reversed */ };
V.p2c2_stereoCount = {
  t: 'অপ্রতিসম কার্বনের সংখ্যা ও স্টেরিও সমাণুর সংখ্যা: ২ⁿ নিয়ম, এনানসিওমার ও ডায়াস্টেরিওমার সম্পর্ক এবং মেসো যৌগের ব্যতিক্রম — ফিশার অভিক্ষেপে', k: ['int', '2d'],
  cap: 'যৌগ বেছে নাও। প্রতিটি সম্ভাব্য স্টেরিও সমাণু ফিশার অভিক্ষেপে আঁকা হয় (উল্লম্ব রেখা পেছনে, অনুভূমিক রেখা সামনে; ছেদবিন্দুতে অপ্রতিসম কার্বন, তারকা * চিহ্নিত) এবং প্রতিটি কেন্দ্রের R/S লেখা থাকে। নীল বন্ধনী = এনানসিওমার জোড়া (দর্পণ প্রতিবিম্ব), সবুজ বন্ধনী = আসলে একই যৌগ (মেসো); ভিন্ন জোড়ার সদস্যরা পরস্পরের ডায়াস্টেরিওমার (দর্পণ প্রতিবিম্ব নয় এমন স্টেরিও সমাণু)। টারটারিক এসিডে দুটি "সমাণু" আসলে একই — অণুর মাঝে অভ্যন্তরীণ প্রতিসাম্য তল (মেসো), তাই ২² = ৪ এর বদলে ৩টি। গ্লুকোজে ৪টি কেন্দ্র ⇒ ২⁴ = ১৬টি স্টেরিও সমাণু।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('cp', Object.entries(FS).map(([k, v]) => [k, v.nm.split(' ')[0]]), 'tart')}</div>${X.cv('স্টেরিও সমাণু গণনা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 320 : 600;
    let L = X.fit(c, hf), cp = 'tart';
    const fischer = (g, x, y, s, d, bits, col, title) => {
      const n = d.n, top = y, gap = s; g.strokeStyle = col.fg; g.lineWidth = 1.8; g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center';
      g.fillText(d.top, x, top); g.beginPath(); g.moveTo(x, top + 6); g.lineTo(x, top + gap * n + gap * 0.6); g.stroke();
      for (let i = 0; i < n; i++) { const cy = top + gap * (i + 0.8), right = d.side ? d.side[i] : bits[i]; g.beginPath(); g.moveTo(x - s * 0.9, cy); g.lineTo(x + s * 0.9, cy); g.stroke(); g.font = `bold 11px ${col.font}`; g.textAlign = right ? 'left' : 'right'; g.fillStyle = d.X[i] === 'Br' ? '#a0522d' : '#cc2418'; g.fillText(d.X[i], right ? x + s * 0.95 : x - s * 0.95, cy + 4); g.fillStyle = col.mu; g.textAlign = right ? 'right' : 'left'; g.fillText('H', right ? x - s * 0.95 : x + s * 0.95, cy + 4); g.fillStyle = '#8e44ad'; g.textAlign = 'left'; g.font = `bold 10px ${col.font}`; g.fillText('*', x + 3, cy - 4); const rs = rsOf(d.pr[i], right); g.fillStyle = rs === 'R' ? '#c0392b' : '#2d6fd6'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(rs, x + 5, cy + 12); }
      g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(d.bot, x, top + gap * (n + 0.6) + 14); if (title) { g.font = `9.5px ${col.font}`; g.fillStyle = col.mu; g.fillText(title, x, top + gap * (n + 0.6) + 30); }
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const d = FS[cp], wd = wide(W);
      if (d.n === 4) { const s = Math.min(46, (H - 70) / 5.6); fischer(g, W / 2, 26, s, d, null, col, 'D-গ্লুকোজ: (2R,3S,4R,5R)'); g.fillStyle = col.acc; g.font = `bold 14px ${col.font}`; g.textAlign = wd ? 'left' : 'center'; g.fillText('n = ৪ ⇒ ২⁴ = ১৬টি স্টেরিও সমাণু', wd ? W * 0.62 : W / 2, wd ? H / 2 : H - 10); return; }
      const combos = d.n === 1 ? [[1], [0]] : [[1, 1], [0, 0], [1, 0], [0, 1]];
      const cols = wd ? combos.length : 2, rows = Math.ceil(combos.length / cols), cw = W / cols, s = Math.min(40, (H / rows - 100) / (d.n + 1.2));
      const P = combos.map((b, i) => [cw * (i % cols + 0.5), 24 + Math.floor(i / cols) * (H / rows)]);
      const key = b => b.join(''), same = (a, b) => d.meso && key(a) === key(b.slice().reverse().map(v => v)) && false;
      void same;
      // relationships
      const enant = (a, b) => a.every((v, i) => v !== b[i]);
      const isMeso = b => d.meso && b[0] === b[1];
      for (let pi = 0; pi + 1 < combos.length; pi += 2) { const i = pi, j = pi + 1, same2 = isMeso(combos[i]); const [x1, y1] = P[i], [x2, y2] = P[j], yb = Math.max(y1, y2) + s * (d.n + 0.6) + (d.n === 1 ? 34 : 40); g.strokeStyle = same2 ? '#2f9e44' : '#2d6fd6'; g.lineWidth = 2; g.beginPath(); g.moveTo(x1, yb - 6); g.lineTo(x1, yb); g.lineTo(x2, yb); g.lineTo(x2, yb - 6); g.stroke(); g.fillStyle = g.strokeStyle; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(same2 ? 'একই যৌগ (মেসো)' : 'এনানসিওমার জোড়া', (x1 + x2) / 2, yb + 13); }
      if (combos.length === 4) { g.fillStyle = '#e67e22'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('বাম জোড়ার যেকোনো সদস্য ↔ ডান জোড়ার যেকোনো সদস্য = ডায়াস্টেরিওমার', W / 2, H - 6); if (wd) { g.strokeStyle = col.mu; g.setLineDash([4, 4]); g.beginPath(); g.moveTo(W / 2, 14); g.lineTo(W / 2, H - 22); g.stroke(); g.setLineDash([]); } }
      combos.forEach((b, i) => { const t2 = isMeso(b) ? 'মেসো (অভ্যন্তরীণ প্রতিসাম্য তল)' : ''; fischer(g, P[i][0], P[i][1], s, d, b, col, t2); if (isMeso(b)) { g.strokeStyle = '#2f9e44'; g.setLineDash([4, 3]); g.lineWidth = 1.5; const ym = P[i][1] + s * (0.8 + 0.5); g.beginPath(); g.moveTo(P[i][0] - s * 1.4, ym); g.lineTo(P[i][0] + s * 1.4, ym); g.stroke(); g.setLineDash([]); } });
    };
    const info = () => { const d = FS[cp]; const n = d.n, tot = Math.pow(2, n), act = d.meso ? 3 : tot; out.innerHTML = `<div><b>${d.nm}</b>: অপ্রতিসম কার্বন n = ${bn(n)} ⇒ সর্বোচ্চ ২${n === 1 ? '¹' : n === 2 ? '²' : '⁴'} = ${bn(tot)}টি স্টেরিও সমাণু${d.meso ? `; কিন্তু একটি মেসো রূপ থাকায় প্রকৃত সংখ্যা ${bn(act)} (দুটি আলোক সক্রিয় এনানসিওমার + একটি আলোক নিষ্ক্রিয় মেসো)` : ''}।</div><div class="small" style="margin-top:4px">${d.meso ? 'মেসো টারটারিক এসিডে দুই কেন্দ্রের আবর্তন সমান ও বিপরীত (R,S) — অণুর ভেতরেই প্রশমিত (অভ্যন্তরীণ প্রশমন), তাই অপ্রতিসম কার্বন থাকা সত্ত্বেও আলোক নিষ্ক্রিয়। রেসেমিক মিশ্রণ (বাহ্যিক প্রশমন) থেকে এটি আলাদা — রেসেমিক মিশ্রণ বিভাজন করা যায়, মেসো যায় না।' : n === 2 ? 'দুই কেন্দ্রের সব সম্ভাব্য বিন্যাস: (R,R)–(S,S) এক জোড়া এনানসিওমার, (R,S)–(S,R) আরেক জোড়া; এক জোড়ার সদস্য অন্য জোড়ার সদস্যের ডায়াস্টেরিওমার (ভিন্ন ভৌত ধর্ম)।' : n === 1 ? 'একটি অপ্রতিসম কার্বন ⇒ দুটি এনানসিওমার।' : 'বাস্তবে প্রকৃতিতে প্রধানত D-গ্লুকোজ পাওয়া যায়; বাকি ১৫টির মধ্যে D-ম্যানোজ, D-গ্যালাক্টোজ প্রভৃতি এর ডায়াস্টেরিওমার।'}</div>`; };
    X.onSeg(el, 'cp', v => { cp = v; info(); draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ২.৭ সংকেত থেকে গাঠনিক সমাণু গণনা ======================= */
const IS = {
  'C₄H₁₀': [['বিউটেন', 'CH₃CH₂CH₂CH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2]]], ['২-মিথাইলপ্রোপেন', '(CH₃)₂CHCH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 1]]]],
  'C₅H₁₂': [['পেন্টেন', 'CH₃(CH₂)₃CH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 3]]], ['২-মিথাইলবিউটেন', '(CH₃)₂CHCH₂CH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 1]]], ['২,২-ডাইমিথাইলপ্রোপেন', 'C(CH₃)₄', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 1], ['C', 1]]]],
  'C₆H₁₄': [['হেক্সেন', 'CH₃(CH₂)₄CH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 3], ['C', 4]]], ['২-মিথাইলপেন্টেন', '(CH₃)₂CH(CH₂)₂CH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 3], ['C', 1]]], ['৩-মিথাইলপেন্টেন', 'CH₃CH₂CH(CH₃)CH₂CH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 3], ['C', 2]]], ['২,২-ডাইমিথাইলবিউটেন', '(CH₃)₃CCH₂CH₃', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 1], ['C', 1]]], ['২,৩-ডাইমিথাইলবিউটেন', '(CH₃)₂CHCH(CH₃)₂', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 1], ['C', 2]]]],
  'C₃H₇Cl': [['১-ক্লোরোপ্রোপেন', 'CH₃CH₂CH₂Cl', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['Cl', 2]]], ['২-ক্লোরোপ্রোপেন', 'CH₃CHClCH₃', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['Cl', 1]]]],
  'C₄H₉Cl': [['১-ক্লোরোবিউটেন', 'CH₃(CH₂)₂CH₂Cl', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['Cl', 3]]], ['২-ক্লোরোবিউটেন *', 'CH₃CHClCH₂CH₃', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['Cl', 1]]], ['১-ক্লোরো-২-মিথাইলপ্রোপেন', '(CH₃)₂CHCH₂Cl', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 1], ['Cl', 2]]], ['২-ক্লোরো-২-মিথাইলপ্রোপেন', '(CH₃)₃CCl', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 1], ['Cl', 1]]]],
  'C₂H₄Cl₂': [['১,১-ডাইক্লোরোইথেন', 'CH₃CHCl₂', 'অবস্থান', [['C', -1], ['C', 0], ['Cl', 1], ['Cl', 1]]], ['১,২-ডাইক্লোরোইথেন', 'ClCH₂CH₂Cl', 'অবস্থান', [['Cl', -1], ['C', 0], ['C', 1], ['Cl', 2]]]],
  'C₃H₈O': [['প্রোপান-১-অল', 'CH₃CH₂CH₂OH', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['O', 2]]], ['প্রোপান-২-অল', 'CH₃CH(OH)CH₃', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['O', 1]]], ['মিথক্সিইথেন', 'CH₃OCH₂CH₃', 'কার্যকরী মূলক', [['C', -1], ['O', 0], ['C', 1], ['C', 2]]]],
  'C₄H₁₀O': [['বিউটান-১-অল', 'CH₃(CH₂)₃OH', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['O', 3]]], ['বিউটান-২-অল *', 'CH₃CH(OH)CH₂CH₃', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['O', 1]]], ['২-মিথাইলপ্রোপান-১-অল', '(CH₃)₂CHCH₂OH', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 1], ['O', 2]]], ['২-মিথাইলপ্রোপান-২-অল', '(CH₃)₃COH', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 1], ['O', 1]]], ['ইথক্সিইথেন', 'C₂H₅OC₂H₅', 'কার্যকরী মূলক/মেটামার', [['C', -1], ['C', 0], ['O', 1], ['C', 2], ['C', 3]]], ['১-মিথক্সিপ্রোপেন', 'CH₃OCH₂CH₂CH₃', 'কার্যকরী মূলক/মেটামার', [['C', -1], ['O', 0], ['C', 1], ['C', 2], ['C', 3]]], ['২-মিথক্সিপ্রোপেন', 'CH₃OCH(CH₃)₂', 'কার্যকরী মূলক/মেটামার', [['C', -1], ['O', 0], ['C', 1], ['C', 2], ['C', 2]]]],
  'C₃H₆O': [['প্রোপান্যাল', 'CH₃CH₂CHO', 'কার্যকরী মূলক', [['C', -1], ['C', 0], ['C', 1], ['O', 2, 2]]], ['প্রোপানোন', 'CH₃COCH₃', 'কার্যকরী মূলক', [['C', -1], ['C', 0], ['C', 1], ['O', 1, 2]]], ['প্রপ-২-ইন-১-অল', 'CH₂=CHCH₂OH', 'কার্যকরী মূলক', [['C', -1], ['C', 0, 2], ['C', 1], ['O', 2]]], ['মিথক্সিইথিন', 'CH₂=CHOCH₃', 'কার্যকরী মূলক', [['C', -1], ['C', 0, 2], ['O', 1], ['C', 2]]]],
  'C₄H₈': [['বিউট-১-ইন', 'CH₂=CHCH₂CH₃', 'অবস্থান', [['C', -1], ['C', 0, 2], ['C', 1], ['C', 2]]], ['বিউট-২-ইন (cis/trans)', 'CH₃CH=CHCH₃', 'অবস্থান', [['C', -1], ['C', 0], ['C', 1, 2], ['C', 2]]], ['২-মিথাইলপ্রোপিন', '(CH₃)₂C=CH₂', 'শিকল', [['C', -1], ['C', 0, 2], ['C', 1], ['C', 1]]]],
  'C₂H₄O₂': [['ইথানয়িক এসিড', 'CH₃COOH', 'কার্যকরী মূলক', [['C', -1], ['C', 0], ['O', 1, 2], ['O', 1]]], ['মিথাইল মিথানয়েট', 'HCOOCH₃', 'কার্যকরী মূলক', [['O', -1], ['C', 0, 2], ['O', 1], ['C', 2]]], ['২-হাইড্রক্সিইথান্যাল', 'HOCH₂CHO', 'কার্যকরী মূলক', [['O', -1], ['C', 0], ['C', 1], ['O', 2, 2]]]],
  'C₄H₈O₂': [['বিউটানয়িক এসিড', 'CH₃(CH₂)₂COOH', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['O', 3, 2], ['O', 3]]], ['২-মিথাইলপ্রোপানয়িক এসিড', '(CH₃)₂CHCOOH', 'শিকল', [['C', -1], ['C', 0], ['C', 1], ['C', 1], ['O', 2, 2], ['O', 2]]], ['মিথাইল প্রোপানয়েট', 'CH₃CH₂COOCH₃', 'কার্যকরী মূলক/মেটামার', [['C', -1], ['C', 0], ['C', 1], ['O', 2, 2], ['O', 2], ['C', 4]]], ['ইথাইল ইথানয়েট', 'CH₃COOC₂H₅', 'কার্যকরী মূলক/মেটামার', [['C', -1], ['C', 0], ['O', 1, 2], ['O', 1], ['C', 3], ['C', 4]]], ['প্রোপাইল মিথানয়েট', 'HCOOCH₂CH₂CH₃', 'কার্যকরী মূলক/মেটামার', [['O', -1], ['C', 0, 2], ['O', 1], ['C', 2], ['C', 3], ['C', 4]]], ['আইসোপ্রোপাইল মিথানয়েট', 'HCOOCH(CH₃)₂', 'কার্যকরী মূলক/মেটামার', [['O', -1], ['C', 0, 2], ['O', 1], ['C', 2], ['C', 3], ['C', 3]]]]
};
const ISN = { 'C₄H₈': 'অচাক্রিক ৩টি গাঠনিক (+ বিউট-২-ইনের cis ও trans ⇒ ৪টি অ্যালকিন); চাক্রিক সাইক্লোবিউটেন ও মিথাইলসাইক্লোপ্রোপেন ধরলে মোট ৫টি গাঠনিক সমাণু।', 'C₃H₆O': 'স্থিতিশীল অচাক্রিক ৪টি; চাক্রিক (সাইক্লোপ্রোপানল, অক্সিটেন, মিথাইলঅক্সিরেন) ও অস্থিতিশীল ইনল বাদ।', 'C₄H₁₀O': '৪টি অ্যালকোহল + ৩টি ইথার = ৭টি।', 'C₄H₉Cl': '* চিহ্নিত যৌগে অপ্রতিসম কার্বন — আলোক সমাণু আছে।', 'C₂H₄O₂': 'স্থিতিশীল অচাক্রিক ৩টি; ইনল-ধরনের অস্থিতিশীল রূপ বাদ।' };
const TCOL = { 'শিকল': '#2d6fd6', 'অবস্থান': '#2f9e44', 'কার্যকরী মূলক': '#c0392b', 'কার্যকরী মূলক/মেটামার': '#8e44ad' };
V.p2c2_isoCount = {
  t: 'আণবিক সংকেত থেকে গাঠনিক সমাণু নির্ণয়: অ্যালকেন, হ্যালাইড, অ্যালকোহল-ইথার, কার্বনিল, অ্যালকিন ও এসিড-এস্টারের সব সমাণু — নাম, ধরন ও ত্রিমাত্রিক মডেল', k: ['3d', 'int'],
  cap: 'আণবিক সংকেত বেছে নাও — সেই সংকেতের সব (অচাক্রিক) গাঠনিক সমাণু কার্ড আকারে আসে, প্রতিটিতে সংক্ষিপ্ত গাঠনিক সংকেত, IUPAC নাম ও সমাণুতার ধরন (রঙিন ব্যাজ)। যেকোনো কার্ডে চাপ দিলে উপরে তার ত্রিমাত্রিক মডেল আসে। পদ্ধতিগত গণনার কৌশল: (১) দীর্ঘতম শিকল থেকে শুরু করে প্রতিবার শিকল এক কার্বন ছোট করে শাখা বসাও; (২) প্রতিটি কঙ্কালে কার্যকরী মূলক/বহুবন্ধনের সব অসমতুল্য অবস্থান বসাও; (৩) সম্ভাব্য অন্য কার্যকরী মূলক শ্রেণি (অ্যালকোহল ↔ ইথার, অ্যালডিহাইড ↔ কিটোন, এসিড ↔ এস্টার) যোগ করো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('f', Object.keys(IS).map(k => [k, k]), 'C₄H₁₀O')}</div>${X.cv('সমাণু', 230)}<div data-cards style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin:8px 0"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), cards = el.querySelector('[data-cards]');
    let L = X.fit(c, () => 230), f = 'C₄H₁₀O', sel = 0, m = null, t = 0; const cam = M3.cam({ yaw: 0.3, pitch: 0.35 });
    C4.drag3d(c, cam, () => A.draw());
    const choose = i => { sel = i; const it = IS[f][i]; m = T(it[3], it[0]); cam.user = false; cards.querySelectorAll('[data-i]').forEach(b => { b.style.outline = +b.dataset.i === i ? '2px solid var(--acc)' : 'none'; }); };
    const render = () => { const L2 = IS[f]; cards.innerHTML = L2.map((it, i) => `<button data-i="${i}" class="card" style="text-align:left;padding:8px 10px;border-radius:10px;border:1px solid var(--line);background:var(--sf);color:var(--fg);cursor:pointer;font:inherit"><div style="font-weight:700;font-size:13px">${bn(i + 1)}. ${it[0]}</div><div class="small" style="font-family:inherit">${it[1]}</div><span class="small" style="display:inline-block;margin-top:4px;padding:1px 6px;border-radius:8px;color:#fff;background:${TCOL[it[2]] || '#7f8c8d'}">${it[2]}</span></button>`).join(''); cards.querySelectorAll('[data-i]').forEach(b => { b.onclick = () => choose(+b.dataset.i); }); out.innerHTML = `<div><b>${f}</b>: মোট <b>${bn(L2.length)}</b>টি${ISN[f] ? '' : ' গাঠনিক সমাণু'}। ${ISN[f] || ''}</div>`; choose(0); };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); if (!m) return; cam.cx = W / 2; cam.cy = H / 2 + 8; M3.fit(m, cam, W, H - 30, 0.92); if (!cam.user) cam.yaw += 0.006; M3.render(g, m, cam, { mode: 'bs', col, labels: 'hetero' }); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${IS[f][sel][0]} · ${IS[f][sel][1]}`, W / 2, 16); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'f', v => { f = v; render(); });
    render(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, () => 230); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
