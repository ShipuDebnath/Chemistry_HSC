/* ২য় পত্র অধ্যায় ২ visuals part 4 — 2.2–2.5: homologous series, functional groups, class quiz, alkyl groups & carbon degree, IUPAC naming */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };

/* ---------- diamond-lattice tree placement: list = [[el, parent, order]] ---------- */
const TD = (() => { const s = 1 / Math.sqrt(3); return [[s, s, s], [-s, -s, s], [-s, s, -s], [s, -s, -s]]; })();
M3.treePos = list => {
  const pos = [], par = [], used = [];
  list.forEach((r, i) => {
    const [el, p, o] = r; used.push(new Set());
    if (p == null || p < 0) { pos.push([0, 0, 0]); par.push(0); return; }
    const pp = par[p]; let k = r[3] != null ? r[3] : [0, 1, 2, 3].find(j => !used[p].has(j)); used[p].add(k); par.push(1 - pp); used[i].add(k);
    const d = mul(TD[k], pp ? -1 : 1); pos.push(add(pos[p], mul(d, M3.bondLen(list[p][0], el, o || 1))));
  });
  return pos;
};
M3.tree = (list, opt = {}) => { const pos = M3.treePos(list); if (opt.fix) opt.fix(pos); return M3.mol({ name: opt.name || '', a: list.map((r, i) => [r[0], ...pos[i], r[4] || {}]), b: list.map((r, i) => r[1] == null || r[1] < 0 ? null : [r[1], i, r[2] || 1]).filter(Boolean) }); };

/* ======================= ২.২ সমগোত্রীয় শ্রেণি ======================= */
const HS = {
  alkane: { nm: 'অ্যালকেন', gen: 'CₙH₂ₙ₊₂', n0: 1, bp: [-162, -89, -42, -0.5, 36, 69, 98, 126, 151, 174], names: ['মিথেন', 'ইথেন', 'প্রোপেন', 'বিউটেন', 'পেন্টেন', 'হেক্সেন', 'হেপ্টেন', 'অকটেন', 'নোনেন', 'ডেকেন'], col: '#555' },
  alkene: { nm: 'অ্যালকিন (১-অ্যালকিন)', gen: 'CₙH₂ₙ', n0: 2, bp: [null, -104, -47.6, -6.3, 30, 63, 94, 121, 147, 171], names: [null, 'ইথিন', 'প্রোপিন', 'বিউট-১-ইন', 'পেন্ট-১-ইন', 'হেক্স-১-ইন', 'হেপ্ট-১-ইন', 'অক্ট-১-ইন', 'নোন-১-ইন', 'ডেক-১-ইন'], col: '#2d6fd6' },
  alkyne: { nm: 'অ্যালকাইন (১-অ্যালকাইন)', gen: 'CₙH₂ₙ₋₂', n0: 2, bp: [null, -84, -23, 8, 40, 71, 100, 126, 151, 174], names: [null, 'ইথাইন', 'প্রোপাইন', 'বিউট-১-আইন', 'পেন্ট-১-আইন', 'হেক্স-১-আইন', 'হেপ্ট-১-আইন', 'অক্ট-১-আইন', 'নোন-১-আইন', 'ডেক-১-আইন'], col: '#8e44ad' },
  alcohol: { nm: 'অ্যালকোহল (১-অল)', gen: 'CₙH₂ₙ₊₁OH', n0: 1, bp: [65, 78, 97, 118, 138, 157, 176, 195, 214, 231], names: ['মিথানল', 'ইথানল', 'প্রোপান-১-অল', 'বিউটান-১-অল', 'পেন্টান-১-অল', 'হেক্সান-১-অল', 'হেপ্টান-১-অল', 'অকটান-১-অল', 'নোনান-১-অল', 'ডেকান-১-অল'], col: '#c0392b' },
  aldehyde: { nm: 'অ্যালডিহাইড', gen: 'CₙH₂ₙ₊₁CHO', n0: 1, bp: [-19, 20, 48, 75, 103, 131, 153, 171, 191, 208], names: ['মিথান্যাল', 'ইথান্যাল', 'প্রোপান্যাল', 'বিউটান্যাল', 'পেন্টান্যাল', 'হেক্সান্যাল', 'হেপ্টান্যাল', 'অকটান্যাল', 'নোনান্যাল', 'ডেকান্যাল'], col: '#e67e22' },
  acid: { nm: 'কার্বক্সিলিক এসিড', gen: 'CₙH₂ₙ₊₁COOH', n0: 1, bp: [101, 118, 141, 164, 186, 205, 223, 239, 254, 269], names: ['মিথানয়িক এসিড', 'ইথানয়িক এসিড', 'প্রোপানয়িক এসিড', 'বিউটানয়িক এসিড', 'পেন্টানয়িক এসিড', 'হেক্সানয়িক এসিড', 'হেপ্টানয়িক এসিড', 'অকটানয়িক এসিড', 'নোনানয়িক এসিড', 'ডেকানয়িক এসিড'], col: '#16a085' }
};
/* n = total carbons */
const buildHom = (sr, n) => {
  const L = []; for (let i = 0; i < n; i++) L.push(['C', i - 1, 1]);
  if (sr === 'alkene' && n >= 2) L[1][2] = 2;
  if (sr === 'alkyne' && n >= 2) L[1][2] = 3;
  if (sr === 'alcohol') L.push(['O', n - 1, 1]);
  if (sr === 'aldehyde') L.push(['O', n - 1, 2]);
  if (sr === 'acid') { L.push(['O', n - 1, 2]); L.push(['O', n - 1, 1]); }
  return M3.tree(L, { fix: pos => {
    if (sr === 'alkyne' && n >= 3) pos[0] = add(pos[1], mul(norm(sub(pos[1], pos[2])), 1.20));
    if (sr === 'alkyne' && n >= 4) { /* keep C2–C3 linear too: C3 lies on the axis already through construction of C1 */ }
    if (sr === 'alkene' && n >= 3) { const u = norm(sub(pos[2], pos[1])), w = norm(sub(pos[0], pos[1])); const p = norm(sub(w, mul(u, M3.v.dot(w, u)))); pos[0] = add(pos[1], mul(add(mul(u, -0.5), mul(p, 0.866)), 1.34)); }
    if ((sr === 'aldehyde' || sr === 'acid') && n >= 2) { const c = pos[n - 1], u = norm(sub(pos[n - 2], c)), w = norm(sub(pos[n], c)); const p = norm(sub(w, mul(u, M3.v.dot(w, u)))); pos[n] = add(c, mul(add(mul(u, -0.5), mul(p, 0.866)), 1.21)); if (sr === 'acid') pos[n + 1] = add(c, mul(add(mul(u, -0.5), mul(p, -0.866)), 1.34)); }
  } });
};
V.p2c2_homolog = {
  t: 'সমগোত্রীয় শ্রেণি: একই সাধারণ সংকেত, পরপর সদস্যে –CH₂– (১৪ একক) পার্থক্য, ভৌত ধর্মের ক্রমিক পরিবর্তন — ত্রিমাত্রিক মডেল ও স্ফুটনাঙ্ক লেখচিত্র', k: ['3d', 'int', 'calc'],
  cap: 'শ্রেণি বেছে নাও ও স্লাইডারে কার্বন সংখ্যা n বদলাও — প্রতিবার শিকলে একটি করে –CH₂– (উজ্জ্বল) যুক্ত হয়, আণবিক ভর ১৪ বাড়ে। ডানের লেখচিত্রে ছয়টি শ্রেণির পরীক্ষালব্ধ স্ফুটনাঙ্ক: প্রতিটি শ্রেণিতে n বাড়লে স্ফুটনাঙ্ক মসৃণভাবে বাড়ে (ভ্যান্ডার ওয়ালস বল বাড়ে)। একই n এ অ্যালকোহল ও এসিডের স্ফুটনাঙ্ক অনেক বেশি — হাইড্রোজেন বন্ধনের কারণে; অ্যালডিহাইড মাঝামাঝি (দ্বিপোল আকর্ষণ)। ২৫ °C রেখার নিচে থাকলে সাধারণ তাপমাত্রায় গ্যাস।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('sr', Object.entries(HS).map(([k, v]) => [k, v.nm.split(' ')[0]]), 'alkane')}</div>${X.cv('সমগোত্রীয় শ্রেণি')}<div class="ctl"><label class="small" style="flex:1">কার্বন সংখ্যা n = <b data-nv></b><input type="range" min="1" max="10" step="1" value="4" data-n></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 560;
    let L = X.fit(c, hf), sr = 'alkane', n = 4, m = buildHom('alkane', 4), t = 0; const cam = M3.cam({ yaw: 0.2, pitch: 0.4 });
    C4.drag3d(c, cam, () => A.draw());
    const rebuild = () => { const S = HS[sr]; if (n < S.n0) n = S.n0; q('[data-n]').value = n; q('[data-nv]').textContent = bn(n); m = buildHom(sr, n); info(); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), S = HS[sr];
      const mw = wd ? W * 0.5 : W, mh = wd ? H : H * 0.5; cam.cx = mw / 2; cam.cy = mh / 2 + 8; M3.fit(m, cam, mw, mh - 30, 0.95); if (!cam.user) cam.yaw += 0.004;
      const hl = {}; if (n > S.n0) hl[n - 1] = '#f1c40f';
      M3.render(g, m, cam, { mode: 'bs', col, hl });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${S.names[n - 1]} · ${M3.formula(m)} · M = ${bn(Math.round(M3.mass(m)))}`, mw / 2, 16);
      const px = wd ? W * 0.58 : 50, py = wd ? 26 : mh + 20, pw = wd ? W * 0.38 : W - 66, ph = wd ? H - 70 : H - mh - 64;
      const Pl = cplot(g, { x0: px, y0: py, w: pw, h: ph, xmin: 1, xmax: 10, ymin: -180, ymax: 300, col, xt: [1, 2, 4, 6, 8, 10], yt: [-150, 0, 150, 300], xl: 'কার্বন সংখ্যা n', yl: 'স্ফুটনাঙ্ক (°C)', ylx: 32 });
      g.strokeStyle = '#e67e22'; g.setLineDash([4, 4]); g.lineWidth = 1; g.beginPath(); g.moveTo(px, Pl.Y(25)); g.lineTo(px + pw, Pl.Y(25)); g.stroke(); g.setLineDash([]); g.fillStyle = '#e67e22'; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText('২৫ °C', px + pw, Pl.Y(25) - 3);
      Object.entries(HS).forEach(([k, s]) => { const pts = []; s.bp.forEach((v, i) => { if (v != null) pts.push([Pl.X(i + 1), Pl.Y(v)]); }); g.globalAlpha = k === sr ? 1 : 0.35; path(g, pts, s.col, k === sr ? 2.6 : 1.4); pts.forEach(p => { g.fillStyle = s.col; g.beginPath(); g.arc(p[0], p[1], k === sr ? 3 : 2, 0, 7); g.fill(); }); g.globalAlpha = 1; });
      const v = S.bp[n - 1]; if (v != null) M3.sphere(g, Pl.X(n), Pl.Y(v), 7, S.col, '#fff');
      // legend
      let lx = px + 6, ly = py + 4; g.font = `9px ${col.font}`; Object.values(HS).forEach((s, i) => { const xx = lx + (i % 3) * (pw / 3), yy = ly + Math.floor(i / 3) * 12; g.fillStyle = s.col; g.fillRect(xx, yy, 10, 3); g.fillStyle = col.fg; g.textAlign = 'left'; g.fillText(s.nm.split(' ')[0], xx + 13, yy + 4); });
    };
    const info = () => { const S = HS[sr], v = S.bp[n - 1], prev = n > S.n0 ? S.names[n - 2] : null; out.innerHTML = `<div><b>${S.nm}</b> — সাধারণ সংকেত ${S.gen}। n = ${bn(n)}: <b>${S.names[n - 1]}</b> (${M3.formula(m)}), স্ফুটনাঙ্ক ${bn(v)} °C — সাধারণ তাপমাত্রায় ${v < 25 ? 'গ্যাস' : 'তরল'}।</div><div class="small" style="margin-top:4px">${prev ? `${prev} থেকে ${S.names[n - 1]}: একটি –CH₂– যুক্ত, আণবিক ভর ১৪ বেশি, স্ফুটনাঙ্ক ${bn(Math.round(v - S.bp[n - 2]))} °C বেশি।` : 'শ্রেণির প্রথম সদস্য।'} সমগোত্রীয় সদস্যদের রাসায়নিক ধর্ম প্রায় একই (একই কার্যকরী মূলক), ভৌত ধর্ম ক্রমিকভাবে পরিবর্তিত হয় এবং এদের সাধারণ প্রস্তুত প্রণালী একই।</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'sr', v => { sr = v; cam.user = false; rebuild(); });
    q('[data-n]').oninput = e => { n = +e.target.value; rebuild(); };
    rebuild(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৩ কার্যকরী মূলক ======================= */
const FG = {
  alcohol: ['অ্যালকোহল', '–OH (হাইড্রক্সিল)', 'অল (-ol)', 'ইথানল CH₃CH₂OH', () => M3.LIB.ethanol(), m => m.a.map((a, i) => a.el === 'O' || (a.el === 'H' && M3.nbrs(m, i).some(j => m.a[j].el === 'O')) ? i : -1)],
  ether: ['ইথার', '–O– (অ্যালকক্সি)', 'অ্যালকক্সি…অ্যালকেন', 'মিথক্সিমিথেন CH₃OCH₃', () => M3.LIB.dimethylEther(), m => m.a.map((a, i) => a.el === 'O' ? i : -1)],
  aldehyde: ['অ্যালডিহাইড', '–CHO (ফরমাইল)', 'অ্যাল (-al)', 'ইথান্যাল CH₃CHO', () => M3.LIB.acetaldehyde(), m => [1, 2].concat(M3.nbrs(m, 1).filter(j => m.a[j].el === 'H'))],
  ketone: ['কিটোন', '>C=O (কার্বনিল)', 'ওন (-one)', 'প্রোপানোন CH₃COCH₃', () => M3.LIB.acetone(), () => [1, 3]],
  acid: ['কার্বক্সিলিক এসিড', '–COOH (কার্বক্সিল)', 'অয়িক এসিড (-oic acid)', 'ইথানয়িক এসিড CH₃COOH', () => M3.LIB.aceticAcid(), m => [1, 2, 3].concat(M3.nbrs(m, 3).filter(j => m.a[j].el === 'H'))],
  ester: ['এস্টার', '–COOR (অ্যালকক্সিকার্বনিল)', 'অ্যালকাইল…অয়েট (-oate)', 'মিথাইল ইথানয়েট CH₃COOCH₃', () => M3.mol({ name: 'মিথাইল ইথানয়েট', a: [['C', 0, 0, 0], ['C', 1.50, 0, 0], ['O', 2.10, 1.04, 0], ['O', 2.17, -1.13, 0], ['C', 3.60, -1.13, 0]], b: [[0, 1], [1, 2, 2], [1, 3], [3, 4]] }), () => [1, 2, 3]],
  amide: ['অ্যামাইড', '–CONH₂ (কার্বামোয়িল)', 'অ্যামাইড (-amide)', 'ইথান্যামাইড CH₃CONH₂', () => M3.mol({ name: 'ইথান্যামাইড', a: [['C', 0, 0, 0], ['C', 1.51, 0, 0], ['O', 2.12, 1.05, 0], ['N', 2.18, -1.15, 0, { geo: 'tri', pn: [0, 0, 1] }]], b: [[0, 1], [1, 2, 2], [1, 3]] }), m => [1, 2, 3].concat(M3.nbrs(m, 3).filter(j => m.a[j].el === 'H'))],
  amine: ['অ্যামিন', '–NH₂ (অ্যামিনো)', 'অ্যামিন (-amine)', 'মিথান্যামিন CH₃NH₂', () => M3.LIB.methylamine(), m => [1].concat(M3.nbrs(m, 1).filter(j => m.a[j].el === 'H'))],
  halide: ['অ্যালকাইল হ্যালাইড', '–X (হ্যালো)', 'হ্যালো… (উপসর্গ)', 'ক্লোরোইথেন CH₃CH₂Cl', () => M3.mol({ name: 'ক্লোরোইথেন', a: [['C', 0, 0, 0], ['C', 1.257, 0.889, 0], ['Cl', 2.70, -0.13, 0]], b: [[0, 1], [1, 2]] }), () => [2]],
  nitrile: ['নাইট্রাইল', '–C≡N (সায়ানো)', 'নাইট্রাইল (-nitrile)', 'ইথেননাইট্রাইল CH₃CN', () => M3.mol({ name: 'ইথেননাইট্রাইল', a: [['C', 0, 0, 0], ['C', 1.46, 0, 0], ['N', 2.62, 0, 0]], b: [[0, 1], [1, 2, 3]] }), () => [1, 2]],
  nitro: ['নাইট্রো যৌগ', '–NO₂ (নাইট্রো)', 'নাইট্রো… (উপসর্গ)', 'নাইট্রোমিথেন CH₃NO₂', () => M3.mol({ name: 'নাইট্রোমিথেন', a: [['C', 0, 0, 0], ['N', 1.49, 0, 0, { q: 1 }], ['O', 2.10, 1.07, 0], ['O', 2.10, -1.07, 0, { q: -1 }]], b: [[0, 1], [1, 2, 2], [1, 3]] }), () => [1, 2, 3]],
  acyl: ['অ্যাসিড হ্যালাইড', '–COCl (অ্যাসাইল হ্যালাইড)', 'অয়িল হ্যালাইড (-oyl chloride)', 'ইথানয়িল ক্লোরাইড CH₃COCl', () => M3.mol({ name: 'ইথানয়িল ক্লোরাইড', a: [['C', 0, 0, 0], ['C', 1.50, 0, 0], ['O', 2.10, 1.03, 0], ['Cl', 2.40, -1.42, 0]], b: [[0, 1], [1, 2, 2], [1, 3]] }), () => [1, 2, 3]],
  alkene: ['অ্যালকিন', '>C=C< (দ্বিবন্ধন)', 'ইন (-ene)', 'প্রোপিন CH₃CH=CH₂', () => M3.LIB.propene(), () => [0, 1]],
  alkyne: ['অ্যালকাইন', '–C≡C– (ত্রিবন্ধন)', 'আইন (-yne)', 'প্রোপাইন CH₃C≡CH', () => M3.LIB.propyne(), () => [0, 1]]
};
V.p2c2_fgroups = {
  t: 'কার্যকরী মূলক: যে পরমাণু বা পরমাণুগুচ্ছ যৌগের রাসায়নিক ধর্ম নির্ধারণ করে — ১৪টি প্রধান মূলকের ত্রিমাত্রিক মডেল, নামকরণের প্রত্যয় ও উদাহরণ', k: ['3d', 'int'],
  cap: 'যেকোনো কার্যকরী মূলকের নামে চাপ দাও — তার সবচেয়ে সরল সদস্যের ত্রিমাত্রিক মডেল আসে, কার্যকরী মূলকের পরমাণুগুলো সোনালি আভায় উজ্জ্বল (টেনে ঘোরাও)। বাকি অংশটি (অ্যালকাইল শিকল) প্রায় নিষ্ক্রিয়; যৌগটি কী বিক্রিয়া দেবে তা ঠিক করে এই উজ্জ্বল অংশটি। নিচে IUPAC নামের প্রত্যয়/উপসর্গ ও উদাহরণ।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap;gap:4px" data-btns></div>${X.cv('কার্যকরী মূলক')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), bx = el.querySelector('[data-btns]');
    const hf = w => wide(w) ? 300 : 360;
    let L = X.fit(c, hf), k = 'alcohol', m = FG.alcohol[4](), hlS = new Set(), t = 0; const cam = M3.cam({ yaw: 0.3, pitch: 0.35 });
    bx.innerHTML = Object.entries(FG).map(([key, v]) => `<button class="btn sm" data-k="${key}">${v[0]}</button>`).join('');
    const choose = key => { k = key; m = FG[key][4](); hlS = new Set(FG[key][5](m).filter(i => i >= 0)); cam.user = false; bx.querySelectorAll('[data-k]').forEach(b => b.classList.toggle('primary', b.dataset.k === key)); const f = FG[key]; out.innerHTML = `<div class="table-wrap"><table class="t"><tbody><tr><th>শ্রেণি</th><td>${f[0]}</td><th>কার্যকরী মূলক</th><td>${f[1]}</td></tr><tr><th>IUPAC প্রত্যয়/উপসর্গ</th><td>${f[2]}</td><th>উদাহরণ</th><td>${f[3]}</td></tr></tbody></table></div>`; };
    bx.querySelectorAll('[data-k]').forEach(b => { b.onclick = () => choose(b.dataset.k); });
    C4.drag3d(c, cam, () => A.draw());
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); cam.cx = W / 2; cam.cy = H / 2 + 8; M3.fit(m, cam, W, H - 30, 0.9); if (!cam.user) cam.yaw += 0.005; const hl = {}; hlS.forEach(i => { hl[i] = '#f1c40f'; }); M3.render(g, m, cam, { mode: 'bs', col, hl }); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${FG[k][0]}: ${FG[k][1]} · ${m.name || FG[k][3]} · ${M3.formula(m)}`, W / 2, 16); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    choose('alcohol'); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৪ কার্যকরী মূলক শনাক্তকরণ চর্চা ======================= */
const QPOOL = [
  ['alcohol', () => M3.tree([['C', -1], ['C', 0], ['C', 1], ['O', 2]], { name: 'প্রোপান-১-অল' })],
  ['alcohol', () => M3.tree([['C', -1], ['C', 0], ['C', 1], ['O', 1]], { name: 'প্রোপান-২-অল' })],
  ['ether', () => M3.tree([['C', -1], ['O', 0], ['C', 1], ['C', 2]], { name: 'মিথক্সিইথেন' })],
  ['ketone', () => M3.tree([['C', -1], ['C', 0], ['C', 1], ['C', 2], ['O', 1, 2]], { name: 'বিউটানোন' })],
  ['aldehyde', () => M3.tree([['C', -1], ['C', 0], ['C', 1], ['O', 2, 2]], { name: 'প্রোপান্যাল' })],
  ['acid', () => M3.tree([['C', -1], ['C', 0], ['C', 1], ['O', 2, 2], ['O', 2]], { name: 'প্রোপানয়িক এসিড' })],
  ['ester', () => FG.ester[4]()],
  ['amide', () => FG.amide[4]()],
  ['amine', () => M3.tree([['C', -1], ['C', 0], ['N', 1]], { name: 'ইথান্যামিন' })],
  ['halide', () => M3.tree([['C', -1], ['C', 0], ['Br', 1], ['C', 1]], { name: '২-ব্রোমোপ্রোপেন' })],
  ['nitrile', () => FG.nitrile[4]()],
  ['nitro', () => FG.nitro[4]()],
  ['acyl', () => FG.acyl[4]()],
  ['alkene', () => M3.LIB.propene()],
  ['alkyne', () => M3.LIB.propyne()],
  ['alcohol', () => M3.LIB.methanol()],
  ['aldehyde', () => M3.mol({ name: 'মিথান্যাল', a: [['C', 0, 0, 0], ['O', 1.21, 0, 0]], b: [[0, 1, 2]] })],
  ['ketone', () => M3.LIB.acetone()],
  ['acid', () => M3.mol({ name: 'মিথানয়িক এসিড', a: [['C', 0, 0, 0], ['O', 0.6, 1.04, 0], ['O', 0.67, -1.13, 0, { pref: [1, 0, 0] }]], b: [[0, 1, 2], [0, 2]] })]
];
V.p2c2_fgQuiz = {
  t: 'কার্যকরী মূলক দেখে শ্রেণি চেনো: এলোমেলো ত্রিমাত্রিক অণু — চারটি বিকল্প থেকে সঠিক শ্রেণি বাছাই', k: ['3d', 'int'],
  cap: 'একটি এলোমেলো জৈব অণুর ত্রিমাত্রিক মডেল আসে (টেনে ঘোরাও; লাল = O, নীল = N, সবুজ/বাদামি = হ্যালোজেন)। কার্যকরী মূলকটি খুঁজে চারটি বিকল্প থেকে শ্রেণি বাছাই করো। উত্তরের পর কার্যকরী মূলকটি উজ্জ্বল হয় এবং যৌগের নাম ও কারণ দেখায়। কঠিন জোড়াগুলো: অ্যালকোহল বনাম ইথার (O তে H আছে কি?), অ্যালডিহাইড বনাম কিটোন (C=O এর কার্বনে H আছে কি?), এসিড বনাম এস্টার (–OH নাকি –OR?)।',
  html: () => `${X.cv('কার্যকরী মূলক চেনো', 260)}<div class="ctl" style="flex-wrap:wrap;gap:6px" data-opts></div><div class="ctl"><button class="btn sm" data-nx>পরের অণু →</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), opts = el.querySelector('[data-opts]');
    let L = X.fit(c, () => 260), cur, m, done = false, score = 0, tot = 0, hlS = new Set(), t = 0, last = -1; const cam = M3.cam({ yaw: 0.3, pitch: 0.35 });
    C4.drag3d(c, cam, () => A.draw());
    const fgAtoms = (key, mm) => { const ids = []; mm.a.forEach((a, i) => { if (a.el === 'H' || a.el === 'C') return; ids.push(i); M3.nbrs(mm, i).forEach(j => { if (mm.a[j].el === 'H') ids.push(j); if (mm.a[j].el === 'C' && ['aldehyde', 'ketone', 'acid', 'ester', 'amide', 'acyl', 'nitrile'].includes(key) && mm.b.some(b => ((b.i === i && b.j === j) || (b.j === i && b.i === j)) && b.o > 1)) ids.push(j); }); }); if (key === 'alkene' || key === 'alkyne') mm.b.forEach(b => { if (b.o > 1) ids.push(b.i, b.j); }); if (key === 'aldehyde') mm.a.forEach((a, i) => { if (a.el === 'C' && ids.includes(i)) M3.nbrs(mm, i).forEach(j => { if (mm.a[j].el === 'H') ids.push(j); }); }); return new Set(ids); };
    const next = () => { let r; do { r = Math.floor(Math.random() * QPOOL.length); } while (r === last); last = r; cur = QPOOL[r]; m = cur[1](); done = false; hlS = new Set(); cam.user = false; const keys = Object.keys(FG).filter(k => k !== cur[0]); const confuse = { alcohol: 'ether', ether: 'alcohol', aldehyde: 'ketone', ketone: 'aldehyde', acid: 'ester', ester: 'acid', amide: 'amine', amine: 'amide', nitrile: 'nitro', nitro: 'nitrile', halide: 'acyl', acyl: 'acid', alkene: 'alkyne', alkyne: 'alkene' }; const ch = [cur[0], confuse[cur[0]]]; while (ch.length < 4) { const kk = keys[Math.floor(Math.random() * keys.length)]; if (!ch.includes(kk)) ch.push(kk); } ch.sort(() => Math.random() - 0.5); opts.innerHTML = ch.map(kk => `<button class="btn sm" data-a="${kk}">${FG[kk][0]}</button>`).join(''); opts.querySelectorAll('[data-a]').forEach(b => { b.onclick = () => answer(b.dataset.a, b); }); out.innerHTML = `<div class="small">অণুটির কার্যকরী মূলক কোন শ্রেণির? · স্কোর ${bn(score)}/${bn(tot)}</div>`; };
    const answer = (kk, btn) => { if (done) return; done = true; tot++; const ok = kk === cur[0]; if (ok) score++; hlS = fgAtoms(cur[0], m); opts.querySelectorAll('[data-a]').forEach(b => { if (b.dataset.a === cur[0]) b.classList.add('primary'); }); if (!ok) btn.style.textDecoration = 'line-through'; out.innerHTML = `<div style="font-weight:700;color:${ok ? 'var(--ok)' : 'var(--bad)'}">${ok ? '✓ সঠিক!' : '✗ সঠিক উত্তর: ' + FG[cur[0]][0]}</div><div class="small">${m.name || ''} (${M3.formula(m)}) — কার্যকরী মূলক ${FG[cur[0]][1]}। স্কোর ${bn(score)}/${bn(tot)}</div>`; };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); cam.cx = W / 2; cam.cy = H / 2; M3.fit(m, cam, W, H - 10, 0.9); if (!cam.user) cam.yaw += 0.006; const hl = {}; hlS.forEach(i => { hl[i] = '#f1c40f'; }); M3.render(g, m, cam, { mode: 'bs', col, hl, labels: 'hetero' }); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    el.querySelector('[data-nx]').onclick = next;
    next(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, () => 260); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৫ অ্যালকাইল মূলক ও কার্বনের শ্রেণি (১°, ২°, ৩°, ৪°) ======================= */
const ALK = {
  methyl: ['মিথাইল', 'CH₃–', [['X', -1], ['C', 0]]],
  ethyl: ['ইথাইল', 'CH₃CH₂–', [['X', -1], ['C', 0], ['C', 1]]],
  propyl: ['প্রোপাইল (n-প্রোপাইল)', 'CH₃CH₂CH₂–', [['X', -1], ['C', 0], ['C', 1], ['C', 2]]],
  ipr: ['আইসোপ্রোপাইল', '(CH₃)₂CH–', [['X', -1], ['C', 0], ['C', 1], ['C', 1]]],
  butyl: ['বিউটাইল (n-বিউটাইল)', 'CH₃(CH₂)₃–', [['X', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 3]]],
  sbu: ['সেকেন্ডারি-বিউটাইল', 'CH₃CH₂CH(CH₃)–', [['X', -1], ['C', 0], ['C', 1], ['C', 1], ['C', 2]]],
  ibu: ['আইসোবিউটাইল', '(CH₃)₂CHCH₂–', [['X', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 2]]],
  tbu: ['টারশিয়ারি-বিউটাইল', '(CH₃)₃C–', [['X', -1], ['C', 0], ['C', 1], ['C', 1], ['C', 1]]],
  iso: ['আইসো-অকটেন: ২,২,৪-ট্রাইমিথাইলপেন্টেন', '(CH₃)₃CCH₂CH(CH₃)₂', [['C', -1], ['C', 0], ['C', 1], ['C', 2], ['C', 3], ['C', 1], ['C', 1], ['C', 3]]]
};
const DEG = ['#7f8c8d', '#2d6fd6', '#2f9e44', '#e67e22', '#c0392b'];
V.p2c2_alkyl = {
  t: 'অ্যালকাইল মূলক ও কার্বন পরমাণুর শ্রেণি: মিথাইল থেকে টারশিয়ারি-বিউটাইল — সংযোগ বিন্দুসহ ত্রিমাত্রিক মডেল এবং ১°, ২°, ৩°, ৪° কার্বনের রং-সংকেত', k: ['3d', 'int'],
  cap: 'অ্যালকাইল মূলক বেছে নাও: সোনালি বল (X) হলো সংযোগ বিন্দু — যেখানে মূলকটি অণুর বাকি অংশের সাথে যুক্ত হয়। প্রতিটি কার্বন তার সাথে যুক্ত অন্য কার্বনের সংখ্যা অনুযায়ী রঙিন: নীল = প্রাইমারি (১°), সবুজ = সেকেন্ডারি (২°), কমলা = টারশিয়ারি (৩°), লাল = কোয়াটারনারি (৪°)। X কে কার্বন হিসেবে গোনা হয় না, কিন্তু সংযোগ বিন্দুর কার্বনের ধরন দিয়েই মূলকের নাম (সেকেন্ডারি-বিউটাইল, টারশিয়ারি-বিউটাইল)। শেষ বোতামে আইসো-অকটেনে চার ধরনের কার্বনই দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('al', Object.entries(ALK).map(([k, v]) => [k, v[0].split(' ')[0].replace(':', '')]), 'ipr')}</div>${X.cv('অ্যালকাইল মূলক')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 360 : 400;
    let L = X.fit(c, hf), al = 'ipr', m, deg = [], t = 0; const cam = M3.cam({ yaw: 0.4, pitch: 0.4 });
    const rebuild = () => { const s = ALK[al]; m = M3.tree(s[2].map(r => r[0] === 'X' ? [r[0], r[1], 1, null, { noH: true }] : r), { name: s[0] }); deg = m.a.map((a, i) => a.el === 'C' ? M3.nbrs(m, i).filter(j => m.a[j].el === 'C').length : -1); const cnt = [0, 0, 0, 0, 0]; deg.forEach(d => { if (d >= 0) cnt[Math.max(1, d)]++; }); const att = m.a.findIndex(a => a.el === 'X'), ac = att >= 0 ? M3.nbrs(m, att)[0] : -1; const dn = ['', 'প্রাইমারি (১°)', 'সেকেন্ডারি (২°)', 'টারশিয়ারি (৩°)', 'কোয়াটারনারি (৪°)'];
      out.innerHTML = `<div><b>${s[0]}</b>: ${s[1]}${ac >= 0 ? ` — সংযোগ বিন্দুর কার্বন ${dn[deg[ac] + 1]} (X সহ গুনলে)` : ''}</div><div class="small" style="margin-top:4px">${al === 'iso' ? `১° কার্বন ${bn(cnt[1])}টি, ২° ${bn(cnt[2])}টি, ৩° ${bn(cnt[3])}টি, ৪° ${bn(cnt[4])}টি। আইসো-অকটেনের অকটেন নম্বর ১০০ ধরা হয় — শাখান্বিত অ্যালকেন ইঞ্জিনে মসৃণভাবে জ্বলে।` : 'প্রাইমারি কার্বন: অন্য ১টি C এর সাথে যুক্ত; সেকেন্ডারি: ২টি; টারশিয়ারি: ৩টি; কোয়াটারনারি: ৪টি। অ্যালকেন থেকে একটি H সরালে অ্যালকাইল মূলক (R–) পাওয়া যায়: CₙH₂ₙ₊₁–।'}</div>`; };
    C4.drag3d(c, cam, () => A.draw());
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); cam.cx = W / 2; cam.cy = H / 2 + 8; M3.fit(m, cam, W, H - 40, 1.12); if (!cam.user) cam.yaw += 0.005; const hl = {}; m.a.forEach((a, i) => { if (a.el === 'C') { const d = deg[i] + (M3.nbrs(m, i).some(j => m.a[j].el === 'X') ? 1 : 0); hl[i] = DEG[Math.min(4, Math.max(1, d))]; } }); const alpha = {}; m.a.forEach((a, i) => { if (a.el === 'H') alpha[i] = 0.45; }); const r = M3.render(g, m, cam, { mode: 'bs', col, hl, labels: false, alpha });
      m.a.forEach((a, i) => { if (a.el !== 'C') return; const d = deg[i] + (M3.nbrs(m, i).some(j => m.a[j].el === 'X') ? 1 : 0), p = r.S[i]; g.fillStyle = DEG[Math.min(4, Math.max(1, d))]; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(['', '১°', '২°', '৩°', '৪°'][Math.min(4, Math.max(1, d))], p[0], p[1] - 18); });
      const xi = m.a.findIndex(a => a.el === 'X'); if (xi >= 0) { const p = r.S[xi]; g.fillStyle = '#b7791f'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('সংযোগ বিন্দু', p[0], p[1] + 22); }
      g.font = `9.5px ${col.font}`; ['১° প্রাইমারি', '২° সেকেন্ডারি', '৩° টারশিয়ারি', '৪° কোয়াটারনারি'].forEach((s, k) => { g.fillStyle = DEG[k + 1]; g.textAlign = 'left'; g.fillText('● ' + s, 8 + k * Math.min(110, W / 4), H - 8); }); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'al', v => { al = v; cam.user = false; rebuild(); });
    rebuild(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৫ IUPAC নামকরণ: ধাপে ধাপে ======================= */
/* a: [el, x, y] (2D grid), b: [i, j, order], ch: main chain in numbering order, sub: [[atoms], name, locant], fg: [atoms] principal group / multiple bond, parts: [[text, kind]] kind: s=substituent, p=parent, f=suffix */
const IU = [
  { nm: '২-মিথাইলবিউটেন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['C', 1, -1.5]], b: [[0, 1], [1, 2], [2, 3], [1, 4]], ch: [0, 1, 2, 3], sub: [[[4], 'মিথাইল', 2]], r1: 'দীর্ঘতম শিকল ৪টি কার্বনের — মূল নাম বিউটেন।', r2: 'যে প্রান্ত থেকে শাখা কাছে, সেখান থেকে নম্বর: বাম থেকে মিথাইল ২ নম্বরে (ডান থেকে হতো ৩)।', parts: [['২-মিথাইল', 's'], ['বিউটেন', 'p']], wrong: ['৩-মিথাইলবিউটেন', '২-ইথাইলপ্রোপেন', '১,১-ডাইমিথাইলপ্রোপেন'] },
  { nm: '৩-মিথাইলহেক্সেন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['C', 4, 0], ['C', 3, -1.5], ['C', 4, -2]], b: [[0, 1], [1, 2], [2, 3], [3, 4], [3, 5], [5, 6]], ch: [6, 5, 3, 2, 1, 0], sub: [[[4], 'মিথাইল', 3]], r1: 'সাবধান! অনুভূমিক শিকলে ৫টি C, কিন্তু নিচে বাঁকানো পথে ৬টি C — দীর্ঘতম শিকল সবসময় সোজা হয় না। মূল নাম হেক্সেন।', r2: 'শাখার কাছের প্রান্ত (নিচের প্রান্ত) থেকে নম্বর দিলে মিথাইল ৩ নম্বরে (অন্য প্রান্ত থেকে ৪)।', parts: [['৩-মিথাইল', 's'], ['হেক্সেন', 'p']], wrong: ['২-ইথাইলপেন্টেন', '৪-মিথাইলহেক্সেন', '৩-ইথাইলপেন্টেন'] },
  { nm: '৩-ইথাইল-২-মিথাইলহেক্সেন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['C', 4, 0], ['C', 5, -0.5], ['C', 1, -1.5], ['C', 2, 1], ['C', 3, 1.5]], b: [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [1, 6], [2, 7], [7, 8]], ch: [0, 1, 2, 3, 4, 5], sub: [[[6], 'মিথাইল', 2], [[7, 8], 'ইথাইল', 3]], r1: 'দুটি ৬-কার্বন শিকল সম্ভব; যেটিতে শাখার সংখ্যা বেশি (২টি) সেটি মূল শিকল — হেক্সেন।', r2: 'বাম থেকে শাখা {২, ৩}, ডান থেকে {৪, ৫} — প্রথম পার্থক্যের বিন্দুতে ছোট সংখ্যা: বাম থেকে।', r4: 'শাখাগুলো ইংরেজি বর্ণানুক্রমে সাজাও: ethyl (e) আগে, methyl (m) পরে।', parts: [['৩-ইথাইল-২-মিথাইল', 's'], ['হেক্সেন', 'p']], wrong: ['২-মিথাইল-৩-ইথাইলহেক্সেন', '৪-ইথাইল-৫-মিথাইলহেক্সেন', '৩-আইসোপ্রোপাইলহেক্সেন'] },
  { nm: '২,২-ডাইমিথাইলপ্রোপেন', a: [['C', 0, 0], ['C', 1, 0], ['C', 2, 0], ['C', 1, -1], ['C', 1, 1]], b: [[0, 1], [1, 2], [1, 3], [1, 4]], ch: [0, 1, 2], sub: [[[3], 'মিথাইল', 2], [[4], 'মিথাইল', 2]], r1: 'যেকোনো দিকে দীর্ঘতম শিকল ৩টি C — প্রোপেন।', r2: 'উভয় মিথাইল ২ নম্বর কার্বনে।', r4: 'একই শাখা দুইবার: "ডাই" উপসর্গ, প্রতিটির অবস্থান আলাদাভাবে লেখা হয় (২,২)।', parts: [['২,২-ডাইমিথাইল', 's'], ['প্রোপেন', 'p']], wrong: ['২-ডাইমিথাইলপ্রোপেন', 'নিওপেন্টেন', '২,২-মিথাইলপ্রোপেন'] },
  { nm: '২-ব্রোমো-৩-মিথাইলবিউটেন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['Br', 1, -1.5], ['C', 2, 1]], b: [[0, 1], [1, 2], [2, 3], [1, 4], [2, 5]], ch: [0, 1, 2, 3], sub: [[[4], 'ব্রোমো', 2], [[5], 'মিথাইল', 3]], r1: 'দীর্ঘতম শিকল ৪টি C — বিউটেন। হ্যালোজেন উপসর্গ হিসেবে শাখার মতো গণ্য।', r2: 'দুই দিক থেকেই অবস্থান {২, ৩} — সমান হলে বর্ণানুক্রমে যে আগে (bromo) সে ছোট নম্বর পাবে।', parts: [['২-ব্রোমো-৩-মিথাইল', 's'], ['বিউটেন', 'p']], wrong: ['৩-ব্রোমো-২-মিথাইলবিউটেন', '২-মিথাইল-৩-ব্রোমোবিউটেন', '১-ব্রোমো-১,২-ডাইমিথাইলপ্রোপেন'] },
  { nm: 'বিউট-২-ইন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5]], b: [[0, 1], [1, 2, 2], [2, 3]], ch: [0, 1, 2, 3], sub: [], fg: [1, 2], r1: 'দ্বিবন্ধনযুক্ত দীর্ঘতম শিকল ৪টি C — বিউট- + ইন।', r2: 'দ্বিবন্ধন যে প্রান্তের কাছে সেখান থেকে নম্বর; এখানে দুই দিক থেকেই ২ — দ্বিবন্ধন C২ ও C৩ এর মধ্যে, ছোট নম্বরটি (২) লেখা হয়।', parts: [['বিউট', 'p'], ['-২-ইন', 'f']], wrong: ['বিউট-৩-ইন', 'বিউটেন-২', '২-বিউটাইন'] },
  { nm: '৩-মিথাইলবিউট-১-ইন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['C', 2, 1]], b: [[0, 1, 2], [1, 2], [2, 3], [2, 4]], ch: [0, 1, 2, 3], sub: [[[4], 'মিথাইল', 3]], fg: [0, 1], r1: 'দ্বিবন্ধনযুক্ত দীর্ঘতম শিকল ৪টি C।', r2: 'শাখার চেয়ে দ্বিবন্ধন অগ্রাধিকার পায়: দ্বিবন্ধন C১–C২ (বাম থেকে); ফলে মিথাইল ৩ নম্বরে। (ডান থেকে দিলে মিথাইল ২ হতো, কিন্তু দ্বিবন্ধন ৩ — ভুল।)', parts: [['৩-মিথাইল', 's'], ['বিউট', 'p'], ['-১-ইন', 'f']], wrong: ['২-মিথাইলবিউট-৩-ইন', '৩-মিথাইলবিউটিন', '২-মিথাইলবিউট-১-ইন'] },
  { nm: '৪-মিথাইলপেন্ট-২-আইন', a: [['C', 0, 0], ['C', 1, 0], ['C', 2, 0], ['C', 3, 0], ['C', 4, -0.5], ['C', 3, 1]], b: [[0, 1], [1, 2, 3], [2, 3], [3, 4], [3, 5]], ch: [0, 1, 2, 3, 4], sub: [[[5], 'মিথাইল', 4]], fg: [1, 2], r1: 'ত্রিবন্ধনযুক্ত দীর্ঘতম শিকল ৫টি C — পেন্ট- + আইন। ত্রিবন্ধনের কার্বনগুলো রৈখিক (sp)।', r2: 'ত্রিবন্ধনের কাছের প্রান্ত (বাম) থেকে নম্বর: ত্রিবন্ধন ২, মিথাইল ৪।', parts: [['৪-মিথাইল', 's'], ['পেন্ট', 'p'], ['-২-আইন', 'f']], wrong: ['২-মিথাইলপেন্ট-৩-আইন', '৪-মিথাইলপেন্ট-৩-আইন', '২-মিথাইলহেক্স-৩-আইন'] },
  { nm: 'বিউটান-২-অল', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['O', 1, -1.5]], b: [[0, 1], [1, 2], [2, 3], [1, 4]], ch: [0, 1, 2, 3], sub: [], fg: [4], r1: '–OH যুক্ত কার্বনসহ দীর্ঘতম শিকল ৪টি C — বিউটেন → বিউটান-।', r2: 'প্রধান কার্যকরী মূলক (–OH) সবচেয়ে ছোট নম্বর পাবে: বাম থেকে ২।', r4: 'অ্যালকেনের শেষ "e" বাদ দিয়ে "অল" (-ol) প্রত্যয়: butane → butan-2-ol।', parts: [['বিউটান', 'p'], ['-২-অল', 'f']], wrong: ['বিউটান-৩-অল', '২-হাইড্রক্সিবিউটেন', '১-মিথাইলপ্রোপান-১-অল'] },
  { nm: '৩-মিথাইলবিউটান্যাল', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['O', 0, 1], ['C', 2, 1]], b: [[0, 1], [1, 2], [2, 3], [0, 4, 2], [2, 5]], ch: [0, 1, 2, 3], sub: [[[5], 'মিথাইল', 3]], fg: [0, 4], r1: '–CHO এর কার্বনসহ দীর্ঘতম শিকল ৪টি C।', r2: '–CHO এর কার্বন সবসময় ১ নম্বর (তাই অবস্থান লেখা হয় না); মিথাইল ৩ নম্বরে।', r4: 'অ্যালকেন → অ্যাল (-al) প্রত্যয়: butanal।', parts: [['৩-মিথাইল', 's'], ['বিউটা', 'p'], ['ন্যাল', 'f']], wrong: ['২-মিথাইলবিউটান্যাল', '৩-মিথাইলবিউটান-১-অল', '৩-মিথাইলবিউটানোন'] },
  { nm: 'পেন্টান-৩-ওন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['C', 4, 0], ['O', 2, 1]], b: [[0, 1], [1, 2], [2, 3], [3, 4], [2, 5, 2]], ch: [0, 1, 2, 3, 4], sub: [], fg: [2, 5], r1: 'কিটোন মূলকের কার্বনসহ দীর্ঘতম শিকল ৫টি C।', r2: 'C=O এর কার্বন দুই দিক থেকেই ৩ নম্বর।', r4: 'অ্যালকেন → ওন (-one): pentan-3-one (সাধারণ নাম ডাইইথাইল কিটোন)।', parts: [['পেন্টান', 'p'], ['-৩-ওন', 'f']], wrong: ['পেন্টান-২-ওন', '৩-পেন্টান্যাল', 'ডাইমিথাইল কিটোন'] },
  { nm: '২-মিথাইলপ্রোপানয়িক এসিড', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['O', 0, 1], ['O', -1, -0.5], ['C', 1, -1.5]], b: [[0, 1], [1, 2], [0, 3, 2], [0, 4], [1, 5]], ch: [0, 1, 2], sub: [[[5], 'মিথাইল', 2]], fg: [0, 3, 4], r1: '–COOH এর কার্বনসহ দীর্ঘতম শিকল ৩টি C — প্রোপেন।', r2: '–COOH এর কার্বন সবসময় ১; মিথাইল ২ নম্বরে।', r4: 'অ্যালকেন → অয়িক এসিড (-oic acid): propanoic acid।', parts: [['২-মিথাইল', 's'], ['প্রোপান', 'p'], ['য়িক এসিড', 'f']], wrong: ['২-মিথাইলবিউটানয়িক এসিড', '১-মিথাইলপ্রোপানয়িক এসিড', '২-মিথাইলপ্রোপান্যাল'] },
  { nm: '৪-মিথাইলপেন্ট-৩-ইন-২-ওন', a: [['C', 0, 0], ['C', 1, -0.5], ['C', 2, 0], ['C', 3, -0.5], ['C', 4, 0], ['O', 1, -1.5], ['C', 3, -1.5]], b: [[0, 1], [1, 2], [2, 3, 2], [3, 4], [1, 5, 2], [3, 6]], ch: [0, 1, 2, 3, 4], sub: [[[6], 'মিথাইল', 4]], fg: [1, 5, 2, 3], r1: 'কিটোন ও দ্বিবন্ধন উভয়ই ধারণকারী দীর্ঘতম শিকল ৫টি C।', r2: 'অগ্রাধিকার: কিটোন > দ্বিবন্ধন > শাখা। কিটোন বাম থেকে ২ (ডান থেকে ৪) — তাই বাম থেকে নম্বর; দ্বিবন্ধন ৩, মিথাইল ৪।', r4: 'পেন্ট + -৩-ইন + -২-ওন: "pent-3-en-2-one" (দ্বিবন্ধনের "e" বাদ যায় কারণ পরে স্বরবর্ণ)।', parts: [['৪-মিথাইল', 's'], ['পেন্ট', 'p'], ['-৩-ইন-২-ওন', 'f']], wrong: ['২-মিথাইলপেন্ট-২-ইন-৪-ওন', '৪-মিথাইলপেন্ট-২-ইন-৪-ওন', '৪-মিথাইলপেন্টান-২-ওন'] }
];
const KCOL = { s: '#e67e22', p: '#2d6fd6', f: '#2f9e44' };
const subN = n => n > 1 ? String(n).split('').map(d => '₀₁₂₃₄₅₆₇₈₉'[d]).join('') : '';
V.p2c2_iupac = {
  t: 'IUPAC নামকরণ ধাপে ধাপে: দীর্ঘতম শিকল → নম্বর প্রদান → শাখা ও কার্যকরী মূলক → বর্ণানুক্রমে নাম গঠন (১৩টি উদাহরণ ও নিজে যাচাই)', k: ['int', '2d', 'anim'],
  cap: 'যৌগ বেছে নাও এবং "পরের ধাপ" চাপো। ধাপ ১: দীর্ঘতম শিকল নীল আভায় উজ্জ্বল হয় (বাঁকানো পথও হতে পারে!); ধাপ ২: সঠিক প্রান্ত থেকে কার্বনগুলোতে নম্বর বসে; ধাপ ৩: শাখা (কমলা) ও প্রধান কার্যকরী মূলক বা বহুবন্ধন (সবুজ) চিহ্নিত হয়; ধাপ ৪: নামের অংশগুলো রঙে মিলিয়ে জোড়া লাগে — কমলা = শাখা ও অবস্থান, নীল = মূল শিকল, সবুজ = প্রত্যয়। "চর্চা মোড" এ ধাপ দেখার আগে চারটি নাম থেকে সঠিকটি বেছে নিজেকে যাচাই করো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap"><select data-sel style="padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--sf);color:var(--fg);font:inherit;max-width:100%">${IU.map((u, i) => `<option value="${i}">${i + 1}. ${u.nm}</option>`).join('')}</select>${X.seg('md', [['learn', 'শেখো'], ['quiz', 'চর্চা']], 'learn')}</div>${X.cv('IUPAC নামকরণ')}<div class="ctl" data-ctl><button class="btn sm" data-pv>◀</button><button class="btn sm primary" data-nx>পরের ধাপ ▶</button><span class="small" data-st></span></div><div class="ctl" data-opts style="flex-wrap:wrap;gap:6px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), opts = q('[data-opts]');
    const hf = w => wide(w) ? 300 : 330;
    let L = X.fit(c, hf), ix = 0, st = 0, md = 'learn', anim = 1, t = 0, quizDone = false;
    const label = (u, i) => { const a = u.a[i]; if (a[0] !== 'C') return a[0] === 'O' ? (u.b.some(b => (b[0] === i || b[1] === i) && (b[2] || 1) === 2) ? 'O' : 'OH') : a[0]; const s = u.b.reduce((tt, b) => tt + (b[0] === i || b[1] === i ? (b[2] || 1) : 0), 0), h = 4 - s; return h > 0 ? 'CH' + subN(h) : 'C'; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const u = IU[ix];
      const xs = u.a.map(a => a[1]), ys = u.a.map(a => a[2]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      const sc = Math.min((W - 80) / Math.max(1, x1 - x0), (H - 110) / Math.max(1, y1 - y0), 90), ox = W / 2 - (x0 + x1) / 2 * sc, oy = (H - 50) / 2 + 6 - (y0 + y1) / 2 * sc;
      const P = i => [ox + u.a[i][1] * sc, oy + u.a[i][2] * sc];
      const chainSet = new Set(u.ch), subSet = new Set(u.sub.flatMap(s2 => s2[0])), fgSet = new Set(u.fg || []);
      // chain halo
      if (st >= 1) { const k = st === 1 ? Math.min(1, anim) : 1, n = Math.max(1, Math.round(k * (u.ch.length - 1))); g.strokeStyle = 'rgba(45,111,214,.28)'; g.lineWidth = 26; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); u.ch.slice(0, n + 1).forEach((ci, j) => { const [x, y] = P(ci); j ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke(); g.lineCap = 'butt'; }
      // bonds
      u.b.forEach(([i, j, o]) => { const [xa, ya] = P(i), [xb, yb] = P(j), dx = xb - xa, dy = yb - ya, l = Math.hypot(dx, dy), ux = dx / l, uy = dy / l, nx = -uy, ny = ux, sh = 17; const hot = st >= 3 && fgSet.has(i) && fgSet.has(j); g.strokeStyle = hot ? KCOL.f : col.fg; g.lineWidth = hot ? 2.4 : 1.6; const offs = (o || 1) === 1 ? [0] : o === 2 ? [-3, 3] : [-4.5, 0, 4.5]; offs.forEach(of => { g.beginPath(); g.moveTo(xa + ux * sh + nx * of, ya + uy * sh + ny * of); g.lineTo(xb - ux * sh + nx * of, yb - uy * sh + ny * of); g.stroke(); }); });
      // atoms
      u.a.forEach((a, i) => { const [x, y] = P(i), lab = label(u, i); let cc = col.fg; if (st >= 3 && subSet.has(i)) cc = KCOL.s; if (st >= 3 && fgSet.has(i)) cc = KCOL.f; if (a[0] === 'O') cc = st >= 3 ? KCOL.f : '#cc2418'; if (a[0] === 'Br') cc = st >= 3 ? KCOL.s : '#86280f'; g.font = `bold 13px ${col.font}`; const tw = g.measureText(lab).width; g.fillStyle = col.sf; g.fillRect(x - tw / 2 - 2, y - 9, tw + 4, 18); g.fillStyle = cc; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(lab, x, y); g.textBaseline = 'alphabetic'; });
      // numbering
      if (st >= 2) { const k = st === 2 ? anim : 1; u.ch.forEach((ci, j) => { if (j / u.ch.length > k) return; const [x, y] = P(ci); const up = y - 22 < 12 ? 24 : -22; M3.sphere(g, x + 14, y + up, 8, '#2d6fd6', '#a9c8ff'); g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(j + 1), x + 14, y + up + 3.5); }); }
      // substituent tags
      if (st >= 3) u.sub.forEach(([atoms, nm2]) => { const [x, y] = P(atoms[atoms.length - 1]); g.fillStyle = KCOL.s; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(nm2, x, y + (y > oy ? 22 : -16)); });
      // name
      if (st >= 4) { const k = Math.min(1, anim); g.font = `bold 18px ${col.font}`; const parts = IU[ix].parts, ws = parts.map(p => g.measureText(p[0]).width), tot = ws.reduce((a2, b2) => a2 + b2, 0); let x = W / 2 - tot / 2; parts.forEach((p, j) => { g.globalAlpha = Math.max(0, Math.min(1, k * parts.length - j)); g.fillStyle = KCOL[p[1]]; g.textAlign = 'left'; g.fillText(p[0], x, H - 14); x += ws[j]; }); g.globalAlpha = 1; }
      else { g.fillStyle = col.mu; g.font = `11px ${col.font}`; g.textAlign = 'center'; g.fillText(['ধাপ ১ দিয়ে শুরু করো', 'ধাপ ১: দীর্ঘতম শিকল', 'ধাপ ২: নম্বর প্রদান', 'ধাপ ৩: শাখা ও কার্যকরী মূলক'][st], W / 2, H - 14); }
    };
    const info = () => { const u = IU[ix]; q('[data-st]').textContent = `ধাপ ${bn(st)}/৪`; const T = ['', u.r1, u.r2, (u.sub.length ? 'শাখা: ' + u.sub.map(s2 => `${s2[1]} (C-${bn(s2[2])})`).join(', ') + '। ' : 'কোনো শাখা নেই। ') + (u.fg ? 'প্রধান কার্যকরী মূলক/বহুবন্ধন সবুজ রঙে।' : ''), (u.r4 ? u.r4 + ' ' : '') + `পূর্ণ নাম: <b>${u.nm}</b>`]; out.innerHTML = st ? `<div><b>ধাপ ${bn(st)}:</b> ${T[st]}</div>` : '<div class="small">"পরের ধাপ" চাপো।</div>'; };
    const quiz = () => { const u = IU[ix]; quizDone = false; const ch = [u.nm].concat(u.wrong).sort(() => Math.random() - 0.5); opts.innerHTML = '<span class="small" style="width:100%">সঠিক IUPAC নাম কোনটি?</span>' + ch.map(n2 => `<button class="btn sm" data-n="${n2}">${n2}</button>`).join(''); opts.querySelectorAll('[data-n]').forEach(b => { b.onclick = () => { if (quizDone) return; quizDone = true; const ok = b.dataset.n === u.nm; opts.querySelectorAll('[data-n]').forEach(bb => { if (bb.dataset.n === u.nm) bb.classList.add('primary'); }); if (!ok) b.style.textDecoration = 'line-through'; st = 4; anim = 0; info(); out.innerHTML = `<div style="font-weight:700;color:${ok ? 'var(--ok)' : 'var(--bad)'}">${ok ? '✓ সঠিক!' : '✗ সঠিক নাম: ' + u.nm}</div>` + out.innerHTML; }; }); };
    const reset = () => { st = 0; anim = 1; info(); if (md === 'quiz') quiz(); else opts.innerHTML = ''; };
    const A = X.anim(el, dt => { if (dt) { t += dt; anim = Math.min(1.2, anim + dt * 1.2); } draw(); }, { paused: false });
    q('[data-sel]').onchange = e => { ix = +e.target.value; reset(); };
    q('[data-nx]').onclick = () => { if (st < 4) { st++; anim = 0; info(); } };
    q('[data-pv]').onclick = () => { if (st > 0) { st--; anim = 1; info(); } };
    X.onSeg(el, 'md', v => { md = v; reset(); });
    reset(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
