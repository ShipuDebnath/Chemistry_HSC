/* ২য় পত্র অধ্যায় ২ visuals part 1 — M3: 3D molecular engine (builder with VSEPR hydrogen placement, ball-and-stick / space-filling / stick renderer, orbital lobes, measurements) */
(function () {
'use strict';
const X = window.VX;
const M3 = window.M3 = {};
/* ---------- vector helpers ---------- */
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const len = a => Math.hypot(a[0], a[1], a[2]), norm = a => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }, neg = a => [-a[0], -a[1], -a[2]];
const perp = a => { const t = Math.abs(a[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0]; return norm(cross(a, t)); };
M3.v = { add, sub, mul, dot, cross, len, norm, neg, perp };
/* ---------- elements: [base colour, highlight, ball radius (Å, ball-and-stick), vdW radius (Å), standard valence, valence electrons, name] ---------- */
const EL = M3.EL = {
  H: ['#cfcfcf', '#ffffff', 0.25, 1.20, 1, 1, 'হাইড্রোজেন'],
  C: ['#303030', '#9a9a9a', 0.38, 1.70, 4, 4, 'কার্বন'],
  N: ['#2a4fc4', '#a8bcff', 0.36, 1.55, 3, 5, 'নাইট্রোজেন'],
  O: ['#cc2418', '#ffa49a', 0.35, 1.52, 2, 6, 'অক্সিজেন'],
  F: ['#56b833', '#d3f7b5', 0.32, 1.47, 1, 7, 'ফ্লোরিন'],
  Cl: ['#1c9a1c', '#a5eca5', 0.46, 1.75, 1, 7, 'ক্লোরিন'],
  Br: ['#86280f', '#e5a184', 0.50, 1.85, 1, 7, 'ব্রোমিন'],
  I: ['#5b1b8c', '#c99af2', 0.56, 1.98, 1, 7, 'আয়োডিন'],
  S: ['#cfae14', '#fff39a', 0.46, 1.80, 2, 6, 'সালফার'],
  P: ['#e07b10', '#ffc98a', 0.46, 1.80, 3, 5, 'ফসফরাস'],
  Si: ['#b08d6a', '#efd9c0', 0.50, 2.10, 4, 4, 'সিলিকন'],
  Na: ['#8a3fd1', '#d5aef7', 0.55, 2.27, 1, 1, 'সোডিয়াম'],
  Mg: ['#2c9b45', '#a7e9b5', 0.50, 1.73, 2, 2, 'ম্যাগনেসিয়াম'],
  X: ['#e0a020', '#ffe2a0', 0.30, 1.50, 1, 1, '']
};
/* experimental bond lengths (Å) by pair and order */
const BL = { CC: [1.54, 1.34, 1.20], CH: [1.09], CO: [1.43, 1.21, 1.13], CN: [1.47, 1.28, 1.16], NH: [1.01], OH: [0.96], NO: [1.40, 1.21], NN: [1.45, 1.25, 1.10], CCl: [1.77], CBr: [1.94], CI: [2.14], CF: [1.35], CS: [1.82, 1.60], SH: [1.34], SO: [1.57, 1.43], OO: [1.48, 1.21], HH: [0.74], ClCl: [1.99], BrBr: [2.28], SiSi: [2.35], SiH: [1.48], OP: [1.60, 1.48], CMg: [2.10], MgBr: [2.40], CNa: [2.2] };
M3.bondLen = (e1, e2, o = 1) => { const k = [e1, e2].sort().join(''), k2 = e1 + e2, k3 = e2 + e1, t = BL[k2] || BL[k3] || BL[k]; if (o === 1.5) return e1 === 'C' && e2 === 'C' ? 1.39 : 1.35; if (t) return t[Math.min(t.length, Math.round(o)) - 1]; const r = (EL[e1] || EL.X)[3] * 0.45 + (EL[e2] || EL.X)[3] * 0.45; return r * (o === 2 ? 0.87 : o === 3 ? 0.78 : 1); };
/* zig-zag chain skeleton coordinates (sp³, 109.5°, 1.54 Å) */
M3.zig = (n, opt = {}) => { const d = opt.d || 1.54, h = d * Math.sin(109.47 * Math.PI / 360), v = d * Math.cos(109.47 * Math.PI / 360); const o = []; for (let i = 0; i < n; i++) o.push([i * h, i % 2 ? v : 0, 0]); return o; };
/* ---------- builder ---------- */
/* spec: { a: [[el, x, y, z, {q, lp, nH, geo, rad, pn, stag}]...], b: [[i, j, order]...], H: true }  (heavy-atom coordinates in Å) */
M3.mol = spec => {
  const m = { a: [], b: [], name: spec.name || '' };
  spec.a.forEach(r => { const o = r[4] || {}; m.a.push(Object.assign({ el: r[0], p: [r[1], r[2], r[3]] }, o)); });
  spec.b.forEach(r => m.b.push({ i: r[0], j: r[1], o: r[2] || 1, st: r[3] || '' }));
  if (spec.H !== false) addH(m, spec);
  bondOffsets(m); center(m);
  return m;
};
const nbrs = (m, i) => m.b.filter(b => b.i === i || b.j === i).map(b => b.i === i ? b.j : b.i);
M3.nbrs = nbrs;
function addH(m, spec) {
  const n0 = m.a.length;
  for (let i = 0; i < n0; i++) {
    const A = m.a[i]; if (A.el === 'H' || A.noH) continue;
    const E = EL[A.el] || EL.X, q = A.q || 0;
    let bonds = A.el === 'C' || A.el === 'Si' ? 4 - Math.abs(q) : E[4] + q; if (A.rad) bonds -= 1;
    let lp = A.lp != null ? A.lp : Math.max(0, Math.round((E[5] - q - bonds - (A.rad ? 1 : 0)) / 2));
    const bs = m.b.filter(b => b.i === i || b.j === i), s = bs.reduce((t, b) => t + b.o, 0), nb = nbrs(m, i);
    const nH = A.nH != null ? A.nH : Math.max(0, Math.round(bonds - s));
    const extra = (A.rad ? 1 : 0) + (A.el === 'C' && q > 0 ? 1 : 0); // radical / empty p counted for planar geometry (C⁺ is sp²)
    let ster = nb.length + nH + lp;
    let geo = A.geo || (bs.some(b => b.o === 3) || bs.filter(b => b.o === 2).length === 2 ? 'lin' : bs.some(b => b.o === 2 || b.o === 1.5) || (A.el === 'C' && (q > 0 || A.rad)) ? 'tri' : ster >= 4 ? 'tet' : ster === 3 ? 'tri' : 'lin');
    if (A.el === 'C' && q > 0) { ster = nb.length + nH; geo = 'tri'; }
    if (A.rad && A.el === 'C') geo = 'tri';
    if (geo === 'tri' && lp > 0 && A.el !== 'C' && bs.some(b => b.o === 2)) { /* carbonyl O: 2 lone pairs in plane */ }
    const slots = geo === 'tet' ? 4 : geo === 'tri' ? 3 : 2, need = Math.max(0, Math.min(slots - nb.length, nH + lp));
    const Ev = nb.map(j => norm(sub(m.a[j].p, A.p)));
    let ref = null; if (nb.length === 1) { const j = nb[0], oth = nbrs(m, j).filter(k => k !== i); if (oth.length) ref = sub(m.a[oth[0]].p, m.a[j].p); }
    const dirs = newDirs(Ev, geo, need, ref, A);
    A.lps = [];
    dirs.forEach((d, k) => { if (k < nH) { const h = m.a.length; m.a.push({ el: 'H', p: add(A.p, mul(d, M3.bondLen(A.el, 'H'))) }); m.b.push({ i, j: h, o: 1 }); } else A.lps.push(d); });
    if (geo === 'tri' && (A.el === 'C' && (q !== 0 || A.rad) || A.pz)) { const n = Ev.length + dirs.length >= 2 ? norm(cross(Ev[0] || dirs[0], Ev[1] || dirs[Ev.length ? 0 : 1])) : [0, 0, 1]; A.pzDir = n; }
    void extra;
  }
}
function newDirs(Ev, geo, k, ref, A) {
  if (k <= 0) return [];
  const n = Ev.length;
  if (geo === 'lin') { if (n >= 1) return [neg(Ev[0])]; return [[1, 0, 0], [-1, 0, 0]].slice(0, k); }
  if (geo === 'tri') {
    if (n >= 2) return [neg(norm(add(Ev[0], Ev[1])))];
    if (n === 1) { let pn = A.pn || null; if (!pn && ref) { const c = cross(Ev[0], ref); if (len(c) > 1e-3) pn = norm(c); } if (!pn) { pn = Math.abs(Ev[0][2]) < 0.9 ? [0, 0, 1] : [0, 1, 0]; } const p = norm(cross(pn, Ev[0])); const a = mul(Ev[0], -0.5), r = mul(p, Math.sqrt(3) / 2); return [add(a, r), sub(a, r)].slice(0, k); }
    return [[1, 0, 0], [-0.5, 0.866, 0], [-0.5, -0.866, 0]].slice(0, k);
  }
  // tetrahedral
  if (n >= 3) return [neg(norm(add(add(Ev[0], Ev[1]), Ev[2])))];
  if (n === 2) { const b = neg(norm(add(Ev[0], Ev[1]))), nn = norm(cross(Ev[0], Ev[1])), ca = Math.cos(54.75 * Math.PI / 180), sa = Math.sin(54.75 * Math.PI / 180); return [add(mul(b, ca), mul(nn, sa)), sub(mul(b, ca), mul(nn, sa))].slice(0, k); }
  if (n === 1) { const a = neg(Ev[0]); let p; if (ref) { const r = sub(ref, mul(a, dot(ref, a))); p = len(r) > 1e-3 ? norm(r) : perp(a); } else p = A.pref ? norm(sub(A.pref, mul(a, dot(A.pref, a)))) : perp(a); const qv = cross(a, p), off = ref ? (A.stag === false ? 0 : Math.PI / 3) : 0; const o = []; for (let t = 0; t < 3; t++) { const f = off + t * 2 * Math.PI / 3; o.push(add(mul(a, 1 / 3), mul(add(mul(p, Math.cos(f)), mul(qv, Math.sin(f))), Math.sqrt(8 / 9)))); } return o.slice(0, k); }
  const s = 1 / Math.sqrt(3); return [[s, s, s], [-s, -s, s], [-s, s, -s], [s, -s, -s]].slice(0, k);
}
function bondOffsets(m) {
  m.b.forEach(b => { if (b.o === 1) return; const A = m.a[b.i], B = m.a[b.j], d = norm(sub(B.p, A.p)); let u = null; const cand = nbrs(m, b.i).filter(k => k !== b.j).concat(nbrs(m, b.j).filter(k => k !== b.i)); for (const k of cand) { const base = nbrs(m, b.i).includes(k) ? A.p : B.p, v = sub(m.a[k].p, base), r = sub(v, mul(d, dot(v, d))); if (len(r) > 0.1) { u = norm(r); break; } } if (b.o === 1.5 && m.ring) { const mid = mul(add(A.p, B.p), 0.5), r = sub(m.ring, mid); u = norm(sub(r, mul(d, dot(r, d)))); } b.u = u || perp(d); });
}
function center(m) { const c = [0, 0, 0]; m.a.forEach(a => { c[0] += a.p[0]; c[1] += a.p[1]; c[2] += a.p[2]; }); m.c = mul(c, 1 / m.a.length); m.R = Math.max(...m.a.map(a => len(sub(a.p, m.c)) + (EL[a.el] || EL.X)[2])); }
M3.center = center; M3.offsets = bondOffsets;
M3.clone = m => { const o = { a: m.a.map(a => Object.assign({}, a, { p: a.p.slice(), lps: a.lps ? a.lps.map(v => v.slice()) : [] })), b: m.b.map(b => Object.assign({}, b)), c: m.c.slice(), R: m.R, name: m.name, ring: m.ring }; return o; };
M3.formula = m => { const c = {}; m.a.forEach(a => { c[a.el] = (c[a.el] || 0) + 1; }); const sub_ = '₀₁₂₃₄₅₆₇₈₉', s = n => n > 1 ? String(n).split('').map(d => sub_[d]).join('') : ''; const order = ['C', 'H'].filter(e => c[e]).concat(Object.keys(c).filter(e => e !== 'C' && e !== 'H').sort()); return order.map(e => e + s(c[e])).join(''); };
M3.mass = m => { const W = { H: 1.008, C: 12.011, N: 14.007, O: 15.999, F: 19.0, Cl: 35.45, Br: 79.9, I: 126.9, S: 32.06, P: 30.97, Si: 28.09, Na: 22.99, Mg: 24.31 }; return m.a.reduce((t, a) => t + (W[a.el] || 0), 0); };
/* ---------- camera / projection ---------- */
M3.cam = (o = {}) => Object.assign({ yaw: 0.6, pitch: 0.35, roll: 0, sc: 40, cx: 0, cy: 0, D: 16, user: false }, o);
M3.projector = (cam, c0) => { const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw), cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch), cr = Math.cos(cam.roll || 0), sr = Math.sin(cam.roll || 0), c = c0 || [0, 0, 0]; return p => { let x = p[0] - c[0], y = -(p[1] - c[1]), z = p[2] - c[2]; let x1 = x * cy + z * sy, z1 = -x * sy + z * cy; let y1 = y * cp - z1 * sp, z2 = y * sp + z1 * cp; const x2 = x1 * cr - y1 * sr, y2 = x1 * sr + y1 * cr; const f = cam.D / (cam.D - z2); return [cam.cx + x2 * cam.sc * f, cam.cy + y2 * cam.sc * f, z2, f]; }; };
M3.fit = (m, cam, W, H, pad = 0.9) => { cam.sc = Math.min(W, H) / 2 / (m.R + 0.4) * pad; return cam; };
const shade = (hex, k) => { const n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255, f = v => Math.max(0, Math.min(255, Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k))); return `rgb(${f(r)},${f(g)},${f(b)})`; };
M3.shade = shade;
/* shaded sphere with specular highlight */
const sphere = M3.sphere = (g, x, y, r, base, hi, alpha = 1) => {
  if (r <= 0.3) return; g.save(); g.globalAlpha *= alpha;
  const gr = g.createRadialGradient(x - r * 0.38, y - r * 0.42, r * 0.05, x - r * 0.1, y - r * 0.1, r * 1.05);
  gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.12, hi); gr.addColorStop(0.62, base); gr.addColorStop(1, shade(base, -0.55));
  g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); g.strokeStyle = 'rgba(0,0,0,.28)'; g.lineWidth = 0.6; g.stroke(); g.restore();
};
/* cylinder-looking stick between two screen points */
const stick = (g, x1, y1, x2, y2, w, c1, c2) => {
  const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
  [[x1, y1, mx, my, c1], [mx, my, x2, y2, c2]].forEach(([a, b, c, d, col]) => { g.lineCap = 'butt'; g.strokeStyle = shade(col, -0.45); g.lineWidth = w; g.beginPath(); g.moveTo(a, b); g.lineTo(c, d); g.stroke(); g.strokeStyle = col; g.lineWidth = w * 0.62; g.beginPath(); g.moveTo(a, b); g.lineTo(c, d); g.stroke(); g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = w * 0.2; const dx = d - b, dy = -(c - a), l = Math.hypot(dx, dy) || 1, ox = dx / l * w * 0.18, oy = dy / l * w * 0.18; g.beginPath(); g.moveTo(a - ox, b - oy); g.lineTo(c - ox, d - oy); g.stroke(); });
};
M3.stick = stick;
/* orbital lobe: teardrop from origin along dir */
M3.lobeShape = (g, p0, p1, wpx, fill, alpha, stroke) => {
  const dx = p1[0] - p0[0], dy = p1[1] - p0[1], L = Math.hypot(dx, dy);
  g.save(); g.globalAlpha *= alpha;
  if (L < wpx * 0.55) { const r = Math.max(wpx * 0.55, L); const gr = g.createRadialGradient(p0[0] + dx * 0.5 - r * 0.3, p0[1] + dy * 0.5 - r * 0.3, r * 0.1, p0[0] + dx * 0.5, p0[1] + dy * 0.5, r); gr.addColorStop(0, shade(fill, 0.55)); gr.addColorStop(1, fill); g.fillStyle = gr; g.beginPath(); g.arc(p0[0] + dx * 0.5, p0[1] + dy * 0.5, r, 0, 7); g.fill(); if (stroke) { g.strokeStyle = stroke; g.lineWidth = 0.8; g.stroke(); } g.restore(); return; }
  const a = Math.atan2(dy, dx); g.translate(p0[0], p0[1]); g.rotate(a);
  const w = wpx / 2; g.beginPath(); g.moveTo(0, 0); g.bezierCurveTo(L * 0.18, -w * 1.05, L * 0.95, -w * 1.15, L, 0); g.bezierCurveTo(L * 0.95, w * 1.15, L * 0.18, w * 1.05, 0, 0);
  const gr = g.createLinearGradient(0, -w, 0, w); gr.addColorStop(0, shade(fill, 0.5)); gr.addColorStop(0.45, fill); gr.addColorStop(1, shade(fill, -0.35)); g.fillStyle = gr; g.fill(); if (stroke) { g.strokeStyle = stroke; g.lineWidth = 0.8; g.stroke(); }
  g.restore();
};
/* ---------- renderer ---------- */
/* opt: { mode: 'bs'|'sf'|'st'|'wf', labels: 'hetero'|'all'|false, hl: {idx: colour}, dim: Set, lp: bool, extra: [{z, draw(g, P)}], lobes: [{o, d, len, w, col, a}], measure: [[i,j] | [i,j,k] | [i,j,k,l]], col, alpha: {idx: a}, charges: {idx: q} } */
M3.render = (g, m, cam, opt = {}) => {
  const col = opt.col || X.C(), mode = opt.mode || 'bs', P = M3.projector(cam, opt.center || m.c);
  const S = m.a.map(a => P(a.p)), items = [];
  const rad = (a, f) => { const e = EL[a.el] || EL.X; return (mode === 'sf' ? e[3] * 0.92 : mode === 'st' ? 0.13 : mode === 'wf' ? 0 : e[2] * (opt.ballScale || 1)) * cam.sc * f; };
  if (mode !== 'sf') m.b.forEach((b, bi) => {
    const A = m.a[b.i], B = m.a[b.j], pa = S[b.i], pb = S[b.j], z = (pa[2] + pb[2]) / 2, f = (pa[3] + pb[3]) / 2;
    items.push({ z: z - 0.01, draw: () => {
      const ca = (EL[A.el] || EL.X)[0], cb = (EL[B.el] || EL.X)[0], dimmed = opt.dim && (opt.dim.has(b.i) || opt.dim.has(b.j)), w = (mode === 'st' ? 0.26 : 0.17) * cam.sc * f, bc = opt.bondCol && opt.bondCol[bi];
      g.save(); if (dimmed) g.globalAlpha *= 0.18; if (opt.alpha && (opt.alpha[b.i] != null || opt.alpha[b.j] != null)) g.globalAlpha *= Math.min(opt.alpha[b.i] ?? 1, opt.alpha[b.j] ?? 1);
      if (b.st === 'dash') { g.setLineDash([4, 4]); g.strokeStyle = bc || '#e67e22'; g.lineWidth = Math.max(1.5, w * 0.45); g.beginPath(); g.moveTo(pa[0], pa[1]); g.lineTo(pb[0], pb[1]); g.stroke(); g.setLineDash([]); g.restore(); return; }
      if (mode === 'wf') { g.strokeStyle = bc || col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(pa[0], pa[1]); g.lineTo(pb[0], pb[1]); g.stroke(); g.restore(); return; }
      const cA = bc || (A.el === 'C' ? '#5a5a5a' : ca === '#cfcfcf' ? '#bdbdbd' : ca), cB = bc || (B.el === 'C' ? '#5a5a5a' : cb === '#cfcfcf' ? '#bdbdbd' : cb);
      if (b.o === 1 || mode === 'st' && b.o !== 1.5 && !opt.multi) stick(g, pa[0], pa[1], pb[0], pb[1], w, cA, cB);
      else {
        const u = b.u || [0, 0, 1], offs = b.o === 2 ? [-0.11, 0.11] : b.o === 3 ? [-0.15, 0, 0.15] : [0, 0.17];
        offs.forEach((o, k) => { const qa = P(add(A.p, mul(u, o))), qb = P(add(B.p, mul(u, o))); if (b.o === 1.5 && k === 1) { const sh = 0.18, qa2 = P(add(A.p, add(mul(u, o), mul(norm(sub(B.p, A.p)), sh)))), qb2 = P(add(B.p, add(mul(u, o), mul(norm(sub(A.p, B.p)), sh)))); g.setLineDash([3, 3]); g.strokeStyle = col.mu; g.lineWidth = 1.6; g.beginPath(); g.moveTo(qa2[0], qa2[1]); g.lineTo(qb2[0], qb2[1]); g.stroke(); g.setLineDash([]); } else stick(g, qa[0], qa[1], qb[0], qb[1], w * (b.o === 1 ? 1 : 0.62), cA, cB); });
      }
      if (b.st === 'dash' || b.st === 'partial') { /* partial bond in TS */ }
      g.restore();
    } });
  });
  m.a.forEach((a, i) => {
    const p = S[i]; items.push({ z: p[2], draw: () => {
      const e = EL[a.el] || EL.X, r = rad(a, p[3]); const dimmed = opt.dim && opt.dim.has(i); g.save(); if (dimmed) g.globalAlpha *= 0.18; if (opt.alpha && opt.alpha[i] != null) g.globalAlpha *= opt.alpha[i];
      if (opt.hl && opt.hl[i]) { const rr = Math.max(r, 6) * 1.55 + 3; const gl = g.createRadialGradient(p[0], p[1], rr * 0.4, p[0], p[1], rr); gl.addColorStop(0, opt.hl[i] + 'aa'); gl.addColorStop(1, opt.hl[i] + '00'); g.fillStyle = gl; g.beginPath(); g.arc(p[0], p[1], rr, 0, 7); g.fill(); }
      if (opt.charges && opt.charges[i]) { const qv = opt.charges[i], rr = Math.max(r, 6) * 1.9; const gl = g.createRadialGradient(p[0], p[1], r * 0.5, p[0], p[1], rr); gl.addColorStop(0, qv < 0 ? 'rgba(220,40,40,.45)' : 'rgba(40,90,230,.45)'); gl.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gl; g.beginPath(); g.arc(p[0], p[1], rr, 0, 7); g.fill(); }
      if (mode !== 'wf') sphere(g, p[0], p[1], r, e[0], e[1], mode === 'sf' ? 1 : 1);
      const lab = opt.labels === 'all' || (opt.labels !== false && a.el !== 'C' && a.el !== 'H') || (opt.labels === 'num' && a.el === 'C');
      if (lab && mode !== 'sf' && r > 4) { g.fillStyle = a.el === 'H' || a.el === 'S' || a.el === 'F' ? '#222' : '#fff'; g.font = `bold ${Math.max(8, Math.round(r * 0.85))}px ${col.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(a.lab || a.el, p[0], p[1] + 0.5); g.textBaseline = 'alphabetic'; }
      if (mode === 'wf' && a.el !== 'C') { g.fillStyle = e[0]; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(a.el, p[0], p[1]); g.textBaseline = 'alphabetic'; }
      if (a.q && opt.showQ !== false) { const s = a.q > 0 ? '+' : '−'; g.fillStyle = a.q > 0 ? '#2d6fd6' : '#c0392b'; g.font = `bold ${Math.max(11, r * 0.8)}px ${col.font}`; g.textAlign = 'left'; g.fillText(s, p[0] + r * 0.7, p[1] - r * 0.6); }
      g.restore();
    } });
    if (opt.lp && a.lps && a.lps.length) a.lps.forEach(d => { const o2 = add(a.p, mul(d, 0.55)), pe = P(o2); items.push({ z: pe[2], draw: () => { M3.lobeShape(g, P(add(a.p, mul(d, 0.12))), P(add(a.p, mul(d, 0.95))), 0.5 * cam.sc * pe[3], '#e8c21a', 0.55, 'rgba(120,90,0,.5)'); const pp = P(add(a.p, mul(d, 0.62))), n = norm(cross(d, perp(d))); const e1 = P(add(add(a.p, mul(d, 0.62)), mul(n, 0.09))), e2 = P(sub(add(a.p, mul(d, 0.62)), mul(n, 0.09))); void pp; g.fillStyle = '#3a2a00'; [e1, e2].forEach(q => { g.beginPath(); g.arc(q[0], q[1], Math.max(1.4, 0.045 * cam.sc * q[3]), 0, 7); g.fill(); }); } }); });
  });
  (opt.lobes || []).forEach(L => { const pe = P(add(L.o, mul(L.d, L.len * 0.5))); items.push({ z: pe[2] + (L.dz || 0), draw: () => M3.lobeShape(g, P(L.o), P(add(L.o, mul(L.d, L.len))), L.w * cam.sc * pe[3], L.col, L.a == null ? 0.6 : L.a, L.stroke) }); });
  (opt.extra || []).forEach(e => items.push({ z: e.z3 ? P(e.z3)[2] : e.z, draw: () => e.draw(g, P) }));
  items.sort((u, v) => u.z - v.z).forEach(it => it.draw());
  (opt.measure || []).forEach(mm => M3.measure(g, m, P, mm, col));
  return { S, P };
};
M3.measure = (g, m, P, mm, col) => {
  const pts = mm.map(i => m.a[i].p), sp = pts.map(P); g.save(); g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center';
  const tag = (x, y, s, c) => { const w = g.measureText(s).width + 8; g.fillStyle = col.sf; g.globalAlpha = 0.9; g.fillRect(x - w / 2, y - 9, w, 14); g.globalAlpha = 1; g.strokeStyle = c; g.lineWidth = 1; g.strokeRect(x - w / 2, y - 9, w, 14); g.fillStyle = c; g.fillText(s, x, y + 2); };
  if (mm.length === 2) { const d = len(sub(pts[0], pts[1])) * 100; g.strokeStyle = '#e67e22'; g.setLineDash([4, 3]); g.lineWidth = 1.4; g.beginPath(); g.moveTo(sp[0][0], sp[0][1]); g.lineTo(sp[1][0], sp[1][1]); g.stroke(); g.setLineDash([]); tag((sp[0][0] + sp[1][0]) / 2, (sp[0][1] + sp[1][1]) / 2 - 10, `${X.bn(Math.round(d))} pm`, '#e67e22'); }
  if (mm.length === 3) { const u = norm(sub(pts[0], pts[1])), v = norm(sub(pts[2], pts[1])), ang = Math.acos(Math.max(-1, Math.min(1, dot(u, v)))) * 180 / Math.PI; const arc = []; for (let t = 0; t <= 1.0001; t += 0.1) { const w = norm(add(mul(u, 1 - t), mul(v, t))); arc.push(P(add(pts[1], mul(w, 0.45)))); } g.strokeStyle = '#8e44ad'; g.lineWidth = 2; g.beginPath(); arc.forEach((q, k) => k ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1])); g.stroke(); const mid = P(add(pts[1], mul(norm(add(u, v)), 0.8))); tag(mid[0], mid[1], `${X.bn(ang.toFixed(1))}°`, '#8e44ad'); }
  if (mm.length === 4) { const b1 = sub(pts[1], pts[0]), b2 = sub(pts[2], pts[1]), b3 = sub(pts[3], pts[2]), n1 = cross(b1, b2), n2 = cross(b2, b3), m1 = cross(n1, norm(b2)); const ang = Math.atan2(dot(m1, n2), dot(n1, n2)) * 180 / Math.PI; const mid = P(mul(add(pts[1], pts[2]), 0.5)); tag(mid[0], mid[1] - 16, `দ্বিতল কোণ ${X.bn(Math.round(ang))}°`, '#16a085'); }
  g.restore();
};
/* pick nearest atom on screen */
M3.pick = (S, m, x, y, rmin = 10) => { let best = -1, bd = 1e9; S.forEach((p, i) => { const d = Math.hypot(p[0] - x, p[1] - y); if (d < Math.max(rmin, 14) && d < bd && (best < 0 || p[2] > S[best][2] - 0.3)) { bd = d; best = i; } }); return best; };
/* rotate a set of atoms about an axis (i→j bond), used for conformers */
M3.rotateAbout = (m, i, j, set, ang) => { const o = m.a[i].p, ax = norm(sub(m.a[j].p, o)), c = Math.cos(ang), s = Math.sin(ang); set.forEach(k => { const v = sub(m.a[k].p, o), d = dot(ax, v), cr = cross(ax, v); m.a[k].p = add(o, add(add(mul(v, c), mul(cr, s)), mul(ax, d * (1 - c)))); }); };
/* atoms on j's side of bond i–j */
M3.side = (m, i, j) => { const seen = new Set([i, j]), st = [j], out = []; while (st.length) { const k = st.pop(); nbrs(m, k).forEach(n => { if (!seen.has(n)) { seen.add(n); out.push(n); st.push(n); } }); } return out; };
/* linear interpolation between two molecules with identical atom lists */
M3.lerp = (m1, m2, t) => { const o = M3.clone(m1); o.a.forEach((a, k) => { a.p = add(mul(m1.a[k].p, 1 - t), mul(m2.a[k].p, t)); }); return o; };
/* standard library of molecules used across the chapter */
const LIB = M3.LIB = {};
const Z = (n, o) => M3.zig(n, o);
LIB.methane = () => M3.mol({ name: 'মিথেন', a: [['C', 0, 0, 0]], b: [] });
LIB.ethane = () => M3.mol({ name: 'ইথেন', a: [['C', 0, 0, 0], ['C', 1.54, 0, 0]], b: [[0, 1, 1]] });
LIB.ethene = () => M3.mol({ name: 'ইথিন', a: [['C', 0, 0, 0], ['C', 1.34, 0, 0]], b: [[0, 1, 2]] });
LIB.ethyne = () => M3.mol({ name: 'ইথাইন', a: [['C', 0, 0, 0], ['C', 1.20, 0, 0]], b: [[0, 1, 3]] });
LIB.propane = () => M3.mol({ name: 'প্রোপেন', a: Z(3).map(p => ['C', ...p]), b: [[0, 1], [1, 2]] });
LIB.butane = () => M3.mol({ name: 'বিউটেন', a: Z(4).map(p => ['C', ...p]), b: [[0, 1], [1, 2], [2, 3]] });
LIB.pentane = () => M3.mol({ name: 'পেন্টেন', a: Z(5).map(p => ['C', ...p]), b: [[0, 1], [1, 2], [2, 3], [3, 4]] });
LIB.hexane = () => M3.mol({ name: 'হেক্সেন', a: Z(6).map(p => ['C', ...p]), b: [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5]] });
LIB.isobutane = () => { const c = [0, 0, 0], s = 1.54; return M3.mol({ name: '২-মিথাইলপ্রোপেন (আইসোবিউটেন)', a: [['C', ...c], ['C', 0, s, 0], ['C', s * 0.9428, -s / 3, 0], ['C', -s * 0.4714, -s / 3, s * 0.8165]], b: [[0, 1], [0, 2], [0, 3]] }); };
LIB.neopentane = () => { const s = 1.54, t = s / Math.sqrt(3); return M3.mol({ name: '২,২-ডাইমিথাইলপ্রোপেন (নিওপেন্টেন)', a: [['C', 0, 0, 0], ['C', t, t, t], ['C', -t, -t, t], ['C', -t, t, -t], ['C', t, -t, -t]], b: [[0, 1], [0, 2], [0, 3], [0, 4]] }); };
LIB.benzene = () => { const a = [], b = []; for (let k = 0; k < 6; k++) { const t = k * Math.PI / 3; a.push(['C', 1.39 * Math.cos(t), 1.39 * Math.sin(t), 0]); b.push([k, (k + 1) % 6, 1.5]); } const m = { name: 'বেনজিন' }; const mm = M3.mol({ name: 'বেনজিন', a, b }); mm.ring = [0, 0, 0]; bondOffsets(mm); void m; return mm; };
LIB.benzeneK = (alt = 0) => { const a = [], b = []; for (let k = 0; k < 6; k++) { const t = k * Math.PI / 3; a.push(['C', 1.39 * Math.cos(t), 1.39 * Math.sin(t), 0]); b.push([k, (k + 1) % 6, (k + alt) % 2 ? 1 : 2]); } const mm = M3.mol({ name: 'বেনজিন (কেকুলে)', a, b }); return mm; };
LIB.cyclohexane = () => { const a = [], b = [], R = 1.452 * 1.0; for (let k = 0; k < 6; k++) { const t = k * Math.PI / 3; a.push(['C', R * Math.cos(t), R * Math.sin(t), k % 2 ? 0.25 : -0.25]); b.push([k, (k + 1) % 6, 1]); } return M3.mol({ name: 'সাইক্লোহেক্সেন (চেয়ার)', a, b }); };
LIB.ethanol = () => { const z = Z(3, { d: 1.50 }); return M3.mol({ name: 'ইথানল', a: [['C', ...z[0]], ['C', ...z[1]], ['O', z[2][0] - 0.05, z[2][1] - 0.05, 0]], b: [[0, 1], [1, 2]] }); };
LIB.methanol = () => M3.mol({ name: 'মিথানল', a: [['C', 0, 0, 0], ['O', 1.43, 0, 0]], b: [[0, 1]] });
LIB.water = () => M3.mol({ name: 'পানি', a: [['O', 0, 0, 0, { pref: [0, 1, 0] }]], b: [] });
LIB.ammonia = () => M3.mol({ name: 'অ্যামোনিয়া', a: [['N', 0, 0, 0]], b: [] });
LIB.urea = () => M3.mol({ name: 'ইউরিয়া', a: [['C', 0, 0, 0], ['O', 0, 1.25, 0], ['N', 1.17, -0.68, 0, { geo: 'tri', pn: [0, 0, 1] }], ['N', -1.17, -0.68, 0, { geo: 'tri', pn: [0, 0, 1] }]], b: [[0, 1, 2], [0, 2, 1], [0, 3, 1]] });
LIB.ammoniumCyanate = () => { const m = M3.mol({ name: 'অ্যামোনিয়াম সায়ানেট', a: [['N', -2.4, 0, 0, { q: 1 }], ['O', 1.0, 0, 0, { q: -1, nH: 0 }], ['C', 2.26, 0, 0, { nH: 0 }], ['N', 3.43, 0, 0, { nH: 0 }]], b: [[1, 2, 1], [2, 3, 3]] }); return m; };
LIB.acetaldehyde = () => M3.mol({ name: 'ইথান্যাল', a: [['C', 0, 0, 0], ['C', 1.50, 0, 0], ['O', 2.10, 1.05, 0]], b: [[0, 1], [1, 2, 2]] });
LIB.acetone = () => M3.mol({ name: 'প্রোপানোন', a: [['C', 0, 0, 0], ['C', 1.25, 0.86, 0], ['C', 2.50, 0, 0], ['O', 1.25, 2.07, 0]], b: [[0, 1], [1, 2], [1, 3, 2]] });
LIB.aceticAcid = () => M3.mol({ name: 'ইথানয়িক এসিড', a: [['C', 0, 0, 0], ['C', 1.50, 0, 0], ['O', 2.12, 1.04, 0], ['O', 2.14, -1.12, 0, { pref: [1, 0, 0] }]], b: [[0, 1], [1, 2, 2], [1, 3]] });
LIB.methylamine = () => M3.mol({ name: 'মিথাইলঅ্যামিন', a: [['C', 0, 0, 0], ['N', 1.47, 0, 0]], b: [[0, 1]] });
LIB.chloromethane = () => M3.mol({ name: 'ক্লোরোমিথেন', a: [['C', 0, 0, 0], ['Cl', 1.77, 0, 0]], b: [[0, 1]] });
LIB.dimethylEther = () => M3.mol({ name: 'মিথক্সিমিথেন', a: [['C', -1.17, -0.4, 0], ['O', 0, 0.42, 0], ['C', 1.17, -0.4, 0]], b: [[0, 1], [1, 2]] });
LIB.co2 = () => M3.mol({ name: 'কার্বন ডাইঅক্সাইড', a: [['O', -1.16, 0, 0], ['C', 0, 0, 0], ['O', 1.16, 0, 0]], b: [[0, 1, 2], [1, 2, 2]] });
LIB.nacl = () => M3.mol({ name: 'NaCl', a: [['Na', 0, 0, 0, { noH: true }], ['Cl', 2.8, 0, 0, { noH: true }]], b: [], H: false });
})();
