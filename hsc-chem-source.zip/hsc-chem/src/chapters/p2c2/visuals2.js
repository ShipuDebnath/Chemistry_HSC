/* ২য় পত্র অধ্যায় ২ visuals part 2 — 2.0: vital force & Wöhler, catenation, organic vs inorganic */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
M3.ease = ease;
/* burner flame */
const flame = (g, x, y, s, t) => { for (let k = 0; k < 3; k++) { const h = s * (1.6 - k * 0.4) * (1 + 0.08 * Math.sin(t * 13 + k)), w = s * (0.45 - k * 0.1); const gr = g.createLinearGradient(x, y, x, y - h); gr.addColorStop(0, k === 2 ? 'rgba(80,140,255,.95)' : 'rgba(60,110,255,.7)'); gr.addColorStop(0.5, k === 0 ? 'rgba(255,170,40,.55)' : 'rgba(120,170,255,.8)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(x - w, y); g.quadraticCurveTo(x - w * 0.9, y - h * 0.5, x + Math.sin(t * 9 + k) * w * 0.2, y - h); g.quadraticCurveTo(x + w * 0.9, y - h * 0.5, x + w, y); g.closePath(); g.fill(); } };
M3.flame = flame;
const burner = (g, x, y, s, t, col, on = true) => { g.fillStyle = '#7a7f87'; g.fillRect(x - s * 0.18, y - s * 1.1, s * 0.36, s * 1.1); g.fillStyle = '#5a5f66'; rr(g, x - s * 0.6, y - s * 0.12, s * 1.2, s * 0.16, 3); g.fill(); g.fillStyle = '#9aa0a8'; g.fillRect(x - s * 0.22, y - s * 1.16, s * 0.44, s * 0.1); if (on) flame(g, x, y - s * 1.16, s * 0.55, t); void col; };
M3.burner = burner;
/* test tube (angled) */
const tube = (g, x, y, L, w, ang, fill, level, col) => { g.save(); g.translate(x, y); g.rotate(ang); if (fill && level > 0) { g.fillStyle = fill; g.beginPath(); g.moveTo(-w / 2 + 1, L - L * level); g.lineTo(-w / 2 + 1, L - w / 2); g.arc(0, L - w / 2, w / 2 - 1, Math.PI, 0, true); g.lineTo(w / 2 - 1, L - L * level); g.closePath(); g.fill(); } g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(-w / 2, 0); g.lineTo(-w / 2, L - w / 2); g.arc(0, L - w / 2, w / 2, Math.PI, 0, true); g.lineTo(w / 2, 0); g.stroke(); g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(-w / 2 + 2, 4, 3, L - w); g.restore(); };
M3.tube = tube;

/* ======================= ২.০.১ ভোলারের ইউরিয়া সংশ্লেষণ ======================= */
/* atom order: 0 N1 (ammonium N), 1 C, 2 O, 3 N2 (cyanate N), 4 Ha, 5 Hb, 6 Hc, 7 Hd */
const WS = (() => {
  const tet = (c, a0, k) => { const s = 1 / Math.sqrt(3), D = [[s, s, s], [-s, -s, s], [-s, s, -s], [s, -s, -s]]; void a0; return D.map(d => add(c, mul(d, k))); };
  const rotZ = (v, a) => [v[0] * Math.cos(a) - v[1] * Math.sin(a), v[0] * Math.sin(a) + v[1] * Math.cos(a), v[2]];
  // stage 0: NH4+ below-left, cyanate N=C=O tilted 60°
  const w = [Math.cos(Math.PI / 3), Math.sin(Math.PI / 3), 0];
  const C = [0, 0, 0], O0 = mul(w, 1.18), N20 = mul(w, -1.21);
  const N10 = [-1.25, -3.75, 0];
  const toN2 = norm(sub(N20, N10)); // Hd points at N2
  // tetrahedral H's on N1 with one along toN2
  const tetAlong = (c, d, k) => { const p = M3.v.perp(d), q = M3.v.cross(d, p), o = [add(c, mul(d, k))]; for (let t = 0; t < 3; t++) { const f = t * 2 * Math.PI / 3; o.push(add(c, mul(add(mul(d, -1 / 3), mul(add(mul(p, Math.cos(f)), mul(q, Math.sin(f))), Math.sqrt(8 / 9))), k))); } return o; };
  const h0 = tetAlong(N10, toN2, 1.03);
  const S0 = [N10, C, O0, N20, h0[1], h0[2], h0[3], h0[0]];
  // stage 1: H–N=C=O (H–N–C 124°), NH3 drifts right
  const hdDir = rotZ(norm(neg(w)), -56 * Math.PI / 180);
  function neg(v) { return [-v[0], -v[1], -v[2]]; }
  const N11 = [0.6, -3.2, 0], toC1 = norm(sub(C, N11)), h1 = tetAlong(N11, toC1, 1.01);
  const S1 = [N11, C, mul(w, 1.17), mul(w, -1.21), h1[1], h1[2], h1[3], add(mul(w, -1.21), mul(hdDir, 1.01))];
  // stage 3: urea (from library frame: C(0,0), O(0,1.25), N(±1.17,−0.68)); we rotate so O stays near cyanate O direction
  const U = M3.LIB.urea(); const ua = U.a; // C0 O1 N2(+x) N3(−x) H4,H5 on N2, H6,H7 on N3
  const rot = -Math.PI / 6; const T = v => rotZ(sub(v, ua[0].p), rot);
  const S3 = [T(ua[2].p), [0, 0, 0], T(ua[1].p), T(ua[3].p), T(ua[4].p), T(ua[5].p), T(ua[6].p), T(ua[7].p)];
  // stage 2: NH3 approaching C (N1···C 2.0 Å), HNCO bending
  const N12 = add(S3[0], mul(norm(S3[0]), 0.75)), toC2 = norm(sub(C, N12)), h2 = tetAlong(N12, toC2, 1.01);
  const S2 = [N12, C, mul(norm(add(S3[2], mul(w, 1.17))), 1.18), mul(norm(add(S3[3], mul(w, -1.21))), 1.24), h2[1], h2[2], h2[3], null];
  S2[7] = add(S2[3], mul(norm(sub(S3[7], S3[3])), 1.01));
  // assign Ha,Hb to the two final N1–H positions and Hc → N2 (proton shuttle)
  S3.splice(4, 4, S3[4], S3[5], S3[6], S3[7]);
  void tet;
  return [S0, S1, S2, S3];
})();
const WB = [
  [[0, 4, 1], [0, 5, 1], [0, 6, 1], [0, 7, 1], [3, 1, 2], [1, 2, 2]],
  [[0, 4, 1], [0, 5, 1], [0, 6, 1], [3, 7, 1], [3, 1, 2], [1, 2, 2]],
  [[0, 4, 1], [0, 5, 1], [0, 6, 1], [3, 7, 1], [3, 1, 2], [1, 2, 2], [0, 1, 1, 'dash']],
  [[0, 4, 1], [0, 5, 1], [3, 6, 1], [3, 7, 1], [3, 1, 1], [1, 2, 2], [0, 1, 1]]
];
const WQ = [{ 0: 1, 3: -1 }, {}, {}, {}];
const WST = [
  ['অ্যামোনিয়াম সায়ানেট (আয়নিক, অজৈব)', '\\ce{NH4+ + [N=C=O]-}', 'কেলাসে NH₄⁺ ও OCN⁻ আয়ন — অজৈব লবণ। পটাসিয়াম সায়ানেট ও অ্যামোনিয়াম সালফেট (বা সিলভার সায়ানেট ও অ্যামোনিয়াম ক্লোরাইড) মিশিয়ে তৈরি।'],
  ['প্রোটন স্থানান্তর (তাপে)', '\\ce{NH4+ + OCN- <=> NH3 + HNCO}', 'তাপে NH₄⁺ একটি প্রোটন (H⁺) সায়ানেট আয়নের N কে দেয় — তৈরি হয় অ্যামোনিয়া ও আইসোসায়ানিক এসিড (H–N=C=O)।'],
  ['নিউক্লিওফিলিক আক্রমণ', '\\ce{NH3 + HN=C=O -> [H3N^{+}-C(=NH)-O^{-}]}', 'NH₃ এর N এর নিঃসঙ্গ ইলেকট্রন জোড় HNCO এর ইলেকট্রন-ঘাটতি C কে আক্রমণ করে (কমলা বিন্দু রেখা = গঠনরত বন্ধন)।'],
  ['ইউরিয়া (জৈব যৌগ)', '\\ce{NH4OCN ->[\\Delta] (NH2)2CO}', 'প্রোটনের পুনর্বিন্যাসে তৈরি হয় ইউরিয়া — একই সংকেত CH₄N₂O, কিন্তু সম্পূর্ণ ভিন্ন গঠন। অজৈব লবণ থেকে প্রাণীর মূত্রের জৈব যৌগ: প্রাণশক্তি মতবাদে প্রথম বড় আঘাত।']
];
V.p2c2_wohler = {
  t: 'ভোলারের ইউরিয়া সংশ্লেষণ (১৮২৮): অজৈব অ্যামোনিয়াম সায়ানেট থেকে জৈব ইউরিয়া — ধাপে ধাপে ত্রিমাত্রিক আণবিক রূপান্তর', k: ['3d', 'anim', 'int'],
  cap: 'বাঁয়ে পরীক্ষানলে অ্যামোনিয়াম সায়ানেটের জলীয় দ্রবণ বুনসেন শিখায় উত্তপ্ত হচ্ছে; ডানে আণবিক স্তরে কী ঘটছে তার ত্রিমাত্রিক মডেল (টেনে ঘোরাও)। সময়রেখা চালাও বা ধাপ বেছে নাও: (১) NH₄⁺ ও OCN⁻ আয়ন, (২) প্রোটন স্থানান্তরে NH₃ ও আইসোসায়ানিক এসিড, (৩) NH₃ এর নিঃসঙ্গ জোড় দিয়ে কার্বনে আক্রমণ, (৪) ইউরিয়া। দুটি যৌগের আণবিক সংকেত একই (CH₄N₂O) — এরা পরস্পরের সমাণু; এই আবিষ্কারই প্রমাণ করে জৈব যৌগ তৈরিতে কোনো "প্রাণশক্তি" লাগে না।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('st', [['0', '১ আয়ন'], ['1', '২ প্রোটন স্থানান্তর'], ['2', '৩ আক্রমণ'], ['3', '৪ ইউরিয়া']], '0')}<button class="btn sm primary" data-play>▶ চালাও</button>${X.seg('md', [['bs', 'বল-স্টিক'], ['sf', 'স্থান-পূরক']], 'bs')}</div>${X.cv('ভোলারের ইউরিয়া সংশ্লেষণ')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 560;
    let L = X.fit(c, hf), s = 0, target = 0, play = false, t = 0, mode = 'bs', lastStage = -1; const cam = M3.cam({ yaw: 0.25, pitch: 0.2 });
    C4.drag3d(c, cam, () => A.draw());
    const molAt = u => { const k = Math.min(2, Math.floor(u)), f = ease(Math.min(1, u - k)), P0 = WS[k], P1 = WS[Math.min(3, k + 1)]; const st = u - k > 0.5 ? Math.min(3, k + 1) : k; const sp = { a: P0.map((p, i) => { const pp = add(mul(p, 1 - f), mul(P1[i], f)); return [i === 1 ? 'C' : i === 2 ? 'O' : i === 0 || i === 3 ? 'N' : 'H', ...pp, { q: WQ[st][i] || 0 }]; }), b: WB[st], H: false }; return M3.mol(sp); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      // lab panel
      const lx = wd ? W * 0.16 : W * 0.5, ly = wd ? H * 0.92 : 200, bs = wd ? 46 : 40;
      burner(g, lx, ly, bs, t, col, true);
      const tx = lx - 12, ty = ly - bs * 1.16 - bs * 2.6; tube(g, tx, ty, bs * 2.4, 22, -0.25, s < 2.5 ? 'rgba(170,200,255,.5)' : 'rgba(200,220,255,.45)', 0.35, col);
      for (let k = 0; k < 8; k++) { const u = (t * 0.6 + k / 8) % 1, bx = tx + 6 + Math.sin(k * 7 + t * 3) * 4 + (bs * 2.4 * 0.75) * Math.sin(0.25) * (1 - u * 0.3), by = ty + bs * 2.4 * (0.95 - u * 0.3); g.fillStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.arc(bx, by, 1.6, 0, 7); g.fill(); }
      if (s > 2.6) { g.fillStyle = 'rgba(255,255,255,.85)'; for (let k = 0; k < 10; k++) { g.fillRect(tx - 14 + (k * 37 % 13), ty + bs * 2.0 + (k * 11 % 9), 2.5, 2.5); } }
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(s < 2.5 ? 'NH₄OCN (জলীয়)' : 'ইউরিয়া কেলাস', lx, ly + 16);
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText('ফ্রিডরিখ ভোলার, ১৮২৮', lx, wd ? 22 : 18);
      // 3D molecule
      const m = molAt(s), mx = wd ? W * 0.63 : W / 2, my = wd ? H * 0.52 : 400; cam.cx = mx; cam.cy = my; cam.sc = wd ? Math.min(W * 0.075, 52) : Math.min(W * 0.11, 44);
      if (!cam.user) cam.yaw = 0.25 + Math.sin(t * 0.4) * 0.35;
      const st = Math.round(s), hl = {}; if (s > 0.6 && s < 1.4) hl[7] = '#f1c40f'; if (s > 1.6 && s < 2.6) { hl[0] = '#e67e22'; hl[1] = '#e67e22'; } if (s > 2.6) hl[6] = '#f1c40f';
      M3.render(g, m, cam, { mode, labels: 'all', hl, col, center: [0, -1.2, 0] });
      // curved arrow for electron movement in stage 2
      if (s > 1.5 && s < 2.5 && mode === 'bs') { const P = M3.projector(cam, [0, -1.2, 0]), a = P(m.a[0].p), b = P(m.a[1].p); g.strokeStyle = '#e67e22'; g.lineWidth = 2; g.beginPath(); const cxp = (a[0] + b[0]) / 2 + 30, cyp = (a[1] + b[1]) / 2; g.moveTo(a[0] + 8, a[1]); g.quadraticCurveTo(cxp, cyp, b[0] + 10, b[1] + 6); g.stroke(); const an = Math.atan2(b[1] + 6 - cyp, b[0] + 10 - cxp); g.fillStyle = '#e67e22'; g.beginPath(); g.moveTo(b[0] + 10, b[1] + 6); g.lineTo(b[0] + 10 - 8 * Math.cos(an - 0.4), b[1] + 6 - 8 * Math.sin(an - 0.4)); g.lineTo(b[0] + 10 - 8 * Math.cos(an + 0.4), b[1] + 6 - 8 * Math.sin(an + 0.4)); g.fill(); }
      // timeline
      const tx0 = wd ? W * 0.36 : 20, tw = wd ? W * 0.6 : W - 40, tyl = H - 14; g.strokeStyle = col.mu; g.lineWidth = 3; g.beginPath(); g.moveTo(tx0, tyl); g.lineTo(tx0 + tw, tyl); g.stroke(); g.strokeStyle = col.acc; g.beginPath(); g.moveTo(tx0, tyl); g.lineTo(tx0 + tw * s / 3, tyl); g.stroke(); for (let k = 0; k < 4; k++) { const x = tx0 + tw * k / 3; g.fillStyle = s >= k - 0.01 ? col.acc : col.sf; g.strokeStyle = col.acc; g.lineWidth = 1.5; g.beginPath(); g.arc(x, tyl, 6, 0, 7); g.fill(); g.stroke(); }
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(WST[st][0], mx, wd ? 20 : 268);
      if (st !== lastStage) { lastStage = st; info(st); }
    };
    const info = st => { out.innerHTML = `${TXB(WST[st][1])}<div class="small">${WST[st][2]}</div><div class="small" style="margin-top:4px">আণবিক সংকেত: NH₄OCN = CH₄N₂O = (NH₂)₂CO · মোলার ভর ৬০ g mol⁻¹ (ভর সংরক্ষিত, কেবল পরমাণুর বিন্যাস বদলেছে)</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (play) { target = Math.min(3, target + dt * 0.35); if (target >= 3) play = false; } s += (target - s) * Math.min(1, dt * 3); } draw(); }, { paused: false });
    X.onSeg(el, 'st', v => { play = false; target = +v; });
    X.onSeg(el, 'md', v => { mode = v; });
    q('[data-play]').onclick = () => { s = 0; target = 0; play = true; };
    info(0); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.০.২ কার্বনের বিশিষ্টতা: শৃঙ্খলগঠন ======================= */
const ISO = [1, 1, 1, 2, 3, 5, 9, 18, 35, 75, 159, 355, 802, 1858, 4347, 10359, 24894, 60523, 148284, 366319];
const BE = [['C–C', 346, '#303030'], ['S–S', 266, '#cfae14'], ['Si–Si', 222, '#b08d6a'], ['P–P', 201, '#e07b10'], ['N–N', 163, '#2a4fc4'], ['O–O', 146, '#cc2418']];
const adamantane = () => { const a = 0.89, b = 1.78, CH = [[a, a, a], [a, -a, -a], [-a, a, -a], [-a, -a, a]], CH2 = [[b, 0, 0], [-b, 0, 0], [0, b, 0], [0, -b, 0], [0, 0, b], [0, 0, -b]]; const at = CH.concat(CH2).map(p => ['C', ...p]), bd = []; CH.forEach((p, i) => CH2.forEach((q2, j) => { const d = Math.hypot(p[0] - q2[0], p[1] - q2[1], p[2] - q2[2]); if (d < 1.6) bd.push([i, 4 + j, 1]); })); return M3.mol({ name: 'অ্যাডামান্টেন (হীরকের ক্ষুদ্রতম একক)', a: at, b: bd }); };
const butyne = () => M3.mol({ name: 'বিউট-২-আইন', a: [['C', -2.66, 0, 0], ['C', -1.20 / 2 - 0.0, 0, 0], ['C', 0.60, 0, 0], ['C', 2.06, 0, 0]], b: [[0, 1, 1], [1, 2, 3], [2, 3, 1]] });
const chainN = n => M3.mol({ name: '', a: M3.zig(n).map(p => ['C', ...p]), b: Array.from({ length: n - 1 }, (_, i) => [i, i + 1, 1]) });
const CATM = { chain: ['সরল শৃঙ্খল', null, 'C–C একক বন্ধনে যুক্ত দীর্ঘ জিগজ্যাগ শৃঙ্খল; প্রতিটি C sp³, C–C–C কোণ ১০৯.৫°। স্লাইডারে কার্বন সংখ্যা বাড়াও।'], branch: ['শাখান্বিত', () => M3.LIB.neopentane(), 'একটি C চারটি C এর সাথে যুক্ত হতে পারে — শাখা তৈরি হয়। C₅H₁₂ এর তিনটি গাঠনিক রূপের একটি।'], ring: ['বলয় (অ্যালিসাইক্লিক)', () => M3.LIB.cyclohexane(), 'শৃঙ্খলের দুই প্রান্ত যুক্ত হয়ে বলয় — সাইক্লোহেক্সেন চেয়ার আকৃতিতে বলয় চাপমুক্ত (C–C–C ≈ ১১১°)।'], arom: ['অ্যারোমেটিক বলয়', () => M3.LIB.benzene(), 'সমতলীয় ছয় সদস্যের বলয়, সব C–C দৈর্ঘ্য সমান (১৩৯ pm) — বিস্থানীকৃত π ইলেকট্রন।'], multi: ['বহুবন্ধন', () => butyne(), 'কার্বন নিজের সাথে দ্বিবন্ধন ও ত্রিবন্ধনও গঠন করে — বিউট-২-আইনে C≡C (১২০ pm)।'], dia: ['হীরক খণ্ড', () => adamantane(), 'অ্যাডামান্টেন C₁₀H₁₆: চারটি জোড়া চেয়ার বলয় — হীরকের কেলাস জালির ক্ষুদ্রতম একক। হীরকে এই বিন্যাস ত্রিমাত্রিকভাবে অসীম পর্যন্ত চলে।'] };
V.p2c2_catenation = {
  t: 'কার্বনের শৃঙ্খলগঠন (ক্যাটিনেশন): সরল শৃঙ্খল, শাখা, বলয়, বহুবন্ধন ও হীরক — সাথে বন্ধন শক্তির তুলনা ও সমাণু সংখ্যার বিস্ফোরণ', k: ['3d', 'int'],
  cap: 'উপরের বোতাম দিয়ে কার্বন কঙ্কালের ধরন বেছে নাও; ত্রিমাত্রিক মডেল টেনে ঘোরানো যায়। "সরল শৃঙ্খল" এ স্লাইডারে কার্বন সংখ্যা n বাড়ালে CₙH₂ₙ₊₂ এর সম্ভাব্য গাঠনিক সমাণুর সংখ্যা দেখায় — n = ২০ তে তিন লক্ষের বেশি! ডানের দণ্ডলেখ সমজাতীয় একক বন্ধনের শক্তি তুলনা করে: C–C বন্ধন (৩৪৬ kJ mol⁻¹) অন্য মৌলের তুলনায় অনেক শক্তিশালী, আর কার্বনের চারটি যোজ্যতা ও ছোট আকার মিলে শৃঙ্খলগঠনের এই অসাধারণ ক্ষমতা দেয় — এ কারণেই জৈব যৌগের সংখ্যা কোটির ঘরে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ty', Object.entries(CATM).map(([k, v]) => [k, v[0]]), 'chain')}</div>${X.cv('কার্বনের শৃঙ্খলগঠন')}<div class="ctl" data-nrow><label class="small" style="flex:1">কার্বন সংখ্যা n = <b data-nv></b><input type="range" min="2" max="20" step="1" value="6" data-n></label>${X.seg('md', [['bs', 'বল-স্টিক'], ['sf', 'স্থান-পূরক'], ['wf', 'রেখা']], 'bs')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 340 : 520;
    let L = X.fit(c, hf), ty = 'chain', n = 6, mode = 'bs', m = chainN(6), t = 0; const cam = M3.cam({ yaw: 0.3, pitch: 0.35 });
    C4.drag3d(c, cam, () => A.draw());
    const rebuild = () => { m = ty === 'chain' ? chainN(n) : CATM[ty][1](); q('[data-nrow] label').style.display = ty === 'chain' ? '' : 'none'; info(); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const mw = wd ? W * 0.6 : W, mh = wd ? H : H * 0.6; cam.cx = mw / 2; cam.cy = mh / 2 + 8; M3.fit(m, cam, mw, mh - 30, 0.95);
      if (!cam.user) cam.yaw += 0.004;
      M3.render(g, m, cam, { mode, col });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${ty === 'chain' ? `n-অ্যালকেন C${bn(n)}H${bn(2 * n + 2)}` : m.name} · ${M3.formula(m)}`, mw / 2, 16);
      // bond energy chart
      const gx = wd ? W * 0.66 : 60, gy = wd ? 34 : mh + 26, gw = wd ? W * 0.31 : W - 80, gh = wd ? H * 0.5 : H - mh - 70;
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('সমজাতীয় একক বন্ধন শক্তি (kJ mol⁻¹)', gx - (wd ? 0 : 40), gy - 12);
      const bh = gh / BE.length; BE.forEach(([nm, v, cc], i) => { const y = gy + i * bh, w = gw * v / 380; g.fillStyle = cc; g.globalAlpha = nm === 'C–C' ? 1 : 0.75; rr(g, gx, y + 3, w, bh - 7, 3); g.fill(); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `${nm === 'C–C' ? 'bold ' : ''}10px ${col.font}`; g.textAlign = 'right'; g.fillText(nm, gx - 4, y + bh / 2 + 3); g.textAlign = 'left'; g.fillText(bn(v), gx + w + 4, y + bh / 2 + 3); });
      if (wd || true) { const iy = wd ? gy + gh + 30 : H - 20; const nn = ty === 'chain' ? n : null; g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = wd ? 'left' : 'center'; const tx = wd ? gx - 10 : W / 2; if (nn) { g.fillStyle = col.acc; g.font = `bold 12px ${col.font}`; g.fillText(`C${bn(nn)}H${bn(2 * nn + 2)} এর গাঠনিক সমাণু: ${bn(ISO[nn - 1].toLocaleString('en-US'))}`, tx, iy); } else { g.fillText('কার্বন: ৪ যোজ্যতা · ছোট আকার · মাঝারি তড়িৎঋণাত্মকতা', tx, iy); } }
    };
    const info = () => { out.innerHTML = `<div><b>${CATM[ty][0]}:</b> ${CATM[ty][2]}</div><div class="small" style="margin-top:4px">শৃঙ্খলগঠনের কারণ: (১) চতুর্যোজী কার্বন একসাথে চারটি বন্ধন গঠন করে, (২) ছোট পরমাণু বলে C–C অধিক্রমণ ভালো ও বন্ধন শক্তিশালী, (৩) C–C ও C–H দুটিই শক্তিশালী ও প্রায় অপোলার — শৃঙ্খল স্থিতিশীল, (৪) Si–Si দুর্বল আর Si–O (৪৫২) বেশি শক্তিশালী, তাই সিলিকন শৃঙ্খলের বদলে সিলিকেট গঠন করে।</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'ty', v => { ty = v; cam.user = false; rebuild(); });
    X.onSeg(el, 'md', v => { mode = v; });
    const ni = q('[data-n]'), nv = q('[data-nv]'); ni.oninput = () => { n = +ni.value; nv.textContent = bn(n); rebuild(); }; nv.textContent = bn(n);
    rebuild(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.০.৩ জৈব বনাম অজৈব যৌগ: পরীক্ষাগারে পার্থক্য ======================= */
const OIT = {
  heat: ['উত্তপ্তকরণ', 'চিনি (C₁₂H₂₂O₁₁)', 'খাদ্য লবণ (NaCl)', 'চিনি ১৮৬ °C এ গলে, আরও তাপে ভেঙে কালো কার্বন (অঙ্গার) ও জলীয় বাষ্প দেয়; NaCl ৮০১ °C এর আগে গলেই না।', '\\ce{C12H22O11 ->[\\Delta] 12C + 11H2O}'],
  burn: ['দহন', 'ইথানল (C₂H₅OH)', 'NaCl দ্রবণ', 'ইথানল নীলাভ শিখায় জ্বলে CO₂ ও H₂O দেয় — চুনের পানি ঘোলা হয়; NaCl জ্বলে না (কেবল শিখায় হলুদ বর্ণ দেয়)।', '\\ce{C2H5OH + 3O2 -> 2CO2 + 3H2O}'],
  sol: ['দ্রাব্যতা', 'ন্যাপথালিন (C₁₀H₈)', 'NaCl', 'পোলার পানিতে আয়নিক NaCl দ্রবীভূত হয়, অপোলার ন্যাপথালিন হয় না; বেনজিন বা কেরোসিনের মতো অপোলার দ্রাবকে উল্টো। "সমধর্মী সমধর্মীকে দ্রবীভূত করে"।', '\\ce{NaCl(s) ->[H2O] Na+(aq) + Cl-(aq)}'],
  cond: ['তড়িৎ পরিবাহিতা', 'চিনির দ্রবণ', 'NaCl দ্রবণ', 'NaCl দ্রবণে মুক্ত Na⁺ ও Cl⁻ আয়ন বিদ্যুৎ বহন করে — বাতি জ্বলে; চিনির দ্রবণে আয়ন নেই, অণু অবিকৃত — বাতি জ্বলে না।', '\\ce{NaCl -> Na+ + Cl-}'],
  rate: ['বিক্রিয়ার গতি', 'ক্লোরোইথেন (C₂H₅Cl)', 'NaCl দ্রবণ', 'AgNO₃ যোগে NaCl তাৎক্ষণিক সাদা AgCl অধঃক্ষেপ দেয় (আয়নিক বিক্রিয়া, মুহূর্তে); C₂H₅Cl এর সমযোজী C–Cl বন্ধন ভাঙতে হয় — সাধারণ তাপমাত্রায় অধঃক্ষেপ পড়ে না বা অতি ধীরে।', '\\ce{Ag+(aq) + Cl-(aq) -> AgCl(s) v}']
};
V.p2c2_orgInorg = {
  t: 'জৈব ও অজৈব যৌগের পার্থক্য: পাঁচটি পাশাপাশি পরীক্ষা — উত্তপ্তকরণ, দহন, দ্রাব্যতা, তড়িৎ পরিবাহিতা ও বিক্রিয়ার গতি', k: ['anim', 'int', '2d'],
  cap: 'পরীক্ষা বেছে নিয়ে "শুরু" চাপো। বাঁ পাশে জৈব যৌগ, ডান পাশে অজৈব যৌগ একই অবস্থায় পরীক্ষা হয়। চিনি পুড়ে কালো অঙ্গার হয় কিন্তু লবণ অপরিবর্তিত; ইথানল জ্বলে CO₂ দেয় যা চুনের পানি ঘোলা করে; লবণ পানিতে গলে কিন্তু ন্যাপথালিন ভাসে; লবণের দ্রবণে বাতি জ্বলে কিন্তু চিনির দ্রবণে নয়; AgNO₃ যোগে লবণ মুহূর্তে সাদা অধঃক্ষেপ দেয়, কিন্তু ক্লোরোইথেন দেয় না। প্রতিটি পর্যবেক্ষণের পেছনে মূল কারণ একটিই — সমযোজী বনাম আয়নিক বন্ধন।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ex', Object.entries(OIT).map(([k, v]) => [k, v[0]]), 'heat')}<button class="btn sm primary" data-go>▶ শুরু</button></div>${X.cv('জৈব বনাম অজৈব পরীক্ষা')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 400;
    let L = X.fit(c, hf), ex = 'heat', p = 0, run = false, t = 0;
    const R = X.rng(5), PTS = Array.from({ length: 40 }, () => [R(), R(), R()]);
    const scene = (g, x0, w, H, org, col) => {
      const cx = x0 + w / 2, base = H - 40, k = Math.min(1, p);
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(org ? 'জৈব: ' + OIT[ex][1] : 'অজৈব: ' + OIT[ex][2], cx, 18);
      g.fillStyle = org ? '#2f9e44' : '#2d6fd6'; g.fillRect(x0 + 12, 24, w - 24, 2);
      if (ex === 'heat') {
        burner(g, cx, base, 34, t, col, run || p > 0); const tx = cx, ty = base - 34 * 1.16 - 100;
        // crucible
        g.fillStyle = '#cfd3d8'; g.beginPath(); g.moveTo(tx - 34, ty + 50); g.lineTo(tx + 34, ty + 50); g.lineTo(tx + 24, ty + 86); g.lineTo(tx - 24, ty + 86); g.closePath(); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.stroke();
        if (org) { const melt = Math.min(1, k * 2.5), char = Math.max(0, (k - 0.35) / 0.65); const cc = `rgb(${Math.round(250 - 230 * char)},${Math.round(250 - 236 * char - 40 * melt * (1 - char))},${Math.round(250 - 240 * char - 120 * melt * (1 - char))})`; g.fillStyle = cc; g.beginPath(); g.ellipse(tx, ty + 60 - char * 10, 26, 8 + char * 6, 0, 0, 7); g.fill(); if (char > 0.05) for (let i = 0; i < 6; i++) { const u = (t * 0.5 + i / 6) % 1; g.fillStyle = `rgba(200,200,210,${0.5 * (1 - u)})`; g.beginPath(); g.arc(tx + Math.sin(i * 3 + t) * 12, ty + 40 - u * 60, 6 + u * 10, 0, 7); g.fill(); } g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(char > 0.5 ? 'কালো অঙ্গার + জলীয় বাষ্প' : melt > 0.5 ? 'গলে বাদামি (ক্যারামেল)' : 'সাদা দানা', tx, base + 16); }
        else { for (let i = 0; i < 14; i++) { const P = PTS[i]; g.fillStyle = '#fafafa'; g.strokeStyle = '#999'; g.lineWidth = 0.5; g.fillRect(tx - 22 + P[0] * 40, ty + 54 + P[1] * 8, 4, 4); g.strokeRect(tx - 22 + P[0] * 40, ty + 54 + P[1] * 8, 4, 4); } g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText('অপরিবর্তিত (গলনাঙ্ক ৮০১ °C)', tx, base + 16); }
        g.fillStyle = '#c0392b'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`${bn(Math.round(25 + k * 375))} °C`, cx + 40, ty + 70);
      } else if (ex === 'burn') {
        const dx = cx, dy = base - 30; g.fillStyle = '#e8e8ee'; g.strokeStyle = col.fg; g.lineWidth = 1.2; rr(g, dx - 26, dy, 52, 30, 4); g.fill(); g.stroke(); g.fillStyle = org ? 'rgba(200,220,255,.6)' : 'rgba(200,230,255,.6)'; g.fillRect(dx - 24, dy + 10, 48, 18);
        if (run || p > 0) { if (org) flame(g, dx, dy, 22, t); else { g.fillStyle = 'rgba(255,200,0,.6)'; g.beginPath(); g.arc(dx, dy - 6, 5 + Math.sin(t * 20) * 2, 0, 7); g.fill(); } }
        // inverted funnel + limewater tube
        const lx = cx + w * 0.3, ly = base - 110; tube(g, lx, ly, 90, 22, 0, org ? `rgba(240,240,240,${0.35 + 0.6 * k})` : 'rgba(220,235,255,.35)', 0.55, col); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText('চুনের পানি', lx, ly - 6);
        g.strokeStyle = col.mu; g.lineWidth = 1.5; g.beginPath(); g.moveTo(dx, dy - 60); g.lineTo(dx, dy - 80); g.lineTo(lx, dy - 80); g.lineTo(lx, ly + 50); g.stroke(); g.beginPath(); g.moveTo(dx - 20, dy - 40); g.lineTo(dx, dy - 60); g.lineTo(dx + 20, dy - 40); g.stroke();
        if (org && p > 0) for (let i = 0; i < 6; i++) { const u = (t * 0.7 + i / 6) % 1; g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.arc(lx + Math.sin(i * 4) * 5, ly + 85 - u * 40, 2, 0, 7); g.fill(); }
        g.fillStyle = org ? (k > 0.5 ? '#c0392b' : col.mu) : col.mu; g.font = `bold 9.5px ${col.font}`; g.fillText(org ? (k > 0.5 ? 'ঘোলা: CaCO₃ ↓' : '') : 'জ্বলে না · হলুদ শিখা (Na)', cx, base + 18);
      } else if (ex === 'sol') {
        const bw = 70, bh = 110, bx = cx - bw / 2, by = base - bh;
        g.fillStyle = 'rgba(140,190,240,.35)'; g.fillRect(bx, by + 20, bw, bh - 20); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(bx, by); g.lineTo(bx, by + bh); g.lineTo(bx + bw, by + bh); g.lineTo(bx + bw, by); g.stroke();
        if (org) { for (let i = 0; i < 16; i++) { const P = PTS[i]; g.fillStyle = '#f5f5f5'; g.strokeStyle = '#888'; g.lineWidth = 0.6; const y = by + 18 + P[1] * 4; g.beginPath(); g.ellipse(bx + 6 + P[0] * (bw - 12), y, 4, 2, P[2] * 3, 0, 7); g.fill(); g.stroke(); } g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText('ভাসছে — অদ্রবণীয়', cx, base + 16); }
        else { const n = Math.round(16 * (1 - k)); for (let i = 0; i < n; i++) { const P = PTS[i]; g.fillStyle = '#fafafa'; g.strokeStyle = '#888'; g.lineWidth = 0.5; g.fillRect(bx + 8 + P[0] * (bw - 16), by + bh - 8 - P[1] * 6, 4, 4); g.strokeRect(bx + 8 + P[0] * (bw - 16), by + bh - 8 - P[1] * 6, 4, 4); } for (let i = 0; i < Math.round(30 * k); i++) { const P = PTS[i % 40], px = bx + 6 + ((P[0] + t * 0.05 * (P[2] - 0.5)) % 1 + 1) % 1 * (bw - 12), py = by + 26 + ((P[1] + t * 0.04 * (P[0] - 0.5)) % 1 + 1) % 1 * (bh - 34); g.fillStyle = i % 2 ? '#8e44ad' : '#1c9a1c'; g.beginPath(); g.arc(px, py, 2.4, 0, 7); g.fill(); } g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(k > 0.8 ? 'সম্পূর্ণ দ্রবীভূত (Na⁺ বেগুনি, Cl⁻ সবুজ)' : 'দ্রবীভূত হচ্ছে…', cx, base + 16); }
      } else if (ex === 'cond') {
        const bw = 80, bh = 90, bx = cx - bw / 2, by = base - bh; g.fillStyle = 'rgba(140,190,240,.35)'; g.fillRect(bx, by + 14, bw, bh - 14); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(bx, by); g.lineTo(bx, by + bh); g.lineTo(bx + bw, by + bh); g.lineTo(bx + bw, by); g.stroke();
        g.fillStyle = '#555'; g.fillRect(bx + 16, by - 20, 6, 80); g.fillRect(bx + bw - 22, by - 20, 6, 80);
        const on = !org && (run || p > 0), lx = cx, ly = by - 60; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(bx + 19, by - 20); g.lineTo(bx + 19, ly); g.lineTo(lx - 10, ly); g.moveTo(lx + 10, ly); g.lineTo(bx + bw - 19, ly); g.lineTo(bx + bw - 19, by - 20); g.stroke();
        if (on) { const gl = g.createRadialGradient(lx, ly - 4, 2, lx, ly - 4, 30); gl.addColorStop(0, 'rgba(255,230,80,.9)'); gl.addColorStop(1, 'rgba(255,230,80,0)'); g.fillStyle = gl; g.beginPath(); g.arc(lx, ly - 4, 30, 0, 7); g.fill(); }
        g.fillStyle = on ? '#ffe066' : 'rgba(220,220,220,.6)'; g.strokeStyle = col.fg; g.beginPath(); g.arc(lx, ly - 4, 10, 0, 7); g.fill(); g.stroke();
        for (let i = 0; i < 24; i++) { const P = PTS[i]; let px = bx + 8 + P[0] * (bw - 16), py = by + 20 + P[1] * (bh - 28); if (!org && on) px = bx + 8 + (((P[0] + (i % 2 ? 1 : -1) * t * 0.12) % 1 + 1) % 1) * (bw - 16); if (org) { g.fillStyle = '#d0c090'; g.beginPath(); g.ellipse(px, py, 4, 2.5, P[2] * 3, 0, 7); g.fill(); } else { g.fillStyle = i % 2 ? '#8e44ad' : '#1c9a1c'; g.beginPath(); g.arc(px, py, 2.6, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 6px ${col.font}`; g.fillText(i % 2 ? '+' : '−', px, py + 2); } }
        g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(org ? 'অণু নিরপেক্ষ — বাতি নেভা' : on ? 'আয়ন চলাচল — বাতি জ্বলে' : '', cx, base + 16);
      } else {
        const tx = cx, ty = base - 120; tube(g, tx, ty, 110, 30, 0, k > 0.1 && !org ? `rgba(245,245,245,${0.4 + 0.55 * k})` : 'rgba(200,225,255,.4)', 0.6, col);
        if (!org && k > 0.05) for (let i = 0; i < Math.round(30 * k); i++) { const P = PTS[i]; g.fillStyle = '#ffffff'; g.beginPath(); g.arc(tx - 10 + P[0] * 20, ty + 60 + P[1] * 44 + k * 4, 1.6, 0, 7); g.fill(); }
        // dropper
        const dy = ty - 40 + Math.min(1, p * 3) * 20; g.fillStyle = '#c9c9c9'; g.fillRect(tx - 4, dy, 8, 30); g.fillStyle = '#c0392b'; g.beginPath(); g.ellipse(tx, dy - 6, 7, 9, 0, 0, 7); g.fill(); if (p > 0 && p < 0.4) { g.fillStyle = 'rgba(200,220,255,.9)'; g.beginPath(); g.arc(tx, dy + 34 + ((t * 80) % 30), 2.5, 0, 7); g.fill(); }
        g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText('AgNO₃', tx + 22, ty - 20);
        g.fillStyle = !org && k > 0.2 ? '#c0392b' : col.mu; g.font = `bold 9.5px ${col.font}`; g.fillText(org ? 'অধঃক্ষেপ নেই (স্বচ্ছ)' : k > 0.2 ? 'সাদা AgCl তাৎক্ষণিক' : '', cx, base + 16);
      }
    };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); scene(g, 0, W / 2, H, true, col); g.strokeStyle = col.mu; g.setLineDash([4, 4]); g.beginPath(); g.moveTo(W / 2, 10); g.lineTo(W / 2, H - 10); g.stroke(); g.setLineDash([]); scene(g, W / 2, W / 2, H, false, col); };
    const info = () => { const e = OIT[ex]; out.innerHTML = `<div>${e[3]}</div>${TXB(e[4])}`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.2); if (p >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'ex', v => { ex = v; p = 0; run = false; info(); });
    q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
