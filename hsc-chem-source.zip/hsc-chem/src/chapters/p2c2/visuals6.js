/* ২য় পত্র অধ্যায় ২ visuals part 6 — 2.8–2.9: coal tar, benzene preparation, benzene π-MO & resonance, Hückel/Frost, benzene reaction map, aliphatic vs aromatic tests */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm, cross, dot, len } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = M3.ease;

/* ---------- arene builder: subs = {ringIndex: group} ---------- */
M3.arene = (subs = {}, name = '') => {
  const a = [], b = [];
  for (let k = 0; k < 6; k++) { const t = Math.PI / 2 + k * Math.PI / 3; a.push(['C', 1.39 * Math.cos(t), 1.39 * Math.sin(t), 0, { pn: [0, 0, 1] }]); b.push([k, (k + 1) % 6, 1.5]); }
  const addG = (k, gk) => {
    const t = Math.PI / 2 + k * Math.PI / 3, u = [Math.cos(t), Math.sin(t), 0], p = [-u[1], u[0], 0], base = a[k].slice(1, 4);
    const at = (el, pos, opt) => { a.push([el, ...pos, opt || {}]); return a.length - 1; }, rot = (ang, L, o) => add(o, mul(add(mul(u, Math.cos(ang)), mul(p, Math.sin(ang))), L));
    if (gk === 'CH3') { b.push([k, at('C', add(base, mul(u, 1.51)))]); return; }
    if (gk === 'C2H5') { const c1 = at('C', add(base, mul(u, 1.51))); b.push([k, c1]); b.push([c1, at('C', add(a[c1].slice(1, 4), mul(add(mul(u, 0.333), mul([0, 0, 1], 0.943)), 1.53)))]); return; }
    if (gk === 'OH') { b.push([k, at('O', add(base, mul(u, 1.36), {}), { geo: 'tri', pn: [0, 0, 1] })]); return; }
    if (gk === 'NH2') { b.push([k, at('N', add(base, mul(u, 1.40)), { geo: 'tri', pn: [0, 0, 1] })]); return; }
    if (gk === 'Cl' || gk === 'Br') { b.push([k, at(gk, add(base, mul(u, gk === 'Cl' ? 1.74 : 1.90)))]); return; }
    if (gk === 'NO2') { const n = at('N', add(base, mul(u, 1.47)), { q: 1 }); b.push([k, n]); const np = a[n].slice(1, 4); b.push([n, at('O', rot(Math.PI / 3, 1.22, np)), 2]); b.push([n, at('O', rot(-Math.PI / 3, 1.22, np), { q: -1 })]); return; }
    if (gk === 'COOH' || gk === 'COO-' || gk === 'CHO' || gk === 'COCH3') { const c = at('C', add(base, mul(u, 1.48)), { geo: 'tri', pn: [0, 0, 1] }); b.push([k, c]); const cp = a[c].slice(1, 4); b.push([c, at('O', rot(Math.PI / 3, 1.22, cp)), 2]); if (gk === 'COOH') b.push([c, at('O', rot(-Math.PI / 3, 1.34, cp), { geo: 'tri', pn: [0, 0, 1] })]); if (gk === 'COO-') b.push([c, at('O', rot(-Math.PI / 3, 1.27, cp), { q: -1 })]); if (gk === 'COCH3') b.push([c, at('C', rot(-Math.PI / 3, 1.50, cp))]); return; }
    if (gk === 'SO3H') { const s = at('S', add(base, mul(u, 1.77)), { geo: 'tet' }); b.push([k, s]); const sp = a[s].slice(1, 4); [0, 1, 2].forEach(j => { const f = j * 2 * Math.PI / 3, d = add(mul(u, 0.333), mul(add(mul(p, Math.cos(f)), mul([0, 0, 1], Math.sin(f))), 0.943)); b.push([s, at('O', add(sp, mul(d, j < 2 ? 1.43 : 1.57))), j < 2 ? 2 : 1]); }); return; }
  };
  Object.entries(subs).forEach(([k, gk]) => addG(+k, gk));
  const m = M3.mol({ name, a, b }); m.ring = [0, 0, 0]; M3.offsets(m); return m;
};
/* 2D benzene hexagon */
const hex = (g, cx, cy, r, col, opt = {}) => { const pts = []; for (let k = 0; k < 6; k++) { const t = -Math.PI / 2 + k * Math.PI / 3; pts.push([cx + r * Math.cos(t), cy + r * Math.sin(t)]); } g.strokeStyle = opt.color || col.fg; g.lineWidth = opt.w || 1.8; g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.stroke(); if (opt.circle) { g.beginPath(); g.arc(cx, cy, r * 0.58, 0, 7); g.stroke(); } (opt.dbl || []).forEach(i => { const a2 = pts[i], b2 = pts[(i + 1) % 6], mx = (a2[0] + b2[0]) / 2, my = (a2[1] + b2[1]) / 2, k2 = 0.78; g.beginPath(); g.moveTo(cx + (a2[0] - cx) * k2 + (mx - cx) * 0, cy + (a2[1] - cy) * k2); g.lineTo(cx + (b2[0] - cx) * k2, cy + (b2[1] - cy) * k2); g.globalAlpha = opt.dblAlpha == null ? 1 : opt.dblAlpha; g.stroke(); g.globalAlpha = 1; void mx; void my; }); return pts; };
M3.hex = hex;

/* ======================= ২.৮.১ আলকাতরা থেকে বেনজিন ও টলুইন ======================= */
const FR = [
  ['হালকা তেল', 80, 170, '#f4d03f', 'বেনজিন, টলুইন, জাইলিন', 0.82],
  ['মধ্যম তেল (কার্বলিক তেল)', 170, 230, '#e59866', 'ফেনল, ন্যাপথালিন', 0.64],
  ['ভারী তেল (ক্রিওসোট তেল)', 230, 270, '#af601a', 'ক্রেসল, ন্যাপথালিন', 0.46],
  ['অ্যানথ্রাসিন তেল (সবুজ তেল)', 270, 360, '#5d6d2e', 'অ্যানথ্রাসিন, ফেনানথ্রিন', 0.28],
  ['পিচ (অবশেষ)', 360, 999, '#1c1c1c', 'রাস্তা ও ছাদে আলকাতরা', 0.06]
];
V.p2c2_coalTar = {
  t: 'আলকাতরার আংশিক পাতন ও হালকা তেল থেকে বেনজিন-টলুইন পৃথকীকরণ: তাপমাত্রা বাড়ার সাথে পাঁচটি ভগ্নাংশ এবং শোধনের ধাপ', k: ['anim', 'int', '2d'],
  cap: 'কয়লার অন্তর্ধূম পাতনে (বায়ুশূন্য অবস্থায় ~১০০০ °C) কোক, কোল গ্যাস, অ্যামোনিয়াকাল লিকার ও আলকাতরা পাওয়া যায়। স্লাইডারে পাতন পাত্রের তাপমাত্রা বাড়াও — যে ভগ্নাংশের স্ফুটনাঙ্কের পরিসরে পৌঁছায়, সেটির বাষ্প স্তম্ভ বেয়ে উঠে নির্দিষ্ট উচ্চতায় ঘনীভূত হয়ে সংগ্রাহক পাত্রে জমে। "শোধন" ধাপে হালকা তেল থেকে বেনজিন (স্ফু. ৮০ °C) ও টলুইন (স্ফু. ১১১ °C) কীভাবে আলাদা হয় দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('md', [['dist', 'আংশিক পাতন'], ['pur', 'হালকা তেলের শোধন']], 'dist')}</div>${X.cv('আলকাতরার পাতন')}<div class="ctl" data-tw><label class="small" style="flex:1">পাত্রের তাপমাত্রা = <b data-tv></b> °C<input type="range" min="20" max="400" step="1" value="20" data-t></label><button class="btn sm primary" data-play>▶ গরম করো</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 460;
    let L = X.fit(c, hf), T = 20, md = 'dist', play = false, t = 0, fill = FR.map(() => 0), ps = 0;
    const R = X.rng(4), BUB = Array.from({ length: 40 }, () => [R(), R()]);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 'pur') {
        const steps = [['হালকা তেল', '#f4d03f', 'C₆H₆ + C₆H₅CH₃ + জাইলিন + সামান্য ফেনল ও পিরিডিন'], ['গাঢ় H₂SO₄ দিয়ে ধোয়া', '#e74c3c', 'ক্ষারীয় অপদ্রব্য (পিরিডিন) সালফেট লবণ হয়ে দূর হয়'], ['NaOH দ্রবণ দিয়ে ধোয়া', '#3498db', 'অম্লীয় অপদ্রব্য (ফেনল, ক্রেসল) সোডিয়াম ফিনক্সাইড হয়ে দূর হয়'], ['পানি দিয়ে ধুয়ে আংশিক পাতন', '#2ecc71', '৮০–১১০ °C: বেনজিন (৮০ °C) · ১১০–১৪০ °C: টলুইন (১১১ °C)'], ['বিশুদ্ধ বেনজিন: হিমায়িত কেলাসন', '#bdc3c7', 'বেনজিনের গলনাঙ্ক ৫.৫ °C — ঠান্ডা করলে কেলাস হয়, অপদ্রব্য তরলে থাকে']];
        const k = Math.min(steps.length - 1, Math.floor(ps)); const cw = Math.min(150, (W - 40) / (wd ? 5 : 2.2)); steps.forEach((s, i) => { const x = wd ? 20 + i * ((W - 40) / 5) + ((W - 40) / 5 - cw) / 2 : (i % 2 ? W / 2 + 6 : 14), y = wd ? 60 : 30 + Math.floor(i / 2) * 140, on = i <= k; g.globalAlpha = on ? 1 : 0.35; g.fillStyle = col.sf; g.strokeStyle = s[1]; g.lineWidth = 2; rr(g, x, y, cw, 110, 10); g.fill(); g.stroke(); // flask
          const fx = x + cw / 2, fy = y + 50; g.fillStyle = s[1]; g.globalAlpha *= 0.55; g.beginPath(); g.arc(fx, fy + 6, 18, 0, Math.PI); g.fill(); g.globalAlpha = on ? 1 : 0.35; g.strokeStyle = col.fg; g.lineWidth = 1.3; g.beginPath(); g.arc(fx, fy, 22, 0.25 * Math.PI, 0.75 * Math.PI + Math.PI * 1.5, false); g.stroke(); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(`${bn(i + 1)}. ${s[0]}`, fx, y + 16); g.font = `8.5px ${col.font}`; g.fillStyle = col.mu; const words = s[2].split(' '); let line = '', ly = y + 84; words.forEach(wd2 => { if (g.measureText(line + wd2).width > cw - 10) { g.fillText(line, fx, ly); line = ''; ly += 11; } line += wd2 + ' '; }); g.fillText(line, fx, ly); g.globalAlpha = 1; if (i < steps.length - 1 && wd) { g.fillStyle = col.acc; g.beginPath(); g.moveTo(x + cw + 4, y + 55); g.lineTo(x + cw + 12, y + 50); g.lineTo(x + cw + 12, y + 60); g.fill(); } });
        return;
      }
      // still
      const sx = wd ? W * 0.2 : W * 0.3, sy = H - 70, colX = sx + 50, colTop = 30, colBot = sy - 30;
      M3.burner(g, sx, H - 6, 30, t, col, T > 25);
      g.fillStyle = '#2c2c2c'; g.beginPath(); g.ellipse(sx, sy, 50, 34, 0, 0, 7); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.stroke(); g.fillStyle = '#3a2a1a'; g.beginPath(); g.ellipse(sx, sy + 12, 44, 18, 0, 0, Math.PI); g.fill();
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('আলকাতরা', sx, sy + 4); g.fillStyle = '#e74c3c'; g.fillText(`${bn(Math.round(T))} °C`, sx, sy - 40);
      // column
      g.fillStyle = 'rgba(180,200,220,.18)'; g.fillRect(colX - 14, colTop, 28, colBot - colTop); g.strokeStyle = col.fg; g.strokeRect(colX - 14, colTop, 28, colBot - colTop); g.beginPath(); g.moveTo(sx + 30, sy - 24); g.lineTo(colX - 14, colBot - 6); g.stroke();
      for (let y = colTop + 14; y < colBot; y += 16) { g.beginPath(); g.moveTo(colX - 14, y); g.lineTo(colX + 8, y); g.stroke(); }
      // vapour bubbles
      const active = FR.findIndex(f => T >= f[1] && T < f[2]);
      if (active >= 0 && active < 4) { const ty = colTop + (colBot - colTop) * (1 - FR[active][5]); BUB.forEach(([u, v]) => { const ph2 = (u + t * 0.4) % 1, y = colBot - (colBot - ty) * ph2; g.fillStyle = FR[active][3]; g.globalAlpha = 0.7 * (1 - ph2 * 0.5); g.beginPath(); g.arc(colX - 8 + v * 16, y, 2.2, 0, 7); g.fill(); }); g.globalAlpha = 1; }
      // side outlets & receivers
      FR.slice(0, 4).forEach((f, i) => { const y = colTop + (colBot - colTop) * (1 - f[5]), rx = wd ? W * 0.5 + i * 0 : W * 0.68, ry = y; const ex = wd ? W * 0.62 : W - 40; g.strokeStyle = col.fg; g.lineWidth = 1.4; g.beginPath(); g.moveTo(colX + 14, y); g.lineTo(ex - 18, y + 6); g.stroke(); void rx; void ry;
        // receiver
        g.fillStyle = col.sf; g.strokeStyle = col.fg; g.beginPath(); g.moveTo(ex - 12, y + 2); g.lineTo(ex - 12, y + 26); g.arc(ex, y + 26, 12, Math.PI, 0, true); g.lineTo(ex + 12, y + 2); g.stroke(); const lv = fill[i]; if (lv > 0) { g.fillStyle = f[3]; g.globalAlpha = 0.8; g.fillRect(ex - 11, y + 38 - lv * 34, 22, lv * 34 - 1); g.globalAlpha = 1; }
        if (active === i) { g.fillStyle = f[3]; for (let k = 0; k < 3; k++) { const yy = y + 8 + ((t * 30 + k * 9) % 26); g.beginPath(); g.arc(ex - 14 + ((ex - colX) * 0), yy - 4, 1.8, 0, 7); g.fill(); } }
        if (wd) { g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`${f[0]} (${bn(f[1])}–${bn(f[2])} °C)`, ex + 18, y + 14); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(f[4], ex + 18, y + 27); } else { g.fillStyle = col.fg; g.font = `bold 9px ${col.font}`; g.textAlign = 'right'; g.fillText(`${bn(f[1])}–${bn(f[2])}°`, ex - 16, y - 2); }
      });
      if (T >= 360) { g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('পাত্রে অবশেষ: পিচ', sx, sy + 50); }
    };
    const info = () => { if (md === 'pur') { out.innerHTML = `<div>হালকা তেলে বেনজিন প্রায় ৬০%, টলুইন ১৫%। অম্ল ও ক্ষার দিয়ে ধুয়ে ক্ষারীয় ও অম্লীয় অপদ্রব্য দূর করা হয়, তারপর আংশিক পাতনে স্ফুটনাঙ্কের পার্থক্যে (৮০ বনাম ১১১ °C) বেনজিন ও টলুইন আলাদা হয়। বর্তমানে অধিকাংশ বেনজিন পেট্রোলিয়ামের অনুঘটকীয় রিফর্মিং থেকে তৈরি হয়।</div>`; return; } const a = FR.findIndex(f => T >= f[1] && T < f[2]); q('[data-tv]').textContent = bn(Math.round(T)); out.innerHTML = a >= 0 ? `<div><b>${FR[a][0]}</b> (${bn(FR[a][1])}–${FR[a][2] > 900 ? '' : bn(FR[a][2])} °C) সংগ্রহ হচ্ছে — প্রধান উপাদান: ${FR[a][4]}।</div>` : '<div class="small">তাপমাত্রা ৮০ °C এর নিচে — কেবল পানি ও দ্রবীভূত গ্যাস বের হয়।</div>'; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (md === 'pur') ps = Math.min(4.99, ps + dt * 0.6); if (play && md === 'dist') { T = Math.min(400, T + dt * 40); q('[data-t]').value = T; if (T >= 400) play = false; info(); } const a = FR.findIndex(f => T >= f[1] && T < f[2]); if (a >= 0 && a < 4) fill[a] = Math.min(1, fill[a] + dt * 0.25); } draw(); }, { paused: false });
    q('[data-t]').oninput = e => { T = +e.target.value; play = false; info(); };
    q('[data-play]').onclick = () => { T = 20; fill = FR.map(() => 0); play = true; };
    X.onSeg(el, 'md', v => { md = v; ps = 0; q('[data-tw]').style.display = v === 'dist' ? '' : 'none'; info(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৮.২ বেনজিন ও টলুইন প্রস্তুতি ======================= */
const trimer = () => { // benzene target with atom order: C0..C5, H6..H11 (H on Ck = 6+k)
  const B = M3.arene({}, 'বেনজিন'); // atoms 0-5 C, 6-11 H
  const tgt = B.a.map(a => a.p.slice());
  // ethyne k = C(2k), C(2k+1) with H on each, pushed outward from the C2k–C(2k+1) bond midpoint
  const start = tgt.map(p => p.slice());
  for (let k = 0; k < 3; k++) { const i = 2 * k, j = 2 * k + 1, mid = mul(add(tgt[i], tgt[j]), 0.5), out = norm(mid), axis = norm(sub(tgt[j], tgt[i])), sh = mul(out, 2.6); const ci = add(add(mid, sh), mul(axis, -0.60)), cj = add(add(mid, sh), mul(axis, 0.60)); start[i] = ci; start[j] = cj; start[6 + i] = add(ci, mul(axis, -1.06)); start[6 + j] = add(cj, mul(axis, 1.06)); }
  return { B, tgt, start };
};
const PREP = {
  trimer: { nm: 'ইথাইনের পলিমারকরণ', eq: '3HC#CH ->[\\text{লোহিত তপ্ত Fe নল},\\ 873\\ \\mathrm{K}] C6H6', note: 'তিনটি ইথাইন অণুর π বন্ধন ভেঙে নতুন তিনটি σ বন্ধন তৈরি হয়ে বেনজিন বলয় গঠিত হয় (চাক্রিক ত্রিপলিমারকরণ)। লাল-তপ্ত লোহার নল বা Ni(CO)₂/প্রভাবক ব্যবহৃত হয়।' },
  decarb: { nm: 'সোডিয়াম বেনজোয়েটের ডিকার্বক্সিলেশন', eq: 'C6H5COONa + NaOH ->[\\text{CaO},\\ \\Delta] C6H6 + Na2CO3', note: 'সোডা লাইম (NaOH + CaO) দিয়ে উত্তপ্ত করলে –COONa মূলক H দ্বারা প্রতিস্থাপিত হয়, এক কার্বন কমে যায়। CaO আর্দ্রতা শোষণ করে ও কাচ রক্ষা করে।', r: () => M3.arene({ 0: 'COO-' }, 'সোডিয়াম বেনজোয়েট'), p: () => M3.arene({}, 'বেনজিন') },
  phenol: { nm: 'ফেনলের জিংক চূর্ণ দ্বারা বিজারণ', eq: 'C6H5OH + Zn ->[\\Delta] C6H6 + ZnO', note: 'ফেনলের বাষ্প উত্তপ্ত জিংক চূর্ণের উপর দিয়ে চালনা করলে –OH অপসারিত হয়।', r: () => M3.arene({ 0: 'OH' }, 'ফেনল'), p: () => M3.arene({}, 'বেনজিন') },
  fc: { nm: 'টলুইন: ফ্রিডেল-ক্রাফটস অ্যালকাইলেশন', eq: 'C6H6 + CH3Cl ->[\\text{অনার্দ্র AlCl}_3] C6H5CH3 + HCl', note: 'AlCl₃ (লুইস এসিড) CH₃Cl থেকে ইলেকট্রোফাইল CH₃⁺ (বা মেরুকৃত জটিল) তৈরি করে, যা বেনজিন বলয়ের H কে প্রতিস্থাপন করে।', r: () => M3.arene({}, 'বেনজিন'), p: () => M3.arene({ 0: 'CH3' }, 'টলুইন') },
  wf: { nm: 'টলুইন: উর্টজ-ফিটিগ বিক্রিয়া', eq: 'C6H5Br + CH3Br + 2Na ->[\\text{শুষ্ক ইথার}] C6H5CH3 + 2NaBr', note: 'অ্যারাইল হ্যালাইড ও অ্যালকাইল হ্যালাইডের মিশ্রণ শুষ্ক ইথারে সোডিয়াম ধাতুর সাথে বিক্রিয়ায় নতুন C–C বন্ধন গঠন করে।', r: () => M3.arene({ 0: 'Br' }, 'ব্রোমোবেনজিন'), p: () => M3.arene({ 0: 'CH3' }, 'টলুইন') },
  tolOx: { nm: 'টলুইন থেকে বেনজিন (ডিঅ্যালকাইলেশন)', eq: 'C6H5CH3 + H2 ->[\\text{প্রভাবক},\\ 600\\ ^\\circ\\mathrm{C}] C6H6 + CH4', note: 'শিল্পে চাহিদার তুলনায় বেশি টলুইন থাকায় হাইড্রোডিঅ্যালকাইলেশনে বেনজিনে রূপান্তর করা হয়।', r: () => M3.arene({ 0: 'CH3' }, 'টলুইন'), p: () => M3.arene({}, 'বেনজিন') }
};
V.p2c2_benzenePrep = {
  t: 'বেনজিন ও টলুইনের প্রস্তুত প্রণালী: ইথাইনের চাক্রিক পলিমারকরণ (ত্রিমাত্রিক অ্যানিমেশন), ডিকার্বক্সিলেশন, ফেনলের বিজারণ, ফ্রিডেল-ক্রাফটস ও উর্টজ-ফিটিগ', k: ['3d', 'anim', 'int'],
  cap: 'পদ্ধতি বেছে নাও। "ইথাইনের পলিমারকরণ" এ তিনটি HC≡CH অণু (প্রতিটি আলাদা রঙের আভায়) কাছে এসে প্রতিটির একটি করে π বন্ধন ভেঙে তিনটি নতুন C–C σ বন্ধন তৈরি করে — ছয় সদস্যের বেনজিন বলয়। অন্য পদ্ধতিগুলোতে বিক্রিয়ক ও উৎপাদের ত্রিমাত্রিক মডেল পাশাপাশি, পরিবর্তিত অংশটি উজ্জ্বল; নিচে সমীকরণ ও শর্ত।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('pm', [['trimer', 'ইথাইন থেকে'], ['decarb', 'বেনজোয়েট থেকে'], ['phenol', 'ফেনল থেকে'], ['fc', 'টলুইন: ফ্রিডেল-ক্রাফটস'], ['wf', 'টলুইন: উর্টজ-ফিটিগ'], ['tolOx', 'টলুইন → বেনজিন']], 'trimer')}<button class="btn sm primary" data-play>▶ আবার চালাও</button></div>${X.cv('বেনজিন প্রস্তুতি')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 460;
    let L = X.fit(c, hf), pm = 'trimer', TR = trimer(), ph = 0, t = 0, R = null, P = null; const cam = M3.cam({ yaw: 0.2, pitch: 0.7 });
    C4.drag3d(c, cam, () => A.draw());
    const set = k => { pm = k; ph = 0; cam.user = false; const d = PREP[k]; if (d.r) { R = d.r(); P = d.p(); } out.innerHTML = `<div><b>${d.nm}</b></div>${TXB(`\\ce{${d.eq}}`)}<div class="small">${d.note}</div>`; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W); if (!cam.user) cam.yaw += 0.004;
      if (pm === 'trimer') {
        const k = ease(Math.min(1, Math.max(0, (ph - 0.3) / 1.6))), m = M3.clone(TR.B); m.a.forEach((a, i) => { a.p = add(mul(TR.start[i], 1 - k), mul(TR.tgt[i], k)); });
        if (k < 0.5) { m.b = []; for (let j = 0; j < 3; j++) { m.b.push({ i: 2 * j, j: 2 * j + 1, o: 3 }); m.b.push({ i: 2 * j, j: 6 + 2 * j, o: 1 }); m.b.push({ i: 2 * j + 1, j: 7 + 2 * j, o: 1 }); } if (k > 0.25) for (let j = 0; j < 3; j++) m.b.push({ i: 2 * j + 1, j: (2 * j + 2) % 6, o: 1, st: 'dash' }); m.ring = null; }
        M3.offsets(m); cam.cx = W / 2; cam.cy = H / 2 + 8; cam.sc = Math.min(W, H - 30) / 2 / 5.0; const hl = {}; if (k < 0.95) ['#e74c3c', '#2ecc71', '#3498db'].forEach((cc, j) => { hl[2 * j] = cc; hl[2 * j + 1] = cc; });
        M3.render(g, m, cam, { mode: 'bs', col, hl, center: [0, 0, 0] });
        g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(k < 0.05 ? '৩ HC≡CH' : k < 0.95 ? 'π বন্ধন ভেঙে নতুন σ বন্ধন (কমলা বিন্দু রেখা)' : 'বেনজিন C₆H₆', W / 2, 18); return;
      }
      const w2 = wd ? W / 2 : W, h2 = wd ? H : H / 2, Rm = Math.max(R.R, P.R);
      [[R, 0], [P, 1]].forEach(([m, i]) => { const c2 = M3.cam(cam); c2.cx = wd ? w2 * (i + 0.5) : W / 2; c2.cy = wd ? H / 2 + 8 : h2 * (i + 0.5) + 6; c2.sc = Math.min(w2, h2 - 34) / 2 / (Rm + 0.3) * 0.92; const hl = {}; m.a.forEach((a, j) => { if (j >= 6 && a.el !== 'H') hl[j] = '#f1c40f'; }); if (!Object.keys(hl).length) hl[6] = '#f1c40f'; M3.render(g, m, c2, { mode: 'bs', col, hl, labels: 'hetero' }); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${i ? 'উৎপাদ' : 'বিক্রিয়ক'}: ${m.name} (${M3.formula(m)})`, c2.cx, wd ? 18 : h2 * i + 14); });
      g.fillStyle = col.acc; if (wd) { g.beginPath(); g.moveTo(W / 2 - 14, H / 2 - 8); g.lineTo(W / 2 + 14, H / 2); g.lineTo(W / 2 - 14, H / 2 + 8); g.fill(); } else { g.beginPath(); g.moveTo(W / 2 - 8, H / 2 - 10); g.lineTo(W / 2, H / 2 + 8); g.lineTo(W / 2 + 8, H / 2 - 10); g.fill(); }
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; ph += dt * 0.5; if (ph > 3.4) ph = 0; } draw(); }, { paused: false });
    X.onSeg(el, 'pm', set); q('[data-play]').onclick = () => { ph = 0; };
    set('trimer'); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৮.৩ বেনজিনের আণবিক অরবিটাল গঠন ও রেজোন্যান্স ======================= */
V.p2c2_benzeneMO = {
  t: 'বেনজিনের গঠন: ছয়টি sp² কার্বনের সমান্তরাল p অরবিটাল → বিস্থানীকৃত বলয়াকার π মেঘ, কেকুলে রেজোন্যান্স রূপ, সমান বন্ধন দৈর্ঘ্য (১৩৯ pm) ও রেজোন্যান্স শক্তি', k: ['3d', 'anim', 'int', 'calc'],
  cap: 'চারটি দৃশ্য: (১) "p অরবিটাল" — প্রতিটি sp² কার্বনের অসংকরিত p_z অরবিটাল বলয়ের তলের লম্বভাবে; (২) "π মেঘ" — ছয়টি p অরবিটাল পাশাপাশি সব দিকে অধিক্রমণ করে বলয়ের উপরে ও নিচে দুটি বলয়াকার (ডোনাট) ইলেকট্রন মেঘ তৈরি করে, ছয়টি π ইলেকট্রন কোনো নির্দিষ্ট দুটি কার্বনে আটকে থাকে না; (৩) "কেকুলে" — দুটি রেজোন্যান্স কাঠামো যাদের মধ্যে প্রকৃত অণু অবস্থান করে (দুটি রূপের মধ্যে "দোলে" না!); (৪) "শক্তি" — হাইড্রোজেনেশন তাপ থেকে রেজোন্যান্স শক্তি। মডেল টেনে ঘোরাও।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('vw', [['p', 'p অরবিটাল'], ['pi', 'π মেঘ'], ['kek', 'কেকুলে রেজোন্যান্স'], ['en', 'শক্তি ও দৈর্ঘ্য']], 'pi')}</div>${X.cv('বেনজিনের গঠন')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 340 : 440;
    let L = X.fit(c, hf), vw = 'pi', t = 0; const B = M3.arene({}, 'বেনজিন'), K1 = M3.LIB.benzeneK(0), K2 = M3.LIB.benzeneK(1); const cam = M3.cam({ yaw: 0.3, pitch: 0.9 });
    C4.drag3d(c, cam, () => A.draw());
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (vw === 'en') {
        const px = 60, py = 30, pw = wd ? W * 0.5 : W - 90, ph = H - 80; const lv = [['সাইক্লোহেক্সিন (১টি C=C)', -120, '#2d6fd6'], ['সাইক্লোহেক্সা-১,৩-ডাইইন (২টি)', -232, '#8e44ad'], ['কাল্পনিক "সাইক্লোহেক্সাট্রাইইন" (৩ × ১২০)', -360, '#c0392b'], ['বেনজিন (পরীক্ষালব্ধ)', -208, '#2f9e44']];
        const Y = v => py + ph * (-v) / 380; g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(px, py); g.lineTo(px, py + ph); g.stroke(); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'right'; [0, -100, -200, -300].forEach(v => { g.fillText(bn(v), px - 4, Y(v) + 3); g.globalAlpha = 0.2; g.beginPath(); g.moveTo(px, Y(v)); g.lineTo(px + pw, Y(v)); g.stroke(); g.globalAlpha = 1; });
        g.save(); g.translate(px - 38, py + ph / 2); g.rotate(-Math.PI / 2); g.textAlign = 'center'; g.fillText('হাইড্রোজেনেশন তাপ ΔH (kJ mol⁻¹)', 0, 0); g.restore();
        g.fillStyle = col.fg; g.textAlign = 'left'; g.fillText('০: বিক্রিয়ক + H₂', px + 6, Y(0) - 4);
        lv.forEach(([nm, v, cc], i) => { const x = px + 14 + i * (pw - 20) / 4, w = (pw - 20) / 4 - 14; g.fillStyle = cc; g.globalAlpha = 0.85; g.fillRect(x, Y(0), w, Y(v) - Y(0)); g.globalAlpha = 1; g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(v), x + w / 2, Y(v) + 13); g.font = `8.5px ${col.font}`; const ws = nm.split(' '); ws.forEach((wd3, j) => g.fillText(wd3, x + w / 2, Y(v) + 26 + j * 10)); });
        const x3 = px + 14 + 3 * (pw - 20) / 4 + ((pw - 20) / 4 - 14) / 2; g.strokeStyle = '#e67e22'; g.lineWidth = 2; g.setLineDash([4, 3]); g.beginPath(); g.moveTo(x3 - 30, Y(-360)); g.lineTo(x3 + 10, Y(-360)); g.stroke(); g.setLineDash([]); g.beginPath(); g.moveTo(x3 + 6, Y(-360)); g.lineTo(x3 + 6, Y(-208)); g.stroke(); g.fillStyle = '#e67e22'; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText('রেজোন্যান্স শক্তি ≈ ১৫২', x3 + 2, (Y(-360) + Y(-208)) / 2 + 26);
        if (wd) { const bx = W * 0.62, by = 50, bw = W * 0.34; g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText('C–C বন্ধন দৈর্ঘ্য (pm)', bx, by); [['C–C (ইথেন)', 154, '#555'], ['বেনজিন', 139, '#2f9e44'], ['C=C (ইথিন)', 134, '#2d6fd6']].forEach(([nm, v, cc], i) => { const y = by + 18 + i * 34, w = bw * (v - 100) / 60; g.fillStyle = cc; g.fillRect(bx, y, w, 20); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText(`${nm}: ${bn(v)}`, bx + 4, y + 33); }); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText('বেনজিনের ছয়টি বন্ধন সমান — একক ও দ্বিবন্ধনের মাঝামাঝি', bx, by + 130); }
        return;
      }
      cam.cx = W / 2; cam.cy = H / 2 + 6; cam.sc = Math.min(W, H) / 2 / 3.4; if (!cam.user) cam.yaw += 0.004;
      if (vw === 'kek') {
        const s = (Math.sin(t * 1.2) + 1) / 2, m = s > 0.5 ? K1 : K2; const w2 = wd ? W / 2 : W;
        [[K1, 0], [K2, 1]].forEach(([mm, i]) => { const c2 = M3.cam(cam); c2.sc = cam.sc * (wd ? 0.75 : 0.55); c2.cx = wd ? w2 * (i + 0.5) : W / 2; c2.cy = wd ? H / 2 + 6 : H * (0.27 + 0.47 * i); M3.render(g, mm, c2, { mode: 'bs', col }); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`কেকুলে রূপ ${bn(i + 1)}`, c2.cx, wd ? 18 : H * (0.27 + 0.47 * i) - c2.sc * 2.4); });
        g.fillStyle = col.acc; g.font = `bold 22px ${col.font}`; g.textAlign = 'center'; g.fillText('⟷', W / 2, wd ? H / 2 + 12 : H * 0.51); void m; void s;
        g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.fillText('প্রকৃত বেনজিন = দুটি রূপের রেজোন্যান্স সংকর (বৃত্তসহ ষড়ভুজ)', W / 2, H - 8); return;
      }
      const lobes = [], extra = [];
      if (vw === 'p') B.a.slice(0, 6).forEach(a => [1, -1].forEach(sg => lobes.push({ o: a.p, d: [0, 0, sg], len: 1.15, w: 0.75, col: sg > 0 ? '#3d7fd9' : '#d9433d', a: 0.5, stroke: 'rgba(0,0,0,.25)' })));
      if (vw === 'pi') { [0.72, -0.72].forEach(zz => { const N = 48; for (let k = 0; k < N; k++) { const a1 = k / N * 2 * Math.PI, a2 = (k + 1) / N * 2 * Math.PI, p1 = [1.39 * Math.cos(a1), 1.39 * Math.sin(a1), zz], p2 = [1.39 * Math.cos(a2), 1.39 * Math.sin(a2), zz]; extra.push({ z3: mul(add(p1, p2), 0.5), draw: (g2, P) => { const q1 = P(p1), q2 = P(p2); g2.save(); g2.lineCap = 'round'; g2.strokeStyle = zz > 0 ? 'rgba(61,127,217,.30)' : 'rgba(217,67,61,.30)'; g2.lineWidth = 0.95 * cam.sc * q1[3]; g2.beginPath(); g2.moveTo(q1[0], q1[1]); g2.lineTo(q2[0], q2[1]); g2.stroke(); g2.restore(); } }); } });
        // electrons circulating
        for (let e = 0; e < 6; e++) { const ang = t * 0.8 + e * Math.PI / 3, zz = e % 2 ? 0.72 : -0.72, p = [1.39 * Math.cos(ang), 1.39 * Math.sin(ang), zz]; extra.push({ z3: p, draw: (g2, P) => { const q2 = P(p); g2.fillStyle = '#f1c40f'; g2.beginPath(); g2.arc(q2[0], q2[1], 3.2, 0, 7); g2.fill(); g2.strokeStyle = '#7d6608'; g2.stroke(); } }); } }
      M3.render(g, B, cam, { mode: 'bs', col, lobes, extra, center: [0, 0, 0] });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(vw === 'p' ? 'ছয়টি অসংকরিত p_z অরবিটাল (প্রতি C তে একটি, একটি করে ইলেকট্রন)' : 'বিস্থানীকৃত π মেঘ: ছয়টি π ইলেকট্রন (হলুদ) পুরো বলয়ে বিস্তৃত', W / 2, 16);
    };
    const info = () => { out.innerHTML = { p: '<div>প্রতিটি কার্বন sp² সংকরিত: দুটি sp² পাশের দুটি C এর সাথে এবং একটি H এর সাথে σ বন্ধন গঠন করে (সব কোণ ১২০°, অণু সমতলীয়)। অবশিষ্ট p_z অরবিটালে একটি করে ইলেকট্রন — মোট ছয়টি।</div>', pi: '<div>প্রতিটি p_z অরবিটাল দুই পাশের প্রতিবেশী উভয়ের সাথেই সমানভাবে অধিক্রমণ করে — ফলে নির্দিষ্ট তিনটি π বন্ধনের বদলে একটি অবিচ্ছিন্ন বলয়াকার π মেঘ। ইলেকট্রনের বিস্থানীকরণ অণুকে অতিরিক্ত স্থিতিশীলতা দেয় (রেজোন্যান্স শক্তি ~১৫০ kJ mol⁻¹) — তাই বেনজিন সংযোজনের বদলে প্রতিস্থাপন বিক্রিয়া দেয়, যাতে এই বলয় অক্ষত থাকে।</div>', kek: '<div>১৮৬৫ সালে কেকুলে একক ও দ্বিবন্ধন পর্যায়ক্রমে সাজানো বলয় প্রস্তাব করেন। কিন্তু বেনজিনের মাত্র একটি ১,২-ডাইব্রোমো সমাণু পাওয়া যায় এবং সব বন্ধন সমান — তাই প্রকৃত গঠন দুটি কেকুলে রূপের রেজোন্যান্স সংকর। রেজোন্যান্স রূপগুলো কাল্পনিক; অণু কখনো একটি রূপে থাকে না।</div>', en: '<div>সাইক্লোহেক্সিনের একটি C=C এর হাইড্রোজেনেশন তাপ −১২০ kJ mol⁻¹। তিনটি স্থানীয় দ্বিবন্ধন থাকলে বেনজিনের জন্য −৩৬০ আশা করা যেত, কিন্তু পরীক্ষালব্ধ মান −২০৮। পার্থক্য ≈ ১৫২ kJ mol⁻¹ = রেজোন্যান্স (বিস্থানীকরণ) শক্তি — বেনজিন ততটাই বেশি স্থিতিশীল।</div>' }[vw]; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'vw', v => { vw = v; info(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৮.৫ অ্যারোমেটিসিটি: হাকেল নিয়ম ও ফ্রস্ট বৃত্ত ======================= */
const HK = {
  benzene: ['বেনজিন', 6, 6, true, true, 'A', 'C₆H₆ — প্রতি C sp², ৬π'],
  cbd: ['সাইক্লোবিউটাডাইইন', 4, 4, true, true, 'AA', '৪π (4n, n = ১) — অ্যান্টি-অ্যারোমেটিক, অত্যন্ত অস্থিতিশীল'],
  cot: ['সাইক্লোঅক্টাটেট্রাইইন', 8, 8, false, true, 'N', '৮π, কিন্তু টব আকৃতি (অসমতলীয়) — অ্যারোমেটিক নয়, সাধারণ অ্যালকিনের মতো আচরণ'],
  cpd: ['সাইক্লোপেন্টাডাইইন', 5, 4, true, false, 'N', 'একটি sp³ CH₂ — বলয়ে অবিচ্ছিন্ন p অরবিটাল নেই'],
  cpa: ['সাইক্লোপেন্টাডাইইনাইল অ্যানায়ন', 5, 6, true, true, 'A', 'C₅H₅⁻ — ৬π (CH₂ থেকে H⁺ সরালে নিঃসঙ্গ জোড় p তে); তাই সাইক্লোপেন্টাডাইইন অস্বাভাবিক অম্লীয় (pKa ১৬)'],
  cpc: ['সাইক্লোপেন্টাডাইইনাইল ক্যাটায়ন', 5, 4, true, true, 'AA', 'C₅H₅⁺ — ৪π, অ্যান্টি-অ্যারোমেটিক'],
  trop: ['ট্রোপিলিয়াম ক্যাটায়ন', 7, 6, true, true, 'A', 'C₇H₇⁺ — ৬π, স্থিতিশীল কার্বোক্যাটায়ন (লবণ হিসেবে পৃথক করা যায়)'],
  pyridine: ['পিরিডিন', 6, 6, true, true, 'A', 'N এর নিঃসঙ্গ জোড় বলয়ের তলে (sp²) — π তে অংশ নেয় না; ৬π'],
  pyrrole: ['পাইরোল', 5, 6, true, true, 'A', 'N এর নিঃসঙ্গ জোড় p অরবিটালে — ৪ + ২ = ৬π'],
  furan: ['ফিউরান', 5, 6, true, true, 'A', 'O এর একটি নিঃসঙ্গ জোড় π তে — ৬π']
};
const HKL = { A: ['অ্যারোমেটিক ✓', '#2f9e44'], AA: ['অ্যান্টি-অ্যারোমেটিক ✗', '#c0392b'], N: ['অ্যারোমেটিক নয়', '#7f8c8d'] };
V.p2c2_huckel = {
  t: 'অ্যারোমেটিসিটি ও হাকেলের (4n+2) নিয়ম: চারটি শর্ত যাচাই এবং ফ্রস্ট বৃত্তে π আণবিক অরবিটালের শক্তিস্তর ও ইলেকট্রন বিন্যাস', k: ['int', '2d', 'calc'],
  cap: 'যৌগ বেছে নাও। বাঁয়ে বলয়ের গঠন (প্রতিটি বলয় পরমাণুর p অরবিটাল ও π ইলেকট্রন বিন্দু), মাঝে চারটি শর্তের যাচাই তালিকা — চাক্রিক, সমতলীয়, পূর্ণ সংযুগ্মিত (প্রতিটি বলয় পরমাণুতে p অরবিটাল) এবং π ইলেকট্রন = 4n+2। ডানে ফ্রস্ট বৃত্ত: বৃত্তের ভেতর বহুভুজ শীর্ষ নিচে রেখে আঁকলে শীর্ষবিন্দুগুলোর উচ্চতাই π আণবিক অরবিটালের শক্তি। 4n+2 ইলেকট্রনে সব বন্ধনী অরবিটাল জোড়ায় জোড়ায় পূর্ণ (বদ্ধ খোলক — স্থিতিশীল); 4n ইলেকট্রনে দুটি অযুগ্ম ইলেকট্রন সমশক্তির অরবিটালে থাকে (অস্থিতিশীল)।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('m', Object.entries(HK).map(([k, v]) => [k, v[0].replace('সাইক্লোপেন্টাডাইইনাইল ', 'C₅H₅').replace('অ্যানায়ন', '⁻').replace('ক্যাটায়ন', '⁺')]), 'benzene')}</div>${X.cv('হাকেল নিয়ম')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 300 : 600;
    let L = X.fit(c, hf), m = 'benzene';
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const d = HK[m], n = d[1], ne = d[2], wd = wide(W);
      // ring
      const rx = wd ? W * 0.17 : W * 0.3, ry = wd ? H / 2 : 110, R = wd ? Math.min(70, W * 0.1) : 64;
      const pts = []; for (let k = 0; k < n; k++) { const a = -Math.PI / 2 + k * 2 * Math.PI / n; pts.push([rx + R * Math.cos(a), ry + R * Math.sin(a)]); }
      g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.stroke();
      const het = { pyridine: 'N', pyrrole: 'N', furan: 'O' }[m];
      pts.forEach((p, k) => { const sp3 = m === 'cpd' && k === 0, isH = het && k === 0; if (m === 'cot') { /* tub shown below */ } g.fillStyle = col.sf; g.beginPath(); g.arc(p[0], p[1], 9, 0, 7); g.fill(); g.fillStyle = isH ? (het === 'N' ? '#2a4fc4' : '#cc2418') : sp3 ? '#7f8c8d' : col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(isH ? het : sp3 ? 'CH₂' : 'C', p[0], p[1] + 4); if (!sp3) { g.fillStyle = 'rgba(61,127,217,.35)'; g.beginPath(); g.ellipse(p[0], p[1] - 16, 5, 9, 0, 0, 7); g.fill(); g.fillStyle = 'rgba(217,67,61,.3)'; g.beginPath(); g.ellipse(p[0], p[1] + 16, 5, 9, 0, 0, 7); g.fill(); } });
      // π electron dots distributed
      for (let e = 0; e < ne; e++) { const a = -Math.PI / 2 + (e + 0.5) * 2 * Math.PI / ne; g.fillStyle = '#f1c40f'; g.strokeStyle = '#7d6608'; g.beginPath(); g.arc(rx + R * 0.55 * Math.cos(a), ry + R * 0.55 * Math.sin(a), 3.5, 0, 7); g.fill(); g.stroke(); }
      if (m === 'cpa' || m === 'cpc' || m === 'trop') { g.fillStyle = m === 'cpa' ? '#c0392b' : '#2d6fd6'; g.font = `bold 18px ${col.font}`; g.fillText(m === 'cpa' ? '−' : '+', rx, ry + 6); }
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${d[0]} · ${bn(ne)}π`, rx, ry + R + 34);
      // criteria
      const cx2 = wd ? W * 0.36 : 16, cy2 = wd ? 40 : 220, nn = (ne - 2) / 4; const crit = [['চাক্রিক', true], ['সমতলীয়', d[3]], ['পূর্ণ সংযুগ্মিত (প্রতিটি বলয় পরমাণুতে p অরবিটাল)', d[4]], [`π ইলেকট্রন = 4n+2 (${bn(ne)} ⇒ n = ${Number.isInteger(nn) ? bn(nn) : 'পূর্ণসংখ্যা নয়'})`, Number.isInteger(nn)]];
      crit.forEach(([s, ok], i) => { const y = cy2 + i * 26; g.fillStyle = ok ? '#2f9e44' : '#c0392b'; g.font = `bold 14px ${col.font}`; g.textAlign = 'left'; g.fillText(ok ? '✓' : '✗', cx2, y); g.fillStyle = col.fg; g.font = `10.5px ${col.font}`; g.fillText(s, cx2 + 18, y); });
      const vd = HKL[d[5]]; g.fillStyle = vd[1]; g.font = `bold 14px ${col.font}`; g.fillText(vd[0], cx2, cy2 + 4 * 26 + 6);
      // Frost circle
      const fx = wd ? W * 0.8 : W / 2, fy = wd ? H / 2 + 6 : 470, fr = wd ? Math.min(90, H * 0.3) : 80;
      g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.arc(fx, fy, fr, 0, 7); g.stroke(); g.setLineDash([]); g.beginPath(); g.moveTo(fx - fr - 20, fy); g.lineTo(fx + fr + 20, fy); g.stroke(); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('অবন্ধনী স্তর (α)', fx + fr - 50, fy - 4); g.fillText('বন্ধনী ↓', fx - fr - 18, fy + fr * 0.6); g.fillText('প্রতিবন্ধনী ↑', fx - fr - 18, fy - fr * 0.6);
      const V2 = []; for (let k = 0; k < n; k++) { const a = Math.PI / 2 + k * 2 * Math.PI / n; V2.push([fx + fr * Math.cos(a), fy + fr * Math.sin(a), Math.round(Math.sin(a) * 1000) / 1000]); }
      g.strokeStyle = col.acc; g.lineWidth = 1.5; g.beginPath(); V2.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.stroke();
      // levels: group vertices by height
      const lv = {}; V2.forEach(p => { const k2 = p[2].toFixed(3); (lv[k2] = lv[k2] || []).push(p); }); const levels = Object.values(lv).sort((a, b) => b[0][2] - a[0][2]); // lowest energy first (largest y)
      let left = d[4] ? ne : 0; levels.forEach(grp => { const deg = grp.length; let e = Math.min(left, 2 * deg); left -= e; const fillEach = []; for (let i = 0; i < deg; i++) fillEach.push(0); for (let i = 0; i < e; i++) fillEach[i % deg]++; grp.sort((a, b) => a[0] - b[0]).forEach((p, i) => { g.strokeStyle = col.fg; g.lineWidth = 2.5; g.beginPath(); g.moveTo(p[0] - 12, p[1]); g.lineTo(p[0] + 12, p[1]); g.stroke(); const ne2 = fillEach[i]; g.strokeStyle = '#c0392b'; g.fillStyle = '#c0392b'; g.lineWidth = 1.8; for (let s = 0; s < ne2; s++) { const xx = p[0] + (s ? 4 : -4), up = s === 0; g.beginPath(); g.moveTo(xx, p[1] + (up ? 7 : -7)); g.lineTo(xx, p[1] + (up ? -7 : 7)); g.stroke(); g.beginPath(); g.moveTo(xx, p[1] + (up ? -9 : 9)); g.lineTo(xx - 2.5, p[1] + (up ? -4 : 4)); g.lineTo(xx + 2.5, p[1] + (up ? -4 : 4)); g.fill(); } }); });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(d[4] ? 'ফ্রস্ট বৃত্ত: π MO শক্তিস্তর' : 'ফ্রস্ট বৃত্ত প্রযোজ্য নয় (সংযুগ্মন ভাঙা)', fx, fy - fr - 12);
    };
    const info = () => { const d = HK[m]; out.innerHTML = `<div><b>${d[0]}</b>: ${d[6]}।</div><div class="small" style="margin-top:4px">হাকেল নিয়ম (১৯৩১): সমতলীয়, চাক্রিক, পূর্ণ সংযুগ্মিত যে অণুতে (4n+2) সংখ্যক π ইলেকট্রন (n = ০, ১, ২…; অর্থাৎ ২, ৬, ১০, ১৪…) থাকে, তা অ্যারোমেটিক। একই শর্তে 4n π ইলেকট্রন (৪, ৮…) হলে অ্যান্টি-অ্যারোমেটিক (অতিরিক্ত অস্থিতিশীল); কোনো শর্ত না মানলে অ্যারোমেটিক নয়।</div>`; };
    X.onSeg(el, 'm', v => { m = v; info(); draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ২.৮.৪ বেনজিনের বিক্রিয়া মানচিত্র ======================= */
const bhc = () => { const a = [], b = [], R = 1.457; for (let k = 0; k < 6; k++) { const t = k * Math.PI / 3, z = k % 2 ? 0.25 : -0.25; a.push(['C', R * Math.cos(t), R * Math.sin(t), z]); b.push([k, (k + 1) % 6]); } for (let k = 0; k < 6; k++) { const t = k * Math.PI / 3, z = k % 2 ? 0.25 : -0.25, u = [Math.cos(t), Math.sin(t), 0]; a.push(['Cl', ...add(a[k].slice(1, 4), add(mul(u, 1.70), [0, 0, k < 3 ? (z > 0 ? 0.6 : -0.6) : -Math.sign(z) * 0.4]))]); b.push([k, 6 + k]); } return M3.mol({ name: '১,২,৩,৪,৫,৬-হেক্সাক্লোরোসাইক্লোহেক্সেন (BHC)', a, b }); };
const BRX = [
  ['nitro', 'নাইট্রেশন', 'প্রতিস্থাপন', 'C6H6 + HNO3 ->[\\text{গাঢ় H}_2\\text{SO}_4,\\ 50\\text{–}55\\ ^\\circ\\mathrm{C}] C6H5NO2 + H2O', 'নাইট্রোবেনজিন (হালকা হলুদ, তিক্ত বাদামের গন্ধ)', () => M3.arene({ 0: 'NO2' }, 'নাইট্রোবেনজিন')],
  ['bromo', 'হ্যালোজিনেশন', 'প্রতিস্থাপন', 'C6H6 + Br2 ->[\\text{FeBr}_3] C6H5Br + HBr', 'ব্রোমোবেনজিন; প্রভাবক Fe/FeBr₃ (বা AlCl₃), অন্ধকারে', () => M3.arene({ 0: 'Br' }, 'ব্রোমোবেনজিন')],
  ['sulfo', 'সালফোনেশন', 'প্রতিস্থাপন (উভমুখী)', 'C6H6 + H2SO4 (ধূমায়মান) <=>[\\Delta] C6H5SO3H + H2O', 'বেনজিন সালফোনিক এসিড; ইলেকট্রোফাইল SO₃', () => M3.arene({ 0: 'SO3H' }, 'বেনজিন সালফোনিক এসিড')],
  ['alkyl', 'ফ্রিডেল-ক্রাফটস অ্যালকাইলেশন', 'প্রতিস্থাপন', 'C6H6 + CH3Cl ->[\\text{অনার্দ্র AlCl}_3] C6H5CH3 + HCl', 'টলুইন; বহু-অ্যালকাইলেশন হতে পারে', () => M3.arene({ 0: 'CH3' }, 'টলুইন')],
  ['acyl', 'ফ্রিডেল-ক্রাফটস অ্যাসাইলেশন', 'প্রতিস্থাপন', 'C6H6 + CH3COCl ->[\\text{অনার্দ্র AlCl}_3] C6H5COCH3 + HCl', 'অ্যাসিটোফেনোন; ইলেকট্রোফাইল অ্যাসাইলিয়াম আয়ন CH₃CO⁺', () => M3.arene({ 0: 'COCH3' }, 'অ্যাসিটোফেনোন')],
  ['hydro', 'হাইড্রোজেনেশন', 'সংযোজন', 'C6H6 + 3H2 ->[\\text{Ni},\\ 200\\ ^\\circ\\mathrm{C}] C6H12', 'সাইক্লোহেক্সেন; উচ্চ তাপ ও চাপ লাগে (অ্যালকিনের চেয়ে কঠিন)', () => M3.LIB.cyclohexane()],
  ['bhc', 'ক্লোরিনের সংযোজন', 'সংযোজন', 'C6H6 + 3Cl2 ->[\\text{সূর্যালোক/UV}] C6H6Cl6', 'বেনজিন হেক্সাক্লোরাইড (BHC, একটি সমাণু লিন্ডেন — কীটনাশক, বর্তমানে নিষিদ্ধপ্রায়); মুক্তমূলক কৌশল', bhc],
  ['comb', 'দহন', 'জারণ', '2C6H6 + 15O2 -> 12CO2 + 6H2O', 'উচ্চ C : H অনুপাত — অপর্যাপ্ত বায়ুতে প্রচুর ভুসাযুক্ত (কালো ধোঁয়া) উজ্জ্বল শিখা', () => M3.LIB.co2()]
];
V.p2c2_benzeneRx = {
  t: 'বেনজিনের রাসায়নিক বিক্রিয়ার মানচিত্র: ইলেকট্রোফিলিক প্রতিস্থাপন (নাইট্রেশন, হ্যালোজিনেশন, সালফোনেশন, ফ্রিডেল-ক্রাফটস), সংযোজন (H₂, Cl₂) ও দহন — উৎপাদের ত্রিমাত্রিক মডেলসহ', k: ['3d', 'int'],
  cap: 'কেন্দ্রে বেনজিন, চারপাশে আটটি বিক্রিয়া। যেকোনো বিক্রিয়ার নামে চাপ দাও — উৎপাদের ত্রিমাত্রিক মডেল ডানে আসে, নিচে সমীকরণ ও শর্ত। সবুজ = প্রতিস্থাপন (অ্যারোমেটিক বলয় অক্ষত থাকে — বেনজিনের প্রধান বিক্রিয়া), লাল = সংযোজন (বলয়ের অ্যারোমেটিসিটি নষ্ট হয় — কঠোর শর্ত লাগে), ধূসর = জারণ। লক্ষ করো: সংযোজন উৎপাদ সাইক্লোহেক্সেন ও BHC সমতলীয় নয়।',
  html: () => `${X.cv('বেনজিনের বিক্রিয়া')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 380 : 620;
    let L = X.fit(c, hf), sel = 0, m = BRX[0][5](), t = 0, boxes = []; const cam = M3.cam({ yaw: 0.3, pitch: 0.6 });
    const choose = i => { sel = i; m = BRX[i][5](); cam.user = false; const r = BRX[i]; out.innerHTML = `<div><b>${r[1]}</b> <span class="small">(${r[2]})</span></div>${TXB(`\\ce{${r[3]}}`)}<div class="small">${r[4]}</div>`; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const mx = wd ? W * 0.28 : W / 2, my = wd ? H / 2 : 190, R = wd ? Math.min(W * 0.2, 140) : Math.min(W * 0.36, 140);
      hex(g, mx, my, 26, col, { circle: true, w: 2.2 }); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('C₆H₆', mx, my + 44);
      boxes = [];
      BRX.forEach((r, i) => { const a = -Math.PI / 2 + i * 2 * Math.PI / BRX.length, x = mx + R * Math.cos(a), y = my + R * 0.8 * Math.sin(a), cc = r[2].startsWith('প্রতি') ? '#2f9e44' : r[2] === 'সংযোজন' ? '#c0392b' : '#7f8c8d', on = i === sel; g.strokeStyle = cc; g.lineWidth = on ? 2.6 : 1.3; g.globalAlpha = on ? 1 : 0.6; g.beginPath(); g.moveTo(mx + 34 * Math.cos(a), my + 34 * 0.8 * Math.sin(a)); g.lineTo(x - 30 * Math.cos(a), y - 18 * Math.sin(a)); g.stroke(); g.globalAlpha = 1; g.font = `${on ? 'bold ' : ''}10px ${col.font}`; const tw = g.measureText(r[1]).width + 14; g.fillStyle = on ? cc : col.sf; g.strokeStyle = cc; rr(g, x - tw / 2, y - 11, tw, 22, 9); g.fill(); g.stroke(); g.fillStyle = on ? '#fff' : col.fg; g.textAlign = 'center'; g.fillText(r[1], x, y + 4); boxes.push([x - tw / 2, y - 11, tw, 22, i]); });
      const px = wd ? W * 0.76 : W / 2, py = wd ? H / 2 : 400 + (H - 400) / 2, pw = wd ? W * 0.44 : W, ph = wd ? H : H - 400; cam.cx = px; cam.cy = py + 6; M3.fit(m, cam, pw, ph - 30, 0.85); if (!cam.user) cam.yaw += 0.005;
      M3.render(g, m, cam, { mode: 'bs', col, labels: 'hetero' }); g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${m.name || 'CO₂'} · ${M3.formula(m)}`, px, py - ph / 2 + 18);
    };
    C4.drag3d(c, cam, () => A.draw());
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, b = boxes.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (b) choose(b[4]); });
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    choose(0); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.৯ অ্যালিফেটিক বনাম অ্যারোমেটিক: পরীক্ষাগারে পার্থক্য ======================= */
const AT = {
  br: ['ব্রোমিন পানি', 'হেক্স-১-ইন তাৎক্ষণিক বর্ণহীন (C=C তে Br₂ সংযোজন)। বেনজিনে কোনো বিক্রিয়া নেই — তবে Br₂ অপোলার বেনজিনে বেশি দ্রবণীয় বলে উপরের বেনজিন স্তর কমলা হয়, নিচের পানির স্তর ফিকে হয় (নিষ্কাশন, বিক্রিয়া নয়)।', 'CH2=CH(CH2)3CH3 + Br2 -> CH2Br-CHBr(CH2)3CH3'],
  km: ['বেয়ার পরীক্ষা (ঠান্ডা লঘু ক্ষারীয় KMnO₄)', 'হেক্স-১-ইনে বেগুনি রং দূর হয়ে বাদামি MnO₂ অধঃক্ষেপ (ডাইঅল গঠন)। বেনজিনে বেগুনি রং অপরিবর্তিত — অ্যারোমেটিক বলয় সাধারণ জারকে জারিত হয় না।', '3CH2=CHR + 2KMnO4 + 4H2O -> 3HOCH2-CH(OH)R + 2MnO2 v + 2KOH'],
  fl: ['দহন শিখা', 'হেক্সেন (C : H = ১ : ২.৩) প্রায় ধোঁয়াহীন নীলাভ-হলুদ শিখায় জ্বলে। বেনজিন (C : H = ১ : ১) উজ্জ্বল হলুদ ভুসাযুক্ত শিখায় জ্বলে — কার্বনের অনুপাত বেশি বলে অসম্পূর্ণ দহনে কালো কার্বন কণা তৈরি হয়।', '2C6H6 + 15O2 -> 12CO2 + 6H2O']
};
V.p2c2_aliArom = {
  t: 'অ্যালিফেটিক ও অ্যারোমেটিক যৌগের পার্থক্য: ব্রোমিন পানি, বেয়ার পরীক্ষা ও দহন শিখায় অ্যালকিন-অ্যালকেন বনাম বেনজিন', k: ['anim', 'int', '2d'],
  cap: 'পরীক্ষা বেছে নিয়ে "শুরু" চাপো — বাঁয়ে অ্যালিফেটিক (হেক্স-১-ইন বা হেক্সেন), ডানে অ্যারোমেটিক (বেনজিন)। বেনজিনে তিনটি দ্বিবন্ধন আঁকা হলেও এটি অ্যালকিনের মতো আচরণ করে না: Br₂ পানি ও KMnO₄ এর রং দূর করে না, কারণ বিস্থানীকৃত π ব্যবস্থা ভেঙে সংযোজন শক্তিগতভাবে প্রতিকূল। ব্রোমিন পানিতে বেনজিনের উপরের স্তর কমলা হয় — এটি দ্রাবক নিষ্কাশন, বিক্রিয়া নয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('ex', Object.entries(AT).map(([k, v]) => [k, v[0].split(' (')[0]]), 'br')}<button class="btn sm primary" data-go>▶ শুরু</button></div>${X.cv('অ্যালিফেটিক বনাম অ্যারোমেটিক')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 360;
    let L = X.fit(c, hf), ex = 'br', p = 0, run = false, t = 0;
    const scene = (g, x0, w, H, ali, col) => {
      const cx = x0 + w / 2, base = H - 30, k = Math.min(1, p);
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(ali ? (ex === 'fl' ? 'হেক্সেন C₆H₁₄' : 'হেক্স-১-ইন C₆H₁₂') : 'বেনজিন C₆H₆', cx, 18);
      if (ex === 'fl') { const dx = cx, dy = base - 40; g.fillStyle = '#d5d8dc'; g.strokeStyle = col.fg; rr(g, dx - 24, dy, 48, 28, 4); g.fill(); g.stroke(); if (run || p > 0) { if (ali) M3.flame(g, dx, dy, 24, t); else { for (let i = 0; i < 3; i++) { const h = 70 * (1 + 0.1 * Math.sin(t * 9 + i)), w2 = 16 - i * 4; const gr = g.createLinearGradient(dx, dy, dx, dy - h); gr.addColorStop(0, 'rgba(255,140,0,.9)'); gr.addColorStop(0.6, 'rgba(255,210,60,.85)'); gr.addColorStop(1, 'rgba(255,255,200,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(dx - w2, dy); g.quadraticCurveTo(dx - w2, dy - h * 0.5, dx + Math.sin(t * 7) * 4, dy - h); g.quadraticCurveTo(dx + w2, dy - h * 0.5, dx + w2, dy); g.fill(); } for (let i = 0; i < 14; i++) { const u = (t * 0.4 + i / 14) % 1; g.fillStyle = `rgba(20,20,20,${0.6 * (1 - u)})`; g.beginPath(); g.arc(dx + Math.sin(i * 2.3 + t) * (6 + u * 26), dy - 70 - u * 120, 5 + u * 14, 0, 7); g.fill(); } } } g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(ali ? 'পরিষ্কার শিখা' : 'ভুসাযুক্ত কালো ধোঁয়া', cx, base + 18); return; }
      const tx = cx, ty = 62, TL = base - 72; // test tube
      const reagent = ex === 'br' ? [200, 110, 20] : [120, 30, 150];
      if (ali) { const f = Math.min(1, k * 1.5); const c0 = ex === 'br' ? `rgba(${Math.round(200 + 40 * f)},${Math.round(110 + 120 * f)},${Math.round(20 + 200 * f)},${0.7 - 0.5 * f})` : `rgba(${Math.round(120 + 40 * f)},${Math.round(30 + 50 * f)},${Math.round(150 - 120 * f)},${0.7 - 0.3 * f})`; M3.tube(g, tx, ty, TL, 34, 0, c0, 0.65, col); if (ex === 'km' && f > 0.4) { for (let i = 0; i < 18; i++) { g.fillStyle = '#5d4037'; g.beginPath(); g.arc(tx - 11 + (i * 7) % 22, ty + TL - 10 - (i % 3) * 4, 2.2, 0, 7); g.fill(); } } }
      else { if (ex === 'br') { // two layers: aqueous bottom fades, benzene top orange
          M3.tube(g, tx, ty, TL, 34, 0, `rgba(${reagent.join(',')},${0.7 - 0.45 * k})`, 0.4, col); g.fillStyle = `rgba(230,120,30,${0.25 + 0.55 * k})`; g.fillRect(tx - 16, ty + TL * 0.35, 32, TL * 0.25); g.strokeStyle = col.mu; g.beginPath(); g.moveTo(tx - 16, ty + TL * 0.6); g.lineTo(tx + 16, ty + TL * 0.6); g.stroke(); g.fillStyle = col.mu; g.font = `8.5px ${col.font}`; g.textAlign = 'left'; g.fillText('বেনজিন স্তর', tx + 20, ty + TL * 0.48); g.fillText('পানির স্তর', tx + 20, ty + TL * 0.8); }
        else M3.tube(g, tx, ty, TL, 34, 0, `rgba(${reagent.join(',')},0.7)`, 0.65, col); }
      // dropper
      const dy = ty - 30 + Math.min(1, p * 3) * 16; g.fillStyle = '#c9c9c9'; g.fillRect(tx - 4, dy, 8, 26); g.fillStyle = '#555'; g.beginPath(); g.ellipse(tx, dy - 5, 7, 9, 0, 0, 7); g.fill();
      g.fillStyle = col.mu; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(ali ? (k > 0.6 ? (ex === 'br' ? 'বর্ণহীন — সংযোজন ✓' : 'বাদামি MnO₂ ↓ ✓') : '') : (k > 0.6 ? (ex === 'br' ? 'বিক্রিয়া নেই (কেবল নিষ্কাশন)' : 'বেগুনি — বিক্রিয়া নেই') : ''), cx, base + 18);
    };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); scene(g, 0, W / 2, H, true, col); g.strokeStyle = col.mu; g.setLineDash([4, 4]); g.beginPath(); g.moveTo(W / 2, 10); g.lineTo(W / 2, H - 10); g.stroke(); g.setLineDash([]); scene(g, W / 2, W / 2, H, false, col); };
    const info = () => { const e = AT[ex]; out.innerHTML = `<div><b>${e[0]}:</b> ${e[1]}</div>${TXB(`\\ce{${e[2]}}`)}`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.3); if (p >= 1) run = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'ex', v => { ex = v; p = 0; run = false; info(); });
    q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
