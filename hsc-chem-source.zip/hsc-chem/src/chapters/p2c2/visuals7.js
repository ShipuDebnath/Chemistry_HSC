/* ২য় পত্র অধ্যায় ২ visuals part 7 — 2.10 reaction mechanisms: EAS with arenium resonance & energy profile, directing effects, SN2/SN1 (3D), Markovnikov & peroxide effect, E2 (3D) & Saytzeff, 1,2-shift rearrangement */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, cplot = C4.cplot, path = C4.path, wide = P2.wide;
const { add, sub, mul, norm, cross, dot, len } = M3.v;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const ease = M3.ease;

/* ---------- 2D mechanism helpers ---------- */
const curly = (g, p, q, bend, color, w = 2, half = false) => { const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2, dx = q[0] - p[0], dy = q[1] - p[1], l = Math.hypot(dx, dy) || 1, cx = mx - dy / l * bend, cy = my + dx / l * bend; g.strokeStyle = color; g.fillStyle = color; g.lineWidth = w; g.beginPath(); g.moveTo(p[0], p[1]); g.quadraticCurveTo(cx, cy, q[0], q[1]); g.stroke(); const a = Math.atan2(q[1] - cy, q[0] - cx); g.beginPath(); g.moveTo(q[0], q[1]); g.lineTo(q[0] - 9 * Math.cos(a - 0.38), q[1] - 9 * Math.sin(a - 0.38)); if (!half) g.lineTo(q[0] - 9 * Math.cos(a + 0.38), q[1] - 9 * Math.sin(a + 0.38)); else g.lineTo(q[0] - 4 * Math.cos(a), q[1] - 4 * Math.sin(a)); g.closePath(); g.fill(); };
M3.curly = curly;
const ringPts = (cx, cy, r) => { const p = []; for (let k = 0; k < 6; k++) { const t = -Math.PI / 2 + k * Math.PI / 3; p.push([cx + r * Math.cos(t), cy + r * Math.sin(t)]); } return p; };
/* draw ring: dbl = edge indices (edge e: vertex e→e+1), plus = vertex with +, sp3 = vertex index drawn with H/E labels */
const ring2 = (g, cx, cy, r, col, o = {}) => {
  const P = ringPts(cx, cy, r); g.strokeStyle = o.color || col.fg; g.lineWidth = o.w || 1.8; g.beginPath(); P.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.stroke();
  (o.dbl || []).forEach(e => { const a = P[e], b = P[(e + 1) % 6], k = 0.76; g.beginPath(); g.moveTo(cx + (a[0] - cx) * k + (b[0] - a[0]) * 0.08, cy + (a[1] - cy) * k + (b[1] - a[1]) * 0.08); g.lineTo(cx + (b[0] - cx) * k - (b[0] - a[0]) * 0.08, cy + (b[1] - cy) * k - (b[1] - a[1]) * 0.08); g.stroke(); });
  if (o.circle) { g.beginPath(); g.arc(cx, cy, r * 0.58, 0, 7); g.stroke(); }
  if (o.plus != null) { const p = P[o.plus], hot = o.hot; g.fillStyle = hot === 'good' ? '#2f9e44' : hot === 'bad' ? '#c0392b' : '#2d6fd6'; const px = cx + (p[0] - cx) * 0.6, py = cy + (p[1] - cy) * 0.6; if (hot) { g.globalAlpha = 0.25; g.beginPath(); g.arc(px, py, 10, 0, 7); g.fill(); g.globalAlpha = 1; } g.font = `bold 14px ${col.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('+', px, py); g.textBaseline = 'alphabetic'; }
  if (o.sp3 != null) { const p = P[o.sp3], ux = (p[0] - cx) / r, uy = (p[1] - cy) / r, px = -uy, py = ux; g.strokeStyle = col.fg; g.lineWidth = 1.5; [[1, o.E || 'E'], [-1, 'H']].forEach(([sg, lab]) => { const ex = p[0] + ux * r * 0.42 + px * sg * r * 0.32, ey = p[1] + uy * r * 0.42 + py * sg * r * 0.32; g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(ex, ey); g.stroke(); g.fillStyle = lab === 'H' ? col.mu : '#c0392b'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(lab, ex + ux * 9 + px * sg * 4, ey + uy * 9 + py * sg * 4 + 4); }); }
  if (o.G) { const p = P[o.Gat || 0], ux = (p[0] - cx) / r, uy = (p[1] - cy) / r; const ex = p[0] + ux * r * 0.45, ey = p[1] + uy * r * 0.45; g.strokeStyle = col.fg; g.lineWidth = o.Gdbl ? 1.5 : 1.8; g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(ex, ey); g.stroke(); if (o.Gdbl) { g.beginPath(); g.moveTo(p[0] + 3, p[1]); g.lineTo(ex + 3, ey); g.stroke(); } g.fillStyle = '#8e44ad'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(o.G + (o.Gplus ? '⁺' : ''), ex + ux * 10, ey + uy * 10 + 4); }
  return P;
};
M3.ring2 = ring2;
const eprofile = (g, x0, y0, w, h, col, pts, mark, labels) => { // pts: [[x(0..1), E(0..1)]...] smooth through
  g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0, y0 + h); g.lineTo(x0 + w, y0 + h); g.stroke(); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.save(); g.translate(x0 - 8, y0 + h / 2); g.rotate(-Math.PI / 2); g.textAlign = 'center'; g.fillText('স্থিতিশক্তি', 0, 0); g.restore(); g.textAlign = 'center'; g.fillText('বিক্রিয়ার অগ্রগতি →', x0 + w / 2, y0 + h + 13);
  const X_ = u => x0 + u * w, Y_ = e => y0 + h - e * h; const curve = []; for (let i = 0; i < pts.length - 1; i++) { const [xa, ea] = pts[i], [xb, eb] = pts[i + 1]; for (let s = 0; s <= 1; s += 0.05) { const k = (1 - Math.cos(s * Math.PI)) / 2; curve.push([X_(xa + (xb - xa) * s), Y_(ea + (eb - ea) * k)]); } }
  path(g, curve, col.acc, 2.4); (labels || []).forEach(([u, e, s]) => { g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(s, X_(u), Y_(e) - 6); });
  if (mark != null) { const i = Math.min(curve.length - 1, Math.max(0, Math.round(mark * (curve.length - 1)))); M3.sphere(g, curve[i][0], curve[i][1], 6, '#f39c12', '#ffe0a0'); }
  return { X: X_, Y: Y_ };
};
M3.eprofile = eprofile;

/* ======================= ২.১০.৫ ইলেকট্রোফিলিক অ্যারোমেটিক প্রতিস্থাপনের কৌশল ======================= */
const EASR = {
  nitro: ['নাইট্রেশন', 'NO₂', 'HNO3 + 2H2SO4 <=> NO2+ + H3O+ + 2HSO4-', 'HSO₄⁻', 'C6H6 + NO2+ -> C6H5NO2 + H+'],
  bromo: ['ব্রোমিনেশন', 'Br', 'Br2 + FeBr3 -> Br+ + FeBr4-', 'FeBr₄⁻', 'C6H6 + Br2 ->[FeBr3] C6H5Br + HBr'],
  sulfo: ['সালফোনেশন', 'SO₃H', '2H2SO4 <=> SO3 + H3O+ + HSO4-', 'HSO₄⁻', 'C6H6 + SO3 <=> C6H5SO3H'],
  alkyl: ['ফ্রিডেল-ক্রাফটস অ্যালকাইলেশন', 'CH₃', 'CH3Cl + AlCl3 -> CH3+ + AlCl4-', 'AlCl₄⁻', 'C6H6 + CH3Cl ->[AlCl3] C6H5CH3 + HCl'],
  acyl: ['ফ্রিডেল-ক্রাফটস অ্যাসাইলেশন', 'COCH₃', 'CH3COCl + AlCl3 -> CH3CO+ + AlCl4-', 'AlCl₄⁻', 'C6H6 + CH3COCl ->[AlCl3] C6H5COCH3 + HCl']
};
const EST = ['ধাপ ১: ইলেকট্রোফাইল তৈরি', 'ধাপ ২: π ইলেকট্রনের আক্রমণ (ধীর)', 'অ্যারেনিয়াম আয়ন (σ-জটিল): রেজোন্যান্স', 'ধাপ ৩: প্রোটন অপসারণ (দ্রুত)', 'উৎপাদ: অ্যারোমেটিসিটি ফিরে এলো'];
V.p2c2_eas = {
  t: 'ইলেকট্রোফিলিক অ্যারোমেটিক প্রতিস্থাপনের কৌশল: ইলেকট্রোফাইল তৈরি → π আক্রমণ → অ্যারেনিয়াম আয়নের তিনটি রেজোন্যান্স রূপ → প্রোটন অপসারণ — বাঁকা তীর ও শক্তি লেখচিত্রসহ', k: ['anim', 'int', '2d'],
  cap: 'বিক্রিয়া বেছে নিয়ে ধাপ এগোও (বা চালাও)। বাঁকা তীর ইলেকট্রন জোড়ের গতিপথ দেখায় (লেজ = ইলেকট্রনের উৎস, মাথা = গন্তব্য)। ধাপ ২ এ বলয়ের একটি π জোড় ইলেকট্রোফাইল E⁺ কে আক্রমণ করে — একটি কার্বন sp³ হয়ে যায়, অ্যারোমেটিসিটি সাময়িকভাবে হারায়; এটি ধীর ও হার-নির্ধারক ধাপ (লেখচিত্রের প্রথম উঁচু চূড়া)। তৈরি অ্যারেনিয়াম আয়নের ধনাত্মক চার্জ তিনটি কার্বনে (sp³ কার্বনের অর্থো ও প্যারা অবস্থানে) রেজোন্যান্সে বিস্তৃত। ধাপ ৩ এ ক্ষারক sp³ কার্বনের H⁺ সরিয়ে নেয়, C–H বন্ধনের ইলেকট্রন বলয়ে ফিরে অ্যারোমেটিসিটি পুনর্গঠিত হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('rx', Object.entries(EASR).map(([k, v]) => [k, v[0].replace('ফ্রিডেল-ক্রাফটস ', 'F-C ')]), 'nitro')}</div>${X.cv('ইলেকট্রোফিলিক প্রতিস্থাপন')}<div class="ctl"><button class="btn sm" data-pv>◀</button><button class="btn sm primary" data-nx>পরের ধাপ ▶</button><button class="btn sm" data-play>▶ চালাও</button><span class="small" data-st></span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 560;
    let L = X.fit(c, hf), rx = 'nitro', st = 0, t = 0, play = false, an = 1;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), d = EASR[rx], E = d[1];
      const mw = wd ? W * 0.62 : W, mh = wd ? H : 330, cx = mw / 2, cy = mh / 2 + 10, r = Math.min(46, mw / 9);
      const k = Math.min(1, an);
      g.fillStyle = col.fg; g.font = `bold 11.5px ${col.font}`; g.textAlign = 'center'; g.fillText(EST[st], cx, 18);
      if (st === 0) { g.fillStyle = col.fg; g.font = `13px ${col.font}`; g.fillText(`${d[0]}: বিকারক থেকে শক্তিশালী ইলেকট্রোফাইল`, cx, cy - 30); g.fillStyle = '#c0392b'; g.font = `bold 28px ${col.font}`; g.fillText(E === 'SO₃H' ? 'SO₃' : E === 'COCH₃' ? 'CH₃C≡O⁺' : E + '⁺', cx, cy + 20); g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.fillText('(নিচে সমীকরণ দেখো)', cx, cy + 44); }
      if (st === 1) { const P = ring2(g, cx - r * 0.3, cy + 10, r, col, { dbl: [0, 2, 4] }); const ex = cx + r * 1.6, ey = cy - r * 1.3 + (1 - k) * -10; g.fillStyle = '#c0392b'; g.font = `bold 16px ${col.font}`; g.textAlign = 'center'; g.fillText(E === 'SO₃H' ? 'SO₃' : E + '⁺', ex, ey); const a = P[0], b = P[1], mid = [(a[0] + b[0]) / 2 - 6, (a[1] + b[1]) / 2 + 6]; if (k > 0.2) curly(g, mid, [ex - 18, ey - 4], -30, '#e67e22', 2.2); }
      if (st === 2) { const forms = [[1, [2, 4]], [3, [1, 4]], [5, [1, 3]]], cyc = Math.floor(t * 0.7) % 3; const gap = wd ? mw / 3.1 : mw / 3.1, rs = Math.min(r * 0.78, gap / 3.2); forms.forEach(([pl, db], i) => { const x = mw / 2 + (i - 1) * gap, y = cy + 6; g.globalAlpha = i === cyc ? 1 : 0.55; ring2(g, x, y, rs, col, { dbl: db, plus: pl, sp3: 0, E, hot: i === cyc ? 'mark' : null }); g.globalAlpha = 1; if (i < 2) { g.fillStyle = col.acc; g.font = `bold 16px ${col.font}`; g.textAlign = 'center'; g.fillText('↔', x + gap / 2, y + 4); } }); g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('ধনাত্মক চার্জ sp³ কার্বনের অর্থো ও প্যারা অবস্থানে বিস্তৃত', mw / 2, cy + rs * 2.4); }
      if (st === 3) { const P = ring2(g, cx - r * 0.2, cy + 14, r, col, { dbl: [2, 4], plus: 1, sp3: 0, E }); const p0 = P[0], hx = p0[0] - r * 0.32 - 4, hy = p0[1] - r * 0.42 - 6, bx = hx - r * 1.4, by = hy - 18; g.fillStyle = '#2d6fd6'; g.font = `bold 13px ${col.font}`; g.textAlign = 'center'; g.fillText(d[3], bx, by); if (k > 0.2) { curly(g, [bx + 14, by + 4], [hx - 4, hy - 4], -20, '#2d6fd6', 2); const cm = [(p0[0] + hx) / 2 + 3, (p0[1] + hy) / 2 + 6]; curly(g, cm, [(P[0][0] + P[1][0]) / 2 + 2, (P[0][1] + P[1][1]) / 2 + 4], 16, '#e67e22', 2); } }
      if (st === 4) { const P = ring2(g, cx, cy + 10, r, col, { circle: true }); const p0 = P[0]; g.strokeStyle = col.fg; g.lineWidth = 1.8; g.beginPath(); g.moveTo(p0[0], p0[1]); g.lineTo(p0[0], p0[1] - r * 0.5); g.stroke(); g.fillStyle = '#c0392b'; g.font = `bold 14px ${col.font}`; g.textAlign = 'center'; g.fillText(E, p0[0], p0[1] - r * 0.5 - 6); g.fillStyle = col.mu; g.font = `11px ${col.font}`; g.fillText(`+ H⁺ (${d[3]} এর সাথে যুক্ত হয়ে প্রভাবক পুনরুৎপাদন)`, cx, cy + r * 1.7); }
      // energy profile
      const px = wd ? W * 0.68 : 46, py = wd ? 40 : mh + 20, pw = wd ? W * 0.29 : W - 66, ph = wd ? H - 90 : H - mh - 56;
      const mk = [0.02, 0.18, 0.45, 0.7, 0.98][st];
      eprofile(g, px, py, pw, ph, col, [[0, 0.35], [0.25, 0.92], [0.45, 0.55], [0.6, 0.68], [1, 0.12]], mk, [[0.25, 0.92, 'TS₁'], [0.45, 0.55, 'অ্যারেনিয়াম'], [0.6, 0.68, 'TS₂'], [0.03, 0.35, 'C₆H₆ + E⁺'], [0.95, 0.12, 'C₆H₅E']]);
    };
    const info = () => { const d = EASR[rx]; q('[data-st]').textContent = `ধাপ ${bn(st + 1)}/৫`; const T = [`ইলেকট্রোফাইল তৈরি: ${TXB(`\\ce{${d[2]}}`)}`, 'বেনজিনের π মেঘের একটি ইলেকট্রন জোড় ইলেকট্রোফাইলের সাথে নতুন C–E σ বন্ধন গঠন করে। বলয়ের একটি কার্বন sp³ হয় — ৬π ব্যবস্থা ভেঙে যায়, তাই সক্রিয়ণ শক্তি বেশি: এটিই হার-নির্ধারক ধাপ।', 'অ্যারেনিয়াম আয়ন (σ-জটিল বা হুইল্যান্ড মধ্যবর্তী): অবশিষ্ট ৪টি π ইলেকট্রন পাঁচটি কার্বনে বিস্থানীকৃত, ধনাত্মক চার্জ তিনটি রেজোন্যান্স রূপে তিনটি কার্বনে (অর্থো, প্যারা) বিস্তৃত — কিছুটা স্থিতিশীল কিন্তু অ্যারোমেটিক নয়।', `ক্ষারক (${d[3]}) sp³ কার্বনের H⁺ গ্রহণ করে; C–H বন্ধনের ইলেকট্রন জোড় বলয়ে ফিরে ধনাত্মক চার্জ প্রশমিত করে।`, `অ্যারোমেটিক বলয় পুনর্গঠিত — নিট বিক্রিয়া: ${TXB(`\\ce{${d[4]}}`)}`][st]; out.innerHTML = `<div><b>${d[0]} — ${EST[st]}:</b> ${T}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; an += dt * 1.5; if (play) { if (an > 2.2) { if (st < 4) { st++; an = 0; info(); } else play = false; } } } draw(); }, { paused: false });
    X.onSeg(el, 'rx', v => { rx = v; st = 0; an = 0; info(); });
    q('[data-nx]').onclick = () => { play = false; if (st < 4) { st++; an = 0; info(); } };
    q('[data-pv]').onclick = () => { play = false; if (st > 0) { st--; an = 1; info(); } };
    q('[data-play]').onclick = () => { st = 0; an = 0; play = true; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১০.৫ বহু প্রতিস্থাপন ও অরিয়েন্টেশন ======================= */
const DIR = {
  CH3: ['–CH₃ (টলুইন)', 'op', 'act', [58.5, 4.5, 37], '২৫', '+I আবেশ ও হাইপারকনজুগেশন — দুর্বল সক্রিয়কারী, অর্থো-প্যারা নির্দেশক', false],
  OH: ['–OH (ফেনল)', 'op', 'act', [40, 0, 60], '~১০০০', '+M (O এর নিঃসঙ্গ জোড়ের রেজোন্যান্স দান) > −I — প্রবল সক্রিয়কারী, অর্থো-প্যারা', true],
  OCH3: ['–OCH₃ (অ্যানিসোল)', 'op', 'act', [31, 2, 67], 'অনেক বেশি', '+M > −I — প্রবল সক্রিয়কারী, অর্থো-প্যারা (প্যারা বেশি — অর্থোতে স্থানিক বাধা)', true],
  Cl: ['–Cl (ক্লোরোবেনজিন)', 'op', 'deact', [30, 1, 69], '০.০৩৩', '−I > +M — দুর্বল নিষ্ক্রিয়কারী, তবু নিঃসঙ্গ জোড় দান করে অর্থো-প্যারা নির্দেশক (ব্যতিক্রম!)', true],
  NO2: ['–NO₂ (নাইট্রোবেনজিন)', 'm', 'deact', [6.4, 93.2, 0.3], '৬ × ১০⁻⁸', '−I ও −M — প্রবল নিষ্ক্রিয়কারী, মেটা নির্দেশক', false],
  COOH: ['–COOH (বেনজোয়িক এসিড)', 'm', 'deact', [18.5, 80.2, 1.3], '≪ ১', '−I ও −M — নিষ্ক্রিয়কারী, মেটা নির্দেশক', false],
  CHO: ['–CHO (বেনজালডিহাইড)', 'm', 'deact', [19, 72, 9], '≪ ১', '−M — নিষ্ক্রিয়কারী, মেটা নির্দেশক', false],
  CN: ['–CN (বেনজোনাইট্রাইল)', 'm', 'deact', [17, 81, 2], '≪ ১', '−I ও −M — নিষ্ক্রিয়কারী, মেটা নির্দেশক', false]
};
V.p2c2_orient = {
  t: 'বেনজিনে দ্বিতীয় প্রতিস্থাপন ও অরিয়েন্টেশন: সক্রিয়কারী/নিষ্ক্রিয়কারী মূলক, অর্থো-প্যারা বনাম মেটা নির্দেশনা — অ্যারেনিয়াম আয়নের রেজোন্যান্স বিশ্লেষণ ও নাইট্রেশনের পরীক্ষালব্ধ উৎপাদ বণ্টন', k: ['int', '2d', 'calc'],
  cap: 'প্রথম প্রতিস্থাপক (G, বেগুনি) বেছে নাও। তিনটি সারি দেখায় নতুন ইলেকট্রোফাইল অর্থো, মেটা ও প্যারা অবস্থানে আক্রমণ করলে অ্যারেনিয়াম আয়নের রেজোন্যান্স রূপ। অর্থো ও প্যারা আক্রমণে একটি রূপে ধনাত্মক চার্জ ঠিক G যুক্ত কার্বনে পড়ে (বৃত্তচিহ্নিত): G ইলেকট্রনদাতা হলে এটি স্থিতিশীল (সবুজ), ইলেকট্রন-আকর্ষী হলে অস্থিতিশীল (লাল)। –OH, –OCH₃, –Cl এর নিঃসঙ্গ জোড় একটি অতিরিক্ত চতুর্থ রূপ দেয় যেখানে প্রতিটি পরমাণুর অষ্টক পূর্ণ। মেটা আক্রমণে চার্জ কখনো G এর কার্বনে পড়ে না। ডানে পরীক্ষালব্ধ নাইট্রেশন উৎপাদের শতকরা বণ্টন ও বেনজিনের তুলনায় আপেক্ষিক হার।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('g', Object.entries(DIR).map(([k, v]) => [k, v[0].split(' ')[0]]), 'CH3')}</div>${X.cv('অরিয়েন্টেশন')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 420 : 760;
    let L = X.fit(c, hf), gk = 'CH3';
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), d = DIR[gk], G = d[0].split(' ')[0].replace('–', ''), donor = d[2] === 'act' || gk === 'Cl';
      const gw = wd ? W * 0.68 : W, rowH = wd ? (H - 20) / 3 : 150, colW = gw / 5.2, rs = Math.min(24, rowH / 4.2, colW * 0.26);
      [['অর্থো', 1], ['মেটা', 2], ['প্যারা', 3]].forEach(([nm, a], ri) => {
        const y = 14 + ri * rowH + rowH / 2; g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`${nm} আক্রমণ`, 4, y - rowH / 2 + 12);
        const s = a, forms = [[(s + 1) % 6, [(s + 2) % 6, (s + 4) % 6]], [(s + 3) % 6, [(s + 1) % 6, (s + 4) % 6]], [(s + 5) % 6, [(s + 1) % 6, (s + 3) % 6]]];
        forms.forEach(([pl, db], i) => { const x = colW * (i + 0.85); const onG = pl === 0; ring2(g, x, y + 6, rs, col, { dbl: db, plus: pl, sp3: s, E: 'E', G, hot: onG ? (donor ? 'good' : 'bad') : null }); if (onG) { g.strokeStyle = donor ? '#2f9e44' : '#c0392b'; g.lineWidth = 2; g.beginPath(); g.arc(x, y + 6 - rs, 9, 0, 7); g.stroke(); } if (i < 2 || (d[6] && (a === 1 || a === 3))) { g.fillStyle = col.mu; g.font = `12px ${col.font}`; g.textAlign = 'center'; g.fillText('↔', x + colW / 2, y + 10); } });
        if (d[6] && (a === 1 || a === 3)) { const x = colW * 3.85, dbl = a === 1 ? [3] : [1, 4]; const db2 = a === 1 ? [2, 4] : [1, 4]; void dbl; ring2(g, x, y + 6, rs, col, { dbl: a === 1 ? [2, 4] : [1, 4], sp3: s, E: 'E', G, Gdbl: true, Gplus: true }); g.fillStyle = '#2f9e44'; g.font = `bold 9px ${col.font}`; g.textAlign = 'center'; g.fillText('সব অষ্টক পূর্ণ', x, y + rs * 2.1); void db2; }
        const verdict = (a === 2) ? (donor ? 'কম অনুকূল' : 'তুলনামূলক অনুকূল ✓') : (donor ? 'অনুকূল ✓' : 'প্রতিকূল ✗'); g.fillStyle = verdict.includes('✓') ? '#2f9e44' : '#c0392b'; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText(verdict, gw - 6, y - rowH / 2 + 12);
      });
      // bars
      const bx = wd ? W * 0.72 : 50, by = wd ? 40 : 3 * rowH + 36, bw = wd ? W * 0.25 : W - 70, bh = wd ? H * 0.45 : 150;
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('নাইট্রেশন উৎপাদ (%)', bx - (wd ? 0 : 30), by - 10);
      ['অর্থো', 'মেটা', 'প্যারা'].forEach((nm, i) => { const v = d[3][i], h = bh * v / 100, x = bx + i * bw / 3 + 6, w2 = bw / 3 - 12; g.fillStyle = (i === 1) === (d[1] === 'm') ? '#2f9e44' : '#95a5a6'; g.fillRect(x, by + bh - h, w2, h); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(v), x + w2 / 2, by + bh - h - 4); g.font = `9.5px ${col.font}`; g.fillText(nm, x + w2 / 2, by + bh + 12); });
      g.strokeStyle = col.mu; g.beginPath(); g.moveTo(bx, by + bh); g.lineTo(bx + bw, by + bh); g.stroke();
      g.fillStyle = d[2] === 'act' ? '#2f9e44' : '#c0392b'; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`আপেক্ষিক হার: ${d[4]} (বেনজিন = ১)`, bx - (wd ? 0 : 30), by + bh + 30); g.fillText(d[2] === 'act' ? 'সক্রিয়কারী' : 'নিষ্ক্রিয়কারী', bx - (wd ? 0 : 30), by + bh + 46); g.fillStyle = col.fg; g.fillText(d[1] === 'op' ? 'অর্থো-প্যারা নির্দেশক' : 'মেটা নির্দেশক', bx - (wd ? 0 : 30), by + bh + 62);
    };
    const info = () => { const d = DIR[gk]; out.innerHTML = `<div><b>${d[0]}</b>: ${d[5]}।</div><div class="small" style="margin-top:4px">সাধারণ নিয়ম: যে মূলক বলয়ে ইলেকট্রন দান করে (–OH, –NH₂, –OCH₃, –CH₃) তা অ্যারেনিয়াম আয়নকে স্থিতিশীল করে বিক্রিয়া দ্রুত করে (সক্রিয়কারী) এবং অর্থো-প্যারা নির্দেশ করে। যে মূলক ইলেকট্রন টানে (–NO₂, –CN, –CHO, –COOH, –SO₃H) তা বলয় নিষ্ক্রিয় করে এবং মেটা নির্দেশ করে — কারণ অর্থো-প্যারা আক্রমণে চার্জ সরাসরি ইলেকট্রন-আকর্ষী মূলকের পাশে পড়ে। হ্যালোজেন ব্যতিক্রম: −I প্রভাবে নিষ্ক্রিয়কারী কিন্তু +M প্রভাবে অর্থো-প্যারা নির্দেশক।</div>`; };
    X.onSeg(el, 'g', v => { gk = v; info(); draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ২.১০.২ নিউক্লিওফিলিক প্রতিস্থাপন: SN2 ও SN1 (ত্রিমাত্রিক) ======================= */
/* SN2 substrate frame: C at origin, leaving group on +x, three groups at angle θ from +x (θ: 109.47° → 90° (TS) → 70.53°) */
const sn2Frame = (chiral) => {
  const groups = chiral ? [['H'], ['CH3'], ['C2H5']] : [['H'], ['H'], ['H']];
  return groups.map((gg, i) => ({ k: gg[0], phi: i * 2 * Math.PI / 3 + Math.PI / 2 }));
};
const buildSN2 = (s, chiral, nu) => { // s in [0,1]
  const th = (109.47 - 38.94 * ease(s)) * Math.PI / 180, a = [], b = [];
  a.push(['C', 0, 0, 0, { noH: true }]); // 0
  const xBr = 1.94 + 2.6 * Math.max(0, (s - 0.45) / 0.55) + 0.35 * Math.min(1, s / 0.5), xNu = -(4.2 - (4.2 - 1.43) * Math.min(1, s / 0.6) + 0.0);
  a.push(['Br', xBr, 0, 0, { noH: true, q: s > 0.7 ? -1 : 0 }]); // 1
  a.push(['O', xNu, 0, 0, { noH: true, q: s < 0.3 ? -1 : 0 }]); // 2
  a.push(['H', xNu - 0.96 * Math.cos(0.5), 0.96 * Math.sin(0.5), 0, { noH: true }]); // 3 H on O
  if (s < 0.3 || s >= 0.7) { b.push([0, s < 0.7 ? 1 : 2, 1]); } else { b.push([0, 1, 1, 'dash']); b.push([0, 2, 1, 'dash']); }
  if (s >= 0.7) { /* no C–Br */ } else if (s < 0.3) { /* no C–O */ }
  b.push([2, 3, 1]);
  sn2Frame(chiral).forEach(gr => { const d = [Math.cos(th), Math.sin(th) * Math.cos(gr.phi), Math.sin(th) * Math.sin(gr.phi)];
    if (gr.k === 'H') { a.push(['H', ...mul(d, 1.09), { noH: true }]); b.push([0, a.length - 1]); return; }
    const cpos = mul(d, 1.53); a.push(['C', ...cpos, { noH: true }]); const ci = a.length - 1; b.push([0, ci]);
    // methyl/ethyl hydrogens: rigid group oriented along d
    const p = norm(cross(d, [0, 0, 1])), q2 = cross(d, p); const Hdirs = [0, 1, 2].map(j => { const f = j * 2 * Math.PI / 3 + 0.3; return add(mul(d, 1 / 3), mul(add(mul(p, Math.cos(f)), mul(q2, Math.sin(f))), Math.sqrt(8 / 9))); });
    if (gr.k === 'CH3') Hdirs.forEach(h => { a.push(['H', ...add(cpos, mul(h, 1.09)), { noH: true }]); b.push([ci, a.length - 1]); });
    else { const c2 = add(cpos, mul(Hdirs[0], 1.53)); a.push(['C', ...c2, { noH: true }]); const c2i = a.length - 1; b.push([ci, c2i]); [Hdirs[1], Hdirs[2]].forEach(h => { a.push(['H', ...add(cpos, mul(h, 1.09)), { noH: true }]); b.push([ci, a.length - 1]); }); const dd = Hdirs[0], pp = norm(cross(dd, [0, 0, 1])), qq = cross(dd, pp); [0, 1, 2].forEach(j => { const f = j * 2 * Math.PI / 3 + 1.2, hd = add(mul(dd, 1 / 3), mul(add(mul(pp, Math.cos(f)), mul(qq, Math.sin(f))), Math.sqrt(8 / 9))); a.push(['H', ...add(c2, mul(hd, 1.09)), { noH: true }]); b.push([c2i, a.length - 1]); }); }
  });
  void nu; const m = M3.mol({ a, b, H: false }); return m;
};
const buildSN1 = (s, face) => { // tert-butyl: s 0..0.5 ionisation (Br leaves, planarise), 0.5..1 Nu attack from face (+1 back = -x, -1 front = +x)
  const a = [], b = []; a.push(['C', 0, 0, 0, { noH: true, q: s > 0.3 && s < 0.75 ? 1 : 0 }]);
  const s1 = ease(Math.min(1, s / 0.5)), s2 = ease(Math.max(0, (s - 0.5) / 0.5));
  const xBr = 1.97 + 3.2 * s1; a.push(['Br', xBr, 0, 0, { noH: true, q: s1 > 0.6 ? -1 : 0 }]);
  const nuSide = face > 0 ? -1 : 1; const xNu = nuSide * (4.5 - (4.5 - 1.43) * s2); a.push(['O', xNu, 0.0, 1.2 * (1 - s2) * 0, { noH: true, q: s2 < 0.6 ? -1 : 0 }]); a.push(['H', xNu + nuSide * 0.6, 0.75, 0, { noH: true }]);
  if (s1 < 0.4) b.push([0, 1, 1]); else if (s1 < 0.8) b.push([0, 1, 1, 'dash']);
  if (s2 > 0.6) b.push([0, 2, 1]); else if (s2 > 0.25) b.push([0, 2, 1, 'dash']); b.push([2, 3, 1]);
  // methyl angle: start 109.47 from +x (Br side), plane at 90, end: if Nu from −x → 70.53 (groups toward +x) else 109.47
  const th0 = 109.47, thP = 90, thE = nuSide < 0 ? 70.53 : 109.47; const th = (s < 0.5 ? th0 + (thP - th0) * s1 : thP + (thE - thP) * s2) * Math.PI / 180;
  [0, 1, 2].forEach(i => { const phi = i * 2 * Math.PI / 3 + Math.PI / 2, d = [Math.cos(th), Math.sin(th) * Math.cos(phi), Math.sin(th) * Math.sin(phi)], cp = mul(d, 1.53); a.push(['C', ...cp, { noH: true }]); const ci = a.length - 1; b.push([0, ci]); const p = norm(cross(d, [1, 0, 0])), q2 = cross(d, p); [0, 1, 2].forEach(j => { const f = j * 2 * Math.PI / 3 + 0.5, h = add(mul(d, 1 / 3), mul(add(mul(p, Math.cos(f)), mul(q2, Math.sin(f))), Math.sqrt(8 / 9))); a.push(['H', ...add(cp, mul(h, 1.09)), { noH: true }]); b.push([ci, a.length - 1]); }); });
  return M3.mol({ a, b, H: false });
};
V.p2c2_sn2 = {
  t: 'নিউক্লিওফিলিক প্রতিস্থাপন: SN2 (এক ধাপে পেছন দিক থেকে আক্রমণ, ছাতার মতো উল্টে যাওয়া বা ওয়াল্ডেন বিপরীতকরণ) ও SN1 (কার্বোক্যাটায়ন মধ্যবর্তী, দুই দিক থেকে আক্রমণ) — ত্রিমাত্রিক অ্যানিমেশন ও শক্তি লেখচিত্র', k: ['3d', 'anim', 'int'],
  cap: 'কৌশল বেছে নাও ও চালাও (বা স্লাইডারে ধাপে ধাপে দেখো)। SN2: OH⁻ (লাল) Br এর ঠিক বিপরীত দিক থেকে কার্বনে আসে; ট্রানজিশন অবস্থায় (কমলা বিন্দু রেখা) কার্বনে পাঁচটি গ্রুপ — তিনটি একই তলে, O ও Br আংশিক বন্ধনে; তারপর Br⁻ বেরিয়ে যায় এবং বাকি তিনটি গ্রুপ ঝড়ে উল্টে যাওয়া ছাতার মতো অন্য দিকে উল্টে যায়। "কাইরাল" চালু করলে (R)-২-ব্রোমোবিউটেন থেকে (S)-বিউটান-২-অল — বিন্যাস উল্টে যায়। SN1: টারশিয়ারি-বিউটাইল ব্রোমাইডে প্রথমে Br⁻ নিজেই বেরিয়ে যায় (ধীর), তৈরি হয় সমতলীয় sp² কার্বোক্যাটায়ন (খালি p অরবিটাল); তারপর OH⁻ দুই দিকের যেকোনো দিক থেকে সমান সম্ভাবনায় আক্রমণ করে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('mc', [['sn2', 'SN2'], ['sn1', 'SN1']], 'sn2')}<label class="small" data-chw><input type="checkbox" data-ch> কাইরাল সাবস্ট্রেট</label><span data-fw style="display:none">${X.seg('fc', [['1', 'পেছন থেকে আক্রমণ'], ['-1', 'সামনে থেকে আক্রমণ']], '1')}</span><button class="btn sm primary" data-play>▶ চালাও</button></div>${X.cv('নিউক্লিওফিলিক প্রতিস্থাপন')}<div class="ctl"><label class="small" style="flex:1">অগ্রগতি<input type="range" min="0" max="1" step="0.005" value="0" data-s></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 520;
    let L = X.fit(c, hf), mc = 'sn2', chiral = false, face = 1, s = 0, play = false, t = 0; const cam = M3.cam({ yaw: 0.35, pitch: 0.3 });
    C4.drag3d(c, cam, () => A.draw());
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      const m = mc === 'sn2' ? buildSN2(s, chiral) : buildSN1(s, face);
      const mw = wd ? W * 0.64 : W, mh = wd ? H : H * 0.62; cam.cx = mw / 2; cam.cy = mh / 2 + 8; cam.sc = Math.min(mw / 11, mh / 6.5); cam.D = 40;
      const lobes = []; if (mc === 'sn1' && s > 0.42 && s < 0.62) { const k2 = 1 - Math.abs(s - 0.52) / 0.1; [1, -1].forEach(sg => lobes.push({ o: [0, 0, 0], d: [sg, 0, 0], len: 1.2, w: 0.8, col: sg > 0 ? '#3d7fd9' : '#d9433d', a: 0.35 * Math.max(0, k2) })); }
      const hl = { 0: '#f1c40f' }; M3.render(g, m, cam, { mode: 'bs', col, hl, lobes, labels: 'hetero', center: [0, 0, 0] });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center';
      const lab = mc === 'sn2' ? (s < 0.3 ? `${chiral ? '(R)-২-ব্রোমোবিউটেন' : 'CH₃Br'} + OH⁻` : s < 0.7 ? 'ট্রানজিশন অবস্থা [HO···C···Br]⁻ (পঞ্চযোজী, ত্রিকোণীয় দ্বিপিরামিড)' : `${chiral ? '(S)-বিউটান-২-অল' : 'CH₃OH'} + Br⁻ (বিন্যাস উল্টে গেছে)`) : (s < 0.3 ? '(CH₃)₃C–Br' : s < 0.5 ? 'C–Br বিষমবিভাজন (ধীর ধাপ)' : s < 0.65 ? '(CH₃)₃C⁺ — সমতলীয় sp² কার্বোক্যাটায়ন + Br⁻' : '(CH₃)₃C–OH + Br⁻');
      g.fillText(lab, mw / 2, 16);
      // energy profile
      const px = wd ? W * 0.69 : 46, py = wd ? 36 : mh + 18, pw = wd ? W * 0.28 : W - 66, ph = wd ? H - 86 : H - mh - 54;
      if (mc === 'sn2') eprofile(g, px, py, pw, ph, col, [[0, 0.35], [0.5, 0.9], [1, 0.15]], s, [[0.5, 0.9, 'TS'], [0.05, 0.35, 'RX + Nu⁻'], [0.95, 0.15, 'RNu + X⁻']]);
      else eprofile(g, px, py, pw, ph, col, [[0, 0.3], [0.32, 0.92], [0.5, 0.62], [0.62, 0.7], [1, 0.12]], s, [[0.32, 0.92, 'TS₁'], [0.5, 0.62, 'R⁺'], [0.62, 0.7, 'TS₂']]);
    };
    const info = () => { out.innerHTML = mc === 'sn2' ? `<div><b>SN2</b> (Substitution, Nucleophilic, bimolecular): এক ধাপে বন্ধন গঠন ও ভাঙন একসাথে। হার = k[RX][Nu⁻] — দ্বিতীয় ক্রম। পেছন দিক থেকে আক্রমণের ফলে বিন্যাস উল্টে যায় (ওয়াল্ডেন বিপরীতকরণ)${chiral ? ': (R) → (S)' : ''}।</div><div class="small" style="margin-top:4px">সাবস্ট্রেটের সক্রিয়তা: CH₃X > ১° > ২° ≫ ৩° (বড় গ্রুপ পেছনের পথ আটকায় — স্থানিক বাধা)। শক্তিশালী নিউক্লিওফাইল ও পোলার অ্যাপ্রোটিক দ্রাবক (অ্যাসিটোন, DMSO) সহায়ক।</div>${TXB('\\ce{CH3Br + OH- -> CH3OH + Br-}')}` : `<div><b>SN1</b> (unimolecular): দুই ধাপ — (১) C–X বন্ধন নিজে থেকে বিষমবিভাজিত হয়ে কার্বোক্যাটায়ন (ধীর, হার-নির্ধারক); (২) নিউক্লিওফাইল দ্রুত যুক্ত হয়। হার = k[RX] — প্রথম ক্রম, নিউক্লিওফাইলের ঘনত্বের উপর নির্ভর করে না।</div><div class="small" style="margin-top:4px">কার্বোক্যাটায়ন সমতলীয়, তাই নিউক্লিওফাইল দুই দিক থেকে সমান সম্ভাবনায় আসে — কাইরাল সাবস্ট্রেটে রেসেমিক মিশ্রণ (রেসেমাইজেশন)। সক্রিয়তা: ৩° > ২° ≫ ১° > CH₃ (কার্বোক্যাটায়নের স্থিতিশীলতা)। পোলার প্রোটিক দ্রাবক (পানি, অ্যালকোহল) সহায়ক।</div>${TXB('\\ce{(CH3)3C-Br ->[\\text{ধীর}] (CH3)3C+ + Br-}')}${TXB('\\ce{(CH3)3C+ + OH- ->[\\text{দ্রুত}] (CH3)3C-OH}')}`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (play) { s = Math.min(1, s + dt * 0.18); q('[data-s]').value = s; if (s >= 1) play = false; } } draw(); }, { paused: false });
    X.onSeg(el, 'mc', v => { mc = v; s = 0; q('[data-s]').value = 0; q('[data-chw]').style.display = v === 'sn2' ? '' : 'none'; q('[data-fw]').style.display = v === 'sn1' ? '' : 'none'; info(); });
    X.onSeg(el, 'fc', v => { face = +v; s = 0; play = true; });
    q('[data-ch]').onchange = e => { chiral = e.target.checked; info(); };
    q('[data-s]').oninput = e => { s = +e.target.value; play = false; };
    q('[data-play]').onclick = () => { s = 0; play = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১০.১ সংযোজন বিক্রিয়া: মারকনিকভ নিয়ম ও পারক্সাইড প্রভাব ======================= */
V.p2c2_markov = {
  t: 'অ্যালকিনে ইলেকট্রোফিলিক সংযোজন: প্রোপিন + HBr — দুটি সম্ভাব্য কার্বোক্যাটায়ন, স্থিতিশীলতা (৩° > ২° > ১°) ও মারকনিকভ নিয়ম; পারক্সাইডের উপস্থিতিতে মুক্তমূলক পথে বিপরীত-মারকনিকভ সংযোজন (খারাস প্রভাব)', k: ['anim', 'int', '2d'],
  cap: 'বাঁয়ে বাঁকা তীরসহ কৌশল, ডানে দুটি প্রতিযোগী পথের শক্তি লেখচিত্র। আয়নিক পথে C=C এর π জোড় HBr এর H⁺ কে আক্রমণ করে; H যদি প্রান্তের CH₂ তে যায় তবে মাঝের কার্বনে সেকেন্ডারি (২°) কার্বোক্যাটায়ন, মাঝের CH তে গেলে প্রান্তে প্রাইমারি (১°)। ২° কার্বোক্যাটায়ন বেশি স্থিতিশীল (দুটি অ্যালকাইল গ্রুপের +I ও ৬টি α-H এর হাইপারকনজুগেশন), তাই এর পথে সক্রিয়ণ শক্তি কম — প্রধান উৎপাদ ২-ব্রোমোপ্রোপেন (মারকনিকভ)। "পারক্সাইড" চালু করলে Br• মুক্তমূলক প্রথমে প্রান্তের কার্বনে যুক্ত হয়ে বেশি স্থিতিশীল ২° মুক্তমূলক তৈরি করে — উৎপাদ ১-ব্রোমোপ্রোপেন।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${X.seg('pm', [['ion', 'আয়নিক (মারকনিকভ)'], ['rad', 'পারক্সাইডসহ (বিপরীত-মারকনিকভ)']], 'ion')}<button class="btn sm" data-pv>◀</button><button class="btn sm primary" data-nx>পরের ধাপ ▶</button><span class="small" data-st></span></div>${X.cv('মারকনিকভ নিয়ম')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 560;
    let L = X.fit(c, hf), pm = 'ion', st = 0, an = 1, t = 0;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), mw = wd ? W * 0.6 : W, mh = wd ? H : 320, k = Math.min(1, an);
      const S = Math.min(58, mw / 6.5), x0 = mw / 2 - S * 1.2, y0 = mh / 2 + 4; const C1 = [x0, y0], C2 = [x0 + S, y0 - S * 0.5], C3 = [x0 + 2 * S, y0];
      const atom = (p, t2, color) => { g.font = `bold 13px ${col.font}`; const w2 = g.measureText(t2).width + 6; g.fillStyle = col.sf; g.fillRect(p[0] - w2 / 2, p[1] - 9, w2, 18); g.fillStyle = color || col.fg; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(t2, p[0], p[1]); g.textBaseline = 'alphabetic'; };
      const bond = (p, q2, o = 1, dash) => { const dx = q2[0] - p[0], dy = q2[1] - p[1], l = Math.hypot(dx, dy), ux = dx / l, uy = dy / l, nx = -uy * 3, ny = ux * 3; g.strokeStyle = col.fg; g.lineWidth = 1.6; if (dash) g.setLineDash([3, 3]); const offs = o === 2 ? [-1, 1] : [0]; offs.forEach(f => { g.beginPath(); g.moveTo(p[0] + ux * 16 + nx * f, p[1] + uy * 16 + ny * f); g.lineTo(q2[0] - ux * 16 + nx * f, q2[1] - uy * 16 + ny * f); g.stroke(); }); g.setLineDash([]); };
      const titles = pm === 'ion' ? ['প্রোপিন + H–Br', 'ধাপ ১: π জোড় H⁺ আক্রমণ করে (ধীর)', '২° কার্বোক্যাটায়ন (বেশি স্থিতিশীল) + Br⁻', 'ধাপ ২: Br⁻ কার্বোক্যাটায়নে যুক্ত হয় (দ্রুত)', 'প্রধান উৎপাদ: ২-ব্রোমোপ্রোপেন'] : ['RO–OR → 2RO• (তাপ/আলো); RO• + HBr → ROH + Br•', 'Br• প্রান্তের CH₂ তে যুক্ত হয়', '২° মুক্তমূলক (বেশি স্থিতিশীল)', 'মুক্তমূলক HBr থেকে H• টেনে নেয়, নতুন Br• তৈরি (শৃঙ্খল)', 'প্রধান উৎপাদ: ১-ব্রোমোপ্রোপেন'];
      g.fillStyle = col.fg; g.font = `bold 11.5px ${col.font}`; g.textAlign = 'center'; g.fillText(titles[st], mw / 2, 18);
      const ion = pm === 'ion';
      if (st <= 1) { bond(C1, C2); bond(C2, C3, 2); atom(C1, 'CH₃'); atom(C2, 'CH'); atom(C3, 'CH₂'); const Hp = [C3[0] + S * 0.9, C3[1] - S * 1.3], Brp = [Hp[0] + S * 0.9, Hp[1]]; if (ion) { bond(Hp, Brp); atom(Hp, 'H'); atom(Brp, 'Br', '#86280f'); if (st === 1 && k > 0.2) { const mid = [(C2[0] + C3[0]) / 2, (C2[1] + C3[1]) / 2 - 4]; curly(g, mid, [Hp[0] - 8, Hp[1] + 6], -22, '#e67e22'); curly(g, [(Hp[0] + Brp[0]) / 2, Hp[1] - 6], [Brp[0], Brp[1] - 14], -18, '#2d6fd6'); } } else { atom(Hp, 'Br•', '#86280f'); if (st === 1 && k > 0.2) { const mid = [(C2[0] + C3[0]) / 2, (C2[1] + C3[1]) / 2 - 4]; curly(g, [Hp[0] - 6, Hp[1] + 8], [C3[0] + 6, C3[1] - 14], 18, '#8e44ad', 1.6, true); curly(g, mid, [C3[0] - 2, C3[1] - 14], -14, '#8e44ad', 1.6, true); } } }
      if (st === 2 || st === 3) { bond(C1, C2); bond(C2, C3); atom(C1, 'CH₃'); atom(C3, ion ? 'CH₃' : 'CH₂Br', ion ? null : '#86280f'); atom(C2, ion ? 'CH⁺' : 'CH•', ion ? '#2d6fd6' : '#8e44ad'); if (st === 3) { if (ion) { const Br = [C2[0], C2[1] - S * 1.3]; atom(Br, ':Br⁻', '#86280f'); if (k > 0.2) curly(g, [Br[0] - 6, Br[1] + 9], [C2[0] - 6, C2[1] - 12], 16, '#e67e22'); } else { const Hp = [C2[0] + S * 0.4, C2[1] - S * 1.3], Brp = [Hp[0] + S * 0.9, Hp[1]]; bond(Hp, Brp); atom(Hp, 'H'); atom(Brp, 'Br', '#86280f'); if (k > 0.2) curly(g, [C2[0] + 4, C2[1] - 12], [Hp[0] - 4, Hp[1] + 8], -14, '#8e44ad', 1.6, true); } }
        // hyperconjugation hint
        g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(ion ? '২ টি অ্যালকাইল গ্রুপ: +I ও ৬টি α-H হাইপারকনজুগেশন' : 'মুক্তমূলকও ২° হলে বেশি স্থিতিশীল', mw / 2, y0 + S * 1.1); }
      if (st === 4) { bond(C1, C2); bond(C2, C3); atom(C1, 'CH₃'); if (ion) { atom(C2, 'CH'); atom(C3, 'CH₃'); const Br = [C2[0], C2[1] - S * 1.1]; bond(C2, Br); atom(Br, 'Br', '#86280f'); } else { atom(C2, 'CH₂'); atom(C3, 'CH₂Br', '#86280f'); } g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(ion ? 'সামান্য ১-ব্রোমোপ্রোপেন (গৌণ উৎপাদ)' : 'পারক্সাইড প্রভাব কেবল HBr এর ক্ষেত্রে (HCl, HI এ নয়)', mw / 2, y0 + S * 1.1); }
      // energy diagram: two paths
      const px = wd ? W * 0.66 : 46, py = wd ? 36 : mh + 20, pw = wd ? W * 0.31 : W - 66, ph = wd ? H - 90 : H - mh - 56; g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(px, py); g.lineTo(px, py + ph); g.lineTo(px + pw, py + ph); g.stroke(); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('বিক্রিয়ার অগ্রগতি →', px + pw / 2, py + ph + 13);
      const X_ = u => px + u * pw, Y_ = e => py + ph - e * ph; const mk = (pts, color, w) => { const cv = []; for (let i = 0; i < pts.length - 1; i++) for (let s2 = 0; s2 <= 1; s2 += 0.05) { const kk = (1 - Math.cos(s2 * Math.PI)) / 2; cv.push([X_(pts[i][0] + (pts[i + 1][0] - pts[i][0]) * s2), Y_(pts[i][1] + (pts[i + 1][1] - pts[i][1]) * kk)]); } path(g, cv, color, w); return cv; };
      const major = mk([[0, 0.4], [0.3, 0.78], [0.48, 0.55], [0.6, 0.6], [1, 0.12]], '#2f9e44', 2.6), minor = mk([[0, 0.4], [0.3, 0.95], [0.48, 0.78], [0.6, 0.82], [1, 0.16]], '#c0392b', 1.6);
      g.font = `bold 9.5px ${col.font}`; g.fillStyle = '#2f9e44'; g.textAlign = 'left'; g.fillText(ion ? '২° পথ (প্রধান)' : '২° মুক্তমূলক পথ', X_(0.62), Y_(0.58) + 14); g.fillStyle = '#c0392b'; g.fillText(ion ? '১° পথ (গৌণ)' : '১° মুক্তমূলক পথ', X_(0.62), Y_(0.84) - 4);
      const mkI = Math.min(major.length - 1, Math.round([0.02, 0.2, 0.45, 0.65, 0.98][st] * (major.length - 1))); M3.sphere(g, major[mkI][0], major[mkI][1], 6, '#f39c12', '#ffe0a0'); void minor;
    };
    const info = () => { q('[data-st]').textContent = `ধাপ ${bn(st + 1)}/৫`; out.innerHTML = pm === 'ion' ? `<div><b>মারকনিকভ নিয়ম (১৮৬৯):</b> অপ্রতিসম অ্যালকিনে অপ্রতিসম বিকারক (HX, H₂O/H⁺) যুক্ত হলে বিকারকের ধনাত্মক অংশ (H) দ্বিবন্ধনের সেই কার্বনে যুক্ত হয় যেটিতে আগে থেকে বেশি H আছে; ঋণাত্মক অংশ যায় কম H যুক্ত কার্বনে। আধুনিক ব্যাখ্যা: বেশি স্থিতিশীল কার্বোক্যাটায়ন তৈরি হয়।</div>${TXB('\\ce{CH3-CH=CH2 + HBr -> CH3-CHBr-CH3}')}<div class="small">কার্বোক্যাটায়নের স্থিতিশীলতা: ৩° > ২° > ১° > CH₃⁺ — অ্যালকাইল গ্রুপের +I প্রভাব ও হাইপারকনজুগেশন ধনাত্মক চার্জ ছড়িয়ে দেয়।</div>` : `<div><b>পারক্সাইড প্রভাব (খারাস, ১৯৩৩):</b> জৈব পারক্সাইডের (R–O–O–R) উপস্থিতিতে HBr অপ্রতিসম অ্যালকিনে মারকনিকভ নিয়মের বিপরীতভাবে যুক্ত হয় — মুক্তমূলক শৃঙ্খল কৌশল।</div>${TXB('\\ce{CH3-CH=CH2 + HBr ->[\\text{(PhCOO)}_2] CH3-CH2-CH2Br}')}<div class="small">HCl এর H–Cl বন্ধন খুব শক্তিশালী ও HI এর I• সংযোজন প্রতিকূল — তাই কেবল HBr এ পারক্সাইড প্রভাব দেখা যায়।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; an += dt * 1.5; } draw(); }, { paused: false });
    X.onSeg(el, 'pm', v => { pm = v; st = 0; an = 0; info(); });
    q('[data-nx]').onclick = () => { if (st < 4) { st++; an = 0; info(); } };
    q('[data-pv]').onclick = () => { if (st > 0) { st--; an = 1; info(); } };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১০.৩ অপসারণ বিক্রিয়া: E2 (ত্রিমাত্রিক) ও সেজেফ নিয়ম ======================= */
const e2Start = () => { const m = M3.relax(M3.tree([['C', -1], ['C', 0], ['Br', 0]], 'ব্রোমোইথেন')); return m; };
const E2D = (() => {
  const m = e2Start(); // atoms: 0 Cα? tree: 0 C (has Br at idx2), 1 C (β)
  const Ca = 0, Cb = 1, Br = 2; const P = m.a.map(a => a.p.slice());
  const u = norm(sub(P[Cb], P[Ca])), brv = sub(P[Br], P[Ca]), v = norm(sub(brv, mul(u, dot(brv, u))));
  // anti-periplanar β-H: H on Cb with largest component along −v
  const Hb = M3.nbrs(m, Cb).filter(j => m.a[j].el === 'H'); const anti = Hb.reduce((best, j) => dot(sub(P[j], P[Cb]), v) < dot(sub(P[best], P[Cb]), v) ? j : best, Hb[0]);
  const w = norm(cross(u, v));
  // end positions: alkene in plane spanned by u and w
  const mid = mul(add(P[Ca], P[Cb]), 0.5), E = P.map(p => p.slice()); E[Ca] = sub(mid, mul(u, 0.67)); E[Cb] = add(mid, mul(u, 0.67));
  const place = (c, sgn, hs) => { hs.forEach(j => { const side = dot(sub(P[j], P[c]), w) >= 0 ? 1 : -1; const ang = 121.5 * Math.PI / 180; E[j] = add(E[c], mul(add(mul(u, sgn * Math.cos(Math.PI - ang)), mul(w, side * Math.sin(Math.PI - ang))), 1.086)); }); };
  place(Ca, -1, M3.nbrs(m, Ca).filter(j => m.a[j].el === 'H')); place(Cb, 1, Hb.filter(j => j !== anti));
  E[Br] = add(P[Br], mul(v, 3.0));
  // base O approaching anti H along −v
  const Ostart = add(P[anti], mul(v, -3.2)), Oend = add(P[anti], mul(v, -1.6)); E[anti] = add(P[anti], mul(v, -0.5));
  return { m, P, E, Ca, Cb, Br, anti, Ostart, Oend, v };
})();
V.p2c2_e2 = {
  t: 'অপসারণ বিক্রিয়া: E2 কৌশল — ক্ষারক β-H টানে, একই সাথে C=C তৈরি ও Br⁻ বিদায় (অ্যান্টি-পেরিপ্ল্যানার জ্যামিতি, ত্রিমাত্রিক); সেজেফ নিয়ম ও SN2 এর সাথে প্রতিযোগিতা', k: ['3d', 'anim', 'int'],
  cap: 'চালাও বা স্লাইডারে দেখো। অ্যালকোহলীয় KOH এর OH⁻ (লাল) β-কার্বনের সেই H টির দিকে আসে যেটি Br এর ঠিক বিপরীত দিকে (অ্যান্টি-পেরিপ্ল্যানার — H–C–C–Br দ্বিতল কোণ ১৮০°)। এক ধাপেই তিনটি ঘটনা: O–H বন্ধন তৈরি, C–H বন্ধনের ইলেকট্রন C–C এর মাঝে নতুন π বন্ধন তৈরি, এবং C–Br বন্ধনের ইলেকট্রন নিয়ে Br⁻ বিদায়। শেষে দুই কার্বন sp² — সমতলীয় ইথিন। নিচে সেজেফ নিয়মের উদাহরণ।',
  html: () => `${X.cv('E2 অপসারণ')}<div class="ctl"><button class="btn sm primary" data-play>▶ চালাও</button><label class="small" style="flex:1">অগ্রগতি<input type="range" min="0" max="1" step="0.005" value="0" data-s></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 520;
    let L = X.fit(c, hf), s = 0, play = false, t = 0; const cam = M3.cam({ yaw: 0.9, pitch: 0.25 });
    C4.drag3d(c, cam, () => A.draw());
    const D = E2D;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), k = ease(Math.max(0, Math.min(1, (s - 0.15) / 0.7))), ko = ease(Math.min(1, s / 0.4));
      const a = D.m.a.map((at, i) => [at.el, ...add(mul(D.P[i], 1 - k), mul(D.E[i], k)), { noH: true, q: at.el === 'Br' && k > 0.7 ? -1 : 0 }]);
      const Op = add(mul(D.Ostart, 1 - ko), mul(D.Oend, ko)); const Hon = add(Op, mul(norm(sub(Op, D.P[D.Ca])), 0.96)); a.push(['O', ...Op, { noH: true, q: k < 0.5 ? -1 : 0 }]); a.push(['H', ...add(Op, [0, 0.9, 0.3]), { noH: true }]); void Hon;
      const iO = a.length - 2, iH2 = a.length - 1; const b = [];
      D.m.b.forEach(bb => { const isBr = (bb.i === D.Br || bb.j === D.Br), isAnti = (bb.i === D.anti || bb.j === D.anti), isCC = (bb.i === D.Ca && bb.j === D.Cb) || (bb.j === D.Ca && bb.i === D.Cb); if (isBr) { if (k < 0.3) b.push([bb.i, bb.j, 1]); else if (k < 0.75) b.push([bb.i, bb.j, 1, 'dash']); return; } if (isAnti) { if (k < 0.3) b.push([bb.i, bb.j, 1]); else if (k < 0.75) b.push([bb.i, bb.j, 1, 'dash']); return; } if (isCC) { b.push([bb.i, bb.j, k > 0.6 ? 2 : 1]); return; } b.push([bb.i, bb.j, 1]); });
      b.push([iO, iH2, 1]); if (k > 0.3 && k < 0.75) b.push([iO, D.anti, 1, 'dash']); else if (k >= 0.75) b.push([iO, D.anti, 1]);
      const m = M3.mol({ a, b, H: false }); m.a[D.Ca].pn = null;
      const mw = wd ? W * 0.64 : W, mh = wd ? H : H * 0.62; cam.cx = mw / 2; cam.cy = mh / 2 + 6; cam.sc = Math.min(mw / 9.5, mh / 6); cam.D = 40; if (!cam.user) cam.yaw = 0.9 + 0.25 * Math.sin(t * 0.3);
      const hl = {}; hl[D.anti] = '#f1c40f'; M3.render(g, m, cam, { mode: 'bs', col, hl, labels: 'hetero', center: mul(add(D.P[D.Ca], D.P[D.Cb]), 0.5), measure: k < 0.05 ? [[D.anti, D.Cb, D.Ca, D.Br]] : [] });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(k < 0.05 ? 'CH₃CH₂Br + OH⁻ (অ্যালকোহলীয়)' : k < 0.75 ? 'ট্রানজিশন অবস্থা: চারটি বন্ধন একসাথে বদলাচ্ছে' : 'CH₂=CH₂ + H₂O + Br⁻', mw / 2, 16);
      // Saytzeff bars
      const px = wd ? W * 0.68 : 40, py = wd ? 40 : mh + 26, pw = wd ? W * 0.28 : W - 60, ph = wd ? H * 0.42 : H - mh - 80; g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('২-ব্রোমোবিউটেন + KOH (অ্যালকোহলীয়)', px, py - 10);
      [['বিউট-২-ইন', 81, '#2f9e44'], ['বিউট-১-ইন', 19, '#95a5a6']].forEach(([nm, v, cc], i) => { const y = py + i * (ph / 2.2) + 6, w2 = pw * v / 100; g.fillStyle = cc; g.fillRect(px, y, w2, ph / 3.2); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText(`${nm}: ${bn(v)}%`, px + 4, y + ph / 3.2 + 12); });
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText('বেশি প্রতিস্থাপিত (বেশি স্থিতিশীল) অ্যালকিন প্রধান', px, py + ph + 18);
    };
    const info = () => { out.innerHTML = `<div><b>E2 (Elimination, bimolecular):</b> এক ধাপে H–X অপসারণ; হার = k[RX][ক্ষারক]। β-H ও বিদায়ী গ্রুপ অ্যান্টি-পেরিপ্ল্যানার হলে C–H ও C–Br অরবিটাল একই তলে সমান্তরাল থাকে, তাই নতুন π বন্ধন মসৃণভাবে তৈরি হয়।</div>${TXB('\\ce{CH3CH2Br + KOH ->[\\text{অ্যালকোহল},\\ \\Delta] CH2=CH2 + KBr + H2O}')}<div class="small"><b>সেজেফ নিয়ম:</b> অপসারণে একাধিক অ্যালকিন সম্ভব হলে বেশি অ্যালকাইল-প্রতিস্থাপিত (বেশি স্থিতিশীল) অ্যালকিন প্রধান উৎপাদ: CH₃CHBrCH₂CH₃ → CH₃CH=CHCH₃ (প্রধান) + CH₂=CHCH₂CH₃। <b>প্রতিযোগিতা:</b> জলীয় KOH → প্রতিস্থাপন (অ্যালকোহল, SN); অ্যালকোহলীয় KOH ও উচ্চ তাপ → অপসারণ (অ্যালকিন, E)। ৩° হ্যালাইড ও ভারী ক্ষারকে অপসারণ বেশি।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (play) { s = Math.min(1, s + dt * 0.2); q('[data-s]').value = s; if (s >= 1) play = false; } } draw(); }, { paused: false });
    q('[data-s]').oninput = e => { s = +e.target.value; play = false; }; q('[data-play]').onclick = () => { s = 0; play = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ২.১০.৪ পুনর্বিন্যাস: কার্বোক্যাটায়নে ১,২-মিথাইল স্থানান্তর ======================= */
const SHIFT = (() => { // 3,3-dimethylbutan-2-yl cation → 2,3-dimethylbutan-2-yl cation
  const L1 = [['C', -1], ['C', 0, 1, null, { q: 1 }], ['C', 1], ['C', 2], ['C', 2], ['C', 2]]; // 0 C1, 1 C2(+), 2 C3, 3,4,5 methyls on C3
  const m1 = M3.relax(M3.tree(L1, { name: '' })); const mig = 5;
  const m2 = M3.clone(m1); m2.b = m2.b.filter(b => !((b.i === 2 && b.j === mig) || (b.j === 2 && b.i === mig))); m2.b.push({ i: 1, j: mig, o: 1 }); m2.a[1].q = 0; m2.a[2].q = 1; m2.a[1].p = m1.a[1].p.slice();
  // move migrating CH3 roughly to C2 before relaxing
  const migSet = [mig].concat(M3.nbrs(m1, mig).filter(j => m1.a[j].el === 'H')); const sh = sub(m1.a[1].p, m1.a[2].p); migSet.forEach(j => { m2.a[j].p = add(m1.a[j].p, sh); }); M3.relax(m2, 400);
  // align m2 onto m1 by C1,C2 frame for smooth interpolation
  return { m1, m2, mig, migSet };
})();
V.p2c2_shift = {
  t: 'পারমাণবিক পুনর্বিন্যাস: সেকেন্ডারি কার্বোক্যাটায়নে ১,২-মিথাইল স্থানান্তরে অধিক স্থিতিশীল টারশিয়ারি কার্বোক্যাটায়ন (ত্রিমাত্রিক) — সাথে সমাণুকরণের উদাহরণ', k: ['3d', 'anim', 'int'],
  cap: 'চালাও: ৩,৩-ডাইমিথাইলবিউট-২-ইল কার্বোক্যাটায়নে (২°, হলুদ আভার কার্বনে ধনাত্মক চার্জ) পাশের কার্বনের একটি মিথাইল মূলক (সবুজ) তার বন্ধনী ইলেকট্রন জোড়সহ ধনাত্মক কার্বনে সরে যায়। এখন ধনাত্মক চার্জ চলে আসে আগের কার্বনে, যা তিনটি কার্বনের সাথে যুক্ত — টারশিয়ারি (৩°), বেশি স্থিতিশীল। এ কারণেই ৩,৩-ডাইমিথাইলবিউট-১-ইনে HCl যুক্ত করলে প্রত্যাশিত উৎপাদের সাথে "পুনর্বিন্যস্ত" ২-ক্লোরো-২,৩-ডাইমিথাইলবিউটেনও পাওয়া যায়।',
  html: () => `${X.cv('১,২-স্থানান্তর')}<div class="ctl"><button class="btn sm primary" data-play>▶ চালাও</button><label class="small" style="flex:1">অগ্রগতি<input type="range" min="0" max="1" step="0.005" value="0" data-s></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 400;
    let L = X.fit(c, hf), s = 0, play = false, t = 0; const cam = M3.cam({ yaw: 0.4, pitch: 0.3 });
    C4.drag3d(c, cam, () => A.draw());
    const D = SHIFT;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const k = ease(Math.max(0, Math.min(1, (s - 0.1) / 0.8)));
      const m = M3.clone(D.m1); m.a.forEach((a, i) => { a.p = add(mul(D.m1.a[i].p, 1 - k), mul(D.m2.a[i].p, k)); }); m.b = (k < 0.5 ? D.m1.b : D.m2.b).map(b => Object.assign({}, b)); if (k > 0.25 && k < 0.75) { m.b = m.b.filter(b => !(b.i === D.mig || b.j === D.mig) || M3.nbrs(D.m1, D.mig).includes(b.i === D.mig ? b.j : b.i) && D.m1.a[b.i === D.mig ? b.j : b.i].el === 'H'); m.b.push({ i: 1, j: D.mig, o: 1, st: 'dash' }); m.b.push({ i: 2, j: D.mig, o: 1, st: 'dash' }); }
      m.a[1].q = k < 0.5 ? 1 : 0; m.a[2].q = k < 0.5 ? 0 : 1; M3.offsets(m); M3.center(m);
      cam.cx = W / 2; cam.cy = H / 2 + 8; M3.fit(D.m1, cam, W, H - 40, 0.95); if (!cam.user) cam.yaw += 0.003;
      const hl = {}; hl[k < 0.5 ? 1 : 2] = '#f1c40f'; D.migSet.forEach(j => { if (D.m1.a[j].el === 'C') hl[j] = '#2ecc71'; });
      M3.render(g, m, cam, { mode: 'bs', col, hl, center: D.m1.c });
      g.fillStyle = col.fg; g.font = `bold 11.5px ${col.font}`; g.textAlign = 'center'; g.fillText(k < 0.1 ? '২° কার্বোক্যাটায়ন: (CH₃)₃C–C⁺H–CH₃' : k < 0.9 ? '১,২-মিথাইল স্থানান্তর (মিথাইল মূলক ইলেকট্রন জোড়সহ সরে)' : '৩° কার্বোক্যাটায়ন: (CH₃)₂C⁺–CH(CH₃)–CH₃', W / 2, 16);
    };
    const info = () => { out.innerHTML = `<div><b>পুনর্বিন্যাস বিক্রিয়া:</b> যে বিক্রিয়ায় অণুর ভেতরে পরমাণু বা মূলকের স্থান পরিবর্তনের ফলে নতুন কাঠামোর যৌগ (প্রায়ই সমাণু) তৈরি হয়। কার্বোক্যাটায়ন সবসময় বেশি স্থিতিশীল রূপে যেতে চায়: H⁻ (হাইড্রাইড) বা CH₃⁻ এর ১,২-স্থানান্তরে ২° → ৩°।</div>${TXB('\\ce{(CH3)3C-CH=CH2 + HCl -> (CH3)2CCl-CH(CH3)2 + (CH3)3C-CHCl-CH3}')}<div class="small"><b>সমাণুকরণ:</b> n-বিউটেন অনার্দ্র AlCl₃ ও HCl এর সাথে ~২০০ °C এ আইসোবিউটেনে রূপান্তরিত হয় — পেট্রোলের অকটেন নম্বর বাড়াতে শিল্পে ব্যবহৃত: {CH₃CH₂CH₂CH₃ → (CH₃)₂CHCH₃}। অ্যামোনিয়াম সায়ানেট → ইউরিয়াও একটি পুনর্বিন্যাস।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (play) { s = Math.min(1, s + dt * 0.22); q('[data-s]').value = s; if (s >= 1) play = false; } } draw(); }, { paused: false });
    q('[data-s]').oninput = e => { s = +e.target.value; play = false; }; q('[data-play]').onclick = () => { s = 0; play = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
