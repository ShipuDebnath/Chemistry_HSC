/* ২য় পত্র অধ্যায় ৩ visuals part 8 — 3.15 Beer–Lambert (spectrophotometer, photon attenuation, calibration curve); 3.16 atomic absorption spectroscopy */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit;max-width:100%">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const sig = (v, d = 3) => { if (!isFinite(v)) return '—'; if (v === 0) return '০'; const a = Math.abs(v); if (a >= 1e5 || a < 1e-3) { const e = Math.floor(Math.log10(a)), m = v / 10 ** e; const sup = String(e).split('').map(ch => '⁻⁰¹²³⁴⁵⁶⁷⁸⁹'['-0123456789'.indexOf(ch)]).join(''); return `${bn(m.toFixed(d - 1))} × ১০${sup}`; } return bn((+v.toPrecision(d)).toString()); };
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
// visible wavelength → rgb
const wl2rgb = (w, a = 1) => { let r = 0, g = 0, b = 0; if (w < 380) { r = 0.45; b = 0.6; } else if (w < 440) { r = -(w - 440) / 60; b = 1; } else if (w < 490) { g = (w - 440) / 50; b = 1; } else if (w < 510) { g = 1; b = -(w - 510) / 20; } else if (w < 580) { r = (w - 510) / 70; g = 1; } else if (w < 645) { r = 1; g = -(w - 645) / 65; } else if (w <= 780) { r = 1; } else { r = 0.5; } return `rgba(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)},${a})`; };
const gauss = (x, m, s) => Math.exp(-0.5 * ((x - m) / s) ** 2);

/* ======================= ৩.১৫ বিয়ার-ল্যাম্বার্ট সূত্র ======================= */
// [name, εmax, spectrum fn(λ)→relative, colour, λmax, unit-ish note]
const BS = [
  { n: 'KMnO₄ (পারম্যাঙ্গানেট)', e: 2400, lm: 525, sp: l => 0.75 * gauss(l, 507, 14) + gauss(l, 526, 13) + 0.85 * gauss(l, 546, 14) + 0.3 * gauss(l, 311, 20), col: '#8e24aa', cmax: 4e-4 },
  { n: '[Fe(phen)₃]²⁺ (আয়রন নির্ণয়)', e: 11100, lm: 510, sp: l => gauss(l, 510, 38) + 0.4 * gauss(l, 470, 25), col: '#e8590c', cmax: 1e-4 },
  { n: '[Cu(NH₃)₄]²⁺ (টেট্রাঅ্যামিন কপার)', e: 52, lm: 600, sp: l => gauss(l, 600, 70), col: '#1864ab', cmax: 0.02 },
  { n: 'K₂Cr₂O₇ (অম্লীয়)', e: 3150, lm: 350, sp: l => gauss(l, 350, 28) + 0.12 * gauss(l, 440, 35) + 0.85 * gauss(l, 257, 18), col: '#f08c00', cmax: 3e-4 }
];
V.p2c3_beerLambert = {
  t: 'বিয়ার-ল্যাম্বার্ট সূত্র ও বর্ণালিমিতি: আলোর উৎস → একবর্ণী যন্ত্র → কিউভেট → ডিটেক্টর; ফোটনের ক্ষয়, A = εlc, ট্রান্সমিট্যান্স, শোষণ বর্ণালি ও λmax, প্রমাণ রেখা (calibration curve) থেকে অজানা ঘনমাত্রা এবং উচ্চ ঘনমাত্রায় বিচ্যুতি', k: ['anim', 'int', 'calc', 'plot'],
  cap: 'উপরে বর্ণালিমিটারের কার্যপ্রণালি: সাদা আলো প্রিজম/গ্রেটিংয়ে বিভক্ত হয়, নির্বাচিত তরঙ্গদৈর্ঘ্যের আলো কিউভেটের দ্রবণ ভেদ করে — প্রতিটি ফোটন বিন্দু দ্রবণে শোষিত হতে পারে; ডিটেক্টরে কম ফোটন পৌঁছায়। ঘনমাত্রা (c), পথদৈর্ঘ্য (l) ও তরঙ্গদৈর্ঘ্য (λ) বদলাও। নিচে বামে দ্রবের শোষণ বর্ণালি (λmax এ সর্বোচ্চ সংবেদনশীলতা), ডানে প্রমাণ রেখা: পাঁচটি প্রমাণ দ্রবণের শোষণ বনাম ঘনমাত্রা সরলরেখা — "অজানা নমুনা মাপো" চাপলে অজানার শোষণ থেকে রেখায় ঘনমাত্রা পড়া হয়। খুব বেশি ঘনমাত্রায় (A > ~১.৫) সূত্র থেকে বিচ্যুতি দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-s', BS.map((s, i) => [String(i), s.n]), '0')}<button class="btn sm" data-u>🔬 অজানা নমুনা মাপো</button><button class="btn sm" data-lm>λmax এ যাও</button></div>${X.cv('বিয়ার-ল্যাম্বার্ট')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:130px">c = <b data-cv></b><input type="range" min="0" max="1.5" step="0.01" value="0.5" data-c></label><label class="small" style="flex:1;min-width:110px">l = <b data-lv></b> cm<input type="range" min="0.2" max="5" step="0.1" value="1" data-l></label><label class="small" style="flex:1;min-width:130px">λ = <b data-wv></b> nm<input type="range" min="200" max="800" step="1" value="525" data-w></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 400 : 560;
    let L = X.fit(c, hf), si = 0, cf = 0.5, l = 1, lam = 525, t = 0, unk = null;
    const S = () => BS[si];
    const conc = () => cf * S().cmax; // mol/L
    const eps = lm => S().e * S().sp(lm) / S().sp(S().lm);
    const Areal = (cc, lm, ll) => { const Aid = eps(lm) * ll * cc; return Aid > 1 ? 1 + (Aid - 1) * 0.72 - 0.06 * (Aid - 1) ** 2 * 0.5 : Aid; }; // mild negative deviation at high A (stray light/aggregation)
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const s = S(), wd = wide(W), cc = conc(), A = Math.max(0, Areal(cc, lam, l)), Tr = 10 ** -A;
      // schematic
      const y = wd ? 60 : 50, x0 = 18, x1 = W - 18; const lampX = x0 + 14, prX = x0 + (x1 - x0) * 0.2, slX = x0 + (x1 - x0) * 0.33, cuX = x0 + (x1 - x0) * 0.55, deX = x1 - 30;
      g.fillStyle = '#ffe066'; g.beginPath(); g.arc(lampX, y, 11, 0, 7); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.stroke(); T(g, wd ? 'আলোর উৎস' : 'উৎস', lampX + 4, y + 30, col, { s: 8.5, c: col.mu });
      // white beam to prism
      g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 4; g.beginPath(); g.moveTo(lampX + 12, y); g.lineTo(prX - 10, y); g.stroke(); g.strokeStyle = col.mu; g.lineWidth = 1; g.beginPath(); g.moveTo(lampX + 12, y - 2); g.lineTo(prX - 10, y - 2); g.stroke();
      g.fillStyle = 'rgba(180,210,240,.5)'; g.beginPath(); g.moveTo(prX, y - 18); g.lineTo(prX - 14, y + 14); g.lineTo(prX + 14, y + 14); g.closePath(); g.fill(); g.strokeStyle = col.fg; g.stroke(); T(g, wd ? 'একবর্ণী যন্ত্র' : 'প্রিজম', prX, y + (wd ? 30 : 42), col, { s: 8.5, c: col.mu });
      for (let k = 0; k < 7; k++) { const wl = 400 + k * 50; g.strokeStyle = wl2rgb(wl, 0.8); g.lineWidth = 1.5; g.beginPath(); g.moveTo(prX + 8, y); g.lineTo(slX, y - 18 + k * 6); g.stroke(); }
      g.fillStyle = col.fg; g.fillRect(slX - 2, y - 24, 4, 20); g.fillRect(slX - 2, y + 4, 4, 20); if (wd) T(g, 'রেখাছিদ্র', slX, y + 34, col, { s: 8.5, c: col.mu });
      const beam = wl2rgb(lam, 0.95); g.strokeStyle = beam; g.lineWidth = 3; g.beginPath(); g.moveTo(slX, y); g.lineTo(cuX - 20 * l / 2 - 8, y); g.stroke();
      // cuvette
      const cw = Math.max(16, Math.min(90, 18 * l)), ch = 46; g.fillStyle = `rgba(${parseInt(s.col.slice(1, 3), 16)},${parseInt(s.col.slice(3, 5), 16)},${parseInt(s.col.slice(5, 7), 16)},${Math.min(0.85, 0.08 + (1 - 10 ** -(s.e * cc * 1)) * 0.8).toFixed(3)})`; g.fillRect(cuX - cw / 2, y - ch / 2, cw, ch); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.strokeRect(cuX - cw / 2, y - ch / 2, cw, ch); T(g, wd ? `কিউভেট (l = ${bn(l)} cm)` : 'কিউভেট', cuX, y + ch / 2 + 14, col, { s: 8.5, c: col.mu });
      // photons
      const nP = 22; for (let i = 0; i < nP; i++) { const ph = (t * 0.35 + i / nP) % 1, seed = (i * 0.6180339) % 1, xx = slX + ph * (deX - slX), yy = y + (seed - 0.5) * 10; const inC = xx > cuX - cw / 2; const absorbed = seed > Tr; const depth = (xx - (cuX - cw / 2)) / cw; if (inC && absorbed && depth > (seed - Tr) / (1 - Tr + 1e-9)) continue; g.fillStyle = beam; g.beginPath(); g.arc(xx, yy, 2.4, 0, 7); g.fill(); }
      g.fillStyle = col.s3 || '#999'; rr(g, deX - 10, y - 18, 30, 36, 4); g.fill(); g.strokeStyle = col.fg; g.stroke(); T(g, 'ডিটেক্টর', deX + 5, y + 32, col, { s: 8.5, c: col.mu }); T(g, `I₀ → I`, (cuX + deX) / 2, y - 24, col, { s: 9, c: col.mu });
      // readout
      T(g, `A = ${bn(A.toFixed(3))}   %T = ${bn((Tr * 100).toFixed(1))}%`, W / 2, wd ? 18 : 16, col, { b: true, s: 12, c: col.acc });
      // spectrum plot
      const py0 = wd ? 130 : 120, gx = wd ? 40 : 34, gw = wd ? W * 0.44 : W - 48, gh = wd ? H - py0 - 40 : 170; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(gx, py0, gw, gh); for (let wv = 380; wv < 780; wv += 2) { g.fillStyle = wl2rgb(wv, 0.18); g.fillRect(gx + (wv - 200) / 600 * gw, py0 + gh - 6, gw / 300 + 1, 6); }
      let mx = 0; for (let wv = 200; wv <= 800; wv += 2) mx = Math.max(mx, eps(wv)); g.beginPath(); for (let wv = 200; wv <= 800; wv += 2) { const xx = gx + (wv - 200) / 600 * gw, yy = py0 + gh - eps(wv) / mx * (gh - 14); wv === 200 ? g.moveTo(xx, yy) : g.lineTo(xx, yy); } g.strokeStyle = s.col; g.lineWidth = 2; g.stroke(); const lx = gx + (lam - 200) / 600 * gw; g.strokeStyle = beam; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(lx, py0); g.lineTo(lx, py0 + gh); g.stroke(); g.setLineDash([]); T(g, `λmax ${bn(s.lm)} nm`, gx + (s.lm - 200) / 600 * gw, py0 + 12, col, { s: 9, b: true, c: s.col }); [200, 400, 600, 800].forEach(v => T(g, bn(v), gx + (v - 200) / 600 * gw, py0 + gh + 12, col, { s: 8.5, c: col.mu })); T(g, 'শোষণ বর্ণালি: ε বনাম λ (nm)', gx + gw / 2, py0 + gh + 24, col, { s: 9, c: col.mu });
      // calibration plot
      const cx0 = wd ? W * 0.55 : 34, cy0 = wd ? py0 : py0 + gh + 44, cw2 = wd ? W * 0.42 : W - 48, ch2 = wd ? gh : H - cy0 - 34; g.strokeStyle = col.ln || col.mu; g.strokeRect(cx0, cy0, cw2, ch2); const cMaxP = 1.5 * s.cmax, Amax = Math.max(0.2, Areal(cMaxP, lam, l) * 1.1, eps(lam) * l * cMaxP * 1.05); const Xc = v => cx0 + v / cMaxP * cw2, Ya = a => cy0 + ch2 - a / Amax * ch2;
      g.strokeStyle = col.mu; g.setLineDash([4, 3]); g.beginPath(); g.moveTo(Xc(0), Ya(0)); g.lineTo(Xc(cMaxP), Ya(eps(lam) * l * cMaxP)); g.stroke(); g.setLineDash([]); g.beginPath(); for (let i = 0; i <= 60; i++) { const v = cMaxP * i / 60; i ? g.lineTo(Xc(v), Ya(Areal(v, lam, l))) : g.moveTo(Xc(v), Ya(0)); } g.strokeStyle = col.fg; g.lineWidth = 1.5; g.stroke();
      [0.2, 0.4, 0.6, 0.8, 1.0].forEach(f => { const v = f * s.cmax; g.fillStyle = col.acc; g.beginPath(); g.arc(Xc(v), Ya(Areal(v, lam, l)), 4, 0, 7); g.fill(); });
      g.fillStyle = '#e03131'; g.beginPath(); g.arc(Xc(cc), Ya(A), 5, 0, 7); g.fill();
      if (unk) { const Au = Areal(unk, lam, l), cu = Au / (eps(lam) * l); g.strokeStyle = '#2f9e44'; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(cx0, Ya(Au)); g.lineTo(Xc(cu), Ya(Au)); g.lineTo(Xc(cu), cy0 + ch2); g.stroke(); g.setLineDash([]); g.fillStyle = '#2f9e44'; g.beginPath(); g.arc(Xc(cu), Ya(Au), 5, 0, 7); g.fill(); T(g, 'অজানা', Xc(cu) + 6, Ya(Au) - 6, col, { s: 9, b: true, c: '#2f9e44', a: 'left' }); }
      T(g, 'প্রমাণ রেখা: A বনাম c', cx0 + cw2 / 2, cy0 + ch2 + 14, col, { s: 9, c: col.mu }); T(g, 'A', cx0 - 8, cy0 + 8, col, { s: 9, c: col.mu });
    };
    const info = () => { const s = S(), cc = conc(), A = Math.max(0, Areal(cc, lam, l)), Aid = eps(lam) * l * cc; q('[data-cv]').textContent = `${sig(cc)} M`; q('[data-lv]').textContent = bn(l); q('[data-wv]').textContent = bn(lam);
      let u = ''; if (unk) { const Au = Areal(unk, lam, l), cu = Au / (eps(lam) * l); u = `<div class="small"><b>অজানা নমুনা:</b> A = ${bn(Au.toFixed(3))} ⇒ c = A/(εl) = ${bn(Au.toFixed(3))} ÷ (${sig(eps(lam))} × ${bn(l)}) = <b>${sig(cu)} M</b>${Au > 1.2 ? ' — ⚠️ শোষণ বেশি, নমুনা লঘু করে আবার মাপা উচিত (রৈখিক পরিসরের বাইরে)।' : ''}</div>`; }
      out.innerHTML = `<div>${TXB(`A = \\log\\dfrac{I_0}{I} = \\varepsilon\\, l\\, c \\qquad T = \\dfrac{I}{I_0} = 10^{-A}`)}</div><div class="small">ε (${bn(lam)} nm) = ${sig(eps(lam))} L mol⁻¹ cm⁻¹ (λmax এ ${sig(s.e)}); তাত্ত্বিক A = ${bn(Aid.toFixed(3))}${Aid > 1.0 ? `, পরিমাপিত ${bn(A.toFixed(3))} — উচ্চ ঘনমাত্রায় ঋণাত্মক বিচ্যুতি` : ''}; ট্রান্সমিট্যান্স T = ১০^(−A) = ${bn((10 ** -A * 100).toFixed(1))}%।</div><div class="small">λ কে λmax থেকে সরালে ε কমে — সংবেদনশীলতা কমে এবং তরঙ্গদৈর্ঘ্যের সামান্য ভুলে বড় ত্রুটি হয়। তাই পরিমাপ সবসময় λmax এ।</div>${u}`; draw(); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    q('[data-s]').onchange = e => { si = +e.target.value; lam = S().lm; q('[data-w]').value = lam; unk = null; info(); };
    q('[data-c]').oninput = e => { cf = +e.target.value; info(); }; q('[data-l]').oninput = e => { l = +e.target.value; info(); }; q('[data-w]').oninput = e => { lam = +e.target.value; info(); };
    q('[data-lm]').onclick = () => { lam = S().lm; q('[data-w]').value = lam; info(); };
    q('[data-u]').onclick = () => { unk = S().cmax * (0.25 + Math.random() * 0.7); info(); };
    info();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.১৬ পারমাণবিক শোষণ বর্ণালি ======================= */
const AE = [
  { s: 'Pb', n: 'সিসা', lam: 283.3, col: '#495057', std: [0.5, 1, 2, 4, 6], unit: 'mg/L', k: 0.0155, note: 'ব্যাটারি কারখানা ও রং থেকে পানি-মাটিতে দূষণ; WHO সীমা ০.০১ mg/L — এত কম মাত্রায় গ্রাফাইট চুল্লি AAS লাগে।' },
  { s: 'Cu', n: 'কপার', lam: 324.8, col: '#c87533', std: [1, 2, 3, 4, 5], unit: 'mg/L', k: 0.062, note: 'খাবার পানিতে WHO নির্দেশিকা ২ mg/L।' },
  { s: 'Fe', n: 'আয়রন', lam: 248.3, col: '#a61e4d', std: [1, 2, 4, 6, 8], unit: 'mg/L', k: 0.048, note: 'নলকূপের পানিতে লোহা প্রায়ই ১–১০ mg/L; বাংলাদেশ মান ০.৩–১.০ mg/L।' },
  { s: 'Zn', n: 'জিংক', lam: 213.9, col: '#868e96', std: [0.2, 0.4, 0.6, 0.8, 1.0], unit: 'mg/L', k: 0.42, note: 'জিংক অত্যন্ত সংবেদনশীল AAS মৌল — মাটি ও খাদ্যে জিংকের ঘাটতি নির্ণয়ে।' },
  { s: 'Na', n: 'সোডিয়াম', lam: 589.0, col: '#fab005', std: [0.2, 0.4, 0.6, 0.8, 1.0], unit: 'mg/L', k: 0.55, note: 'হলুদ D-রেখা (৫৮৯ nm) — শিখা পরীক্ষার হলুদ রঙের উৎস; স্যালাইন ও খাদ্যে সোডিয়াম নির্ণয়।' },
  { s: 'As', n: 'আর্সেনিক', lam: 193.7, col: '#5f3dc4', std: [5, 10, 20, 30, 50], unit: 'µg/L', k: 0.0062, note: 'আর্সিন (AsH₃) উৎপাদন বা গ্রাফাইট চুল্লি পদ্ধতিতে ppb স্তরে — নলকূপের পানির পরীক্ষাগার নিশ্চিতকরণ।' }
];
V.p2c3_aas = {
  t: 'পারমাণবিক শোষণ বর্ণালি (AAS): ফাঁপা ক্যাথোড ল্যাম্প → শিখায় পরমাণুকরণ → একবর্ণী যন্ত্র → ডিটেক্টর; নির্দিষ্ট মৌলের নির্দিষ্ট তরঙ্গদৈর্ঘ্যের আলো শোষণ (শক্তিস্তর চিত্র), প্রমাণ রেখা ও পানির নমুনায় ভারী ধাতু নির্ণয়', k: ['anim', 'int', 'calc', 'plot'],
  cap: 'মৌল বেছে নাও — ফাঁপা ক্যাথোড ল্যাম্প ঠিক ঐ মৌলের বৈশিষ্ট্যসূচক তরঙ্গদৈর্ঘ্যের আলো দেয়। নমুনা দ্রবণ নেবুলাইজারে কুয়াশা হয়ে শিখায় যায়; শিখার তাপে দ্রাবক উবে, লবণ ভেঙে মুক্ত ভূমি-অবস্থার পরমাণু তৈরি হয়। এই পরমাণুগুলো ল্যাম্পের আলোর ফোটন শোষণ করে উত্তেজিত অবস্থায় যায় (ডানে শক্তিস্তর চিত্র: ΔE = hc/λ)। যত বেশি পরমাণু, তত বেশি শোষণ — ঘনমাত্রার সমানুপাতিক। নিচে প্রমাণ দ্রবণ দিয়ে প্রমাণ রেখা; "নমুনা মাপো" চাপলে অজানা পানির নমুনার ঘনমাত্রা নির্ণীত হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-e', AE.map((s, i) => [String(i), `${s.n} (${s.s}, ${s.lam} nm)`]), '0')}<button class="btn sm primary" data-m>💧 নমুনা মাপো</button><label class="small" style="flex:1;min-width:150px">প্রমাণ দ্রবণ <b data-sv></b><input type="range" min="0" max="5" step="1" value="2" data-st></label></div>${X.cv('AAS')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 400 : 560;
    let L = X.fit(c, hf), ei = 0, sti = 2, unk = null, t = 0;
    const E = () => AE[ei];
    const cur = () => sti === 0 ? 0 : sti <= 5 ? E().std[sti - 1] : 0;
    const absOf = cc => E().k * cc * (1 - 0.04 * E().k * cc);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const e = E(), wd = wide(W), cc = unk != null && sti < 0 ? unk : cur(), Aval = absOf(cc);
      const y = wd ? 70 : 60, x0 = 16, x1 = W - 16; const hcl = x0 + 26, fl = x0 + (x1 - x0) * (wd ? 0.38 : 0.4), mono = x0 + (x1 - x0) * 0.68, det = x1 - 20;
      // HCL lamp
      g.fillStyle = col.s2; rr(g, hcl - 24, y - 14, 48, 28, 8); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.stroke(); g.fillStyle = e.col; g.fillRect(hcl - 8, y - 7, 12, 14); g.fillStyle = 'rgba(255,240,180,.7)'; g.beginPath(); g.arc(hcl - 2, y, 5 + Math.sin(t * 8) * 1, 0, 7); g.fill(); T(g, `ফাঁপা ক্যাথোড ল্যাম্প (${e.s})`, hcl + 4, y + 30, col, { s: 8.5, c: col.mu });
      const beam = e.lam > 380 ? wl2rgb(e.lam, 0.9) : 'rgba(150,100,230,.85)';
      // flame + burner
      g.fillStyle = col.fg; g.fillRect(fl - 30, y + 18, 60, 6); g.fillRect(fl - 4, y + 24, 8, 30); const fh = 34; const grd = g.createLinearGradient(0, y + 18, 0, y + 18 - fh); grd.addColorStop(0, 'rgba(30,100,255,.85)'); grd.addColorStop(0.5, e.s === 'Na' ? 'rgba(255,200,40,.75)' : 'rgba(255,170,40,.55)'); grd.addColorStop(1, 'rgba(255,220,120,0)'); g.fillStyle = grd; g.beginPath(); g.moveTo(fl - 30, y + 18); for (let i = 0; i <= 12; i++) { const xx = fl - 30 + i * 5; g.lineTo(xx, y + 18 - fh * (0.6 + 0.4 * Math.sin(i * 0.9 + t * 9) * 0.5 + 0.4 * Math.sin(i / 12 * Math.PI))); } g.lineTo(fl + 30, y + 18); g.closePath(); g.fill(); T(g, 'শিখা (বায়ু-অ্যাসিটিলিন, ~২৩০০ °C)', fl, y + 66, col, { s: 8.5, c: col.mu });
      // nebulizer
      g.strokeStyle = col.mu; g.beginPath(); g.moveTo(fl, y + 54); g.lineTo(fl, y + 76); g.lineTo(fl - 40, y + 86); g.stroke(); g.fillStyle = 'rgba(120,170,230,.6)'; g.fillRect(fl - 52, y + 82, 14, 18); T(g, 'নমুনা → নেবুলাইজার', fl - 45, y + 112, col, { s: 8, c: col.mu });
      // atoms in flame
      const nA = Math.round(Math.min(28, cc / e.std[4] * 24)); for (let i = 0; i < nA; i++) { const a = i * 2.39, xx = fl + Math.cos(a + t) * 22 * ((i * 0.37) % 1), yy = y + 10 - ((i * 0.61 + t * 0.3) % 1) * 30; const ex = ((t * 1.3 + i * 0.29) % 1) < 0.25; g.fillStyle = ex ? '#ffd43b' : e.col; g.beginPath(); g.arc(xx, yy, 3, 0, 7); g.fill(); if (ex) { g.strokeStyle = '#ffd43b'; g.beginPath(); g.arc(xx, yy, 5.5, 0, 7); g.stroke(); } }
      // beam with attenuation
      const Tr = 10 ** -Aval; g.strokeStyle = beam; g.lineWidth = 4; g.beginPath(); g.moveTo(hcl + 24, y); g.lineTo(fl - 30, y); g.stroke(); g.globalAlpha = 0.25 + 0.75 * Tr; g.beginPath(); g.moveTo(fl + 30, y); g.lineTo(mono - 16, y); g.stroke(); g.globalAlpha = 1; g.lineWidth = 2; g.globalAlpha = 0.5 + 0.5 * Tr; g.beginPath(); g.moveTo(fl - 30, y); g.lineTo(fl + 30, y); g.stroke(); g.globalAlpha = 1;
      g.fillStyle = col.s2; rr(g, mono - 16, y - 16, 32, 32, 4); g.fill(); g.strokeStyle = col.fg; g.stroke(); T(g, 'একবর্ণী', mono, y + 30, col, { s: 8.5, c: col.mu }); g.strokeStyle = beam; g.lineWidth = 3; g.globalAlpha = 0.25 + 0.75 * Tr; g.beginPath(); g.moveTo(mono + 16, y); g.lineTo(det - 10, y); g.stroke(); g.globalAlpha = 1; g.fillStyle = col.s3 || '#999'; rr(g, det - 10, y - 16, 22, 32, 4); g.fill(); g.strokeStyle = col.fg; g.stroke(); T(g, 'ডিটেক্টর', det, y + 30, col, { s: 8.5, c: col.mu });
      T(g, `শোষণ A = ${bn(Aval.toFixed(4))}`, W / 2, 16, col, { b: true, s: 12, c: col.acc });
      // energy level
      const ex = wd ? W * 0.06 : 20, ey = wd ? 190 : 210, ew = wd ? W * 0.3 : W * 0.4, eh = wd ? H - ey - 30 : 150; g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(ex, ey + eh); g.lineTo(ex + ew, ey + eh); g.moveTo(ex, ey + 20); g.lineTo(ex + ew, ey + 20); g.stroke(); T(g, 'উত্তেজিত অবস্থা', ex + ew, ey + 14, col, { s: 9, a: 'right', c: col.mu }); T(g, 'ভূমি অবস্থা', ex + ew, ey + eh + 14, col, { s: 9, a: 'right', c: col.mu }); const u = (t * 0.7) % 1; const eY = u < 0.5 ? ey + eh : ey + eh - (eh - 20) * Math.min(1, (u - 0.5) * 4); g.fillStyle = '#ffd43b'; g.beginPath(); g.arc(ex + ew * 0.55, eY, 5, 0, 7); g.fill(); g.strokeStyle = '#e67700'; g.stroke(); const wx = ex + 6; g.strokeStyle = beam; g.lineWidth = 1.8; g.beginPath(); for (let i = 0; i <= 40; i++) { const xx = wx + i * (ew * 0.45 / 40), yy = ey + eh / 2 + Math.sin(i * 0.9 - t * 10) * 6; i ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.stroke(); T(g, `hν (${bn(e.lam)} nm)`, ex + ew * 0.22, ey + eh / 2 - 12, col, { s: 9, b: true }); T(g, `ΔE = hc/λ = ${bn((1239.84 / e.lam).toFixed(2))} eV`, ex + ew / 2, ey + eh + 28, col, { s: 9, c: col.mu });
      // calibration
      const gx = wd ? W * 0.45 : 40, gy = wd ? 190 : ey + eh + 50, gw = wd ? W * 0.52 : W - 54, gh = wd ? H - gy - 34 : H - gy - 34; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(gx, gy, gw, gh); const cM = e.std[4] * 1.2, aM = absOf(cM) * 1.1; const Xc = v => gx + v / cM * gw, Ya = a => gy + gh - a / aM * gh;
      g.beginPath(); for (let i = 0; i <= 50; i++) { const v = cM * i / 50; i ? g.lineTo(Xc(v), Ya(absOf(v))) : g.moveTo(Xc(v), Ya(0)); } g.strokeStyle = col.fg; g.lineWidth = 1.4; g.stroke(); e.std.forEach((v, i) => { g.fillStyle = i === sti - 1 ? '#e03131' : col.acc; g.beginPath(); g.arc(Xc(v), Ya(absOf(v)), i === sti - 1 ? 5 : 4, 0, 7); g.fill(); T(g, bn(v), Xc(v), gy + gh + 12, col, { s: 8.5, c: col.mu }); });
      if (unk != null) { const Au = absOf(unk); g.strokeStyle = '#2f9e44'; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(gx, Ya(Au)); g.lineTo(Xc(unk), Ya(Au)); g.lineTo(Xc(unk), gy + gh); g.stroke(); g.setLineDash([]); g.fillStyle = '#2f9e44'; g.beginPath(); g.arc(Xc(unk), Ya(Au), 5, 0, 7); g.fill(); T(g, 'নমুনা', Xc(unk) + 6, Ya(Au) - 6, col, { s: 9, b: true, c: '#2f9e44', a: 'left' }); }
      T(g, `প্রমাণ রেখা: A বনাম ${e.s} (${e.unit})`, gx + gw / 2, gy + gh + 24, col, { s: 9, c: col.mu });
    };
    const info = () => { const e = E(); q('[data-sv]').textContent = sti === 0 ? 'ব্ল্যাংক (০)' : `${bn(e.std[sti - 1])} ${e.unit}`; let u = ''; if (unk != null) { const Au = absOf(unk); u = `<div class="small"><b>পানির নমুনা:</b> A = ${bn(Au.toFixed(4))} ⇒ প্রমাণ রেখা থেকে ${e.s} = <b>${bn(unk.toFixed(e.unit === 'µg/L' ? 1 : 2))} ${e.unit}</b>। ${e.s === 'As' ? (unk > 50 ? '⚠️ বাংলাদেশ মান (৫০ µg/L) অতিক্রম।' : unk > 10 ? '⚠️ WHO সীমা (১০ µg/L) অতিক্রম।' : '✓ WHO সীমার মধ্যে।') : e.s === 'Pb' ? (unk > 0.01 ? '⚠️ WHO সীমা (০.০১ mg/L) অনেক গুণ বেশি — ভারী দূষণ।' : '') : ''}</div>`; }
      out.innerHTML = `<div class="small"><b>${e.n} (${e.s}):</b> বৈশিষ্ট্যসূচক রেখা ${bn(e.lam)} nm। ${e.note}</div><div class="small">শোষণ A = log(I₀/I) ∝ শিখার আলোকপথে মুক্ত পরমাণুর সংখ্যা ∝ নমুনার ঘনমাত্রা (বিয়ার-ল্যাম্বার্ট)। ফাঁপা ক্যাথোড ল্যাম্পের রেখা অত্যন্ত সরু এবং কেবল ঐ মৌলের পরমাণুই তা শোষণ করে — তাই অন্য মৌলের উপস্থিতিতেও নির্বাচনী পরিমাপ সম্ভব।</div>${u}`; draw(); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    q('[data-e]').onchange = e => { ei = +e.target.value; unk = null; info(); };
    q('[data-st]').oninput = e => { sti = +e.target.value; info(); };
    q('[data-m]').onclick = () => { const e = E(); unk = e.std[0] * 0.6 + Math.random() * (e.std[4] - e.std[0] * 0.6); info(); };
    info();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
