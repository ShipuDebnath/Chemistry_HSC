/* ২য় পত্র অধ্যায় ৩ visuals part 9 — 3.17 UV-Vis (transitions, conjugation, colour wheel); 3.18 HPLC; 3.19 GC — animated column bands and live chromatograms */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit;max-width:100%">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const wl2rgb = (w, a = 1) => { let r = 0, g = 0, b = 0; if (w < 380) { r = 0.45; b = 0.6; } else if (w < 440) { r = -(w - 440) / 60; b = 1; } else if (w < 490) { g = (w - 440) / 50; b = 1; } else if (w < 510) { g = 1; b = -(w - 510) / 20; } else if (w < 580) { r = (w - 510) / 70; g = 1; } else if (w < 645) { r = 1; g = -(w - 645) / 65; } else if (w <= 780) { r = 1; } else { r = 0.5; } return `rgba(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)},${a})`; };
const gauss = (x, m, s) => Math.exp(-0.5 * ((x - m) / s) ** 2);

/* ======================= ৩.১৭ UV-Vis ======================= */
// [name, peaks [[λ, logε, width]], transition, observed colour, note]
const UV = [
  { n: 'ইথিন (C₂H₄)', pk: [[171, 4.2, 10]], tr: 'π → π*', obs: 'বর্ণহীন', conj: 1, note: 'একটি C=C — শোষণ সুদূর-UV তে (১৭১ nm)।' },
  { n: '১,৩-বিউটাডাইন', pk: [[217, 4.3, 12]], tr: 'π → π*', obs: 'বর্ণহীন', conj: 2, note: 'দুটি সংযুক্ত দ্বিবন্ধন — λmax ২১৭ nm (বেথোক্রোমিক সরণ)।' },
  { n: '১,৩,৫-হেক্সাট্রাইন', pk: [[258, 4.6, 14]], tr: 'π → π*', obs: 'বর্ণহীন', conj: 3, note: 'তিনটি সংযুক্ত দ্বিবন্ধন — λmax ২৫৮ nm।' },
  { n: 'বেনজিন', pk: [[184, 4.8, 8], [204, 3.9, 8], [255, 2.3, 10]], tr: 'π → π* (তিনটি পট্টি)', obs: 'বর্ণহীন', conj: 3, note: '২৫৫ nm এ দুর্বল সূক্ষ্ম-গঠনযুক্ত পট্টি (B-পট্টি) — অ্যারোমেটিক যৌগ শনাক্তকরণে।' },
  { n: 'অ্যাসিটোন (C=O)', pk: [[188, 3.0, 10], [279, 1.2, 18]], tr: 'n → π* (দুর্বল), π → π*', obs: 'বর্ণহীন', conj: 1, note: '২৭৯ nm এ দুর্বল n → π* (ε ≈ ১৫) — অবন্ধনী ইলেকট্রনের উত্তেজনা।' },
  { n: 'β-ক্যারোটিন (গাজর)', pk: [[425, 4.9, 16], [451, 5.1, 16], [478, 5.0, 16]], tr: 'π → π* (১১টি সংযুক্ত C=C)', obs: 'কমলা', conj: 11, note: '১১টি সংযুক্ত দ্বিবন্ধন — শোষণ দৃশ্যমান নীল-সবুজে (৪৫১ nm), তাই কমলা দেখায়।' },
  { n: 'ক্লোরোফিল-a', pk: [[430, 5.0, 18], [662, 4.9, 14]], tr: 'π → π* (পরফাইরিন)', obs: 'সবুজ', conj: 9, note: 'নীল (৪৩০) ও লাল (৬৬২) শোষণ — সবুজ প্রতিফলিত/সঞ্চালিত হয়।' },
  { n: 'KMnO₄', pk: [[526, 3.4, 22], [311, 3.0, 20]], tr: 'আধান স্থানান্তর (O → Mn)', obs: 'বেগুনি', conj: 0, note: 'সবুজ-হলুদ (৫২৬ nm) শোষণ করে — পরিপূরক বেগুনি দেখায়।' },
  { n: '[Cu(H₂O)₆]²⁺', pk: [[800, 1.1, 120]], tr: 'd → d', obs: 'হালকা নীল', conj: 0, note: 'দুর্বল d-d স্থানান্তর লাল-কমলা অঞ্চলে — তাই নীল।' }
];
const WHEEL = [[400, 'বেগুনি'], [435, 'নীল'], [490, 'সবুজাভ নীল'], [530, 'সবুজ'], [570, 'হলুদ-সবুজ'], [590, 'হলুদ'], [620, 'কমলা'], [700, 'লাল']];
V.p2c3_uvvis = {
  t: 'UV-দৃশ্যমান বর্ণালি: শোষণ বর্ণালি ও λmax, ইলেকট্রন স্থানান্তর (σ→σ*, π→π*, n→π*, d-d), সংযুক্ত দ্বিবন্ধন বাড়লে বেথোক্রোমিক সরণ, এবং বর্ণচক্রে শোষিত ও দৃশ্যমান (পরিপূরক) রং', k: ['int', 'plot'],
  cap: 'যৌগ বেছে নাও। বামে শোষণ বর্ণালি (log ε বনাম λ, ১৫০–৮৫০ nm; ৪০০ nm এর নিচে UV, উপরে দৃশ্যমান রংধনু পট্টি)। ডানে বর্ণচক্র: শোষিত রং (λmax) থেকে ঠিক বিপরীত দিকের পরিপূরক রংটি আমরা দেখি। মাঝে আণবিক কক্ষকের শক্তিস্তর চিত্র: সংযুক্ত দ্বিবন্ধন বাড়লে HOMO–LUMO ব্যবধান কমে, তাই শোষণ দীর্ঘ তরঙ্গদৈর্ঘ্যে সরে যায় — ইথিন থেকে β-ক্যারোটিন পর্যন্ত ক্রমে দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-u', UV.map((s, i) => [String(i), s.n]), '5')}</div>${X.cv('UV-Vis')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : 600;
    let L = X.fit(c, hf), ui = 5;
    const spec = (u, l) => u.pk.reduce((a, [m, le, w]) => Math.max(a, le * gauss(l, m, w) ), 0);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const u = UV[ui], wd = wide(W);
      // spectrum
      const gx = 36, gy = 14, gw = wd ? W * 0.5 : W - 50, gh = wd ? H - 50 : 200; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(gx, gy, gw, gh); const Xl = l => gx + (l - 150) / 700 * gw, Yl = v => gy + gh - v / 5.5 * (gh - 10);
      g.fillStyle = 'rgba(120,80,200,.08)'; g.fillRect(gx, gy, Xl(400) - gx, gh); T(g, 'UV', (gx + Xl(400)) / 2, gy + 14, col, { s: 10, b: true, c: col.mu }); for (let l = 400; l < 780; l += 2) { g.fillStyle = wl2rgb(l, 0.22); g.fillRect(Xl(l), gy + gh - 8, gw / 350 + 1, 8); } T(g, 'দৃশ্যমান', (Xl(400) + Xl(780)) / 2, gy + 14, col, { s: 10, b: true, c: col.mu });
      g.beginPath(); for (let l = 150; l <= 850; l += 1) { const xx = Xl(l), yy = Yl(spec(u, l)); l === 150 ? g.moveTo(xx, yy) : g.lineTo(xx, yy); } g.strokeStyle = col.acc; g.lineWidth = 2; g.stroke(); const main = u.pk.reduce((a, b) => b[1] > a[1] ? b : a); T(g, `λmax ${bn(main[0])} nm`, Xl(main[0]), Yl(main[1]) - 6, col, { s: 9.5, b: true, c: col.acc }); [200, 400, 600, 800].forEach(v => T(g, bn(v), Xl(v), gy + gh + 12, col, { s: 8.5, c: col.mu })); [1, 2, 3, 4, 5].forEach(v => T(g, bn(v), gx - 6, Yl(v) + 3, col, { s: 8.5, c: col.mu, a: 'right' })); T(g, 'log ε', gx - 6, gy + 8, col, { s: 8.5, c: col.mu, a: 'right' }); T(g, 'λ (nm)', gx + gw / 2, gy + gh + 24, col, { s: 9, c: col.mu });
      // MO diagram
      const mx = wd ? W * 0.58 : 30, my = wd ? 20 : gy + gh + 44, mw = wd ? W * 0.16 : W * 0.4, mh = wd ? H - 60 : 200; const n = Math.max(1, u.conj), gap = u.conj ? Math.max(0.12, 1 / (1 + 0.55 * (n - 1))) : 0.5; T(g, 'শক্তি', mx, my + 6, col, { s: 9, c: col.mu, a: 'left' }); const yH = my + mh * 0.55 + mh * 0.2 * gap, yL = my + mh * 0.55 - mh * 0.45 * gap; g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(mx + 10, yH); g.lineTo(mx + mw - 10, yH); g.moveTo(mx + 10, yL); g.lineTo(mx + mw - 10, yL); g.stroke(); T(g, u.tr.startsWith('d') ? 'd (নিম্ন)' : 'HOMO (π / n)', mx + mw / 2, yH + 14, col, { s: 9, c: col.mu }); T(g, u.tr.startsWith('d') ? 'd (উচ্চ)' : 'LUMO (π*)', mx + mw / 2, yL - 6, col, { s: 9, c: col.mu }); g.fillStyle = col.fg; T(g, '↑↓', mx + mw / 2, yH - 3, col, { s: 11, b: true }); const lam = main[0]; g.strokeStyle = lam > 380 && lam < 780 ? wl2rgb(lam, 1) : '#7048e8'; g.lineWidth = 2; g.beginPath(); g.moveTo(mx + mw * 0.75, yH); g.lineTo(mx + mw * 0.75, yL + 6); g.stroke(); g.beginPath(); g.moveTo(mx + mw * 0.75, yL); g.lineTo(mx + mw * 0.75 - 4, yL + 8); g.lineTo(mx + mw * 0.75 + 4, yL + 8); g.closePath(); g.fillStyle = g.strokeStyle; g.fill(); T(g, `ΔE = ${bn((1239.84 / lam).toFixed(2))} eV`, mx + mw / 2, my + mh - 4, col, { s: 9, b: true }); if (u.conj) T(g, `সংযুক্ত C=C: ${bn(u.conj)}`, mx + mw / 2, my + mh - 18, col, { s: 9, c: col.mu });
      // colour wheel
      const cx = wd ? W * 0.86 : W * 0.72, cy = wd ? H * 0.45 : my + mh / 2, R = wd ? Math.min(66, H * 0.22) : Math.min(70, W * 0.2); for (let i = 0; i < 360; i++) { const lw = 400 + (i / 360) * 300; g.fillStyle = wl2rgb(lw, 0.9); g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, R, (i - 90) * Math.PI / 180, (i - 88) * Math.PI / 180); g.closePath(); g.fill(); } g.fillStyle = col.sf; g.beginPath(); g.arc(cx, cy, R * 0.45, 0, 7); g.fill();
      const ang = l => ((l - 400) / 300 * 360 - 90) * Math.PI / 180; const visPk = u.pk.filter(p => p[0] >= 400 && p[0] <= 700).sort((a, b) => b[1] - a[1])[0];
      if (visPk) { const a = ang(visPk[0]); g.strokeStyle = col.fg; g.lineWidth = 2.5; g.beginPath(); g.moveTo(cx + Math.cos(a) * R * 0.5, cy + Math.sin(a) * R * 0.5); g.lineTo(cx + Math.cos(a) * R * 1.08, cy + Math.sin(a) * R * 1.08); g.stroke(); T(g, 'শোষিত', cx + Math.cos(a) * R * 1.28, cy + Math.sin(a) * R * 1.28 + 3, col, { s: 9, b: true }); const b = a + Math.PI; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(cx + Math.cos(b) * R * 0.5, cy + Math.sin(b) * R * 0.5); g.lineTo(cx + Math.cos(b) * R * 1.08, cy + Math.sin(b) * R * 1.08); g.stroke(); g.setLineDash([]); T(g, 'দৃশ্যমান', cx + Math.cos(b) * R * 1.3, cy + Math.sin(b) * R * 1.3 + 3, col, { s: 9, b: true }); }
      T(g, u.obs, cx, cy + 4, col, { s: 11, b: true }); T(g, 'বর্ণচক্র', cx, cy + R + 22, col, { s: 9, c: col.mu });
    };
    const info = () => { const u = UV[ui], main = u.pk.reduce((a, b) => b[1] > a[1] ? b : a); out.innerHTML = `<div class="small"><b>${u.n}:</b> স্থানান্তর ${u.tr}; λmax = ${bn(main[0])} nm, ε ≈ ${bn(Math.round(10 ** main[1]).toLocaleString('en-US'))} L mol⁻¹ cm⁻¹; দেখায় ${u.obs}। ${u.note}</div><div>${TXB(`\\Delta E = h\\nu = \\dfrac{hc}{\\lambda}`)}</div>`; draw(); };
    q('[data-u]').onchange = e => { ui = +e.target.value; info(); };
    info();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ক্রোমাটোগ্রাফি ইঞ্জিন ======================= */
const chromMount = (el, cfg) => {
  const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
  const hf = w => wide(w) ? 380 : 520;
  let L = X.fit(c, hf), t = 0, run = false, tm = 0, si = 0;
  const comps = () => cfg.comps(si, q);
  const draw = () => {
    const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), C = comps(), tmax = Math.max(...C.map(k => k.tR)) * 1.18 + 0.5;
    // instrument row
    const y = wd ? 54 : 50, x0 = 14, x1 = W - 14; const parts = cfg.parts; const pw = (x1 - x0) / parts.length; const bw = Math.min(52, pw - 6), hb = bw / 2;
    parts.forEach((p, i) => { const px = x0 + pw * i + pw / 2; if (p[1] !== 'col') { g.fillStyle = col.s2; rr(g, px - hb, y - 16, bw, 32, 6); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1; g.stroke(); T(g, wd ? p[0] : (p[2] || p[0]), px, y + 3, col, { s: wd ? 9 : 8, b: true }); } });
    // column (spans the col part, coiled for GC look not needed)
    const ci = parts.findIndex(p => p[1] === 'col'), cx0 = x0 + pw * ci + 4, cx1 = x0 + pw * (ci + 1) - 4; if (cfg.oven) { g.fillStyle = `rgba(255,${Math.round(200 - (cfg.ovenT(q) - 40) * 0.8)},120,.25)`; rr(g, cx0 - 2, y - 24, cx1 - cx0 + 4, 48, 6); g.fill(); T(g, `চুল্লি ${bn(cfg.ovenT(q))} °C`, (cx0 + cx1) / 2, y - 28, col, { s: 8.5, c: '#e8590c', b: true }); }
    g.fillStyle = cfg.colFill; g.fillRect(cx0, y - 8, cx1 - cx0, 16); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(cx0, y - 8, cx1 - cx0, 16); T(g, wd ? cfg.colLabel : cfg.colLabel.split(' (')[0], (cx0 + cx1) / 2, y + 26, col, { s: 8.5, c: col.mu });
    for (let i = 0; i < parts.length - 1; i++) { const a = x0 + pw * i + pw / 2 + (parts[i][1] === 'col' ? 0 : hb), b = x0 + pw * (i + 1) + pw / 2 - (parts[i + 1][1] === 'col' ? 0 : hb); if (parts[i][1] === 'col' || parts[i + 1][1] === 'col') continue; g.strokeStyle = col.mu; g.lineWidth = 2; g.beginPath(); g.moveTo(a, y); g.lineTo(b, y); g.stroke(); }
    // connect to column
    g.strokeStyle = col.mu; g.lineWidth = 2; g.beginPath(); g.moveTo(x0 + pw * (ci - 1) + pw / 2 + hb, y); g.lineTo(cx0, y); g.moveTo(cx1, y); g.lineTo(x0 + pw * (ci + 1) + pw / 2 - hb, y); g.stroke();
    // bands
    if (tm > 0) C.forEach(k => { const f = tm / k.tR; if (f > 1.05) return; const bx = cx0 + (cx1 - cx0) * Math.min(1, f), sw = 4 + 22 * Math.sqrt(Math.min(1, f)) * (k.tR / tmax) * 0.6; const gr = g.createLinearGradient(bx - sw, 0, bx + sw, 0); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.5, k.c); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.globalAlpha = 0.85; g.fillRect(bx - sw, y - 7, 2 * sw, 14); g.globalAlpha = 1; });
    // chromatogram
    const gx = 36, gy = wd ? 110 : 100, gw = W - 52, gh = H - gy - 36; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(gx, gy, gw, gh); const Xt = v => gx + v / tmax * gw; let ymax = 0; const sigOf = k => k.tR / Math.sqrt(cfg.N) + 0.01; C.forEach(k => { ymax = Math.max(ymax, k.amt / sigOf(k)); }); const Ys = v => gy + gh - v / (ymax * 1.15) * (gh - 6);
    const upto = run || tm > 0 ? Math.min(tm, tmax) : tmax; g.beginPath(); for (let i = 0; i <= 600; i++) { const tt = tmax * i / 600; if (tt > upto) break; let s = 0; C.forEach(k => { s += k.amt / sigOf(k) * Math.exp(-0.5 * ((tt - k.tR) / sigOf(k)) ** 2); }); const xx = Xt(tt), yy = Ys(s); i ? g.lineTo(xx, yy) : g.moveTo(xx, yy); } g.strokeStyle = col.fg; g.lineWidth = 1.6; g.stroke();
    C.forEach(k => { if (k.tR > upto) return; const xx = Xt(k.tR), yy = Ys(k.amt / sigOf(k)); T(g, k.n, xx, Math.max(gy + 10, yy - 16), col, { s: 9, b: true, c: k.c }); T(g, `${bn(k.tR.toFixed(2))} মিনিট`, xx, Math.max(gy + 21, yy - 5), col, { s: 8, c: col.mu }); });
    for (let v = 0; v <= tmax; v += tmax > 15 ? 5 : tmax > 6 ? 2 : 1) T(g, bn(v), Xt(v), gy + gh + 12, col, { s: 8.5, c: col.mu }); T(g, 'সংরক্ষণ সময় tR (মিনিট) →   ক্রোমাটোগ্রাম (ডিটেক্টর সংকেত)', gx + gw / 2, gy + gh + 25, col, { s: 9, c: col.mu });
    if (run || tm > 0) { g.strokeStyle = '#e03131'; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(Xt(upto), gy); g.lineTo(Xt(upto), gy + gh); g.stroke(); g.setLineDash([]); }
  };
  const info = () => { const C = comps(); const s = [...C].sort((a, b) => a.tR - b.tR); let rs = ''; for (let i = 1; i < s.length; i++) { const a = s[i - 1], b = s[i], wa = 4 * a.tR / Math.sqrt(cfg.N), wb = 4 * b.tR / Math.sqrt(cfg.N), R = 2 * (b.tR - a.tR) / (wa + wb); rs += `${a.n}–${b.n}: R = ${bn(R.toFixed(2))}${R < 1.5 ? ' ⚠️ অসম্পূর্ণ পৃথকীকরণ' : ''}; `; } out.innerHTML = `${cfg.info(si, q, C)}<div class="small"><b>পৃথকীকরণ (রেজোলিউশন, R ≥ ১.৫ হলে সম্পূর্ণ):</b> ${rs}</div><div class="small"><b>শিখরের ক্ষেত্রফল</b> ∝ উপাদানের পরিমাণ: ${C.map(k => `${k.n} ${bn((k.amt * k.rf).toFixed(1))}`).join(', ')} (আপেক্ষিক)।</div>`; draw(); };
  const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { const C = comps(), tmax = Math.max(...C.map(k => k.tR)) * 1.18 + 0.5; tm += dt * tmax / 7; if (tm >= tmax) { tm = tmax; run = false; } } } draw(); }, { paused: false });
  q('[data-go]').onclick = () => { tm = 0; run = true; };
  q('[data-s]').onchange = e => { si = +e.target.value; tm = 0; run = false; info(); };
  el.querySelectorAll('input[type=range]').forEach(r => r.oninput = () => { cfg.label(q); tm = 0; run = false; info(); });
  cfg.label(q); info();
  const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
  return () => { A.stop(); un(); };
};

/* ======================= ৩.১৮ HPLC ======================= */
const HPS = [
  { n: 'ব্যথানাশক ট্যাবলেট (প্যারাসিটামল + ক্যাফেইন + অ্যাসপিরিন)', c: [['প্যারাসিটামল', 1.0, 3.0, 5, '#1c7ed6', 1], ['ক্যাফেইন', 1.6, 3.5, 1, '#e8590c', 1.3], ['অ্যাসপিরিন', 2.2, 3.8, 4, '#2f9e44', 0.8]] },
  { n: 'কোমল পানীয় (ক্যাফেইন + বেনজোয়িক এসিড + সোডিয়াম স্যাকারিন)', c: [['স্যাকারিন', 0.7, 2.6, 2, '#ae3ec9', 1.1], ['ক্যাফেইন', 1.6, 3.5, 1.5, '#e8590c', 1.3], ['বেনজোয়িক এসিড', 2.6, 4.0, 2, '#1098ad', 1]] },
  { n: 'প্রমাণ মিশ্রণ (চারটি উপাদান সমান)', c: [['প্যারাসিটামল', 1.0, 3.0, 2, '#1c7ed6', 1], ['ক্যাফেইন', 1.6, 3.5, 2, '#e8590c', 1.3], ['অ্যাসপিরিন', 2.2, 3.8, 2, '#2f9e44', 0.8], ['বেনজোয়িক এসিড', 2.6, 4.0, 2, '#1098ad', 1]] }
];
V.p2c3_hplc = {
  t: 'উচ্চ দক্ষতা সম্পন্ন তরল ক্রোমাটোগ্রাফি (HPLC): দ্রাবক আধার → উচ্চচাপ পাম্প → ইনজেক্টর → C18 কলাম → UV ডিটেক্টর; কলামে উপাদানের পট্টির অগ্রগতি, সরাসরি ক্রোমাটোগ্রাম, মোবাইল দশার মিথানল % ও প্রবাহ হারের প্রভাব, রেজোলিউশন', k: ['anim', 'int', 'plot'],
  cap: 'নমুনা বেছে "▶ ইনজেক্ট" চাপো। রিভার্স-ফেজ C18 কলামে (অধ্রুবীয় স্থির দশা) মোবাইল দশা (পানি-মিথানল) উপাদানগুলোকে বয়ে নেয়; যে উপাদান বেশি অধ্রুবীয় সে স্থির দশায় বেশি সময় আটকে থাকে — দেরিতে বের হয় (বেশি সংরক্ষণ সময়)। কলামে রঙিন পট্টিগুলো আলাদা গতিতে এগোয় এবং চওড়া হতে থাকে; ডিটেক্টরে পৌঁছালে নিচের ক্রোমাটোগ্রামে শিখর আঁকা হয়। মিথানল % বাড়ালে মোবাইল দশা কম ধ্রুবীয় হয় — সব শিখর দ্রুত আসে কিন্তু কাছাকাছি চলে আসে (রেজোলিউশন কমে)। প্রবাহ হার বাড়ালে সব সময় সমানুপাতিক হারে কমে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-s', HPS.map((s, i) => [String(i), s.n]), '0')}<button class="btn sm primary" data-go>▶ ইনজেক্ট</button></div>${X.cv('HPLC')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:150px">মিথানল = <b data-pv></b>%<input type="range" min="20" max="70" step="1" value="40" data-p></label><label class="small" style="flex:1;min-width:150px">প্রবাহ হার = <b data-fv></b> mL/মিনিট<input type="range" min="0.5" max="2" step="0.1" value="1" data-f></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    return chromMount(el, {
      N: 6000, colFill: 'rgba(200,200,210,.5)', colLabel: 'C18 কলাম (২৫০ × ৪.৬ mm, ৫ µm কণা)',
      parts: [['দ্রাবক', 'b'], ['পাম্প', 'b'], ['ইনজেক্টর', 'b', 'ইনজেক্ট'], ['কলাম', 'col'], ['UV ডিটেক্টর', 'b', 'UV']],
      comps: (si, q) => { const phi = +q('[data-p]').value / 100, F = +q('[data-f]').value, t0 = 2.5 / F; return HPS[si].c.map(([n, lkw, S, amt, c, rf]) => ({ n, tR: t0 * (1 + 10 ** (lkw - S * phi)), amt, c, rf })); },
      label: q => { q('[data-pv]').textContent = bn(q('[data-p]').value); q('[data-fv]').textContent = bn(q('[data-f]').value); },
      info: (si, q, C) => `<div class="small"><b>মৃত সময়</b> t₀ = ${bn((2.5 / +q('[data-f]').value).toFixed(2))} মিনিট (অধারিত উপাদান); ধারণ গুণক k = (tR − t₀)/t₀। মোবাইল দশা: পানি:মিথানল = ${bn(100 - +q('[data-p]').value)}:${bn(q('[data-p]').value)}; চাপ প্রায় ${bn(Math.round(60 + 90 * +q('[data-f]').value))} bar। সনাক্তকরণ ২৫৪ nm এ UV শোষণে।</div>`
    });
  }
};

/* ======================= ৩.১৯ GC ======================= */
// [name, bp °C, colour, FID relative response (≈ C atoms effective)]
const GCC = { 'অ্যাসিটোন': [56, '#868e96', 0.75], 'মিথানল': [64.7, '#e03131', 0.45], 'ইথানল': [78.4, '#1c7ed6', 0.7], 'আইসোপ্রোপানল': [82.5, '#2f9e44', 0.8], 'প্রোপান-১-অল': [97.2, '#ae3ec9', 0.85], 'বিউটান-১-অল': [117.7, '#e8590c', 0.9] };
const GCS = [
  { n: 'হ্যান্ড স্যানিটাইজার (খাঁটি)', m: [['ইথানল', 70], ['আইসোপ্রোপানল', 5], ['প্রোপান-১-অল', 5]] },
  { n: 'ভেজাল স্যানিটাইজার (মিথানল মিশ্রিত)', m: [['মিথানল', 12], ['ইথানল', 55], ['প্রোপান-১-অল', 5]] },
  { n: 'প্রমাণ মিশ্রণ (ছয়টি উপাদান সমান)', m: [['অ্যাসিটোন', 10], ['মিথানল', 10], ['ইথানল', 10], ['আইসোপ্রোপানল', 10], ['প্রোপান-১-অল', 10], ['বিউটান-১-অল', 10]] }
];
V.p2c3_gc = {
  t: 'গ্যাস ক্রোমাটোগ্রাফি (GC): বাহক গ্যাস → উত্তপ্ত ইনজেক্টর → চুল্লির ভেতরে কৈশিক কলাম → FID ডিটেক্টর; স্ফুটনাঙ্ক অনুযায়ী সংরক্ষণ সময়, চুল্লির তাপমাত্রার প্রভাব, অভ্যন্তরীণ প্রমাণ দিয়ে পরিমাণ নির্ণয় এবং স্যানিটাইজারে মিথানল ভেজাল শনাক্তকরণ', k: ['anim', 'int', 'plot'],
  cap: 'নমুনা বেছে "▶ ইনজেক্ট" চাপো। উত্তপ্ত ইনজেক্টরে নমুনা বাষ্পীভূত হয়ে নিষ্ক্রিয় বাহক গ্যাসের (He/N₂) সাথে কলামে যায়। যে উপাদানের স্ফুটনাঙ্ক কম (উদ্বায়িতা বেশি) সে বেশি সময় গ্যাসীয় দশায় থাকে — আগে বের হয়। চুল্লির তাপমাত্রা বাড়ালে সব উপাদান দ্রুত বের হয় কিন্তু শিখরগুলো কাছাকাছি চলে আসে। শিখা আয়নীকরণ ডিটেক্টর (FID) জৈব যৌগে সাড়া দেয় (পানিতে দেয় না)। প্রোপান-১-অল এখানে অভ্যন্তরীণ প্রমাণ (internal standard) — শিখরের ক্ষেত্রফলের অনুপাত থেকে পরিমাণ নির্ণয় হয়। দ্বিতীয় নমুনায় বিষাক্ত মিথানলের শিখর খোঁজো!',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-s', GCS.map((s, i) => [String(i), s.n]), '0')}<button class="btn sm primary" data-go>▶ ইনজেক্ট</button></div>${X.cv('GC')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:150px">চুল্লির তাপমাত্রা = <b data-tv></b> °C<input type="range" min="35" max="120" step="1" value="50" data-t></label><label class="small" style="flex:1;min-width:150px">বাহক গ্যাস প্রবাহ = <b data-fv></b> mL/মিনিট<input type="range" min="0.5" max="3" step="0.1" value="1.2" data-f></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    return chromMount(el, {
      N: 40000, oven: true, ovenT: q => +q('[data-t]').value, colFill: 'rgba(230,200,150,.45)', colLabel: 'কৈশিক কলাম (৩০ m × ০.২৫ mm, ধ্রুবীয় স্থির দশা)',
      parts: [['বাহক গ্যাস (He)', 'b', 'He'], ['ইনজেক্টর ২৫০ °C', 'b', 'ইনজেক্টর'], ['কলাম', 'col'], ['FID', 'b']],
      comps: (si, q) => { const To = +q('[data-t]').value, F = +q('[data-f]').value, t0 = 1.6 / F; return GCS[si].m.map(([n, amt]) => { const [bp, c, rf] = GCC[n]; const k = 0.9 * Math.exp((bp - To) / 22 + 0.4); return { n, tR: t0 * (1 + k), amt: amt * rf, c, rf: 1 / rf }; }); },
      label: q => { q('[data-tv]').textContent = bn(q('[data-t]').value); q('[data-fv]').textContent = bn(q('[data-f]').value); },
      info: (si, q, C) => { const s = GCS[si]; const is = C.find(k => k.n === 'প্রোপান-১-অল'); const me = C.find(k => k.n === 'মিথানল'); let r = ''; if (is) { r = C.filter(k => k !== is).map(k => { const ratio = k.amt / is.amt; const rf = GCC[k.n][2] / GCC['প্রোপান-১-অল'][2]; const pct = ratio / rf * 5; return `${k.n} ≈ ${bn(pct.toFixed(1))}%`; }).join(', '); r = `<div class="small"><b>অভ্যন্তরীণ প্রমাণ (৫% প্রোপান-১-অল) পদ্ধতিতে:</b> ${r} (v/v)।</div>`; } return `<div class="small">স্ফুটনাঙ্ক: ${C.map(k => `${k.n} ${bn(GCC[k.n][0])} °C`).join(', ')} — ক্রোমাটোগ্রামে বের হওয়ার ক্রম প্রায় এই ক্রমেই।</div>${r}${me ? `<div class="small"><b>⚠️ মিথানল শনাক্ত!</b> মিথানল ত্বক ও শ্বাসের মাধ্যমে শোষিত হয়ে অন্ধত্ব ও মৃত্যু ঘটাতে পারে; FDA/WHO নির্দেশনায় স্যানিটাইজারে মিথানল নিষিদ্ধ। GC এর সংরক্ষণ সময় মিলিয়ে এটি নিশ্চিত করা হয়।</div>` : ''}`; }
    });
  }
};
})();
