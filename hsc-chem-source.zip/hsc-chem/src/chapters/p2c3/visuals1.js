/* ২য় পত্র অধ্যায় ৩ visuals part 1 — 3.1 mole hub & molar volume, equation balancer, ionic equations, Gay-Lussac volume ratios; 3.2–3.4 stoichiometry, limiting reagent, gas volume at any T/P, gas collection over water */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V, M3 = window.M3;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const sig = (v, d = 3) => { if (!isFinite(v)) return '—'; if (v === 0) return '০'; const a = Math.abs(v); if (a >= 1e5 || a < 1e-3) { const e = Math.floor(Math.log10(a)), m = v / 10 ** e; const sup = String(e).split('').map(ch => '⁻⁰¹²³⁴⁵⁶⁷⁸⁹'['-0123456789'.indexOf(ch)]).join(''); return `${bn(m.toFixed(d - 1))} × ১০${sup}`; } return bn((+v.toPrecision(d)).toString()); };
const NA = 6.022e23, VM = 22.4, R = 0.0821;
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;

/* ======================= ৩.১ মোল হাব ======================= */
const SUB = { H2: ['H₂', 2.016, 1, '#ecf0f1'], O2: ['O₂', 32.00, 1, '#e74c3c'], N2: ['N₂', 28.02, 1, '#3498db'], CO2: ['CO₂', 44.01, 1, '#7f8c8d'], NH3: ['NH₃', 17.03, 1, '#2980b9'], CH4: ['CH₄', 16.04, 1, '#555'], H2O: ['H₂O', 18.02, 0, '#5dade2'], NaCl: ['NaCl', 58.44, 0, '#bdc3c7'], CaCO3: ['CaCO₃', 100.09, 0, '#f5f5f5'], C6H12O6: ['C₆H₁₂O₆', 180.16, 0, '#f0e68c'] };
V.p2c3_moleHub = {
  t: 'মোল হাব: ভর ↔ মোল ↔ কণার সংখ্যা ↔ গ্যাসের আয়তন (STP তে ২২.৪ L) — যেকোনো একটি দিলে বাকিগুলো, অ্যাভোগেড্রো সংখ্যার দৃশ্যায়ন ও মোলার আয়তনের ঘনক', k: ['int', 'calc', '2d'],
  cap: 'পদার্থ বেছে নাও, তারপর চারটি ঘরের যেকোনো একটিতে মান লেখো — বাকি তিনটি সঙ্গে সঙ্গে হিসাব হয় এবং মাঝের "মোল" কেন্দ্রের সাথে তীরগুলো উজ্জ্বল হয়: ভর ÷ M = মোল; মোল × N_A = কণা; মোল × ২২.৪ L = গ্যাসের আয়তন (STP)। ডানে মোলার আয়তনের ঘনক (প্রতি বাহু ২৮.২ cm — একটি ফুটবলের চেয়ে বড় বাক্স) — যেকোনো গ্যাসের ১ mol STP তে এতটুকু জায়গা নেয়, অথচ ১ mol পানি (তরল) মাত্র ১৮ mL। কঠিন ও তরলের ক্ষেত্রে আয়তনের ঘর নিষ্ক্রিয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-s', Object.entries(SUB).map(([k, v]) => [k, `${v[0]} (M = ${v[1]})`]), 'CO2')}</div><div class="ctl" style="flex-wrap:wrap;gap:6px">${[['m', 'ভর (g)'], ['n', 'মোল (mol)'], ['N', 'অণুর সংখ্যা'], ['v', 'আয়তন, STP (L)']].map(([k, l]) => `<label class="small" style="flex:1;min-width:130px">${l}<input data-f="${k}" type="text" inputmode="decimal" style="width:100%;padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit"></label>`).join('')}</div>${X.cv('মোল হাব')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 260 : 420;
    let L = X.fit(c, hf), sk = 'CO2', n = 1, last = 'n', t = 0;
    const parse = s => { const v = parseFloat(String(s).replace(/[০-৯]/g, d => '০১২৩৪৫৬৭৮৯'.indexOf(d)).replace(/×\s*10\^?/, 'e').replace(',', '.')); return isFinite(v) ? v : NaN; };
    const fill = () => { const S = SUB[sk], vals = { m: n * S[1], n, N: n * NA, v: S[2] ? n * VM : NaN }; el.querySelectorAll('[data-f]').forEach(inp => { const k = inp.dataset.f; inp.disabled = k === 'v' && !S[2]; if (k !== last || document.activeElement !== inp) inp.value = isFinite(vals[k]) ? (k === 'N' ? vals[k].toExponential(3) : (+vals[k].toPrecision(4)).toString()) : '—'; }); info(); };
    el.querySelectorAll('[data-f]').forEach(inp => inp.addEventListener('input', () => { const v = parse(inp.value); if (!(v >= 0)) return; const S = SUB[sk], k = inp.dataset.f; last = k; n = k === 'm' ? v / S[1] : k === 'n' ? v : k === 'N' ? v / NA : v / VM; fill(); }));
    q('[data-s]').onchange = e => { sk = e.target.value; fill(); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), S = SUB[sk];
      const cx = wd ? W * 0.32 : W / 2, cy = wd ? H / 2 : 120, Rr = wd ? 90 : 80; const nodes = [['ভর', `${sig(n * S[1])} g`, -Math.PI / 2, 'm', `÷ M (${bn(S[1])})`], ['কণা', `${sig(n * NA)}`, 0, 'N', '× N_A'], ['আয়তন', S[2] ? `${sig(n * VM)} L` : 'প্রযোজ্য নয়', Math.PI / 2, 'v', '× ২২.৪ L'], ['ভর → মোল → …', '', Math.PI, '', '']];
      nodes.slice(0, 3).forEach(([nm, val, a, k, op]) => { const x = cx + Rr * 1.5 * Math.cos(a) * (wd ? 1 : 0.95), y = cy + Rr * Math.sin(a); const on = k === last; g.strokeStyle = on ? col.acc : col.mu; g.lineWidth = on ? 2.5 : 1.3; g.beginPath(); g.moveTo(cx, cy); g.lineTo(x, y); g.stroke(); T(g, op, (cx + x) / 2 + (a === 0 ? 0 : 34), (cy + y) / 2 - 4, col, { s: 9, c: col.acc }); g.fillStyle = col.sf; g.strokeStyle = on ? col.acc : col.mu; rr(g, x - 52, y - 18, 104, 36, 9); g.fill(); g.stroke(); T(g, nm, x, y - 3, col, { s: 9.5, c: col.mu }); T(g, val, x, y + 11, col, { b: true, s: 10.5 }); });
      M3.sphere(g, cx, cy, 30, '#2d6fd6', '#a9c8ff'); T(g, `${sig(n)}`, cx, cy + 2, col, { b: true, s: 12, c: '#fff' }); T(g, 'mol', cx, cy + 15, col, { s: 9, c: '#fff' });
      // molar volume cube
      if (wd || true) { const bx = wd ? W * 0.72 : W / 2, by = wd ? H / 2 : 320, s = wd ? 70 : 56, d = s * 0.45; g.strokeStyle = col.fg; g.lineWidth = 1.4; g.fillStyle = S[2] ? 'rgba(52,152,219,.12)' : 'rgba(150,150,150,.08)'; g.beginPath(); g.rect(bx - s / 2, by - s / 2, s, s); g.fill(); g.stroke(); g.beginPath(); g.moveTo(bx - s / 2, by - s / 2); g.lineTo(bx - s / 2 + d, by - s / 2 - d); g.lineTo(bx + s / 2 + d, by - s / 2 - d); g.lineTo(bx + s / 2, by - s / 2); g.moveTo(bx + s / 2 + d, by - s / 2 - d); g.lineTo(bx + s / 2 + d, by + s / 2 - d); g.lineTo(bx + s / 2, by + s / 2); g.stroke();
        for (let i = 0; i < 26; i++) { const u = (Math.sin(t * (0.6 + i * 0.07) + i * 3) + 1) / 2, v2 = (Math.cos(t * (0.5 + i * 0.05) + i * 5) + 1) / 2; if (S[2]) M3.sphere(g, bx - s / 2 + 6 + u * (s - 12), by - s / 2 + 6 + v2 * (s - 12), 2.6, S[3] === '#ecf0f1' ? '#999' : S[3], '#fff'); }
        T(g, S[2] ? `১ mol যেকোনো গ্যাস = ২২.৪ L (STP)` : 'কঠিন/তরল: মোলার আয়তন ভিন্ন', bx + d / 2, by + s / 2 + 18, col, { s: 9.5, b: true }); T(g, S[2] ? 'বাহু ≈ ২৮.২ cm' : (sk === 'H2O' ? '১ mol পানি ≈ ১৮ mL' : ''), bx + d / 2, by + s / 2 + 32, col, { s: 9, c: col.mu }); }
    };
    const info = () => { const S = SUB[sk]; out.innerHTML = `${TXB(`n = \\dfrac{m}{M} = \\dfrac{N}{N_A}${S[2] ? ' = \\dfrac{V_{\\text{STP}}}{22.4\\ \\text{L}}' : ''}`)}<div class="small">${S[0]} এর ${bn(+n.toPrecision(4))} mol = ${sig(n * S[1], 4)} g = ${sig(n * NA, 4)} টি অণু${S[2] ? ` = STP তে ${sig(n * VM, 4)} L` : ''}। প্রতি অণুর ভর = M/N_A = ${sig(S[1] / NA)} g।</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    fill(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.১.২ সমীকরণ সমতা ======================= */
const EQS = [
  ['মিথেনের দহন', [['CH4', { C: 1, H: 4 }], ['O2', { O: 2 }]], [['CO2', { C: 1, O: 2 }], ['H2O', { H: 2, O: 1 }]], [1, 2, 1, 2]],
  ['প্রোপেনের দহন', [['C3H8', { C: 3, H: 8 }], ['O2', { O: 2 }]], [['CO2', { C: 1, O: 2 }], ['H2O', { H: 2, O: 1 }]], [1, 5, 3, 4]],
  ['অ্যালুমিনিয়ামের জারণ', [['Al', { Al: 1 }], ['O2', { O: 2 }]], [['Al2O3', { Al: 2, O: 3 }]], [4, 3, 2]],
  ['হেমাটাইটের বিজারণ', [['Fe2O3', { Fe: 2, O: 3 }], ['CO', { C: 1, O: 1 }]], [['Fe', { Fe: 1 }], ['CO2', { C: 1, O: 2 }]], [1, 3, 2, 3]],
  ['অ্যামোনিয়ার জারণ (অসওয়াল্ড)', [['NH3', { N: 1, H: 3 }], ['O2', { O: 2 }]], [['NO', { N: 1, O: 1 }], ['H2O', { H: 2, O: 1 }]], [4, 5, 4, 6]],
  ['গ্লুকোজের শ্বসন', [['C6H12O6', { C: 6, H: 12, O: 6 }], ['O2', { O: 2 }]], [['CO2', { C: 1, O: 2 }], ['H2O', { H: 2, O: 1 }]], [1, 6, 6, 6]],
  ['KMnO₄ ও গাঢ় HCl', [['KMnO4', { K: 1, Mn: 1, O: 4 }], ['HCl', { H: 1, Cl: 1 }]], [['KCl', { K: 1, Cl: 1 }], ['MnCl2', { Mn: 1, Cl: 2 }], ['H2O', { H: 2, O: 1 }], ['Cl2', { Cl: 2 }]], [2, 16, 2, 2, 8, 5]],
  ['তামা ও লঘু HNO₃', [['Cu', { Cu: 1 }], ['HNO3', { H: 1, N: 1, O: 3 }]], [['Cu(NO3)2', { Cu: 1, N: 2, O: 6 }], ['NO', { N: 1, O: 1 }], ['H2O', { H: 2, O: 1 }]], [3, 8, 3, 2, 4]]
];
const sub2 = s => s.replace(/(\d+)/g, d => d.split('').map(x => '₀₁₂₃₄₅₆₇₈₉'[x]).join(''));
V.p2c3_balance = {
  t: 'রাসায়নিক সমীকরণ সমতাকরণ: সহগ বাড়িয়ে-কমিয়ে প্রতিটি মৌলের পরমাণু সংখ্যা দুই পাশে মিলাও — পরমাণু হিসাবের দণ্ডলেখ, ধাপভিত্তিক ইঙ্গিত (হিট-ট্রায়াল ও বীজগাণিতিক পদ্ধতি)', k: ['int', '2d'],
  cap: 'একটি অসম সমীকরণ বেছে নাও। প্রতিটি সংকেতের নিচে ▲/▼ বোতামে সহগ বদলাও। দণ্ডলেখে প্রতিটি মৌলের বাম (বিক্রিয়ক) ও ডান (উৎপাদ) পাশের পরমাণু সংখ্যা — সমান হলে সবুজ ✓। সব মৌল সমান হলে এবং সহগগুলো ক্ষুদ্রতম পূর্ণসংখ্যা হলে সমীকরণ সমতাকৃত। "ইঙ্গিত" চাপলে কোন মৌল আগে মেলাতে হবে বলে দেয় — নিয়ম: যে মৌল সবচেয়ে কম সংকেতে আছে (সাধারণত ধাতু বা C) আগে, তারপর H, শেষে O বা মুক্ত মৌল (O₂, Cl₂)।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-e', EQS.map((e, i) => [String(i), e[0]]), '0')}<button class="btn sm" data-hint>ইঙ্গিত</button><button class="btn sm" data-sol>সমাধান দেখাও</button><button class="btn sm" data-rst>রিসেট</button></div><div data-eq style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;justify-content:center;margin:6px 0"></div>${X.cv('পরমাণু হিসাব', 200)}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), eqd = q('[data-eq]');
    let L = X.fit(c, () => 200), ei = 0, co = [], hint = '';
    const E = () => EQS[ei], sp = () => E()[1].concat(E()[2]);
    const elems = () => { const s = []; sp().forEach(([, f]) => Object.keys(f).forEach(k => { if (!s.includes(k)) s.push(k); })); return s; };
    const count = side => { const r = {}, lst = side ? E()[2] : E()[1], off = side ? E()[1].length : 0; lst.forEach(([, f], i) => Object.entries(f).forEach(([k, v]) => { r[k] = (r[k] || 0) + v * co[off + i]; })); return r; };
    const gcd = (a, b) => b ? gcd(b, a % b) : a;
    const build = () => { const nL = E()[1].length; eqd.innerHTML = sp().map(([f], i) => `${i === nL ? '<b style="font-size:20px">→</b>' : i ? '<b>+</b>' : ''}<span style="display:inline-flex;flex-direction:column;align-items:center;border:1px solid var(--line);border-radius:10px;padding:2px 6px"><button class="btn sm" data-u="${i}" style="min-height:22px;padding:0 10px">▲</button><span style="font-size:17px"><b style="color:var(--accent)">${co[i] > 1 ? co[i] : ''}</b>${sub2(f)}</span><button class="btn sm" data-d="${i}" style="min-height:22px;padding:0 10px">▼</button></span>`).join(' '); eqd.querySelectorAll('[data-u]').forEach(b => b.onclick = () => { co[+b.dataset.u] = Math.min(20, co[+b.dataset.u] + 1); hint = ''; build(); draw(); info(); }); eqd.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { co[+b.dataset.d] = Math.max(1, co[+b.dataset.d] - 1); hint = ''; build(); draw(); info(); }); };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const es = elems(), l = count(0), r = count(1), n = es.length, cw = (W - 20) / n, mx = Math.max(...es.map(e => Math.max(l[e], r[e]))); es.forEach((e, i) => { const x = 10 + i * cw, ok = l[e] === r[e], bw = Math.min(26, cw / 3), base = H - 30, h = H - 70; [[l[e], '#2d6fd6', -1], [r[e], '#e67e22', 1]].forEach(([v, cc, s]) => { const bh = v / mx * h, bx = x + cw / 2 + s * (bw / 2 + 2) - bw / 2; g.fillStyle = cc; g.fillRect(bx, base - bh, bw, bh); T(g, bn(v), bx + bw / 2, base - bh - 4, col, { s: 10, b: true }); }); T(g, `${e} ${ok ? '✓' : '✗'}`, x + cw / 2, H - 12, col, { b: true, s: 11, c: ok ? '#2f9e44' : '#c0392b' }); }); T(g, 'নীল: বিক্রিয়ক পাশ · কমলা: উৎপাদ পাশ', W / 2, 14, col, { s: 9.5, c: col.mu }); };
    const info = () => { const es = elems(), l = count(0), r = count(1), all = es.every(e => l[e] === r[e]), g0 = co.reduce(gcd); const txt = sp().map(([f], i) => (co[i] > 1 ? co[i] : '') + f), nL = E()[1].length; out.innerHTML = `${TXB(`\\ce{${txt.slice(0, nL).join(' + ')} -> ${txt.slice(nL).join(' + ')}}`)}<div style="font-weight:700;color:${all && g0 === 1 ? 'var(--ok)' : all ? 'var(--warn)' : 'var(--muted)'}">${all ? (g0 === 1 ? '✓ সমতাকৃত! সব মৌলের পরমাণু সংখ্যা সমান এবং সহগগুলো ক্ষুদ্রতম পূর্ণসংখ্যা।' : `সমান হয়েছে, কিন্তু সব সহগ ${bn(g0)} দিয়ে বিভাজ্য — ক্ষুদ্রতম অনুপাতে আনো।`) : `অমিল মৌল: ${es.filter(e => l[e] !== r[e]).join(', ')}`}</div>${hint ? `<div class="small">${hint}</div>` : ''}`; };
    const doHint = () => { const es = elems(), l = count(0), r = count(1); const bad = es.filter(e => l[e] !== r[e]); if (!bad.length) { hint = 'সব মিলে গেছে!'; return; } const freq = e => sp().filter(([, f]) => f[e]).length; bad.sort((a, b) => freq(a) - freq(b) || (a === 'O') - (b === 'O') || (a === 'H') - (b === 'H')); const e = bad[0]; hint = `ইঙ্গিত: এখন ${e} মেলাও — বাম পাশে ${bn(l[e])}টি, ডান পাশে ${bn(r[e])}টি। ${freq(e) === 2 ? `${e} কেবল দুটি সংকেতে আছে, তাই এটি আগে মেলানো সহজ।` : 'একাধিক সংকেতে থাকা মৌল (যেমন O) শেষে মেলাও।'}`; };
    const reset = () => { co = sp().map(() => 1); hint = ''; build(); draw(); info(); };
    q('[data-e]').onchange = e => { ei = +e.target.value; reset(); };
    q('[data-hint]').onclick = () => { doHint(); info(); }; q('[data-sol]').onclick = () => { co = E()[3].slice(); hint = 'বীজগাণিতিক পদ্ধতি: প্রতিটি সহগকে অজানা (a, b, c…) ধরে প্রতিটি মৌলের জন্য সমীকরণ লিখে সমাধান করলে এই ক্ষুদ্রতম পূর্ণসংখ্যা অনুপাত পাওয়া যায়।'; build(); draw(); info(); }; q('[data-rst]').onclick = reset;
    reset();
    const un = X.onResize(el, () => { L = X.fit(c, () => 200); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৩.১.৩ আয়নিক সমীকরণ ======================= */
const ION = [
  ['AgNO₃ + NaCl', 'AgNO3(aq) + NaCl(aq) -> AgCl(s) v + NaNO3(aq)', 'Ag+(aq) + NO3-(aq) + Na+(aq) + Cl-(aq) -> AgCl(s) + Na+(aq) + NO3-(aq)', 'Ag+(aq) + Cl-(aq) -> AgCl(s)', ['Na⁺', 'NO₃⁻'], [['Ag⁺', '#bdc3c7'], ['NO₃⁻', '#e74c3c'], ['Na⁺', '#8e44ad'], ['Cl⁻', '#27ae60']], ['Ag⁺', 'Cl⁻'], '#f5f5f5', 'সাদা AgCl অধঃক্ষেপ'],
  ['BaCl₂ + Na₂SO₄', 'BaCl2(aq) + Na2SO4(aq) -> BaSO4(s) v + 2NaCl(aq)', 'Ba^2+(aq) + 2Cl-(aq) + 2Na+(aq) + SO4^2-(aq) -> BaSO4(s) + 2Na+(aq) + 2Cl-(aq)', 'Ba^2+(aq) + SO4^2-(aq) -> BaSO4(s)', ['Na⁺', 'Cl⁻'], [['Ba²⁺', '#16a085'], ['Cl⁻', '#27ae60'], ['Na⁺', '#8e44ad'], ['SO₄²⁻', '#f1c40f']], ['Ba²⁺', 'SO₄²⁻'], '#ffffff', 'সাদা BaSO₄ অধঃক্ষেপ (সালফেট পরীক্ষা)'],
  ['HCl + NaOH', 'HCl(aq) + NaOH(aq) -> NaCl(aq) + H2O(l)', 'H+(aq) + Cl-(aq) + Na+(aq) + OH-(aq) -> Na+(aq) + Cl-(aq) + H2O(l)', 'H+(aq) + OH-(aq) -> H2O(l)', ['Na⁺', 'Cl⁻'], [['H⁺', '#e74c3c'], ['Cl⁻', '#27ae60'], ['Na⁺', '#8e44ad'], ['OH⁻', '#3498db']], ['H⁺', 'OH⁻'], null, 'পানি তৈরি — সব শক্তিশালী এসিড-ক্ষার প্রশমনের একই নিট বিক্রিয়া'],
  ['CuSO₄ + NaOH', 'CuSO4(aq) + 2NaOH(aq) -> Cu(OH)2(s) v + Na2SO4(aq)', 'Cu^2+(aq) + SO4^2-(aq) + 2Na+(aq) + 2OH-(aq) -> Cu(OH)2(s) + 2Na+(aq) + SO4^2-(aq)', 'Cu^2+(aq) + 2OH-(aq) -> Cu(OH)2(s)', ['Na⁺', 'SO₄²⁻'], [['Cu²⁺', '#2e86de'], ['SO₄²⁻', '#f1c40f'], ['Na⁺', '#8e44ad'], ['OH⁻', '#3498db']], ['Cu²⁺', 'OH⁻'], '#5dade2', 'নীল Cu(OH)₂ অধঃক্ষেপ'],
  ['Zn + CuSO₄', 'Zn(s) + CuSO4(aq) -> ZnSO4(aq) + Cu(s)', 'Zn(s) + Cu^2+(aq) + SO4^2-(aq) -> Zn^2+(aq) + SO4^2-(aq) + Cu(s)', 'Zn(s) + Cu^2+(aq) -> Zn^2+(aq) + Cu(s)', ['SO₄²⁻'], [['Cu²⁺', '#2e86de'], ['SO₄²⁻', '#f1c40f']], ['Cu²⁺'], '#b9770e', 'লালচে Cu জমা হয়, নীল বর্ণ ফিকে (রিডক্স)']
];
V.p2c3_ionic = {
  t: 'আয়নিক সমীকরণ: আণবিক → পূর্ণ আয়নিক → নিট আয়নিক সমীকরণ; দর্শক আয়ন চিহ্নিতকরণ এবং বিকারে আয়নগুলোর অ্যানিমেশন (অধঃক্ষেপণ, প্রশমন, প্রতিস্থাপন)', k: ['anim', 'int', '2d'],
  cap: 'একটি বিক্রিয়া বেছে "মিশাও" চাপো। বিকারে দ্রবণের আয়নগুলো এলোমেলো ঘুরছে; যে আয়নগুলো প্রকৃতপক্ষে বিক্রিয়া করে (উজ্জ্বল রিং) তারা একত্রিত হয়ে অধঃক্ষেপ বা পানি তৈরি করে, আর দর্শক আয়ন (ধূসর রিং) আগের মতোই দ্রবণে ঘুরতে থাকে — এগুলো নিট সমীকরণ থেকে বাদ যায়। নিচে তিন ধাপের সমীকরণ: আণবিক, পূর্ণ আয়নিক (শক্তিশালী তড়িৎবিশ্লেষ্য আয়নে ভেঙে লেখা) ও নিট আয়নিক। নিয়ম: অধঃক্ষেপ, পানি, গ্যাস ও দুর্বল তড়িৎবিশ্লেষ্য আণবিক রূপে থাকে; দুই পাশে আধান ও পরমাণু দুটোই সমান হতে হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-r', ION.map((r, i) => [String(i), r[0]]), '0')}<button class="btn sm primary" data-go>▶ মিশাও</button></div>${X.cv('আয়নিক সমীকরণ')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 280 : 300;
    let L = X.fit(c, hf), ri = 0, p = 0, run = false, t = 0, parts = [];
    const seed = () => { const r = ION[ri]; parts = []; let s = 7; const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; }; r[5].forEach(([nm, cc]) => { for (let i = 0; i < 6; i++) parts.push({ nm, cc, x: rnd(), y: rnd(), vx: rnd() - 0.5, vy: rnd() - 0.5, act: r[6].includes(nm) }); }); if (ri === 4) for (let i = 0; i < 4; i++) parts.push({ nm: 'Zn²⁺', cc: '#95a5a6', x: 0.5, y: 0.5, vx: 0, vy: 0, act: false, born: true }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const r = ION[ri], k = Math.min(1, p);
      const bx = 20, by = 20, bw = W - 40, bh = H - 50; g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(bx, by); g.lineTo(bx, by + bh); g.lineTo(bx + bw, by + bh); g.lineTo(bx + bw, by); g.stroke(); g.fillStyle = 'rgba(100,170,230,.10)'; g.fillRect(bx + 2, by + 10, bw - 4, bh - 12);
      if (ri === 4) { g.fillStyle = '#7f8c8d'; g.fillRect(bx + bw / 2 - 8, by - 10, 16, bh * 0.75); if (k > 0.2) { g.fillStyle = '#b9770e'; for (let i = 0; i < 20 * k; i++) g.fillRect(bx + bw / 2 - 10 + (i % 2) * 18, by + 10 + i * bh * 0.03, 3, 4); } T(g, 'Zn দণ্ড', bx + bw / 2, by + bh * 0.75 + 4, col, { s: 9, c: col.mu }); }
      const pairs = r[6], nPrec = Math.floor(k * 6);
      parts.forEach((pt, i) => { if (pt.born && k < 0.3) return; let x = bx + 10 + pt.x * (bw - 20), y = by + 18 + pt.y * (bh - 30); const idx = parts.filter(z => z.nm === pt.nm).indexOf(pt);
        if (pt.act && idx < nPrec && r[7]) { const tx = bx + bw * 0.3 + idx * 18 + (pairs.indexOf(pt.nm) ? 8 : 0), ty = by + bh - 10 - (pairs.indexOf(pt.nm) ? 7 : 0); const f = Math.min(1, (k * 6 - idx)); x = x + (tx - x) * f; y = y + (ty - y) * f; }
        if (pt.act && idx < nPrec && ri === 4) { const tx = bx + bw / 2, f = Math.min(1, (k * 6 - idx)); x = x + (tx - x) * f; if (f >= 1) return; }
        M3.sphere(g, x, y, 7, pt.cc, '#fff'); g.strokeStyle = pt.act ? '#f1c40f' : col.mu; g.lineWidth = pt.act ? 2 : 1; g.beginPath(); g.arc(x, y, 9, 0, 7); g.stroke(); T(g, pt.nm, x, y - 11, col, { s: 8, c: col.mu }); });
      if (ri === 2 && k > 0.2) for (let i = 0; i < nPrec; i++) { M3.sphere(g, bx + bw * 0.6 + i * 16, by + 30, 6, '#5dade2', '#fff'); T(g, 'H₂O', bx + bw * 0.6 + i * 16, by + 22, col, { s: 7.5, c: '#2471a3' }); }
      T(g, k >= 1 ? r[8] : run ? 'বিক্রিয়া চলছে…' : 'হলুদ রিং = বিক্রিয়ক আয়ন · ধূসর রিং = দর্শক আয়ন', W / 2, H - 8, col, { s: 10, b: k >= 1 });
    };
    const info = () => { const r = ION[ri]; out.innerHTML = `<div class="small"><b>আণবিক সমীকরণ:</b></div>${TXB(`\\ce{${r[1]}}`)}<div class="small"><b>পূর্ণ আয়নিক সমীকরণ:</b></div>${TXB(`\\ce{${r[2]}}`)}<div class="small"><b>নিট আয়নিক সমীকরণ</b> (দর্শক আয়ন: ${r[4].join(', ')} বাদ):</div>${TXB(`\\ce{${r[3]}}`)}`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; parts.forEach(pt => { pt.x += pt.vx * dt * 0.15; pt.y += pt.vy * dt * 0.15; if (pt.x < 0 || pt.x > 1) pt.vx *= -1; if (pt.y < 0 || pt.y > 1) pt.vy *= -1; pt.x = Math.max(0, Math.min(1, pt.x)); pt.y = Math.max(0, Math.min(1, pt.y)); }); if (run) { p = Math.min(1, p + dt * 0.3); if (p >= 1) run = false; } } draw(); }, { paused: false });
    q('[data-r]').onchange = e => { ri = +e.target.value; p = 0; run = false; seed(); info(); }; q('[data-go]').onclick = () => { p = 0; run = true; };
    seed(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.১.৪ গে-লুসাকের সূত্র ======================= */
const GL = [
  ['H₂ + Cl₂ → 2HCl', [['H₂', 1, '#bdc3c7'], ['Cl₂', 1, '#27ae60']], [['HCl', 2, '#16a085']], 'H2(g) + Cl2(g) -> 2HCl(g)'],
  ['2H₂ + O₂ → 2H₂O (বাষ্প)', [['H₂', 2, '#bdc3c7'], ['O₂', 1, '#e74c3c']], [['H₂O(g)', 2, '#5dade2']], '2H2(g) + O2(g) -> 2H2O(g)'],
  ['N₂ + 3H₂ → 2NH₃', [['N₂', 1, '#3498db'], ['H₂', 3, '#bdc3c7']], [['NH₃', 2, '#2980b9']], 'N2(g) + 3H2(g) -> 2NH3(g)'],
  ['CH₄ + 2O₂ → CO₂ + 2H₂O (তরল)', [['CH₄', 1, '#555'], ['O₂', 2, '#e74c3c']], [['CO₂', 1, '#7f8c8d']], 'CH4(g) + 2O2(g) -> CO2(g) + 2H2O(l)'],
  ['2CO + O₂ → 2CO₂', [['CO', 2, '#34495e'], ['O₂', 1, '#e74c3c']], [['CO₂', 2, '#7f8c8d']], '2CO(g) + O2(g) -> 2CO2(g)']
];
V.p2c3_gayLussac = {
  t: 'গে-লুসাকের গ্যাস আয়তন সূত্র: একই তাপমাত্রা ও চাপে বিক্রিয়ক ও উৎপাদ গ্যাসের আয়তন সরল পূর্ণসংখ্যার অনুপাতে (সমীকরণের সহগ অনুপাতে) — সিরিঞ্জ অ্যানিমেশন, বাড়তি বিক্রিয়ক ও মোট আয়তনের পরিবর্তন', k: ['anim', 'int', 'calc'],
  cap: 'বিক্রিয়া বেছে নিয়ে দুটি বিক্রিয়ক গ্যাসের আয়তন (mL) স্লাইডারে ঠিক করো, তারপর "বিক্রিয়া" চাপো। দুটি সিরিঞ্জ থেকে গ্যাস মিশ্রণ পাত্রে যায়; উৎপাদ সিরিঞ্জে কতটুকু উৎপাদ তৈরি হলো এবং কোন বিক্রিয়ক কতটুকু বাড়তি রইল দেখায়। একই T ও P তে আয়তন মোল সংখ্যার সমানুপাতিক (অ্যাভোগেড্রো সূত্র) — তাই আয়তনের অনুপাত = সহগের অনুপাত। লক্ষ করো, তরল পানি তৈরি হলে (মিথেনের দহন) তার আয়তন গ্যাসের হিসাবে ধরা হয় না, তাই মোট আয়তন অনেক কমে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-r', GL.map((r, i) => [String(i), r[0]]), '0')}<button class="btn sm primary" data-go>▶ বিক্রিয়া</button></div>${X.cv('গে-লুসাকের সূত্র')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:130px"><span data-l0></span> = <b data-v0></b> mL<input type="range" min="0" max="100" step="5" value="50" data-a></label><label class="small" style="flex:1;min-width:130px"><span data-l1></span> = <b data-v1></b> mL<input type="range" min="0" max="100" step="5" value="50" data-b></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 280 : 360;
    let L = X.fit(c, hf), ri = 0, va = 50, vb = 50, p = 0, run = false, t = 0;
    const calc = () => { const r = GL[ri], a = r[1][0][1], b = r[1][1][1], ext = Math.min(va / a, vb / b); return { ext, la: va - ext * a, lb: vb - ext * b, prod: r[2].map(x => ext * x[1]) }; };
    const syr = (g, col, x, y, w, h, frac, cc, lab, val) => { g.strokeStyle = col.fg; g.lineWidth = 1.5; g.strokeRect(x, y, w, h); for (let i = 1; i < 10; i++) { g.beginPath(); g.moveTo(x, y + h * i / 10); g.lineTo(x + 6, y + h * i / 10); g.stroke(); } g.fillStyle = cc; g.globalAlpha = 0.45; g.fillRect(x + 1, y + h * (1 - frac), w - 2, h * frac); g.globalAlpha = 1; g.fillStyle = col.mu; g.fillRect(x - 4, y + h * (1 - frac) - 4, w + 8, 4); g.fillRect(x + w / 2 - 2, y + h * (1 - frac) - 30, 4, 26); T(g, lab, x + w / 2, y + h + 14, col, { b: true, s: 10, c: cc === '#bdc3c7' ? col.fg : cc }); T(g, `${sig(val)} mL`, x + w / 2, y + h + 27, col, { s: 9.5 }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const r = GL[ri], k = Math.min(1, p), C = calc(); const wd = wide(W), sw = wd ? 42 : 34, sh = H - 90, y0 = 40;
      const xs = wd ? [W * 0.1, W * 0.25, W * 0.6, W * 0.78] : [W * 0.08, W * 0.3, W * 0.56, W * 0.8];
      syr(g, col, xs[0], y0, sw, sh, (va - (va - C.la) * k) / 100, r[1][0][2], r[1][0][0], va - (va - C.la) * k);
      syr(g, col, xs[1], y0, sw, sh, (vb - (vb - C.lb) * k) / 100, r[1][1][2], r[1][1][0], vb - (vb - C.lb) * k);
      r[2].forEach((pr, i) => syr(g, col, xs[2 + i], y0, sw, sh, Math.min(1, C.prod[i] * k / 200), pr[2], pr[0], C.prod[i] * k));
      T(g, '→', (xs[1] + xs[2] + sw) / 2, y0 + sh / 2, col, { b: true, s: 22, c: col.acc }); T(g, 'একই T ও P', (xs[1] + xs[2] + sw) / 2, y0 + sh / 2 + 18, col, { s: 9, c: col.mu });
      T(g, r[0], W / 2, 18, col, { b: true, s: 12 }); if (k >= 1) T(g, `মোট গ্যাস আয়তন: ${sig(va + vb)} → ${sig(C.la + C.lb + C.prod.reduce((a, b) => a + b, 0))} mL`, W / 2, H - 6, col, { b: true, s: 10.5, c: '#2f9e44' });
    };
    const info = () => { const r = GL[ri], C = calc(); q('[data-l0]').textContent = r[1][0][0]; q('[data-l1]').textContent = r[1][1][0]; q('[data-v0]').textContent = bn(va); q('[data-v1]').textContent = bn(vb); const ratio = r[1].concat(r[2]).map(x => bn(x[1])).join(' : '); out.innerHTML = `${TXB(`\\ce{${r[3]}}`)}<div>আয়তন অনুপাত (গ্যাস) = ${ratio}। বিক্রিয়ার মাত্রা অনুযায়ী উৎপাদ ${r[2].map((x, i) => `${x[0]} = ${sig(C.prod[i])} mL`).join(', ')}; অবশিষ্ট ${C.la > 1e-9 ? `${r[1][0][0]} = ${sig(C.la)} mL` : ''}${C.lb > 1e-9 ? `${r[1][1][0]} = ${sig(C.lb)} mL` : ''}${C.la < 1e-9 && C.lb < 1e-9 ? 'কিছু নেই (সঠিক অনুপাত)' : ''}।</div><div class="small">সীমিত বিক্রিয়ক: ${C.la < 1e-9 && C.lb < 1e-9 ? 'নেই — দুটিই সম্পূর্ণ ব্যয়' : C.la < 1e-9 ? r[1][0][0] : r[1][1][0]}।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.4); if (p >= 1) run = false; } } draw(); }, { paused: false });
    q('[data-r]').onchange = e => { ri = +e.target.value; p = 0; info(); }; q('[data-a]').oninput = e => { va = +e.target.value; p = 0; info(); }; q('[data-b]').oninput = e => { vb = +e.target.value; p = 0; info(); }; q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.২–৩.৪ স্টয়কিওমিতি ও সীমিত বিক্রিয়ক ======================= */
const RX = [
  ['Zn + 2HCl → ZnCl₂ + H₂', [['Zn', 1, 65.38, 's'], ['HCl', 2, 36.46, 'aq']], ['H₂', 1, 2.016], 'Zn + 2HCl -> ZnCl2 + H2 ^'],
  ['CaCO₃ + 2HCl → CaCl₂ + H₂O + CO₂', [['CaCO₃', 1, 100.09, 's'], ['HCl', 2, 36.46, 'aq']], ['CO₂', 1, 44.01], 'CaCO3 + 2HCl -> CaCl2 + H2O + CO2 ^'],
  ['2KClO₃ → 2KCl + 3O₂ (তাপ, MnO₂)', [['KClO₃', 2, 122.55, 's']], ['O₂', 3, 32.00], '2KClO3 ->[\\text{MnO}_2][\\Delta] 2KCl + 3O2 ^'],
  ['Mg + H₂SO₄ → MgSO₄ + H₂', [['Mg', 1, 24.31, 's'], ['H₂SO₄', 1, 98.08, 'aq']], ['H₂', 1, 2.016], 'Mg + H2SO4 -> MgSO4 + H2 ^'],
  ['NH₄Cl + NaOH → NaCl + H₂O + NH₃', [['NH₄Cl', 1, 53.49, 's'], ['NaOH', 1, 40.00, 's']], ['NH₃', 1, 17.03], 'NH4Cl + NaOH ->[\\Delta] NaCl + H2O + NH3 ^']
];
V.p2c3_stoich = {
  t: 'স্টয়কিওমিতি গণক: বিক্রিয়কের ভর থেকে সীমিত বিক্রিয়ক, উৎপাদ গ্যাসের মোল, ভর ও আয়তন (STP এবং যেকোনো তাপমাত্রা-চাপে PV = nRT), বিশুদ্ধতা ও শতকরা উৎপাদন — পানির উপর গ্যাস সংগ্রহের অ্যানিমেশন', k: ['anim', 'int', 'calc'],
  cap: 'বিক্রিয়া বেছে বিক্রিয়কের ভর (g), নমুনার বিশুদ্ধতা (%), তাপমাত্রা ও চাপ এবং শতকরা উৎপাদন ঠিক করো। "বিক্রিয়া" চাপলে ফ্লাস্কে গ্যাস তৈরি হয়ে নির্গম নল দিয়ে পানিপূর্ণ উল্টানো পাত্রে জমে (পানি অপসারণ পদ্ধতি) — গ্যাসের আয়তন বাড়ার সাথে পানির স্তর নামে। নিচে ধাপে ধাপে সমাধান: ভর → মোল → সীমিত বিক্রিয়ক নির্ধারণ (মোল ÷ সহগ সবচেয়ে কম যেটির) → উৎপাদের মোল (সহগ অনুপাতে) → ভর ও আয়তন। পানির উপর সংগৃহীত গ্যাসের ক্ষেত্রে শুষ্ক গ্যাসের চাপ = মোট চাপ − জলীয় বাষ্পচাপ।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-r', RX.map((r, i) => [String(i), r[0]]), '0')}<button class="btn sm primary" data-go>▶ বিক্রিয়া</button></div>${X.cv('স্টয়কিওমিতি')}<div class="ctl" style="flex-wrap:wrap" data-in></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), inp = q('[data-in]');
    const hf = w => wide(w) ? 280 : 340;
    let L = X.fit(c, hf), ri = 0, ms = [6.54, 10], pur = 100, Tc = 0, Pk = 101.3, yld = 100, wet = false, p = 0, run = false, t = 0;
    const PH2O = Tc => 0.6113 * Math.exp(17.27 * Tc / (Tc + 237.3)); // kPa (Tetens)
    const build = () => { const r = RX[ri]; inp.innerHTML = r[1].map((x, i) => `<label class="small" style="flex:1;min-width:120px">${x[0]} = <b data-mv${i}></b> g<input type="range" min="0.5" max="${i ? 40 : 30}" step="0.1" value="${ms[i]}" data-m${i}></label>`).join('') + `<label class="small" style="flex:1;min-width:110px">বিশুদ্ধতা (${r[1][0][0]}) = <b data-pv></b>%<input type="range" min="50" max="100" value="${pur}" data-p></label><label class="small" style="flex:1;min-width:110px">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="0" max="50" value="${Tc}" data-t></label><label class="small" style="flex:1;min-width:110px">চাপ = <b data-kv></b> kPa<input type="range" min="90" max="110" step="0.1" value="${Pk}" data-k></label><label class="small" style="flex:1;min-width:110px">শতকরা উৎপাদন = <b data-yv></b>%<input type="range" min="50" max="100" value="${yld}" data-y></label><label class="small"><input type="checkbox" data-w ${wet ? 'checked' : ''}> পানির উপর সংগ্রহ</label>`; r[1].forEach((x, i) => { inp.querySelector(`[data-m${i}]`).oninput = e => { ms[i] = +e.target.value; p = 0; info(); }; }); inp.querySelector('[data-p]').oninput = e => { pur = +e.target.value; p = 0; info(); }; inp.querySelector('[data-t]').oninput = e => { Tc = +e.target.value; info(); }; inp.querySelector('[data-k]').oninput = e => { Pk = +e.target.value; info(); }; inp.querySelector('[data-y]').oninput = e => { yld = +e.target.value; p = 0; info(); }; inp.querySelector('[data-w]').onchange = e => { wet = e.target.checked; info(); }; };
    const calc = () => { const r = RX[ri]; const mol = r[1].map((x, i) => (i === 0 ? ms[i] * pur / 100 : ms[i]) / x[2]); const per = mol.map((m, i) => m / r[1][i][1]); const lim = per.indexOf(Math.min(...per)); const ext = per[lim]; const ng = ext * r[2][1] * yld / 100; const Pdry = wet ? Pk - PH2O(Tc) : Pk; const V = ng * 8.314 * (Tc + 273.15) / Pdry; return { mol, lim, ext, ng, mg: ng * r[2][2], Vstp: ng * VM, V, Pdry }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const C = calc(), k = Math.min(1, p), wd = wide(W);
      const fx = wd ? W * 0.18 : W * 0.2, fy = H * 0.62; g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.arc(fx, fy, 36, -Math.PI / 2 + 0.3, 1.5 * Math.PI - 0.3); g.stroke(); g.beginPath(); g.moveTo(fx - 10, fy - 35); g.lineTo(fx - 10, fy - 70); g.moveTo(fx + 10, fy - 35); g.lineTo(fx + 10, fy - 70); g.stroke(); g.fillStyle = 'rgba(180,210,240,.35)'; g.beginPath(); g.arc(fx, fy, 34, 0.1 * Math.PI, 0.9 * Math.PI); g.fill();
      const solid = 1 - k * (C.lim === 0 ? 1 : C.ext / C.mol[0]); for (let i = 0; i < 18 * solid; i++) { g.fillStyle = '#7f8c8d'; g.fillRect(fx - 20 + (i * 13 % 40), fy + 18 + (i % 3) * 4, 4, 4); }
      if (run) for (let i = 0; i < 10; i++) { const u = (t * 1.2 + i / 10) % 1; g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.arc(fx - 15 + (i * 7 % 30), fy + 25 - u * 40, 2, 0, 7); g.fill(); }
      // delivery tube to trough
      const tx = wd ? W * 0.5 : W * 0.66, trY = H * 0.55; g.strokeStyle = col.fg; g.lineWidth = 3; g.beginPath(); g.moveTo(fx, fy - 70); g.lineTo(fx, fy - 90); g.lineTo(tx - 50, fy - 90); g.lineTo(tx - 50, trY + 40); g.lineTo(tx, trY + 40); g.stroke();
      g.fillStyle = 'rgba(80,150,230,.25)'; g.fillRect(tx - 80, trY, 160, H - trY - 10); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.strokeRect(tx - 80, trY, 160, H - trY - 10);
      const jx = tx - 20, jy = 20, jw = 40, jh = trY + 30 - jy, frac = Math.min(1, C.V * k / 1e-3 / 3000); g.fillStyle = 'rgba(80,150,230,.35)'; g.fillRect(jx, jy + jh * frac, jw, jh * (1 - frac)); g.strokeRect(jx, jy, jw, jh); if (run) for (let i = 0; i < 5; i++) { const u = (t * 1.5 + i / 5) % 1; g.fillStyle = '#fff'; g.beginPath(); g.arc(tx - 2, trY + 40 - u * (jh * (1 - frac)) * 0.4, 3, 0, 7); g.fill(); }
      T(g, `${RX[ri][2][0]}: ${sig(C.V * k * 1000)} mL`, jx + jw / 2, jy - 6, col, { b: true, s: 10.5 });
      // summary panel
      const px = wd ? W * 0.68 : 12, py = wd ? 30 : 16; if (wd) { [['সীমিত বিক্রিয়ক', RX[ri][1][C.lim][0]], ['উৎপাদ (মোল)', `${sig(C.ng)} mol`], ['উৎপাদ (ভর)', `${sig(C.mg)} g`], ['আয়তন (STP)', `${sig(C.Vstp)} L`], [`আয়তন (${bn(Tc)} °C, ${bn(+Pk.toFixed(1))} kPa)`, `${sig(C.V * 1000)} mL`]].forEach(([a, b], i) => { T(g, a, px, py + i * 38, col, { s: 9.5, a: 'left', c: col.mu }); T(g, b, px, py + i * 38 + 15, col, { s: 12, a: 'left', b: true }); }); }
    };
    const info = () => { const r = RX[ri], C = calc(); r[1].forEach((x, i) => { const e = inp.querySelector(`[data-mv${i}]`); if (e) e.textContent = bn(ms[i]); }); [['pv', pur], ['tv', Tc], ['kv', +Pk.toFixed(1)], ['yv', yld]].forEach(([k, v]) => { const e = inp.querySelector(`[data-${k}]`); if (e) e.textContent = bn(v); });
      const steps = r[1].map((x, i) => `${x[0]}: ${i === 0 && pur < 100 ? `${bn(ms[0])} × ${bn(pur)}% = ${sig(ms[0] * pur / 100)} g; ` : ''}${sig(i === 0 ? ms[0] * pur / 100 : ms[i])} ÷ ${bn(x[2])} = ${sig(C.mol[i])} mol; ÷ সহগ ${bn(x[1])} = ${sig(C.mol[i] / x[1])}`).join('<br>');
      out.innerHTML = `${TXB(`\\ce{${r[3]}}`)}<div class="small"><b>ধাপ ১ — মোল:</b><br>${steps}</div><div class="small"><b>ধাপ ২ — সীমিত বিক্রিয়ক:</b> ${r[1][C.lim][0]} (মোল/সহগ সবচেয়ে কম)${r[1].length > 1 ? `; অপর বিক্রিয়ক বাড়তি` : ''}।</div><div class="small"><b>ধাপ ৩ — উৎপাদ:</b> ${r[2][0]} এর মোল = ${sig(C.ext)} × ${bn(r[2][1])}${yld < 100 ? ` × ${bn(yld)}%` : ''} = ${sig(C.ng)} mol; ভর = ${sig(C.mg)} g; STP তে আয়তন = ${sig(C.ng)} × ২২.৪ = ${sig(C.Vstp)} L।</div><div class="small"><b>ধাপ ৪ — প্রকৃত অবস্থা:</b> V = nRT/P${wet ? ` (শুষ্ক চাপ = ${bn(+Pk.toFixed(1))} − ${sig(PH2O(Tc))} = ${sig(C.Pdry)} kPa)` : ''} = ${sig(C.ng)} × ৮.৩১৪ × ${bn(+(Tc + 273.15).toFixed(2))} ÷ ${sig(C.Pdry)} = ${sig(C.V)} L।</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.25); if (p >= 1) run = false; } } draw(); }, { paused: false });
    q('[data-r]').onchange = e => { ri = +e.target.value; ms = ri === 0 ? [6.54, 10] : ri === 1 ? [10, 10] : ri === 2 ? [12.25] : ri === 3 ? [2.43, 15] : [5.35, 5]; p = 0; build(); info(); };
    q('[data-go]').onclick = () => { p = 0; run = true; };
    build(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
