/* ২য় পত্র অধ্যায় ৩ visuals part 3 — 3.5 molarity (standard solution in volumetric flask), 3.6 concentration unit converter & ppm ladder, 3.7 dilution practical & serial dilution */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const sig = (v, d = 3) => { if (!isFinite(v)) return '—'; if (v === 0) return '০'; const a = Math.abs(v); if (a >= 1e5 || a < 1e-3) { const e = Math.floor(Math.log10(a)), m = v / 10 ** e; const sup = String(e).split('').map(ch => '⁻⁰¹²³⁴⁵⁶⁷⁸⁹'['-0123456789'.indexOf(ch)]).join(''); return `${bn(m.toFixed(d - 1))} × ১০${sup}`; } return bn((+v.toPrecision(d)).toString()); };
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };

/* volumetric flask path: returns geometry */
const flaskPath = (g, cx, top, H) => { const nw = Math.max(5, H * 0.055), r = H * 0.3, bc = top + H - r, nb = bc - Math.sqrt(r * r - nw * nw); const a0 = Math.asin(nw / r); g.beginPath(); g.moveTo(cx - nw, top); g.lineTo(cx - nw, nb); g.arc(cx, bc, r, -Math.PI / 2 - a0, -Math.PI / 2 + a0, true); g.lineTo(cx + nw, top); return { nw, r, bc, nb, mark: top + (nb - top) * 0.35, bottom: bc + r }; };
const flask = (g, col, cx, top, H, level, color, alpha, label) => {
  // level: 0..1 where 1 = calibration mark
  g.save(); const G = flaskPath(g, cx, top, H); g.clip(); const ly = G.bottom - level * (G.bottom - G.mark); if (level > 0) { g.fillStyle = color ? rgba(color, Math.max(0.06, alpha)) : 'rgba(120,170,230,.22)'; g.fillRect(cx - G.r - 2, ly, 2 * G.r + 4, G.bottom - ly + 2); g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(cx - G.r * 0.6, ly, G.r * 0.25, G.bottom - ly); } g.restore();
  flaskPath(g, cx, top, H); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.stroke(); g.strokeStyle = '#e03131'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(cx - G.nw - 4, G.mark); g.lineTo(cx + G.nw + 4, G.mark); g.stroke(); g.fillStyle = col.fg; g.fillRect(cx - G.nw - 2, top - 8, 2 * G.nw + 4, 8);
  if (label) T(g, label, cx, G.bottom + 14, col, { b: true, s: 10 }); return G;
};

/* ======================= ৩.৫ মোলারিটি: প্রমাণ দ্রবণ প্রস্তুতি ======================= */
const SOL = [
  ['NaCl', 'NaCl (সোডিয়াম ক্লোরাইড)', 58.5, null, 0],
  ['NaOH', 'NaOH (সোডিয়াম হাইড্রক্সাইড)', 40, null, 0],
  ['Na2CO3', 'Na₂CO₃ (সোডিয়াম কার্বনেট — প্রাইমারি স্ট্যান্ডার্ড)', 106, null, 0],
  ['H2C2O4', 'H₂C₂O₄·2H₂O (অক্সালিক এসিড — প্রাইমারি স্ট্যান্ডার্ড)', 126, null, 0],
  ['CuSO4', 'CuSO₄·5H₂O (তুঁতে)', 249.7, '#1e88e5', 6],
  ['KMnO4', 'KMnO₄ (পটাশিয়াম পারম্যাঙ্গানেট)', 158, '#8e24aa', 400],
  ['K2Cr2O7', 'K₂Cr₂O₇ (পটাশিয়াম ডাইক্রোমেট — প্রাইমারি স্ট্যান্ডার্ড)', 294.2, '#ef6c00', 40]
];
const SUBN = { NaCl: 'NaCl', NaOH: 'NaOH', Na2CO3: 'Na₂CO₃', H2C2O4: 'H₂C₂O₄·2H₂O', CuSO4: 'CuSO₄·5H₂O', KMnO4: 'KMnO₄', K2Cr2O7: 'K₂Cr₂O₇' };
V.p2c3_molarity = {
  t: 'মোলারিটি ও প্রমাণ দ্রবণ প্রস্তুতি: নির্ভুল ভর মেপে আয়তনিক ফ্লাস্কে দ্রবীভূত করে দাগ পর্যন্ত পূরণ — দ্রবণের রং, কণার ঘনত্ব ও মোলারিটির হিসাব; নির্দিষ্ট মোলারিটির জন্য প্রয়োজনীয় ভর', k: ['anim', 'int', 'calc'],
  cap: 'দ্রব বেছে নাও, ভর (g) ও আয়তনিক ফ্লাস্কের আয়তন ঠিক করো এবং "প্রস্তুত করো" চাপো। অ্যানিমেশন: (১) রাসায়নিক নিক্তিতে ওজন, (২) ফানেল দিয়ে ফ্লাস্কে স্থানান্তর, (৩) অল্প পাতিত পানিতে দ্রবীভূত করা, (৪) দাগ পর্যন্ত পানি যোগ — শেষ কয়েক ফোঁটা ড্রপার দিয়ে, মেনিস্কাসের নিচের অংশ দাগ বরাবর (ডানে বিবর্ধিত)। রঙিন দ্রবের ক্ষেত্রে রঙের তীব্রতা ঘনমাত্রার সাথে বাড়ে। ডানের বাক্সে প্রতি একক আয়তনে দ্রব-কণার সংখ্যা মোলারিটির সমানুপাতিক। "লক্ষ্য মোলারিটি" দিলে প্রয়োজনীয় ভর হিসাব হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-s', SOL.map((s, i) => [String(i), s[1]]), '0')}${SEL('data-v', [['100', '১০০ mL'], ['250', '২৫০ mL'], ['500', '৫০০ mL'], ['1000', '১০০০ mL']], '250')}<button class="btn sm primary" data-go>▶ প্রস্তুত করো</button></div>${X.cv('মোলারিটি')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:2;min-width:160px">দ্রবের ভর = <b data-mv></b> g<input type="range" min="0.05" max="60" step="0.05" value="5.85" data-m></label><label class="small" style="flex:1;min-width:120px">লক্ষ্য মোলারিটি (M) <input type="number" min="0.001" max="5" step="0.001" value="0.1" data-tg style="width:80px;padding:4px;border-radius:6px;border:1px solid var(--line);background:var(--surface);color:var(--fg)"></label><button class="btn sm" data-use>এই ভর নাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 400;
    let L = X.fit(c, hf), si = 0, m = 5.85, vol = 250, p = 1, run = false, t = 0;
    const M = () => m / SOL[si][2] / (vol / 1000);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const s = SOL[si], wd = wide(W), conc = M();
      const stg = p < 0.2 ? 0 : p < 0.4 ? 1 : p < 0.65 ? 2 : p < 1 ? 3 : 4;
      // balance
      const bx = wd ? W * 0.12 : W * 0.22, by = wd ? H - 40 : H * 0.42; g.fillStyle = col.s3 || '#ccc'; g.fillRect(bx - 50, by, 100, 22); g.fillStyle = '#111'; g.fillRect(bx - 30, by + 5, 60, 12); T(g, stg === 0 ? `${(m * Math.min(1, p / 0.2)).toFixed(2)} g` : stg >= 1 ? '0.00 g' : '', bx, by + 15, col, { b: true, s: 9.5, c: '#69db7c' }); g.fillStyle = col.mu; g.fillRect(bx - 28, by - 3, 56, 3);
      const pile = stg === 0 ? Math.min(1, p / 0.2) : stg === 1 ? 1 - (p - 0.2) / 0.2 : 0; if (pile > 0) { g.fillStyle = s[3] || '#f1f3f5'; g.strokeStyle = col.mu; g.beginPath(); g.moveTo(bx - 18 * pile, by - 3); g.quadraticCurveTo(bx, by - 3 - 26 * pile, bx + 18 * pile, by - 3); g.closePath(); g.fill(); g.stroke(); }
      T(g, 'রাসায়নিক নিক্তি', bx, by + 36, col, { s: 9, c: col.mu });
      // flask
      const fx = wd ? W * 0.42 : W * 0.66, ft = wd ? 30 : 24, fH = wd ? H - 70 : H * 0.48;
      const level = stg <= 1 ? 0 : stg === 2 ? 0.45 * (p - 0.4) / 0.25 : stg === 3 ? 0.45 + 0.55 * (p - 0.65) / 0.35 : 1;
      const dissolved = stg >= 3 ? 1 : stg === 2 ? (p - 0.4) / 0.25 : 0;
      const alpha = s[3] ? Math.min(0.92, 1 - Math.exp(-s[4] * conc * (stg >= 3 ? 1 / Math.max(0.45, level) * level : 1) * 0.45)) * dissolved : 0;
      const G = flask(g, col, fx, ft, fH, level, s[3], alpha, `${bn(vol)} mL আয়তনিক ফ্লাস্ক`);
      if (stg === 1) { g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(fx - 16, ft - 26); g.lineTo(fx - 3, ft - 2); g.lineTo(fx + 3, ft - 2); g.lineTo(fx + 16, ft - 26); g.closePath(); g.stroke(); for (let i = 0; i < 8; i++) { const u = (t * 2 + i / 8) % 1; g.fillStyle = s[3] || '#adb5bd'; g.fillRect(fx - 2 + (i % 3 - 1) * 2, ft - 2 + u * (G.bottom - ft - 12), 3, 3); } }
      if (stg === 2 || stg === 3) { if (stg === 3 && p > 0.92) { g.fillStyle = col.mu; g.fillRect(fx - 3, ft - 46, 6, 30); g.beginPath(); g.ellipse(fx, ft - 50, 7, 9, 0, 0, 7); g.fill(); const u = (t * 2) % 1; g.fillStyle = 'rgba(120,170,230,.9)'; g.beginPath(); g.arc(fx, ft - 14 + u * 20, 2.5, 0, 7); g.fill(); T(g, 'ড্রপার', fx + 22, ft - 40, col, { s: 9, c: col.mu, a: 'left' }); } else { const u = (t * 3) % 1; g.strokeStyle = 'rgba(120,170,230,.8)'; g.lineWidth = 3; g.beginPath(); g.moveTo(fx, ft - 30); g.lineTo(fx, ft - 30 + 30 + u * 6); g.stroke(); T(g, 'পাতিত পানি', fx + 18, ft - 22, col, { s: 9, c: col.mu, a: 'left' }); } }
      if (stg === 2 && !s[3]) for (let i = 0; i < 14 * (1 - dissolved); i++) { g.fillStyle = '#adb5bd'; g.fillRect(fx - 20 + (i * 11 % 40), G.bottom - 8 - (i % 3) * 3, 3, 3); }
      // meniscus inset
      if (stg === 4 && wd) { const ix = fx + G.r + 70, iy = G.mark; g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(fx + G.nw + 2, G.mark); g.lineTo(ix - 32, iy); g.stroke(); g.setLineDash([]); g.save(); g.beginPath(); g.arc(ix, iy, 30, 0, 7); g.clip(); g.fillStyle = col.sf; g.fillRect(ix - 30, iy - 30, 60, 60); g.fillStyle = s[3] ? rgba(s[3], Math.max(0.15, alpha)) : 'rgba(120,170,230,.35)'; g.beginPath(); g.moveTo(ix - 30, iy - 10); g.quadraticCurveTo(ix, iy + 12, ix + 30, iy - 10); g.lineTo(ix + 30, iy + 30); g.lineTo(ix - 30, iy + 30); g.closePath(); g.fill(); g.strokeStyle = '#e03131'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(ix - 30, iy + 1); g.lineTo(ix + 30, iy + 1); g.stroke(); g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.arc(ix, iy, 30, 0, 7); g.stroke(); T(g, 'মেনিস্কাসের তলা = দাগ', ix, iy + 44, col, { s: 9, c: col.mu }); }
      // particle box
      const px = wd ? W * 0.8 : W * 0.06, py = wd ? 40 : H * 0.6 + 14, pw = wd ? W * 0.16 : W * 0.88 - 10, ph = wd ? H - 110 : H * 0.3; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(px, py, pw, ph); T(g, 'কণা-দৃশ্য (প্রতি একক আয়তন)', px + pw / 2, py - 6, col, { s: 9, c: col.mu });
      const np = stg >= 3 ? Math.min(90, Math.round(conc * 60)) : 0; for (let i = 0; i < np; i++) { const a = (i * 137.5) % 360, rx = ((i * 73) % 100) / 100, ry = ((i * 41 + 17) % 100) / 100; g.fillStyle = s[3] || '#495057'; g.beginPath(); g.arc(px + 6 + rx * (pw - 12) + Math.sin(t * 2 + a) * 2, py + 6 + ry * (ph - 12) + Math.cos(t * 2 + a) * 2, 2.8, 0, 7); g.fill(); }
      if (stg >= 3) T(g, `${sig(conc)} M`, px + pw / 2, py + ph + 16, col, { b: true, s: 12, c: col.acc });
      const lab = ['১. ওজন নাও', '২. স্থানান্তর', '৩. দ্রবীভূত করো', '৪. দাগ পর্যন্ত পূরণ', '৫. ঝাঁকিয়ে সমসত্ত্ব করো ✓'][stg]; T(g, lab, wd ? W * 0.12 : W * 0.22, 18, col, { b: true, s: 11, c: '#2f9e44' });
    };
    const info = () => { const s = SOL[si], n = m / s[2], conc = M(), tg = +q('[data-tg]').value || 0.1, need = tg * vol / 1000 * s[2]; q('[data-mv]').textContent = bn(m.toFixed(2)); out.innerHTML = `<div><b>মোলারিটি:</b> ${TXB(`M = \\dfrac{n}{V(\\text{L})} = \\dfrac{m}{M_r \\times V(\\text{L})}`)}</div><div class="small">n(${SUBN[s[0]]}) = ${bn(m.toFixed(2))} ÷ ${bn(s[2])} = ${sig(n)} mol; V = ${bn(vol)} mL = ${bn(vol / 1000)} L ⇒ <b>M = ${sig(n)} ÷ ${bn(vol / 1000)} = ${sig(conc)} mol L⁻¹</b>${conc >= 0.0995 && conc < 0.1005 ? ' (ডেসিমোলার)' : conc > 0.995 && conc < 1.005 ? ' (মোলার)' : ''}।</div><div class="small"><b>লক্ষ্য:</b> ${bn(vol)} mL ${bn(tg)} M দ্রবণের জন্য ভর = ${bn(tg)} × ${bn(vol / 1000)} × ${bn(s[2])} = <b>${sig(need, 4)} g</b>${s[0] === 'NaOH' ? ' — NaOH আর্দ্রতাগ্রাহী ও CO₂ শোষক, তাই এর দ্রবণ প্রমাণ দ্রবণ নয়; পরে টাইট্রেশনে প্রমিতকরণ করতে হয়।' : s[0] === 'CuSO4' || s[0] === 'H2C2O4' ? ' — কেলাস পানিসহ আণবিক ভর ব্যবহার করতে হবে।' : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.12); if (p >= 1) run = false; } } draw(); }, { paused: false });
    q('[data-s]').onchange = e => { si = +e.target.value; p = 1; info(); };
    q('[data-v]').onchange = e => { vol = +e.target.value; p = 1; info(); };
    q('[data-m]').oninput = e => { m = +e.target.value; p = 1; info(); };
    q('[data-tg]').oninput = info;
    q('[data-use]').onclick = () => { const tg = +q('[data-tg]').value || 0.1; m = Math.min(60, Math.max(0.05, +(tg * vol / 1000 * SOL[si][2]).toFixed(2))); q('[data-m]').value = m; p = 1; info(); };
    q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.৬ ঘনমাত্রার একক রূপান্তর ও ppm মই ======================= */
const CS = [
  ['NaCl', 58.5, 1.0], ['NaOH', 40, 1.0], ['HCl', 36.5, 1.19], ['H₂SO₄', 98, 1.84], ['HNO₃', 63, 1.42], ['NH₃', 17, 0.90], ['C₆H₁₂O₆ (গ্লুকোজ)', 180, 1.0], ['As (আর্সেনিক)', 74.9, 1.0], ['F⁻ (ফ্লোরাইড)', 19, 1.0], ['Pb (সিসা)', 207.2, 1.0]
];
const REF = [
  [0.01, 'WHO আর্সেনিক সীমা (১০ ppb)'], [0.05, 'বাংলাদেশ আর্সেনিক মান (৫০ ppb)'], [1.5, 'ফ্লোরাইড সীমা (১.৫ ppm)'], [420 * 1.8, ''], [9000, 'স্যালাইন ০.৯% NaCl'], [35000, 'সমুদ্রের পানি ~৩.৫% লবণ'], [440000, 'গাঢ় HCl ৩৭% (w/w)'], [1803200, 'গাঢ় H₂SO₄ ৯৮%']
].filter(r => r[1]);
V.p2c3_concConv = {
  t: 'ঘনমাত্রার একক রূপান্তর: মোলারিটি ⇄ শতকরা (w/v, w/w ঘনত্বসহ) ⇄ g/L ⇄ ppm ⇄ ppb — লগারিদমিক "ঘনমাত্রার মই" এ খাবার পানির আর্সেনিক থেকে গাঢ় সালফিউরিক এসিড পর্যন্ত', k: ['int', 'calc'],
  cap: 'দ্রব ও ইনপুটের একক বেছে মান লেখো; বাকি সব একক তাৎক্ষণিক হিসাব হয়। শতকরা (w/w) থেকে মোলারিটিতে যেতে দ্রবণের ঘনত্ব লাগে (গাঢ় এসিডের জন্য ঘনত্ব আগে থেকে বসানো)। নিচের লগ-স্কেলের মইয়ে প্রতিটি দাগ আগের দাগের ১০ গুণ — তোমার দ্রবণ কোথায় পড়ল দেখো এবং বাস্তব রেফারেন্সের সাথে তুলনা করো (WHO আর্সেনিক সীমা ১০ ppb, বাংলাদেশ মান ৫০ ppb, সমুদ্রের পানি ~৩.৫%)। লঘু জলীয় দ্রবণে ১ ppm ≈ ১ mg/L।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-s', CS.map((s, i) => [String(i), s[0]]), '0')}${SEL('data-u', [['M', 'মোলারিটি (M)'], ['wv', '% (w/v)'], ['ww', '% (w/w)'], ['gL', 'g/L'], ['ppm', 'ppm (mg/L)'], ['ppb', 'ppb (µg/L)']], 'M')}<input type="number" step="any" value="0.1" data-x style="width:110px;padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg)"><label class="small">ঘনত্ব <input type="number" step="0.01" min="0.5" max="2.5" value="1.00" data-d style="width:64px;padding:4px;border-radius:6px;border:1px solid var(--line);background:var(--surface);color:var(--fg)"> g/mL</label></div>${X.cv('ঘনমাত্রার মই')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 200 : 225;
    let L = X.fit(c, hf), si = 0, ppm = 5850;
    const get = () => { const s = CS[si], u = q('[data-u]').value, x = +q('[data-x]').value || 0, d = +q('[data-d]').value || 1; let gL; if (u === 'M') gL = x * s[1]; else if (u === 'wv') gL = x * 10; else if (u === 'ww') gL = x * d * 10; else if (u === 'gL') gL = x; else if (u === 'ppm') gL = x / 1000; else gL = x / 1e6; return { s, u, x, d, gL, M: gL / s[1], wv: gL / 10, ww: gL / (d * 10), ppm: gL * 1000, ppb: gL * 1e6 }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const r = get(), wd = wide(W);
      const x0 = 16, x1 = W - 16, y = wd ? H * 0.5 : 70, lo = -3, hi = 6.5; const X_ = v => x0 + (Math.log10(Math.max(v, 1e-3)) - lo) / (hi - lo) * (x1 - x0);
      const grd = g.createLinearGradient(x0, 0, x1, 0); grd.addColorStop(0, '#d0ebff'); grd.addColorStop(0.5, '#74c0fc'); grd.addColorStop(1, '#1864ab'); g.fillStyle = grd; g.fillRect(x0, y - 7, x1 - x0, 14);
      for (let e = lo; e <= 6; e++) { const xx = X_(10 ** e); g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(xx, y - 10); g.lineTo(xx, y + 10); g.stroke(); const lab = e < 0 ? `${bn(10 ** (e + 3))} ppb` : e < 4 ? `${bn(10 ** e)} ppm` : `${bn(10 ** (e - 4))}%`; if (wd || e % 2 === 1) T(g, lab, xx, y + 24, col, { s: 9, c: col.mu }); }
      if (!wd) { REF.forEach(([v, s], i) => { const xx = X_(v); g.fillStyle = col.mu; g.beginPath(); g.arc(xx, y, 7, 0, 7); g.fill(); T(g, bn(i + 1), xx, y + 3.5, col, { b: true, s: 9, c: col.sf }); T(g, `${bn(i + 1)}. ${s}`, 16 + (i % 2) * (W / 2), y + 50 + Math.floor(i / 2) * 15, col, { s: 9, a: 'left', c: col.mu }); }); }
      else REF.forEach(([v, s], i) => { const xx = X_(v); const up = i % 2 === 0, yy = up ? y - 22 : y + 46; g.strokeStyle = col.mu; g.setLineDash([2, 2]); g.beginPath(); g.moveTo(xx, up ? y - 8 : y + 8); g.lineTo(xx, up ? yy + 3 : yy - 10); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.beginPath(); g.arc(xx, y, 2.5, 0, 7); g.fill(); g.font = `9px ${col.font}`; const tw = g.measureText(s).width; T(g, s, Math.min(x1 - tw / 2, Math.max(x0 + tw / 2, xx)), yy, col, { s: 9, c: col.mu }); });
      const xx = X_(r.ppm); g.fillStyle = '#e8590c'; g.beginPath(); g.moveTo(xx, y - 9); g.lineTo(xx - 8, y - 22); g.lineTo(xx + 8, y - 22); g.closePath(); g.fill(); g.beginPath(); g.moveTo(xx, y + 9); g.lineTo(xx - 8, y + 22); g.lineTo(xx + 8, y + 22); g.closePath(); g.fill();
      T(g, `তোমার দ্রবণ: ${sig(r.ppm)} ppm`, W / 2, 16, col, { b: true, s: 11.5, c: '#e8590c' });
      T(g, 'প্রতি দাগ = ১০ গুণ (লগ স্কেল)', W / 2, H - 6, col, { s: 9, c: col.mu });
    };
    const info = () => { const r = get(); const ser = r.s[0].includes('As') ? (r.ppm > 0.05 ? '⚠️ বাংলাদেশের খাবার পানির মান (০.০৫ mg/L) অতিক্রম করেছে।' : r.ppm > 0.01 ? '⚠️ WHO সীমা (০.০১ mg/L) অতিক্রম করেছে, তবে বাংলাদেশ মানের মধ্যে।' : '✓ WHO সীমার মধ্যে।') : r.s[0].includes('F⁻') ? (r.ppm > 1.5 ? '⚠️ WHO ফ্লোরাইড সীমা (১.৫ mg/L) অতিক্রম — দাঁত/হাড়ের ফ্লোরোসিস ঝুঁকি।' : '') : r.s[0].includes('Pb') ? (r.ppm > 0.01 ? '⚠️ WHO সিসা নির্দেশিকা (০.০১ mg/L) অতিক্রম।' : '') : '';
      out.innerHTML = `<div class="table-wrap"><table class="t"><thead><tr><th>মোলারিটি</th><th>g/L</th><th>% (w/v)</th><th>% (w/w)</th><th>ppm (mg/L)</th><th>ppb (µg/L)</th></tr></thead><tbody><tr><td><b>${sig(r.M)} M</b></td><td>${sig(r.gL)}</td><td>${sig(r.wv)}%</td><td>${sig(r.ww)}%</td><td>${sig(r.ppm)}</td><td>${sig(r.ppb)}</td></tr></tbody></table></div><div class="small">সূত্র: g/L = M × Mᵣ (${bn(r.s[1])}); % (w/v) = g/L ÷ ১০; M = % (w/w) × ঘনত্ব × ১০ ÷ Mᵣ; ppm = g/L × ১০০০ = M × Mᵣ × ১০০০।${r.d !== 1 ? ` এখানে ঘনত্ব ${bn(r.d)} g/mL।` : ''}</div>${ser ? `<div class="small"><b>${ser}</b></div>` : ''}`; draw(); };
    q('[data-s]').onchange = e => { si = +e.target.value; q('[data-d]').value = CS[si][2].toFixed(2); if (CS[si][2] > 1.05 || CS[si][2] < 0.95) { q('[data-u]').value = 'ww'; q('[data-x]').value = { 'HCl': 37, 'H₂SO₄': 98, 'HNO₃': 70, 'NH₃': 28 }[CS[si][0]] || 10; } else if (/As|F⁻|Pb/.test(CS[si][0])) { q('[data-u]').value = 'ppb'; q('[data-x]').value = 50; } info(); };
    ['[data-u]', '[data-x]', '[data-d]'].forEach(s => q(s).oninput = info); q('[data-u]').onchange = info;
    info();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৩.৭ ব্যবহারিক: লঘুকরণ ও ধারাবাহিক লঘুকরণ ======================= */
V.p2c3_dilution = {
  t: 'ব্যবহারিক — দ্রবণের লঘুকরণ: পিপেট দিয়ে স্টক দ্রবণ নিয়ে আয়তনিক ফ্লাস্কে দাগ পর্যন্ত পাতিত পানি যোগ (C₁V₁ = C₂V₂); ধারাবাহিক (১:১০) লঘুকরণে KMnO₄ দ্রবণের রঙের পরিবর্তন', k: ['anim', 'int', 'calc', 'lab'],
  cap: '"একক লঘুকরণ" মোডে স্টক KMnO₄ দ্রবণের ঘনমাত্রা, পিপেটের আয়তন (V₁) ও ফ্লাস্কের আয়তন (V₂) বেছে "লঘু করো" চাপো — পিপেট স্টক থেকে দ্রবণ টেনে ফ্লাস্কে ঢালে, তারপর দাগ পর্যন্ত পানি যোগ হয়। দ্রবের মোল অপরিবর্তিত থাকে (C₁V₁ = C₂V₂), তাই রং হালকা হয়। "লক্ষ্য" ঘনমাত্রা দিলে প্রয়োজনীয় V₁ হিসাব হয়। "ধারাবাহিক লঘুকরণ" মোডে প্রতিটি টেস্টটিউবে আগেরটি থেকে ১ mL + ৯ mL পানি — প্রতি ধাপে ঘনমাত্রা ১০ ভাগের ১ ভাগ; রং বিয়ার-ল্যাম্বার্ট সূত্র অনুযায়ী (শোষণ ∝ ঘনমাত্রা) হালকা হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap"><button class="btn sm primary" data-md="0">একক লঘুকরণ</button><button class="btn sm" data-md="1">ধারাবাহিক লঘুকরণ</button><button class="btn sm" data-go>▶ লঘু করো</button></div>${X.cv('লঘুকরণ')}<div class="ctl" style="flex-wrap:wrap" data-c1>${SEL('data-c', [['0.02', 'স্টক ০.০২ M'], ['0.01', 'স্টক ০.০১ M'], ['0.005', 'স্টক ০.০০৫ M'], ['0.002', 'স্টক ০.০০২ M']], '0.02')}${SEL('data-v1', [['5', 'পিপেট ৫ mL'], ['10', 'পিপেট ১০ mL'], ['20', 'পিপেট ২০ mL'], ['25', 'পিপেট ২৫ mL'], ['50', 'পিপেট ৫০ mL']], '10')}${SEL('data-v2', [['100', 'ফ্লাস্ক ১০০ mL'], ['250', 'ফ্লাস্ক ২৫০ mL'], ['500', 'ফ্লাস্ক ৫০০ mL']], '100')}<label class="small">লক্ষ্য C₂ (M) <input type="number" step="0.0001" value="0.001" data-tg style="width:80px;padding:4px;border-radius:6px;border:1px solid var(--line);background:var(--surface);color:var(--fg)"></label></div><ol class="steps small" data-st style="margin:6px 0"></ol><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), stl = q('[data-st]');
    const hf = w => wide(w) ? 300 : 360;
    let L = X.fit(c, hf), md = 0, C1 = 0.02, V1 = 10, V2 = 100, p = 1, run = false, t = 0;
    const COLR = '#8e24aa', alphaOf = (cM, path) => Math.min(0.95, 1 - Math.pow(10, -2400 * cM * path)); // ε ≈ 2400 L mol⁻¹ cm⁻¹ at 525 nm
    const STEPS = [['স্টক দ্রবণ দিয়ে পিপেট ও বিকার ধুয়ে নাও (rinsing)।', 0], ['পিপেট-ফিলার দিয়ে দাগ পর্যন্ত স্টক দ্রবণ টেনে নাও — মেনিস্কাসের তলা দাগে।', 0.25], ['পিপেটের দ্রবণ পরিষ্কার আয়তনিক ফ্লাস্কে ঢালো; শেষ ফোঁটা ফুঁ দিয়ে বের করবে না।', 0.5], ['পাতিত পানি দিয়ে দাগ পর্যন্ত পূরণ করো (শেষে ড্রপার)।', 0.75], ['ছিপি লাগিয়ে উল্টে-পাল্টে ঝাঁকিয়ে সমসত্ত্ব করো ও লেবেল দাও।', 1]];
    const SER = ['এক সারিতে ৫টি পরিষ্কার টেস্টটিউবে ৯ mL করে পাতিত পানি নাও।', 'স্টক দ্রবণ থেকে ১ mL প্রথম টিউবে দাও ও ঝাঁকাও (১:১০)।', 'প্রথম টিউব থেকে ১ mL দ্বিতীয় টিউবে — এভাবে পরপর।', 'প্রতি ধাপে নতুন পিপেট টিপ ব্যবহার করো।', 'রঙ তুলনা করো: ঘনমাত্রা ১০⁻¹, ১০⁻², ... গুণ।'];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      if (md === 0) {
        const C2 = C1 * V1 / V2; const sx = wd ? W * 0.15 : W * 0.2, sy = H - 30; const bw = wd ? 70 : 56, bh = wd ? 80 : 70;
        // stock beaker
        const pull = p < 0.25 ? p / 0.25 : 1; g.fillStyle = rgba(COLR, alphaOf(C1, 0.6)); g.fillRect(sx - bw / 2 + 2, sy - bh * 0.7 + bh * 0.05 * pull, bw - 4, bh * 0.7 - bh * 0.05 * pull); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(sx - bw / 2, sy - bh); g.lineTo(sx - bw / 2, sy); g.lineTo(sx + bw / 2, sy); g.lineTo(sx + bw / 2, sy - bh); g.stroke(); T(g, `স্টক ${sig(C1)} M`, sx, sy + 14, col, { b: true, s: 10 });
        // flask
        const fx = wd ? W * 0.55 : W * 0.68, ft = 34, fH = H - 70; const lvl = p < 0.5 ? 0 : p < 0.75 ? (V1 / V2) * (p - 0.5) / 0.25 : (V1 / V2) + (1 - V1 / V2) * Math.min(1, (p - 0.75) / 0.25); const nIn = p < 0.5 ? 0 : Math.min(1, (p - 0.5) / 0.25); const cf = lvl > 0 ? C1 * V1 * nIn / (V2 * lvl) : 0;
        const G = flask(g, col, fx, ft, fH, Math.max(0.0001, lvl), COLR, alphaOf(cf, 0.6) * (lvl > 0 ? 1 : 0), `${bn(V2)} mL ফ্লাস্ক`);
        // pipette
        const ph2 = fH * 0.75, pxp = p < 0.25 ? sx : p < 0.5 ? sx + (fx - sx) * (p - 0.25) / 0.25 : p < 0.75 ? fx : fx + (W - fx) * 0.6 * Math.min(1, (p - 0.75) / 0.1); const pyTop = p < 0.25 ? sy - bh * 0.6 - ph2 : 10; const fillP = p < 0.25 ? pull : p < 0.5 ? 1 : p < 0.75 ? 1 - (p - 0.5) / 0.25 : 0;
        if (p < 0.85) { g.strokeStyle = col.fg; g.lineWidth = 1.3; const bx = pxp, bulbY = pyTop + ph2 * 0.45; g.beginPath(); g.moveTo(bx - 2, pyTop); g.lineTo(bx - 2, bulbY - 18); g.moveTo(bx + 2, pyTop); g.lineTo(bx + 2, bulbY - 18); g.stroke(); g.beginPath(); g.ellipse(bx, bulbY, 7, 18, 0, 0, 7); g.stroke(); g.beginPath(); g.moveTo(bx - 2, bulbY + 18); g.lineTo(bx - 1, pyTop + ph2); g.moveTo(bx + 2, bulbY + 18); g.lineTo(bx + 1, pyTop + ph2); g.stroke(); if (fillP > 0) { g.fillStyle = rgba(COLR, alphaOf(C1, 0.6)); g.beginPath(); g.ellipse(bx, bulbY, 6, 17 * Math.min(1, fillP * 1.2), 0, 0, 7); g.fill(); g.fillRect(bx - 1.5, bulbY + 17, 3, (pyTop + ph2 - bulbY - 17)); g.fillRect(bx - 1.5, bulbY - 17 - (bulbY - 17 - pyTop - 20) * Math.max(0, fillP - 0.8) / 0.2, 3, (bulbY - 17 - pyTop - 20) * Math.max(0, fillP - 0.8) / 0.2); } g.strokeStyle = '#e03131'; g.beginPath(); g.moveTo(bx - 5, pyTop + 20); g.lineTo(bx + 5, pyTop + 20); g.stroke(); T(g, `${bn(V1)} mL পিপেট`, bx + 12, pyTop + 12, col, { s: 9, c: col.mu, a: 'left' }); }
        if (p >= 0.75 && p < 1) { const u = (t * 3) % 1; g.strokeStyle = 'rgba(120,170,230,.85)'; g.lineWidth = 3; g.beginPath(); g.moveTo(fx, ft - 26); g.lineTo(fx, ft - 4 + u * 4); g.stroke(); T(g, 'পাতিত পানি', fx + 14, ft - 18, col, { s: 9, c: col.mu, a: 'left' }); }
        if (p >= 1) { T(g, `C₂ = ${sig(C2)} M`, fx, G.bottom + 28, col, { b: true, s: 12, c: col.acc }); if (wd) { T(g, `${sig(C1)} × ${bn(V1)} = ${sig(C2)} × ${bn(V2)}`, W * 0.85, H / 2 - 10, col, { b: true, s: 11 }); T(g, `দ্রবের মোল: ${sig(C1 * V1 / 1000)} mol (অপরিবর্তিত)`, W * 0.85, H / 2 + 10, col, { s: 9.5, c: col.mu }); T(g, `লঘুকরণ গুণক = ${bn(V2 / V1)}`, W * 0.85, H / 2 + 28, col, { s: 9.5, c: col.mu }); } }
      } else {
        const n = 6, gap = (W - 30) / n, ty = 40, th = H - 110; const conc = i => C1 * 10 ** -i; const shown = run ? Math.floor(p * n * 1.0001) : n;
        for (let i = 0; i < n; i++) { const x = 15 + gap * (i + 0.5), w = Math.min(34, gap * 0.45); const filled = i === 0 || i < shown; g.save(); g.beginPath(); g.moveTo(x - w / 2, ty); g.lineTo(x - w / 2, ty + th - w / 2); g.arc(x, ty + th - w / 2, w / 2, Math.PI, 0, true); g.lineTo(x + w / 2, ty); g.clip(); g.fillStyle = filled ? rgba(COLR, Math.max(0.02, alphaOf(conc(i), 1.5))) : 'rgba(120,170,230,.18)'; g.fillRect(x - w / 2, ty + th * 0.25, w, th); g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.4; g.beginPath(); g.moveTo(x - w / 2, ty); g.lineTo(x - w / 2, ty + th - w / 2); g.arc(x, ty + th - w / 2, w / 2, Math.PI, 0, true); g.lineTo(x + w / 2, ty); g.stroke(); T(g, i === 0 ? 'স্টক' : `${bn(i)}`, x, ty - 8, col, { b: true, s: 10 }); T(g, sig(conc(i), 2), x, ty + th + 16, col, { s: wd ? 10 : 8.5, b: true }); T(g, 'M', x, ty + th + 28, col, { s: 8.5, c: col.mu }); if (i > 0 && i < shown && wd) { g.strokeStyle = col.acc; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x - gap + w / 2 + 2, ty + 10); g.quadraticCurveTo(x - gap / 2, ty - 18, x - w / 2 - 2, ty + 10); g.stroke(); T(g, '১ mL', x - gap / 2, ty - 14, col, { s: 8.5, c: col.acc }); } }
        T(g, 'প্রতি টিউব: ১ mL আগের দ্রবণ + ৯ mL পানি  ⇒  ঘনমাত্রা ÷ ১০', W / 2, H - 8, col, { s: 9.5, c: col.mu });
      }
    };
    const steps = () => { const list = md ? SER : STEPS.map(s => s[0]); const cur = md ? -1 : STEPS.findIndex(s => p <= s[1] + 1e-9); stl.innerHTML = list.map((s, i) => `<li style="${i === cur && run ? 'font-weight:700;color:var(--accent)' : ''}">${s}</li>`).join(''); };
    const info = () => { const C2 = C1 * V1 / V2, tg = +q('[data-tg]').value || 0.001, need = tg * V2 / C1; q('[data-c1]').querySelectorAll('[data-v1],[data-v2],[data-tg]').forEach(e => { const lb = e.closest('label'); (lb || e).style.display = md ? 'none' : ''; });
      out.innerHTML = md ? `<div>${TXB(`C_n = C_0 \\times \\left(\\dfrac{1}{10}\\right)^n`)}</div><div class="small">স্টক ${sig(C1)} M থেকে ৫ ধাপ পরে ${sig(C1 * 1e-5)} M — মোট লঘুকরণ গুণক ১০⁵। এভাবে খুব লঘু দ্রবণ (যেমন বিয়ার-ল্যাম্বার্ট প্রমাণ রেখার দ্রবণ) নির্ভুলভাবে তৈরি করা যায়, যা সরাসরি ওজন করে সম্ভব নয়।</div>` : `<div>${TXB(`C_1V_1 = C_2V_2 \\;\\Rightarrow\\; C_2 = \\dfrac{${C1} \\times ${V1}}{${V2}} = ${+C2.toPrecision(3)}\\ \\text{M}`)}</div><div class="small">লক্ষ্য ${bn(tg)} M দ্রবণ ${bn(V2)} mL তৈরিতে V₁ = C₂V₂/C₁ = ${bn(tg)} × ${bn(V2)} ÷ ${sig(C1)} = <b>${sig(need)} mL</b> স্টক${need > V2 ? ' — স্টকের চেয়ে বেশি ঘন দ্রবণ লঘুকরণে তৈরি সম্ভব নয়!' : ''}।</div>`; steps(); };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * (md ? 0.2 : 0.12)); if (p >= 1) run = false; steps(); } } draw(); }, { paused: false });
    el.querySelectorAll('[data-md]').forEach(b => b.onclick = () => { md = +b.dataset.md; el.querySelectorAll('[data-md]').forEach(x => x.classList.toggle('primary', x === b)); p = 1; run = false; info(); });
    q('[data-c]').onchange = e => { C1 = +e.target.value; p = 1; info(); }; q('[data-v1]').onchange = e => { V1 = +e.target.value; p = 1; info(); }; q('[data-v2]').onchange = e => { V2 = +e.target.value; p = 1; info(); }; q('[data-tg]').oninput = info;
    q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
