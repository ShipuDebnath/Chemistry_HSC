/* ২য় পত্র অধ্যায় ৩ visuals part 6 — 3.11 indicators (colour ranges, HIn equilibrium, choosing an indicator against titration curves); 3.12 plant-juice indicators practical */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit;max-width:100%">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const hex2 = h => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const mix = (a, b, u, al = 1) => { const A = a ? hex2(a) : null, B = b ? hex2(b) : null; if (!A && !B) return 'rgba(230,240,250,.25)'; if (!A) return `rgba(${B.join(',')},${(al * u).toFixed(3)})`; if (!B) return `rgba(${A.join(',')},${(al * (1 - u)).toFixed(3)})`; return `rgba(${A.map((v, i) => Math.round(v + (B[i] - v) * u)).join(',')},${al})`; };
const sstep = u => { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); };
const tube = (g, col, x, y, w, h, fill) => { g.save(); g.beginPath(); g.moveTo(x - w / 2, y); g.lineTo(x - w / 2, y + h - w / 2); g.arc(x, y + h - w / 2, w / 2, Math.PI, 0, true); g.lineTo(x + w / 2, y); g.clip(); g.fillStyle = fill; g.fillRect(x - w / 2, y + h * 0.3, w, h); g.fillStyle = 'rgba(255,255,255,.22)'; g.fillRect(x - w / 2 + 3, y + h * 0.3, w * 0.18, h * 0.65); g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.3; g.beginPath(); g.moveTo(x - w / 2, y); g.lineTo(x - w / 2, y + h - w / 2); g.arc(x, y + h - w / 2, w / 2, Math.PI, 0, true); g.lineTo(x + w / 2, y); g.stroke(); };

/* ======================= ৩.১১ নির্দেশক ======================= */
// [key, name, lo, hi, acidColour, baseColour, pKIn, type]
const IND = [
  ['MO', 'মিথাইল অরেঞ্জ', 3.1, 4.4, '#e03131', '#fab005', 3.7, 'অ্যাজো রঞ্জক (মৃদু ক্ষারক)'],
  ['MR', 'মিথাইল রেড', 4.4, 6.2, '#e03131', '#fcc419', 5.1, 'অ্যাজো রঞ্জক'],
  ['LT', 'লিটমাস', 5.0, 8.0, '#d6336c', '#3b5bdb', 6.5, 'প্রাকৃতিক (লাইকেন থেকে)'],
  ['BTB', 'ব্রোমোথাইমল ব্লু', 6.0, 7.6, '#fab005', '#1c7ed6', 7.1, 'সালফোনথ্যালিন'],
  ['PP', 'ফেনলফথ্যালিন', 8.2, 10.0, null, '#e64980', 9.3, 'থ্যালিন (মৃদু এসিড)'],
  ['TP', 'থাইমলফথ্যালিন', 9.3, 10.5, null, '#1971c2', 9.9, 'থ্যালিন']
];
const indCol = (I, pH, al = 0.85) => mix(I[4], I[5], sstep((pH - I[2]) / (I[3] - I[2])), al);
const Kw = 1e-14;
const curve = (type, v) => { // 25 mL 0.1 M titrand, 0.1 M titrant
  const Ca = 0.1, Va = 25, Cb = 0.1, Vt = Va + v, a = Ca * Va, b = Cb * v; const sp = d => { const h = (d + Math.sqrt(d * d + 4 * Kw)) / 2; return -Math.log10(h); };
  if (type === 0) return sp((a - b) / Vt);
  if (type === 1) { const Ka = 1.8e-5; if (b < 1e-9) return -Math.log10(Math.sqrt(Ka * a / Vt)); if (b < a - 1e-6) return -Math.log10(Ka) + Math.log10(b / (a - b)); if (Math.abs(b - a) < 1e-6) return 14 + Math.log10(Math.sqrt(Kw / Ka * a / Vt)); return sp((a - b) / Vt); }
  const Kb = 1.8e-5; if (b < a - 1e-6) return sp((a - b) / Vt); if (Math.abs(b - a) < 1e-6) return -Math.log10(Math.sqrt(Kw / Kb * a / Vt)); return 14 + Math.log10(Kb) - Math.log10(a / (b - a));
};
const TT = ['HCl (তীব্র) + NaOH (তীব্র)', 'CH₃COOH (মৃদু) + NaOH (তীব্র)', 'HCl (তীব্র) + NH₃ (মৃদু)'];
V.p2c3_indicator = {
  t: 'এসিড-ক্ষার নির্দেশক: বর্ণ পরিবর্তনের পরিসর, HIn ⇌ H⁺ + In⁻ সাম্যাবস্থা ও [In⁻]/[HIn] অনুপাত, এবং টাইট্রেশন বক্ররেখার খাড়া অংশের সাথে মিলিয়ে উপযুক্ত নির্দেশক বাছাই', k: ['int', 'plot'],
  cap: 'উপরে pH স্লাইডার সরাও — ছয়টি নির্দেশকের টেস্টটিউবের রং একসাথে বদলায়, আর বেছে নেওয়া নির্দেশকের জন্য অম্লীয় রূপ (HIn) ও ক্ষারীয় রূপ (In⁻) এর অনুপাত দণ্ডে দেখানো হয়। নির্দেশকের রং মোটামুটি pH = pK_In ± ১ পরিসরে বদলায় (যখন [In⁻]/[HIn] অনুপাত ০.১ থেকে ১০)। নিচের লেখচিত্রে টাইট্রেশনের ধরন বেছে নাও: রঙিন পট্টিগুলো প্রতিটি নির্দেশকের পরিসর। যে নির্দেশকের পট্টি বক্ররেখার প্রায়-খাড়া অংশের (প্রশমন বিন্দুর চারপাশে) মধ্যে পড়ে, সেটিই উপযুক্ত — সবুজ টিক চিহ্ন দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap"><label class="small" style="flex:2;min-width:180px">pH = <b data-pv></b><input type="range" min="0" max="14" step="0.05" value="7" data-p></label>${SEL('data-i', IND.map((s, i) => [String(i), s[1]]), '4')}${SEL('data-t', TT.map((s, i) => [String(i), s]), '0')}</div>${X.cv('নির্দেশক')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 420 : 600;
    let L = X.fit(c, hf), pH = 7, ii = 4, tt = 0;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W);
      // tubes
      const n = IND.length, tw = wd ? 26 : 22, gap = (wd ? W * 0.62 : W) / n; IND.forEach((I, i) => { const x = gap * (i + 0.5), y = 14, h = wd ? 110 : 96; tube(g, col, x, y, tw, h, indCol(I, pH)); g.strokeStyle = i === ii ? col.acc : 'transparent'; g.lineWidth = 2.5; g.strokeRect(x - tw / 2 - 5, y - 5, tw + 10, h + 10); T(g, I[1], x, y + h + 16, col, { s: wd ? 9.5 : 8, b: i === ii }); T(g, `${bn(I[2])}–${bn(I[3])}`, x, y + h + 29, col, { s: 8.5, c: col.mu }); });
      // ratio bar for selected
      const I = IND[ii], rx = wd ? W * 0.66 : 14, ry = wd ? 24 : 170, rw = wd ? W * 0.31 : W - 28; const fr = 1 / (1 + Math.pow(10, I[6] - pH)); T(g, `${I[1]}: HIn ⇌ H⁺ + In⁻ (pK_In ≈ ${bn(I[6])})`, rx + rw / 2, ry, col, { b: true, s: 10 }); g.fillStyle = I[4] || col.s3; g.fillRect(rx, ry + 10, rw * (1 - fr), 22); g.fillStyle = I[5]; g.fillRect(rx + rw * (1 - fr), ry + 10, rw * fr, 22); g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(rx, ry + 10, rw, 22); T(g, `HIn ${bn(Math.round((1 - fr) * 100))}%`, rx + 4, ry + 46, col, { s: 9.5, a: 'left' }); T(g, `In⁻ ${bn(Math.round(fr * 100))}%`, rx + rw - 4, ry + 46, col, { s: 9.5, a: 'right' }); const ratio = fr / (1 - fr); T(g, `[In⁻]/[HIn] = ${ratio > 999 ? '> ১০০০' : ratio < 0.001 ? '< ০.০০১' : bn(+ratio.toPrecision(2))}`, rx + rw / 2, ry + 62, col, { s: 10, b: true, c: col.acc }); T(g, ratio < 0.1 ? `অম্লীয় রং প্রাধান্য (${I[4] ? 'HIn' : 'বর্ণহীন'})` : ratio > 10 ? 'ক্ষারীয় রং প্রাধান্য (In⁻)' : 'মিশ্র রং — পরিবর্তনের পরিসরে', rx + rw / 2, ry + 78, col, { s: 9.5, c: col.mu });
      // titration curve with bands
      const gx = wd ? 46 : 36, gy = wd ? 190 : 270, gw = W - gx - 16, gh = H - gy - 34; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(gx, gy, gw, gh); const Y = p => gy + gh * (1 - p / 14), Xv = v => gx + v / 50 * gw;
      IND.forEach((J, j) => { const y1 = Y(J[3]), y2 = Y(J[2]); const steepLo = tt === 0 ? 3 : tt === 1 ? 7.5 : 3, steepHi = tt === 0 ? 10.5 : tt === 1 ? 10.5 : 6.6; const ok = J[2] >= steepLo - 0.05 && J[3] <= steepHi + 0.05; const bx = gx + gw - (n - j) * (wd ? 24 : 18); g.fillStyle = mix(J[4] || '#dee2e6', J[5], 0.5, j === ii ? 0.45 : 0.18); g.fillRect(gx, y1, gw, y2 - y1); g.fillStyle = mix(J[4] || '#dee2e6', J[5], 0.5, 0.9); g.fillRect(bx, y1, wd ? 18 : 13, y2 - y1); if (ok) T(g, '✓', bx + (wd ? 9 : 6.5), y1 - 3, col, { b: true, s: 11, c: '#2f9e44' }); });
      g.beginPath(); for (let i = 0; i <= 500; i++) { const v = i / 10, p = curve(tt, v); const x = Xv(v), y = Y(p); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.strokeStyle = col.fg; g.lineWidth = 2.2; g.stroke();
      g.setLineDash([3, 3]); g.strokeStyle = '#e8590c'; g.beginPath(); g.moveTo(Xv(25), gy); g.lineTo(Xv(25), gy + gh); g.stroke(); g.setLineDash([]); T(g, 'প্রশমন বিন্দু', Xv(25) + 4, gy + 12, col, { s: 9, a: 'left', c: '#e8590c' });
      g.strokeStyle = col.acc; g.lineWidth = 1; g.setLineDash([2, 2]); g.beginPath(); g.moveTo(gx, Y(pH)); g.lineTo(gx + gw, Y(pH)); g.stroke(); g.setLineDash([]);
      [0, 2, 4, 6, 8, 10, 12, 14].forEach(v => T(g, bn(v), gx - 8, Y(v) + 3, col, { s: 8.5, c: col.mu, a: 'right' })); T(g, 'pH', gx - 8, gy - 4, col, { s: 9, c: col.mu, a: 'right' }); [0, 10, 20, 30, 40, 50].forEach(v => T(g, bn(v), Xv(v), gy + gh + 12, col, { s: 8.5, c: col.mu })); T(g, `${TT[tt]} — টাইট্রেন্টের আয়তন (mL), ২৫ mL ০.১ M`, gx + gw / 2, gy + gh + 26, col, { s: 9, c: col.mu });
    };
    const info = () => { const I = IND[ii]; q('[data-pv]').textContent = bn(pH.toFixed(2)); const good = [['PP বা MO যেকোনো (খাড়া অংশ pH ~৪–১০)'], ['ফেনলফথ্যালিন (খাড়া অংশ pH ~৭.৫–১০.৫; প্রশমন বিন্দু ~৮.৭)'], ['মিথাইল অরেঞ্জ বা মিথাইল রেড (খাড়া অংশ pH ~৩.৫–৬.৫; প্রশমন বিন্দু ~৫.৩)']][tt][0]; out.innerHTML = `<div class="small"><b>${I[1]}</b> (${I[7]}): অম্লীয় মাধ্যমে ${I[4] ? 'রঙিন' : 'বর্ণহীন'}, ক্ষারীয়তে রঙিন; পরিসর pH ${bn(I[2])}–${bn(I[3])}।</div><div>${TXB(`\\mathrm{pH} = \\mathrm{p}K_{\\text{In}} + \\log\\dfrac{[\\text{In}^-]}{[\\text{HIn}]}`)}</div><div class="small"><b>${TT[tt]}:</b> উপযুক্ত নির্দেশক — ${good}।</div>`; draw(); };
    q('[data-p]').oninput = e => { pH = +e.target.value; info(); }; q('[data-i]').onchange = e => { ii = +e.target.value; info(); }; q('[data-t]').onchange = e => { tt = +e.target.value; info(); };
    info();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৩.১২ ব্যবহারিক: রঙিন উদ্ভিদের রস ======================= */
// colour stops [pH, hex]
const PJ = [
  ['cab', 'লাল বাঁধাকপি (অ্যান্থোসায়ানিন)', [[1, '#c2185b'], [3, '#d81b60'], [5, '#8e24aa'], [7, '#5e35b1'], [8, '#1e88e5'], [10, '#00897b'], [12, '#7cb342'], [13.5, '#fdd835']]],
  ['hib', 'জবা ফুল (অ্যান্থোসায়ানিন)', [[1, '#d50032'], [3, '#e91e63'], [5.5, '#c2185b'], [7, '#8e44ad'], [8.5, '#5c6bc0'], [10, '#2e7d32'], [13, '#827717']]],
  ['tur', 'হলুদ (কারকিউমিন)', [[1, '#fbc02d'], [7.4, '#fbc02d'], [8.6, '#f57f17'], [10, '#bf360c'], [13, '#8d1b0c']]],
  ['bet', 'বিটমূল (বিটানিন)', [[1, '#ad1457'], [8, '#ad1457'], [10, '#8e24aa'], [11.5, '#6d4c41'], [13, '#fbc02d']]]
];
const pjCol = (P, pH, al = 0.85) => { const s = P[2]; if (pH <= s[0][0]) return mix(s[0][1], s[0][1], 0, al); for (let i = 0; i < s.length - 1; i++) if (pH <= s[i + 1][0]) return mix(s[i][1], s[i + 1][1], (pH - s[i][0]) / (s[i + 1][0] - s[i][0]), al); return mix(s[s.length - 1][1], s[s.length - 1][1], 0, al); };
const HH = [['লেবুর রস', 2.2], ['ভিনেগার', 2.9], ['সোডা পানি', 4.5], ['বৃষ্টির পানি', 5.6], ['ট্যাপের পানি', 7.0], ['খাবার সোডা দ্রবণ', 8.3], ['সাবান পানি', 10], ['চুন পানি', 12.4], ['০.১ M NaOH', 13]];
V.p2c3_plantJuice = {
  t: 'ব্যবহারিক — রঙিন উদ্ভিদের রস নির্দেশক হিসেবে: লাল বাঁধাকপি, জবা ফুল, হলুদ ও বিটমূলের রস দিয়ে গৃহস্থালি দ্রবণের pH আন্দাজ এবং HCl-NaOH প্রশমন বিন্দু নির্ণয়', k: ['anim', 'int', 'lab'],
  cap: '"রঙের তালিকা" মোডে রস বেছে নাও — নয়টি গৃহস্থালি দ্রবণে (লেবুর রস থেকে NaOH) রসের রং এবং নিচে পুরো pH স্কেলে রঙের পট্টি দেখা যায়। লাল বাঁধাকপি ও জবার অ্যান্থোসায়ানিন প্রায় পুরো স্কেলে রং বদলায় (লাল → বেগুনি → নীল → সবুজ → হলুদ), আর হলুদের কারকিউমিন কেবল pH ~৮ এর উপরে হলুদ থেকে লালচে-বাদামি হয়। "টাইট্রেশন" মোডে কনিক্যাল ফ্লাস্কে ২০ mL ০.১ M HCl ও কয়েক ফোঁটা রস; বুরেট থেকে ০.১ M NaOH যোগ করতে স্লাইডার সরাও — প্রশমন বিন্দুর কাছে হঠাৎ রং বদলায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap"><button class="btn sm primary" data-md="0">রঙের তালিকা</button><button class="btn sm" data-md="1">টাইট্রেশন</button>${SEL('data-j', PJ.map((s, i) => [String(i), s[1]]), '0')}</div>${X.cv('উদ্ভিদ নির্দেশক')}<div class="ctl" data-tc style="display:none"><label class="small" style="flex:1">যোগ করা NaOH = <b data-vv></b> mL<input type="range" min="0" max="35" step="0.05" value="0" data-v></label></div><ol class="steps small" style="margin:6px 0"><li>লাল বাঁধাকপি/জবা ফুলের পাপড়ি কুচি করে গরম পাতিত পানিতে ১০ মিনিট ভিজিয়ে রাখো (হলুদ হলে ইথানলে গুলিয়ে নাও)।</li><li>ছেঁকে স্বচ্ছ রঙিন নির্যাস সংগ্রহ করো — এটিই নির্দেশক।</li><li>প্রতিটি টেস্টটিউবে ৫ mL নমুনা নিয়ে ৫–৬ ফোঁটা নির্যাস যোগ করে রং লিপিবদ্ধ করো।</li><li>প্রশমন বিন্দু নির্ণয়ে ২০ mL ০.১ M HCl এ ১ mL নির্যাস দিয়ে বুরেট থেকে ০.১ M NaOH যোগ করো; রং হঠাৎ বদলালে পাঠ নাও।</li></ol><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 380;
    let L = X.fit(c, hf), md = 0, ji = 0, v = 0, t = 0;
    const pHt = vv => { const a = 0.1 * 20, b = 0.1 * vv, Vt = 20 + vv, d = (a - b) / Vt, h = (d + Math.sqrt(d * d + 4e-14)) / 2; return -Math.log10(h); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const P = PJ[ji], wd = wide(W);
      if (md === 0) {
        const n = HH.length, gap = W / n, tw = Math.min(26, gap * 0.55), th = wd ? 130 : 110; HH.forEach(([nm, p], i) => { const x = gap * (i + 0.5); tube(g, col, x, 20, tw, th, pjCol(P, p)); T(g, `pH ${bn(p)}`, x, 20 + th + 14, col, { s: wd ? 9.5 : 8, b: true }); const words = nm.split(' '); words.forEach((w, k) => T(g, w, x, 20 + th + 27 + k * 11, col, { s: wd ? 9 : 7.5, c: col.mu })); });
        const by = H - 40, bx = 14, bw = W - 28; for (let i = 0; i < bw; i++) { g.fillStyle = pjCol(P, 1 + 13 * i / bw, 1); g.fillRect(bx + i, by, 1.2, 16); } g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(bx, by, bw, 16); for (let p = 1; p <= 14; p += wd ? 1 : 2) T(g, bn(p), bx + (p - 1) / 13 * bw, by + 28, col, { s: 8.5, c: col.mu });
      } else {
        const fx = wd ? W * 0.3 : W * 0.5, fy = H - 30, pH = pHt(v); // burette
        g.fillStyle = col.s2; g.fillRect(fx - 6, 0, 12, fy - 150); g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(fx - 6, 0, 12, fy - 150); g.fillStyle = 'rgba(120,170,230,.5)'; g.fillRect(fx - 5, (fy - 150) * (v / 50), 10, (fy - 150) * (1 - v / 50)); g.fillStyle = col.fg; g.fillRect(fx - 2, fy - 150, 4, 18);
        const u = (t * 2) % 1; g.fillStyle = 'rgba(120,170,230,.9)'; g.beginPath(); g.arc(fx, fy - 128 + u * 40, 2.4, 0, 7); g.fill();
        // conical flask
        g.save(); g.beginPath(); g.moveTo(fx - 9, fy - 105); g.lineTo(fx - 9, fy - 80); g.lineTo(fx - 55, fy); g.lineTo(fx + 55, fy); g.lineTo(fx + 9, fy - 80); g.lineTo(fx + 9, fy - 105); g.closePath(); g.clip(); g.fillStyle = pjCol(P, pH, 0.8); const lv = fy - 40 - v * 0.6; g.fillRect(fx - 60, lv + Math.sin(t * 6) * 1.5, 120, fy - lv + 4); g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(fx - 9, fy - 105); g.lineTo(fx - 9, fy - 80); g.lineTo(fx - 55, fy); g.lineTo(fx + 55, fy); g.lineTo(fx + 9, fy - 80); g.lineTo(fx + 9, fy - 105); g.stroke();
        T(g, `pH ≈ ${bn(pH.toFixed(1))}`, fx + 70, fy - 50, col, { b: true, s: 12, a: 'left' }); T(g, '২০ mL ০.১ M HCl + রস', fx, fy + 14, col, { s: 9, c: col.mu });
        if (wd) { const gx = W * 0.58, gy = 20, gw = W * 0.38, gh = H - 60; g.strokeStyle = col.ln || col.mu; g.strokeRect(gx, gy, gw, gh); for (let i = 0; i <= 350; i++) { const vv = i / 10, p = pHt(vv); g.fillStyle = pjCol(P, p, 1); g.fillRect(gx + vv / 35 * gw - 1, gy + gh * (1 - p / 14) - 1.5, 3, 3); } g.fillStyle = col.fg; g.beginPath(); g.arc(gx + v / 35 * gw, gy + gh * (1 - pH / 14), 5, 0, 7); g.fill(); T(g, 'pH বনাম NaOH (mL) — রেখার রং = রসের রং', gx + gw / 2, gy + gh + 14, col, { s: 9, c: col.mu }); }
      }
    };
    const info = () => { const P = PJ[ji]; q('[data-vv]').textContent = bn(v.toFixed(2)); const pH = pHt(v); out.innerHTML = md === 0 ? `<div class="small"><b>${P[1]}:</b> ${ji === 2 ? 'কারকিউমিন pH ~৭.৪ পর্যন্ত হলুদ, ~৮.৬ এর উপরে লালচে-বাদামি — তাই এটি কেবল ক্ষার শনাক্তকরণে উপযোগী (হলুদের দাগে সাবান লাগালে লাল হয় কেন বোঝা যায়)।' : ji === 3 ? 'বিটানিন বিস্তৃত অম্লীয়-নিরপেক্ষ পরিসরে লাল-বেগুনি; তীব্র ক্ষারে বাদামি-হলুদ (বিয়োজিত হয়)।' : 'অ্যান্থোসায়ানিন অণুর গঠন pH ভেদে বদলায় (ফ্ল্যাভিলিয়াম ক্যাটায়ন → কুইনোনয়েড → চালকোন) — তাই এক রস দিয়েই প্রায় পুরো pH স্কেল আন্দাজ করা যায়।'}</div><div class="small">সীমাবদ্ধতা: প্রাকৃতিক রঞ্জকের পরিবর্তন ধীর ও বিস্তৃত পরিসরে হয়, নির্যাসের রং ঋতু ও উৎস ভেদে বদলায়, এবং সময়ের সাথে নষ্ট হয় — তাই নির্ভুল কাজে কৃত্রিম নির্দেশক বা pH মিটার শ্রেয়।</div>` : `<div class="small">২০ mL ০.১ M HCl = ২ mmol ⇒ প্রশমন বিন্দু ২০ mL ০.১ M NaOH এ। বর্তমানে ${bn(v.toFixed(2))} mL, pH ≈ ${bn(pH.toFixed(2))}। ${Math.abs(v - 20) < 0.3 ? '<b>প্রশমন বিন্দুর কাছে — এক-দুই ফোঁটায় রং হঠাৎ বদলায়!</b>' : v < 20 ? 'এসিড বাড়তি।' : 'ক্ষার বাড়তি।'}</div><div class="small">তীব্র-তীব্র টাইট্রেশনে ১৯.৯ mL থেকে ২০.১ mL এ pH প্রায় ৩.৭ থেকে ১০.৩ — এই লাফের মধ্যে রসের যেকোনো স্পষ্ট রং পরিবর্তনই সমাপ্তি বিন্দু নির্দেশ করে।</div>`; draw(); };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    el.querySelectorAll('[data-md]').forEach(b => b.onclick = () => { md = +b.dataset.md; el.querySelectorAll('[data-md]').forEach(x => x.classList.toggle('primary', x === b)); q('[data-tc]').style.display = md ? 'flex' : 'none'; info(); });
    q('[data-j]').onchange = e => { ji = +e.target.value; info(); }; q('[data-v]').oninput = e => { v = +e.target.value; info(); };
    info();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
