/* ২য় পত্র অধ্যায় ৩ visuals part 4 — 3.8 neutralization (particles, pH, heat, curve); 3.9 Zn/Cu electron transfer, oxidation-number explorer */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const sig = (v, d = 3) => { if (!isFinite(v)) return '—'; if (v === 0) return '০'; const a = Math.abs(v); if (a >= 1e5 || a < 1e-3) { const e = Math.floor(Math.log10(a)), m = v / 10 ** e; const sup = String(e).split('').map(ch => '⁻⁰¹²³⁴⁵⁶⁷⁸⁹'['-0123456789'.indexOf(ch)]).join(''); return `${bn(m.toFixed(d - 1))} × ১০${sup}`; } return bn((+v.toPrecision(d)).toString()); };
const lerp = (a, b, u) => a + (b - a) * u;
const UI = [[0, [204, 0, 0]], [3, [235, 50, 30]], [4, [245, 130, 30]], [5, [250, 190, 40]], [6, [230, 225, 50]], [7, [80, 180, 70]], [8, [40, 150, 140]], [9, [40, 100, 190]], [10, [70, 60, 170]], [12, [110, 40, 150]], [14, [90, 20, 110]]];
const uiCol = (pH, a = 0.75) => { pH = Math.max(0, Math.min(14, pH)); let i = 0; while (i < UI.length - 2 && UI[i + 1][0] < pH) i++; const [p0, c0] = UI[i], [p1, c1] = UI[i + 1], u = (pH - p0) / (p1 - p0 || 1); return `rgba(${c0.map((v, k) => Math.round(lerp(v, c1[k], u))).join(',')},${a})`; };

/* ======================= ৩.৮ প্রশমন ======================= */
const ACD = [['HCl', 'HCl (তীব্র)', 1, 0, 'Cl⁻'], ['HNO3', 'HNO₃ (তীব্র)', 1, 0, 'NO₃⁻'], ['H2SO4', 'H₂SO₄ (তীব্র, দ্বিক্ষারীয়)', 2, 0, 'SO₄²⁻'], ['CH3COOH', 'CH₃COOH (মৃদু, Ka = ১.৮ × ১০⁻⁵)', 1, 1.8e-5, 'CH₃COO⁻']];
const BAS = [['NaOH', 'NaOH (তীব্র)', 1, 0, 'Na⁺'], ['KOH', 'KOH (তীব্র)', 1, 0, 'K⁺'], ['BaOH2', 'Ba(OH)₂ (তীব্র, দ্বি-অম্লীয়)', 2, 0, 'Ba²⁺'], ['NH3', 'NH₃ (মৃদু, Kb = ১.৮ × ১০⁻⁵)', 1, 1.8e-5, 'NH₄⁺']];
const NM = { HCl: 'HCl', HNO3: 'HNO₃', H2SO4: 'H₂SO₄', CH3COOH: 'CH₃COOH', NaOH: 'NaOH', KOH: 'KOH', BaOH2: 'Ba(OH)₂', NH3: 'NH₃' };
const Kw = 1e-14;
const pHof = (A, B, Ca, Va, Cb, Vb) => { // mmol of H+ capacity vs OH- capacity
  const ha = Ca * Va * A[2], ob = Cb * Vb * B[2], Vt = Va + Vb, d = (ha - ob) / Vt; const Ka = A[3], Kb = B[3];
  const strongPH = dd => { const h = (dd + Math.sqrt(dd * dd + 4 * Kw)) / 2; return -Math.log10(h); };
  if (!Ka && !Kb) return strongPH(d);
  if (Ka && !Kb) { if (ob <= 1e-12) { const C = ha / Vt; return -Math.log10((-Ka + Math.sqrt(Ka * Ka + 4 * Ka * C)) / 2); } if (ob < ha - 1e-9) return -Math.log10(Ka) + Math.log10(ob / (ha - ob)); if (Math.abs(ob - ha) <= 1e-9) { const C = ha / Vt; return 14 + Math.log10(Math.sqrt(Kw / Ka * C)); } return strongPH(d); }
  if (!Ka && Kb) { if (ob < ha - 1e-9) return strongPH(d) ; if (Math.abs(ob - ha) <= 1e-9) { const C = ha / Vt; return -Math.log10(Math.sqrt(Kw / Kb * C)); } if (ha <= 1e-12) { const C = ob / Vt; return 14 + Math.log10((-Kb + Math.sqrt(Kb * Kb + 4 * Kb * C)) / 2); } return 14 + Math.log10(Kb) - Math.log10(ha / (ob - ha)); }
  // weak-weak
  if (ob <= 1e-12) { const C = ha / Vt; return -Math.log10(Math.sqrt(Ka * C)); }
  if (Math.abs(ob - ha) < 1e-9) return 7 + 0.5 * (Math.log10(Kb) - Math.log10(Ka));
  if (ob < ha) return -Math.log10(Ka) + Math.log10(ob / (ha - ob)); return 14 + Math.log10(Kb) - Math.log10(ha / (ob - ha));
};
V.p2c3_neutral = {
  t: 'এসিড-ক্ষার প্রশমন: কণার স্তরে H⁺ + OH⁻ → H₂O, সার্বজনীন নির্দেশকের রং, pH মিটার, প্রশমন তাপে তাপমাত্রা বৃদ্ধি এবং প্রশমন বিন্দু (তীব্র/মৃদু এসিড ও ক্ষারের সমন্বয়)', k: ['anim', 'int', 'calc', 'plot'],
  cap: 'এসিড ও ক্ষার বেছে নাও; বিকারে ২৫ mL এসিড আছে। স্লাইডারে ক্ষারের আয়তন বাড়াও — বিকারের দ্রবণের রং (সার্বজনীন নির্দেশক), pH মিটার, থার্মোমিটার ও কণা-দৃশ্য (লাল H₃O⁺/H⁺, নীল OH⁻, সাদা-লাল H₂O; মৃদু এসিড হলে অবিয়োজিত HA অণু ধূসর) একসাথে বদলায়। প্রশমন বিন্দুতে এসিডের মোট H⁺ এর মোল = ক্ষারের মোট OH⁻ এর মোল (দ্বিক্ষারীয় H₂SO₄ বা Ba(OH)₂ এ গুণক ২)। তীব্র-তীব্র প্রশমনে প্রশমন বিন্দুতে pH = ৭, কিন্তু মৃদু এসিড + তীব্র ক্ষারে > ৭ এবং তীব্র এসিড + মৃদু ক্ষারে < ৭ (লবণের আর্দ্রবিশ্লেষণ)। প্রশমন তাপ: তীব্র-তীব্রে প্রতি মোল পানিতে −৫৭.৩ kJ।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-a', ACD.map((s, i) => [String(i), s[1]]), '0')}${SEL('data-b', BAS.map((s, i) => [String(i), s[1]]), '0')}</div>${X.cv('প্রশমন')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:110px">এসিড = <b data-cav></b> M<input type="range" min="0.1" max="1" step="0.05" value="0.5" data-ca></label><label class="small" style="flex:1;min-width:110px">ক্ষার = <b data-cbv></b> M<input type="range" min="0.1" max="1" step="0.05" value="0.5" data-cb></label><label class="small" style="flex:2;min-width:160px">যোগ করা ক্ষার = <b data-vbv></b> mL<input type="range" min="0" max="60" step="0.1" value="0" data-vb></label><button class="btn sm" data-eq>প্রশমন বিন্দুতে যাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 310 : 520;
    let L = X.fit(c, hf), ai = 0, bi = 0, Ca = 0.5, Cb = 0.5, Vb = 0, Va = 25, t = 0;
    const st = () => { const A = ACD[ai], B = BAS[bi], ha = Ca * Va * A[2], ob = Cb * Vb * B[2], nw = Math.min(ha, ob), dH = (A[3] || B[3]) ? (A[3] && B[3] ? 50.4 : 55.9) : 57.3; const dT = nw / 1000 * dH * 1000 / ((Va + Vb) * 4.18); return { A, B, ha, ob, nw, dH, dT, pH: pHof(A, B, Ca, Va, Cb, Vb), Veq: ha / (Cb * B[2]) }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const S = st(), wd = wide(W);
      // beaker
      const bx = wd ? W * 0.15 : W * 0.3, by = wd ? H - 40 : 210, bw = wd ? 110 : 100, bh = wd ? 150 : 130; const fill = Math.min(0.92, (Va + Vb) / 100);
      g.fillStyle = uiCol(S.pH, 0.7); g.fillRect(bx - bw / 2 + 2, by - bh * fill, bw - 4, bh * fill); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(bx - bw / 2, by - bh); g.lineTo(bx - bw / 2, by); g.lineTo(bx + bw / 2, by); g.lineTo(bx + bw / 2, by - bh); g.stroke();
      // burette tip + drops
      g.fillStyle = col.s3 || '#ccc'; g.fillRect(bx - 4, 0, 8, by - bh - 20); g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(bx - 4, 0, 8, by - bh - 20); const u = (t * 1.5) % 1; g.fillStyle = 'rgba(120,170,230,.9)'; g.beginPath(); g.arc(bx, by - bh - 16 + u * (bh * (1 - fill) + 16), 2.5, 0, 7); g.fill(); T(g, `বুরেট: ${NM[S.B[0]]}`, bx + 10, 14, col, { s: 9, a: 'left', c: col.mu });
      // pH meter & thermometer
      const mx = bx + bw / 2 + (wd ? 14 : 20), my = by - bh - 10; g.fillStyle = '#222'; g.fillRect(mx, my, wd ? 70 : 60, 34); g.fillStyle = '#69db7c'; g.font = `bold 15px ${col.mono}`; g.textAlign = 'center'; g.fillText(S.pH.toFixed(2), mx + (wd ? 35 : 30), my + 23); T(g, 'pH', mx + (wd ? 35 : 30), my - 4, col, { s: 9, c: col.mu });
      const tx = mx + (wd ? 20 : 15), ty = my + 50, th = 80; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(tx - 4, ty, 8, th); g.beginPath(); g.arc(tx, ty + th + 6, 7, 0, 7); g.fillStyle = '#e03131'; g.fill(); g.stroke(); const tf = Math.min(1, (S.dT) / 15 * 0.8 + 0.15); g.fillStyle = '#e03131'; g.fillRect(tx - 2, ty + th * (1 - tf), 4, th * tf); T(g, `${bn((25 + S.dT).toFixed(1))} °C`, tx + 10, ty + th * (1 - tf) + 4, col, { s: 10, b: true, a: 'left' });
      // particle zoom
      const zx = wd ? W * 0.5 : W * 0.5, zy = wd ? H * 0.42 : 300, zr = wd ? Math.min(78, H * 0.28) : 70; g.save(); g.beginPath(); g.arc(zx, zy, zr, 0, 7); g.clip(); g.fillStyle = uiCol(S.pH, 0.15); g.fillRect(zx - zr, zy - zr, 2 * zr, 2 * zr);
      const Vt = Va + Vb, sc = 7 / 0.5; // particles per (mmol/mL)
      const hfree = S.A[3] ? Math.pow(10, -S.pH) : Math.max(0, (S.ha - S.ob) / Vt), ofree = Math.pow(10, S.pH - 14);
      const nH = Math.round(Math.min(12, (S.A[3] ? Math.pow(10, -S.pH) * 3000 : hfree * sc))), nOH = Math.round(Math.min(12, S.B[3] ? ofree * 3000 : Math.max(0, (S.ob - S.ha) / Vt) * sc)); const nHA = S.A[3] ? Math.round(Math.min(10, Math.max(0, S.ha - S.ob) / Vt * sc)) : 0; const nW = Math.round(Math.min(14, S.nw / Vt * sc * 1.2)); const nSp = Math.round(Math.min(8, S.ob / Vt * sc * 0.6)), nAn = Math.round(Math.min(8, S.ha / Vt * sc * 0.6 / (S.A[2])));
      let k = 0; const P = () => { k++; const a = k * 2.399, rr = zr * 0.85 * Math.sqrt((k * 0.618) % 1); return [zx + Math.cos(a + t * 0.25 * (k % 3 - 1)) * rr, zy + Math.sin(a + t * 0.25 * (k % 3 - 1)) * rr]; };
      const ion = (x, y, cc, lab, r = 7) => { g.fillStyle = cc; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 7px ${col.font}`; g.textAlign = 'center'; g.fillText(lab, x, y + 2.5); };
      for (let i = 0; i < nH; i++) { const [x, y] = P(); ion(x, y, '#e03131', 'H⁺'); }
      for (let i = 0; i < nOH; i++) { const [x, y] = P(); ion(x, y, '#1c7ed6', 'OH⁻', 8); }
      for (let i = 0; i < nHA; i++) { const [x, y] = P(); ion(x, y, '#868e96', 'HA', 8); }
      for (let i = 0; i < nW; i++) { const [x, y] = P(); g.fillStyle = '#e03131'; g.beginPath(); g.arc(x, y, 5, 0, 7); g.fill(); g.fillStyle = '#f1f3f5'; g.beginPath(); g.arc(x - 5, y + 4, 3, 0, 7); g.arc(x + 5, y + 4, 3, 0, 7); g.fill(); }
      for (let i = 0; i < nSp; i++) { const [x, y] = P(); ion(x, y, '#ae3ec9', S.B[0] === 'NH3' ? 'NH₄⁺' : S.B[4].replace('⁺', '').replace('²', ''), 6); }
      for (let i = 0; i < nAn; i++) { const [x, y] = P(); ion(x, y, '#2f9e44', S.A[0] === 'CH3COOH' ? 'A⁻' : S.A[0] === 'H2SO4' ? 'SO₄' : S.A[4].replace('⁻', ''), 6); }
      g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.arc(zx, zy, zr, 0, 7); g.stroke(); T(g, 'কণা-দৃশ্য (বিবর্ধিত)', zx, zy + zr + 14, col, { s: 9, c: col.mu });
      // curve
      const cx0 = wd ? W * 0.66 : 36, cy0 = wd ? 20 : 400, cw = wd ? W * 0.31 : W - 50, ch = wd ? H - 60 : 100; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(cx0, cy0, cw, ch); g.beginPath(); for (let i = 0; i <= 240; i++) { const v = i / 4, ph = pHof(S.A, S.B, Ca, Va, Cb, v), x = cx0 + v / 60 * cw, y = cy0 + ch * (1 - ph / 14); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.strokeStyle = col.acc; g.lineWidth = 2; g.stroke();
      const ex = cx0 + Math.min(1, S.Veq / 60) * cw; if (S.Veq <= 60) { g.setLineDash([3, 3]); g.strokeStyle = '#e8590c'; g.beginPath(); g.moveTo(ex, cy0); g.lineTo(ex, cy0 + ch); g.stroke(); g.setLineDash([]); T(g, `প্রশমন বিন্দু ${bn(+S.Veq.toFixed(1))} mL`, Math.min(ex, cx0 + cw - 50), cy0 + 12, col, { s: 9, c: '#e8590c', b: true }); }
      g.strokeStyle = col.mu; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(cx0, cy0 + ch / 2); g.lineTo(cx0 + cw, cy0 + ch / 2); g.stroke(); g.setLineDash([]);
      const px = cx0 + Vb / 60 * cw, py = cy0 + ch * (1 - S.pH / 14); g.fillStyle = '#e03131'; g.beginPath(); g.arc(px, py, 5, 0, 7); g.fill();
      T(g, 'pH', cx0 - 10, cy0 + 8, col, { s: 9, c: col.mu }); [0, 7, 14].forEach(v => T(g, bn(v), cx0 - 10, cy0 + ch * (1 - v / 14) + 3, col, { s: 8.5, c: col.mu })); T(g, 'ক্ষারের আয়তন (mL) →', cx0 + cw / 2, cy0 + ch + 14, col, { s: 9, c: col.mu });
    };
    const info = () => { const S = st(); [['cav', Ca], ['cbv', Cb], ['vbv', Vb]].forEach(([k, v]) => q(`[data-${k}]`).textContent = bn(+v.toFixed(2))); const eqn = { HCl: { NaOH: 'HCl + NaOH -> NaCl + H2O', KOH: 'HCl + KOH -> KCl + H2O', BaOH2: '2HCl + Ba(OH)2 -> BaCl2 + 2H2O', NH3: 'HCl + NH3 -> NH4Cl' }, HNO3: { NaOH: 'HNO3 + NaOH -> NaNO3 + H2O', KOH: 'HNO3 + KOH -> KNO3 + H2O', BaOH2: '2HNO3 + Ba(OH)2 -> Ba(NO3)2 + 2H2O', NH3: 'HNO3 + NH3 -> NH4NO3' }, H2SO4: { NaOH: 'H2SO4 + 2NaOH -> Na2SO4 + 2H2O', KOH: 'H2SO4 + 2KOH -> K2SO4 + 2H2O', BaOH2: 'H2SO4 + Ba(OH)2 -> BaSO4 v + 2H2O', NH3: 'H2SO4 + 2NH3 -> (NH4)2SO4' }, CH3COOH: { NaOH: 'CH3COOH + NaOH -> CH3COONa + H2O', KOH: 'CH3COOH + KOH -> CH3COOK + H2O', BaOH2: '2CH3COOH + Ba(OH)2 -> (CH3COO)2Ba + 2H2O', NH3: 'CH3COOH + NH3 -> CH3COONH4' } }[S.A[0]][S.B[0]];
      const zone = Math.abs(S.ob - S.ha) < 1e-6 ? 'ঠিক প্রশমন বিন্দু' : S.ob < S.ha ? 'প্রশমন বিন্দুর আগে — এসিড বাড়তি' : 'প্রশমন বিন্দুর পরে — ক্ষার বাড়তি';
      out.innerHTML = `${TXB(`\\ce{${eqn}}`)}<div class="small"><b>অবস্থা:</b> ${zone}; pH = ${bn(S.pH.toFixed(2))}।</div><div class="small">এসিডের H⁺ ক্ষমতা = ${bn(Ca)} × ${bn(Va)} × ${bn(S.A[2])} = ${sig(S.ha)} mmol; যোগ করা OH⁻ = ${bn(Cb)} × ${bn(+Vb.toFixed(1))} × ${bn(S.B[2])} = ${sig(S.ob)} mmol।</div><div class="small"><b>প্রশমন বিন্দুর শর্ত:</b> ${TXB(`n_a \\times M_a V_a = n_b \\times M_b V_b`)} ⇒ V(ক্ষার) = ${bn(S.A[2])} × ${bn(Ca)} × ${bn(Va)} ÷ (${bn(S.B[2])} × ${bn(Cb)}) = <b>${sig(S.Veq)} mL</b>।</div><div class="small"><b>প্রশমন তাপ:</b> উৎপন্ন H₂O = ${sig(S.nw)} mmol × ${bn(S.dH)} kJ/mol = ${sig(S.nw * S.dH)} J; ΔT ≈ q/(m × ৪.১৮) = ${bn(S.dT.toFixed(2))} °C।${S.A[3] || S.B[3] ? ' মৃদু এসিড/ক্ষারের বিয়োজনে কিছু তাপ শোষিত হয়, তাই প্রশমন তাপ ৫৭.৩ kJ/mol এর কম।' : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    q('[data-a]').onchange = e => { ai = +e.target.value; info(); }; q('[data-b]').onchange = e => { bi = +e.target.value; info(); };
    q('[data-ca]').oninput = e => { Ca = +e.target.value; info(); }; q('[data-cb]').oninput = e => { Cb = +e.target.value; info(); }; q('[data-vb]').oninput = e => { Vb = +e.target.value; info(); };
    q('[data-eq]').onclick = () => { const S = st(); Vb = Math.min(60, S.Veq); q('[data-vb]').value = Vb; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.৯ ইলেকট্রন স্থানান্তর: ধাতব প্রতিস্থাপন ======================= */
const ZC = [
  { t: 'Zn দণ্ড + CuSO₄ দ্রবণ', metal: ['Zn', '#9aa5b1'], ion: ['Cu²⁺', '#1e88e5', 2], dep: ['Cu', '#b5651d'], sol0: '#1e88e5', sol1: null, rx: true, eq: 'Zn(s) + Cu^2+(aq) -> Zn^2+(aq) + Cu(s)', ox: 'Zn -> Zn^2+ + 2e-', red: 'Cu^2+ + 2e- -> Cu', note: 'Zn সক্রিয়তা সিরিজে Cu এর উপরে — তাই Zn ইলেকট্রন ত্যাগ করে (জারিত), Cu²⁺ ইলেকট্রন গ্রহণ করে (বিজারিত)। দ্রবণের নীল রং ফিকে হয়, দণ্ডে লালচে-বাদামি কপার জমে। বিজারক Zn, জারক Cu²⁺।' },
  { t: 'Cu তার + AgNO₃ দ্রবণ', metal: ['Cu', '#c87533'], ion: ['Ag⁺', '#adb5bd', 1], dep: ['Ag', '#e9ecef'], sol0: null, sol1: '#1e88e5', rx: true, eq: 'Cu(s) + 2Ag+(aq) -> Cu^2+(aq) + 2Ag(s)', ox: 'Cu -> Cu^2+ + 2e-', red: '2Ag+ + 2e- -> 2Ag', note: 'Cu, Ag এর চেয়ে সক্রিয়। তারে চকচকে রুপালি কেলাস ("সিলভার ট্রি") জমে, বর্ণহীন দ্রবণ ধীরে নীল হয় (Cu²⁺)। প্রতিটি Cu পরমাণু ২টি ইলেকট্রন দেয় — ২টি Ag⁺ কে বিজারিত করে।' },
  { t: 'Cu দণ্ড + ZnSO₄ দ্রবণ', metal: ['Cu', '#c87533'], ion: ['Zn²⁺', '#ced4da', 2], dep: null, sol0: null, sol1: null, rx: false, eq: 'Cu(s) + Zn^2+(aq) -> \\text{কোনো বিক্রিয়া নেই}', ox: '', red: '', note: 'Cu, Zn এর চেয়ে কম সক্রিয় — Cu পরমাণু Zn²⁺ কে ইলেকট্রন দিতে পারে না (E° অনুযায়ী বিক্রিয়াটি অস্বতঃস্ফূর্ত)। তাই কোনো পরিবর্তন হয় না।' }
];
V.p2c3_znCu = {
  t: 'জারণ-বিজারণ মানে ইলেকট্রন স্থানান্তর: ধাতব প্রতিস্থাপন বিক্রিয়া (Zn + Cu²⁺, Cu + Ag⁺, Cu + Zn²⁺) — বিকারের পরিবর্তন এবং ধাতব পৃষ্ঠে পরমাণু-স্তরে ইলেকট্রনের যাত্রা', k: ['anim', 'int'],
  cap: 'পরীক্ষা বেছে নিয়ে "ডোবাও" চাপো। বামে বিকার — সময়ের সাথে দ্রবণের রং ও ধাতব দণ্ডের পৃষ্ঠ বদলায়। ডানে বিবর্ধিত বৃত্তে ধাতব পৃষ্ঠ: দ্রবণের ধাতব আয়ন পৃষ্ঠে আসে, পৃষ্ঠের একটি পরমাণু থেকে ইলেকট্রন (হলুদ বিন্দু) আয়নে যায় — পরমাণুটি আয়ন হয়ে দ্রবণে চলে যায় (জারণ: ইলেকট্রন ত্যাগ, জারণ সংখ্যা বৃদ্ধি), আর আয়নটি পরমাণু হয়ে পৃষ্ঠে জমে (বিজারণ: ইলেকট্রন গ্রহণ, জারণ সংখ্যা হ্রাস)। জারণ ও বিজারণ সবসময় একসাথে ঘটে। তৃতীয় পরীক্ষায় কেন কিছু ঘটে না দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-x', ZC.map((s, i) => [String(i), s.t]), '0')}<button class="btn sm primary" data-go>▶ ডোবাও</button><button class="btn sm" data-rs>↺ নতুন করে</button></div>${X.cv('ইলেকট্রন স্থানান্তর')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 480;
    let L = X.fit(c, hf), xi = 0, on = false, prog = 0, t = 0, tz = 0;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const s = ZC[xi], wd = wide(W), pr = s.rx ? prog : 0;
      // beaker
      const bx = wd ? W * 0.22 : W * 0.5, by = wd ? H - 30 : 220, bw = wd ? 150 : 140, bh = wd ? 170 : 150;
      const c0 = s.sol0 ? s.sol0 : null, c1 = s.sol1; let fill; if (c0 && !c1) fill = `rgba(30,136,229,${0.55 * (1 - 0.8 * pr)})`; else if (c1) fill = `rgba(30,136,229,${0.5 * pr})`; else fill = 'rgba(200,220,240,.25)';
      g.fillStyle = 'rgba(200,220,240,.25)'; g.fillRect(bx - bw / 2 + 2, by - bh * 0.75, bw - 4, bh * 0.75); g.fillStyle = fill; g.fillRect(bx - bw / 2 + 2, by - bh * 0.75, bw - 4, bh * 0.75); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(bx - bw / 2, by - bh); g.lineTo(bx - bw / 2, by); g.lineTo(bx + bw / 2, by); g.lineTo(bx + bw / 2, by - bh); g.stroke();
      const rx = bx - 12, rw = 24, rTop = by - bh - 30, rLen = on ? bh * 0.95 : bh * 0.4; const dipY = rTop + rLen; g.fillStyle = s.metal[1]; g.fillRect(rx, rTop, rw, rLen); g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(rx, rTop, rw, rLen);
      if (on && s.dep && pr > 0) { const wl = by - bh * 0.75; for (let i = 0; i < 70 * pr; i++) { const yy = wl + ((i * 37) % 100) / 100 * (dipY - wl), side = i % 2 ? rx - 2 - ((i * 13) % 5) : rx + rw + ((i * 7) % 5) - 1; g.fillStyle = s.dep[1]; if (s.dep[0] === 'Ag') { g.strokeStyle = '#ced4da'; g.beginPath(); g.moveTo(side, yy); g.lineTo(side + (i % 2 ? -6 : 6), yy - 4); g.stroke(); } g.beginPath(); g.arc(side, yy, 2.2, 0, 7); g.fill(); } }
      T(g, s.metal[0], bx, rTop - 6, col, { b: true, s: 11 }); T(g, s.t.split('+')[1].trim(), bx, by + 14, col, { s: 10, c: col.mu });
      // zoom
      const zx = wd ? W * 0.68 : W * 0.5, zy = wd ? H * 0.5 : 360, zr = wd ? Math.min(120, H * 0.42) : 105; g.save(); g.beginPath(); g.arc(zx, zy, zr, 0, 7); g.clip(); g.fillStyle = c1 ? `rgba(30,136,229,${0.12 + 0.1 * pr})` : c0 ? `rgba(30,136,229,${0.18})` : 'rgba(200,220,240,.15)'; g.fillRect(zx - zr, zy - zr, 2 * zr, 2 * zr);
      const a = 15, cols = Math.ceil(2 * zr / (2 * a)) + 1, sx = zx - zr * 0.85 - a, rows = 3; const surfX = sx + rows * 2 * a; // lattice on left, solution on right
      const per = 2.4, cyc = Math.floor(tz / per), ph = (tz % per) / per, N = 7; const act = s.rx && on;
      const jc = Math.round(zr / (2 * a)) - 2, cur = cyc % N; for (let r = 0; r < rows; r++) for (let j = 0; j < cols; j++) { const x = sx + r * 2 * a + a, y = zy - zr + j * 2 * a + (r % 2) * a; if (r === rows - 1) { const site = j - jc, done = act && site >= 0 && site < N && (site < cur || (site === cur && ph > 0.75)); if (act && site === cur && ph <= 0.75) continue; if (done && s.dep) { g.fillStyle = s.dep[1]; g.beginPath(); g.arc(x, y, a * 0.92, 0, 7); g.fill(); g.strokeStyle = 'rgba(0,0,0,.3)'; g.stroke(); T(g, s.dep[0], x, y + 3, col, { b: true, s: 8, c: '#222' }); continue; } } const gr = g.createRadialGradient(x - 4, y - 4, 2, x, y, a); gr.addColorStop(0, '#fff'); gr.addColorStop(1, s.metal[1]); g.fillStyle = gr; g.beginPath(); g.arc(x, y, a * 0.92, 0, 7); g.fill(); T(g, s.metal[0], x, y + 3, col, { b: true, s: 8, c: '#222' }); }
      // active site
      const ax = sx + (rows - 1) * 2 * a + a, ay = zy - zr + (jc + cur) * 2 * a + ((rows - 1) % 2) * a;
      if (act) {
        const ix = ph < 0.35 ? lerp(zx + zr * 0.9, ax + 2 * a + 2, ph / 0.35) : ph < 0.6 ? ax + 2 * a + 2 : lerp(ax + 2 * a + 2, ax, Math.min(1, (ph - 0.6) / 0.15)), iy = ph < 0.6 ? ay + 4 : lerp(ay + 4, ay, Math.min(1, (ph - 0.6) / 0.15)); // incoming ion
        if (ph < 0.6) { g.fillStyle = s.ion[1]; g.beginPath(); g.arc(ix, iy, a * 0.75, 0, 7); g.fill(); T(g, s.ion[0], ix, iy + 3, col, { b: true, s: 8, c: s.ion[0] === 'Cu²⁺' ? '#fff' : '#222' }); }
        else if (ph <= 0.75 && s.dep) { g.fillStyle = s.dep[1]; g.beginPath(); g.arc(ix, iy, a * 0.92, 0, 7); g.fill(); T(g, s.dep[0], ix, iy + 3, col, { b: true, s: 8, c: '#222' }); }
        // electrons
        if (ph > 0.35 && ph < 0.6) { const u = (ph - 0.35) / 0.25; for (let e = 0; e < s.ion[2] * (s.dep && s.dep[0] === 'Ag' ? 2 : 1); e++) { const ex = lerp(ax, ax + 2 * a, u), ey = ay + (e - 0.5) * 8 + Math.sin(u * 6 + e) * 3; g.fillStyle = '#ffd43b'; g.beginPath(); g.arc(ex, ey, 3.5, 0, 7); g.fill(); g.strokeStyle = '#e67700'; g.lineWidth = 1; g.stroke(); } T(g, `${s.dep && s.dep[0] === 'Ag' ? '২' : bn(s.ion[2])}e⁻`, ax + a, ay - a - 4, col, { b: true, s: 10, c: '#e67700' }); }
        // leaving metal ion
        const lu = ph < 0.6 ? 0 : (ph - 0.6) / 0.4; if (ph < 0.6) { const gr = g.createRadialGradient(ax - 4, ay - 4, 2, ax, ay, a); gr.addColorStop(0, '#fff'); gr.addColorStop(1, s.metal[1]); g.fillStyle = gr; g.beginPath(); g.arc(ax, ay, a * 0.92, 0, 7); g.fill(); T(g, s.metal[0], ax, ay + 3, col, { b: true, s: 8, c: '#222' }); } else { const lx = lerp(ax, zx + zr * 0.7, lu), ly = lerp(ay, ay - a * 3, lu); g.globalAlpha = 1 - lu * 0.3; g.fillStyle = s.metal[0] === 'Cu' ? '#1e88e5' : '#dee2e6'; g.beginPath(); g.arc(lx, ly, a * 0.7, 0, 7); g.fill(); g.globalAlpha = 1; T(g, `${s.metal[0]}²⁺`, lx, ly + 3, col, { b: true, s: 8, c: s.metal[0] === 'Cu' ? '#fff' : '#222' }); }
      } else { for (let i = 0; i < 4; i++) { const x = zx + zr * 0.3 + Math.sin(t * 0.6 + i * 2) * zr * 0.25, y = zy - zr * 0.6 + i * zr * 0.4; g.fillStyle = s.ion[1]; g.beginPath(); g.arc(x, y, a * 0.75, 0, 7); g.fill(); T(g, s.ion[0], x, y + 3, col, { b: true, s: 8, c: s.ion[0] === 'Cu²⁺' ? '#fff' : '#222' }); } if (on && !s.rx) T(g, '✗ ইলেকট্রন স্থানান্তর হয় না', zx + zr * 0.25, zy + zr * 0.8, col, { b: true, s: 10, c: '#e03131' }); }
      g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.arc(zx, zy, zr, 0, 7); g.stroke(); if (wd) { g.setLineDash([3, 3]); g.strokeStyle = col.mu; g.beginPath(); g.moveTo(rx + rw, by - bh * 0.4); g.lineTo(zx - zr * 0.95, zy); g.stroke(); g.setLineDash([]); }
      T(g, 'ধাতব পৃষ্ঠ (বিবর্ধিত)', zx - zr * 0.4, zy + zr + 14, col, { s: 9, c: col.mu }); T(g, 'দ্রবণ', zx + zr * 0.5, zy + zr + 14, col, { s: 9, c: col.mu });
    };
    const info = () => { const s = ZC[xi]; out.innerHTML = `${TXB(`\\ce{${s.eq}}`)}${s.ox ? `<div class="small"><b>জারণ অর্ধ-বিক্রিয়া</b> (ইলেকট্রন ত্যাগ): ${TXB(`\\ce{${s.ox}}`)} &nbsp; <b>বিজারণ অর্ধ-বিক্রিয়া</b> (ইলেকট্রন গ্রহণ): ${TXB(`\\ce{${s.red}}`)}</div>` : ''}<div class="small">${s.note}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (on) { tz += dt; prog = Math.min(1, prog + dt * 0.05); } } draw(); }, { paused: false });
    q('[data-x]').onchange = e => { xi = +e.target.value; on = false; prog = 0; tz = 0; info(); };
    q('[data-go]').onclick = () => { on = true; }; q('[data-rs]').onclick = () => { on = false; prog = 0; tz = 0; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.৯ জারণ সংখ্যা এক্সপ্লোরার ======================= */
// [display, charge, [[sym, count, ON, how]], note]
const OXR = ['মুক্ত মৌলে জারণ সংখ্যা শূন্য।', 'F সবসময় −১।', 'O সাধারণত −২ (পারঅক্সাইডে −১, সুপারঅক্সাইডে −½, OF₂ এ +২)।', 'H সাধারণত +১ (ধাতব হাইড্রাইডে −১)।', 'গ্রুপ-১ ধাতু +১, গ্রুপ-২ ধাতু +২।', 'নিরপেক্ষ যৌগে সব জারণ সংখ্যার যোগফল ০; আয়নে = আয়নের আধান।'];
const OX = [
  ['KMnO₄', 0, [['K', 1, 1, 'গ্রুপ-১'], ['Mn', 1, 7, '১ + x + ৪(−২) = ০ ⇒ x = +৭'], ['O', 4, -2, 'সাধারণ']], 'Mn এর সর্বোচ্চ জারণ অবস্থা — তাই KMnO₄ তীব্র জারক।'],
  ['K₂Cr₂O₇', 0, [['K', 2, 1, 'গ্রুপ-১'], ['Cr', 2, 6, '২ + ২x + ৭(−২) = ০ ⇒ x = +৬'], ['O', 7, -2, 'সাধারণ']], 'Cr(+৬) কমলা; বিজারিত হয়ে Cr³⁺ (সবুজ)।'],
  ['H₂O₂', 0, [['H', 2, 1, 'সাধারণ'], ['O', 2, -1, '২(+১) + ২x = ০ ⇒ x = −১ (পারঅক্সাইড, O–O বন্ধন)']], '−১ অবস্থান −২ ও ০ এর মাঝে — তাই H₂O₂ জারক ও বিজারক উভয়ই হতে পারে।'],
  ['Na₂S₂O₃', 0, [['Na', 2, 1, 'গ্রুপ-১'], ['S', 2, 2, '২ + ২x − ৬ = ০ ⇒ x = +২ (গড়)'], ['O', 3, -2, 'সাধারণ']], 'গড় +২; গঠন অনুযায়ী কেন্দ্রীয় S ও প্রান্তীয় S ভিন্ন (প্রায়শ +৪ ও ০ ধরা হয়)।'],
  ['Na₂S₄O₆', 0, [['Na', 2, 1, 'গ্রুপ-১'], ['S', 4, 2.5, '২ + ৪x − ১২ = ০ ⇒ x = +২.৫ (গড়)'], ['O', 6, -2, 'সাধারণ']], 'আয়োডোমিতিতে থায়োসালফেট (+২) জারিত হয়ে টেট্রাথায়োনেট (+২.৫) হয় — ভগ্নাংশ জারণ সংখ্যা গড় মান।'],
  ['Fe₃O₄', 0, [['Fe', 3, 8 / 3, '৩x − ৮ = ০ ⇒ x = +৮/৩ (গড়)'], ['O', 4, -2, 'সাধারণ']], 'প্রকৃতপক্ষে FeO·Fe₂O₃ — একটি Fe(+২) ও দুটি Fe(+৩)।'],
  ['CrO₅', 0, [['Cr', 1, 6, 'গঠন: একটি O²⁻ (−২) + দুটি O₂²⁻ পারঅক্সো (প্রতিটি −২) ⇒ x = +৬'], ['O', 5, -1.2, '১টি −২ ও ৪টি −১ (গড় −১.২)']], 'সূত্রমতে হিসাব করলে +১০ আসে — অসম্ভব (Cr এর মাত্র ৬টি যোজ্যতা ইলেকট্রন)। পারঅক্সো বন্ধন বিবেচনায় +৬।'],
  ['H₂SO₅', 0, [['H', 2, 1, 'সাধারণ'], ['S', 1, 6, 'একটি পারঅক্সো (−O–O−) থাকায় ২ + x + ৩(−২) + ২(−১) = ০ ⇒ x = +৬'], ['O', 5, -1.6, '৩টি −২ ও ২টি −১']], 'ক্যারোর এসিড; সরাসরি হিসাবে +৮ আসে, যা S এর পক্ষে অসম্ভব।'],
  ['NH₄NO₃', 0, [['N', 2, 1, 'NH₄⁺ এ N = −৩; NO₃⁻ এ N = +৫ (গড় +১)'], ['H', 4, 1, 'সাধারণ'], ['O', 3, -2, 'সাধারণ']], 'একই যৌগে একই মৌলের দুটি ভিন্ন জারণ অবস্থা — আয়ন দুটি আলাদা ধরে হিসাব করতে হয়।'],
  ['OF₂', 0, [['O', 1, 2, 'x + ২(−১) = ০ ⇒ x = +২'], ['F', 2, -1, 'F সবসময় −১ (সবচেয়ে তড়িৎঋণাত্মক)']], 'অক্সিজেনের ধনাত্মক জারণ সংখ্যার বিরল উদাহরণ।'],
  ['NaH', 0, [['Na', 1, 1, 'গ্রুপ-১'], ['H', 1, -1, 'ধাতব হাইড্রাইডে H⁻']], 'হাইড্রাইড আয়ন পানির সাথে বিক্রিয়া করে H₂ দেয় — তীব্র বিজারক।'],
  ['KO₂', 0, [['K', 1, 1, 'গ্রুপ-১'], ['O', 2, -0.5, '১ + ২x = ০ ⇒ x = −½ (সুপারঅক্সাইড O₂⁻)']], 'ডুবোজাহাজ ও মহাকাশযানে CO₂ শোষণ করে O₂ দিতে ব্যবহৃত।'],
  ['CH₄', 0, [['C', 1, -4, 'x + ৪ = ০ ⇒ x = −৪'], ['H', 4, 1, 'সাধারণ']], 'কার্বনের সর্বনিম্ন জারণ অবস্থা।'],
  ['CH₃OH', 0, [['C', 1, -2, 'x + ৪(+১) − ২ = ০ ⇒ x = −২'], ['H', 4, 1, 'সাধারণ'], ['O', 1, -2, 'সাধারণ']], 'মিথানল → মিথান্যাল → মিথানোয়িক এসিড → CO₂: প্রতিটি ধাপে C এর জারণ সংখ্যা ২ করে বাড়ে।'],
  ['HCHO', 0, [['C', 1, 0, 'x + ২ − ২ = ০ ⇒ x = ০'], ['H', 2, 1, 'সাধারণ'], ['O', 1, -2, 'সাধারণ']], 'যৌগে থেকেও কার্বনের জারণ সংখ্যা শূন্য।'],
  ['HCOOH', 0, [['C', 1, 2, 'x + ২ − ৪ = ০ ⇒ x = +২'], ['H', 2, 1, 'সাধারণ'], ['O', 2, -2, 'সাধারণ']], ''],
  ['C₂O₄²⁻', -2, [['C', 2, 3, '২x − ৮ = −২ ⇒ x = +৩'], ['O', 4, -2, 'সাধারণ']], 'KMnO₄ দিয়ে জারিত হয়ে CO₂ (+৪) — প্রতি C এ ১টি, প্রতি অক্সালেটে ২টি ইলেকট্রন।'],
  ['Cr₂O₇²⁻', -2, [['Cr', 2, 6, '২x − ১৪ = −২ ⇒ x = +৬'], ['O', 7, -2, 'সাধারণ']], ''],
  ['MnO₄²⁻', -2, [['Mn', 1, 6, 'x − ৮ = −২ ⇒ x = +৬'], ['O', 4, -2, 'সাধারণ']], 'ম্যাঙ্গানেট (সবুজ) — ক্ষারীয় মাধ্যমে MnO₄⁻ এর বিজারণে।'],
  ['[Fe(CN)₆]⁴⁻', -4, [['Fe', 1, 2, 'x + ৬(−১) = −৪ ⇒ x = +২ (CN⁻ = −১)'], ['C', 6, 2, 'CN⁻ এ C = +২'], ['N', 6, -3, 'CN⁻ এ N = −৩']], 'জটিল আয়নে লিগ্যান্ডের আধান (CN⁻ = −১) ব্যবহার করলে সহজ।'],
  ['S₂O₈²⁻', -2, [['S', 2, 6, 'একটি পারঅক্সো বন্ধন: ২x + ৬(−২) + ২(−১) = −২ ⇒ x = +৬'], ['O', 8, -1.75, '৬টি −২ ও ২টি −১']], 'পারঅক্সোডাইসালফেট; সূত্রমতে +৭ — কিন্তু S এর সর্বোচ্চ +৬।'],
  ['HClO₄', 0, [['H', 1, 1, 'সাধারণ'], ['Cl', 1, 7, '১ + x − ৮ = ০ ⇒ x = +৭'], ['O', 4, -2, 'সাধারণ']], 'Cl এর সর্বোচ্চ জারণ অবস্থা।']
];
const fON = v => { if (Number.isInteger(v)) return (v > 0 ? '+' : v < 0 ? '−' : '') + bn(Math.abs(v)); const fr = { [8 / 3]: '+৮/৩', [-0.5]: '−½', [2.5]: '+২.৫', [-1.2]: '−১.২', [-1.6]: '−১.৬', [-1.75]: '−১.৭৫' }; return fr[v] || bn(v.toFixed(2)); };
V.p2c3_oxnum = {
  t: 'জারণ সংখ্যা এক্সপ্লোরার: ২২টি যৌগ ও আয়নে প্রতিটি মৌলের জারণ সংখ্যা ধাপে ধাপে — পারঅক্সাইড, সুপারঅক্সাইড, হাইড্রাইড, OF₂, ভগ্নাংশ জারণ সংখ্যা (Fe₃O₄, S₄O₆²⁻) ও বিশেষ ক্ষেত্র (CrO₅, H₂SO₅); কুইজ মোড', k: ['int', 'quiz'],
  cap: 'যৌগ বেছে নাও; প্রতিটি মৌলের টাইলে চাপ দিলে তার জারণ সংখ্যা কীভাবে এল দেখায়। নিচের দণ্ডে প্রতিটি মৌলের অবদান (সংখ্যা × জারণ সংখ্যা) যোগ করে মোট আধান মিলিয়ে দেখানো হয়। জারণ সংখ্যার নিয়মগুলো উপরে — বিশেষ ক্ষেত্রগুলোতে (CrO₅, H₂SO₅, S₂O₈²⁻) সূত্রমতে হিসাবে অসম্ভব মান আসে, তখন গঠন (পারঅক্সো বন্ধন) দেখতে হয়। "কুইজ" চাপলে এলোমেলো যৌগের একটি মৌলের জারণ সংখ্যা অনুমান করতে হবে।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-c', OX.map((s, i) => [String(i), s[0]]), '0')}<button class="btn sm" data-qz>🎲 কুইজ</button></div><ol class="small" style="margin:4px 0 6px;padding-left:20px">${OXR.map(r => `<li>${r}</li>`).join('')}</ol><div data-tiles style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:8px 0"></div>${X.cv('জারণ সংখ্যা')}<div data-qa class="ctl" style="display:none;flex-wrap:wrap;justify-content:center"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), tiles = q('[data-tiles]'), qa = q('[data-qa]');
    const hf = () => 130;
    let L = X.fit(c, hf), ci = 0, sel = 1, quiz = null;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const d = OX[ci], els = d[2]; const tot = els.reduce((a, e) => a + e[1] * Math.abs(e[2]), 0) || 1; const x0 = 14, w = W - 28, y = 40, h = 30; let x = x0;
      const pal = ['#4c6ef5', '#e64980', '#12b886', '#fab005', '#7950f2'];
      els.forEach((e, i) => { const ww = w * e[1] * Math.abs(e[2]) / tot; const hide = quiz && quiz.e === i && !quiz.done; g.fillStyle = pal[i % 5]; g.globalAlpha = i === sel ? 1 : 0.6; g.fillRect(x, y, ww, h); g.globalAlpha = 1; { const lab = hide ? '?' : `${e[0]}: ${bn(e[1])} × (${fON(e[2])})`; g.font = `bold 10px ${col.font}`; const fits = g.measureText(lab).width + 6 < ww; T(g, fits ? lab : (hide ? '?' : e[0]), x + ww / 2, y + 19, col, { b: true, s: 10, c: '#fff' }); } T(g, hide ? '' : (e[2] >= 0 ? '+' : '−'), x + ww / 2, y - 6, col, { s: 10, c: col.mu }); x += ww; });
      const sum = els.reduce((a, e) => a + e[1] * e[2], 0); T(g, `যোগফল = ${quiz && !quiz.done ? '?' : bn(+sum.toFixed(2))} = মোট আধান (${d[1] === 0 ? 'নিরপেক্ষ, ০' : `${bn(Math.abs(d[1]))}${d[1] < 0 ? '−' : '+'}`})`, W / 2, y + h + 24, col, { b: true, s: 11, c: '#2f9e44' });
      T(g, 'প্রতিটি মৌলের অবদান: (পরমাণু সংখ্যা × জারণ সংখ্যা)', W / 2, 16, col, { s: 9.5, c: col.mu });
    };
    const render = () => { const d = OX[ci]; tiles.innerHTML = d[2].map((e, i) => `<button class="btn ${i === sel ? 'primary' : ''}" data-el="${i}" style="min-width:64px;padding:8px 10px;display:flex;flex-direction:column;align-items:center"><b style="font-size:18px">${e[0]}</b><span class="small">${quiz && quiz.e === i && !quiz.done ? '?' : fON(e[2])}</span></button>`).join(''); tiles.querySelectorAll('[data-el]').forEach(b => b.onclick = () => { sel = +b.dataset.el; render(); }); const e = d[2][sel], hide = quiz && quiz.e === sel && !quiz.done; out.innerHTML = `<div style="font-size:18px;text-align:center"><b>${d[0]}</b></div><div class="small"><b>${e[0]}:</b> ${hide ? 'অনুমান করো…' : `${fON(e[2])} — ${e[3]}`}</div>${d[3] && !(quiz && !quiz.done) ? `<div class="small">${d[3]}</div>` : ''}`; draw(); };
    const newQ = () => { ci = Math.floor(Math.random() * OX.length); const d = OX[ci]; let e = d[2].findIndex(x => !/সাধারণ|গ্রুপ/.test(x[3])); if (e < 0) e = 0; quiz = { e, done: false }; sel = e; q('[data-c]').value = ci; const ans = d[2][e][2]; const opts = new Set([ans]); const pool = [-4, -3, -2, -1, -0.5, 0, 1, 2, 2.5, 3, 4, 5, 6, 7, 8 / 3]; while (opts.size < 4) opts.add(pool[Math.floor(Math.random() * pool.length)]); qa.style.display = 'flex'; qa.innerHTML = `<span class="small">${d[0]} এ ${d[2][e][0]} এর জারণ সংখ্যা:</span>` + [...opts].sort((a, b) => a - b).map(v => `<button class="btn sm" data-v="${v}">${fON(v)}</button>`).join('') + '<span class="small" data-fb></span>'; qa.querySelectorAll('[data-v]').forEach(b => b.onclick = () => { const ok = Math.abs(+b.dataset.v - ans) < 1e-6; quiz.done = true; qa.querySelector('[data-fb]').innerHTML = ok ? '✅ সঠিক!' : `❌ সঠিক উত্তর ${fON(ans)}`; render(); }); render(); };
    q('[data-c]').onchange = e => { ci = +e.target.value; sel = Math.max(0, OX[ci][2].findIndex(x => !/সাধারণ|গ্রুপ/.test(x[3]))); quiz = null; qa.style.display = 'none'; render(); };
    q('[data-qz]').onclick = newQ;
    sel = 1; render();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};
})();
