/* ২য় পত্র অধ্যায় ৩ visuals part 5 — 3.9.3 special redox types on an oxidation-number line; 3.10 ion-electron (half-reaction) balancing stepper with electron ledger */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit;max-width:100%">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const sON = v => (v > 0 ? '+' : v < 0 ? '−' : '') + bn(Math.abs(v));
const arrow = (g, x1, y1, x2, y2, c, w = 2) => { g.strokeStyle = c; g.fillStyle = c; g.lineWidth = w; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); const a = Math.atan2(y2 - y1, x2 - x1); g.beginPath(); g.moveTo(x2, y2); g.lineTo(x2 - 8 * Math.cos(a - 0.4), y2 - 8 * Math.sin(a - 0.4)); g.lineTo(x2 - 8 * Math.cos(a + 0.4), y2 - 8 * Math.sin(a + 0.4)); g.closePath(); g.fill(); };

/* ======================= ৩.৯.৩ বিশেষ রিডক্স বিক্রিয়া ======================= */
// [name, type, eq, [[element, from, to, label]], note]
const SR = [
  ['ঠান্ডা লঘু NaOH এ ক্লোরিন', 'অসামঞ্জস্য (disproportionation)', 'Cl2 + 2NaOH -> NaCl + NaOCl + H2O', [['Cl', 0, -1, 'NaCl'], ['Cl', 0, 1, 'NaOCl']], 'একই মৌল (Cl₂ এ ০) একই সাথে জারিত (+১) ও বিজারিত (−১) হয়। এভাবেই ব্লিচিং দ্রবণ (সোডিয়াম হাইপোক্লোরাইট) তৈরি হয়।'],
  ['গরম গাঢ় NaOH এ ক্লোরিন', 'অসামঞ্জস্য (disproportionation)', '3Cl2 + 6NaOH ->[\\Delta] 5NaCl + NaClO3 + 3H2O', [['Cl', 0, -1, 'NaCl (৫টি)'], ['Cl', 0, 5, 'NaClO₃ (১টি)']], '৫টি Cl পরমাণু প্রতিটি ১টি করে ইলেকট্রন গ্রহণ করে (মোট ৫), ১টি Cl পরমাণু ৫টি ইলেকট্রন ত্যাগ করে — ইলেকট্রন সমতা ৫ = ৫।'],
  ['হাইড্রোজেন পারঅক্সাইডের বিয়োজন', 'অসামঞ্জস্য (disproportionation)', '2H2O2 ->[\\text{MnO}_2] 2H2O + O2', [['O', -1, -2, 'H₂O'], ['O', -1, 0, 'O₂']], 'H₂O₂ এ O এর −১ অবস্থা মাঝামাঝি — তাই এটি নিজেই নিজেকে জারিত ও বিজারিত করে।'],
  ['Cu⁺ আয়নের জলীয় দ্রবণে আচরণ', 'অসামঞ্জস্য (disproportionation)', '2Cu+(aq) -> Cu(s) + Cu^2+(aq)', [['Cu', 1, 0, 'Cu'], ['Cu', 1, 2, 'Cu²⁺']], 'জলীয় দ্রবণে Cu⁺ অস্থিতিশীল, তাই Cu₂SO₄ দ্রবণ পাওয়া যায় না।'],
  ['H₂S ও SO₂ এর বিক্রিয়া', 'সমানুপাতিক (comproportionation)', '2H2S + SO2 -> 3S v + 2H2O', [['S', -2, 0, 'H₂S → S'], ['S', 4, 0, 'SO₂ → S']], 'দুটি ভিন্ন জারণ অবস্থার একই মৌল মিলে মাঝামাঝি একটি অবস্থায় আসে (অসামঞ্জস্যের বিপরীত)। আগ্নেয়গিরির আশেপাশে সালফার জমার একটি কারণ।'],
  ['আয়োডেট ও আয়োডাইড', 'সমানুপাতিক (comproportionation)', 'IO3- + 5I- + 6H+ -> 3I2 + 3H2O', [['I', 5, 0, 'IO₃⁻ → I₂'], ['I', -1, 0, 'I⁻ → I₂']], 'আয়োডিনযুক্ত লবণে KIO₃ শনাক্তকরণ ও আয়োডোমিতিতে নির্দিষ্ট পরিমাণ I₂ তৈরিতে ব্যবহৃত।'],
  ['পটাশিয়াম ক্লোরেটের তাপ বিয়োজন', 'আন্তঃআণবিক (intramolecular)', '2KClO3 ->[\\Delta][\\text{MnO}_2] 2KCl + 3O2', [['Cl', 5, -1, 'KCl'], ['O', -2, 0, 'O₂']], 'একই যৌগের ভিন্ন দুটি মৌল — একটি (Cl) বিজারিত, অপরটি (O) জারিত। জারক ও বিজারক একই অণুতে।'],
  ['অ্যামোনিয়াম নাইট্রাইটের বিয়োজন', 'আন্তঃআণবিক সমানুপাতিক', 'NH4NO2 ->[\\Delta] N2 + 2H2O', [['N', -3, 0, 'NH₄⁺ → N₂'], ['N', 3, 0, 'NO₂⁻ → N₂']], 'পরীক্ষাগারে বিশুদ্ধ N₂ প্রস্তুতি — একই যৌগের দুটি N পরমাণু মাঝামাঝি অবস্থায় (০) মিলিত হয়।'],
  ['অ্যামোনিয়াম ডাইক্রোমেটের বিয়োজন ("আগ্নেয়গিরি")', 'আন্তঃআণবিক (intramolecular)', '(NH4)2Cr2O7 ->[\\Delta] N2 + Cr2O3 + 4H2O', [['N', -3, 0, 'N₂ (২টি N, ৬e⁻ ত্যাগ)'], ['Cr', 6, 3, 'Cr₂O₃ (২টি Cr, ৬e⁻ গ্রহণ)']], 'কমলা কেলাস জ্বলে সবুজ Cr₂O₃ এর "ছাই" ছড়িয়ে পড়ে।'],
  ['তুলনা: অধঃক্ষেপণ (রিডক্স নয়)', 'রিডক্স নয়', 'AgNO3 + NaCl -> AgCl v + NaNO3', [['Ag', 1, 1, 'AgCl'], ['Cl', -1, -1, 'AgCl']], 'কোনো মৌলের জারণ সংখ্যা বদলায় না — তাই এটি জারণ-বিজারণ বিক্রিয়া নয়, কেবল আয়ন বিনিময়।']
];
V.p2c3_redoxType = {
  t: 'জারণ সংখ্যা রেখায় বিশেষ রিডক্স বিক্রিয়া: অসামঞ্জস্য (disproportionation), সমানুপাতিক (comproportionation) ও আন্তঃআণবিক জারণ-বিজারণ — জারণ সংখ্যার পরিবর্তনের তীর ও ইলেকট্রন হিসাব', k: ['anim', 'int'],
  cap: 'বিক্রিয়া বেছে নাও। জারণ সংখ্যার রেখায় (−৩ থেকে +৭) প্রতিটি পরিবর্তনশীল মৌলের শুরুর ও শেষের অবস্থান তীর দিয়ে দেখানো হয়: ডানদিকে (জারণ সংখ্যা বৃদ্ধি) লাল তীর = জারণ, বামদিকে (হ্রাস) নীল তীর = বিজারণ। অসামঞ্জস্যে একটি বিন্দু থেকে দুই দিকে দুটি তীর; সমানুপাতিকে দুই দিক থেকে একটি বিন্দুতে মিলন; আন্তঃআণবিকে একই যৌগের দুটি ভিন্ন মৌলের দুটি রেখা। শেষ উদাহরণটি তুলনার জন্য — জারণ সংখ্যা না বদলালে রিডক্স নয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-r', SR.map((s, i) => [String(i), s[0]]), '0')}</div>${X.cv('বিশেষ রিডক্স')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 240 : 280;
    let L = X.fit(c, hf), ri = 0, t = 0;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const s = SR[ri], els = [...new Set(s[3].map(x => x[0]))]; const x0 = 30, x1 = W - 20, lo = -3, hi = 7, Xo = v => x0 + (v - lo) / (hi - lo) * (x1 - x0);
      const u = Math.min(1, (t % 4) / 2);
      T(g, s[1], W / 2, 18, col, { b: true, s: 12, c: s[1].includes('নয়') ? col.mu : '#7048e8' });
      els.forEach((e, k) => { const y = 70 + k * (els.length > 1 ? (H - 110) / (els.length - 1 || 1) : 0) + (els.length === 1 ? (H - 110) / 2 - 20 : 0); g.strokeStyle = col.ln || col.mu; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x0, y); g.lineTo(x1, y); g.stroke(); for (let v = lo; v <= hi; v++) { const xx = Xo(v); g.beginPath(); g.moveTo(xx, y - 5); g.lineTo(xx, y + 5); g.stroke(); T(g, sON(v), xx, y + 18, col, { s: 9, c: v === 0 ? col.fg : col.mu, b: v === 0 }); } T(g, e, 12, y + 4, col, { b: true, s: 12 });
        s[3].filter(x => x[0] === e).forEach(([, f, to, lab], j) => { const xf = Xo(f), xt = Xo(to); g.fillStyle = col.fg; g.beginPath(); g.arc(xf, y, 5, 0, 7); g.fill(); if (f === to) { T(g, `${lab}: অপরিবর্তিত (${sON(f)})`, xf, y - 14 - j * 14, col, { s: 9.5, c: col.mu }); return; } const ox = to > f, cc = ox ? '#e03131' : '#1c7ed6', dy = (j % 2 ? 1 : -1) * 18; const xe = xf + (xt - xf) * u; g.setLineDash([]); g.strokeStyle = cc; g.lineWidth = 2.2; g.beginPath(); g.moveTo(xf, y); g.quadraticCurveTo((xf + xe) / 2, y + dy * 1.8, xe, y); g.stroke(); if (u > 0.95) { arrow(g, xt - (ox ? 9 : -9), y + dy * 0.35, xt, y, cc); g.fillStyle = cc; g.beginPath(); g.arc(xt, y, 5, 0, 7); g.fill(); } const ne = Math.abs(to - f); T(g, `${lab} · ${ox ? 'জারণ' : 'বিজারণ'} (${ox ? '+' : '−'}${bn(ne)})`, (xf + xt) / 2, y + dy * 1.3 + (dy > 0 ? 12 : -4), col, { s: 9.5, b: true, c: cc }); }); });
    };
    const info = () => { const s = SR[ri]; out.innerHTML = `${TXB(`\\ce{${s[2]}}`)}<div class="small">${s[3].map(x => `${x[0]}: ${sON(x[1])} → ${sON(x[2])} (${x[3]})`).join('; ')}</div><div class="small">${s[4]}</div>`; };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    q('[data-r]').onchange = e => { ri = +e.target.value; t = 0; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.১০ অর্ধ-বিক্রিয়া পদ্ধতিতে সমতাকরণ ======================= */
// each: {t, med, on:[[el, from, to, per-atom count in formula unit (atoms changing)]], steps:[[heading, [tex lines], note]], e:[lost per ox unit, gained per red unit, multOx, multRed]}
const HR = [
  { t: 'MnO₄⁻ + Fe²⁺ (অম্লীয়)', on: [['Mn', 7, 2, 1], ['Fe', 2, 3, 1]], e: [1, 5, 5, 1], steps: [
    ['কঙ্কাল সমীকরণ', ['MnO4- + Fe^2+ -> Mn^2+ + Fe^3+'], 'KMnO₄ দিয়ে Fe²⁺ (মোর লবণ) এর টাইট্রেশন — অম্লীয় মাধ্যম (লঘু H₂SO₄)।'],
    ['জারণ সংখ্যার পরিবর্তন', ['{+7}MnO4- -> {+2}Mn^2+', '{+2}Fe^2+ -> {+3}Fe^3+'], 'Mn: +৭ → +২ (৫টি ইলেকট্রন গ্রহণ, বিজারণ); Fe: +২ → +৩ (১টি ইলেকট্রন ত্যাগ, জারণ)।'],
    ['অর্ধ-বিক্রিয়ায় ভাগ', ['জারণ:\\; Fe^2+ -> Fe^3+', 'বিজারণ:\\; MnO4- -> Mn^2+'], 'O ও H বাদে অন্য মৌল দুই পাশে আগে থেকেই সমান।'],
    ['O সমতা (H₂O যোগ)', ['MnO4- -> Mn^2+ + 4H2O'], 'যে পাশে O কম, সেখানে প্রতিটি ঘাটতি O এর জন্য একটি H₂O।'],
    ['H সমতা (H⁺ যোগ)', ['MnO4- + 8H+ -> Mn^2+ + 4H2O'], 'অম্লীয় মাধ্যমে যে পাশে H কম সেখানে H⁺।'],
    ['আধান সমতা (e⁻ যোগ)', ['MnO4- + 8H+ + 5e- -> Mn^2+ + 4H2O', 'Fe^2+ -> Fe^3+ + e-'], 'বামে আধান −১ + ৮ = +৭, ডানে +২ ⇒ বামে ৫e⁻। ইলেকট্রন সংখ্যা জারণ সংখ্যার পরিবর্তনের সাথে মেলে ✓।'],
    ['ইলেকট্রন সমান করতে গুণ', ['MnO4- + 8H+ + 5e- -> Mn^2+ + 4H2O \\quad (\\times 1)', '5Fe^2+ -> 5Fe^3+ + 5e- \\quad (\\times 5)'], 'ত্যাগকৃত ইলেকট্রন = গৃহীত ইলেকট্রন = ৫।'],
    ['যোগ ও কাটাকাটি', ['MnO4- + 8H+ + 5Fe^2+ -> Mn^2+ + 5Fe^3+ + 4H2O'], 'দুই পাশের ৫e⁻ কেটে যায়।'],
    ['যাচাই ও আণবিক রূপ', ['2KMnO4 + 10FeSO4 + 8H2SO4 -> K2SO4 + 2MnSO4 + 5Fe2(SO4)3 + 8H2O'], 'আধান: বাম −১ + ৮ + ১০ = +১৭; ডান +২ + ১৫ = +১৭ ✓। মোল অনুপাত MnO₄⁻ : Fe²⁺ = ১ : ৫ — টাইট্রেশন গণনার মূল।']] },
  { t: 'Cr₂O₇²⁻ + Fe²⁺ (অম্লীয়)', on: [['Cr', 6, 3, 2], ['Fe', 2, 3, 1]], e: [1, 6, 6, 1], steps: [
    ['কঙ্কাল সমীকরণ', ['Cr2O7^2- + Fe^2+ -> Cr^3+ + Fe^3+'], 'ডাইক্রোমেট টাইট্রেশন — নির্দেশক ডাইফিনাইলঅ্যামিন।'],
    ['জারণ সংখ্যার পরিবর্তন', ['{+6}Cr2O7^2- -> {+3}Cr^3+', '{+2}Fe^2+ -> {+3}Fe^3+'], 'প্রতি Cr এ ৩টি, প্রতি Cr₂O₇²⁻ এ ৬টি ইলেকট্রন গ্রহণ।'],
    ['অর্ধ-বিক্রিয়ায় ভাগ ও Cr সমতা', ['জারণ:\\; Fe^2+ -> Fe^3+', 'বিজারণ:\\; Cr2O7^2- -> 2Cr^3+'], 'আগে O ও H ছাড়া অন্য মৌল (Cr) সমান করো।'],
    ['O সমতা', ['Cr2O7^2- -> 2Cr^3+ + 7H2O'], ''],
    ['H সমতা', ['Cr2O7^2- + 14H+ -> 2Cr^3+ + 7H2O'], ''],
    ['আধান সমতা', ['Cr2O7^2- + 14H+ + 6e- -> 2Cr^3+ + 7H2O', 'Fe^2+ -> Fe^3+ + e-'], 'বামে −২ + ১৪ = +১২, ডানে +৬ ⇒ ৬e⁻।'],
    ['গুণ', ['6Fe^2+ -> 6Fe^3+ + 6e- \\quad (\\times 6)'], ''],
    ['যোগ', ['Cr2O7^2- + 14H+ + 6Fe^2+ -> 2Cr^3+ + 6Fe^3+ + 7H2O'], ''],
    ['যাচাই', ['K2Cr2O7 + 6FeSO4 + 7H2SO4 -> K2SO4 + Cr2(SO4)3 + 3Fe2(SO4)3 + 7H2O'], 'আধান: −২ + ১৪ + ১২ = +২৪; ৬ + ১৮ = +২৪ ✓। Cr₂O₇²⁻ : Fe²⁺ = ১ : ৬।']] },
  { t: 'MnO₄⁻ + C₂O₄²⁻ (অম্লীয়, ৬০–৭০ °C)', on: [['Mn', 7, 2, 1], ['C', 3, 4, 2]], e: [2, 5, 5, 2], steps: [
    ['কঙ্কাল সমীকরণ', ['MnO4- + C2O4^2- -> Mn^2+ + CO2'], 'অক্সালিক এসিড/সোডিয়াম অক্সালেট দিয়ে KMnO₄ এর প্রমিতকরণ।'],
    ['জারণ সংখ্যার পরিবর্তন', ['{+7}Mn -> {+2}Mn', '{+3}C2O4^2- -> {+4}CO2'], 'প্রতি C এ ১, প্রতি অক্সালেটে ২টি ইলেকট্রন ত্যাগ।'],
    ['অর্ধ-বিক্রিয়া ও C সমতা', ['জারণ:\\; C2O4^2- -> 2CO2', 'বিজারণ:\\; MnO4- -> Mn^2+'], ''],
    ['O সমতা', ['MnO4- -> Mn^2+ + 4H2O'], 'অক্সালেট অর্ধে O ইতিমধ্যে সমান (৪ = ৪)।'],
    ['H সমতা', ['MnO4- + 8H+ -> Mn^2+ + 4H2O'], ''],
    ['আধান সমতা', ['MnO4- + 8H+ + 5e- -> Mn^2+ + 4H2O', 'C2O4^2- -> 2CO2 + 2e-'], ''],
    ['গুণ (ল.সা.গু. ১০)', ['2MnO4- + 16H+ + 10e- -> 2Mn^2+ + 8H2O \\quad (\\times 2)', '5C2O4^2- -> 10CO2 + 10e- \\quad (\\times 5)'], ''],
    ['যোগ', ['2MnO4- + 16H+ + 5C2O4^2- -> 2Mn^2+ + 10CO2 + 8H2O'], ''],
    ['যাচাই', ['2KMnO4 + 5H2C2O4 + 3H2SO4 -> K2SO4 + 2MnSO4 + 10CO2 + 8H2O'], 'আধান: −২ + ১৬ − ১০ = +৪; +৪ ✓। MnO₄⁻ : C₂O₄²⁻ = ২ : ৫। উৎপন্ন Mn²⁺ বিক্রিয়াকে প্রভাবিত করে (স্বপ্রভাবন), তাই শুরুতে ধীর, পরে দ্রুত।']] },
  { t: 'Cu + লঘু HNO₃', on: [['N', 5, 2, 1], ['Cu', 0, 2, 1]], e: [2, 3, 3, 2], steps: [
    ['কঙ্কাল সমীকরণ', ['Cu + NO3- -> Cu^2+ + NO'], 'লঘু নাইট্রিক এসিডে কপার দ্রবীভূত হয়ে বর্ণহীন NO দেয় (বাতাসে বাদামি NO₂ হয়)।'],
    ['জারণ সংখ্যার পরিবর্তন', ['{0}Cu -> {+2}Cu^2+', '{+5}NO3- -> {+2}NO'], 'N: +৫ → +২ (৩e⁻ গ্রহণ); Cu: ০ → +২ (২e⁻ ত্যাগ)।'],
    ['অর্ধ-বিক্রিয়ায় ভাগ', ['জারণ:\\; Cu -> Cu^2+', 'বিজারণ:\\; NO3- -> NO'], ''],
    ['O সমতা', ['NO3- -> NO + 2H2O'], ''],
    ['H সমতা', ['NO3- + 4H+ -> NO + 2H2O'], ''],
    ['আধান সমতা', ['NO3- + 4H+ + 3e- -> NO + 2H2O', 'Cu -> Cu^2+ + 2e-'], ''],
    ['গুণ (ল.সা.গু. ৬)', ['2NO3- + 8H+ + 6e- -> 2NO + 4H2O \\quad (\\times 2)', '3Cu -> 3Cu^2+ + 6e- \\quad (\\times 3)'], ''],
    ['যোগ', ['3Cu + 2NO3- + 8H+ -> 3Cu^2+ + 2NO + 4H2O'], ''],
    ['যাচাই ও আণবিক রূপ', ['3Cu + 8HNO3 -> 3Cu(NO3)2 + 2NO ^ + 4H2O'], 'আণবিক রূপে ৮টি HNO₃ এর মাত্র ২টি জারক, বাকি ৬টি লবণ গঠনে (এসিড হিসেবে) কাজ করে।']] },
  { t: 'I₂ + S₂O₃²⁻ (আয়োডোমিতি)', on: [['I', 0, -1, 2], ['S', 2, 2.5, 4]], e: [2, 2, 1, 1], steps: [
    ['কঙ্কাল সমীকরণ', ['I2 + S2O3^2- -> I- + S4O6^2-'], 'আয়োডোমিতির শেষ ধাপ — নির্দেশক স্টার্চ (নীল → বর্ণহীন)।'],
    ['জারণ সংখ্যার পরিবর্তন', ['{0}I2 -> {-1}I-', '{+2}S2O3^2- -> {+2.5}S4O6^2-'], 'প্রতি I₂ এ ২টি ইলেকট্রন গ্রহণ; প্রতি দুটি S₂O₃²⁻ থেকে ২টি ইলেকট্রন ত্যাগ (প্রতি S এ ০.৫)।'],
    ['অর্ধ-বিক্রিয়া ও মৌল সমতা', ['জারণ:\\; 2S2O3^2- -> S4O6^2-', 'বিজারণ:\\; I2 -> 2I-'], 'এখানে O ও H সমতার প্রয়োজন নেই।'],
    ['আধান সমতা', ['2S2O3^2- -> S4O6^2- + 2e-', 'I2 + 2e- -> 2I-'], 'বামে −৪, ডানে −২ ⇒ ডানে ২e⁻।'],
    ['যোগ', ['I2 + 2S2O3^2- -> 2I- + S4O6^2-'], 'ইলেকট্রন ইতিমধ্যে সমান — গুণ লাগে না।'],
    ['যাচাই', ['I2 + 2Na2S2O3 -> 2NaI + Na2S4O6'], 'আধান: −৪ = −২ − ২ ✓। I₂ : S₂O₃²⁻ = ১ : ২।']] },
  { t: 'Cl₂ + গরম গাঢ় OH⁻ (ক্ষারীয়, অসামঞ্জস্য)', on: [['Cl', 0, 5, 1], ['Cl', 0, -1, 1]], e: [5, 1, 1, 5], steps: [
    ['কঙ্কাল সমীকরণ', ['Cl2 + OH- -> Cl- + ClO3-'], 'ক্ষারীয় মাধ্যম: প্রথমে অম্লীয় মাধ্যমের মতো সমতা করে পরে H⁺ এর সমান OH⁻ দুই পাশে যোগ করা হয়।'],
    ['জারণ সংখ্যার পরিবর্তন', ['{0}Cl2 -> {-1}Cl-', '{0}Cl2 -> {+5}ClO3-'], 'একই Cl₂ থেকে জারণ (০ → +৫) ও বিজারণ (০ → −১)।'],
    ['অর্ধ-বিক্রিয়া ও Cl সমতা', ['জারণ:\\; Cl2 -> 2ClO3-', 'বিজারণ:\\; Cl2 -> 2Cl-'], ''],
    ['O ও H সমতা (অম্লীয় ধরে)', ['Cl2 + 6H2O -> 2ClO3- + 12H+'], ''],
    ['ক্ষারীয় রূপান্তর (দুই পাশে ১২OH⁻)', ['Cl2 + 12OH- -> 2ClO3- + 6H2O'], '১২H⁺ + ১২OH⁻ = ১২H₂O; দুই পাশের পানি কাটাকাটি।'],
    ['আধান সমতা', ['Cl2 + 12OH- -> 2ClO3- + 6H2O + 10e-', 'Cl2 + 2e- -> 2Cl-'], 'বামে −১২, ডানে −২ ⇒ ১০e⁻।'],
    ['গুণ', ['5Cl2 + 10e- -> 10Cl- \\quad (\\times 5)'], ''],
    ['যোগ ও সরলীকরণ', ['6Cl2 + 12OH- -> 10Cl- + 2ClO3- + 6H2O', '3Cl2 + 6OH- -> 5Cl- + ClO3- + 3H2O'], '২ দিয়ে ভাগ করে ক্ষুদ্রতম পূর্ণসংখ্যা।'],
    ['যাচাই ও আণবিক রূপ', ['3Cl2 + 6NaOH ->[\\Delta] 5NaCl + NaClO3 + 3H2O'], 'আধান: −৬ = −৫ − ১ ✓।']] },
  { t: 'MnO₄⁻ + H₂O₂ (অম্লীয়)', on: [['Mn', 7, 2, 1], ['O', -1, 0, 2]], e: [2, 5, 5, 2], steps: [
    ['কঙ্কাল সমীকরণ', ['MnO4- + H2O2 -> Mn^2+ + O2'], 'এখানে H₂O₂ বিজারক হিসেবে কাজ করে।'],
    ['জারণ সংখ্যার পরিবর্তন', ['{+7}Mn -> {+2}Mn', 'H2{-1}O2 -> {0}O2'], 'প্রতি H₂O₂ থেকে ২টি ইলেকট্রন ত্যাগ।'],
    ['অর্ধ-বিক্রিয়ায় ভাগ', ['জারণ:\\; H2O2 -> O2', 'বিজারণ:\\; MnO4- -> Mn^2+'], ''],
    ['O ও H সমতা', ['H2O2 -> O2 + 2H+', 'MnO4- + 8H+ -> Mn^2+ + 4H2O'], ''],
    ['আধান সমতা', ['H2O2 -> O2 + 2H+ + 2e-', 'MnO4- + 8H+ + 5e- -> Mn^2+ + 4H2O'], ''],
    ['গুণ (ল.সা.গু. ১০)', ['5H2O2 -> 5O2 + 10H+ + 10e- \\quad (\\times 5)', '2MnO4- + 16H+ + 10e- -> 2Mn^2+ + 8H2O \\quad (\\times 2)'], ''],
    ['যোগ ও H⁺ কাটাকাটি', ['2MnO4- + 5H2O2 + 6H+ -> 2Mn^2+ + 5O2 + 8H2O'], 'বামের ১৬H⁺ থেকে ডানের ১০H⁺ বাদ ⇒ ৬H⁺।'],
    ['যাচাই', ['2KMnO4 + 5H2O2 + 3H2SO4 -> K2SO4 + 2MnSO4 + 5O2 + 8H2O'], 'আধান: −২ + ৬ = +৪; +৪ ✓।']] }
];

const ceON = s => s.split(/(\{[+\-−0-9.]+\}[A-Z][a-z]?\d*(?:\^\d*[+\-]|[+\-](?=\s|$))?)/).filter(x => x !== '').map(seg => { const m = seg.match(/^\{([+\-−0-9.]+)\}(.+)$/); return m ? `\\overset{${m[1]}}{\\ce{${m[2]}}}` : (seg.trim() ? `\\ce{${seg}}` : ''); }).join('');
const fmt = line => { let lab = ''; const m = line.match(/^(জারণ|বিজারণ):\; (.*)$/); if (m) { lab = m[1]; line = m[2]; } let tail = ''; const qi = line.indexOf('\\quad'); if (qi >= 0) { tail = line.slice(qi); line = line.slice(0, qi); } const body = /\{[+\-−0-9.]+\}[A-Z]/.test(line) ? ceON(line) : `\\ce{${line}}`; return `<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">${lab ? `<span class="small"><b>${lab}:</b></span>` : ''}${TXB(body + tail)}</div>`; };
V.p2c3_halfRxn = {
  t: 'আয়ন-ইলেকট্রন (অর্ধ-বিক্রিয়া) পদ্ধতিতে রিডক্স সমীকরণ সমতাকরণ: ধাপে ধাপে — জারণ সংখ্যা, O ও H সমতা (অম্লীয় ও ক্ষারীয় মাধ্যম), ইলেকট্রন সমতা; ইলেকট্রন খাতা ও জারণ সংখ্যা রেখা', k: ['int', 'calc'],
  cap: 'বিক্রিয়া বেছে "পরের ধাপ" চাপো। প্রতিটি ধাপে সমীকরণ ও ব্যাখ্যা দেখানো হয়। উপরের চিত্রে বামে জারণ সংখ্যা রেখায় জারিত (লাল, ডানমুখী) ও বিজারিত (নীল, বামমুখী) মৌলের পরিবর্তন; ডানে "ইলেকট্রন খাতা" — জারণ অর্ধ-বিক্রিয়ায় ত্যাগকৃত ও বিজারণ অর্ধ-বিক্রিয়ায় গৃহীত ইলেকট্রনের বাক্স। গুণের ধাপে খাতার দুই পাশ সমান হয় — এটাই রিডক্স সমতার মূলনীতি: ত্যাগকৃত ইলেকট্রন = গৃহীত ইলেকট্রন।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-r', HR.map((s, i) => [String(i), s.t]), '0')}<button class="btn sm" data-pv>◀ আগের</button><button class="btn sm primary" data-nx>পরের ধাপ ▶</button><button class="btn sm" data-al>সব ধাপ</button></div>${X.cv('ইলেকট্রন খাতা')}<div data-steps></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), sd = el.querySelector('[data-steps]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 170 : 300;
    let L = X.fit(c, hf), ri = 0, k = 0, all = false;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const r = HR[ri], wd = wide(W), n = r.steps.length;
      // ON line
      const lw = wd ? W * 0.48 : W - 30, x0 = 24, lo = -2, hi = 7, Xo = v => x0 + (v - lo) / (hi - lo) * (lw - 10); const showON = k >= 1;
      r.on.forEach(([e, f, to], i) => { const y = 34 + i * 52; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x0, y); g.lineTo(x0 + lw - 10, y); g.stroke(); for (let v = lo; v <= hi; v++) { const xx = Xo(v); g.beginPath(); g.moveTo(xx, y - 4); g.lineTo(xx, y + 4); g.stroke(); T(g, sON(v), xx, y + 16, col, { s: 8.5, c: col.mu }); } T(g, e, 10, y + 4, col, { b: true, s: 11 }); if (showON) { const ox = to > f, cc = ox ? '#e03131' : '#1c7ed6'; arrow(g, Xo(f), y - 8, Xo(to), y - 8, cc, 2.5); g.fillStyle = cc; g.beginPath(); g.arc(Xo(f), y, 4, 0, 7); g.fill(); T(g, ox ? 'জারণ' : 'বিজারণ', (Xo(f) + Xo(to)) / 2, y - 14, col, { s: 9, b: true, c: cc }); } });
      // ledger
      const lx = wd ? W * 0.55 : 12, ly = wd ? 16 : 140, lW = wd ? W * 0.42 : W - 24; const [eo, er, mo, mr] = r.e; const mult = k >= Math.max(0, n - 3); const lost = showON ? eo * (mult ? mo : 1) : 0, gain = showON ? er * (mult ? mr : 1) : 0, mx = Math.max(eo * mo, er * mr, 1);
      T(g, 'ইলেকট্রন খাতা', lx + lW / 2, ly + 8, col, { b: true, s: 11 }); const bw = Math.min(16, (lW / 2 - 20) / Math.min(mx, 10)), rowsN = Math.ceil(mx / 10);
      [[lost, 'ত্যাগ (জারণ)', '#e03131', lx + 6], [gain, 'গ্রহণ (বিজারণ)', '#1c7ed6', lx + lW / 2 + 6]].forEach(([nn, lab, cc, bx]) => { T(g, `${lab}: ${bn(nn)}e⁻`, bx + (lW / 2 - 12) / 2, ly + 28, col, { s: 9.5, b: true, c: cc }); for (let i = 0; i < nn; i++) { const xx = bx + (i % 10) * (bw + 2), yy = ly + 38 + Math.floor(i / 10) * (bw + 2); g.fillStyle = cc; g.globalAlpha = 0.85; g.fillRect(xx, yy, bw, bw); g.globalAlpha = 1; T(g, 'e', xx + bw / 2, yy + bw * 0.72, col, { s: Math.max(7, bw * 0.6), c: '#fff', b: true }); } });
      const ok = showON && lost === gain; T(g, !showON ? '' : ok ? '✓ ত্যাগ = গ্রহণ' : `ল.সা.গু. করতে গুণ: জারণ × ${bn(mo)}, বিজারণ × ${bn(mr)}`, lx + lW / 2, ly + 52 + rowsN * (bw + 2) + 6, col, { b: true, s: 10, c: ok ? '#2f9e44' : '#e67700' });
      T(g, `ধাপ ${bn(Math.min(k + 1, n))}/${bn(n)}`, W - 30, H - 6, col, { s: 9, c: col.mu });
    };
    const render = () => { const r = HR[ri], upto = all ? r.steps.length - 1 : k; sd.innerHTML = r.steps.slice(0, upto + 1).map(([h, tx, note], i) => `<div class="calc-out" style="margin:6px 0;${i === upto ? 'border-left:4px solid var(--accent)' : 'opacity:.75'}"><div class="small"><b>ধাপ ${bn(i + 1)} — ${h}</b></div>${tx.map(fmt).join('')}${note ? `<div class="small">${note}</div>` : ''}</div>`).join(''); draw(); };
    q('[data-r]').onchange = e => { ri = +e.target.value; k = 0; all = false; render(); };
    q('[data-nx]').onclick = () => { k = Math.min(HR[ri].steps.length - 1, k + 1); all = false; render(); };
    q('[data-pv]').onclick = () => { k = Math.max(0, k - 1); all = false; render(); };
    q('[data-al]').onclick = () => { all = true; k = HR[ri].steps.length - 1; render(); };
    render();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};
})();
