/* ২য় পত্র অধ্যায় ৩ visuals part 10 — chapter concept map */
(function () {
'use strict';
const V = window.VIS, X = window.VX, P2 = window.P2V;
const wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
const CG = [['A', 'রাসায়নিক গণনা', '#3b5bdb'], ['B', 'দ্রবণের ঘনমাত্রা', '#0c8599'], ['C', 'টাইট্রেশন ও রিডক্স', '#e8590c'], ['D', 'যন্ত্রভিত্তিক বিশ্লেষণ', '#7048e8']];
const CN = [
  ['mol', 'মোল ও মোলার আয়তন', 'A', 'n = m/M = N/N_A = V/২২.৪ L — সব পরিমাণগত গণনার কেন্দ্র', 'p2c3s1a'],
  ['bal', 'সুষম ও আয়নিক সমীকরণ', 'A', 'সহগ = মোল অনুপাত; নিট আয়নিক সমীকরণে দর্শক আয়ন বাদ', 'p2c3s1b'],
  ['gl', 'গে-লুসাক ও গ্যাসের আয়তন', 'A', 'একই T, P তে গ্যাসের আয়তন অনুপাত = সহগ অনুপাত; PV = nRT', 'p2c3s1d'],
  ['lim', 'সীমিত বিক্রিয়ক ও উৎপাদন', 'A', 'মোল ÷ সহগ সবচেয়ে কম যেটির সেটি সীমিত; শতকরা উৎপাদন ও বিশুদ্ধতা', 'p2c3s2b'],
  ['M', 'মোলারিটি ও প্রমাণ দ্রবণ', 'B', 'M = n/V(L); প্রাইমারি স্ট্যান্ডার্ড Na₂CO₃, অক্সালিক এসিড, K₂Cr₂O₇', 'p2c3s3a'],
  ['pct', 'শতকরা ও ppm', 'B', 'M = %×d×১০/Mᵣ; ppm = M×Mᵣ×১০০০; আর্সেনিক মান ৫০ ppb', 'p2c3s3b'],
  ['dil', 'লঘুকরণ C₁V₁ = C₂V₂', 'B', 'লঘুকরণে দ্রবের মোল অপরিবর্তিত; ধারাবাহিক লঘুকরণ', 'p2c3s3d'],
  ['neu', 'প্রশমন ও প্রশমন বিন্দু', 'C', 'H⁺ + OH⁻ → H₂O; nₐMₐVₐ = n_bM_bV_b; প্রশমন তাপ −৫৭.৩ kJ/mol', 'p2c3s4a'],
  ['ox', 'জারণ সংখ্যা ও জারক-বিজারক', 'C', 'জারণ = ইলেকট্রন ত্যাগ; জারক নিজে বিজারিত হয়', 'p2c3s5a'],
  ['half', 'অর্ধ-বিক্রিয়া ও রিডক্স গণনা', 'C', 'MnO₄⁻ : Fe²⁺ = ১ : ৫; M₁V₁n₁ = M₂V₂n₂', 'p2c3s6a'],
  ['ind', 'নির্দেশক', 'C', 'পরিসর pK_In ± ১; খাড়া অংশের সাথে মিলিয়ে বাছাই', 'p2c3s7a'],
  ['tit', 'টাইট্রেশন ও আয়োডোমিতি', 'C', 'সামঞ্জস্যপূর্ণ পাঠ; KMnO₄ স্বনির্দেশক; 2Cu²⁺ ≡ I₂ ≡ 2S₂O₃²⁻', 'p2c3s8a'],
  ['bl', 'বিয়ার-ল্যাম্বার্ট সূত্র', 'D', 'A = εlc = log(I₀/I); প্রমাণ রেখা থেকে অজানা ঘনমাত্রা', 'p2c3s9a'],
  ['aas', 'পারমাণবিক শোষণ (AAS)', 'D', 'ফাঁপা ক্যাথোড ল্যাম্প ও শিখায় মুক্ত পরমাণুর নির্দিষ্ট রেখা শোষণ — ভারী ধাতু নির্ণয়', 'p2c3s9b'],
  ['uv', 'UV-Vis বর্ণালি', 'D', 'π→π*, n→π*; সংযুক্তি বাড়লে λmax বাড়ে; পরিপূরক রং', 'p2c3s9c'],
  ['chr', 'ক্রোমাটোগ্রাফি (HPLC, GC)', 'D', 'স্থির ও মোবাইল দশায় বণ্টনের পার্থক্যে পৃথকীকরণ; সংরক্ষণ সময়ে শনাক্তকরণ, ক্ষেত্রফলে পরিমাণ', 'p2c3s10a']
];
const CE = [['mol', 'bal', 'সহগ = মোল'], ['mol', 'gl', '২২.৪ L/mol'], ['bal', 'lim', 'মোল অনুপাত'], ['gl', 'lim', 'উৎপাদ গ্যাস'], ['mol', 'M', 'প্রতি লিটারে মোল'], ['M', 'pct', 'একক রূপান্তর'], ['M', 'dil', 'n = CV'], ['M', 'neu', 'MV = মোল'], ['bal', 'neu', 'নিট আয়নিক'], ['bal', 'half', 'আধান সমতা'], ['ox', 'half', 'ইলেকট্রন হিসাব'], ['neu', 'ind', 'প্রশমন বিন্দুর pH'], ['ind', 'tit', 'সমাপ্তি বিন্দু'], ['half', 'tit', 'রিডক্স টাইট্রেশন'], ['dil', 'bl', 'প্রমাণ দ্রবণ সারি'], ['pct', 'aas', 'ppm/ppb স্তর'], ['bl', 'aas', 'A ∝ c'], ['bl', 'uv', 'λmax'], ['uv', 'chr', 'UV ডিটেক্টর'], ['pct', 'chr', 'ভেজাল/দূষক']];
V.p2c3_conceptMap = {
  t: 'অধ্যায় ৩ (পরিমাণগত রসায়ন) এর ধারণা মানচিত্র: ১৬টি মূল ধারণা চারটি স্তম্ভে — রাসায়নিক গণনা, দ্রবণের ঘনমাত্রা, টাইট্রেশন ও রিডক্স, যন্ত্রভিত্তিক বিশ্লেষণ — ও তাদের সংযোগ', k: ['int', '2d'],
  cap: 'যেকোনো ধারণায় চাপ দাও: সংযুক্ত রেখা ও সংযোগের কারণ উজ্জ্বল হয়; নিচে মূল তথ্য ও সরাসরি সেই পাঠে যাওয়ার বোতাম। পুরো অধ্যায়ের যুক্তি: মোল সব গণনার কেন্দ্র → সুষম সমীকরণ মোল অনুপাত দেয় → দ্রবণে মোল = মোলারিটি × আয়তন → টাইট্রেশনে প্রশমন বা ইলেকট্রন সমতা থেকে অজানা ঘনমাত্রা → যন্ত্রে আলো শোষণ বা পৃথকীকরণ দিয়ে অতি লঘু পরিমাণ নির্ণয়।',
  html: () => `${X.cv('অধ্যায় ৩ এর ধারণা মানচিত্র')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 470 : 760;
    let L = X.fit(c, hf), sel = 'mol', boxes = [];
    const layout = () => { const { W, H } = L, wd = wide(W), P = {}; CG.forEach(([gid], gi) => { const ns = CN.filter(n => n[2] === gid); ns.forEach((n, j) => { if (wd) { const cw = (W - 20) / 4; P[n[0]] = [10 + cw * (gi + 0.5), 56 + j * ((H - 70) / Math.max(4, ns.length))]; } else { const rowsBefore = CG.slice(0, gi).reduce((a, [g2]) => a + Math.ceil(CN.filter(z => z[2] === g2).length / 2), 0); const r = rowsBefore + Math.floor(j / 2); P[n[0]] = [W * (j % 2 ? 0.74 : 0.26), 50 + gi * 30 + r * 64]; } }); }); return P; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), P = layout(); boxes = [];
      if (wd) CG.forEach(([gid, nm, cc], gi) => { const cw = (W - 20) / 4; g.fillStyle = cc; g.globalAlpha = 0.07; rr(g, 12 + cw * gi, 6, cw - 4, H - 12, 12); g.fill(); g.globalAlpha = 1; T(g, nm, 10 + cw * (gi + 0.5), 24, col, { b: true, s: 10, c: cc }); });
      else CG.forEach(([gid, nm, cc], gi) => { const ns = CN.filter(n => n[2] === gid), y0 = P[ns[0][0]][1] - 34; T(g, nm, W / 2, y0 + 4, col, { b: true, s: 10, c: cc }); });
      CE.forEach(([a, b, lab]) => { const on = a === sel || b === sel, pa = P[a], pb = P[b]; g.strokeStyle = on ? col.acc : col.mu; g.globalAlpha = on ? 1 : 0.25; g.lineWidth = on ? 2 : 1; g.beginPath(); g.moveTo(pa[0], pa[1]); g.bezierCurveTo(pa[0] + (pb[0] - pa[0]) * 0.5, pa[1], pa[0] + (pb[0] - pa[0]) * 0.5, pb[1], pb[0], pb[1]); g.stroke(); g.globalAlpha = 1; if (on) { const mx = (pa[0] + pb[0]) / 2, my = (pa[1] + pb[1]) / 2; g.font = `9px ${col.font}`; const tw = g.measureText(lab).width + 8; g.fillStyle = col.sf; rr(g, mx - tw / 2, my - 8, tw, 14, 5); g.fill(); T(g, lab, mx, my + 3, col, { s: 9, c: col.acc }); } });
      CN.forEach(n => { const [x, y] = P[n[0]], cc = CG.find(z => z[0] === n[2])[2], on = n[0] === sel; g.font = `${on ? 'bold ' : ''}${wd ? 9.5 : 9}px ${col.font}`; const words = n[1].split(' '), lines = []; let ln = ''; const mw = wd ? (W - 20) / 4 - 20 : W * 0.44; words.forEach(w2 => { if (g.measureText(ln + ' ' + w2).width > mw - 12 && ln) { lines.push(ln); ln = w2; } else ln = ln ? ln + ' ' + w2 : w2; }); lines.push(ln); const bw = Math.min(mw, Math.max(...lines.map(s => g.measureText(s).width)) + 14), bh = lines.length * 12 + 10; g.fillStyle = on ? cc : col.sf; g.strokeStyle = cc; g.lineWidth = on ? 2 : 1.2; rr(g, x - bw / 2, y - bh / 2, bw, bh, 8); g.fill(); g.stroke(); lines.forEach((s, i) => T(g, s, x, y - bh / 2 + 15 + i * 12, col, { s: wd ? 9.5 : 9, b: on, c: on ? '#fff' : col.fg })); boxes.push([x - bw / 2, y - bh / 2, bw, bh, n[0]]); });
    };
    const info = () => { const n = CN.find(z => z[0] === sel), links = CE.filter(([a, b]) => a === sel || b === sel).map(([a, b, lab]) => { const o = CN.find(z => z[0] === (a === sel ? b : a)); return `${o[1]} (${lab})`; }); out.innerHTML = `<div><b>${n[1]}:</b> ${n[3]}।</div><div class="small" style="margin-top:4px">সংযোগ: ${links.join('; ')}।</div><div style="margin-top:6px"><button class="btn sm" data-act="lesson" data-id="${n[4]}">এই পাঠে যাও →</button></div>`; };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, b = boxes.find(z => x >= z[0] && x <= z[0] + z[2] && y >= z[1] && y <= z[1] + z[3]); if (b) { sel = b[4]; info(); draw(); } });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};
})();
