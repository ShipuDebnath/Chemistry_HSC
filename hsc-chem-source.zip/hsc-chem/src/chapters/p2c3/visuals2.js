/* ২য় পত্র অধ্যায় ৩ visuals part 2 — 3.3 limiting reagent at particle level; mass–mass road map */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const AC = { H: ['#f4f6f7', 4.6], O: ['#e74c3c', 7], N: ['#3b6fd8', 7], C: ['#555', 7], Cl: ['#2ecc71', 8] };
const SH = {
  H2: [['H', -4.5, 0], ['H', 4.5, 0]], O2: [['O', -6, 0], ['O', 6, 0]], N2: [['N', -6, 0], ['N', 6, 0]], Cl2: [['Cl', -7, 0], ['Cl', 7, 0]],
  H2O: [['O', 0, 0], ['H', -7.5, 5.5], ['H', 7.5, 5.5]], NH3: [['N', 0, 0], ['H', -8, 5], ['H', 8, 5], ['H', 0, -8.5]],
  CH4: [['C', 0, 0], ['H', -7, -6], ['H', 7, -6], ['H', -7, 6], ['H', 7, 6]], CO2: [['O', -11, 0], ['C', 0, 0], ['O', 11, 0]], CO: [['C', -5, 0], ['O', 6, 0]], HCl: [['H', -6, 0], ['Cl', 5, 0]]
};
const MW = { H2: 2.016, O2: 32.00, N2: 28.02, Cl2: 70.90, H2O: 18.02, NH3: 17.03, CH4: 16.04, CO2: 44.01, CO: 28.01, HCl: 36.46 };
const NM = { H2: 'H₂', O2: 'O₂', N2: 'N₂', Cl2: 'Cl₂', H2O: 'H₂O', NH3: 'NH₃', CH4: 'CH₄', CO2: 'CO₂', CO: 'CO', HCl: 'HCl' };
const LR = [
  ['2H₂ + O₂ → 2H₂O', [['H2', 2], ['O2', 1]], [['H2O', 2]], '2H2 + O2 -> 2H2O'],
  ['N₂ + 3H₂ → 2NH₃', [['N2', 1], ['H2', 3]], [['NH3', 2]], 'N2 + 3H2 -> 2NH3'],
  ['CH₄ + 2O₂ → CO₂ + 2H₂O', [['CH4', 1], ['O2', 2]], [['CO2', 1], ['H2O', 2]], 'CH4 + 2O2 -> CO2 + 2H2O'],
  ['2CO + O₂ → 2CO₂', [['CO', 2], ['O2', 1]], [['CO2', 2]], '2CO + O2 -> 2CO2'],
  ['H₂ + Cl₂ → 2HCl', [['H2', 1], ['Cl2', 1]], [['HCl', 2]], 'H2 + Cl2 -> 2HCl']
];
const mol = (g, key, x, y, s, a, ang) => { g.save(); g.translate(x, y); g.rotate(ang); g.globalAlpha = a; SH[key].slice().sort((p, q) => AC[p[0]][1] - AC[q[0]][1]).reverse().forEach(([e, dx, dy]) => { const [cc, r] = AC[e]; const gr = g.createRadialGradient(dx * s - r * s * 0.35, dy * s - r * s * 0.35, r * s * 0.1, dx * s, dy * s, r * s); gr.addColorStop(0, '#fff'); gr.addColorStop(0.35, cc); gr.addColorStop(1, 'rgba(0,0,0,.55)'); g.fillStyle = gr; g.beginPath(); g.arc(dx * s, dy * s, r * s, 0, 7); g.fill(); }); g.restore(); };
const rnd = s => () => (s = (s * 16807) % 2147483647) / 2147483647;

V.p2c3_limiting = {
  t: 'সীমিত বিক্রিয়ক — কণার স্তরে: অণুগুলো জোড় বেঁধে উৎপাদ তৈরি করে, যে বিক্রিয়ক আগে ফুরিয়ে যায় সে-ই উৎপাদের পরিমাণ ঠিক করে; বাড়তি বিক্রিয়ক, তাত্ত্বিক উৎপাদন ও ভরের হিসাব এবং "অনুমান করো" খেলা', k: ['anim', 'int', 'quiz'],
  cap: 'বিক্রিয়া বেছে প্রতিটি বিক্রিয়কের অণুর সংখ্যা স্লাইডারে ঠিক করো এবং "বিক্রিয়া" চাপো। বাম বাক্সে বিক্রিয়ক অণু (বল-মডেল: সাদা H, লাল O, নীল N, ধূসর C, সবুজ Cl), ডান বাক্সে বিক্রিয়ার পর উৎপাদ ও অবশিষ্ট (বাড়তি) অণু — বাড়তিগুলো হলুদ বলয়ে চিহ্নিত। নিয়ম: প্রতিটি বিক্রিয়কের (সংখ্যা ÷ সহগ) হিসাব করো; যেটির মান সবচেয়ে কম সেটিই সীমিত বিক্রিয়ক। নিচে প্রতিটি "অণু" কে ১ mol ধরে ভরের হিসাব — দেখো, ভর বেশি হলেই বিক্রিয়ক বেশি নয়। "অনুমান করো" মোডে এলোমেলো সংখ্যা আসবে; বিক্রিয়ার আগে সীমিত বিক্রিয়ক বেছে নাও।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-r', LR.map((r, i) => [String(i), r[0]]), '0')}<button class="btn sm primary" data-go>▶ বিক্রিয়া</button><button class="btn sm" data-qz>🎲 অনুমান করো</button></div>${X.cv('সীমিত বিক্রিয়ক')}<div class="ctl" style="flex-wrap:wrap"><label class="small" style="flex:1;min-width:130px"><span data-l0></span>: <b data-v0></b> টি অণু<input type="range" min="0" max="12" value="6" data-a></label><label class="small" style="flex:1;min-width:130px"><span data-l1></span>: <b data-v1></b> টি অণু<input type="range" min="0" max="12" value="6" data-b></label></div><div data-quiz class="ctl" style="display:none;flex-wrap:wrap"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), qz = q('[data-quiz]');
    const hf = w => wide(w) ? 300 : 430;
    let L = X.fit(c, hf), ri = 0, n = [6, 6], p = 0, run = false, t = 0, quiz = false, reveal = true;
    const calc = () => { const r = LR[ri], per = r[1].map((x, i) => n[i] / x[1]); const ext = Math.floor(Math.min(...per)); const lim = per[0] === per[1] ? -1 : per[0] < per[1] ? 0 : 1; return { per, ext, left: r[1].map((x, i) => n[i] - ext * x[1]), prod: r[2].map(x => ext * x[1]), lim }; };
    const pos = (cnt, seed, bx, by, bw, bh) => { const R = rnd(seed), cols = Math.max(3, Math.ceil(Math.sqrt(cnt * bw / bh))), rows = Math.ceil(cnt / cols) || 1, out = []; for (let i = 0; i < cnt; i++) { const cx = i % cols, cy = Math.floor(i / cols); out.push([bx + (cx + 0.5) * bw / cols + (R() - 0.5) * bw / cols * 0.35, by + (cy + 0.5) * bh / rows + (R() - 0.5) * bh / rows * 0.3, R() * 6.28]); } return out; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const r = LR[ri], C = calc(), k = Math.min(1, p), wd = wide(W);
      const bw = wd ? (W - 70) / 2 : W - 24, bh = wd ? H - 70 : (H - 90) / 2, b1 = [12, 28], b2 = wd ? [W / 2 + 23, 28] : [12, 28 + bh + 34];
      [[b1, 'বিক্রিয়ার আগে'], [b2, 'বিক্রিয়ার পরে']].forEach(([b, s]) => { g.strokeStyle = col.line || col.mu; g.lineWidth = 1.2; g.strokeRect(b[0], b[1], bw, bh); T(g, s, b[0] + bw / 2, b[1] - 8, col, { b: true, s: 11 }); });
      if (wd) T(g, '→', W / 2, H / 2, col, { b: true, s: 22, c: col.acc }); else T(g, '↓', W / 2, b2[1] - 20, col, { b: true, s: 16, c: col.acc });
      const tot = n[0] + n[1], s = Math.max(0.75, Math.min(1.3, Math.sqrt(bw * bh / Math.max(1, tot) / 900)));
      // before box: reactants (the reacted ones fade/shrink toward centre)
      const all = []; r[1].forEach((x, i) => { for (let j = 0; j < n[i]; j++) all.push([x[0], i, j]); });
      const P1 = pos(all.length, 7 + ri, b1[0] + 6, b1[1] + 6, bw - 12, bh - 12);
      all.forEach(([key, i, j], m) => { const used = j < C.ext * r[1][i][1]; const a = used ? 1 - 0.75 * k : 1; mol(g, key, P1[m][0], P1[m][1], s, a, P1[m][2] + t * 0.3 * (m % 2 ? 1 : -1)); });
      // after box: products + leftovers
      const aft = []; r[2].forEach((x, i) => { for (let j = 0; j < C.prod[i]; j++) aft.push([x[0], 0]); }); r[1].forEach((x, i) => { for (let j = 0; j < C.left[i]; j++) aft.push([x[0], 1]); });
      const P2_ = pos(aft.length, 11 + ri, b2[0] + 6, b2[1] + 6, bw - 12, bh - 12);
      if (k > 0) aft.forEach(([key, ex], m) => { const a = ex ? 1 : k; if (ex && reveal) { g.strokeStyle = '#f1c40f'; g.lineWidth = 2; g.globalAlpha = 0.9; g.beginPath(); g.arc(P2_[m][0], P2_[m][1], 15 * s, 0, 7); g.stroke(); g.globalAlpha = 1; } mol(g, key, P2_[m][0], P2_[m][1], s, a, P2_[m][2] + t * 0.3); });
      else T(g, '"বিক্রিয়া" চাপো', b2[0] + bw / 2, b2[1] + bh / 2, col, { s: 11, c: col.mu });
      // legend counts
      const ly = wd ? H - 22 : H - 10; const leg = k >= 1 ? r[2].map((x, i) => `${NM[x[0]]} ${bn(C.prod[i])}`).concat(r[1].map((x, i) => C.left[i] ? `বাড়তি ${NM[x[0]]} ${bn(C.left[i])}` : '').filter(Boolean)).join(' · ') : r[1].map((x, i) => `${NM[x[0]]} ${bn(n[i])}`).join(' + ');
      T(g, leg, W / 2, ly, col, { b: true, s: 10.5, c: k >= 1 ? '#2f9e44' : col.fg });
    };
    const info = () => {
      const r = LR[ri], C = calc(); q('[data-l0]').textContent = NM[r[1][0][0]]; q('[data-l1]').textContent = NM[r[1][1][0]]; q('[data-v0]').textContent = bn(n[0]); q('[data-v1]').textContent = bn(n[1]); q('[data-a]').value = n[0]; q('[data-b]').value = n[1];
      if (quiz && !reveal) { out.innerHTML = `${TXB(`\\ce{${r[3]}}`)}<div>বিক্রিয়া চালানোর আগে বলো — কোনটি সীমিত বিক্রিয়ক?</div>`; return; }
      const m = r[1].map((x, i) => n[i] * MW[x[0]]), pm = r[2].map((x, i) => C.prod[i] * MW[x[0]]);
      out.innerHTML = `${TXB(`\\ce{${r[3]}}`)}<div class="small">${r[1].map((x, i) => `${NM[x[0]]}: ${bn(n[i])} ÷ ${bn(x[1])} = <b>${bn(+C.per[i].toFixed(2))}</b>`).join(' &nbsp;|&nbsp; ')}</div><div><b>সীমিত বিক্রিয়ক:</b> ${C.lim < 0 ? 'নেই — দুটি বিক্রিয়ক ঠিক সহগ-অনুপাতে আছে' : NM[r[1][C.lim][0]]}${C.lim >= 0 ? `; বাড়তি: ${NM[r[1][1 - C.lim][0]]} (${bn(C.left[1 - C.lim])} টি অণু অবশিষ্ট${C.left[C.lim] ? `, এবং ${NM[r[1][C.lim][0]]} এর ${bn(C.left[C.lim])} টি অণু জোড় না পেয়ে থাকে` : ''})` : ''}।</div><div class="small">প্রতি অণুকে ১ mol ধরলে — বিক্রিয়ক: ${r[1].map((x, i) => `${NM[x[0]]} ${bn(+m[i].toFixed(1))} g`).join(', ')}; উৎপাদ: ${r[2].map((x, i) => `${NM[x[0]]} ${bn(+pm[i].toFixed(1))} g`).join(', ')}। ভর বেশি হওয়া মানেই বিক্রিয়ক বেশি নয় — তুলনা সবসময় মোল ÷ সহগ দিয়ে।</div>`;
    };
    const newQ = () => { const r = LR[ri]; let a, b; do { a = 1 + Math.floor(Math.random() * 12); b = 1 + Math.floor(Math.random() * 12); } while (a / r[1][0][1] === b / r[1][1][1]); n = [a, b]; p = 0; reveal = false; qz.style.display = 'flex'; qz.innerHTML = r[1].map((x, i) => `<button class="btn sm" data-ans="${i}">${NM[x[0]]} সীমিত</button>`).join('') + '<span class="small" data-fb></span>'; qz.querySelectorAll('[data-ans]').forEach(bt => bt.onclick = () => { const C = calc(), ok = +bt.dataset.ans === C.lim; qz.querySelector('[data-fb]').innerHTML = ok ? '✅ সঠিক! এখন বিক্রিয়া দেখো।' : `❌ নয় — ${r[1].map((x, i) => `${NM[x[0]]}: ${bn(n[i])}÷${bn(x[1])} = ${bn(+C.per[i].toFixed(2))}`).join(', ')}; ছোট মানটি সীমিত।`; reveal = true; p = 0; run = true; info(); }); info(); };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(1, p + dt * 0.5); if (p >= 1) run = false; } } draw(); }, { paused: false });
    q('[data-r]').onchange = e => { ri = +e.target.value; p = 0; if (quiz) newQ(); else info(); };
    q('[data-a]').oninput = e => { n[0] = +e.target.value; p = 0; quiz = false; reveal = true; qz.style.display = 'none'; info(); };
    q('[data-b]').oninput = e => { n[1] = +e.target.value; p = 0; quiz = false; reveal = true; qz.style.display = 'none'; info(); };
    q('[data-go]').onclick = () => { if (quiz && !reveal) return; p = 0; run = true; };
    q('[data-qz]').onclick = () => { quiz = true; newQ(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.৩ ভর-ভর-আয়তন রোডম্যাপ ======================= */
const PB = [
  { eq: '2KClO3 ->[\\Delta][\\text{MnO}_2] 2KCl + 3O2 ^', a: ['KClO₃', 2, 122.5], b: ['O₂', 3, 32.00], gas: 1, m: 24.5, q: '২৪.৫ g KClO₃ সম্পূর্ণ বিয়োজিত হলে কত g ও STP তে কত লিটার O₂ পাওয়া যাবে?' },
  { eq: 'CaCO3 ->[\\Delta] CaO + CO2 ^', a: ['CaCO₃', 1, 100], b: ['CO₂', 1, 44], gas: 1, m: 50, q: '৫০ g চুনাপাথর পোড়ালে কত g ও STP তে কত লিটার CO₂ তৈরি হবে?' },
  { eq: 'Zn + H2SO4 -> ZnSO4 + H2 ^', a: ['Zn', 1, 65.4], b: ['H₂', 1, 2], gas: 1, m: 13.08, q: '১৩.০৮ g জিংক বাড়তি লঘু H₂SO₄ এ দ্রবীভূত হলে কত g ও কত লিটার (STP) H₂ পাওয়া যাবে?' },
  { eq: 'Fe2O3 + 3CO -> 2Fe + 3CO2', a: ['Fe₂O₃', 1, 160], b: ['Fe', 2, 56], gas: 0, m: 1000, q: '১ kg (১০০০ g) হেমাটাইট (Fe₂O₃) থেকে সর্বোচ্চ কত g লোহা পাওয়া যাবে?' },
  { eq: '2NaHCO3 ->[\\Delta] Na2CO3 + H2O + CO2 ^', a: ['NaHCO₃', 2, 84], b: ['CO₂', 1, 44], gas: 1, m: 8.4, q: '৮.৪ g খাবার সোডা (NaHCO₃) উত্তপ্ত করলে কত লিটার (STP) CO₂ নির্গত হয় — কেক ফোলাতে যা কাজে লাগে?' }
];
V.p2c3_roadmap = {
  t: 'স্টয়কিওমিতির রোডম্যাপ: ভর (g) → মোল → সহগ অনুপাত → মোল → ভর (g) বা আয়তন (L) — ধাপে ধাপে আলোকিত পথ, পরিবর্তনযোগ্য ভর এবং পাঁচটি বাস্তব সমস্যা', k: ['anim', 'int', 'calc'],
  cap: 'সমস্যা বেছে নাও ও বিক্রিয়কের ভর বদলাও। "ধাপে ধাপে" চাপলে রোডম্যাপের প্রতিটি সেতু একে একে আলোকিত হয়: (১) ভর ÷ মোলার ভর = মোল; (২) সমীকরণের সহগ অনুপাতে উৎপাদের মোল — এটিই একমাত্র ধাপ যেখানে সমীকরণ লাগে; (৩) মোল × মোলার ভর = উৎপাদের ভর, অথবা মোল × ২২.৪ L = STP তে আয়তন (কেবল গ্যাস হলে)। প্রতিটি ধাপের সংখ্যা নিচে দেখানো হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-r', PB.map((r, i) => [String(i), `সমস্যা ${bn(i + 1)}: ${r.a[0]} → ${r.b[0]}`]), '0')}<button class="btn sm primary" data-go>▶ ধাপে ধাপে</button></div><div class="small" data-qq style="margin:4px 0"></div>${X.cv('রোডম্যাপ')}<div class="ctl"><label class="small" style="flex:1">বিক্রিয়কের ভর = <b data-mv></b> g<input type="range" min="1" max="200" step="0.1" data-m></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 210 : 380;
    let L = X.fit(c, hf), ri = 0, m = PB[0].m, p = 3, run = false, t = 0;
    const calc = () => { const r = PB[ri], na = m / r.a[2], nb = na * r.b[1] / r.a[1]; return { na, nb, mb: nb * r.b[2], vb: nb * 22.4 }; };
    const f = v => bn(+v.toPrecision(4));
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const r = PB[ri], C = calc(), wd = wide(W);
      const nodes = wd ? [[W * 0.09, H * 0.5], [W * 0.36, H * 0.5], [W * 0.62, H * 0.5], [W * 0.89, H * 0.22], [W * 0.89, H * 0.78]] : [[W * 0.5, 34], [W * 0.5, 120], [W * 0.5, 210], [W * 0.27, 320], [W * 0.73, 320]];
      const lab = [[`${r.a[0]} এর ভর`, `${f(m)} g`], [`${r.a[0]} এর মোল`, `${f(C.na)} mol`], [`${r.b[0]} এর মোল`, `${f(C.nb)} mol`], [`${r.b[0]} এর ভর`, `${f(C.mb)} g`], [r.gas ? `${r.b[0]} আয়তন (STP)` : 'আয়তন', r.gas ? `${f(C.vb)} L` : 'প্রযোজ্য নয় (কঠিন)']];
      const edges = [[0, 1, `÷ ${bn(r.a[2])} g/mol`], [1, 2, `× ${bn(r.b[1])}/${bn(r.a[1])} (সহগ)`], [2, 3, `× ${bn(r.b[2])} g/mol`], [2, 4, '× ২২.৪ L/mol']];
      edges.forEach(([a, b, s], i) => { const on = p > i + (i === 3 ? -1 : 0), A = nodes[a], B = nodes[b]; const fr = Math.max(0, Math.min(1, p - (i === 3 ? 2 : i))); g.strokeStyle = col.line || col.mu; g.lineWidth = 3; g.beginPath(); g.moveTo(A[0], A[1]); g.lineTo(B[0], B[1]); g.stroke(); if (fr > 0 && !(i === 3 && !r.gas)) { g.strokeStyle = i === 1 ? '#e67700' : col.acc; g.lineWidth = 4; g.beginPath(); g.moveTo(A[0], A[1]); g.lineTo(A[0] + (B[0] - A[0]) * fr, A[1] + (B[1] - A[1]) * fr); g.stroke(); } const mx = (A[0] + B[0]) / 2 + (wd ? 0 : (i === 1 || i === 0 ? 0 : 0)), my = (A[1] + B[1]) / 2 - (wd && A[1] === B[1] ? 16 : 0); g.font = `bold 9.5px ${col.font}`; const tw = g.measureText(s).width + 10; g.fillStyle = col.sf; g.fillRect(mx - tw / 2, my - 9, tw, 15); T(g, s, mx, my + 2.5, col, { b: true, s: 9.5, c: i === 1 ? '#e67700' : col.mu }); });
      nodes.forEach(([x, y], i) => { const lit = i === 0 || p >= (i <= 2 ? i : 3) - 0.02; const w = wd ? Math.min(118, W * 0.17) : Math.min(150, W * 0.42), h = 42; g.fillStyle = lit ? (i === 0 ? '#3b5bdb' : i === 2 || i === 1 ? '#7048e8' : '#2f9e44') : col.s2; g.globalAlpha = lit ? 0.92 : 1; g.beginPath(); g.roundRect ? g.roundRect(x - w / 2, y - h / 2, w, h, 10) : g.rect(x - w / 2, y - h / 2, w, h); g.fill(); g.globalAlpha = 1; g.strokeStyle = col.line || col.mu; g.lineWidth = 1; g.stroke(); T(g, lab[i][0], x, y - 4, col, { s: 9.5, c: lit ? '#fff' : col.mu }); T(g, lit ? lab[i][1] : '?', x, y + 12, col, { b: true, s: 11.5, c: lit ? '#fff' : col.mu }); });
      if (run) { const i = Math.min(3, Math.floor(p)); const e = edges[i] || edges[3]; const A = nodes[e[0]], B = nodes[e[1]], fr = p - Math.floor(p); g.fillStyle = '#ffd43b'; g.beginPath(); g.arc(A[0] + (B[0] - A[0]) * fr, A[1] + (B[1] - A[1]) * fr, 6, 0, 7); g.fill(); }
    };
    const info = () => { const r = PB[ri], C = calc(); q('[data-mv]').textContent = bn(m); q('[data-m]').value = m; q('[data-qq]').innerHTML = `<b>প্রশ্ন:</b> ${r.q}`; out.innerHTML = `${TXB(`\\ce{${r.eq}}`)}<div class="small"><b>১.</b> ${r.a[0]} এর মোল = ${f(m)} ÷ ${bn(r.a[2])} = ${f(C.na)} mol<br><b>২.</b> সমীকরণ: ${bn(r.a[1])} mol ${r.a[0]} ≡ ${bn(r.b[1])} mol ${r.b[0]} ⇒ ${r.b[0]} এর মোল = ${f(C.na)} × ${bn(r.b[1])}/${bn(r.a[1])} = ${f(C.nb)} mol<br><b>৩.</b> ${r.b[0]} এর ভর = ${f(C.nb)} × ${bn(r.b[2])} = <b>${f(C.mb)} g</b>${r.gas ? `; STP তে আয়তন = ${f(C.nb)} × ২২.৪ = <b>${f(C.vb)} L</b>` : ''}</div>`; };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (run) { p = Math.min(3, p + dt * 0.6); if (p >= 3) run = false; } } draw(); }, { paused: false });
    q('[data-r]').onchange = e => { ri = +e.target.value; m = PB[ri].m; p = 3; info(); };
    q('[data-m]').max = 1200; q('[data-m]').oninput = e => { m = +e.target.value; info(); };
    q('[data-go]').onclick = () => { p = 0; run = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
