/* ২য় পত্র অধ্যায় ৩ visuals part 7 — 3.13 acid–base titration simulator (burette reading, indicators, live pH curve, trials table); 3.14 redox titrations: KMnO4/Fe2+, iodometry (Cu2+), iodimetry (vitamin C) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V, P2 = window.P2V;
const bn = X.bn, TXB = C4.txb, wide = P2.wide;
const T = (g, s, x, y, col, o = {}) => { g.fillStyle = o.c || col.fg; g.font = `${o.b ? 'bold ' : ''}${o.s || 10}px ${col.font}`; g.textAlign = o.a || 'center'; g.fillText(s, x, y); };
const SEL = (attr, opts, v) => `<select ${attr} style="padding:6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit;max-width:100%">${opts.map(([k, n]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const hex2 = h => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const mix = (a, b, u, al = 1) => { const A = a ? hex2(a) : null, B = b ? hex2(b) : null; if (!A && !B) return 'rgba(225,235,248,.35)'; if (!A) return `rgba(${B.join(',')},${(al * u).toFixed(3)})`; if (!B) return `rgba(${A.join(',')},${(al * (1 - u)).toFixed(3)})`; return `rgba(${A.map((v, i) => Math.round(v + (B[i] - v) * u)).join(',')},${al})`; };
const sstep = u => { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); };
const f2 = v => bn(v.toFixed(2));
const Kw = 1e-14;
const solveH = f => { let lo = -14, hi = 0.5; for (let i = 0; i < 70; i++) { const m = (lo + hi) / 2; f(10 ** m) > 0 ? hi = m : lo = m; } return -(lo + hi) / 2; }; // returns pH; f increasing in h

/* shared apparatus */
const burette = (g, col, x, y0, Lb, read, liq, drip, t) => { const w = 14; g.fillStyle = col.s2; g.fillRect(x - w / 2, y0, w, Lb); const ly = y0 + Lb * Math.min(1, read / 50); g.fillStyle = liq; g.fillRect(x - w / 2 + 1, ly, w - 2, Lb - (ly - y0)); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.strokeRect(x - w / 2, y0, w, Lb); for (let m = 0; m <= 50; m++) { const yy = y0 + Lb * m / 50; g.beginPath(); g.moveTo(x - w / 2, yy); g.lineTo(x - w / 2 + (m % 5 ? 3 : 6), yy); g.stroke(); if (m % 10 === 0) T(g, bn(m), x - w / 2 - 4, yy + 3, col, { s: 8, a: 'right', c: col.mu }); } g.fillStyle = col.fg; g.fillRect(x - 9, y0 + Lb, 18, 6); g.fillRect(x - 2, y0 + Lb + 6, 4, 16); if (drip) { const u = (t * 3) % 1; g.fillStyle = liq; g.beginPath(); g.arc(x, y0 + Lb + 24 + u * 26, 2.6, 0, 7); g.fill(); } return ly; };
const meniscus = (g, col, cx, cy, r, read, liq) => { g.save(); g.beginPath(); g.arc(cx, cy, r, 0, 7); g.clip(); g.fillStyle = col.sf; g.fillRect(cx - r, cy - r, 2 * r, 2 * r); const sc = r * 1.6; // pixels per mL in inset
  const yR = v => cy + (v - read) * sc; g.fillStyle = liq; g.beginPath(); g.moveTo(cx - r, yR(read) - 6); g.quadraticCurveTo(cx, yR(read) + 6, cx + r, yR(read) - 6); g.lineTo(cx + r, cy + r); g.lineTo(cx - r, cy + r); g.closePath(); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1; for (let k = Math.floor((read - 1) * 10); k <= Math.ceil((read + 1) * 10); k++) { const v = k / 10, yy = yR(v); if (v < 0) continue; g.beginPath(); g.moveTo(cx - r, yy); g.lineTo(cx - r + (k % 10 === 0 ? r * 0.9 : k % 5 === 0 ? r * 0.6 : r * 0.35), yy); g.stroke(); if (k % 10 === 0) T(g, bn(v.toFixed(0)), cx - r + r * 0.95, yy + 3, col, { s: 8.5, a: 'left', b: true }); } g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.stroke(); g.strokeStyle = '#e03131'; g.setLineDash([3, 2]); g.beginPath(); g.moveTo(cx - r, cy + 6); g.lineTo(cx + r, cy + 6); g.stroke(); g.setLineDash([]); };
const flask = (g, col, x, y, s, fill, ppt, t, swirl) => { const P = () => { g.beginPath(); g.moveTo(x - 8 * s, y - 100 * s); g.lineTo(x - 8 * s, y - 72 * s); g.lineTo(x - 52 * s, y); g.lineTo(x + 52 * s, y); g.lineTo(x + 8 * s, y - 72 * s); g.lineTo(x + 8 * s, y - 100 * s); }; g.save(); P(); g.closePath(); g.clip(); const lv = y - 36 * s; for (const fs of ['rgba(205,225,245,.35)', fill]) { g.fillStyle = fs; g.beginPath(); g.moveTo(x - 60 * s, y + 2); for (let i = 0; i <= 24; i++) { const xx = x - 60 * s + i * 5 * s; g.lineTo(xx, lv + Math.sin(i * 0.8 + t * 8) * (swirl ? 2.5 : 0.6) * s); } g.lineTo(x + 60 * s, y + 2); g.closePath(); g.fill(); } if (ppt) { g.fillStyle = ppt; for (let i = 0; i < 60; i++) { const a = i * 2.39 + t * (swirl ? 3 : 0.4), r = ((i * 37) % 100) / 100; g.fillRect(x + Math.cos(a) * 40 * s * r, y - 4 * s - ((i * 53) % 100) / 100 * 28 * s, 2.2, 2.2); } } g.restore(); g.strokeStyle = col.fg; g.lineWidth = 1.5; P(); g.stroke(); };

/* ======================= ৩.১৩ এসিড-ক্ষার টাইট্রেশন ======================= */
const AB = [
  { t: 'অজানা HCl (২৫ mL) ← ০.১ M NaOH', fl: 'HCl', br: 'NaOH', Cb: 0.1, Va: 25, sys: 0, eqn: 'HCl + NaOH -> NaCl + H2O', dir: 1 },
  { t: 'অজানা CH₃COOH (২৫ mL) ← ০.১ M NaOH', fl: 'CH₃COOH', br: 'NaOH', Cb: 0.1, Va: 25, sys: 1, eqn: 'CH3COOH + NaOH -> CH3COONa + H2O', dir: 1 },
  { t: '০.০৫ M Na₂CO₃ (২৫ mL) ← অজানা HCl (প্রমিতকরণ)', fl: 'Na₂CO₃', br: 'HCl', Cb: null, Va: 25, sys: 2, eqn: 'Na2CO3 + 2HCl -> 2NaCl + H2O + CO2 ^', dir: -1 }
];
const INDS = [['PP', 'ফেনলফথ্যালিন', 8.2, 10.0, null, '#e64980'], ['MO', 'মিথাইল অরেঞ্জ', 3.1, 4.4, '#e03131', '#fab005'], ['MR', 'মিথাইল রেড', 4.4, 6.2, '#e03131', '#fcc419'], ['BTB', 'ব্রোমোথাইমল ব্লু', 6.0, 7.6, '#fab005', '#1c7ed6']];
V.p2c3_titration = {
  t: 'এসিড-ক্ষার টাইট্রেশন সিমুলেটর: বুরেট পাঠ (মেনিস্কাস বিবর্ধিত), ফোঁটা-ফোঁটা যোগ, নির্দেশকের সমাপ্তি বিন্দু, সরাসরি pH বক্ররেখা, ট্রায়াল সারণি (সামঞ্জস্যপূর্ণ পাঠ) ও অজানা ঘনমাত্রা গণনা — HCl, CH₃COOH ও Na₂CO₃ দিয়ে HCl এর প্রমিতকরণ', k: ['anim', 'int', 'lab', 'calc', 'plot'],
  cap: 'টাইট্রেশন ও নির্দেশক বেছে নাও। "+১ mL", "+০.১ mL" ও "+১ ফোঁটা" (০.০৫ mL) বোতামে বুরেট থেকে দ্রবণ যোগ করো — ফ্লাস্ক ঝাঁকানো হয়, নির্দেশকের রং ও pH বদলায়, ডানে pH বক্ররেখা আঁকা হয়। রং স্থায়ীভাবে বদলালে "সমাপ্তি বিন্দু লিখো" চাপো: প্রাথমিক ও শেষ বুরেট পাঠ সারণিতে যায় (বিবর্ধিত বৃত্তে মেনিস্কাসের তলা থেকে পাঠ নেওয়া হয়)। প্রথম ট্রায়াল দ্রুত (rough), পরে সমাপ্তি বিন্দুর কাছে ফোঁটা-ফোঁটা করে কমপক্ষে দুটি সামঞ্জস্যপূর্ণ পাঠ (পার্থক্য ≤ ০.১ mL) নাও। গড় পাঠ দিয়ে অজানা ঘনমাত্রা হিসাব হয়। ভুল নির্দেশক (যেমন CH₃COOH এ মিথাইল অরেঞ্জ) দিলে কী হয় দেখো। Na₂CO₃ এ ফেনলফথ্যালিন প্রথম প্রশমন বিন্দু (NaHCO₃) দেখায়!',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-s', AB.map((s, i) => [String(i), s.t]), '0')}${SEL('data-i', INDS.map((s, i) => [String(i), s[1]]), '0')}</div>${X.cv('টাইট্রেশন')}<div class="ctl" style="flex-wrap:wrap;justify-content:center"><button class="btn sm" data-a="1">+১ mL</button><button class="btn sm" data-a="0.1">+০.১ mL</button><button class="btn sm" data-a="0.05">+১ ফোঁটা</button><button class="btn sm primary" data-rec>✓ সমাপ্তি বিন্দু লিখো</button><button class="btn sm" data-new>↺ নতুন ট্রায়াল</button><button class="btn sm" data-rv>উত্তর দেখাও</button></div><div data-tab></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), tab = el.querySelector('[data-tab]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 560;
    let L = X.fit(c, hf), si = 0, ii = 0, t = 0, drip = 0, added = 0, r0 = 0, pts = [], trials = [], rev = false, truth = [0.08 + Math.random() * 0.04, 0.07 + Math.random() * 0.03, 0.09 + Math.random() * 0.03];
    const S = () => AB[si];
    const pHat = v => { const s = S(), Vt = s.Va + v; if (s.sys === 0) { const Cl = truth[0] * s.Va / Vt, Na = s.Cb * v / Vt; return solveH(h => Na + h - Kw / h - Cl); } if (s.sys === 1) { const Ct = truth[1] * s.Va / Vt, Na = s.Cb * v / Vt, Ka = 1.8e-5; return solveH(h => Na + h - Kw / h - Ct * Ka / (h + Ka)); } const Ct = 0.05 * s.Va / Vt, Na = 2 * Ct, Cl = truth[2] * v / Vt, K1 = 4.3e-7, K2 = 4.8e-11; return solveH(h => Na + h - Kw / h - Cl - Ct * (K1 * h + 2 * K1 * K2) / (h * h + K1 * h + K1 * K2)); };
    const indC = (pH, al = 0.8) => { const I = INDS[ii]; return mix(I[4], I[5], sstep((pH - I[2]) / (I[3] - I[2])), al); };
    const liq = () => S().br === 'NaOH' ? 'rgba(150,190,240,.55)' : 'rgba(170,200,235,.5)';
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), pH = pHat(added), read = r0 + added;
      const bx = wd ? W * 0.12 : W * 0.2, by0 = 10, Lb = wd ? H - 150 : 260; burette(g, col, bx, by0, Lb, read, liq(), drip > 0, t);
      const my = Math.max(40, by0 + Lb * Math.min(1, read / 50)); meniscus(g, col, bx + (wd ? 62 : 70), my, wd ? 34 : 30, read, liq()); T(g, `পাঠ: ${f2(read)} mL`, bx + (wd ? 62 : 70), my + (wd ? 50 : 46), col, { b: true, s: 10 });
      const fx = bx, fy = wd ? H - 10 : Lb + 140, s = wd ? 1.05 : 0.95; flask(g, col, fx, fy, s, indC(pH), null, t, drip > 0); T(g, `pH ${bn(pH.toFixed(2))}`, fx + 70 * s, fy - 20, col, { b: true, s: 11, a: 'left' });
      // curve
      const gx = wd ? W * 0.42 : 40, gy = wd ? 16 : Lb + 165, gw = wd ? W * 0.55 : W - 54, gh = wd ? H - 50 : H - Lb - 200; g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.strokeRect(gx, gy, gw, gh); const Vmax = 40, Xv = v => gx + v / Vmax * gw, Y = p => gy + gh * (1 - p / 14); const I = INDS[ii]; g.fillStyle = mix(I[4] || '#dee2e6', I[5], 0.5, 0.25); g.fillRect(gx, Y(I[3]), gw, Y(I[2]) - Y(I[3])); T(g, `${I[1]} পরিসর`, gx + gw - 4, Y(I[3]) - 3, col, { s: 8.5, a: 'right', c: col.mu });
      if (rev) { g.beginPath(); for (let i = 0; i <= 400; i++) { const v = i / 10, p = pHat(v); i ? g.lineTo(Xv(v), Y(p)) : g.moveTo(Xv(v), Y(p)); } g.strokeStyle = col.mu; g.setLineDash([4, 3]); g.lineWidth = 1.2; g.stroke(); g.setLineDash([]); }
      g.fillStyle = col.acc; pts.forEach(([v, p]) => { g.beginPath(); g.arc(Xv(v), Y(p), 2.4, 0, 7); g.fill(); }); g.fillStyle = '#e03131'; g.beginPath(); g.arc(Xv(added), Y(pH), 4.5, 0, 7); g.fill();
      [0, 7, 14].forEach(v => T(g, bn(v), gx - 6, Y(v) + 3, col, { s: 8.5, a: 'right', c: col.mu })); [0, 10, 20, 30, 40].forEach(v => T(g, bn(v), Xv(v), gy + gh + 12, col, { s: 8.5, c: col.mu })); T(g, `যোগ করা ${S().br} (mL)`, gx + gw / 2, gy + gh + 24, col, { s: 9, c: col.mu });
    };
    const conc = () => { const ok = trials.filter(x => !x.rough); let best = null; for (let i = 0; i < ok.length; i++) for (let j = i + 1; j < ok.length; j++) if (Math.abs(ok[i].v - ok[j].v) <= 0.1001) { const set = ok.filter(x => Math.abs(x.v - ok[i].v) <= 0.1001 && Math.abs(x.v - ok[j].v) <= 0.1001); if (!best || set.length > best.length) best = set; } return best; };
    const result = () => { const s = S(), best = conc(); if (!best) return `<div class="small">${trials.length ? 'এখনো দুটি সামঞ্জস্যপূর্ণ (পার্থক্য ≤ ০.১ mL) পাঠ পাওয়া যায়নি — আরেকটি ট্রায়াল করো।' : 'প্রথম ট্রায়ালটি দ্রুত করে আনুমানিক সমাপ্তি বিন্দু জেনে নাও।'}</div>`; const Vm = best.reduce((a, x) => a + x.v, 0) / best.length; let txt;
      if (s.sys === 0) txt = `HCl + NaOH (১ : ১) ⇒ M(HCl) = ০.১ × ${f2(Vm)} ÷ ২৫ = <b>${bn((0.1 * Vm / 25).toFixed(4))} M</b>`;
      else if (s.sys === 1) txt = `CH₃COOH + NaOH (১ : ১) ⇒ M = ০.১ × ${f2(Vm)} ÷ ২৫ = <b>${bn((0.1 * Vm / 25).toFixed(4))} M</b>${ii !== 0 ? ' — ⚠️ মৃদু এসিডে ফেনলফথ্যালিন ছাড়া অন্য নির্দেশক প্রশমন বিন্দুর অনেক আগে রং বদলায়, তাই এই মান কম ও অনির্ভরযোগ্য!' : ''}`;
      else txt = ii === 0 ? `ফেনলফথ্যালিনে প্রথম প্রশমন বিন্দু: Na₂CO₃ + HCl → NaHCO₃ + NaCl (১ : ১) ⇒ M(HCl) = ০.০৫ × ২৫ ÷ ${f2(Vm)} = <b>${bn((0.05 * 25 / Vm).toFixed(4))} M</b>` : `সম্পূর্ণ প্রশমন (মিথাইল অরেঞ্জ): Na₂CO₃ + 2HCl (১ : ২) ⇒ M(HCl) = ২ × ০.০৫ × ২৫ ÷ ${f2(Vm)} = <b>${bn((0.1 * 25 / Vm).toFixed(4))} M</b>${ii === 3 || ii === 2 ? ' — ⚠️ এই নির্দেশক কার্বনেটের কোনো প্রশমন বিন্দুর সাথে ভালো মেলে না।' : ''}`;
      return `<div class="small">সামঞ্জস্যপূর্ণ পাঠের গড় = ${f2(Vm)} mL।</div><div class="small">${txt}</div>`; };
    const render = () => { const s = S(); tab.innerHTML = trials.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>ট্রায়াল</th><th>প্রাথমিক পাঠ (mL)</th><th>শেষ পাঠ (mL)</th><th>ব্যবহৃত আয়তন (mL)</th></tr></thead><tbody>${trials.map((x, i) => `<tr><td>${x.rough ? 'আনুমানিক' : bn(i)}</td><td>${f2(x.a)}</td><td>${f2(x.b)}</td><td><b>${f2(x.v)}</b></td></tr>`).join('')}</tbody></table></div>` : ''; const tr = s.sys === 0 ? truth[0] : s.sys === 1 ? truth[1] : truth[2]; out.innerHTML = `${TXB(`\\ce{${s.eqn}}`)}${result()}${rev ? `<div class="small"><b>প্রকৃত মান:</b> ${s.sys === 2 ? 'HCl' : s.fl} = ${bn(tr.toFixed(4))} M। প্রশমন বিন্দু: ${s.sys === 2 ? `${f2(0.05 * 25 / tr)} mL (প্রথম, NaHCO₃) ও ${f2(0.1 * 25 / tr)} mL (দ্বিতীয়)` : `${f2(tr * 25 / 0.1)} mL`}। ধূসর ড্যাশ রেখা = সম্পূর্ণ তাত্ত্বিক বক্ররেখা।</div>` : ''}`; draw(); };
    const add = d => { added = Math.min(50 - r0, +(added + d).toFixed(2)); pts.push([added, pHat(added)]); drip = 0.6; render(); };
    const reset = (full) => { added = 0; pts = [[0, pHat(0)]]; r0 = full ? 0 : +(Math.random() * 0.8).toFixed(2); if (full) { trials = []; rev = false; } render(); };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (drip > 0) drip -= dt; } draw(); }, { paused: false });
    el.querySelectorAll('[data-a]').forEach(b => b.onclick = () => add(+b.dataset.a));
    q('[data-rec]').onclick = () => { if (added <= 0) return; trials.push({ a: r0, b: r0 + added, v: added, rough: trials.length === 0 }); reset(false); };
    q('[data-new]').onclick = () => reset(false);
    q('[data-rv]').onclick = () => { rev = !rev; render(); };
    q('[data-s]').onchange = e => { si = +e.target.value; if (si === 2) { ii = 1; q('[data-i]').value = '1'; } else if (si === 1) { ii = 0; q('[data-i]').value = '0'; } reset(true); };
    q('[data-i]').onchange = e => { ii = +e.target.value; render(); };
    reset(true);
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৩.১৪ রিডক্স টাইট্রেশন ======================= */
const RT = [
  { t: 'KMnO₄ (০.০২ M) ← Fe²⁺ (মোর লবণ, ১০ mL + লঘু H₂SO₄)', br: '#7b1fa2', brA: 0.9, Vf: 10, eqn: 'MnO4- + 8H+ + 5Fe^2+ -> Mn^2+ + 5Fe^3+ + 4H2O', starch: false },
  { t: 'আয়োডোমিতি: Na₂S₂O₃ (০.০৫ M) ← Cu²⁺ (২৫ mL) + বাড়তি KI', br: null, brA: 0, Vf: 25, eqn: '2Cu^2+ + 4I- -> 2CuI v + I2', eqn2: 'I2 + 2S2O3^2- -> 2I- + S4O6^2-', starch: true },
  { t: 'আয়োডিমিতি: I₂ (০.০১ M) ← ভিটামিন C (২৫ mL) + স্টার্চ', br: '#8d4a0f', brA: 0.8, Vf: 25, eqn: 'C6H8O6 + I2 -> C6H6O6 + 2H+ + 2I-', starch: true }
];
V.p2c3_redoxTit = {
  t: 'ব্যবহারিক — জারণ-বিজারণ টাইট্রেশন: KMnO₄ দিয়ে Fe²⁺ (স্বনির্দেশক), আয়োডোমিতিতে Cu²⁺ (I₂ মুক্তি ও থায়োসালফেট টাইট্রেশন, শেষে স্টার্চ) এবং আয়োডিমিতিতে ভিটামিন C (I₂ দিয়ে সরাসরি) — রঙের ধাপ ও গণনা', k: ['anim', 'int', 'lab', 'calc'],
  cap: 'টাইট্রেশন বেছে নাও এবং বোতামে বুরেট থেকে টাইট্রেন্ট যোগ করো। KMnO₄ মোডে প্রতিটি ফোঁটার বেগুনি রং ফ্লাস্কে মিলিয়ে যায় — প্রশমন (সমতুল্য) বিন্দুর পর এক ফোঁটায় স্থায়ী হালকা গোলাপি = সমাপ্তি বিন্দু। আয়োডোমিতিতে Cu²⁺ ও KI থেকে মুক্ত I₂ এর বাদামি রং ও সাদা CuI অধঃক্ষেপ; থায়োসালফেট যোগে বাদামি → হালকা হলুদ হলে স্টার্চ যোগ করো (নীল-কালো), তারপর নীল রং ঠিক মিলিয়ে গেলেই সমাপ্তি বিন্দু। আগেভাগে স্টার্চ দিলে সতর্কবার্তা দেখো। আয়োডিমিতিতে ভিটামিন C, I₂ কে বিজারিত করে — প্রথম বাড়তি I₂ স্টার্চের সাথে স্থায়ী নীল রং দেয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px;flex-wrap:wrap">${SEL('data-m', RT.map((s, i) => [String(i), s.t]), '0')}</div>${X.cv('রিডক্স টাইট্রেশন')}<div class="ctl" style="flex-wrap:wrap;justify-content:center"><button class="btn sm" data-a="1">+১ mL</button><button class="btn sm" data-a="0.1">+০.১ mL</button><button class="btn sm" data-a="0.05">+১ ফোঁটা</button><button class="btn sm" data-st>🧪 স্টার্চ যোগ করো</button><button class="btn sm primary" data-rec>✓ সমাপ্তি বিন্দু</button><button class="btn sm" data-new>↺ নতুন</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 560;
    let L = X.fit(c, hf), mi = 0, t = 0, drip = 0, flash = 0, added = 0, starch = false, early = false, rec = null, truth = [0.09 + Math.random() * 0.03, 0.04 + Math.random() * 0.02, 0.48 + Math.random() * 0.05];
    const eqV = () => mi === 0 ? truth[0] * 10 / 5 / 0.02 : mi === 1 ? truth[1] * 25 / 0.05 : (truth[2] * 1000 / 176.12 / 250 * 25) / 0.01; // mL
    const state = () => { const Ve = eqV(), Vt = RT[mi].Vf + 10 + added; if (mi === 0) { const ex = Math.max(0, added - Ve) * 0.02 / Vt; const fe3 = Math.min(added, Ve) / Ve; return { fill: ex > 0 ? `rgba(194,24,91,${Math.min(0.9, 1 - Math.pow(10, -2400 * ex * 1.5)).toFixed(3)})` : `rgba(250,225,140,${(0.12 + 0.18 * fe3).toFixed(3)})`, ppt: null, done: ex > 0 }; }
      if (mi === 1) { const I2 = Math.max(0, 1 - added / Ve); const fill = starch && I2 > 0 ? `rgba(25,30,80,${Math.min(0.92, 0.25 + I2 * 3).toFixed(3)})` : I2 > 0 ? `rgba(140,70,15,${(0.12 + 0.75 * I2).toFixed(3)})` : 'rgba(245,240,230,.55)'; return { fill, ppt: 'rgba(250,245,235,.9)', done: I2 <= 0, I2 }; }
      const exI = Math.max(0, added - Ve) * 0.01 / Vt; return { fill: exI > 0 ? `rgba(25,30,90,${Math.min(0.9, 0.2 + exI * 4000).toFixed(3)})` : 'rgba(230,240,250,.35)', ppt: null, done: exI > 0 }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const wd = wide(W), m = RT[mi], st = state();
      const liq = mi === 0 ? 'rgba(123,31,162,.9)' : mi === 1 ? 'rgba(170,200,235,.5)' : 'rgba(141,74,15,.85)';
      const bx = wd ? W * 0.18 : W * 0.25, Lb = wd ? H - 140 : 250; burette(g, col, bx, 8, Lb, added, liq, drip > 0, t); const my = Math.max(38, 8 + Lb * Math.min(1, added / 50)); meniscus(g, col, bx + 64, my, 30, added, liq); T(g, `পাঠ: ${f2(added)} mL`, bx + 64, my + 46, col, { b: true, s: 10 });
      const fx = bx, fy = wd ? H - 8 : Lb + 130; flask(g, col, fx, fy, wd ? 1.05 : 0.95, st.fill, st.ppt, t, drip > 0);
      if (flash > 0 && mi === 0 && !st.done) { g.fillStyle = `rgba(194,24,91,${(flash * 0.6).toFixed(3)})`; g.beginPath(); g.arc(fx, fy - 30, 14 * flash + 4, 0, 7); g.fill(); }
      // stage panel
      const px = wd ? W * 0.45 : 14, py = wd ? 24 : Lb + 160, pw = wd ? W * 0.52 : W - 28; const Ve = eqV(), fr = Math.min(1, added / Ve);
      const stages = mi === 0 ? [['শুরু: Fe²⁺ (প্রায় বর্ণহীন, হালকা সবুজাভ)', 0], ['প্রতি ফোঁটা KMnO₄ বর্ণহীন হয় (Mn²⁺), Fe³⁺ এর হালকা হলুদ আভা', 0.05], ['সমতুল্য বিন্দু: সব Fe²⁺ জারিত', 1], ['এক ফোঁটা বাড়তি MnO₄⁻ → স্থায়ী গোলাপি = সমাপ্তি বিন্দু', 1.001]]
        : mi === 1 ? [['Cu²⁺ + বাড়তি KI → সাদা CuI↓ + বাদামি I₂', 0], ['থায়োসালফেট যোগ: বাদামি ক্রমশ হালকা', 0.05], ['হালকা খড়-হলুদ: এখন স্টার্চ যোগ করো → নীল-কালো', 0.8], ['নীল রং ঠিক মিলিয়ে গেলে = সমাপ্তি বিন্দু (সাদা অধঃক্ষেপ থাকে)', 1.0]]
          : [['ভিটামিন C + স্টার্চ: বর্ণহীন', 0], ['প্রতি ফোঁটা I₂ সাথে সাথে বিজারিত (I⁻) — রং থাকে না', 0.05], ['সমতুল্য বিন্দু: সব অ্যাসকরবিক এসিড জারিত', 1], ['প্রথম বাড়তি I₂ + স্টার্চ → স্থায়ী নীল = সমাপ্তি বিন্দু', 1.001]];
      T(g, 'ধাপসমূহ', px, py, col, { b: true, s: 11, a: 'left' }); stages.forEach(([s, f], i) => { const cur = st.done ? 3 : fr >= stages[2][1] ? 2 : fr >= stages[1][1] ? 1 : 0, on = i === cur; const y = py + 22 + i * (wd ? 30 : 26); g.fillStyle = on ? col.acc : col.s3 || '#ccc'; g.beginPath(); g.arc(px + 8, y - 4, 6, 0, 7); g.fill(); T(g, bn(i + 1), px + 8, y - 0.5, col, { s: 8.5, b: true, c: '#fff' }); const words = s; g.font = `${on ? 'bold ' : ''}${wd ? 10 : 9}px ${col.font}`; T(g, words, px + 20, y, col, { s: wd ? 10 : 9, a: 'left', b: on, c: on ? col.fg : col.mu }); });
      if (mi === 1 && early) T(g, '⚠️ স্টার্চ আগেভাগে দেওয়া হয়েছে — I₂-স্টার্চ জটিল ধীরে ভাঙে, সমাপ্তি বিন্দু দেরিতে ও ভুল আসতে পারে', px, py + 22 + 4 * (wd ? 30 : 26), col, { s: 9, a: 'left', c: '#e8590c', b: true });
    };
    const info = () => { const m = RT[mi]; let calc = ''; if (rec != null) { const v = rec; if (mi === 0) { const n = 0.02 * v * 5; calc = `MnO₄⁻ = ০.০২ × ${f2(v)} = ${bn((0.02 * v).toFixed(4))} mmol ⇒ Fe²⁺ = ৫ × ${bn((0.02 * v).toFixed(4))} = ${bn(n.toFixed(4))} mmol (১০ mL এ) ⇒ M(Fe²⁺) = <b>${bn((n / 10).toFixed(4))} M</b>; Fe = ${bn((n / 10 * 55.85).toFixed(3))} g/L।`; } else if (mi === 1) { const n = 0.05 * v; calc = `S₂O₃²⁻ = ০.০৫ × ${f2(v)} = ${bn(n.toFixed(4))} mmol = I₂ এর ২ গুণ = Cu²⁺ এর সমান (2Cu²⁺ ≡ I₂ ≡ 2S₂O₃²⁻) ⇒ M(Cu²⁺) = ${bn(n.toFixed(4))} ÷ ২৫ = <b>${bn((n / 25).toFixed(4))} M</b>; Cu = ${bn((n / 25 * 63.55).toFixed(3))} g/L।`; } else { const n = 0.01 * v; calc = `I₂ = ০.০১ × ${f2(v)} = ${bn(n.toFixed(4))} mmol = অ্যাসকরবিক এসিড (১ : ১) — ২৫ mL এ; ট্যাবলেট ২৫০ mL এ দ্রবীভূত ⇒ মোট ${bn((n * 10).toFixed(3))} mmol × ১৭৬.১ = <b>${bn((n * 10 * 176.12).toFixed(0))} mg</b> ভিটামিন C প্রতি ট্যাবলেটে।`; } }
      out.innerHTML = `${TXB(`\\ce{${m.eqn}}`)}${m.eqn2 ? TXB(`\\ce{${m.eqn2}}`) : ''}<div class="small">${mi === 0 ? 'KMnO₄ স্বনির্দেশক — কোনো বাহ্যিক নির্দেশক লাগে না। লঘু H₂SO₄ মাধ্যম (HCl নয় — Cl⁻ জারিত হয়)।' : mi === 1 ? 'আয়োডোমিতি (পরোক্ষ): জারক (Cu²⁺) বাড়তি I⁻ কে জারিত করে সমতুল্য I₂ মুক্ত করে; মুক্ত I₂ কে প্রমাণ থায়োসালফেট দিয়ে টাইট্রেট করা হয়। স্টার্চ শেষের দিকে দিতে হয়।' : 'আয়োডিমিতি (প্রত্যক্ষ): প্রমাণ I₂ দ্রবণ নিজেই জারক হিসেবে বিজারককে (ভিটামিন C) সরাসরি টাইট্রেট করে। স্টার্চ শুরুতেই দেওয়া যায়।'}</div>${rec != null ? `<div class="small"><b>পাঠ ${f2(rec)} mL থেকে:</b> ${calc}</div><div class="small">প্রকৃত সমতুল্য আয়তন: ${f2(eqV())} mL।</div>` : ''}`; draw(); };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (drip > 0) drip -= dt; if (flash > 0) flash -= dt * 1.5; } draw(); }, { paused: false });
    el.querySelectorAll('[data-a]').forEach(b => b.onclick = () => { added = Math.min(50, +(added + +b.dataset.a).toFixed(2)); drip = 0.6; flash = 1; info(); });
    q('[data-st]').onclick = () => { if (mi !== 1 || starch) return; starch = true; const st = state(); early = st.I2 > 0.35; info(); };
    q('[data-rec]').onclick = () => { rec = added; info(); };
    q('[data-new]').onclick = () => { added = 0; starch = mi === 2; early = false; rec = null; info(); };
    q('[data-m]').onchange = e => { mi = +e.target.value; added = 0; starch = mi === 2; early = false; rec = null; q('[data-st]').style.display = mi === 1 ? '' : 'none'; info(); };
    q('[data-st]').style.display = 'none';
    info();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
