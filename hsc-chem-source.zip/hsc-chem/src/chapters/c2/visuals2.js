/* Visuals part 2 — spectra & applications (2.5–2.11) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;
const h = 6.626e-34, c = 2.998e8, eV = 1.602e-19, NA = 6.022e23;

/* ---------- gradient helper ---------- */
const visGrad = (id, a = 380, b = 750) => { let s = `<linearGradient id="${id}" x1="0" x2="1" y1="0" y2="0">`; for (let k = 0; k <= 20; k++) { const w = a + (b - a) * k / 20; s += `<stop offset="${k / 20}" stop-color="${X.wl(w)}"/>`; } return s + '</linearGradient>'; };

V.emWave = {
  t: 'তড়িৎচুম্বকীয় তরঙ্গ: পরস্পর লম্ব তড়িৎ ও চৌম্বকক্ষেত্র', k: ['anim', 'int'],
  cap: 'তড়িৎক্ষেত্র (E, নীল) ও চৌম্বকক্ষেত্র (B, কমলা) একই দশায় স্পন্দিত হয়, পরস্পরের সাথে এবং তরঙ্গের গতির দিকের সাথে লম্ব। দুটি পরপর শীর্ষের দূরত্বই তরঙ্গদৈর্ঘ্য λ। স্লাইডার টেনে λ বদলাও — λ কমলে কম্পাঙ্ক ও শক্তি বাড়ে।',
  html: () => X.cv('তড়িৎচুম্বকীয় তরঙ্গ') + `<div class="ctl"><label style="flex:none">λ</label><input type="range" min="40" max="200" value="110" data-l style="flex:1;min-width:140px"><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const cv = el.querySelector('canvas'); const hf = W => Math.min(240, Math.max(190, W * 0.45)); let L = X.fit(cv, hf);
    let lam = 110, ph = 0; const out = el.querySelector('[data-out]');
    const info = () => { const rel = lam / 110; out.innerHTML = `আপেক্ষিক তরঙ্গদৈর্ঘ্য λ = ${X.bn(rel.toFixed(2))} একক → কম্পাঙ্ক ν = c/λ ∝ ${X.bn((1 / rel).toFixed(2))} · শক্তি E = hν ∝ ${X.bn((1 / rel).toFixed(2))} <span class="muted">(তরঙ্গদৈর্ঘ্য দ্বিগুণ হলে শক্তি অর্ধেক)</span>`; };
    el.querySelector('[data-l]').addEventListener('input', e => { lam = +e.target.value; info(); A.draw(); }); info();
    const A = X.anim(cv, dt => {
      ph += dt * 3;
      const C = X.C(), g = L.g, W = L.W, H = L.H, cy = H * 0.55, x0 = 24, x1 = W - 20, amp = H * 0.3;
      g.clearRect(0, 0, W, H);
      g.strokeStyle = C.ln; g.lineWidth = 1; g.beginPath(); g.moveTo(x0, cy); g.lineTo(x1, cy); g.stroke();
      g.fillStyle = C.mu; g.font = `12px ${C.font}`; g.fillText('গতির দিক →  c = 3×10⁸ m/s', x1 - 170, cy + amp + 22 > H - 4 ? H - 6 : cy + amp + 22);
      const k = 2 * Math.PI / lam;
      // B (perspective)
      g.strokeStyle = C.a2; g.lineWidth = 2; g.beginPath();
      for (let x = x0; x <= x1; x += 2) { const z = Math.sin(k * (x - x0) - ph) * amp * 0.75; const sx = x + z * 0.45, sy = cy - z * 0.32; x === x0 ? g.moveTo(sx, sy) : g.lineTo(sx, sy); } g.stroke();
      g.globalAlpha = 0.35; for (let x = x0; x <= x1; x += 12) { const z = Math.sin(k * (x - x0) - ph) * amp * 0.75; g.beginPath(); g.moveTo(x, cy); g.lineTo(x + z * 0.45, cy - z * 0.32); g.stroke(); } g.globalAlpha = 1;
      // E
      g.strokeStyle = C.acc; g.lineWidth = 2.4; g.beginPath();
      for (let x = x0; x <= x1; x += 2) { const y = cy - Math.sin(k * (x - x0) - ph) * amp; x === x0 ? g.moveTo(x, y) : g.lineTo(x, y); } g.stroke();
      g.globalAlpha = 0.35; for (let x = x0; x <= x1; x += 12) { const y = cy - Math.sin(k * (x - x0) - ph) * amp; g.beginPath(); g.moveTo(x, cy); g.lineTo(x, y); g.stroke(); } g.globalAlpha = 1;
      // λ bracket: find two consecutive peaks of E
      const phase = ((ph / k) % lam + lam) % lam; let p1 = x0 + lam / 4 + phase; while (p1 - lam > x0) p1 -= lam; const p2 = p1 + lam;
      if (p2 < x1) { g.strokeStyle = C.fg; g.lineWidth = 1; const yb = cy - amp - 10; g.beginPath(); g.moveTo(p1, yb + 4); g.lineTo(p1, yb); g.lineTo(p2, yb); g.lineTo(p2, yb + 4); g.stroke(); g.fillStyle = C.fg; g.font = `13px ${C.mono}`; g.fillText('λ', (p1 + p2) / 2 - 3, yb - 4); }
      g.font = `12px ${C.font}`; g.fillStyle = C.acc; g.fillText('E (তড়িৎক্ষেত্র)', x0, 14); g.fillStyle = C.a2; g.fillText('B (চৌম্বকক্ষেত্র)', x0 + 110, 14);
    });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(cv, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

const REG = [
  { k: 'g', n: 'গামা রশ্মি (γ)', a: -14, b: -11, col: '#6b3fa0', r: '< 0.01 nm', src: 'তেজস্ক্রিয় নিউক্লিয়াস, মহাজাগতিক উৎস', use: 'ক্যানসার রেডিওথেরাপি (⁶⁰Co), চিকিৎসা সরঞ্জাম ও খাদ্য জীবাণুমুক্তকরণ', harm: 'সর্বোচ্চ শক্তি; কোষ ও DNA ধ্বংস করে' },
  { k: 'x', n: 'এক্স-রে', a: -11, b: -8, col: '#7b5cc4', r: '0.01–10 nm', src: 'উচ্চগতির ইলেকট্রন ধাতুতে আঘাত (এক্স-রে নল)', use: 'হাড়ের ছবি, CT স্ক্যান, বিমানবন্দরে লাগেজ পরীক্ষা, কেলাস গঠন নির্ণয় (XRD)', harm: 'আয়নায়নকারী; অতিরিক্ত মাত্রায় ক্যানসার ঝুঁকি' },
  { k: 'uv', n: 'অতিবেগুনি (UV)', a: -8, b: Math.log10(4e-7), col: '#8e5de8', r: '10–400 nm', src: 'সূর্য, পারদ বাষ্প বাতি, জীবাণুনাশক বাতি', use: 'জাল নোট ও পাসপোর্ট শনাক্তকরণ, পানি জীবাণুমুক্তকরণ, ত্বকে ভিটামিন D সংশ্লেষণ', harm: 'রোদে পোড়া, ত্বকের ক্যানসার, চোখে ছানি' },
  { k: 'vis', n: 'দৃশ্যমান আলো', a: Math.log10(4e-7), b: Math.log10(7e-7), col: 'url(#emsVis)', r: '400–700 nm', src: 'সূর্য, বাতি, শিখা, LED', use: 'দেখা, সালোকসংশ্লেষণ, শিখা পরীক্ষা, বর্ণালিবীক্ষণ', harm: 'অতি তীব্র আলো (লেজার) চোখের ক্ষতি করতে পারে' },
  { k: 'ir', n: 'অবলোহিত (IR)', a: Math.log10(7e-7), b: -3, col: '#c0392b', r: '700 nm – 1 mm', src: 'সব উষ্ণ বস্তু (মানবদেহ ~৯.৪ μm), সূর্য', use: 'থার্মাল ইমেজিং, ইনফ্রারেড থার্মোমিটার, রিমোট কন্ট্রোল, অণুর ক্রিয়াগোষ্ঠী শনাক্তকরণ (IR বর্ণালি)', harm: 'অতিরিক্ত তাপে পোড়া' },
  { k: 'mw', n: 'মাইক্রোওয়েভ', a: -3, b: 0, col: '#a35d2a', r: '1 mm – 1 m', src: 'ম্যাগনেট্রন, রাডার', use: 'মাইক্রোওয়েভ ওভেন, মোবাইল ও Wi-Fi, রাডার, স্যাটেলাইট যোগাযোগ', harm: 'উচ্চ ক্ষমতায় টিস্যু গরম করে' },
  { k: 'rw', n: 'বেতার তরঙ্গ', a: 0, b: 4, col: '#7a6a4f', r: '> 1 m', src: 'অ্যান্টেনা, বেতার সম্প্রচার', use: 'রেডিও, টিভি সম্প্রচার, MRI (রেডিও কম্পাঙ্কের পালস)', harm: 'সাধারণ মাত্রায় ক্ষতিকর প্রমাণিত নয়' }
];
V.emSpectrum = {
  t: 'তড়িৎচুম্বকীয় বর্ণালির অঞ্চলসমূহ (ইন্টারঅ্যাকটিভ)', k: ['int', 'info'],
  cap: 'স্লাইডার টেনে যেকোনো তরঙ্গদৈর্ঘ্য বেছে নাও অথবা কোনো অঞ্চলে চাপ দাও। অনুভূমিক অক্ষ লগারিদমিক — প্রতিটি দাগে তরঙ্গদৈর্ঘ্য ১০ গুণ বাড়ে। দৃশ্যমান আলো পুরো বর্ণালির খুবই ক্ষুদ্র অংশ। (অঞ্চলের সীমা বিভিন্ন বইয়ে সামান্য ভিন্ন।)',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none">log₁₀λ</label><input type="range" min="-13.5" max="3.5" step="0.01" value="-6.27" data-s style="flex:1;min-width:150px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sl = el.querySelector('[data-s]');
    const x = v => 10 + (v + 14) / 18 * 380;
    const draw = v => {
      let s = `<defs>${visGrad('emsVis')}${visGrad('emsVis2')}</defs>`;
      REG.forEach(r => { s += `<rect x="${x(r.a)}" y="34" width="${x(r.b) - x(r.a)}" height="40" fill="${r.col}" data-r="${r.k}" style="cursor:pointer"/>`; });
      REG.forEach((r, i) => { const mx = (x(r.a) + x(r.b)) / 2; const yy = i % 2 ? 92 : 24; s += `<text x="${r.k === 'vis' ? mx + 2 : mx}" y="${yy}" text-anchor="middle" style="font-size:11px">${r.n.replace(/ \(.*\)/, '')}</text>`; });
      for (let d = -14; d <= 4; d += 2) s += `<line x1="${x(d)}" y1="74" x2="${x(d)}" y2="80" class="s-fg"/><text x="${x(d)}" y="112" text-anchor="middle" class="tm mono" style="font-size:10px">10${X.sup(d)}</text>`;
      s += `<text x="200" y="128" text-anchor="middle" class="tm">তরঙ্গদৈর্ঘ্য (মিটার) →   কম্পাঙ্ক ও শক্তি ←</text>`;
      s += `<rect x="10" y="146" width="380" height="26" fill="url(#emsVis2)"/>`;
      [400, 450, 500, 550, 600, 650, 700].forEach(w => s += `<text x="${10 + (w - 380) / 370 * 380}" y="186" text-anchor="middle" class="tm mono" style="font-size:10px">${w}</text>`);
      s += `<text x="200" y="200" text-anchor="middle" class="tm">দৃশ্যমান অংশ বড় করে (nm): বেগুনি → লাল</text>`;
      const px = x(v); s += `<line x1="${px}" y1="28" x2="${px}" y2="80" stroke="var(--fg)" stroke-width="2"/><path d="M${px - 6} 28 L${px + 6} 28 L${px} 36Z" class="f-fg"/>`;
      const nm = Math.pow(10, v) * 1e9; if (nm >= 380 && nm <= 750) { const vx = 10 + (nm - 380) / 370 * 380; s += `<line x1="${vx}" y1="142" x2="${vx}" y2="176" stroke="var(--fg)" stroke-width="2"/>`; }
      box.innerHTML = X.svg(400, 206, s, 'তড়িৎচুম্বকীয় বর্ণালি');
      box.querySelectorAll('[data-r]').forEach(r => r.addEventListener('click', () => { const R = REG.find(q => q.k === r.dataset.r); const mid = (R.a + R.b) / 2; sl.value = mid; upd(mid); }));
      const R = REG.find(r => v >= r.a && v < r.b) || REG[REG.length - 1];
      const lm = Math.pow(10, v), nu = c / lm, E = h * nu;
      const fmtL = lm < 1e-9 ? X.sci(lm * 1e9) + ' nm' : lm < 1e-6 ? (lm * 1e9).toFixed(1) + ' nm' : lm < 1e-3 ? X.sci(lm * 1e6) + ' μm' : lm < 1 ? X.sci(lm * 1e3) + ' mm' : X.sci(lm) + ' m';
      out.innerHTML = `<b style="font-family:var(--font-body)">${R.n}</b> (${R.r}) — λ = <b>${fmtL}</b> · ν = <b>${X.sci(nu)} Hz</b> · E = <b>${X.sci(E)} J</b> = <b>${X.sci(E / eV)} eV</b><br><span class="small"><b>উৎস:</b> ${R.src}<br><b>ব্যবহার:</b> ${R.use}<br><b>ঝুঁকি:</b> ${R.harm}</span>`;
    };
    const upd = v => draw(+v);
    sl.addEventListener('input', e => upd(e.target.value)); upd(-6.27);
  }
};

V.prismSplit = {
  t: 'প্রিজমে সাদা আলোর বিচ্ছুরণ', k: ['2d'],
  cap: 'সাদা আলো প্রিজমে প্রবেশ করলে বিভিন্ন তরঙ্গদৈর্ঘ্যের আলো ভিন্ন পরিমাণে বাঁকে — বেগুনি (ক্ষুদ্রতম λ) সবচেয়ে বেশি, লাল সবচেয়ে কম। ফলে পর্দায় অবিচ্ছিন্ন রংধনু (VIBGYOR / বেনীআসহকলা) দেখা যায়।',
  html() {
    const cols = [[700, 'লাল'], [620, 'কমলা'], [580, 'হলুদ'], [530, 'সবুজ'], [475, 'আসমানি'], [445, 'নীল'], [410, 'বেগুনি']];
    let rays = cols.map(([w, n], i) => { const y = 92 + i * 15; return `<line x1="232" y1="${118 + i * 2}" x2="352" y2="${y}" stroke="${X.wl(w)}" stroke-width="3"/><text x="356" y="${y + 4}" style="font-size:11px">${n}</text>`; }).join('');
    return X.svg(400, 220, `<line x1="10" y1="140" x2="160" y2="128" stroke="#f4f1e8" stroke-width="5"/><line x1="10" y1="140" x2="160" y2="128" class="s-mu" stroke-width="1"/>
      <text x="14" y="160" class="tm">সাদা আলো</text>
      <polygon points="200,40 140,180 260,180" fill="var(--accent-soft)" stroke="var(--accent)" stroke-width="1.5" opacity=".9"/>
      <line x1="160" y1="128" x2="232" y2="122" stroke="#f4f1e8" stroke-width="4"/>${rays}
      <text x="200" y="200" text-anchor="middle" class="tm">কাচের প্রিজম</text>`, 'প্রিজম');
  }
};

V.planckCalc = {
  t: 'প্ল্যাঙ্কের সমীকরণ ক্যালকুলেটর: E = hν = hc/λ', k: ['calc'],
  cap: 'একটি ফোটনের শক্তি, এক মোল ফোটনের শক্তি (এক আইনস্টাইন) এবং নির্দিষ্ট মোট শক্তিতে ফোটনের সংখ্যা।',
  html: () => `<div class="grid2"><label class="stack" style="gap:4px"><span class="small muted">তরঙ্গদৈর্ঘ্য λ (nm)</span><input class="inp" type="number" value="500" data-l></label><label class="stack" style="gap:4px"><span class="small muted">মোট শক্তি (J) — ঐচ্ছিক</span><input class="inp" type="number" value="1" data-e></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const run = () => { const l = (+el.querySelector('[data-l]').value || 500) * 1e-9, Et = +el.querySelector('[data-e]').value || 0; const nu = c / l, E = h * nu; el.querySelector('[data-out]').innerHTML = `ν = c/λ = <b>${X.sci(nu)} Hz</b> · ν̄ = 1/λ = <b>${X.sci(1 / l / 100)} cm⁻¹</b><br>একটি ফোটনের শক্তি E = hν = <b>${X.sci(E)} J</b> = <b>${(E / eV).toFixed(3)} eV</b><br>এক মোল ফোটন: E × N<sub>A</sub> = <b>${(E * NA / 1000).toFixed(1)} kJ mol⁻¹</b>${Et ? `<br>${X.sci(Et)} J শক্তিতে ফোটন সংখ্যা = ${X.sci(Et)} / ${X.sci(E)} = <b>${X.sci(Et / E)}টি</b>` : ''}`; };
    el.querySelectorAll('input').forEach(i => i.addEventListener('input', run)); run();
  }
};

const LINES = {
  H: { n: 'হাইড্রোজেন (H)', l: [[410.2, .45], [434.0, .55], [486.1, .8], [656.3, 1]] },
  He: { n: 'হিলিয়াম (He)', l: [[447.1, .6], [471.3, .3], [492.2, .3], [501.6, .5], [587.6, 1], [667.8, .6], [706.5, .45]] },
  Na: { n: 'সোডিয়াম (Na)', l: [[589.0, 1], [589.6, .9], [568.8, .15], [616.1, .15], [498.3, .1]] },
  Hg: { n: 'পারদ (Hg)', l: [[404.7, .6], [435.8, 1], [546.1, 1], [577.0, .6], [579.1, .6]] },
  Ne: { n: 'নিয়ন (Ne)', l: [[585.2, .7], [588.2, .4], [594.5, .5], [597.6, .3], [603.0, .4], [607.4, .4], [609.6, .5], [614.3, .6], [616.4, .4], [621.7, .4], [626.6, .5], [633.4, .6], [638.3, .6], [640.2, .9], [650.7, .6], [659.9, .4], [692.9, .5], [703.2, .6]] },
  Li: { n: 'লিথিয়াম (Li)', l: [[670.8, 1], [610.4, .45], [460.3, .15]] },
  K: { n: 'পটাশিয়াম (K)', l: [[766.5, 1], [769.9, .9], [404.4, .35], [404.7, .35]] }
};
const strip = (lines, y, h, idp, opts = {}) => {
  const x = w => 10 + (w - 380) / 400 * 380;
  let s = `<rect x="10" y="${y}" width="380" height="${h}" rx="3" fill="${opts.abs ? `url(#${idp}g)` : '#0d0b12'}"/>`;
  lines.forEach(([w, a]) => { s += `<rect x="${(x(w) - 1.2).toFixed(1)}" y="${y}" width="2.4" height="${h}" fill="${opts.abs ? '#0d0b12' : X.wl(w)}" opacity="${opts.abs ? 0.85 : Math.max(.35, a)}"/>`; });
  return s;
};
V.spectraTypes = {
  t: 'বর্ণালির প্রকারভেদ: অবিচ্ছিন্ন, নির্গমন রেখা, শোষণ রেখা ও ব্যান্ড', k: ['2d'],
  cap: 'উত্তপ্ত কঠিন বা ঘন বস্তু সব রঙের অবিচ্ছিন্ন বর্ণালি দেয়। উত্তপ্ত বা উত্তেজিত গ্যাসীয় পরমাণু কালো পটভূমিতে কয়েকটি উজ্জ্বল রেখা দেয় (নির্গমন)। সাদা আলো শীতল গ্যাসের মধ্য দিয়ে গেলে ঠিক একই জায়গায় কালো রেখা পড়ে (শোষণ)। অণু ঘনভাবে সাজানো রেখার গুচ্ছ বা ব্যান্ড দেয়।',
  html() {
    const H = LINES.H.l; let band = ''; [[390, 6], [427, 8], [470, 6], [520, 7], [560, 6]].forEach(([w0, n]) => { for (let i = 0; i < n; i++) band += `<rect x="${(10 + (w0 + i * 2.2 - 380) / 400 * 380).toFixed(1)}" y="214" width="1.6" height="26" fill="${X.wl(w0 + i * 2.2)}" opacity="${1 - i / (n + 2)}"/>`; });
    const lab = (y, t) => `<text x="10" y="${y}" style="font-size:12.5px;font-weight:600">${t}</text>`;
    let ax = ''; [400, 500, 600, 700].forEach(w => ax += `<text x="${10 + (w - 380) / 400 * 380}" y="258" text-anchor="middle" class="tm mono" style="font-size:10px">${w} nm</text>`);
    return X.svg(400, 264, `<defs>${visGrad('stG', 380, 780)}${visGrad('stAg', 380, 780)}</defs>
      ${lab(14, '১. অবিচ্ছিন্ন বর্ণালি — বাল্বের উত্তপ্ত ফিলামেন্ট, সূর্যের ভেতরের অংশ')}<rect x="10" y="20" width="380" height="26" rx="3" fill="url(#stG)"/>
      ${lab(66, '২. নির্গমন রেখা বর্ণালি — উত্তপ্ত হাইড্রোজেন গ্যাস')}${strip(H, 72, 26, 'st')}
      ${lab(118, '৩. শোষণ রেখা বর্ণালি — শীতল H গ্যাসের মধ্য দিয়ে সাদা আলো')}${strip(H, 124, 26, 'stA', { abs: true })}
      <text x="10" y="170" class="tm">২ ও ৩ নম্বরে রেখার অবস্থান হুবহু এক — এটাই মৌলের "আঙুলের ছাপ"</text>
      ${lab(206, '৪. ব্যান্ড বর্ণালি — অণু (যেমন N₂, CO)')}<rect x="10" y="214" width="380" height="26" rx="3" fill="#0d0b12"/>${band}${ax}`, 'বর্ণালির প্রকারভেদ');
  }
};

V.fingerprints = {
  t: 'মৌলের রেখা বর্ণালি: "আঙুলের ছাপ" মিলিয়ে শনাক্তকরণ', k: ['int'],
  cap: 'প্রতিটি মৌলের রেখার অবস্থান (তরঙ্গদৈর্ঘ্য) অনন্য। নিচের "অজানা নমুনা"-র বর্ণালি দেখে কোন কোন মৌল আছে তা টিক দিয়ে যাচাই করো — বিজ্ঞানীরা ঠিক এভাবেই নক্ষত্রের গঠন জানেন। (তরঙ্গদৈর্ঘ্য nm এককে, প্রধান দৃশ্যমান রেখাগুলো দেখানো হয়েছে।)',
  html: () => `<div data-ref></div><div class="divider" style="margin:10px 0"></div><b class="small">অজানা নমুনা</b><div data-mys></div><div class="row" data-checks style="gap:6px 12px;margin-top:6px"></div><div class="ctl"><button class="btn sm primary" data-chk>${X.ico('check')}যাচাই করো</button><button class="btn sm" data-new>${X.ico('repeat')}নতুন নমুনা</button></div><div class="calc-out" data-out>দুটি মৌলের মিশ্রণ। কোনগুলো আছে?</div>`,
  mount(el) {
    const keys = Object.keys(LINES);
    const ax = y => [400, 450, 500, 550, 600, 650, 700, 750].map(w => `<text x="${10 + (w - 380) / 400 * 380}" y="${y}" text-anchor="middle" class="tm mono" style="font-size:9.5px">${w}</text>`).join('');
    let ref = ''; keys.forEach((k, i) => { const y = 6 + i * 34; ref += `<text x="10" y="${y + 10}" style="font-size:11.5px">${LINES[k].n}</text>${strip(LINES[k].l, y + 14, 16, 'fp' + k)}`; });
    el.querySelector('[data-ref]').innerHTML = X.svg(400, keys.length * 34 + 22, ref + ax(keys.length * 34 + 16), 'মৌলের বর্ণালি');
    const pool = ['H', 'He', 'Na', 'Hg', 'Li', 'K']; let ans = [];
    const chk = el.querySelector('[data-checks]');
    chk.innerHTML = pool.map(k => `<label class="row small" style="gap:4px"><input type="checkbox" value="${k}"> ${k}</label>`).join('');
    const newS = () => { ans = pool.slice().sort(() => Math.random() - .5).slice(0, 2); const lines = ans.flatMap(k => LINES[k].l); el.querySelector('[data-mys]').innerHTML = X.svg(400, 46, strip(lines, 4, 24, 'mys') + ax(42), 'অজানা নমুনা'); chk.querySelectorAll('input').forEach(i => i.checked = false); el.querySelector('[data-out]').innerHTML = 'দুটি মৌলের মিশ্রণ। কোনগুলো আছে?'; };
    el.querySelector('[data-new]').onclick = newS;
    el.querySelector('[data-chk]').onclick = () => { const pick = [...chk.querySelectorAll('input:checked')].map(i => i.value).sort(); const ok = pick.join() === ans.slice().sort().join(); el.querySelector('[data-out]').innerHTML = ok ? `<b style="color:var(--ok)">সঠিক!</b> নমুনায় ${ans.map(k => LINES[k].n).join(' ও ')} আছে।` : `<b style="color:var(--bad)">মেলেনি।</b> প্রতিটি রেখা উপরের তালিকার সাথে মেলাও — একটি মৌলের সব প্রধান রেখা উপস্থিত থাকতে হবে। <button class="btn sm ghost" data-show style="min-height:0;padding:0 4px;color:var(--accent)">উত্তর দেখো</button>`; const s = el.querySelector('[data-show]'); if (s) s.onclick = () => { el.querySelector('[data-out]').innerHTML = `উত্তর: ${ans.map(k => LINES[k].n).join(' ও ')}`; }; };
    newS();
  }
};

/* ---------- Hydrogen spectrum series ---------- */
const RH = 1.0968e7;
const SER = [['লাইম্যান', 1, 'UV'], ['বামার', 2, 'দৃশ্যমান'], ['পাশেন', 3, 'IR'], ['ব্র্যাকেট', 4, 'IR'], ['ফুন্ড', 5, 'দূর IR']];
const lamNm = (n1, n2, Z = 1) => 1e9 / (RH * Z * Z * (1 / (n1 * n1) - 1 / (n2 * n2)));
V.hSeries = {
  t: 'হাইড্রোজেনের পারমাণবিক বর্ণালি: পাঁচটি ধারা', k: ['anim', 'int'],
  cap: 'একটি ধারা বেছে নাও। শক্তিস্তর চিত্রে ঐ ধারার সব স্থানান্তর (তীর) এবং নিচে বর্ণালিতে রেখাগুলোর অবস্থান দেখা যাবে। প্রতিটি ধারার রেখাগুলো ছোট তরঙ্গদৈর্ঘ্যের দিকে ক্রমশ ঘন হয়ে ধারা-সীমায় (n₂ → ∞) মিলিত হয়। শক্তিস্তরের ব্যবধান স্কেল অনুপাতে নয়।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('ser', SER.map(([n, k]) => [k, n]), 2)}</div><div data-svg></div><div data-tab></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), tab = el.querySelector('[data-tab]');
    const yN = n => n === Infinity ? 34 : 262 - 220 * (1 - 1 / n);
    const xs = { 1: 64, 2: 134, 3: 204, 4: 262, 5: 316 };
    const lx = w => 10 + (Math.log10(w) - Math.log10(80)) / (Math.log10(8000) - Math.log10(80)) * 380;
    const draw = sel => {
      sel = +sel; let s = `<defs>${visGrad('hsV', 400, 700)}</defs>`;
      for (let n = 1; n <= 7; n++) { const y = yN(n); s += `<line x1="44" y1="${y}" x2="392" y2="${y}" class="s-ln"/><text x="6" y="${y + 4}" class="mono" style="font-size:11px">n=${n}</text><text x="392" y="${y - 3}" text-anchor="end" class="tm mono" style="font-size:9.5px">${(-13.6 / n / n).toFixed(2)} eV</text>`; }
      s += `<line x1="44" y1="${yN(Infinity)}" x2="392" y2="${yN(Infinity)}" class="s-mu" stroke-dasharray="4 3"/><text x="6" y="${yN(Infinity) + 4}" class="mono" style="font-size:11px">n=∞</text>`;
      let delay = 0;
      SER.forEach(([nm, n1]) => {
        const on = n1 === sel;
        for (let n2 = n1 + 1; n2 <= 7; n2++) {
          const x = xs[n1] + (n2 - n1 - 1) * 8, w = lamNm(n1, n2), vis = w >= 380 && w <= 750;
          const col = on ? (vis ? X.wl(w) : 'var(--accent)') : 'var(--line-strong)';
          s += `<line x1="${x}" y1="${yN(n2)}" x2="${x}" y2="${yN(n1) - 5}" stroke="${col}" stroke-width="${on ? 2.4 : 1.2}" ${on ? `style="stroke-dasharray:300;stroke-dashoffset:300;animation:drawln .5s ${(delay += .18).toFixed(2)}s forwards"` : ''}/><path d="M${x - 3.5} ${yN(n1) - 8} L${x + 3.5} ${yN(n1) - 8} L${x} ${yN(n1) - 1}Z" fill="${col}"/>`;
        }
        s += `<text x="${xs[n1] - 6}" y="${yN(n1) + 14}" style="font-size:10.5px;${on ? 'font-weight:700' : ''}" ${on ? '' : 'class="tm"'}>${nm}</text>`;
      });
      // spectrum strip
      const y0 = 290; s += `<rect x="10" y="${y0}" width="${lx(400) - 10}" height="22" fill="#4a2a78" opacity=".55"/><rect x="${lx(400)}" y="${y0}" width="${lx(700) - lx(400)}" height="22" fill="url(#hsV)"/><rect x="${lx(700)}" y="${y0}" width="${390 - lx(700)}" height="22" fill="#5a1a1a" opacity=".55"/>`;
      s += `<text x="${(10 + lx(400)) / 2}" y="${y0 + 36}" text-anchor="middle" class="tm">UV</text><text x="${(lx(400) + lx(700)) / 2}" y="${y0 + 36}" text-anchor="middle" class="tm">দৃশ্যমান</text><text x="${(lx(700) + 390) / 2}" y="${y0 + 36}" text-anchor="middle" class="tm">IR</text>`;
      for (let n2 = sel + 1; n2 <= 12; n2++) { const w = lamNm(sel, n2); s += `<line x1="${lx(w)}" y1="${y0 - 4}" x2="${lx(w)}" y2="${y0 + 26}" stroke="var(--fg)" stroke-width="${n2 <= 7 ? 2 : 1}" opacity="${n2 <= 7 ? 1 : .5}"/>`; }
      const lim = lamNm(sel, 1e9); s += `<line x1="${lx(lim)}" y1="${y0 - 8}" x2="${lx(lim)}" y2="${y0 + 26}" stroke="var(--bad)" stroke-dasharray="2 2"/><text x="${lx(lim)}" y="${y0 - 11}" text-anchor="middle" style="font-size:10px;fill:var(--bad)">সীমা</text>`;
      [100, 1000].forEach(w => s += `<text x="${lx(w)}" y="${y0 + 50}" text-anchor="middle" class="tm mono" style="font-size:9.5px">${w} nm</text>`);
      box.innerHTML = X.svg(400, 346, s, 'হাইড্রোজেন বর্ণালি');
      const S = SER.find(q => q[1] === sel);
      const rows = []; for (let n2 = sel + 1; n2 <= sel + 5; n2++) { const w = lamNm(sel, n2); rows.push(`<tr><td>${n2} → ${sel}</td><td class="mono">${(1e7 / w).toFixed(0)}</td><td class="mono"><b>${w >= 1000 ? (w / 1000).toFixed(3) + ' μm' : w.toFixed(1) + ' nm'}</b></td><td>${w < 400 ? 'UV' : w <= 700 ? '<span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:' + X.wl(w) + '"></span> দৃশ্যমান' : 'IR'}</td></tr>`); }
      tab.innerHTML = `<div class="table-wrap" style="margin-bottom:0"><table class="t"><thead><tr><th>স্থানান্তর</th><th>ν̄ (cm⁻¹)</th><th>λ</th><th>অঞ্চল</th></tr></thead><tbody>${rows.join('')}<tr><td>∞ → ${sel} (ধারা-সীমা)</td><td class="mono">${(1e7 / lim).toFixed(0)}</td><td class="mono"><b>${lim >= 1000 ? (lim / 1000).toFixed(3) + ' μm' : lim.toFixed(1) + ' nm'}</b></td><td>${S[2]}</td></tr></tbody></table></div>`;
    };
    X.onSeg(el, 'ser', draw); draw(2);
  }
};
V.rydbergCalc = {
  t: 'রিডবার্গ সমীকরণ ক্যালকুলেটর', k: ['calc'],
  cap: '1/λ = R<sub>H</sub>Z²(1/n₁² − 1/n₂²), R<sub>H</sub> = 109678 cm⁻¹। n₂ স্তর থেকে ভূমিস্তরে নামলে সম্ভাব্য মোট রেখা = n₂(n₂ − 1)/2।',
  html: () => `<div class="grid3"><label class="stack" style="gap:4px"><span class="small muted">n₁</span><input class="inp" type="number" min="1" value="2" data-a></label><label class="stack" style="gap:4px"><span class="small muted">n₂</span><input class="inp" type="number" min="2" value="4" data-b></label><label class="stack" style="gap:4px"><span class="small muted">Z</span><select class="inp" data-z><option value="1">1 (H)</option><option value="2">2 (He⁺)</option><option value="3">3 (Li²⁺)</option></select></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const run = () => { const a = Math.max(1, +el.querySelector('[data-a]').value || 1), b = +el.querySelector('[data-b]').value || 2, Z = +el.querySelector('[data-z]').value; const o = el.querySelector('[data-out]'); if (b <= a) { o.innerHTML = '<span style="color:var(--bad)">n₂ অবশ্যই n₁ এর চেয়ে বড় হবে।</span>'; return; } const nb = 109678 * Z * Z * (1 / (a * a) - 1 / (b * b)); const lam = 1 / nb; const E = h * c / (lam / 100); const ser = a <= 5 ? SER[a - 1][0] : (a === 6 ? 'হামফ্রিজ' : '—'); o.innerHTML = `ν̄ = <b>${nb.toFixed(1)} cm⁻¹</b> · λ = <b>${(lam * 1e7).toFixed(2)} nm</b> · ν = <b>${X.sci(c / (lam / 100))} Hz</b><br>E = <b>${X.sci(E)} J</b> = <b>${(E / eV).toFixed(3)} eV</b> · ${Z === 1 ? 'ধারা: <b>' + ser + '</b>' : 'এক-ইলেকট্রন আয়ন'}<br>n = ${b} থেকে ভূমিস্তর পর্যন্ত সম্ভাব্য মোট রেখা = ${b}(${b} − 1)/2 = <b>${b * (b - 1) / 2}টি</b>; n₂ থেকে n₁ পর্যন্ত = (${b} − ${a})(${b} − ${a} + 1)/2 = <b>${(b - a) * (b - a + 1) / 2}টি</b>`; };
    el.querySelectorAll('input,select').forEach(i => i.addEventListener('input', run)); run();
  }
};

/* ---------- UV ---------- */
V.uvDemo = {
  t: 'UV বাতির নিচে আসল বনাম জাল নোট ও পাসপোর্ট (শিক্ষামূলক নমুনা)', k: ['int'],
  cap: 'এটি একটি কাল্পনিক নমুনা নোট — কোনো দেশের প্রকৃত নোটের নকশা নয়। আসল নিরাপত্তা কাগজে অপটিক্যাল ব্রাইটেনার থাকে না বলে UV-তে কাগজ ম্লান থাকে, কিন্তু ভেতরের প্রতিপ্রভ আঁশ, সংখ্যা ও নিরাপত্তা সুতা উজ্জ্বল হয়ে ওঠে। সাধারণ কাগজে ছাপা জাল নোট পুরোটাই নীলচে-সাদা জ্বলে এবং লুকানো চিহ্নগুলো থাকে না।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('doc', [['real', 'আসল নোট'], ['fake', 'জাল নোট'], ['pass', 'পাসপোর্ট পাতা']], 'real')}<button class="btn sm primary" data-uv>UV বাতি জ্বালাও</button></div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    let doc = 'real', uv = false; const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), btn = el.querySelector('[data-uv]');
    const rnd = X.rng(5); const fibers = Array.from({ length: 34 }, () => [24 + rnd() * 352, 34 + rnd() * 152, rnd() * 3.14, ['#ff4fd8', '#3fff9b', '#ffe14a', '#4fc3ff'][Math.floor(rnd() * 4)]]);
    const draw = () => {
      const bg = uv ? '#140726' : 'var(--surface-2)';
      let s = `<rect width="400" height="220" rx="12" fill="${bg}"/>`;
      if (doc !== 'pass') {
        const paper = uv ? (doc === 'fake' ? '#cfe0ff' : '#2a2340') : '#efe6cf';
        s += `<rect x="16" y="26" width="368" height="168" rx="8" fill="${paper}" stroke="${uv ? '#5b4b80' : '#b9a77a'}"/>`;
        if (uv && doc === 'fake') s += `<rect x="16" y="26" width="368" height="168" rx="8" fill="#e8f0ff" opacity=".7" style="filter:blur(4px)"/>`;
        s += `<rect x="28" y="38" width="344" height="144" rx="6" fill="none" stroke="${uv ? (doc === 'fake' ? '#8aa0d0' : '#4b3d6e') : '#8d7a4c'}" stroke-dasharray="6 3"/>`;
        s += `<text x="60" y="120" style="font-size:54px;font-family:var(--font-display);fill:${uv ? (doc === 'fake' ? '#6f86b8' : '#3d3060') : '#6d5a2c'}">১০০</text>`;
        s += `<text x="210" y="70" style="font-size:13px;fill:${uv ? (doc === 'fake' ? '#5c6f99' : '#57487d') : '#5b4a22'}">নমুনা নোট · শিক্ষামূলক</text><text x="210" y="90" style="font-size:11px;fill:${uv ? '#57487d' : '#7d6a3c'}">আসল মুদ্রা নয়</text>`;
        s += `<circle cx="300" cy="140" r="26" fill="none" stroke="${uv ? '#4b3d6e' : '#a8935e'}" stroke-width="2"/><text x="300" y="145" text-anchor="middle" style="font-size:11px;fill:${uv ? '#57487d' : '#7d6a3c'}">জলছাপ</text>`;
        s += `<rect x="176" y="26" width="5" height="168" fill="${uv && doc === 'real' ? '#ff5bd1' : (uv ? '#a9b8de' : '#9a8a64')}" ${uv && doc === 'real' ? 'style="filter:drop-shadow(0 0 4px #ff5bd1)"' : ''}/>`;
        if (doc === 'real') { s += fibers.map(([x, y, a, col]) => `<line x1="${x}" y1="${y}" x2="${(x + 7 * Math.cos(a)).toFixed(1)}" y2="${(y + 7 * Math.sin(a)).toFixed(1)}" stroke="${uv ? col : '#d8c9a2'}" stroke-width="${uv ? 1.6 : 1}" opacity="${uv ? 1 : .5}"/>`).join(''); if (uv) s += `<text x="60" y="168" style="font-size:20px;font-family:var(--font-mono);fill:#3fff9b;filter:drop-shadow(0 0 4px #3fff9b)">AB 1234567</text><path d="M220 120 q20 -20 40 0 t40 0 t40 0" fill="none" stroke="#ffe14a" stroke-width="2" style="filter:drop-shadow(0 0 3px #ffe14a)"/>`; else s += `<text x="60" y="168" style="font-size:20px;font-family:var(--font-mono);fill:#8d7a4c">AB 1234567</text>`; }
        else s += `<text x="60" y="168" style="font-size:20px;font-family:var(--font-mono);fill:${uv ? '#7a8fbf' : '#8d7a4c'}">AB 1234567</text>`;
      } else {
        s += `<rect x="16" y="20" width="368" height="180" rx="8" fill="${uv ? '#241b3d' : '#e9eef0'}" stroke="${uv ? '#4b3d6e' : '#9fb0b8'}"/>`;
        s += `<rect x="30" y="44" width="80" height="100" rx="6" fill="${uv ? '#2f2650' : '#cfd8dc'}"/><circle cx="70" cy="80" r="18" fill="${uv ? '#3b3160' : '#a9b6bc'}"/><path d="M42 140 q28 -40 56 0z" fill="${uv ? '#3b3160' : '#a9b6bc'}"/>`;
        ['নমুনা পাসপোর্ট (শিক্ষামূলক)', 'নাম: ক খ গ', 'জন্ম: ০১.০১.২০০৮', 'নম্বর: X0000000'].forEach((t, i) => s += `<text x="126" y="${60 + i * 22}" style="font-size:${i ? 12 : 13}px;fill:${uv ? '#5d5185' : '#37474f'}">${t}</text>`);
        s += `<text x="30" y="178" style="font-size:11px;font-family:var(--font-mono);fill:${uv ? '#5d5185' : '#546e7a'}">P&lt;XXXSAMPLE&lt;&lt;STUDENT&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;</text>`;
        if (uv) { for (let i = 0; i < 6; i++) s += `<path d="M20 ${40 + i * 26} q46 -16 92 0 t92 0 t92 0 t92 0" fill="none" stroke="#4fc3ff" stroke-width="1.4" opacity=".75"/>`; s += `<circle cx="300" cy="110" r="38" fill="none" stroke="#ff4fd8" stroke-width="3" style="filter:drop-shadow(0 0 5px #ff4fd8)"/><path d="M300 80 l9 20 22 2 -17 14 6 22 -20 -12 -20 12 6 -22 -17 -14 22 -2z" fill="#ffe14a" opacity=".9" style="filter:drop-shadow(0 0 4px #ffe14a)"/><rect x="30" y="44" width="80" height="100" rx="6" fill="none" stroke="#3fff9b" stroke-width="2" style="filter:drop-shadow(0 0 4px #3fff9b)"/>`; }
      }
      if (uv) s += `<rect x="150" y="2" width="100" height="16" rx="4" fill="#3b1f66"/><text x="200" y="14" text-anchor="middle" style="font-size:10px;fill:#d9c4ff">UV-A বাতি ~৩৬৫ nm</text>`;
      box.innerHTML = X.svg(400, 220, s, 'UV শনাক্তকরণ');
      const msg = { real: uv ? '<b>আসল নোট:</b> কাগজ ম্লান (প্রতিপ্রভ নয়), কিন্তু রঙিন নিরাপত্তা আঁশ, সিরিয়াল নম্বর, নকশা ও নিরাপত্তা সুতা উজ্জ্বল — UV শোষণ করে দৃশ্যমান আলো নির্গমন (প্রতিপ্রভা)।' : 'সাধারণ আলোয় আসল ও জাল নোট প্রায় একই রকম দেখায়। UV বাতি জ্বালাও।', fake: uv ? '<b>জাল নোট:</b> সাধারণ কাগজে থাকা অপটিক্যাল ব্রাইটেনার পুরো কাগজকে নীলচে-সাদা উজ্জ্বল করে; লুকানো প্রতিপ্রভ চিহ্ন নেই — সহজেই ধরা পড়ে।' : 'দেখতে আসলের মতো — কিন্তু UV-তে পরীক্ষা করো।', pass: uv ? '<b>পাসপোর্ট:</b> পাতায় অদৃশ্য প্রতিপ্রভ কালির নকশা, প্রতীক ও ছবির চারপাশের চিহ্ন UV-তে ফুটে ওঠে; ইমিগ্রেশনে স্ক্যানারের UV বাতি দিয়ে যাচাই করা হয়।' : 'সাধারণ আলোয় শুধু ছাপা তথ্য দেখা যায়।' };
      out.innerHTML = msg[doc]; btn.textContent = uv ? 'UV বাতি নেভাও' : 'UV বাতি জ্বালাও';
    };
    X.onSeg(el, 'doc', k => { doc = k; draw(); }); btn.onclick = () => { uv = !uv; draw(); }; draw();
  }
};

/* ---------- IR ---------- */
V.irThermo = {
  t: 'থার্মাল ইমেজিং ও ভীনের সূত্র: দেহ থেকে নির্গত অবলোহিত রশ্মি', k: ['int', 'calc'],
  cap: 'প্রতিটি উষ্ণ বস্তু তাপমাত্রা অনুযায়ী IR রশ্মি বিকিরণ করে। থার্মাল ক্যামেরা এই বিকিরণ মেপে রঙে রূপান্তর করে — লাল/হলুদ বেশি উষ্ণ, নীল ঠান্ডা। ভীনের সূত্র λ<sub>max</sub> = b/T (b = 2.898×10⁻³ m K) অনুযায়ী মানবদেহ (~৩১০ K) সবচেয়ে বেশি বিকিরণ করে প্রায় ৯.৩ μm তরঙ্গদৈর্ঘ্যে।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('st', [['n', 'সুস্থ'], ['f', 'জ্বর'], ['k', 'হাঁটুতে প্রদাহ']], 'n')}</div><div data-svg></div><div class="ctl"><label style="flex:none">শরীরের তাপমাত্রা</label><input type="range" min="30" max="42" step="0.1" value="37" data-t style="flex:1;min-width:140px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    let st = 'n', T = 37; const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const heat = v => { const s = ['#1b1f6b', '#2346c9', '#14b0c7', '#3ccf5a', '#f2e030', '#f28a1e', '#e2261b', '#ffffff']; const i = Math.max(0, Math.min(6.999, v * 7)); const a = Math.floor(i); return s[a]; };
    const draw = () => {
      const base = st === 'f' ? 0.78 : 0.62;
      const part = (k) => ({ head: base + .1, torso: base + .08, arm: base - .12, hand: base - .25, leg: base - .1, kneeL: st === 'k' ? .9 : base - .12, kneeR: base - .12, foot: base - .32 })[k];
      let s = `<rect width="400" height="260" rx="10" fill="#0a0c1a"/>`;
      const cx = 140;
      s += `<circle cx="${cx}" cy="38" r="22" fill="${heat(part('head'))}"/>`;
      s += `<rect x="${cx - 32}" y="64" width="64" height="86" rx="18" fill="${heat(part('torso'))}"/>`;
      s += `<rect x="${cx - 56}" y="70" width="20" height="70" rx="10" fill="${heat(part('arm'))}"/><rect x="${cx + 36}" y="70" width="20" height="70" rx="10" fill="${heat(part('arm'))}"/>`;
      s += `<circle cx="${cx - 46}" cy="148" r="10" fill="${heat(part('hand'))}"/><circle cx="${cx + 46}" cy="148" r="10" fill="${heat(part('hand'))}"/>`;
      s += `<rect x="${cx - 28}" y="148" width="24" height="44" rx="10" fill="${heat(part('leg'))}"/><rect x="${cx + 4}" y="148" width="24" height="44" rx="10" fill="${heat(part('leg'))}"/>`;
      s += `<circle cx="${cx - 16}" cy="198" r="13" fill="${heat(part('kneeL'))}"/><circle cx="${cx + 16}" cy="198" r="13" fill="${heat(part('kneeR'))}"/>`;
      s += `<rect x="${cx - 28}" y="206" width="24" height="36" rx="10" fill="${heat(part('leg') - .06)}"/><rect x="${cx + 4}" y="206" width="24" height="36" rx="10" fill="${heat(part('leg') - .06)}"/>`;
      s += `<rect x="${cx - 32}" y="240" width="28" height="10" rx="5" fill="${heat(part('foot'))}"/><rect x="${cx + 4}" y="240" width="28" height="10" rx="5" fill="${heat(part('foot'))}"/>`;
      if (st === 'k') s += `<circle cx="${cx - 16}" cy="198" r="22" fill="none" stroke="#fff" stroke-dasharray="3 3"/><text x="${cx - 44}" y="232" style="font-size:11px;fill:#fff">প্রদাহ</text>`;
      for (let i = 0; i < 8; i++) s += `<rect x="300" y="${30 + i * 24}" width="18" height="24" fill="${heat(1 - i / 8 - .01)}"/>`;
      s += `<text x="324" y="44" style="font-size:11px;fill:#fff">উষ্ণ</text><text x="324" y="222" style="font-size:11px;fill:#fff">শীতল</text><text x="300" y="250" style="font-size:10px;fill:#aab">থার্মাল রং স্কেল</text>`;
      box.innerHTML = X.svg(400, 260, s, 'থার্মাল ইমেজ');
      const K = T + 273.15, lm = 2.898e-3 / K;
      out.innerHTML = `T = ${T.toFixed(1)}°C = ${K.toFixed(2)} K → λ<sub>max</sub> = 2.898×10⁻³ / ${K.toFixed(2)} = <b>${(lm * 1e6).toFixed(2)} μm</b> (দূর-অবলোহিত) · একক ফোটনের শক্তি ≈ <b>${(h * c / lm / eV * 1000).toFixed(0)} meV</b><br><span class="small">${st === 'f' ? 'জ্বরে পুরো দেহ, বিশেষত কপাল ও বুক বেশি উষ্ণ দেখায় — বিমানবন্দরে থার্মাল স্ক্যানারে জ্বর শনাক্ত করা হয়।' : st === 'k' ? 'প্রদাহস্থলে রক্তপ্রবাহ বেড়ে তাপমাত্রা বাড়ে — থার্মোগ্রাফিতে আশপাশের চেয়ে উজ্জ্বল দেখায়।' : 'সুস্থ দেহে মাথা ও বুক উষ্ণতম; হাত-পায়ের প্রান্ত তুলনামূলক শীতল।'}</span>`;
    };
    X.onSeg(el, 'st', k => { st = k; if (k === 'f' && T < 38.5) { T = 39; el.querySelector('[data-t]').value = 39; } if (k === 'n') { T = 37; el.querySelector('[data-t]').value = 37; } draw(); });
    el.querySelector('[data-t]').addEventListener('input', e => { T = +e.target.value; draw(); }); draw();
  }
};

/* ---------- MRI ---------- */
V.mriSim = {
  t: 'MRI-এর মূলনীতি: প্রোটনের স্পিন, অনুনাদ ও শিথিলায়ন', k: ['anim', 'int'],
  cap: '১) সাধারণ অবস্থায় দেহের হাইড্রোজেন নিউক্লিয়াস (প্রোটন) এলোমেলো দিকে থাকে। ২) শক্তিশালী চৌম্বকক্ষেত্র B₀ এ এরা ক্ষেত্রের দিকে (সামান্য বেশি সংখ্যক) সারিবদ্ধ হয়ে লারমর কম্পাঙ্কে ঘোরে (প্রিসেশন)। ৩) ঠিক ঐ কম্পাঙ্কের রেডিও তরঙ্গ পালস দিলে অনুনাদে এরা কাত হয়ে যায়। ৪) পালস বন্ধ করলে এরা আগের অবস্থায় ফেরে এবং রেডিও সংকেত বিকিরণ করে — কম্পিউটার সেই সংকেত থেকে ছবি তৈরি করে।',
  html: () => X.cv('MRI সিমুলেশন') + `<div class="ctl">${X.seg('step', [[0, '১. ক্ষেত্র নেই'], [1, '২. B₀ চালু'], [2, '৩. RF পালস'], [3, '৪. শিথিলায়ন']], 0)}</div><div class="ctl"><label style="flex:none">B₀ (টেসলা)</label><input type="range" min="0.5" max="3" step="0.1" value="1.5" data-b style="flex:1;min-width:120px"><button class="btn sm" data-auto>${X.ico('play')}পুরো প্রক্রিয়া চালাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const cv = el.querySelector('canvas'); const hf = W => W >= 560 ? 280 : Math.round(W * 0.6 + 160); let L = X.fit(cv, hf);
    const N = 24, rnd = X.rng(9); const P = Array.from({ length: N }, (_, i) => ({ a: rnd() * 6.283, up: i % 7 !== 3, ph: rnd() * 6.283, tilt: 0 }));
    let step = 0, t = 0, B = 1.5, sig = [], auto = null;
    const out = el.querySelector('[data-out]');
    const info = () => { const f = 42.58 * B; out.innerHTML = `¹H এর লারমর কম্পাঙ্ক f = γB₀ = 42.58 MHz T⁻¹ × ${B.toFixed(1)} T = <b>${f.toFixed(1)} MHz</b> — এটি বেতার তরঙ্গ অঞ্চলে। ${['এলোমেলো স্পিন — কোনো নিট চুম্বকত্ব নেই।', 'বেশিরভাগ স্পিন ক্ষেত্রের সমান্তরালে (নিম্ন শক্তি), কিছু বিপরীতে (উচ্চ শক্তি); নিট চুম্বকত্ব B₀ এর দিকে।', 'অনুনাদ: প্রোটন RF শক্তি শোষণ করে উচ্চ শক্তিস্তরে যায়, স্পিন কাত হয়ে একই দশায় ঘোরে।', 'শিথিলায়ন (T1, T2): শোষিত শক্তি রেডিও সংকেত হিসেবে ফেরত আসে। বিভিন্ন টিস্যুর (চর্বি, পানি, টিউমার) শিথিলায়ন সময় ভিন্ন — ফলে ছবিতে কনট্রাস্ট।'][step]}`; };
    X.onSeg(el, 'step', k => { step = +k; t = 0; if (step < 3) sig = []; info(); A.pause(false); X.pp(el, A); });
    el.querySelector('[data-b]').addEventListener('input', e => { B = +e.target.value; info(); });
    el.querySelector('[data-auto]').onclick = () => { clearTimeout(auto); let k = 0; const nx = () => { const b = el.querySelectorAll('[data-seg="step"] button')[k]; b && b.click(); k++; if (k < 4) auto = setTimeout(nx, 2600); }; nx(); };
    info();
    const A = X.anim(cv, dt => {
      t += dt; const C = X.C(), g = L.g, W = L.W, H = L.H; g.clearRect(0, 0, W, H);
      const side = W >= 560, gw = side ? W * 0.58 : W, gh = side ? H : H - 130;
      const cols = 6, rows = 4, cw = gw / cols, ch = gh / rows, rr = Math.min(cw, ch) * 0.34;
      if (step >= 1) { g.fillStyle = C.mu; g.font = `12px ${C.font}`; g.fillText('B₀ ↑', 8, 16); }
      const f = 2 + B;
      P.forEach((p, i) => {
        const cx = (i % cols + .5) * cw, cy = Math.floor(i / cols) * ch + ch / 2 + 6;
        let ang;
        if (step === 0) ang = p.a + Math.sin(t * .7 + p.ph) * .2;
        else { const tgt = step === 2 ? Math.PI / 2 : (p.up ? 0 : Math.PI); if (step === 2) p.tilt = Math.min(1, p.tilt + dt * 1.6); else if (step === 3) p.tilt = Math.max(0, p.tilt - dt * 0.45); else p.tilt = 0; const base = p.up ? 0 : Math.PI; ang = base + (Math.PI / 2 - base) * p.tilt + (step >= 1 ? Math.sin(t * f + (step >= 2 ? 0 : p.ph)) * (0.25 + 0.5 * p.tilt) : 0); }
        const ex = cx + Math.sin(ang) * rr, ey = cy - Math.cos(ang) * rr, sx = cx - Math.sin(ang) * rr * .5, sy = cy + Math.cos(ang) * rr * .5;
        g.fillStyle = C.s2; g.beginPath(); g.arc(cx, cy, rr * .55, 0, 6.283); g.fill();
        g.strokeStyle = p.up || step === 0 ? C.acc : C.a2; g.fillStyle = g.strokeStyle; g.lineWidth = 2.2; g.beginPath(); g.moveTo(sx, sy); g.lineTo(ex, ey); g.stroke();
        const ha = Math.atan2(ey - sy, ex - sx); g.beginPath(); g.moveTo(ex, ey); g.lineTo(ex - 7 * Math.cos(ha - .45), ey - 7 * Math.sin(ha - .45)); g.lineTo(ex - 7 * Math.cos(ha + .45), ey - 7 * Math.sin(ha + .45)); g.closePath(); g.fill();
      });
      if (step === 2) { g.strokeStyle = C.ok; g.lineWidth = 1.6; g.beginPath(); for (let x = 0; x <= gw; x += 3) { const y = 10 + Math.sin(x * .25 - t * 12) * 5; x ? g.lineTo(x, y + gh - 18) : g.moveTo(x, y + gh - 18); } g.stroke(); g.fillStyle = C.ok; g.fillText('RF পালস (রেডিও তরঙ্গ)', 8, gh - 26); }
      // signal panel
      const px = side ? gw + 16 : 10, py = side ? 20 : gh + 14, pw = side ? W - gw - 26 : W - 20, ph = side ? H - 50 : 100;
      g.strokeStyle = C.ln; g.lineWidth = 1; g.strokeRect(px, py, pw, ph); g.fillStyle = C.mu; g.fillText('গ্রাহক কয়েলে সংকেত', px + 6, py + 16);
      if (step === 3 && dt) { sig.push(t); if (sig.length > 400) sig.shift(); }
      if (sig.length) { g.strokeStyle = C.acc; g.lineWidth = 1.6; g.beginPath(); const t0 = sig[0]; sig.forEach((tt, k) => { const x = px + 6 + (tt - t0) / 3.2 * (pw - 12); const y = py + ph / 2 + 10 - Math.sin((tt - t0) * f * 6) * Math.exp(-(tt - t0) * 0.9) * (ph * .35); k ? g.lineTo(Math.min(px + pw - 4, x), y) : g.moveTo(x, y); }); g.stroke(); }
      if (step === 3 && t > 3.5 && !A.paused) { A.pause(true); X.pp(el, A); }
    });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(cv, hf); A.draw(); });
    return () => { A.stop(); ro(); clearTimeout(auto); };
  }
};
V.mriMachine = {
  t: 'MRI যন্ত্রের প্রধান অংশ (প্রস্থচ্ছেদ)', k: ['2d'],
  cap: 'অতিপরিবাহী চুম্বক (তরল হিলিয়ামে শীতল) শক্তিশালী স্থির ক্ষেত্র B₀ (১.৫–৩ T) তৈরি করে; গ্রেডিয়েন্ট কয়েল ক্ষেত্রকে অবস্থানভেদে সামান্য বদলায়, ফলে প্রতিটি অংশের সংকেত আলাদা চেনা যায়; RF কয়েল রেডিও পালস পাঠায় ও ফেরত সংকেত গ্রহণ করে; কম্পিউটার ফুরিয়ার রূপান্তরে ছবি তৈরি করে।',
  html() {
    return X.svg(400, 230, `<defs>${X.arrow('mmA')}</defs>
      <circle cx="140" cy="112" r="96" fill="#2f5d9e" opacity=".85"/><circle cx="140" cy="112" r="78" fill="#e08a2e" opacity=".9"/><circle cx="140" cy="112" r="64" fill="#3aa56b" opacity=".9"/><circle cx="140" cy="112" r="52" class="f-bg"/>
      <rect x="62" y="122" width="156" height="12" rx="3" class="f-mu"/><ellipse cx="140" cy="108" rx="40" ry="13" fill="#f2c9a0"/><circle cx="102" cy="104" r="11" fill="#f2c9a0"/>
      <line x1="240" y1="22" x2="210" y2="44" class="s-fg"/><text x="244" y="22" style="font-size:12px">অতিপরিবাহী চুম্বক (B₀)</text>
      <line x1="240" y1="52" x2="210" y2="70" class="s-fg"/><text x="244" y="54" style="font-size:12px">গ্রেডিয়েন্ট কয়েল</text>
      <line x1="240" y1="82" x2="200" y2="92" class="s-fg"/><text x="244" y="86" style="font-size:12px">RF কয়েল (প্রেরক/গ্রাহক)</text>
      <line x1="240" y1="128" x2="216" y2="128" class="s-fg"/><text x="244" y="132" style="font-size:12px">রোগীর বিছানা</text>
      <rect x="300" y="160" width="90" height="56" rx="6" class="f-s3 s-ln"/><ellipse cx="345" cy="186" rx="22" ry="17" fill="#8fa6c2"/><path d="M335 182 q10 -8 20 0 M333 192 q12 6 24 0" stroke="#3b4f68" fill="none"/><text x="345" y="226" text-anchor="middle" class="tm">কম্পিউটার → ছবি</text>
      <path d="M236 150 Q270 170 296 182" fill="none" class="s-fg" stroke-dasharray="4 3" marker-end="url(#mmA)"/>
      <line x1="140" y1="218" x2="140" y2="12" class="s-acc" stroke-width="1.5" stroke-dasharray="5 4" marker-end="url(#mmA)"/><text x="148" y="16" style="font-size:11px;fill:var(--accent)">B₀</text>`, 'MRI যন্ত্র');
  }
};

/* ---------- Flame test ---------- */
const FL = [
  ['none', 'লবণ ছাড়া', '#5b84ff', 'অনুজ্জ্বল বুনসেন শিখা (হালকা নীল)', '—', ''],
  ['Li', 'Li⁺', '#e8173a', 'টকটকে লাল (crimson)', '৬৭০.৮ nm', 'Li'],
  ['Na', 'Na⁺', '#ffb000', 'সোনালি হলুদ (দীর্ঘস্থায়ী, তীব্র)', '৫৮৯.০ ও ৫৮৯.৬ nm (D রেখা)', 'Na'],
  ['K', 'K⁺', '#c58be8', 'হালকা বেগুনি / লাইলাক', '৭৬৬.৫, ৭৬৯.৯ ও ৪০৪.৪ nm', 'K'],
  ['Ca', 'Ca²⁺', '#ff5a1f', 'ইটের মতো লাল (brick red)', 'মূলত CaOH-এর ব্যান্ড (~৬২২ nm ও ~৫৫৪ nm)', ''],
  ['Sr', 'Sr²⁺', '#ff1f45', 'টকটকে লাল (crimson red)', 'SrOH/SrCl-এর লাল ব্যান্ড (~৬০৬–৬৮২ nm)', ''],
  ['Ba', 'Ba²⁺', '#a2e03b', 'আপেল সবুজ / হলদে-সবুজ', 'BaCl/BaOH-এর সবুজ ব্যান্ড (~৫১৩–৫২৪ nm)', ''],
  ['Cu', 'Cu²⁺', '#20c9a6', 'নীলাভ সবুজ', 'CuCl-এর নীল-সবুজ ব্যান্ড', '']
];
V.flameTest = {
  t: 'শিখা পরীক্ষা: ধাতব আয়নের বৈশিষ্ট্যপূর্ণ রং', k: ['anim', 'int'],
  cap: 'একটি আয়ন বেছে নাও — প্লাটিনাম তারে লবণ শিখায় ধরলে যে রং দেখা যায় তা ফুটে উঠবে। "নীল কোবাল্ট কাচ" চালু করলে সোডিয়ামের হলুদ আলো শোষিত হয় — K⁺ এর বেগুনি রং Na⁺ এর ভেজাল থাকলেও দেখা যায়। স্ক্রিনের রং আনুমানিক।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('ion', FL.map(f => [f[0], f[1]]), 'Na')}</div><div data-svg></div><div class="ctl"><label class="row" style="gap:6px"><input type="checkbox" data-co> নীল কোবাল্ট কাচের মধ্য দিয়ে দেখো</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    let ion = 'Na', co = false; const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = () => {
      const f = FL.find(x => x[0] === ion); let col = f[2], seen = f[3];
      if (co) { if (ion === 'Na') { col = '#4a66d8'; seen = 'প্রায় কোনো রং দেখা যায় না — হলুদ আলো কোবাল্ট কাচে শোষিত'; } else if (ion === 'K') { col = '#d4307a'; seen = 'টকটকে লাল-বেগুনি (crimson) দেখায়'; } else if (ion !== 'none') { seen += ' (কাচে কিছুটা ম্লান/রং বদলায়)'; col = col; } }
      const tint = co ? `<rect x="0" y="0" width="400" height="250" fill="#1d3fb8" opacity=".18"/>` : '';
      const lines = f[5] && LINES[f[5]] ? `<g transform="translate(0,214)">${strip(LINES[f[5]].l, 0, 18, 'ft')}</g><text x="10" y="248" class="tm">${LINES[f[5]].n} — নির্গমন রেখা</text>` : `<text x="10" y="232" class="tm">এই আয়নের রং মূলত অণু/মূলকের ব্যান্ড বর্ণালি থেকে আসে।</text>`;
      box.innerHTML = X.svg(400, 252, `<defs><radialGradient id="flG" cx="50%" cy="75%" r="65%"><stop offset="0" stop-color="#ffffff" stop-opacity=".9"/><stop offset=".35" stop-color="${col}"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></radialGradient><linearGradient id="flCone" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#3d5bff"/><stop offset="1" stop-color="#9fb4ff" stop-opacity=".2"/></linearGradient></defs>
        <rect x="0" y="0" width="400" height="210" rx="10" fill="#0c0b14"/>
        <g class="anim-flame"><path d="M200 196 C150 170 156 110 182 70 C190 92 196 60 200 22 C206 62 214 90 220 70 C246 110 252 170 200 196Z" fill="url(#flG)"/></g>
        <path d="M200 196 C186 186 186 160 200 128 C214 160 214 186 200 196Z" fill="url(#flCone)" opacity=".85"/>
        <rect x="186" y="196" width="28" height="14" fill="#6f7782"/>
        ${ion !== 'none' ? `<line x1="330" y1="60" x2="226" y2="150" stroke="#cfd3d8" stroke-width="2"/><circle cx="222" cy="153" r="5" fill="none" stroke="#cfd3d8" stroke-width="2"/><text x="300" y="52" style="font-size:11px;fill:#cfd3d8">প্লাটিনাম/নাইক্রোম তার</text>` : ''}
        ${tint}${lines}`, 'শিখা পরীক্ষা');
      out.innerHTML = `<b>${f[1]}</b> → <b>${seen}</b><br><span class="small">নির্গত বিকিরণ: ${f[4]}</span>`;
    };
    X.onSeg(el, 'ion', k => { ion = k; draw(); }); el.querySelector('[data-co]').addEventListener('change', e => { co = e.target.checked; draw(); }); draw();
  }
};
V.flameProc = {
  t: 'শিখা পরীক্ষার কার্যপ্রণালি ও বুনসেন শিখার অঞ্চল', k: ['2d'],
  cap: 'শিখা পরীক্ষায় সবসময় অনুজ্জ্বল (বায়ুছিদ্র খোলা) শিখা ব্যবহার করা হয়, কারণ উজ্জ্বল হলুদ শিখার নিজস্ব রং আয়নের রং ঢেকে দেয়। নমুনা ধরা হয় শিখার বাইরের দিকের উত্তপ্ত জারণ অঞ্চলে।',
  html() {
    const step = (x, n, t) => `<g transform="translate(${x},0)"><circle cx="0" cy="18" r="11" class="f-accs s-acc"/><text x="0" y="22" text-anchor="middle" style="font-size:12px;font-weight:700;fill:var(--accent)">${n}</text><text x="0" y="44" text-anchor="middle" style="font-size:11px">${t[0]}</text><text x="0" y="58" text-anchor="middle" style="font-size:11px">${t[1]}</text></g>`;
    return X.svg(400, 260, `${step(50, '১', ['তার গাঢ় HCl এ', 'ডুবিয়ে পরিষ্কার'])}${step(150, '২', ['শিখায় ধরে রংহীন', 'না হওয়া পর্যন্ত'])}${step(250, '৩', ['লবণ + গাঢ় HCl', 'এর পেস্টে ডোবাও'])}${step(350, '৪', ['শিখার জারণ', 'অঞ্চলে ধরো'])}
      <line x1="62" y1="18" x2="138" y2="18" class="s-ln"/><line x1="162" y1="18" x2="238" y2="18" class="s-ln"/><line x1="262" y1="18" x2="338" y2="18" class="s-ln"/>
      <path d="M200 236 C170 214 172 150 200 90 C228 150 230 214 200 236Z" fill="#7aa0ff" opacity=".35"/><path d="M200 236 C188 226 188 196 200 168 C212 196 212 226 200 236Z" fill="#3d5bff" opacity=".7"/>
      <rect x="190" y="236" width="20" height="20" fill="#6f7782"/><circle cx="200" cy="250" r="3" class="f-bg"/>
      <line x1="226" y1="128" x2="290" y2="110" class="s-fg"/><text x="294" y="106" style="font-size:12px">জারণ অঞ্চল</text><text x="294" y="121" class="tm">(বাইরের, সবচেয়ে উত্তপ্ত)</text>
      <line x1="206" y1="200" x2="290" y2="180" class="s-fg"/><text x="294" y="180" style="font-size:12px">বিজারণ অঞ্চল</text><text x="294" y="195" class="tm">(ভেতরের নীল শঙ্কু)</text>
      <line x1="190" y1="226" x2="110" y2="214" class="s-fg"/><text x="20" y="206" style="font-size:12px">অদগ্ধ গ্যাস</text><text x="20" y="221" class="tm">(সবচেয়ে শীতল)</text>
      <text x="20" y="140" style="font-size:12px">অনুজ্জ্বল শিখা</text><text x="20" y="155" class="tm">বায়ুছিদ্র খোলা</text>
      <line x1="210" y1="250" x2="260" y2="250" class="s-fg"/><text x="264" y="254" class="tm">বায়ুছিদ্র</text>`, 'শিখা পরীক্ষার ধাপ');
  }
};
})();

