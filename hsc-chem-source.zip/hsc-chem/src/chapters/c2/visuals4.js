/* Visuals part 4 — lab methods, crystallisation, NaCl (2.14–2.15) and distillation rig + simple/fractional (2.16) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;
const f1 = v => (+v).toFixed(1);
const fld = (lab, attr, val) => `<label class="stack" style="gap:4px"><span class="small muted">${lab}</span><input class="inp mono" ${attr} value="${val}" inputmode="decimal"></label>`;
X.fld = fld;
const flame = (x, by, h) => `<path class="anim-flame" d="M${x} ${by - h} C${x + 7} ${by - h * 0.45} ${x + 7} ${by} ${x} ${by} C${x - 7} ${by} ${x - 7} ${by - h * 0.45} ${x} ${by - h}Z" fill="#4f8df5" opacity=".9"/><path class="anim-flame" d="M${x} ${by - h * 0.6} C${x + 3.5} ${by - h * 0.3} ${x + 3.5} ${by} ${x} ${by} C${x - 3.5} ${by} ${x - 3.5} ${by - h * 0.3} ${x} ${by - h * 0.6}Z" fill="#cfe6ff"/>`;
X.flame = flame;
const tripod = (cx, by, run, w = 30) => `<line x1="${cx - w}" y1="${by + 3}" x2="${cx + w}" y2="${by + 3}" class="s-mu" stroke-width="2.5"/><path d="M${cx - w + 6} ${by + 3} L${cx - w} ${by + 40} M${cx + w - 6} ${by + 3} L${cx + w} ${by + 40}" class="s-mu" stroke-width="2" fill="none"/><rect x="${cx - 6}" y="${by + 26}" width="12" height="14" rx="1.5" class="f-s3 s-ln"/>${run ? flame(cx, by + 26, 18) : ''}`;
X.tripod = tripod;

/* ---------- shared distillation rig ---------- */
const U = [0.954, 0.3], N = [-0.3, 0.954];
const PT = (p, t, o) => [p[0] + U[0] * t + N[0] * o, p[1] + U[1] * t + N[1] * o];
const rig = o => {
  const id = o.id, cx = o.cx || 80, r = o.r || 34, cy = o.cy || 186, sy = o.sy || 104, L = o.L || 220, nk = o.col ? 9 : 7;
  const run = !!o.run, by = cy + r;
  const Q1 = [cx + nk, sy], Q2 = PT(Q1, L, 0);
  const rx = Q2[0] + 6, rTop = Q2[1] + 18, rNeckB = rTop + 12, rBase = rTop + 58, hmax = (rBase - rNeckB) * 0.95;
  const recvPath = `M${f1(rx - 7)} ${f1(rTop)} L${f1(rx - 7)} ${f1(rNeckB)} L${f1(rx - 28)} ${f1(rBase)} L${f1(rx + 28)} ${f1(rBase)} L${f1(rx + 7)} ${f1(rNeckB)} L${f1(rx + 7)} ${f1(rTop)}`;
  let s = `<defs><clipPath id="${id}c"><circle cx="${cx}" cy="${cy}" r="${r - 1.6}"/></clipPath><clipPath id="${id}r"><path d="${recvPath}Z"/></clipPath></defs>`;
  if (o.heat !== 'none') s += tripod(cx, by, o.flame != null ? o.flame : run);
  const yj = cy - Math.sqrt(r * r - nk * nk), neckTop = sy - 12;
  const fill = o.fill == null ? 0.45 : o.fill, lvl = by - 2 * r * fill;
  s += `<rect data-fl x="${cx - r}" y="${f1(lvl)}" width="${2 * r}" height="${f1(by - lvl + 2)}" fill="${o.liq || '#9cc9ef'}" opacity=".75" clip-path="url(#${id}c)"/>`;
  if (o.residue) { const rnd = X.rng(4); for (let i = 0; i < 16; i++) s += `<rect x="${f1(cx - r * 0.5 + rnd() * r)}" y="${f1(by - 5 - rnd() * 4)}" width="3" height="3" fill="${o.residue}" clip-path="url(#${id}c)"/>`; }
  s += `<path d="M${cx - nk} ${neckTop} L${cx - nk} ${f1(yj)} A${r} ${r} 0 1 0 ${cx + nk} ${f1(yj)} L${cx + nk} ${neckTop}" fill="none" class="s-fg" stroke-width="2"/>`;
  if (o.col) { let i = 0; for (let y = sy + 16; y < yj - 4; y += 7, i++) for (let k = 0; k < 2; k++) s += `<circle cx="${cx - 4 + k * 8 + (i % 2 ? 1 : -1)}" cy="${y}" r="2.8" class="f-s3 s-ln"/>`; }
  if (o.extra) s += o.extra;
  if (run) {
    const rnd = X.rng(5);
    for (let i = 0; i < 7; i++) s += `<circle class="anim-bub" cx="${f1(cx - r * 0.55 + rnd() * r * 1.1)}" cy="${f1(by - 5 - rnd() * 6)}" r="${f1(1.6 + rnd() * 1.6)}" fill="#fff" stroke="#7fa7c9" stroke-width=".6" style="animation-delay:${(rnd() * 1.6).toFixed(2)}s"/>`;
    for (let i = 0; i < 4; i++) s += `<circle class="anim-vap" cx="${f1(cx - 3 + rnd() * 6)}" cy="${f1(yj + 4)}" r="2.2" fill="${o.vap || '#b8c4cf'}" opacity=".85" style="animation-delay:${(i * 0.55).toFixed(2)}s"/>`;
  }
  s += `<rect x="${cx - nk - 2}" y="${neckTop - 7}" width="${2 * nk + 4}" height="8" rx="2" class="f-mu"/>`;
  if (o.thermo !== false) {
    s += `<line x1="${cx}" y1="${sy - 46}" x2="${cx}" y2="${sy + 1}" class="s-fg" stroke-width="2.4"/><circle cx="${cx}" cy="${sy + 3}" r="3.4" fill="#c0392b"/>`;
    s += `<rect x="${cx + 12}" y="${sy - 58}" width="62" height="20" rx="5" class="f-sf s-acc"/><text data-t x="${cx + 43}" y="${sy - 44}" text-anchor="middle" class="mono" style="font-size:12px;font-weight:600">${o.T || '25°C'}</text><line x1="${cx + 12}" y1="${sy - 46}" x2="${cx + 3}" y2="${sy - 40}" class="s-mu"/>`;
  }
  const a = L * 0.13, b = L * 0.86;
  const j1 = PT(Q1, a, -11), j2 = PT(Q1, b, -11), j3 = PT(Q1, b, 11), j4 = PT(Q1, a, 11);
  s += `<path d="M${f1(j1[0])} ${f1(j1[1])} L${f1(j2[0])} ${f1(j2[1])} L${f1(j3[0])} ${f1(j3[1])} L${f1(j4[0])} ${f1(j4[1])}Z" fill="rgba(70,150,230,.16)" class="s-ln" stroke-width="1.6"/>`;
  [-6, 6].forEach(off => { const w1 = PT(Q1, b - 4, off), w2 = PT(Q1, a + 4, off); s += `<line x1="${f1(w1[0])}" y1="${f1(w1[1])}" x2="${f1(w2[0])}" y2="${f1(w2[1])}" stroke="#3b82f6" stroke-width="1.6" class="anim-flow" opacity=".8"/>`; });
  s += `<line x1="${Q1[0]}" y1="${Q1[1]}" x2="${f1(Q2[0])}" y2="${f1(Q2[1])}" class="s-fg" stroke-width="7" stroke-linecap="round"/><line x1="${Q1[0]}" y1="${Q1[1]}" x2="${f1(Q2[0])}" y2="${f1(Q2[1])}" stroke="var(--surface)" stroke-width="4" stroke-linecap="round"/>`;
  if (run) s += `<line x1="${Q1[0]}" y1="${Q1[1]}" x2="${f1(Q2[0])}" y2="${f1(Q2[1])}" stroke="${o.vap || '#9aa7b4'}" stroke-width="2.4" class="anim-flow"/>`;
  const wi = PT(Q1, b - 10, 11), wo = PT(Q1, a + 10, -11);
  s += `<line x1="${f1(wi[0])}" y1="${f1(wi[1])}" x2="${f1(wi[0])}" y2="${f1(wi[1] + 18)}" stroke="#3b82f6" stroke-width="4"/><line x1="${f1(wo[0])}" y1="${f1(wo[1])}" x2="${f1(wo[0])}" y2="${f1(wo[1] - 16)}" stroke="#3b82f6" stroke-width="4"/>`;
  if (o.lab !== false) s += `<text x="${f1(wi[0] - 5)}" y="${f1(wi[1] + 20)}" text-anchor="end" class="tm" style="font-size:9.5px">পানি প্রবেশ ↑</text><text x="${f1(wo[0] + 5)}" y="${f1(wo[1] - 8)}" class="tm" style="font-size:9.5px">পানি নির্গমন</text>`;
  const hh = hmax * Math.min(1, o.recv || 0), oil = o.oil || 0;
  s += `<path d="M${f1(Q2[0])} ${f1(Q2[1])} L${f1(rx)} ${f1(rTop + 6)}" class="s-fg" stroke-width="5" stroke-linecap="round" fill="none"/>`;
  s += `<rect data-rl x="${f1(rx - 30)}" y="${f1(rBase - hh)}" width="60" height="${f1(hh)}" fill="${o.dist || '#bfe3ff'}" clip-path="url(#${id}r)"/>`;
  if (o.layers) s += `<rect data-rl2 x="${f1(rx - 30)}" y="${f1(rBase - hh * oil)}" width="60" height="${f1(hh * oil)}" fill="${o.oilC || '#d9a441'}" opacity=".9" clip-path="url(#${id}r)"/>`;
  s += `<path d="${recvPath}" fill="none" class="s-fg" stroke-width="2"/>`;
  if (run && o.drip !== false) s += `<circle class="anim-drip" cx="${f1(rx)}" cy="${f1(rTop + 8)}" r="2.6" fill="${o.dripC || '#5aa9e6'}"/>`;
  if (o.lab) {
    const mid = PT(Q1, L * 0.5, -22);
    if (o.thLab !== false) s += `<text x="${cx - 12}" y="${sy - 30}" text-anchor="end" class="tm" style="font-size:10px">থার্মোমিটার</text>`;
    s += `<text x="${f1(mid[0])}" y="${f1(mid[1])}" text-anchor="middle" class="tm" style="font-size:10px" transform="rotate(17.4 ${f1(mid[0])} ${f1(mid[1])})">লিবিগ শীতক</text>`;
    s += `<text x="${f1(rx)}" y="${f1(rBase + 12)}" text-anchor="middle" class="tm" style="font-size:10px">${o.recvLab || 'গ্রাহক পাত্র (পরিস্রুত)'}</text>`;
    s += `<text x="${cx + r + 4}" y="${by + 36}" class="tm" style="font-size:10px">বুনসেন বার্নার</text>`;
    s += `<text x="${cx}" y="${f1(cy - 4)}" text-anchor="middle" style="font-size:9.5px;font-weight:600">${o.flaskLab || 'পাতন ফ্লাস্ক'}</text>`;
    if (o.col) s += `<text x="${cx + nk + 5}" y="${f1((sy + yj) / 2 + 12)}" class="tm" style="font-size:9.5px">আংশিক পাতন স্তম্ভ</text>`;
  }
  return { svg: s, rx, rBase, hmax, by, r, cx, cy, H: Math.max(by + 44, rBase + 18) };
};
X.rig = rig;

/* ======================= 2.14 পরিস্রাবণ ও সেন্ট্রিফিউজ ======================= */
V.filterSim = {
  t: 'অধঃক্ষেপ আলাদা করা: পরিস্রাবণ, শোষণ পরিস্রাবণ ও সেন্ট্রিফিউজ', k: ['anim', 'int'],
  cap: 'তিনটি পদ্ধতির যন্ত্রসজ্জা দেখো। গুণগত বিশ্লেষণে অধঃক্ষেপ (অবশেষ) ও দ্রবণ (পরিস্রুত) আলাদা করা প্রায় প্রতিটি ধাপে লাগে — গ্রুপ বিশ্লেষণে প্রতিটি গ্রুপের অধঃক্ষেপ ছেঁকে পরিস্রুতটি পরের গ্রুপে ব্যবহার করা হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('fm', [['g', 'সাধারণ পরিস্রাবণ'], ['v', 'শোষণ (বুখনার)'], ['c', 'সেন্ট্রিফিউজ']], 'g')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const TX = {
      g: '<b style="font-family:var(--font-body)">সাধারণ (মাধ্যাকর্ষণ) পরিস্রাবণ:</b> ফিল্টার কাগজ দুই ভাঁজ করে শঙ্কু বানিয়ে ফানেলে বসানো হয় এবং পাতিত পানি দিয়ে ভিজিয়ে আটকানো হয়। মিশ্রণ কাচদণ্ড বেয়ে ঢালা হয় — কাগজের কিনারার প্রায় ১ cm নিচ পর্যন্ত। ফানেলের নল গ্রাহক বিকারের ভেতরের গা স্পর্শ করে রাখা হয় — ছিটকানো কমে ও প্রবাহ দ্রুত হয়। কাগজে থাকে <b>অবশেষ</b>, নিচে জমে <b>পরিস্রুত</b>।',
      v: '<b style="font-family:var(--font-body)">শোষণ (বুখনার) পরিস্রাবণ:</b> পাম্প বুখনার ফ্লাস্কের ভেতরের বায়ুচাপ কমায়; বাইরের বায়ুমণ্ডলীয় চাপ তরলকে দ্রুত সমতল ছিদ্রযুক্ত প্লেটের কাগজ ভেদ করে ঠেলে দেয়। কেলাস দ্রুত ছাঁকা, ঠান্ডা দ্রাবকে ধোয়া ও আংশিক শুকানোর জন্য আদর্শ (২.১৪.১, ২.১৫)। পাম্প বন্ধের আগে নল খুলে নিতে হয় — নইলে পানি উল্টো দিকে ফ্লাস্কে ঢুকে যায় (পশ্চাৎ শোষণ)।',
      c: '<b style="font-family:var(--font-body)">সেন্ট্রিফিউগেশন:</b> দ্রুত ঘূর্ণনে কেন্দ্রবিমুখী বল ঘন কণাকে নলের তলায় জমা করে; উপরের স্বচ্ছ তরল ড্রপার দিয়ে টেনে নেওয়া বা ঢেলে আলাদা (ডিক্যান্ট) করা হয়। অল্প পরিমাণ অধঃক্ষেপ (সেমি-মাইক্রো বিশ্লেষণ), সূক্ষ্ম কলয়েডীয় অধঃক্ষেপ ও রক্তের প্লাজমা আলাদা করতে ব্যবহৃত হয়। নলগুলো বিপরীত দিকে সমান ভারে সাজাতে হয় — নইলে যন্ত্র কাঁপে ও ভেঙে যেতে পারে।'
    };
    const draw = m => {
      let s = `<defs>${X.arrow('fsA')}</defs>`;
      if (m === 'g') {
        s += `<rect x="30" y="236" width="130" height="7" rx="2" class="f-s3 s-ln"/><line x1="52" y1="236" x2="52" y2="30" class="s-mu" stroke-width="4"/><line x1="52" y1="72" x2="166" y2="72" class="s-mu" stroke-width="3"/>`;
        s += `<defs><clipPath id="fsP"><path d="M166 64 L234 64 L200 114Z"/></clipPath></defs>`;
        s += `<path d="M160 60 L240 60 L203 120 L203 182 L197 182 L197 120Z" fill="rgba(200,220,235,.25)" class="s-fg" stroke-width="2" stroke-linejoin="round"/>`;
        s += `<path d="M166 64 L234 64 L200 114Z" class="f-sf s-mu"/><rect x="160" y="80" width="80" height="40" fill="#b9a382" opacity=".55" clip-path="url(#fsP)"/>`;
        const rnd = X.rng(8); for (let i = 0; i < 26; i++) { const y = 96 + rnd() * 16, half = (114 - y) * 34 / 50; s += `<circle cx="${f1(200 - half * 0.8 + rnd() * half * 1.6)}" cy="${f1(y)}" r="1.8" fill="#7a5a2f"/>`; }
        s += `<path d="M160 170 L160 240 L240 240 L240 170" fill="none" class="s-fg" stroke-width="2"/><rect x="161.5" y="212" width="77" height="27" fill="#cfe7fb"/><circle class="anim-drip" cx="200" cy="184" r="2.4" fill="#7fbbe8"/>`;
        s += `<path d="M96 12 L138 6 L146 34 L104 42Z" class="f-s2 s-fg"/><path d="M104 34 L142 28 L146 34 L104 42Z" fill="#b9a382" opacity=".8"/><line x1="146" y1="30" x2="190" y2="78" class="s-fg" stroke-width="2.5"/><line x1="148" y1="32" x2="188" y2="76" stroke="#b9a382" stroke-width="2" class="anim-flow"/>`;
        s += `<text x="248" y="86" class="tm" style="font-size:10.5px">← ফিল্টার কাগজে অবশেষ</text><text x="244" y="58" class="tm" style="font-size:10.5px">ফানেল</text><text x="248" y="226" class="tm" style="font-size:10.5px">← পরিস্রুত</text><text x="160" y="22" class="tm" style="font-size:10.5px">কাচদণ্ড বেয়ে ঢালা</text><text x="206" y="160" class="tm" style="font-size:10px">নল বিকারের গায়ে</text>`;
      } else if (m === 'v') {
        s += `<path d="M160 52 L240 52 L240 92 L212 112 L212 132 L188 132 L188 112 L160 92Z" class="f-s2 s-fg" stroke-width="2" stroke-linejoin="round"/><line x1="162" y1="92" x2="238" y2="92" class="s-fg" stroke-width="2"/>`;
        for (let x = 168; x <= 232; x += 8) s += `<circle cx="${x}" cy="92" r="1.4" class="f-bg"/>`;
        s += `<rect x="163" y="84" width="74" height="7" fill="#e9e1d1"/><rect x="163" y="78" width="74" height="7" fill="#9bc3e6" opacity=".7"/>`;
        s += `<rect x="186" y="128" width="28" height="12" rx="3" fill="#7d6b5d"/>`;
        s += `<path d="M190 140 L190 158 L148 236 L252 236 L210 158 L210 140" fill="none" class="s-fg" stroke-width="2"/><path d="M168 200 L232 200 L252 236 L148 236Z" fill="#cfe7fb"/><path d="M190 140 L190 158 L148 236 L252 236 L210 158 L210 140" fill="none" class="s-fg" stroke-width="2"/>`;
        s += `<line x1="210" y1="150" x2="262" y2="150" class="s-fg" stroke-width="5"/><path d="M262 150 C290 150 290 120 318 120" fill="none" stroke="#7d6b5d" stroke-width="7"/><path d="M262 150 C290 150 290 120 318 120" fill="none" stroke="#fff" stroke-width="2" class="anim-flow" opacity=".8"/>`;
        s += `<rect x="318" y="100" width="62" height="40" rx="6" class="f-s3 s-fg"/><text x="349" y="124" text-anchor="middle" style="font-size:11px;font-weight:600">পাম্প</text>`;
        s += `<circle class="anim-drip" cx="200" cy="146" r="2.4" fill="#7fbbe8"/><circle class="anim-drip" cx="200" cy="146" r="2.2" fill="#7fbbe8" style="animation-delay:.5s"/><circle class="anim-drip" cx="200" cy="146" r="2" fill="#7fbbe8" style="animation-delay:.95s"/>`;
        s += `<text x="248" y="74" class="tm" style="font-size:10.5px">বুখনার ফানেল</text><text x="248" y="90" class="tm" style="font-size:10px">(ছিদ্রযুক্ত প্লেটে কাগজ ও কেলাস)</text><text x="92" y="130" text-anchor="end" class="tm" style="font-size:10.5px">রাবার ছিপি</text><line x1="94" y1="127" x2="184" y2="134" class="s-mu" stroke-dasharray="3 3"/><text x="290" y="170" class="tm" style="font-size:10.5px">← বাতাস টেনে নেওয়া হয়</text><text x="120" y="250" class="tm" style="font-size:10.5px">বুখনার ফ্লাস্ক (পুরু কাচ) — নিচে পরিস্রুত</text>`;
      } else {
        let rot = `<circle cx="110" cy="130" r="72" class="f-s2 s-fg" stroke-width="2"/>`;
        [0, 90, 180, 270].forEach(a => { rot += `<g transform="rotate(${a} 110 130)"><rect x="104" y="66" width="12" height="44" rx="6" class="f-sf s-fg"/><rect x="105.5" y="96" width="9" height="12" rx="4" fill="#8a6d3b"/></g>`; });
        rot += `<circle cx="110" cy="130" r="9" class="f-s3 s-fg"/>`;
        s += `<g style="transform-box:fill-box;transform-origin:center;animation:spin .45s linear infinite">${rot}</g><text x="110" y="222" text-anchor="middle" class="tm" style="font-size:10.5px">উপর থেকে দেখা রোটর (ঘূর্ণায়মান)</text>`;
        const tube = (x, sed) => `<path d="M${x - 11} 70 L${x - 11} 190 Q${x - 11} 204 ${x} 204 Q${x + 11} 204 ${x + 11} 190 L${x + 11} 70" fill="none" class="s-fg" stroke-width="2"/>` + (sed ? `<rect x="${x - 9.5}" y="96" width="19" height="84" fill="#dde9f3"/><path d="M${x - 9.5} 180 L${x + 9.5} 180 L${x + 9.5} 190 Q${x + 9.5} 202 ${x} 202 Q${x - 9.5} 202 ${x - 9.5} 190Z" fill="#8a6d3b"/>` : `<path d="M${x - 9.5} 96 L${x + 9.5} 96 L${x + 9.5} 190 Q${x + 9.5} 202 ${x} 202 Q${x - 9.5} 202 ${x - 9.5} 190Z" fill="#c7b391"/>`);
        s += tube(250, false) + tube(340, true) + `<line x1="268" y1="140" x2="320" y2="140" class="s-fg" stroke-width="1.8" marker-end="url(#fsA)"/><text x="250" y="60" text-anchor="middle" class="tm" style="font-size:10.5px">আগে</text><text x="340" y="60" text-anchor="middle" class="tm" style="font-size:10.5px">পরে</text><text x="372" y="140" class="tm" style="font-size:10px" text-anchor="end"></text><text x="296" y="230" text-anchor="middle" class="tm" style="font-size:10px">উপরে স্বচ্ছ তরল · তলায় অধঃক্ষেপ</text>`;
      }
      box.innerHTML = X.svg(400, 254, s, 'পরিস্রাবণ যন্ত্রসজ্জা');
      out.innerHTML = TX[m];
    };
    X.onSeg(el, 'fm', draw); draw('g');
  }
};

/* ======================= 2.14 কোন পদ্ধতি? (পৃথকীকরণ নির্বাচক) ======================= */
const METH = { f: ['পরিস্রাবণ', '২.১৪'], cr: ['কেলাসায়ন', '২.১৪.১'], fc: ['আংশিক কেলাসায়ন', '২.১৫.১'], sd: ['সাধারণ পাতন', '২.১৬'], fd: ['আংশিক পাতন', '২.১৬'], az: ['সমস্ফুটন পাতন', '২.১৬'], st: ['বাষ্প পাতন', '২.১৬'], vd: ['নিম্নচাপ পাতন', '২.১৬'], sb: ['ঊর্ধ্বপাতন', '২.১৬'], ex: ['দ্রাবক নিষ্কাশন', '২.১৭'], sf: ['পৃথকীকরণ ফানেল', '২.১৭'], cc: ['কলাম ক্রোমাটোগ্রাফি', '২.১৮.১'], pc: ['পেপার ক্রোমাটোগ্রাফি', '২.১৮.২'], cf: ['সেন্ট্রিফিউগেশন', '২.১৪'] };
const SEPQ = [
  ['বালি মেশানো পানি থেকে বালি আলাদা করা', 'f', 'বালি পানিতে অদ্রবণীয় কঠিন — ফিল্টার কাগজে আটকে যায়, পানি বেরিয়ে যায়।'],
  ['সমুদ্রের লবণাক্ত পানি থেকে খাবার পানি', 'sd', 'পানি উদ্বায়ী, লবণ অনুদ্বায়ী — স্ফুটনাঙ্কের পার্থক্য অনেক বড়।'],
  ['ইথানল (৭৮°C) ও পানির (১০০°C) মিশ্রণ থেকে ইথানল', 'fd', 'স্ফুটনাঙ্কের পার্থক্য কম (২২°C) — স্তম্ভে বারবার বাষ্পীভবন-ঘনীভবনে ঘন হয় (সর্বোচ্চ ৯৫.৬%)।'],
  ['৯৫.৬% ইথানল থেকে পরম (১০০%) অ্যালকোহল', 'az', 'এটি সমস্ফুটন মিশ্রণ — সাধারণ বা আংশিক পাতনে আর ঘন হয় না; বেনজিনের মতো তৃতীয় উপাদান যোগ করে নতুন সমস্ফুটন মিশ্রণ বানিয়ে পানি সরানো হয়।'],
  ['অশুদ্ধ অ্যানিলিন বিশুদ্ধকরণ (স্ফুটনাঙ্ক ১৮৪°C, পানিতে অমিশ্রণীয়)', 'st', 'উচ্চ স্ফুটনাঙ্কে বিয়োজনের ঝুঁকি; পানিতে অমিশ্রণীয় ও বাষ্পে উদ্বায়ী — পানির সাথে ১০০°C এর নিচে (৯৮.৪°C) পাতিত হয়।'],
  ['গ্লিসারিন বিশুদ্ধকরণ (স্ফুটনাঙ্ক ২৯০°C, বিয়োজিত হয়)', 'vd', 'চাপ কমালে স্ফুটনাঙ্ক কমে — বিয়োজন ছাড়াই কম তাপমাত্রায় পাতন।'],
  ['খাদ্য লবণ (NaCl) ও নিশাদল (NH₄Cl) এর মিশ্রণ', 'sb', 'উত্তাপে NH₄Cl সরাসরি বাষ্প হয়ে ঠান্ডা অংশে আবার কঠিন হয়; NaCl থেকে যায়।'],
  ['আয়োডিনের জলীয় দ্রবণ থেকে আয়োডিন', 'ex', 'আয়োডিন CCl₄ এ পানির চেয়ে প্রায় ৮৫ গুণ বেশি দ্রবণীয়, আর CCl₄ পানিতে অমিশ্রণীয় — বণ্টন সূত্র।'],
  ['কালো কালিতে কয়টি রঞ্জক আছে তা শনাক্ত করা', 'pc', 'অল্প নমুনা যথেষ্ট; রঞ্জকগুলো ভিন্ন গতিতে চলে, Rf মান দিয়ে শনাক্ত করা যায়।'],
  ['পাতার নির্যাস থেকে ক্লোরোফিল ও ক্যারোটিন আলাদা করে সংগ্রহ', 'cc', 'বেশি পরিমাণে পৃথক করে সংগ্রহ করতে হবে — অধিশোষণের পার্থক্যে স্তম্ভে আলাদা ব্যান্ড তৈরি হয়।'],
  ['KNO₃ এর সাথে অল্প NaCl মিশে আছে', 'fc', 'তাপমাত্রা বাড়লে KNO₃ এর দ্রাব্যতা দ্রুত বাড়ে, NaCl এর প্রায় বাড়ে না — ঠান্ডা করলে শুধু KNO₃ কেলাস পড়ে।'],
  ['কেরোসিন ও পানির মিশ্রণ', 'sf', 'দুটি অমিশ্রণীয় তরল — ঘনত্বের পার্থক্যে দুটি স্তর তৈরি হয়; নিচের স্তর স্টপকক দিয়ে বের করা হয়।'],
  ['অপরিশোধিত পেট্রোলিয়াম থেকে পেট্রোল, কেরোসিন, ডিজেল', 'fd', 'অসংখ্য হাইড্রোকার্বন — নির্দিষ্ট স্ফুটনাঙ্ক পরিসরের অংশ হিসেবে স্তম্ভের বিভিন্ন উচ্চতায় আলাদা হয়।'],
  ['অশুদ্ধ বেনজোয়িক এসিড বিশুদ্ধকরণ', 'cr', 'গরম পানিতে বেশি, ঠান্ডা পানিতে খুব কম দ্রবণীয় — গরম দ্রবণ ঠান্ডা করলে বিশুদ্ধ কেলাস পড়ে, অশুদ্ধি মাতৃদ্রবে থাকে।'],
  ['রক্ত থেকে রক্তকণিকা ও প্লাজমা আলাদা করা', 'cf', 'কণাগুলো সূক্ষ্ম ও নরম — দ্রুত ঘূর্ণনে তলায় জমা হয়।'],
  ['গুণগত বিশ্লেষণে AgCl এর অধঃক্ষেপ দ্রবণ থেকে আলাদা করা', 'f', 'অদ্রবণীয় অধঃক্ষেপ — পরিস্রাবণ (অল্প পরিমাণ হলে সেন্ট্রিফিউজও চলে)।']
];
V.sepChooser = {
  t: 'কোন মিশ্রণে কোন পৃথকীকরণ পদ্ধতি? (অনুশীলন)', k: ['int', 'info'],
  cap: 'প্রতিটি মিশ্রণের জন্য সঠিক পদ্ধতি বেছে নাও। মূলনীতি: উপাদানগুলোর যে ধর্মে সবচেয়ে বেশি পার্থক্য (দ্রাব্যতা, স্ফুটনাঙ্ক, উদ্বায়িতা, ঘনত্ব, অধিশোষণ বা বণ্টন সহগ), সেটিই পদ্ধতি নির্ধারণ করে।',
  html: () => `<div data-q></div><div class="ctl"><button class="btn sm" data-pv>← আগের</button><button class="btn sm" data-nx>পরের →</button><span data-sc class="mono small" style="margin-left:auto"></span></div>`,
  mount(el) {
    const q = el.querySelector('[data-q]'), sc = el.querySelector('[data-sc]');
    let i = 0; const ans = {};
    const keys = Object.keys(METH);
    const opts = k => { const rnd = X.rng(17 + k * 7); const c = SEPQ[k][1]; const pool = keys.filter(x => x !== c); const pick = []; while (pick.length < 3) { const p = pool[Math.floor(rnd() * pool.length)]; if (!pick.includes(p)) pick.push(p); } const all = [c, ...pick]; for (let j = all.length - 1; j > 0; j--) { const m = Math.floor(rnd() * (j + 1)); [all[j], all[m]] = [all[m], all[j]]; } return all; };
    const draw = () => {
      const [mix, c, why] = SEPQ[i], a = ans[i];
      q.innerHTML = `<div class="small muted">মিশ্রণ ${X.bn(i + 1)} / ${X.bn(SEPQ.length)}</div><div style="font-weight:600;font-size:16px;margin:4px 0 10px">${mix}</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">${opts(i).map(k => { let st = ''; if (a) { if (k === c) st = 'border-color:var(--ok);box-shadow:inset 0 0 0 1.5px var(--ok)'; else if (k === a) st = 'border-color:var(--bad);box-shadow:inset 0 0 0 1.5px var(--bad)'; } return `<button class="btn sm" data-o="${k}" style="justify-content:flex-start;text-align:left;${st}" ${a ? 'disabled' : ''}>${a && k === c ? '✓ ' : a && k === a ? '✗ ' : ''}${METH[k][0]}</button>`; }).join('')}</div>${a ? `<div class="calc-out"><b style="font-family:var(--font-body)">${a === c ? 'ঠিক!' : 'সঠিক উত্তর: ' + METH[c][0]}</b> (${METH[c][1]}) — ${why}</div>` : ''}`;
      const done = Object.keys(ans).length, ok = Object.keys(ans).filter(k => ans[k] === SEPQ[k][1]).length;
      sc.textContent = `${X.bn(ok)}/${X.bn(done)} সঠিক`;
      q.querySelectorAll('[data-o]').forEach(b => b.onclick = () => { ans[i] = b.dataset.o; draw(); });
    };
    el.querySelector('[data-pv]').onclick = () => { i = (i + SEPQ.length - 1) % SEPQ.length; draw(); };
    el.querySelector('[data-nx]').onclick = () => { i = (i + 1) % SEPQ.length; draw(); };
    draw();
  }
};

/* ======================= 2.14.1 কেলাসায়ন ======================= */
V.crystalSim = {
  t: 'কেলাসায়ন: ঠান্ডা করার হার ও কেলাসের আকার', k: ['anim', 'int'],
  cap: '৮০°C এ ১০০ g পানিতে KNO₃ এর সম্পৃক্ত দ্রবণ (≈১৬৯ g দ্রব) ঠান্ডা করা হচ্ছে। তাপমাত্রা কমলে দ্রাব্যতা কমে, অতিরিক্ত দ্রব কেলাস হিসেবে পড়ে। ধীরে ঠান্ডা করলে অল্প কয়েকটি কেন্দ্রক তৈরি হয় এবং সেগুলো বড়, সুগঠিত ও বিশুদ্ধ কেলাসে বাড়ে; দ্রুত ঠান্ডা করলে একসাথে অসংখ্য কেন্দ্রক — ছোট ছোট কেলাস, যাদের ফাঁকে মাতৃদ্রব আটকে অশুদ্ধি থাকতে পারে। বীজ কেলাস দিলে কেলাসন সেখান থেকেই শুরু হয়। (ছবিটি ধারণাগত; ভরের হিসাব দ্রাব্যতা লেখ থেকে।)',
  html: () => X.cv('কেলাসায়ন অ্যানিমেশন') + `<div class="ctl">${X.seg('cr', [['slow', 'ধীরে ঠান্ডা'], ['fast', 'দ্রুত (বরফ-পানি)']], 'slow')}<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-seed> বীজ কেলাস</label></div><div class="ctl"><button class="btn sm" data-go>ঠান্ডা করো</button><button class="btn sm" data-rs>নতুন করে</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const cv = el.querySelector('canvas'), hf = W => Math.min(270, W * 0.68); let L = X.fit(cv, hf);
    const out = el.querySelector('[data-out]'), S = T => X.solAt('KNO3', T);
    const T0 = 80, T1 = 20, M0 = S(T0), M1 = S(T1);
    let mode = 'slow', seed = false, T = T0, run = false, cr = [];
    const plan = () => {
      const rnd = X.rng(mode === 'slow' ? 3 : 9), n = mode === 'slow' ? (seed ? 3 : 6) : 48; cr = [];
      for (let i = 0; i < n; i++) cr.push({ x: rnd(), y: rnd(), born: seed && i === 0 ? 0 : (mode === 'slow' ? (seed ? 0.35 : 0.1) + rnd() * 0.45 : 0.04 + rnd() * 0.22), rot: (rnd() - 0.5) * 2.2, asp: 0.35 + rnd() * 0.3, w: 0.7 + rnd() * 0.6, seed: seed && i === 0 });
    };
    const msg = () => {
      if (run) { out.innerHTML = 'ঠান্ডা হচ্ছে…'; return; }
      if (T > T0 - 0.1) { out.innerHTML = `শুরু: ৮০°C এ ১০০ g পানিতে <b>${M0.toFixed(0)} g</b> KNO₃ দ্রবীভূত (সম্পৃক্ত)। "ঠান্ডা করো" চাপো।`; return; }
      out.innerHTML = `২০°C এ দ্রাব্যতা <b>${M1.toFixed(1)} g</b> ⟹ কেলাস = ${M0.toFixed(0)} − ${M1.toFixed(1)} = <b>${(M0 - M1).toFixed(1)} g</b> (আদায় <b>${((M0 - M1) / M0 * 100).toFixed(0)}%</b>)। ${mode === 'slow' ? 'অল্প কয়েকটি বড়, সুগঠিত কেলাস — অশুদ্ধি কম আটকায়, বিশুদ্ধতা বেশি।' : 'অসংখ্য ছোট কেলাস — দ্রুত পাওয়া যায়, কিন্তু কেলাসের ফাঁকে মাতৃদ্রব আটকে অশুদ্ধি থাকতে পারে।'} বাকি ${M1.toFixed(1)} g দ্রবণে থাকে — এটিই <b style="font-family:var(--font-body)">মাতৃদ্রব</b>।`;
    };
    plan(); msg();
    const A = X.anim(cv, dt => {
      if (run) { T -= (mode === 'slow' ? 5 : 22) * dt; if (T <= T1) { T = T1; run = false; msg(); } }
      const C = X.C(), g = L.g, W = L.W, H = L.H; g.clearRect(0, 0, W, H);
      const bx = W * 0.08, bw = W * 0.5, top = H * 0.1, bot = H * 0.9, lv = H * 0.22;
      const f = Math.max(0, Math.min(1, (M0 - S(T)) / (M0 - M1)));
      if (mode === 'fast') { g.fillStyle = 'rgba(150,200,240,.35)'; g.fillRect(bx - 12, H * 0.45, bw + 24, bot - H * 0.45 + 8); }
      const hot = (T - T1) / (T0 - T1);
      g.fillStyle = `rgba(${Math.round(190 + 60 * hot)},${Math.round(220 - 30 * hot)},${Math.round(245 - 80 * hot)},.45)`; g.fillRect(bx, lv, bw, bot - lv);
      g.strokeStyle = C.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(bx, top); g.lineTo(bx, bot); g.lineTo(bx + bw, bot); g.lineTo(bx + bw, top); g.stroke();
      if (mode === 'fast') { g.fillStyle = C.mu; g.font = `11px ${C.font}`; g.textAlign = 'left'; g.fillText('বরফ-পানি', bx - 10, bot + 16 > H ? H - 2 : bot + 14); }
      const n = cr.length, base = bw * 0.62 * Math.pow(1 / n, 1 / 3);
      cr.forEach(c => {
        if (!c.seed && f <= c.born) return;
        const gfrac = c.seed ? Math.max(0.12, f) : (f - c.born) / (1 - c.born);
        const len = Math.max(3, base * c.w * Math.cbrt(gfrac)), wd = len * c.asp;
        const x = bx + 10 + c.x * (bw - 20), y = c.seed ? lv + (bot - lv) * 0.4 : bot - 3 - wd / 2 - c.y * c.y * (bot - lv) * (mode === 'slow' ? 0.15 : 0.5);
        if (c.seed) { g.strokeStyle = C.mu; g.lineWidth = 1; g.beginPath(); g.moveTo(x, top - 4); g.lineTo(x, y - wd / 2); g.stroke(); }
        g.save(); g.translate(x, y); g.rotate(c.rot);
        g.beginPath(); g.moveTo(-len / 2, 0); g.lineTo(-len / 2 + wd * 0.5, -wd / 2); g.lineTo(len / 2 - wd * 0.5, -wd / 2); g.lineTo(len / 2, 0); g.lineTo(len / 2 - wd * 0.5, wd / 2); g.lineTo(-len / 2 + wd * 0.5, wd / 2); g.closePath();
        g.fillStyle = 'rgba(245,250,255,.95)'; g.fill(); g.strokeStyle = '#6f8fae'; g.lineWidth = 1; g.stroke();
        g.beginPath(); g.moveTo(-len / 2 + wd * 0.5, -wd / 2); g.lineTo(-len / 2 + wd * 0.7, 0); g.lineTo(len / 2 - wd * 0.7, 0); g.lineTo(len / 2 - wd * 0.5, -wd / 2); g.strokeStyle = 'rgba(111,143,174,.5)'; g.stroke();
        g.restore();
      });
      const tx = W * 0.64; g.textAlign = 'left'; g.fillStyle = C.fg; g.font = `600 ${Math.min(20, W * 0.05)}px ${C.mono}`; g.fillText(T.toFixed(0) + '°C', tx, H * 0.2);
      g.font = `${Math.min(12.5, W * 0.033)}px ${C.font}`; g.fillStyle = C.mu;
      g.fillText('দ্রাব্যতা (g/100 g পানি)', tx, H * 0.33); g.fillStyle = C.fg; g.font = `600 ${Math.min(15, W * 0.04)}px ${C.mono}`; g.fillText(S(T).toFixed(1), tx, H * 0.43);
      g.font = `${Math.min(12.5, W * 0.033)}px ${C.font}`; g.fillStyle = C.mu; g.fillText('কেলাস জমেছে', tx, H * 0.56); g.fillStyle = C.fg; g.font = `600 ${Math.min(15, W * 0.04)}px ${C.mono}`; g.fillText((M0 - S(T)).toFixed(1) + ' g', tx, H * 0.66);
      g.font = `${Math.min(12.5, W * 0.033)}px ${C.font}`; g.fillStyle = C.mu; g.fillText('কেলাসের সংখ্যা', tx, H * 0.79); g.fillStyle = C.fg; g.font = `600 ${Math.min(15, W * 0.04)}px ${C.mono}`; g.fillText(String(cr.filter(c => c.seed || f > c.born).length), tx, H * 0.89);
    });
    const reset = () => { T = T0; run = false; plan(); msg(); A.draw(); };
    X.onSeg(el, 'cr', k => { mode = k; reset(); });
    el.querySelector('[data-seed]').onchange = e => { seed = e.target.checked; reset(); };
    el.querySelector('[data-go]').onclick = () => { if (T <= T1 + 0.01) reset(); run = true; if (A.paused) A.pause(false); msg(); A.draw(); };
    el.querySelector('[data-rs]').onclick = reset;
    const ro = X.onResize(el, () => { L = X.fit(cv, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

/* ======================= 2.15 খাদ্য লবণ থেকে বিশুদ্ধ NaCl ======================= */
V.hclSalt = {
  t: 'খাদ্য লবণ থেকে বিশুদ্ধ NaCl: তিন ধাপ', k: ['anim', 'int'],
  cap: 'ধাপ বেছে নাও। ধাপ ২-এ সম্পৃক্ত লবণ দ্রবণে HCl গ্যাস চালনা করলে Cl⁻ (সম-আয়ন) এর ঘনমাত্রা বাড়ে, [Na⁺][Cl⁻] সম্পৃক্তির সীমা ছাড়িয়ে যায় — বিশুদ্ধ NaCl কেলাস পড়ে। MgCl₂ ও CaCl₂ অনেক বেশি দ্রবণীয় বলে দ্রবণেই থেকে যায়। HCl পানিতে অত্যন্ত দ্রবণীয়, তাই নলের মুখে উল্টানো ফানেল লাগানো হয় — পশ্চাৎ শোষণ রোধ করে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('st', [['1', '১. দ্রবীভূত ও ছাঁকা'], ['2', '২. HCl গ্যাস চালনা'], ['3', '৩. ছাঁকা ও শুকানো']], '1')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let timer = null, n = 0;
    const cube = (x, y, s = 5) => `<rect x="${f1(x)}" y="${f1(y)}" width="${s}" height="${s}" fill="#fff" stroke="#8aa4bd" stroke-width=".8"/>`;
    const TX = {
      '1': 'অশুদ্ধ খাদ্য লবণকে ন্যূনতম পরিমাণ পানিতে দ্রবীভূত করে <b style="font-family:var(--font-body)">সম্পৃক্ত দ্রবণ</b> তৈরি করা হয়। বালি, মাটি ইত্যাদি অদ্রবণীয় ময়লা পরিস্রাবণে আলাদা হয়। পরিস্রুতে Na⁺ ও Cl⁻ ছাড়াও দ্রবণীয় অশুদ্ধি Mg²⁺, Ca²⁺, SO₄²⁻ (MgCl₂, CaCl₂, MgSO₄, CaSO₄) থেকে যায় — MgCl₂ ও CaCl₂ আর্দ্রতাগ্রাহী, তাই অশুদ্ধ লবণ বর্ষায় ভিজে ওঠে।',
      '2': 'ফ্লাস্কে NaCl ও গাঢ় H₂SO₄ মৃদু উত্তপ্ত করলে HCl গ্যাস তৈরি হয়:<div class="eq">NaCl + H₂SO₄ → NaHSO₄ + HCl↑</div>গ্যাসটি সম্পৃক্ত লবণ দ্রবণে চালনা করলে: NaCl(s) ⇌ Na⁺(aq) + Cl⁻(aq) সাম্যে Cl⁻ বেড়ে যায় — লা শাতেলিয়ের নীতি অনুযায়ী সাম্য বামে সরে, <b>বিশুদ্ধ NaCl</b> কেলাসিত হয় (সম-আয়ন প্রভাব, ২.১২.১)। MgCl₂ ও CaCl₂ এর দ্রাব্যতা অনেক বেশি — তাদের সম্পৃক্তি ছাড়ায় না, দ্রবণে থাকে।',
      '3': 'কেলাসগুলো শোষণ পরিস্রাবণে ছেঁকে অল্প <b style="font-family:var(--font-body)">ঠান্ডা গাঢ় HCl</b> (বা খুব অল্প ঠান্ডা পাতিত পানি) দিয়ে ধোয়া হয় — লেগে থাকা মাতৃদ্রব (Mg²⁺, Ca²⁺) দূর হয়, কিন্তু সম-আয়নের কারণে NaCl দ্রবীভূত হয় না। এরপর চীনামাটির পাত্রে উত্তপ্ত করে শুকালে লেগে থাকা HCl ও পানি বাষ্প হয়ে উড়ে যায় — বিশুদ্ধ, শুষ্ক, অনার্দ্র NaCl পাওয়া যায়।'
    };
    const draw = st => {
      clearInterval(timer); n = 0;
      let s = `<defs>${X.arrow('hsA')}</defs>`;
      if (st === '1') {
        s += `<path d="M30 70 L30 160 L110 160 L110 70" fill="none" class="s-fg" stroke-width="2"/><rect x="31.5" y="96" width="77" height="63" fill="#cdbfa3" opacity=".75"/>`;
        const rnd = X.rng(2); for (let i = 0; i < 22; i++) s += `<circle cx="${f1(36 + rnd() * 68)}" cy="${f1(100 + rnd() * 56)}" r="1.6" fill="#7a5a2f"/>`;
        s += `<text x="70" y="180" text-anchor="middle" class="tm" style="font-size:10.5px">অশুদ্ধ লবণ + ন্যূনতম পানি</text><line x1="118" y1="115" x2="160" y2="115" class="s-fg" marker-end="url(#hsA)"/>`;
        s += `<defs><clipPath id="hsP"><path d="M196 54 L264 54 L230 104Z"/></clipPath></defs><path d="M190 50 L270 50 L233 110 L233 168 L227 168 L227 110Z" fill="rgba(200,220,235,.25)" class="s-fg" stroke-width="2"/><path d="M196 54 L264 54 L230 104Z" class="f-sf s-mu"/><rect x="190" y="70" width="80" height="40" fill="#b9a382" opacity=".55" clip-path="url(#hsP)"/>`;
        for (let i = 0; i < 18; i++) { const y = 86 + rnd() * 16, h = (104 - y) * 34 / 50; s += `<circle cx="${f1(230 - h * 0.8 + rnd() * h * 1.6)}" cy="${f1(y)}" r="1.7" fill="#7a5a2f"/>`; }
        s += `<path d="M190 160 L190 236 L270 236 L270 160" fill="none" class="s-fg" stroke-width="2"/><rect x="191.5" y="196" width="77" height="39" fill="#dbe9f5"/><circle class="anim-drip" cx="230" cy="170" r="2.4" fill="#9cc6e6"/>`;
        s += `<text x="276" y="80" class="tm" style="font-size:10.5px">অদ্রবণীয় ময়লা</text><text x="276" y="212" class="tm" style="font-size:10.5px">সম্পৃক্ত লবণ দ্রবণ</text><text x="276" y="226" class="tm" style="font-size:9.5px">(Na⁺, Cl⁻ + Mg²⁺, Ca²⁺, SO₄²⁻)</text>`;
        box.innerHTML = X.svg(400, 246, s, 'দ্রবীভূতকরণ ও পরিস্রাবণ');
      } else if (st === '2') {
        s += `<defs><clipPath id="hsF"><circle cx="80" cy="182" r="31"/></clipPath></defs>` + tripod(80, 214, true, 28);
        s += `<rect x="40" y="186" width="80" height="40" fill="#e6dccb" clip-path="url(#hsF)"/>`;
        const rnd = X.rng(6); for (let i = 0; i < 14; i++) s += `<rect x="${f1(58 + rnd() * 44)}" y="${f1(200 + rnd() * 9)}" width="3.5" height="3.5" fill="#fff" stroke="#9aa" stroke-width=".5" clip-path="url(#hsF)"/>`;
        s += `<path d="M73 112 L73 152 A32 32 0 1 0 87 152 L87 112" fill="none" class="s-fg" stroke-width="2"/><rect x="70" y="106" width="20" height="8" rx="2" class="f-mu"/>`;
        s += `<path d="M66 54 L94 54 L83 80 L83 112 L77 112 L77 80Z" class="s-fg" fill="rgba(240,220,170,.55)" stroke-width="1.6"/><text x="98" y="60" class="tm" style="font-size:9.5px">গাঢ় H₂SO₄</text><line x1="80" y1="112" x2="80" y2="166" class="s-fg" stroke-width="1.2"/>`;
        s += `<path d="M86 118 L120 118 L120 70 L310 70 L310 132" fill="none" class="s-fg" stroke-width="4" stroke-linejoin="round"/><path d="M86 118 L120 118 L120 70 L310 70 L310 132" fill="none" stroke="#c9d7a6" stroke-width="2" class="anim-flow"/>`;
        s += `<path d="M298 132 L322 132 L340 158 L280 158Z" class="s-fg" fill="rgba(200,220,235,.3)" stroke-width="1.8"/>`;
        s += `<path d="M240 140 L240 238 L380 238 L380 140" fill="none" class="s-fg" stroke-width="2"/><rect x="241.5" y="158" width="137" height="79" fill="#dbe9f5"/>`;
        for (let i = 0; i < 6; i++) s += `<circle class="anim-bub" cx="${290 + i * 8}" cy="${156 + (i % 2) * 2}" r="2" fill="#fff" stroke="#9fb4c8" stroke-width=".6" style="animation-delay:${(i * 0.27).toFixed(2)}s"/>`;
        s += `<g data-xt></g>`;
        s += `<text x="80" y="268" text-anchor="middle" class="tm" style="font-size:9.5px">NaCl + গাঢ় H₂SO₄ (মৃদু তাপ)</text><text x="200" y="62" text-anchor="middle" class="tm" style="font-size:10.5px">HCl গ্যাস →</text><text x="328" y="126" class="tm" style="font-size:9.5px">উল্টানো ফানেল</text><text x="310" y="252" text-anchor="middle" class="tm" style="font-size:10px">সম্পৃক্ত লবণ দ্রবণ → NaCl কেলাস</text>`;
        box.innerHTML = X.svg(400, 274, s, 'HCl গ্যাস চালনা');
        const g = box.querySelector('[data-xt]'); const rr = X.rng(13);
        timer = setInterval(() => { if (n >= 46) { clearInterval(timer); return; } n++; const x = 248 + rr() * 124, y = 228 - Math.floor(n / 14) * 5 - rr() * 3; g.insertAdjacentHTML('beforeend', cube(x, y, 4 + rr() * 2)); }, 140);
      } else {
        s += `<path d="M30 60 L110 60 L110 92 L84 112 L84 128 L56 128 L56 112 L30 92Z" class="f-s2 s-fg" stroke-width="2" stroke-linejoin="round"/><line x1="32" y1="92" x2="108" y2="92" class="s-fg" stroke-width="2"/>`;
        const rnd = X.rng(21); for (let i = 0; i < 30; i++) s += cube(34 + rnd() * 68, 78 + rnd() * 9, 4);
        s += `<path d="M28 34 L48 34 L54 54" fill="none" class="s-mu" stroke-width="1.5" marker-end="url(#hsA)"/><text x="14" y="28" class="tm" style="font-size:9.5px">ঠান্ডা গাঢ় HCl দিয়ে ধোয়া</text><text x="70" y="146" text-anchor="middle" class="tm" style="font-size:10px">শোষণ পরিস্রাবণ</text>`;
        s += `<line x1="128" y1="100" x2="196" y2="100" class="s-fg" marker-end="url(#hsA)"/>`;
        s += `<path d="M230 150 Q290 196 350 150" class="f-s2 s-fg" stroke-width="2"/>` + tripod(290, 168, true, 34);
        for (let i = 0; i < 26; i++) s += cube(258 + rnd() * 62, 158 + rnd() * 10, 4);
        for (let i = 0; i < 4; i++) s += `<path class="anim-vap" d="M${270 + i * 14} 148 q4 -6 0 -12 q-4 -6 0 -12" fill="none" stroke="#a3b1bf" stroke-width="1.4" style="animation-delay:${i * 0.5}s"/>`;
        s += `<text x="290" y="112" text-anchor="middle" class="tm" style="font-size:10px">HCl ও পানি বাষ্প হয়ে উড়ে যায়</text><text x="290" y="236" text-anchor="middle" class="tm" style="font-size:10px">চীনামাটির পাত্রে উত্তপ্ত করে শুকানো</text>`;
        box.innerHTML = X.svg(400, 244, s, 'শুকানো');
      }
      out.innerHTML = TX[st];
    };
    X.onSeg(el, 'st', draw); draw('1');
    return () => clearInterval(timer);
  }
};

/* ======================= 2.15.1 আংশিক কেলাসায়ন ======================= */
V.fracCryst = {
  t: 'আংশিক কেলাসায়ন: KNO₃ ও NaCl এর মিশ্রণ পৃথকীকরণ', k: ['calc', 'int'],
  cap: 'উচ্চ তাপমাত্রায় মিশ্রণ পানিতে দ্রবীভূত করা হয়; যে লবণ ওই তাপমাত্রায় দ্রবণীয়তার চেয়ে বেশি আছে তা অদ্রবীভূত থাকে এবং গরম অবস্থায় ছেঁকে আলাদা করা হয়। পরিস্রুত ঠান্ডা করলে যার দ্রাব্যতা তাপমাত্রার সাথে বেশি কমে (KNO₃) সেটি কেলাসিত হয়, অন্যটি (NaCl) দ্রবণে থাকে। হিসাব দ্রাব্যতা লেখের মান দিয়ে; বাস্তবে দুটি লবণ একে অপরের দ্রাব্যতা সামান্য বদলায়।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('pr', [['a', 'উদাহরণ ১'], ['b', 'উদাহরণ ২ (NaCl বেশি)']], 'a')}</div><div class="grid3">${fld('KNO₃ (g)', 'data-k', 100)}${fld('NaCl (g)', 'data-n', 30)}${fld('পানি (g)', 'data-w', 100)}</div><div class="grid2" style="margin-top:8px">${fld('উচ্চ T (°C)', 'data-h', 100)}${fld('নিম্ন T (°C)', 'data-l', 20)}</div><div data-svg style="margin-top:8px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const S = X.solAt;
    const run = () => {
      const mk = Math.max(0, +q('[data-k]').value || 0), mn = Math.max(0, +q('[data-n]').value || 0), w = Math.max(1, +q('[data-w]').value || 100);
      let th = Math.min(100, Math.max(0, +q('[data-h]').value || 100)), tl = Math.min(100, Math.max(0, +q('[data-l]').value || 0)); if (tl >= th) tl = Math.max(0, th - 1);
      const sKh = S('KNO3', th) * w / 100, sNh = S('NaCl', th) * w / 100, sKl = S('KNO3', tl) * w / 100, sNl = S('NaCl', tl) * w / 100;
      const dK = Math.min(mk, sKh), dN = Math.min(mn, sNh), uK = mk - dK, uN = mn - dN;
      const cK = Math.max(0, dK - sKl), cN = Math.max(0, dN - sNl), pur = cK + cN > 0 ? cK / (cK + cN) * 100 : 0;
      const mx = Math.max(mk, mn, 1), bar = (y, tot, parts, lab) => { let x = 96, r = ''; parts.forEach(([v, c, t]) => { const wd = v / mx * 280; if (wd > 0.5) r += `<rect x="${f1(x)}" y="${y}" width="${f1(wd)}" height="22" fill="${c}"/>${wd > 34 ? `<text x="${f1(x + wd / 2)}" y="${y + 15}" text-anchor="middle" style="font-size:10px;fill:#1b1b1b">${t}</text>` : ''}`; x += wd; }); return `<text x="90" y="${y + 15}" text-anchor="end" style="font-size:12px;font-weight:600">${lab}</text>${r}<rect x="96" y="${y}" width="${f1(tot / mx * 280)}" height="22" fill="none" class="s-ln"/>`; };
      let s = bar(14, mk, [[uK, '#c9b38a', 'অদ্রবীভূত'], [cK, '#7fb8e8', 'কেলাস'], [dK - cK, '#e3eef8', 'দ্রবণে']], 'KNO₃') + bar(52, mn, [[uN, '#c9b38a', 'অদ্রবীভূত'], [cN, '#e8a27f', 'কেলাস'], [dN - cN, '#f6e7de', 'দ্রবণে']], 'NaCl');
      s += `<rect x="96" y="88" width="12" height="10" fill="#c9b38a"/><text x="112" y="97" class="tm" style="font-size:10px">${th}°C এ অদ্রবীভূত (গরম অবস্থায় ছাঁকা)</text><rect x="96" y="104" width="12" height="10" fill="#7fb8e8"/><text x="112" y="113" class="tm" style="font-size:10px">${tl}°C এ ঠান্ডা করলে কেলাস</text>`;
      box.innerHTML = X.svg(400, 122, s, 'আংশিক কেলাসায়ন');
      out.innerHTML = `${th}°C এ ${w} g পানিতে দ্রাব্যতা: KNO₃ <b>${sKh.toFixed(1)} g</b>, NaCl <b>${sNh.toFixed(1)} g</b>।<br>` +
        (uK + uN > 0.05 ? `অদ্রবীভূত থাকে: ${uK > 0.05 ? 'KNO₃ ' + uK.toFixed(1) + ' g ' : ''}${uN > 0.05 ? 'NaCl <b>' + uN.toFixed(1) + ' g</b>' : ''} → গরম অবস্থায় ছেঁকে আলাদা।<br>` : 'সব দ্রবীভূত হয়।<br>') +
        `${tl}°C এ দ্রাব্যতা: KNO₃ ${sKl.toFixed(1)} g, NaCl ${sNl.toFixed(1)} g ⟹ কেলাস: KNO₃ <b>${cK.toFixed(1)} g</b>, NaCl <b>${cN.toFixed(1)} g</b>।<br>` +
        (cK + cN > 0 ? `কেলাসের বিশুদ্ধতা (KNO₃) ≈ <b>${pur.toFixed(1)}%</b>। ${cN > 0.05 ? 'NaCl ও কিছুটা কেলাসিত হয়েছে — কেলাসগুলো আবার অল্প গরম পানিতে দ্রবীভূত করে পুনঃকেলাসায়ন করতে হবে।' : 'শুধু KNO₃ কেলাসিত হয়েছে (মাতৃদ্রব ধুয়ে ফেললে বিশুদ্ধ)।'}` : 'কোনো কেলাস পড়েনি — পানি কমাও বা আরও ঠান্ডা করো।');
    };
    const P = { a: [100, 30, 100, 100, 20], b: [100, 60, 100, 100, 20] };
    X.onSeg(el, 'pr', k => { ['k', 'n', 'w', 'h', 'l'].forEach((a, i) => q(`[data-${a}]`).value = P[k][i]); run(); });
    el.querySelectorAll('input').forEach(i => i.addEventListener('input', run)); run();
  }
};

/* ======================= 2.16 সাধারণ পাতন ======================= */
V.simpleDist = {
  t: 'সাধারণ পাতন: অ্যানিমেটেড যন্ত্রসজ্জা', k: ['anim', 'int'],
  cap: '"তাপ দাও" চাপো। তাপমাত্রা স্ফুটনাঙ্কে পৌঁছালে স্থির থাকে এবং বাষ্প শীতকে ঘনীভূত হয়ে গ্রাহক পাত্রে জমে। খেয়াল করো: থার্মোমিটারের বাল্ব পার্শ্বনলের মুখ বরাবর (বাষ্পের তাপমাত্রা মাপে); শীতকে পানি নিচের দিক দিয়ে ঢোকে ও উপরের দিক দিয়ে বের হয় (শীতক সবসময় পানিতে পূর্ণ থাকে, বিপরীতমুখী প্রবাহে শীতলীকরণ বেশি); ফ্লাস্কে ফুটন্ত চিপস থাকে, আর ফ্লাস্ক কখনো সম্পূর্ণ শুকানো হয় না।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('mx', [['salt', 'লবণ-পানি'], ['ace', 'অ্যাসিটোন + পানি']], 'salt')}</div><div data-svg></div><div class="ctl"><button class="btn sm" data-go>তাপ দাও</button><button class="btn sm" data-rs>নতুন করে</button><label style="display:flex;gap:6px;align-items:center;margin-left:auto"><input type="checkbox" data-lb checked> লেবেল</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const MX = {
      salt: { liq: '#cfe3f3', res: '#ffffff', st: [{ bp: 100, n: 'পানি', v: 0.75, c: '#cfe9ff' }], end: 'প্রায় সব পানি পাতিত হয়েছে। লবণ অনুদ্বায়ী — ফ্লাস্কেই থেকে গেছে। গ্রাহক পাত্রে বিশুদ্ধ (পাতিত) পানি। ফ্লাস্ক কখনো সম্পূর্ণ শুকানো হয় না — অতিতাপে ফেটে যেতে পারে।' },
      ace: { liq: '#dbe8f4', st: [{ bp: 56, n: 'অ্যাসিটোন', v: 0.42, c: '#eef5cf' }, { bp: 100, n: 'পানি', v: 0.4, c: '#cfe9ff' }], end: 'প্রথমে ৫৬°C এ অ্যাসিটোন, তারপর তাপমাত্রা লাফিয়ে ১০০°C এ উঠে পানি পাতিত হলো। স্ফুটনাঙ্কের পার্থক্য বড় (৪৪°C) বলে সাধারণ পাতনেই প্রায় পৃথক হয়। পার্থক্য ছোট হলে আংশিক পাতন লাগে।' }
    };
    let mix = 'salt', T = 25, si = 0, dn = 0, tot = 0, recv = 0, ph = 'idle', lab = true, G = null;
    const full = () => {
      const m = MX[mix], st = m.st[Math.min(si, m.st.length - 1)];
      G = rig({ id: 'sdR', run: ph === 'dist', flame: ph === 'heat' || ph === 'dist', fill: Math.max(0.1, 0.5 * (1 - tot)), recv, liq: m.liq, dist: st.c, residue: mix === 'salt' && tot > 0.4 ? '#ffffff' : null, T: Math.round(T) + '°C', lab, vap: '#b9c6d2' });
      box.innerHTML = X.svg(400, G.H, G.svg, 'সাধারণ পাতন');
    };
    const msg = () => {
      const m = MX[mix], st = m.st[Math.min(si, m.st.length - 1)];
      out.innerHTML = ph === 'idle' ? 'থার্মোমিটার এখন কক্ষ তাপমাত্রা দেখাচ্ছে। "তাপ দাও" চাপো।' : ph === 'heat' ? `তাপমাত্রা বাড়ছে… ${st.n} এর স্ফুটনাঙ্ক <b>${st.bp}°C</b>।${si > 0 ? ' (নতুন গ্রাহক পাত্র বসানো হলো)' : ''}` : ph === 'dist' ? `<b>${st.bp}°C</b> এ তাপমাত্রা স্থির — ${st.n} বাষ্পীভূত হয়ে শীতকে ঘনীভূত হচ্ছে, ফোঁটা ফোঁটা <b style="font-family:var(--font-body)">পরিস্রুত</b> জমছে। যতক্ষণ একটি উপাদান পাতিত হয়, তাপমাত্রা স্থির থাকে।` : m.end;
    };
    const setDyn = () => {
      if (!G) return; const t = box.querySelector('[data-t]'); if (t) t.textContent = Math.round(T) + '°C';
      const rl = box.querySelector('[data-rl]'); if (rl) { const hh = G.hmax * Math.min(1, recv); rl.setAttribute('y', f1(G.rBase - hh)); rl.setAttribute('height', f1(hh)); }
      const fl = box.querySelector('[data-fl]'); if (fl) { const fr = Math.max(0.1, 0.5 * (1 - tot)), lvl = G.by - 2 * G.r * fr; fl.setAttribute('y', f1(lvl)); fl.setAttribute('height', f1(G.by - lvl + 2)); }
    };
    const reset = () => { T = 25; si = 0; dn = 0; tot = 0; recv = 0; ph = 'idle'; full(); msg(); };
    const A = X.anim(box, dt => {
      if (ph === 'heat') { const bp = MX[mix].st[si].bp; T += 16 * dt; if (T >= bp) { T = bp; ph = 'dist'; full(); msg(); } setDyn(); }
      else if (ph === 'dist') { const st = MX[mix].st[si], d = 0.07 * dt; dn += d; tot += d * 0.9; recv += d * 1.6; if (dn >= st.v) { si++; dn = 0; if (si < MX[mix].st.length) { ph = 'heat'; recv = 0; full(); } else { si = MX[mix].st.length - 1; ph = 'done'; full(); } msg(); } setDyn(); }
    });
    el.querySelector('[data-go]').onclick = () => { if (ph === 'done') reset(); if (ph === 'idle') { ph = 'heat'; full(); msg(); } if (A.paused) A.pause(false); A.draw(); };
    el.querySelector('[data-rs]').onclick = reset;
    el.querySelector('[data-lb]').onchange = e => { lab = e.target.checked; full(); setDyn(); };
    X.onSeg(el, 'mx', k => { mix = k; reset(); });
    reset();
    return () => A.stop();
  }
};

/* ======================= 2.16 আংশিক পাতন: প্লেট ও পাতন লেখ ======================= */
const Pb = T => Math.pow(10, 6.90565 - 1211.033 / (T + 220.79)), Ptl = T => Math.pow(10, 6.95464 - 1344.8 / (T + 219.482));
const Tbub = x => { let lo = 70, hi = 120; for (let i = 0; i < 34; i++) { const m = (lo + hi) / 2; if (x * Pb(m) + (1 - x) * Ptl(m) > 760) hi = m; else lo = m; } return (lo + hi) / 2; };
const yEq = x => x * Pb(Tbub(x)) / 760;
const yN = (x, n) => { let y = x; for (let i = 0; i <= n; i++) y = yEq(y); return y; };
const distCurve = (x0, n) => { let L = 1, x = x0; const pts = []; for (let f = 0; f <= 0.95 + 1e-9; f += 0.01) { const y = Math.min(1, yN(x, n)), top = n ? yN(x, n - 1) : x; pts.push([f, Tbub(top), y]); const dL = 0.01; const nx = (L * x - y * dL) / (L - dL); L -= dL; x = Math.max(0, nx); } return pts; };
V.fracDist = {
  t: 'আংশিক পাতন: প্লেট সংখ্যা ও পৃথকীকরণ (বেনজিন–টলুইন)', k: ['int', 'calc'],
  cap: 'স্তম্ভের প্রতিটি "তাত্ত্বিক প্লেট" এ বাষ্প ঘনীভূত হয়ে আবার বাষ্পীভূত হয়; প্রতিবার বাষ্পে বেশি উদ্বায়ী উপাদানের (বেনজিন, স্ফুটনাঙ্ক ৮০.১°C) অনুপাত বাড়ে। প্লেট সংখ্যা বাড়াও — মাথার তাপমাত্রার লেখটি ধাপের মতো হয়ে যায়: প্রথমে প্রায় ৮০°C এ বিশুদ্ধ বেনজিন, পরে লাফিয়ে ১১০.৬°C এ টলুইন। ০ প্লেট মানে সাধারণ পাতন (ড্যাশ রেখা)। হিসাব রাউল্টের সূত্র ও অ্যান্টোয়ান সমীকরণ দিয়ে (পূর্ণ রিফ্লাক্স ধরে আসন্ন)।',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none;min-width:86px">তাত্ত্বিক প্লেট</label><input type="range" min="0" max="8" step="1" value="4" data-n style="flex:1"><span class="mono" data-nv style="min-width:34px;text-align:right">4</span></div><div class="ctl"><label style="flex:none;min-width:86px">বেনজিন (মোল%)</label><input type="range" min="10" max="90" step="5" value="50" data-x style="flex:1"><span class="mono" data-xv style="min-width:34px;text-align:right">50%</span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const col = y => { const a = [230, 126, 34], b = [52, 120, 230]; return `rgb(${a.map((v, i) => Math.round(v + (b[i] - v) * y)).join(',')})`; };
    const run = () => {
      const n = +el.querySelector('[data-n]').value, x0 = +el.querySelector('[data-x]').value / 100;
      el.querySelector('[data-nv]').textContent = n; el.querySelector('[data-xv]').textContent = Math.round(x0 * 100) + '%';
      const X0 = 50, X1 = 384, Y0 = 170, Y1 = 22, tx = f => X0 + f * (X1 - X0) / 0.95, ty = T => Y0 - (T - 76) / (114 - 76) * (Y0 - Y1);
      let s = `<line x1="${X0}" y1="${Y0}" x2="${X1}" y2="${Y0}" class="s-ln"/><line x1="${X0}" y1="${Y0}" x2="${X0}" y2="${Y1}" class="s-ln"/>`;
      [80, 90, 100, 110].forEach(T => s += `<text x="${X0 - 5}" y="${f1(ty(T) + 4)}" text-anchor="end" class="tm mono" style="font-size:10px">${T}</text><line x1="${X0}" y1="${f1(ty(T))}" x2="${X1}" y2="${f1(ty(T))}" class="s-ln" opacity=".25"/>`);
      [0, 25, 50, 75, 95].forEach(p => s += `<text x="${f1(tx(p / 100))}" y="${Y0 + 14}" text-anchor="middle" class="tm mono" style="font-size:10px">${p}</text>`);
      s += `<text x="${X1}" y="${Y0 + 28}" text-anchor="end" class="tm" style="font-size:10px">পাতিত আয়তন (%)</text><text x="${X0 + 4}" y="${Y1 - 8}" class="tm" style="font-size:10px">মাথার তাপমাত্রা (°C)</text>`;
      s += `<line x1="${X0}" y1="${f1(ty(80.1))}" x2="${X1}" y2="${f1(ty(80.1))}" stroke="#3478e6" stroke-dasharray="2 4" opacity=".6"/><line x1="${X0}" y1="${f1(ty(110.6))}" x2="${X1}" y2="${f1(ty(110.6))}" stroke="#e67e22" stroke-dasharray="2 4" opacity=".6"/><text x="${X1}" y="${f1(ty(80.1) - 4)}" text-anchor="end" style="font-size:9.5px;fill:#3478e6">বেনজিন ৮০.১</text><text x="${X1}" y="${f1(ty(110.6) + 12)}" text-anchor="end" style="font-size:9.5px;fill:#e67e22">টলুইন ১১০.৬</text>`;
      const path = pts => pts.map((p, i) => (i ? 'L' : 'M') + f1(tx(p[0])) + ' ' + f1(ty(p[1]))).join('');
      const c0 = distCurve(x0, 0), cn = n ? distCurve(x0, n) : c0;
      if (n) s += `<path d="${path(c0)}" fill="none" class="s-mu" stroke-width="1.8" stroke-dasharray="5 4"/>`;
      s += `<path d="${path(cn)}" fill="none" class="s-acc" stroke-width="2.6"/>`;
      const st = [x0]; for (let i = 0; i <= n; i++) st.push(yEq(st[st.length - 1]));
      const bw = Math.min(40, 330 / st.length), gx = 200 - bw * st.length / 2, by = 214;
      st.forEach((v, i) => { const x = gx + i * bw; s += `<rect x="${f1(x + 2)}" y="${by}" width="${f1(bw - 4)}" height="26" rx="4" fill="${col(v)}" opacity=".85"/><text x="${f1(x + bw / 2)}" y="${by + 17}" text-anchor="middle" class="mono" style="font-size:${bw < 34 ? 8.5 : 9.5}px;fill:#fff;font-weight:600">${(v * 100).toFixed(0)}</text><text x="${f1(x + bw / 2)}" y="${by + 38}" text-anchor="middle" class="tm" style="font-size:8.5px">${i === 0 ? 'পাত্র' : i === st.length - 1 ? 'মাথা' : 'প' + X.bn(i)}</text>`; });
      s += `<text x="200" y="${by - 6}" text-anchor="middle" class="tm" style="font-size:10px">প্রতিটি ধাপে বাষ্পে বেনজিন (মোল %) →</text>`;
      box.innerHTML = X.svg(400, 256, s, 'আংশিক পাতন লেখ');
      const y0 = yN(x0, 0), yn = yN(x0, n);
      const pure = cn.filter(p => p[2] >= 0.95).length;
      out.innerHTML = `শুরুতে পাত্রে বেনজিন <b>${(x0 * 100).toFixed(0)}%</b>। প্রথম ফোঁটা পরিস্রুতে বেনজিন — সাধারণ পাতনে <b>${(y0 * 100).toFixed(1)}%</b>${n ? `, ${X.bn(n)} প্লেটের স্তম্ভে <b>${(yn * 100).toFixed(1)}%</b>` : ''}। ${n ? `৯৫% এর বেশি বিশুদ্ধ বেনজিন পাওয়া যায় মোট আয়তনের প্রায় <b>${pure}%</b> পর্যন্ত।` : 'সাধারণ পাতনে তাপমাত্রা ধীরে ধীরে বাড়ে — কোনো অংশই বিশুদ্ধ নয়।'} প্লেট যত বেশি (স্তম্ভ যত লম্বা ও পূর্ণ), পৃথকীকরণ তত তীক্ষ্ণ।`;
    };
    el.querySelectorAll('input').forEach(i => i.addEventListener('input', run)); run();
  }
};

/* ======================= 2.16 পেট্রোলিয়ামের আংশিক পাতন ======================= */
const FR = [
  ['gas', 'পেট্রোলিয়াম গ্যাস', '< ৪০°C', 'C₁–C₄', 'রান্নার গ্যাস (LPG), জ্বালানি, রাসায়নিক শিল্পের কাঁচামাল', '#9ec5fe'],
  ['pet', 'পেট্রোল (গ্যাসোলিন)', '৪০–৭৫°C', 'C₅–C₇', 'মোটরগাড়ির জ্বালানি, দ্রাবক', '#a7e3c4'],
  ['nap', 'ন্যাপথা', '৭৫–১৫০°C', 'C₇–C₁₀', 'পেট্রোকেমিক্যাল কাঁচামাল (প্লাস্টিক, রঞ্জক, ওষুধ), দ্রাবক', '#d6e9a8'],
  ['ker', 'কেরোসিন', '১৫০–২৫০°C', 'C₁₀–C₁₄', 'জেট বিমানের জ্বালানি, বাতি ও চুলার জ্বালানি', '#f5e3a0'],
  ['dsl', 'ডিজেল', '২৫০–৩৫০°C', 'C₁₄–C₂₀', 'বাস-ট্রাক, জেনারেটর, সেচ পাম্প ও রেলইঞ্জিনের জ্বালানি', '#f6c995'],
  ['lub', 'লুব্রিকেটিং তেল, মোম', '৩৫০–৪০০°C', 'C₂₀–C₃₀', 'যন্ত্রাংশ পিচ্ছিলকারক, প্যারাফিন মোম, পেট্রোলিয়াম জেলি', '#e9a87c'],
  ['bit', 'বিটুমিন (অবশেষ)', '> ৪০০°C', '> C₃₀', 'রাস্তা পাকা করা (পিচ), ছাদের জলরোধী আস্তরণ', '#8a6f5c']
];
V.refinery = {
  t: 'অপরিশোধিত পেট্রোলিয়ামের আংশিক পাতন স্তম্ভ', k: ['2d', 'int'],
  cap: 'অপরিশোধিত তেল চুল্লিতে প্রায় ৪০০°C এ উত্তপ্ত করে বাষ্প হিসেবে স্তম্ভের নিচে পাঠানো হয়। স্তম্ভের নিচে তাপমাত্রা বেশি, উপরে কম। বাষ্প উপরে উঠতে উঠতে যে উচ্চতায় তাপমাত্রা তার স্ফুটনাঙ্কের নিচে নামে, সেখানে ঘনীভূত হয়ে ট্রেতে জমে এবং পার্শ্বনল দিয়ে বের হয়। ছোট অণু (কম স্ফুটনাঙ্ক) উপরে, বড় অণু নিচে। একটি অংশে ট্যাপ করো। (তাপমাত্রার পরিসর আনুমানিক; বিভিন্ন বইয়ে সামান্য ভিন্ন।)',
  html: () => `<div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let sel = 'ker';
    const draw = () => {
      let s = `<defs>${X.arrow('rfA')}<linearGradient id="rfG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cfe3fb"/><stop offset="1" stop-color="#f6b47a"/></linearGradient></defs>`;
      s += `<rect x="110" y="20" width="80" height="250" rx="22" fill="url(#rfG)" class="s-fg" stroke-width="2"/>`;
      FR.forEach((f, i) => {
        const y = 40 + i * 33, on = f[0] === sel;
        s += `<line x1="114" y1="${y + 10}" x2="186" y2="${y + 10}" class="s-mu" stroke-dasharray="4 3"/>`;
        s += `<g data-f="${f[0]}" style="cursor:pointer"><line x1="190" y1="${y}" x2="228" y2="${y}" class="s-fg" stroke-width="${on ? 4 : 2.5}" marker-end="url(#rfA)"/><rect x="232" y="${y - 12}" width="160" height="24" rx="7" fill="${f[5]}" ${on ? 'stroke="var(--accent)" stroke-width="2.5"' : 'class="s-ln"'}/><text x="240" y="${y + 4}" style="font-size:11px;font-weight:${on ? 700 : 600};fill:#1b1b1b">${f[1]}</text><text x="386" y="${y + 4}" text-anchor="end" class="mono" style="font-size:9.5px;fill:#333">${f[2]}</text></g>`;
      });
      s += `<path d="M20 250 L60 250 L60 236 L104 236" fill="none" class="s-fg" stroke-width="3" marker-end="url(#rfA)"/><rect x="18" y="252" width="44" height="26" rx="4" class="f-s3 s-fg"/>${flame(40, 276, 16)}<text x="40" y="292" text-anchor="middle" class="tm" style="font-size:9.5px">চুল্লি</text><text x="8" y="210" class="tm" style="font-size:9.5px">অপরিশোধিত</text><text x="8" y="223" class="tm" style="font-size:9.5px">তেলের বাষ্প</text>`;
      s += `<text x="100" y="34" text-anchor="end" class="tm" style="font-size:10px">শীতল</text><text x="100" y="268" text-anchor="end" class="tm" style="font-size:10px">উষ্ণ</text><line x1="96" y1="44" x2="96" y2="254" class="s-mu" marker-start="url(#rfA)"/>`;
      box.innerHTML = X.svg(400, 296, s, 'পেট্রোলিয়াম শোধনাগার স্তম্ভ');
      box.querySelectorAll('[data-f]').forEach(g => g.onclick = () => { sel = g.dataset.f; draw(); });
      const f = FR.find(x => x[0] === sel);
      out.innerHTML = `<b style="font-family:var(--font-body)">${f[1]}</b> — স্ফুটনাঙ্ক পরিসর <b>${f[2]}</b>, কার্বন পরমাণু <b>${f[3]}</b>।<br>ব্যবহার: ${f[4]}।`;
    };
    draw();
  }
};

})();
