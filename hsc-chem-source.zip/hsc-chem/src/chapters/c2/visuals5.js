/* Visuals part 5 — distillation types & sublimation (2.16) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;
const f1 = v => (+v).toFixed(1);

/* ======================= সমস্ফুটন মিশ্রণ: ইথানল–পানি T–x–y লেখ ======================= */
const EW = [[0, 0, 100], [0.019, 0.17, 95.5], [0.0721, 0.3891, 89.0], [0.0966, 0.4375, 86.7], [0.1238, 0.4704, 85.3], [0.1661, 0.5089, 84.1], [0.2337, 0.5445, 82.7], [0.2608, 0.558, 82.3], [0.3273, 0.5826, 81.5], [0.3965, 0.6122, 80.7], [0.5079, 0.6564, 79.8], [0.5198, 0.6599, 79.7], [0.5732, 0.6841, 79.3], [0.6763, 0.7385, 78.74], [0.7472, 0.7815, 78.41], [0.8943, 0.8943, 78.15], [0.95, 0.942, 78.2], [1, 1, 78.3]];
const lin = (arr, xi, cx, cy, v) => { for (let i = 1; i < arr.length; i++) if (v <= arr[i][cx]) { const a = arr[i - 1], b = arr[i], t = (v - a[cx]) / ((b[cx] - a[cx]) || 1); return a[cy] + (b[cy] - a[cy]) * t; } return arr[arr.length - 1][cy]; };
const yOf = x => lin(EW, 0, 0, 1, x), TOf = x => lin(EW, 0, 0, 2, x), TdOf = y => lin(EW, 0, 1, 2, y);
const wE = x => 46.07 * x / (46.07 * x + 18.02 * (1 - x)) * 100;
V.azeoPlot = {
  t: 'সমস্ফুটন মিশ্রণ: ইথানল–পানির স্ফুটনাঙ্ক লেখ', k: ['2d', 'int'],
  cap: 'নিচের নীল রেখা তরলের স্ফুটনাঙ্ক (তরল রেখা), উপরের লাল রেখা ঐ তাপমাত্রায় তৈরি বাষ্পের সংযুতি (বাষ্প রেখা)। স্লাইডার দিয়ে তরলের সংযুতি বদলাও — অনুভূমিক রেখাটি দেখায় বাষ্পে ইথানল কত। ৮৯.৪ মোল% (৯৫.৬% ভর) বিন্দুতে দুই রেখা মিলেছে: এখানে বাষ্প ও তরলের সংযুতি একই, তাই পাতনে আর ঘন হয় না — এটিই সমস্ফুটন মিশ্রণ (স্ফুটনাঙ্ক ৭৮.১৫°C, বিশুদ্ধ ইথানলের ৭৮.৩°C এর চেয়েও কম)। "আংশিক পাতনের ধাপ" চাপলে দেখবে ধাপগুলো সমস্ফুটন বিন্দুতে গিয়ে থেমে যায়।',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none;min-width:92px">তরলে ইথানল</label><input type="range" min="0.02" max="0.99" step="0.01" value="0.10" data-x style="flex:1"><span class="mono" data-xv style="min-width:52px;text-align:right"></span></div><div class="ctl"><button class="btn sm" data-st>আংশিক পাতনের ধাপ দেখাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let steps = false;
    const X0 = 52, X1 = 384, Y0 = 210, Y1 = 18, tx = x => X0 + x * (X1 - X0), ty = T => Y0 - (T - 77) / (101 - 77) * (Y0 - Y1);
    const run = () => {
      const x = +el.querySelector('[data-x]').value, T = TOf(x), y = yOf(x);
      el.querySelector('[data-xv]').textContent = (x * 100).toFixed(0) + ' মোল%';
      let s = `<line x1="${X0}" y1="${Y0}" x2="${X1}" y2="${Y0}" class="s-ln"/><line x1="${X0}" y1="${Y0}" x2="${X0}" y2="${Y1}" class="s-ln"/>`;
      [78, 82, 86, 90, 94, 98].forEach(t => s += `<text x="${X0 - 5}" y="${f1(ty(t) + 4)}" text-anchor="end" class="tm mono" style="font-size:10px">${t}</text><line x1="${X0}" y1="${f1(ty(t))}" x2="${X1}" y2="${f1(ty(t))}" class="s-ln" opacity=".22"/>`);
      [0, 0.2, 0.4, 0.6, 0.8, 1].forEach(v => s += `<text x="${f1(tx(v))}" y="${Y0 + 14}" text-anchor="middle" class="tm mono" style="font-size:10px">${v}</text>`);
      s += `<text x="${X1}" y="${Y0 + 28}" text-anchor="end" class="tm" style="font-size:10px">ইথানলের মোল ভগ্নাংশ</text><text x="${X0 + 4}" y="${Y1 - 4}" class="tm" style="font-size:10px">তাপমাত্রা (°C)</text>`;
      let bub = '', dew = ''; for (let v = 0; v <= 1.0001; v += 0.005) { bub += (v ? 'L' : 'M') + f1(tx(v)) + ' ' + f1(ty(TOf(v))); dew += (v ? 'L' : 'M') + f1(tx(v)) + ' ' + f1(ty(TdOf(v))); }
      s += `<path d="${bub} L${X1} ${Y0} L${X0} ${Y0}Z" fill="rgba(59,130,246,.07)"/><path d="${dew} L${X1} ${Y1} L${X0} ${Y1}Z" fill="rgba(239,68,68,.06)"/>`;
      s += `<path d="${dew}" fill="none" stroke="#e5484d" stroke-width="2.2"/><path d="${bub}" fill="none" stroke="#3b82f6" stroke-width="2.2"/>`;
      s += `<text x="${f1(tx(0.3))}" y="${f1(ty(95))}" class="tm" style="font-size:11px">বাষ্প</text><text x="${f1(tx(0.62))}" y="${f1(ty(77.6))}" class="tm" style="font-size:11px">তরল</text><text x="${f1(tx(0.13))}" y="${f1(ty(88.3))}" style="font-size:10px;fill:#e5484d">বাষ্প রেখা</text><text x="${f1(tx(0.05))}" y="${f1(ty(84))}" style="font-size:10px;fill:#3b82f6">তরল রেখা</text>`;
      s += `<circle cx="${f1(tx(0.8943))}" cy="${f1(ty(78.15))}" r="5" fill="none" stroke="#111" stroke-width="1.5"/><text x="${f1(tx(0.8943) - 6)}" y="${f1(ty(78.15) - 30)}" text-anchor="end" style="font-size:10px;font-weight:600">সমস্ফুটন বিন্দু</text><text x="${f1(tx(0.8943) - 6)}" y="${f1(ty(78.15) - 18)}" text-anchor="end" class="tm" style="font-size:9.5px">৯৫.৬% (ভর), ৭৮.১৫°C</text><line x1="${f1(tx(0.8943) - 4)}" y1="${f1(ty(78.15) - 14)}" x2="${f1(tx(0.8943))}" y2="${f1(ty(78.15) - 5)}" class="s-mu"/>`;
      if (steps) {
        let p = `M${f1(tx(x))} ${f1(ty(T))}`, cx = x, n = 0;
        while (n < 14) { const yy = yOf(cx), tt = TOf(cx); p += ` L${f1(tx(yy))} ${f1(ty(tt))} L${f1(tx(yy))} ${f1(ty(TOf(yy)))}`; n++; if (Math.abs(yy - cx) < 0.004) break; cx = yy; }
        s += `<path d="${p}" fill="none" stroke="#16a34a" stroke-width="1.8"/>`;
        steps = { n, end: cx };
      }
      s += `<line x1="${f1(tx(x))}" y1="${f1(ty(T))}" x2="${f1(tx(y))}" y2="${f1(ty(T))}" class="s-fg" stroke-width="1.6" stroke-dasharray="4 3"/><circle cx="${f1(tx(x))}" cy="${f1(ty(T))}" r="5" fill="#3b82f6" stroke="#fff" stroke-width="1.5"/><circle cx="${f1(tx(y))}" cy="${f1(ty(T))}" r="5" fill="#e5484d" stroke="#fff" stroke-width="1.5"/>`;
      box.innerHTML = X.svg(400, 244, s, 'ইথানল–পানি স্ফুটনাঙ্ক লেখ');
      const richer = y > x + 0.003, same = Math.abs(y - x) <= 0.003;
      out.innerHTML = `তরল: ইথানল <b>${(x * 100).toFixed(0)} মোল%</b> (${wE(x).toFixed(1)}% ভর) — স্ফুটনাঙ্ক <b>${T.toFixed(1)}°C</b>।<br>বাষ্প: ইথানল <b>${(y * 100).toFixed(1)} মোল%</b> (${wE(y).toFixed(1)}% ভর) → ${same ? 'তরল ও বাষ্পের সংযুতি সমান — <b>সমস্ফুটন মিশ্রণ</b>, পাতনে আর পৃথক হয় না।' : richer ? 'বাষ্পে ইথানল বেশি, তাই পাতনে ইথানল ঘন হয়।' : 'সমস্ফুটন বিন্দুর ডানে বাষ্পে ইথানল তরলের চেয়ে <b>কম</b> — পাতনে বরং পানি বেশি বেরিয়ে যায় এবং পাত্রে বিশুদ্ধ ইথানল থাকে।'}` + (steps ? `<br><span style="color:#16a34a">আংশিক পাতনে ${X.bn(steps.n)}টি ধাপে সর্বোচ্চ ≈ ${(steps.end * 100).toFixed(1)} মোল% (${wE(steps.end).toFixed(1)}% ভর) পর্যন্ত পৌঁছানো যায় — সমস্ফুটন বিন্দু পার হওয়া যায় না।</span>` : '');
    };
    el.querySelector('[data-x]').addEventListener('input', () => { if (steps) steps = true; run(); });
    el.querySelector('[data-st]').onclick = () => { steps = steps ? false : true; el.querySelector('[data-st]').textContent = steps ? 'ধাপ লুকাও' : 'আংশিক পাতনের ধাপ দেখাও'; run(); };
    run();
  }
};

/* ======================= বাষ্প পাতন ======================= */
const SDP = { an: ['অ্যানিলিন', 98.4, 43, 93.13, 1.02], nb: ['নাইট্রোবেনজিন', 99.3, 20, 123.11, 1.20], bb: ['ব্রোমোবেনজিন', 95.3, 120, 157.01, 1.50] };
V.steamDist = {
  t: 'বাষ্প পাতন: যন্ত্রসজ্জা ও পরিস্রুতের হিসাব', k: ['anim', 'calc'],
  cap: 'বাষ্প উৎপাদক থেকে বাষ্প মিশ্রণের ভেতর দিয়ে পাঠানো হয়। পানিতে অমিশ্রণীয় দুটি তরলের মোট বাষ্পচাপ = দুটির আলাদা বাষ্পচাপের যোগফল (p = p<sub>পানি</sub> + p<sub>জৈব</sub>)। এই যোগফল ৭৬০ mmHg হলেই মিশ্রণ ফোটে — তাই ১০০°C এর নিচে, জৈব যৌগের স্ফুটনাঙ্কের অনেক নিচে পাতন ঘটে। গ্রাহক পাত্রে দুটি অমিশ্রণীয় স্তর জমে। নিরাপত্তা নল বাষ্প উৎপাদকের অতিরিক্ত চাপ বের করে দেয়।',
  html: () => `<div data-svg></div><div class="ctl"><button class="btn sm" data-go>চালাও</button><button class="btn sm" data-rs>নতুন করে</button></div><div class="grid3" style="margin-top:8px"><label class="stack" style="gap:4px"><span class="small muted">জৈব যৌগ</span><select class="inp" data-c>${Object.keys(SDP).map(k => `<option value="${k}">${SDP[k][0]}</option>`).join('')}</select></label>${X.fld('p<sub>জৈব</sub> (mmHg)', 'data-p', 43)}${X.fld('মোলার ভর', 'data-m', 93.13)}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    let run = false, recv = 0, G = null, oil = 0.2, rho = 1.02;
    const calc = () => {
      const k = q('[data-c]').value, po = Math.min(700, Math.max(1, +q('[data-p]').value || 1)), M = Math.max(1, +q('[data-m]').value || 1), pw = 760 - po;
      const r = po * M / (pw * 18.02), pc = r / (1 + r) * 100; rho = SDP[k][4];
      const vr = (r / rho) / (r / rho + 1); oil = vr;
      out.innerHTML = `p<sub>পানি</sub> = 760 − ${po} = <b>${pw} mmHg</b>${po === SDP[k][2] ? ` (মিশ্রণ ফোটে প্রায় <b>${SDP[k][1]}°C</b> এ — ১০০°C এর নিচে)` : ''}<br>m<sub>জৈব</sub>/m<sub>পানি</sub> = (p<sub>জৈব</sub> × M<sub>জৈব</sub>)/(p<sub>পানি</sub> × 18.02) = (${po} × ${M})/(${pw} × 18.02) = <b>${r.toFixed(3)}</b><br>পরিস্রুতে ${SDP[k][0]} এর ভর ≈ <b>${pc.toFixed(1)}%</b>। বাষ্পচাপ কম হলেও বড় মোলার ভরের কারণে উল্লেখযোগ্য পরিমাণ জৈব যৌগ পাতিত হয়। ঘনত্ব ${rho} g/mL — ${rho > 1 ? 'জৈব স্তর নিচে' : 'জৈব স্তর উপরে'}।`;
    };
    const full = () => {
      const steam = `<path d="M44 150 L44 84 L112 84 L112 214" fill="none" class="s-fg" stroke-width="3.5" stroke-linejoin="round"/>` + (run ? `<path d="M44 150 L44 84 L112 84 L112 214" fill="none" stroke="#fff" stroke-width="1.6" class="anim-flow"/>` : '');
      G = X.rig({ id: 'stR', cx: 118, r: 30, cy: 192, sy: 112, L: 196, run, flame: run, liq: '#e7dcc2', dist: '#cfe9ff', layers: true, oil, oilC: '#c49a3c', recv, lab: true, thLab: false, flaskLab: 'মিশ্রণ', recvLab: 'দুই স্তর: পানি + জৈব', T: run ? (SDP[q('[data-c]').value][1] + '°C') : '25°C', extra: steam });
      let g = `<defs><clipPath id="stG"><circle cx="40" cy="196" r="22.5"/></clipPath></defs>` + X.tripod(40, 220, run, 22);
      g += `<rect x="16" y="198" width="48" height="26" fill="#bfe0f7" opacity=".8" clip-path="url(#stG)"/><path d="M34 150 L34 175 A24 24 0 1 0 46 175 L46 150" fill="none" class="s-fg" stroke-width="2"/><rect x="31" y="145" width="18" height="7" rx="2" class="f-mu"/>`;
      g += `<line x1="37" y1="124" x2="37" y2="214" class="s-fg" stroke-width="2"/><path d="M31 118 L43 118 L38 125 L36 125Z" class="s-fg" fill="none" stroke-width="1.5"/>`;
      if (run) for (let i = 0; i < 4; i++) g += `<circle class="anim-bub" cx="${30 + i * 7}" cy="214" r="1.8" fill="#fff" stroke="#7fa7c9" stroke-width=".6" style="animation-delay:${i * 0.4}s"/>`;
      g += `<text x="4" y="74" class="tm" style="font-size:9.5px">নিরাপত্তা নল</text><line x1="22" y1="78" x2="35" y2="116" class="s-mu" stroke-width=".8"/><text x="40" y="276" text-anchor="middle" class="tm" style="font-size:9.5px">বাষ্প উৎপাদক</text><text x="58" y="98" class="tm" style="font-size:9.5px">বাষ্প →</text>`;
      box.innerHTML = X.svg(400, G.H + 12, g + G.svg, 'বাষ্প পাতন');
    };
    const dyn = () => { if (!G) return; const hh = G.hmax * Math.min(1, recv); const a = box.querySelector('[data-rl]'), b = box.querySelector('[data-rl2]'); if (a) { a.setAttribute('y', f1(G.rBase - hh)); a.setAttribute('height', f1(hh)); } if (b) { b.setAttribute('y', f1(G.rBase - hh * oil)); b.setAttribute('height', f1(hh * oil)); } };
    const A = X.anim(box, dt => { if (run && recv < 1) { recv = Math.min(1, recv + dt * 0.06); dyn(); if (recv >= 1) { run = false; full(); q('[data-go]').textContent = 'চালাও'; } } });
    q('[data-go]').onclick = () => { if (recv >= 1) recv = 0; run = !run; q('[data-go]').textContent = run ? 'থামাও' : 'চালাও'; full(); if (A.paused) A.pause(false); A.draw(); };
    q('[data-rs]').onclick = () => { run = false; recv = 0; q('[data-go]').textContent = 'চালাও'; full(); };
    q('[data-c]').onchange = () => { const d = SDP[q('[data-c]').value]; q('[data-p]').value = d[2]; q('[data-m]').value = d[3]; calc(); full(); };
    ['[data-p]', '[data-m]'].forEach(s => q(s).addEventListener('input', () => { calc(); dyn(); }));
    calc(); full();
    return () => A.stop();
  }
};

/* ======================= নিম্নচাপ পাতন: চাপ বনাম স্ফুটনাঙ্ক ======================= */
const VB = [['পানি', 40.7, 373.15, '#3b82f6'], ['ইথানল', 38.6, 351.4, '#16a34a'], ['অ্যানিলিন', 42.4, 457.3, '#a855f7'], ['গ্লিসারিন', 70, 563.2, '#e5484d']];
const bpAt = (dH, Tb, P) => 1 / (1 / Tb - 8.314 / (dH * 1000) * Math.log(P / 760)) - 273.15;
V.vacBp = {
  t: 'নিম্নচাপ পাতন: চাপ কমালে স্ফুটনাঙ্ক কমে', k: ['int', 'calc'],
  cap: 'তরল তখনই ফোটে যখন তার বাষ্পচাপ বাইরের চাপের সমান হয়। পাম্প দিয়ে বাইরের চাপ কমালে কম তাপমাত্রাতেই বাষ্পচাপ সমান হয় — স্ফুটনাঙ্ক কমে। গ্লিসারিনের মতো যেসব যৌগ স্বাভাবিক স্ফুটনাঙ্কে বিয়োজিত হয়, সেগুলো এভাবে নিরাপদে পাতন করা যায়। (ক্লসিয়াস–ক্ল্যাপেরন সমীকরণ দিয়ে আসন্ন মান।)',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none">চাপ</label><input type="range" min="0.7" max="3.18" step="any" value="2.8808" data-p style="flex:1"><span class="mono" data-pv style="min-width:86px;text-align:right"></span></div><div class="ctl">${[['10', 'ভ্যাকুয়াম ১০ mmHg'], ['253', 'এভারেস্ট চূড়া'], ['760', '১ atm'], ['1520', 'প্রেশার কুকার']].map(([v, n]) => `<button class="btn sm" data-ps="${v}">${n}</button>`).join('')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sl = el.querySelector('[data-p]');
    const X0 = 50, X1 = 384, Y0 = 206, Y1 = 18, lx = v => X0 + (v - 0.7) / (3.18 - 0.7) * (X1 - X0), ty = T => Y0 - T / 320 * (Y0 - Y1);
    const run = () => {
      const v = +sl.value, P = Math.pow(10, v);
      el.querySelector('[data-pv]').textContent = (P < 100 ? P.toFixed(1) : P.toFixed(0)) + ' mmHg';
      let s = `<rect x="${X0}" y="${f1(ty(320))}" width="${X1 - X0}" height="${f1(ty(280) - ty(320))}" fill="rgba(229,72,77,.10)"/><text x="${X0 + 6}" y="${f1(ty(300) + 4)}" style="font-size:9.5px;fill:#e5484d">গ্লিসারিনের বিয়োজন অঞ্চল (≈২৮০°C এর উপরে)</text>`;
      s += `<line x1="${X0}" y1="${Y0}" x2="${X1}" y2="${Y0}" class="s-ln"/><line x1="${X0}" y1="${Y0}" x2="${X0}" y2="${Y1}" class="s-ln"/>`;
      [0, 50, 100, 150, 200, 250, 300].forEach(t => s += `<text x="${X0 - 5}" y="${f1(ty(t) + 4)}" text-anchor="end" class="tm mono" style="font-size:10px">${t}</text><line x1="${X0}" y1="${f1(ty(t))}" x2="${X1}" y2="${f1(ty(t))}" class="s-ln" opacity=".22"/>`);
      [10, 50, 100, 250, 760, 1520].forEach(p => s += `<text x="${f1(lx(Math.log10(p)))}" y="${Y0 + 14}" text-anchor="middle" class="tm mono" style="font-size:9.5px">${p}</text>`);
      s += `<text x="${X1}" y="${Y0 + 28}" text-anchor="end" class="tm" style="font-size:10px">বাইরের চাপ (mmHg, লগ স্কেল)</text><text x="${X0 + 4}" y="${Y1 - 4}" class="tm" style="font-size:10px">স্ফুটনাঙ্ক (°C)</text>`;
      s += `<defs><clipPath id="vbC"><rect x="${X0}" y="${Y1}" width="${X1 - X0}" height="${Y0 - Y1}"/></clipPath></defs>`;
      VB.forEach(([n, dH, Tb, c], i) => { let d = ''; for (let u = 0.7; u <= 3.1801; u += 0.02) d += (u === 0.7 ? 'M' : 'L') + f1(lx(u)) + ' ' + f1(ty(bpAt(dH, Tb, Math.pow(10, u)))); const lu = 2.25, ly = ty(bpAt(dH, Tb, Math.pow(10, lu))) + (i === 1 ? 14 : -6); s += `<path d="${d}" fill="none" stroke="${c}" stroke-width="2.2" clip-path="url(#vbC)"/><text x="${f1(lx(lu))}" y="${f1(ly)}" text-anchor="middle" style="font-size:10px;fill:${c};font-weight:600">${n}</text>`; });
      s += `<line x1="${f1(lx(v))}" y1="${Y0}" x2="${f1(lx(v))}" y2="${Y1}" class="s-fg" stroke-dasharray="4 3"/>`;
      VB.forEach(([n, dH, Tb, c]) => { if (bpAt(dH, Tb, P) >= 0) s += `<circle cx="${f1(lx(v))}" cy="${f1(ty(bpAt(dH, Tb, P)))}" r="4.5" fill="${c}" stroke="#fff" stroke-width="1.4"/>`; });
      box.innerHTML = X.svg(400, 240, s, 'চাপ বনাম স্ফুটনাঙ্ক');
      const rows = VB.map(([n, dH, Tb]) => `${n} <b>${bpAt(dH, Tb, P).toFixed(0)}°C</b>`).join(' · ');
      const g = bpAt(70, 563.2, P);
      out.innerHTML = `${P.toFixed(P < 100 ? 1 : 0)} mmHg চাপে স্ফুটনাঙ্ক: ${rows}<br>${g > 280 ? 'এই চাপে গ্লিসারিন ফোটার আগেই বিয়োজিত হবে — চাপ আরও কমাতে হবে।' : P < 700 ? 'গ্লিসারিন বিয়োজন তাপমাত্রার অনেক নিচে ফুটবে — নিরাপদে পাতন সম্ভব।' : ''} ${P > 800 ? 'চাপ বাড়ালে স্ফুটনাঙ্ক বাড়ে — প্রেশার কুকারে পানি ~১২০°C এ ফোটে, তাই রান্না দ্রুত হয়।' : P < 300 && P > 200 ? 'পাহাড়ের চূড়ায় বায়ুচাপ কম — পানি ~৭০°C এ ফোটে, তাই ডিম সেদ্ধ হতে দেরি হয়।' : ''}`;
    };
    sl.addEventListener('input', run);
    el.querySelectorAll('[data-ps]').forEach(b => b.onclick = () => { sl.value = Math.log10(+b.dataset.ps).toFixed(4); run(); });
    run();
  }
};

/* ======================= ঊর্ধ্বপাতন ======================= */
const SUB = {
  nh: { n: 'NaCl + NH₄Cl', vc: '#d9dde3', dc: '#ffffff', ds: '#9aa6b2', nv: ['#ffffff', 'NaCl'], vo: ['#e6e9ee', 'NH₄Cl'], txt: 'উত্তাপে NH₄Cl(s) ⇌ NH₃(g) + HCl(g) — গরম অংশে বিয়োজিত হয়ে ঠান্ডা ফানেলের গায়ে আবার যুক্ত হয়ে সাদা NH₄Cl কঠিন হিসেবে জমে (প্রকৃতপক্ষে বিয়োজন-পুনঃসংযোজন, তবে পৃথকীকরণ ঊর্ধ্বপাতনের মতোই)। NaCl অনুদ্বায়ী — পাত্রে থাকে।', end: 'ফানেলের গায়ে সাদা NH₄Cl জমেছে, চীনামাটির পাত্রে শুধু NaCl রয়ে গেছে।' },
  io: { n: 'বালি + আয়োডিন', vc: '#8e44ad', dc: '#3a2450', ds: '#6c4a8a', nv: ['#c9ad7d', 'বালি'], vo: ['#4a2c63', 'I₂'], txt: 'আয়োডিন উত্তাপে বেগুনি বাষ্পে পরিণত হয় এবং ঠান্ডা ফানেলের গায়ে সরাসরি ধূসর-কালো চকচকে কেলাস হিসেবে জমে। বালি থেকে যায়। (আয়োডিনের ত্রৈধ বিন্দুর চাপ ৯০ mmHg; ধীরে তাপ দিলে গলার আগেই বাষ্প হয়।)', end: 'ফানেলের গায়ে আয়োডিনের চকচকে কেলাস, পাত্রে শুধু বালি।' },
  na: { n: 'ন্যাপথালিন + লবণ', vc: '#e9edf2', dc: '#fbfbfb', ds: '#a9b4bf', nv: ['#ffffff', 'NaCl'], vo: ['#f2f2f2', 'ন্যাপথালিন'], txt: 'ন্যাপথালিন (ও কর্পূর) উচ্চ বাষ্পচাপের কঠিন — উত্তাপে সরাসরি বাষ্প হয়ে ঠান্ডা অংশে পাতের মতো সাদা কেলাস হিসেবে জমে। এজন্যই ন্যাপথালিনের বল আলমারিতে ধীরে ধীরে ছোট হয়ে যায়।', end: 'ফানেলের গায়ে সাদা ন্যাপথালিন কেলাস, পাত্রে লবণ।' }
};
V.sublim = {
  t: 'ঊর্ধ্বপাতন: চীনামাটির পাত্র ও উল্টানো ফানেল', k: ['anim', 'int'],
  cap: 'কঠিন পদার্থ তরলে পরিণত না হয়ে সরাসরি বাষ্পে এবং বাষ্প সরাসরি কঠিনে পরিণত হলে তাকে ঊর্ধ্বপাতন বলে। মিশ্রণ চীনামাটির পাত্রে নিয়ে ছিদ্রযুক্ত ফিল্টার কাগজে ঢেকে তার উপর উল্টানো ফানেল বসানো হয়; ফানেলের নলের মুখে তুলা গোঁজা থাকে যাতে বাষ্প বেরিয়ে না যায়। ফানেলের গা ঠান্ডা রাখতে ভেজা কাপড় জড়ানো হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('sm', Object.keys(SUB).map(k => [k, SUB[k].n]), 'nh')}</div><div data-svg></div><div class="ctl"><button class="btn sm" data-go>তাপ দাও</button><button class="btn sm" data-rs>নতুন করে</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const xl = y => 140 + (175 - y) * (54 / 90), xr = y => 260 - (175 - y) * (54 / 90), MAXD = 150;
    let m = 'nh', heat = false, P = [], D = 0, acc = 0, rnd = X.rng(31), gP, gD, gM;
    const mixHTML = () => { const S = SUB[m], left = 1 - D / MAXD; const r = X.rng(5); let s = ''; for (let i = 0; i < 22; i++) s += `<rect x="${f1(150 + r() * 98)}" y="${f1(180 + r() * 9)}" width="4" height="4" fill="${S.nv[0]}" stroke="#9aa" stroke-width=".5"/>`; const nv = Math.round(26 * left); for (let i = 0; i < nv; i++) s += `<circle cx="${f1(150 + r() * 98)}" cy="${f1(179 + r() * 9)}" r="2.1" fill="${S.vo[0]}" stroke="${S.ds}" stroke-width=".5"/>`; return s; };
    const full = () => {
      const S = SUB[m];
      let s = X.tripod(200, 200, heat, 52);
      s += `<path d="M128 176 Q200 222 272 176Z" class="f-s2 s-fg" stroke-width="2"/><g data-m>${mixHTML()}</g><line x1="142" y1="174" x2="258" y2="174" class="s-mu" stroke-width="2" stroke-dasharray="7 3"/>`;
      s += `<path d="M140 175 L194 85 L194 46 L206 46 L206 85 L260 175" fill="rgba(200,220,235,.18)" class="s-fg" stroke-width="2" stroke-linejoin="round"/><ellipse cx="200" cy="44" rx="9" ry="6" fill="#f3f3f3" stroke="#bbb"/>`;
      s += `<g data-d></g><g data-p></g>`;
      s += `<text x="216" y="40" class="tm" style="font-size:10px">তুলা</text><text x="268" y="120" class="tm" style="font-size:10px">উল্টানো ফানেল</text><text x="268" y="134" class="tm" style="font-size:9.5px">(গায়ে ${S.vo[1]} জমে)</text><text x="276" y="182" class="tm" style="font-size:10px">ছিদ্রযুক্ত কাগজ</text><text x="86" y="200" text-anchor="end" class="tm" style="font-size:10px">চীনামাটির পাত্র</text>`;
      box.innerHTML = X.svg(400, 246, s, 'ঊর্ধ্বপাতন');
      gP = box.querySelector('[data-p]'); gD = box.querySelector('[data-d]'); gM = box.querySelector('[data-m]');
      depR = X.rng(77); let d = ''; for (let i = 0; i < D; i++) d += dep(depR);
      gD.innerHTML = d;
    };
    const dep = r => { const S = SUB[m], y = 92 + r() * 80, side = r() < 0.5; const x = side ? xl(y) + 2.5 + r() * 2 : xr(y) - 2.5 - r() * 2; return `<rect x="${f1(x - 2)}" y="${f1(y - 1.5)}" width="${f1(3 + r() * 2)}" height="${f1(2.2 + r() * 1.5)}" fill="${S.dc}" stroke="${S.ds}" stroke-width=".6" transform="rotate(${f1((side ? -31 : 31) + (r() - 0.5) * 30)} ${f1(x)} ${f1(y)})"/>`; };
    const msg = () => { const S = SUB[m]; out.innerHTML = D >= MAXD ? `<b style="font-family:var(--font-body)">সম্পন্ন:</b> ${S.end}` : S.txt; };
    let depR = X.rng(77);
    const A = X.anim(box, dt => {
      if (!gP) return;
      if (heat && D < MAXD) { acc += dt * 14; while (acc > 1) { acc--; P.push({ x: 158 + rnd() * 84, y: 172, vx: (rnd() - 0.5) * 30, vy: -30 - rnd() * 18 }); } }
      const S = SUB[m]; let add = '';
      P = P.filter(p => { p.x += p.vx * dt; p.y += p.vy * dt; if (p.y < 176 && (p.x <= xl(p.y) + 3 || p.x >= xr(p.y) - 3 || p.y < 92)) { if (D < MAXD) { D++; add += dep(depR); } return false; } return true; });
      if (add) { gD.insertAdjacentHTML('beforeend', add); if (D % 8 === 0) gM.innerHTML = mixHTML(); if (D >= MAXD) { heat = false; full(); msg(); el.querySelector('[data-go]').textContent = 'তাপ দাও'; } }
      gP.innerHTML = P.map(p => `<circle cx="${f1(p.x)}" cy="${f1(p.y)}" r="2.4" fill="${S.vc}" opacity=".75"/>`).join('');
    });
    const reset = () => { heat = false; P = []; D = 0; acc = 0; full(); msg(); el.querySelector('[data-go]').textContent = 'তাপ দাও'; };
    el.querySelector('[data-go]').onclick = () => { if (D >= MAXD) reset(); heat = !heat; el.querySelector('[data-go]').textContent = heat ? 'তাপ বন্ধ' : 'তাপ দাও'; full(); if (A.paused) A.pause(false); A.draw(); };
    el.querySelector('[data-rs]').onclick = reset;
    X.onSeg(el, 'sm', k => { m = k; reset(); });
    reset();
    return () => A.stop();
  }
};

/* ======================= CO₂ এর দশা চিত্র ======================= */
const TK = t => t + 273.15;
const Psub = T => Math.exp(-3140 * (1 / TK(T) - 1 / 194.65)), Pvap = T => 5.11 * Math.exp(-1998 * (1 / TK(T) - 1 / 216.55)), Tm = P => -56.6 + (P - 5.11) * 0.0221;
const Tsub = P => 1 / (1 / 194.65 - Math.log(P) / 3140) - 273.15, Tboil = P => 1 / (1 / 216.55 - Math.log(P / 5.11) / 1998) - 273.15;
V.phaseCO2 = {
  t: 'দশা চিত্র: কেন শুষ্ক বরফ গলে না, সরাসরি বাষ্প হয়', k: ['2d', 'int'],
  cap: 'দশা চিত্রে চাপ ও তাপমাত্রার প্রতিটি জোড়ায় পদার্থটি কোন অবস্থায় থাকে তা দেখানো হয়। ত্রৈধ বিন্দুতে কঠিন, তরল ও বাষ্প একসাথে সাম্যে থাকে। CO₂ এর ত্রৈধ বিন্দুর চাপ ৫.১১ atm — বায়ুমণ্ডলীয় চাপের (১ atm) চেয়ে বেশি। তাই ১ atm চাপে কঠিন CO₂ (শুষ্ক বরফ) গরম করলে তরল অবস্থা পাওয়াই যায় না; −৭৮.৫°C এ সরাসরি বাষ্প হয় — ঊর্ধ্বপাতন। পানির ত্রৈধ বিন্দুর চাপ মাত্র ০.০০৬ atm, তাই বরফ স্বাভাবিক চাপে গলে। (লগ স্কেল; বক্ররেখাগুলো আসন্ন।)',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none;min-width:70px">তাপমাত্রা</label><input type="range" min="-100" max="50" step="0.5" value="-78.5" data-t style="flex:1"><span class="mono" data-tv style="min-width:62px;text-align:right"></span></div><div class="ctl"><label style="flex:none;min-width:70px">চাপ</label><input type="range" min="-1" max="2" step="0.01" value="0" data-p style="flex:1"><span class="mono" data-pv style="min-width:62px;text-align:right"></span></div><div class="ctl">${[['-78.5,1', 'শুষ্ক বরফ (১ atm)'], ['-56.6,5.11', 'ত্রৈধ বিন্দু'], ['25,64', 'CO₂ সিলিন্ডার'], ['40,90', 'অতিক্রান্তিক']].map(([v, n]) => `<button class="btn sm" data-ps="${v}">${n}</button>`).join('')}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sT = el.querySelector('[data-t]'), sP = el.querySelector('[data-p]');
    const X0 = 54, X1 = 384, Y0 = 214, Y1 = 16, tx = T => X0 + (T + 100) / 150 * (X1 - X0), ty = P => Y0 - (Math.log10(P) + 1) / 3 * (Y0 - Y1);
    const pt = (T, P) => f1(tx(T)) + ' ' + f1(ty(P));
    const state = (T, P) => { if (T > 31 && P > 72.8) return ['অতিক্রান্তিক প্রবাহী', '#a855f7']; if (T <= -56.6) return P < Psub(T) ? ['বাষ্প (গ্যাস)', '#d4a017'] : ['কঠিন (শুষ্ক বরফ)', '#64748b']; if (P >= 5.11 && T < Tm(P)) return ['কঠিন (শুষ্ক বরফ)', '#64748b']; if (T <= 31) return P > Pvap(T) ? ['তরল', '#3b82f6'] : ['বাষ্প (গ্যাস)', '#d4a017']; return ['বাষ্প (গ্যাস)', '#d4a017']; };
    let base = '';
    { let sub = '', vap = ''; for (let T = -100; T <= -56.6; T += 1) sub += (T === -100 ? '' : ' L') + pt(T, Psub(T)); sub += ' L' + pt(-56.6, 5.11); for (let T = -56.6; T <= 31.0001; T += 1) vap += ' L' + pt(Math.min(T, 31), Pvap(Math.min(T, 31))); vap += ' L' + pt(31, 72.8);
      const melt = `${pt(-56.6, 5.11)} L${pt(Tm(100), 100)}`;
      base += `<path d="M${pt(-100, 100)} L${pt(-100, Psub(-100))} L${sub} L${pt(Tm(100), 100)}Z" fill="rgba(100,116,139,.16)"/>`;
      base += `<path d="M${pt(-56.6, 5.11)} L${pt(Tm(100), 100)} L${pt(31, 100)} L${pt(31, 72.8)} ${vap.split(' L').slice(1).reverse().map(s => 'L' + s).join(' ')}Z" fill="rgba(59,130,246,.13)"/>`;
      base += `<path d="M${pt(-100, 0.1)} L${pt(-100, Psub(-100))} L${sub}${vap} L${pt(50, 72.8)} L${pt(50, 0.1)}Z" fill="rgba(212,160,23,.11)"/>`;
      base += `<path d="M${pt(31, 72.8)} L${pt(31, 100)} L${pt(50, 100)} L${pt(50, 72.8)}Z" fill="rgba(168,85,247,.12)"/>`;
      base += `<path d="M${pt(-100, Psub(-100))} L${sub}" fill="none" class="s-fg" stroke-width="2"/><path d="M${pt(-56.6, 5.11)}${vap}" fill="none" class="s-fg" stroke-width="2"/><path d="M${melt}" fill="none" class="s-fg" stroke-width="2"/><path d="M${pt(31, 72.8)} L${pt(31, 100)} M${pt(31, 72.8)} L${pt(50, 72.8)}" class="s-mu" stroke-dasharray="3 3" fill="none"/>`;
    }
    base += `<line x1="${X0}" y1="${Y0}" x2="${X1}" y2="${Y0}" class="s-ln"/><line x1="${X0}" y1="${Y0}" x2="${X0}" y2="${Y1}" class="s-ln"/>`;
    [0.1, 1, 10, 100].forEach(p => base += `<text x="${X0 - 5}" y="${f1(ty(p) + 4)}" text-anchor="end" class="tm mono" style="font-size:10px">${p}</text>`);
    [-100, -75, -50, -25, 0, 25, 50].forEach(t => base += `<text x="${f1(tx(t))}" y="${Y0 + 14}" text-anchor="middle" class="tm mono" style="font-size:10px">${t}</text>`);
    base += `<line x1="${X0}" y1="${f1(ty(1))}" x2="${X1}" y2="${f1(ty(1))}" stroke="#e5484d" stroke-dasharray="5 4" opacity=".8"/><text x="${X1 - 2}" y="${f1(ty(1) - 4)}" text-anchor="end" style="font-size:9.5px;fill:#e5484d">১ atm</text>`;
    base += `<text x="${X1}" y="${Y0 + 28}" text-anchor="end" class="tm" style="font-size:10px">তাপমাত্রা (°C)</text><text x="${X0 + 4}" y="${Y1 - 2}" class="tm" style="font-size:10px">চাপ (atm)</text>`;
    base += `<text x="${f1(tx(-92))}" y="${f1(ty(30))}" style="font-size:11px;font-weight:600;fill:#475569">কঠিন</text><text x="${f1(tx(-40))}" y="${f1(ty(22))}" style="font-size:11px;font-weight:600;fill:#2563eb">তরল</text><text x="${f1(tx(-10))}" y="${f1(ty(0.4))}" style="font-size:11px;font-weight:600;fill:#a16207">বাষ্প</text>`;
    base += `<circle cx="${f1(tx(-56.6))}" cy="${f1(ty(5.11))}" r="4" class="f-fg"/><text x="${f1(tx(-56.6) + 6)}" y="${f1(ty(5.11) + 13)}" style="font-size:9.5px">ত্রৈধ বিন্দু (−৫৬.৬°C, ৫.১১ atm)</text><circle cx="${f1(tx(31))}" cy="${f1(ty(72.8))}" r="4" class="f-fg"/><text x="${f1(tx(31) - 6)}" y="${f1(ty(72.8) + 14)}" text-anchor="end" style="font-size:9.5px">ক্রান্তি বিন্দু (৩১°C, ৭২.৮ atm)</text>`;
    base += `<circle cx="${f1(tx(-78.5))}" cy="${f1(ty(1))}" r="3.5" fill="#e5484d"/>`;
    const run = () => {
      const T = +sT.value, P = Math.pow(10, +sP.value);
      el.querySelector('[data-tv]').textContent = T.toFixed(1) + '°C'; el.querySelector('[data-pv]').textContent = (P < 10 ? P.toFixed(2) : P.toFixed(1)) + ' atm';
      const [st, c] = state(T, P);
      box.innerHTML = X.svg(400, 246, base + `<line x1="${X0}" y1="${f1(ty(P))}" x2="${X1}" y2="${f1(ty(P))}" class="s-acc" stroke-width="1.2" opacity=".55"/><circle cx="${f1(tx(T))}" cy="${f1(ty(P))}" r="6.5" fill="${c}" stroke="#fff" stroke-width="2"/>`, 'CO₂ দশা চিত্র');
      let h;
      if (P < 5.11) h = `এই চাপে কঠিন CO₂ গরম করলে <b>সরাসরি বাষ্প</b> হবে (ঊর্ধ্বপাতন) প্রায় <b>${Tsub(P).toFixed(1)}°C</b> এ — তরল অবস্থা আসবে না।`;
      else if (P < 72.8) h = `এই চাপে কঠিন CO₂ গরম করলে প্রায় <b>${Tm(P).toFixed(1)}°C</b> এ গলে তরল হবে, তারপর <b>${Tboil(P).toFixed(1)}°C</b> এ ফুটবে।`;
      else h = 'এই চাপে গরম করলে গলে তরল হবে; ৩১°C পেরোলে তরল ও বাষ্পের পার্থক্য মুছে গিয়ে <b>অতিক্রান্তিক প্রবাহী</b> হবে (কফি থেকে ক্যাফেইন নিষ্কাশনে ব্যবহৃত)।';
      out.innerHTML = `${T.toFixed(1)}°C ও ${(P < 10 ? P.toFixed(2) : P.toFixed(1))} atm এ CO₂: <b style="color:${c}">${st}</b><br>${h}`;
    };
    [sT, sP].forEach(s => s.addEventListener('input', run));
    el.querySelectorAll('[data-ps]').forEach(b => b.onclick = () => { const [t, p] = b.dataset.ps.split(',').map(Number); sT.value = t; sP.value = Math.log10(p).toFixed(2); run(); });
    run();
  }
};

})();
