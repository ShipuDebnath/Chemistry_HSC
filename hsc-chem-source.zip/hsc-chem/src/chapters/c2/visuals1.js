/* Chapter 2 · Visuals part 1 — atomic structure (2.1–2.4) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;

/* ======================= 2.1 ======================= */
V.modelTimeline = {
  t: 'পরমাণু মডেলের ক্রমবিকাশ', k: ['info'],
  cap: 'প্রতিটি মডেল আগের মডেলের সীমাবদ্ধতা দূর করতে এসেছে। পরীক্ষায় "কোন মডেলের কোন সীমাবদ্ধতা পরের মডেল দূর করেছে" — এই সম্পর্কটি প্রায়ই জিজ্ঞাসা করা হয়।',
  html() {
    const rows = [
      ['১৮০৩', 'ডাল্টন', 'নিরেট গোলক মডেল', 'পরমাণু অবিভাজ্য, কঠিন গোলক', `<circle cx="22" cy="22" r="15" class="f-mu"/>`],
      ['১৯০৪', 'জে. জে. থমসন', 'কিশমিশ-পুডিং মডেল', 'ধনাত্মক গোলকে ইলেকট্রন গাঁথা', `<circle cx="22" cy="22" r="16" class="f-a2s s-a2" stroke-width="1.5"/>${[[16, 15], [27, 13], [14, 27], [26, 28], [21, 21], [30, 22]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="2.4" class="f-acc"/>`).join('')}`],
      ['১৯১১', 'রাদারফোর্ড', 'নিউক্লিয়াস / সৌরজগৎ মডেল', 'ক্ষুদ্র ভারী ধনাত্মক নিউক্লিয়াস, চারপাশে ঘূর্ণায়মান ইলেকট্রন', `<ellipse cx="22" cy="22" rx="17" ry="7" fill="none" class="s-mu"/><ellipse cx="22" cy="22" rx="17" ry="7" fill="none" class="s-mu" transform="rotate(60 22 22)"/><circle cx="22" cy="22" r="3.5" class="f-a2"/><circle cx="39" cy="22" r="2.4" class="f-acc"/>`],
      ['১৯১৩', 'নীলস বোর', 'স্থির কক্ষপথ মডেল', 'নির্দিষ্ট শক্তির বৃত্তাকার কক্ষপথ; কৌণিক ভরবেগ কোয়ান্টায়িত', `<circle cx="22" cy="22" r="7" fill="none" class="s-mu"/><circle cx="22" cy="22" r="12" fill="none" class="s-mu"/><circle cx="22" cy="22" r="17" fill="none" class="s-mu"/><circle cx="22" cy="22" r="3" class="f-a2"/><circle cx="34" cy="22" r="2.4" class="f-acc"/>`],
      ['১৯২৬', 'শ্রোডিঞ্জার ও অন্যান্য', 'কোয়ান্টাম বলবিদ্যা মডেল', 'ইলেকট্রন তরঙ্গ; অরবিটাল = সম্ভাব্যতার মেঘ', Array.from({ length: 70 }, (_, i) => { const r = X.rng(i + 3); const a = r() * 6.283, d = Math.pow(r(), 0.7) * 16; return `<circle cx="${(22 + d * Math.cos(a)).toFixed(1)}" cy="${(22 + d * Math.sin(a)).toFixed(1)}" r="1.1" class="f-acc" opacity=".7"/>`; }).join('') + '<circle cx="22" cy="22" r="2.2" class="f-a2"/>']
    ];
    return `<div class="stack" style="gap:0">${rows.map(([y, w, m, d, s], i) => `<div class="row" style="flex-wrap:nowrap;align-items:flex-start;gap:12px;padding:10px 0;${i ? 'border-top:1px dashed var(--line)' : ''}"><svg viewBox="0 0 44 44" width="44" height="44" style="flex:none" aria-hidden="true">${s}</svg><div style="min-width:0"><div class="small muted mono">${y} · ${w}</div><b>${m}</b><div class="small">${d}</div></div></div>`).join('')}</div>`;
  }
};

V.rfSetup = {
  t: 'রাদারফোর্ডের আলফা কণা বিচ্ছুরণ পরীক্ষার সেটআপ', k: ['2d'],
  cap: 'তেজস্ক্রিয় পোলোনিয়াম থেকে আলফা কণার সরু রশ্মি অতি পাতলা স্বর্ণপাতে আঘাত করে। ZnS পর্দায় প্রতিটি আলফা কণা আঘাতের স্থানে আলোর ঝলক (scintillation) তৈরি করে, যা অণুবীক্ষণ যন্ত্রে গণনা করা হয়।',
  html() {
    const cx = 215, cy = 128, R = 92;
    const P = a => [(cx + R * Math.cos(a * Math.PI / 180)).toFixed(1), (cy + R * Math.sin(a * Math.PI / 180)).toFixed(1)];
    const arc = (a1, a2) => { const [x1, y1] = P(a1), [x2, y2] = P(a2); return `M${x1} ${y1} A${R} ${R} 0 1 1 ${x2} ${y2}`; };
    const paths = [[0, 'straight'], [3, 'straight'], [-3, 'straight'], [18, 'dev'], [-26, 'dev'], [48, 'dev'], [152, 'back']];
    const col = { straight: 'var(--accent-2)', dev: '#2f9e6f', back: '#d63c3c' };
    return X.svg(420, 270, `<defs>${X.arrow('rfA')}</defs>
      <path d="${arc(-162, 162)}" fill="none" class="s-acc" stroke-width="5" opacity=".35"/>
      <rect x="14" y="104" width="54" height="48" rx="4" class="f-mu" opacity=".85"/><circle cx="50" cy="128" r="7" class="f-a2"/><text x="41" y="168" text-anchor="middle" class="tm">সীসার বাক্স</text><text x="50" y="132" text-anchor="middle" style="font-size:8px;fill:var(--surface)">Po</text>
      <rect x="92" y="96" width="9" height="28" class="f-mu"/><rect x="92" y="132" width="9" height="28" class="f-mu"/><text x="96" y="88" text-anchor="middle" class="tm">ছিদ্রযুক্ত পাত</text>
      <line x1="58" y1="128" x2="${cx - 3}" y2="128" stroke="var(--accent-2)" stroke-width="3"/>
      ${paths.map(([a, t]) => { const [x, y] = P(a); return `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="${col[t]}" stroke-width="${t === 'straight' ? 2 : 1.8}" ${t === 'back' ? 'stroke-dasharray="5 3"' : ''}/><circle cx="${x}" cy="${y}" r="4" fill="#fff6a8" stroke="${col[t]}"/>`; }).join('')}
      <rect x="${cx - 3}" y="78" width="6" height="100" fill="#d4a017"/><text x="${cx}" y="70" text-anchor="middle" class="tb" style="font-size:12px">স্বর্ণপাত</text>
      <g transform="translate(${P(-40)[0]},${P(-40)[1]}) rotate(-40)"><rect x="4" y="-7" width="34" height="14" rx="3" class="f-s3 s-mu"/><rect x="38" y="-5" width="10" height="10" class="f-mu"/></g>
      <text x="300" y="16" text-anchor="middle" class="tm">অণুবীক্ষণ যন্ত্র</text>
      <text x="318" y="248" text-anchor="middle" class="tm">ZnS প্রলেপযুক্ত পর্দা</text>
      <g transform="translate(14,214)"><line x1="0" y1="6" x2="22" y2="6" stroke="var(--accent-2)" stroke-width="3"/><text x="28" y="10" class="tm">অধিকাংশ সোজা চলে যায়</text>
      <line x1="0" y1="24" x2="22" y2="24" stroke="#2f9e6f" stroke-width="2"/><text x="28" y="28" class="tm">কিছু সামান্য বেঁকে যায়</text>
      <line x1="0" y1="42" x2="22" y2="42" stroke="#d63c3c" stroke-width="2" stroke-dasharray="5 3"/><text x="28" y="46" class="tm">খুব কম (≈ ২০,০০০-এ ১টি) ফিরে আসে</text></g>`, 'রাদারফোর্ড পরীক্ষার যন্ত্রব্যবস্থা');
  }
};

V.rfSim = {
  t: 'অ্যানিমেশন: স্বর্ণপাতে আলফা কণার বিচ্ছুরণ', k: ['anim', 'int'],
  cap: 'প্রতিটি সোনার পরমাণুর (ডটেড বৃত্ত) কেন্দ্রে ক্ষুদ্র নিউক্লিয়াস। কণাটি নিউক্লিয়াসের যত কাছ দিয়ে যায়, কুলম্ব বিকর্ষণে তত বেশি বেঁকে যায়। ক্যানভাসে ট্যাপ করে নির্দিষ্ট উচ্চতা থেকে কণা ছোড়ো। বোঝার সুবিধার্থে নিউক্লিয়াস বাস্তবের চেয়ে অনেক বড় দেখানো হয়েছে।',
  html: () => X.cv('আলফা কণা বিচ্ছুরণ সিমুলেশন') + `<div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-reset>${X.ico('repeat')}গণনা শূন্য করো</button><label class="row" style="gap:6px"><input type="checkbox" data-trail checked> পথরেখা</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'); let L = X.fit(c, W => Math.min(380, Math.max(240, W * 0.6)));
    let parts = [], cnt = { s: 0, d: 0, b: 0 }, spawnT = 0, trail = true;
    const K = 520; // repulsion constant (scaled)
    const nuclei = () => { const n = 6, out = []; for (let i = 0; i < n; i++) out.push([L.W * 0.55, (i + 0.5) * L.H / n]); return out; };
    let NU = nuclei();
    const spawn = y => parts.push({ x: 4, y: y != null ? y : 10 + Math.random() * (L.H - 20), vx: 200, vy: 0, tr: [] });
    c.addEventListener('pointerdown', e => { const r = c.getBoundingClientRect(); spawn((e.clientY - r.top) * L.H / r.height); A.draw(); });
    const out = el.querySelector('[data-out]');
    const upd = () => { const t = cnt.s + cnt.d + cnt.b; out.innerHTML = `সোজা (&lt;৫°): <b>${X.bn(cnt.s)}</b> · বিচ্যুত (৫°–৯০°): <b>${X.bn(cnt.d)}</b> · ফিরে এসেছে (&gt;৯০°): <b>${X.bn(cnt.b)}</b> · মোট ${X.bn(t)}`; };
    upd();
    el.querySelector('[data-reset]').onclick = () => { cnt = { s: 0, d: 0, b: 0 }; upd(); };
    el.querySelector('[data-trail]').onchange = e => { trail = e.target.checked; };
    const A = X.anim(c, dt => {
      const C = X.C(), g = L.g, W = L.W, H = L.H;
      spawnT += dt; if (spawnT > 0.16) { spawnT = 0; spawn(); }
      for (const p of parts) {
        const sub = 30, h = dt / sub;
        for (let s = 0; s < sub; s++) {
          let ax = 0, ay = 0;
          for (const [nx, ny] of NU) { const dx = p.x - nx, dy = p.y - ny, r2 = dx * dx + dy * dy + 0.4, r = Math.sqrt(r2); const f = K * 200 / r2; ax += f * dx / r; ay += f * dy / r; }
          p.vx += ax * h; p.vy += ay * h; p.x += p.vx * h; p.y += p.vy * h;
        }
        if (dt) { p.tr.push([p.x, p.y]); if (p.tr.length > 90) p.tr.shift(); }
      }
      parts = parts.filter(p => { const gone = p.x < -5 || p.x > W + 5 || p.y < -5 || p.y > H + 5; if (gone) { const a = Math.abs(Math.atan2(p.vy, p.vx)) * 180 / Math.PI; if (a < 5) cnt.s++; else if (a < 90) cnt.d++; else cnt.b++; upd(); } return !gone; });
      g.clearRect(0, 0, W, H); g.fillStyle = C.spec; g.fillRect(0, 0, W, H);
      g.fillStyle = 'rgba(212,160,23,.18)'; g.fillRect(W * 0.55 - 30, 0, 60, H);
      g.setLineDash([3, 4]); g.strokeStyle = 'rgba(255,215,120,.35)';
      for (const [nx, ny] of NU) { g.beginPath(); g.arc(nx, ny, H / 12 - 2, 0, 6.283); g.stroke(); }
      g.setLineDash([]);
      for (const [nx, ny] of NU) { g.fillStyle = '#ff6b5a'; g.beginPath(); g.arc(nx, ny, 3, 0, 6.283); g.fill(); }
      for (const p of parts) {
        if (trail && p.tr.length > 1) { g.strokeStyle = 'rgba(255,190,90,.45)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(p.tr[0][0], p.tr[0][1]); for (const q of p.tr) g.lineTo(q[0], q[1]); g.stroke(); }
        g.fillStyle = '#ffc861'; g.beginPath(); g.arc(p.x, p.y, 2.6, 0, 6.283); g.fill();
      }
      g.fillStyle = 'rgba(255,255,255,.75)'; g.font = `12px ${C.font}`; g.fillText('α উৎস →', 8, 16); g.fillText('স্বর্ণপাত', W * 0.55 - 22, H - 8);
    }, { paused: false });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(c, W => Math.min(380, Math.max(240, W * 0.6))); NU = nuclei(); parts = []; A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

V.rfAtom = {
  t: 'রাদারফোর্ডের পরমাণু মডেল ও এর মূল সীমাবদ্ধতা', k: ['2d', 'anim'],
  cap: 'বামে: সৌরজগতের মতো নিউক্লিয়াসের চারদিকে ইলেকট্রন ঘোরে। ডানে: চিরায়ত তড়িৎচুম্বকীয় তত্ত্ব (ম্যাক্সওয়েল) অনুযায়ী ঘূর্ণায়মান চার্জ ক্রমাগত শক্তি বিকিরণ করবে, ফলে ইলেকট্রন সর্পিল পথে নিউক্লিয়াসে পড়ে যাবে — অথচ বাস্তবে পরমাণু স্থিতিশীল।',
  html() {
    let sp = ''; for (let i = 0; i <= 220; i++) { const t = i / 220, a = t * 6.283 * 3.2, r = 62 - 54 * t; sp += (i ? 'L' : 'M') + (300 + r * Math.cos(a)).toFixed(1) + ' ' + (112 + r * Math.sin(a)).toFixed(1) + ' '; }
    const orb = (rx, ry, rot, dur, e) => `<g transform="rotate(${rot} 110 112)"><ellipse cx="110" cy="112" rx="${rx}" ry="${ry}" fill="none" class="s-mu" stroke-width="1.2"/><circle r="5" class="f-acc"><animateMotion dur="${dur}s" repeatCount="indefinite" path="M${110 + rx} 112 A${rx} ${ry} 0 1 1 ${110 - rx} 112 A${rx} ${ry} 0 1 1 ${110 + rx} 112"/></circle></g>`;
    return X.svg(410, 240, `<defs>${X.arrow('raA')}</defs>
      ${orb(88, 34, 0, 4)}${orb(88, 34, 60, 5.5)}${orb(88, 34, -60, 7)}
      <circle cx="110" cy="112" r="10" class="f-a2"/><text x="110" y="116" text-anchor="middle" style="font-size:11px;fill:var(--surface);font-weight:700">+</text>
      <text x="110" y="226" text-anchor="middle" class="tm">নিউক্লিয়াস (+) ও ঘূর্ণায়মান ইলেকট্রন (−)</text>
      <line x1="215" y1="20" x2="215" y2="215" class="s-ln" stroke-dasharray="4 4"/>
      <path d="${sp}" fill="none" stroke="var(--bad)" stroke-width="1.5" stroke-dasharray="4 3"/>
      <circle cx="300" cy="112" r="7" class="f-a2"/><circle cx="362" cy="112" r="4.5" class="f-acc"/>
      ${[0, 1, 2].map(i => `<path d="M${370 + i * 2} ${96 - i * 8} q6 -4 12 0 t12 0" fill="none" class="s-a2" stroke-width="1.4"/>`).join('')}
      <text x="300" y="196" text-anchor="middle" class="tm">শক্তি বিকিরণ → কক্ষপথ ছোট হয়ে</text><text x="300" y="212" text-anchor="middle" class="tm">নিউক্লিয়াসে পতন (ঘটে না!)</text>`, 'রাদারফোর্ড মডেল');
  }
};

V.bohrSim = {
  t: 'বোর মডেল: ইলেকট্রনের উত্তেজনা ও ফোটন নির্গমন', k: ['anim', 'int'],
  cap: 'উচ্চতর ও নিম্নতর শক্তিস্তর বেছে নাও। "নির্গমন" চাপলে ইলেকট্রন উপরের স্তর থেকে নিচে নামে এবং ΔE = hν শক্তির ফোটন বের হয়; "শোষণ" চাপলে ঠিক সমান শক্তির ফোটন শোষণ করে উপরে ওঠে। কক্ষপথের ব্যাসার্ধ n²-এর সমানুপাতিক।',
  html: () => X.cv('বোর মডেল সিমুলেশন') + `<div class="ctl"><label>উপরের স্তর n₂</label>${X.seg('hi', [2, 3, 4, 5, 6].map(n => [n, X.bn(n)]), 3)}<label>নিচের স্তর n₁</label>${X.seg('lo', [1, 2, 3, 4, 5].map(n => [n, X.bn(n)]), 2)}</div>
    <div class="ctl"><button class="btn sm primary" data-em>${X.ico('next')}নির্গমন (নিচে নামা)</button><button class="btn sm" data-ab>শোষণ (উপরে ওঠা)</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas');
    const hf = W => W >= 560 ? 360 : Math.round(W * 0.95 + 210);
    let L = X.fit(c, hf);
    let hi = 3, lo = 2, n = 3, ang = 0, phase = 'idle', t = 0, photon = null, from = 3, to = 3;
    const E = k => -13.6 / (k * k);
    const series = k => ['লাইম্যান (UV)', 'বামার (দৃশ্যমান)', 'পাশেন (IR)', 'ব্র্যাকেট (IR)', 'ফুন্ড (দূর IR)'][k - 1];
    const out = el.querySelector('[data-out]');
    const info = () => {
      const dE = E(lo) - E(hi); const lam = 1239.84 / Math.abs(dE);
      out.innerHTML = `n₂ = ${X.bn(hi)} → n₁ = ${X.bn(lo)} · ΔE = <b>${Math.abs(dE).toFixed(3)} eV</b> (${X.sci(Math.abs(dE) * 1.602e-19)} J) · λ = <b>${lam.toFixed(1)} nm</b> · ধারা: ${series(lo)}${lam >= 380 && lam <= 750 ? ` <span style="display:inline-block;width:12px;height:12px;border-radius:3px;vertical-align:-1px;background:${X.wl(lam)}"></span>` : ''}`;
    };
    const fix = () => { if (lo >= hi) { lo = hi - 1; el.querySelectorAll('[data-seg="lo"] button').forEach(b => b.classList.toggle('on', +b.dataset.k === lo)); } info(); };
    X.onSeg(el, 'hi', k => { hi = +k; fix(); if (phase === 'idle') n = hi; A.draw(); });
    X.onSeg(el, 'lo', k => { lo = +k; if (lo >= hi) { hi = Math.min(6, lo + 1); el.querySelectorAll('[data-seg="hi"] button').forEach(b => b.classList.toggle('on', +b.dataset.k === hi)); } info(); A.draw(); });
    el.querySelector('[data-em]').onclick = () => { from = hi; to = lo; n = hi; phase = 'move'; t = 0; photon = null; A.pause(false); X.pp(el, A); };
    el.querySelector('[data-ab]').onclick = () => { from = lo; to = hi; n = lo; phase = 'absorb'; t = 0; photon = { k: 'in', p: 0 }; A.pause(false); };
    info();
    const A = X.anim(c, dt => {
      const C = X.C(), g = L.g, W = L.W, H = L.H, side = W >= 560;
      const ax = side ? W * 0.3 : W / 2, ay = side ? H / 2 : (H - 200) / 2 + 4;
      const rmax = side ? Math.min(W * 0.28, H * 0.47) : Math.min(W * 0.46, (H - 210) / 2 - 6);
      const r = k => 8 + (rmax - 8) * (k * k) / 36;
      ang += dt * 2.6 / Math.pow(n, 1.2);
      t += dt;
      let rad = r(n);
      if (phase === 'move' || phase === 'absorb2') {
        const p = Math.min(1, t / 0.9); const e = p * p * (3 - 2 * p);
        rad = r(from) + (r(to) - r(from)) * e;
        if (phase === 'move' && !photon && p > 0.15) photon = { k: 'out', p: 0, a: ang, x: ax + rad * Math.cos(ang), y: ay + rad * Math.sin(ang) };
        if (p >= 1) { n = to; phase = 'idle'; }
      }
      if (phase === 'absorb') { if (photon) photon.p += dt * 1.4; if (!photon || photon.p >= 1) { photon = null; phase = 'absorb2'; t = 0; } }
      g.clearRect(0, 0, W, H);
      for (let k = 1; k <= 6; k++) { g.beginPath(); g.arc(ax, ay, r(k), 0, 6.283); g.strokeStyle = C.ln; g.lineWidth = (k === hi || k === lo) ? 1.6 : 0.8; g.setLineDash(k === hi || k === lo ? [] : [3, 4]); g.stroke(); }
      g.setLineDash([]);
      g.fillStyle = C.mu; g.font = `11px ${C.mono}`;
      for (let k = 1; k <= 6; k++) g.fillText('n=' + k, ax + r(k) * 0.71 + 3, ay - r(k) * 0.71 - 2);
      g.fillStyle = C.a2; g.beginPath(); g.arc(ax, ay, 6, 0, 6.283); g.fill();
      const ex = ax + rad * Math.cos(ang), ey = ay + rad * Math.sin(ang);
      g.fillStyle = C.acc; g.beginPath(); g.arc(ex, ey, 5.5, 0, 6.283); g.fill();
      const dE = Math.abs(E(lo) - E(hi)), lam = 1239.84 / dE, vis = lam >= 380 && lam <= 750, pc = vis ? X.wl(lam) : C.mu;
      if (photon) {
        g.strokeStyle = pc; g.lineWidth = 2.2; g.beginPath();
        let sx, sy, dx, dy, len = rmax * 1.1;
        if (photon.k === 'out') { photon.p += dt * 1.1; sx = photon.x; sy = photon.y; const a = photon.a; dx = Math.cos(a); dy = Math.sin(a); const d0 = photon.p * len; for (let s = 0; s <= 40; s++) { const u = d0 - 40 + s; if (u < 0) continue; const w = Math.sin(u * 0.55) * 5; g.lineTo(sx + dx * u - dy * w, sy + dy * u + dx * w); } if (photon.p > 1.3) photon = null; }
        else { const a = ang + 0.6, tx = ax + r(from) * Math.cos(a), ty = ay + r(from) * Math.sin(a); dx = Math.cos(a); dy = Math.sin(a); const d0 = (1 - photon.p) * len; for (let s = 0; s <= 40; s++) { const u = d0 + s; const w = Math.sin(u * 0.55) * 5; g.lineTo(tx + dx * u - dy * w, ty + dy * u + dx * w); } }
        g.stroke();
      }
      // energy diagram
      const x0 = side ? W * 0.6 : 8, x1 = W - 14, y0 = side ? 40 : H - 178, y1 = side ? H - 18 : H - 12, lx = x0 + 84;
      const yE = e => y1 - (y1 - y0) * (1 - Math.sqrt(-e / 13.6)) * 0.97;
      g.font = `12px ${C.font}`; g.fillStyle = C.fg; g.fillText('শক্তিস্তর চিত্র (eV, স্কেল অনুপাতে নয়)', x0, y0 - 16);
      for (let k = 1; k <= 6; k++) { const y = yE(E(k)); g.strokeStyle = (k === hi || k === lo) ? C.acc : C.ln; g.lineWidth = (k === hi || k === lo) ? 2 : 1; g.beginPath(); g.moveTo(lx, y); g.lineTo(x1, y); g.stroke(); if (k <= 4) { g.fillStyle = (k === hi || k === lo) ? C.fg : C.mu; g.font = `10.5px ${C.mono}`; g.fillText('n=' + k + '  ' + E(k).toFixed(2), x0, y + 4); } }
      g.strokeStyle = C.ln; g.setLineDash([2, 3]); const yi = yE(-0.0001); g.beginPath(); g.moveTo(lx, yi); g.lineTo(x1, yi); g.stroke(); g.setLineDash([]); g.fillStyle = C.mu; g.fillText('n=∞  0', x0, yi + 4);
      const xa = (lx + x1) / 2, ya = yE(E(hi)), yb = yE(E(lo));
      g.strokeStyle = vis ? pc : C.fg; g.fillStyle = g.strokeStyle; g.lineWidth = 2.5; g.beginPath(); g.moveTo(xa, ya); g.lineTo(xa, yb - 7); g.stroke();
      g.beginPath(); g.moveTo(xa - 6, yb - 9); g.lineTo(xa + 6, yb - 9); g.lineTo(xa, yb); g.closePath(); g.fill();
      g.fillStyle = C.fg; g.font = `12px ${C.font}`; g.fillText(lam.toFixed(0) + ' nm', xa + 8, (ya + yb) / 2);
    }, { paused: false });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

V.bohrCalc = {
  t: 'বোর তত্ত্ব ক্যালকুলেটর (H, He⁺, Li²⁺)', k: ['calc'],
  cap: 'r = 0.529 n²/Z Å, v = 2.18×10⁶ Z/n m s⁻¹, E = −13.6 Z²/n² eV, এবং 1/λ = R<sub>H</sub>Z²(1/n₁² − 1/n₂²)। শুধু এক-ইলেকট্রন বিশিষ্ট কণার জন্য প্রযোজ্য।',
  html: () => `<div class="grid2"><label class="stack" style="gap:4px"><span class="small muted">কণা (Z)</span><select data-z class="inp"><option value="1">H (Z = 1)</option><option value="2">He⁺ (Z = 2)</option><option value="3">Li²⁺ (Z = 3)</option></select></label>
    <label class="stack" style="gap:4px"><span class="small muted">কক্ষপথ n</span><input data-n type="number" min="1" max="10" value="1" class="inp"></label>
    <label class="stack" style="gap:4px"><span class="small muted">স্থানান্তর: n₂</span><input data-n2 type="number" min="2" max="12" value="3" class="inp"></label>
    <label class="stack" style="gap:4px"><span class="small muted">→ n₁</span><input data-n1 type="number" min="1" max="11" value="2" class="inp"></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const q = s => el.querySelector(s), out = q('[data-out]');
    const run = () => {
      const Z = +q('[data-z]').value, n = Math.max(1, +q('[data-n]').value || 1), n2 = +q('[data-n2]').value || 3, n1 = +q('[data-n1]').value || 2;
      const r = 0.529 * n * n / Z, v = 2.18e6 * Z / n, E = -13.6 * Z * Z / (n * n);
      let tr = '';
      if (n2 > n1 && n1 >= 1) { const inv = 1.0968e7 * Z * Z * (1 / (n1 * n1) - 1 / (n2 * n2)); const lam = 1 / inv; tr = `<br><b>স্থানান্তর ${n2} → ${n1}:</b> ν̄ = 1/λ = <b>${X.sci(inv / 100, 4)} cm⁻¹</b> · λ = <b>${(lam * 1e9).toFixed(2)} nm</b> · ν = <b>${X.sci(3e8 / lam)} Hz</b> · E = <b>${X.sci(6.626e-34 * 3e8 / lam)} J</b>`; }
      else tr = '<br><span class="muted">স্থানান্তরের জন্য n₂ অবশ্যই n₁-এর চেয়ে বড় হবে।</span>';
      out.innerHTML = `r<sub>${n}</sub> = <b>${r.toFixed(4)} Å</b> (${(r / 10).toFixed(5)} nm) · v<sub>${n}</sub> = <b>${X.sci(v)} m s⁻¹</b><br>E<sub>${n}</sub> = <b>${E.toFixed(3)} eV</b> = <b>${X.sci(E * 1.602e-19)} J</b> = <b>${(E * 96.485).toFixed(1)} kJ mol⁻¹</b> · আয়নীকরণ শক্তি (n থেকে ∞) = <b>${(-E).toFixed(3)} eV</b>${tr}`;
    };
    el.querySelectorAll('input,select').forEach(i => i.addEventListener('input', run)); run();
  }
};

/* ======================= 2.2 ======================= */
V.deBroglie = {
  t: 'দ্য ব্রগলি তরঙ্গদৈর্ঘ্য ক্যালকুলেটর', k: ['calc'],
  cap: 'λ = h/mv। ইলেকট্রনের মতো ক্ষুদ্র কণার λ পরমাণুর আকারের কাছাকাছি, তাই তরঙ্গ ধর্ম গুরুত্বপূর্ণ; ক্রিকেট বলের λ এত ক্ষুদ্র যে তা কখনো ধরা পড়ে না।',
  html: () => `<div class="grid2"><label class="stack" style="gap:4px"><span class="small muted">কণা</span><select data-m class="inp"><option value="9.109e-31">ইলেকট্রন (9.109×10⁻³¹ kg)</option><option value="1.673e-27">প্রোটন (1.673×10⁻²⁷ kg)</option><option value="6.645e-27">আলফা কণা (6.645×10⁻²⁷ kg)</option><option value="0.16">ক্রিকেট বল (0.16 kg)</option></select></label>
  <label class="stack" style="gap:4px"><span class="small muted">বেগ v (m s⁻¹)</span><input data-v type="number" value="1000000" class="inp"></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const run = () => { const m = +el.querySelector('[data-m]').value, v = +el.querySelector('[data-v]').value || 1; const l = 6.626e-34 / (m * v); el.querySelector('[data-out]').innerHTML = `λ = h/mv = 6.626×10⁻³⁴ / (${X.sci(m)} × ${X.sci(v)}) = <b>${X.sci(l)} m</b> = <b>${X.sci(l * 1e9)} nm</b><br>${l > 1e-11 ? 'পরমাণুর আকারের (~10⁻¹⁰ m) কাছাকাছি — তরঙ্গ ধর্ম পরীক্ষায় ধরা পড়ে (যেমন ইলেকট্রন অপবর্তন)।' : 'অত্যন্ত ক্ষুদ্র — বাস্তবে তরঙ্গ ধর্ম পর্যবেক্ষণযোগ্য নয়।'}`; };
    el.querySelectorAll('input,select').forEach(i => i.addEventListener('input', run)); run();
  }
};

const ORB = {
  '1s': { R: 6, n: 1, l: 0, f: (x, y, z, r) => Math.exp(-r), nm: '১s', d: 'গোলাকার, কোনো নোড নেই' },
  '2s': { R: 15, n: 2, l: 0, f: (x, y, z, r) => (2 - r) * Math.exp(-r / 2), nm: '২s', d: 'গোলাকার; ভেতরে একটি রেডিয়াল নোড (r = 2a₀)' },
  '3s': { R: 25, n: 3, l: 0, f: (x, y, z, r) => (27 - 18 * r + 2 * r * r) * Math.exp(-r / 3), nm: '৩s', d: 'গোলাকার; দুটি রেডিয়াল নোড' },
  '2px': { R: 13, n: 2, l: 1, f: (x, y, z, r) => x * Math.exp(-r / 2), nm: '২pₓ', d: 'ডাম্বেল, x অক্ষ বরাবর; yz তল নোডাল তল' },
  '2py': { R: 13, n: 2, l: 1, f: (x, y, z, r) => y * Math.exp(-r / 2), nm: '২p<sub>y</sub>', d: 'ডাম্বেল, y অক্ষ বরাবর; xz তল নোডাল তল' },
  '2pz': { R: 13, n: 2, l: 1, f: (x, y, z, r) => z * Math.exp(-r / 2), nm: '২p<sub>z</sub>', d: 'ডাম্বেল, z অক্ষ বরাবর; xy তল নোডাল তল' },
  '3pz': { R: 24, n: 3, l: 1, f: (x, y, z, r) => z * (6 - r) * Math.exp(-r / 3), nm: '৩p<sub>z</sub>', d: 'ডাম্বেল + একটি রেডিয়াল নোড (দুই স্তরের লোব)' },
  '3dxy': { R: 22, n: 3, l: 2, f: (x, y, z, r) => x * y * Math.exp(-r / 3), nm: '৩d<sub>xy</sub>', d: 'চার পাপড়ি, x ও y অক্ষের মাঝখানে' },
  '3dxz': { R: 22, n: 3, l: 2, f: (x, y, z, r) => x * z * Math.exp(-r / 3), nm: '৩d<sub>xz</sub>', d: 'চার পাপড়ি, x ও z অক্ষের মাঝখানে' },
  '3dyz': { R: 22, n: 3, l: 2, f: (x, y, z, r) => y * z * Math.exp(-r / 3), nm: '৩d<sub>yz</sub>', d: 'চার পাপড়ি, y ও z অক্ষের মাঝখানে' },
  '3dx2y2': { R: 22, n: 3, l: 2, f: (x, y, z, r) => (x * x - y * y) * Math.exp(-r / 3) / 2, nm: '৩d<sub>x²−y²</sub>', d: 'চার পাপড়ি, x ও y অক্ষ বরাবর' },
  '3dz2': { R: 22, n: 3, l: 2, f: (x, y, z, r) => (3 * z * z - r * r) * Math.exp(-r / 3) / 3, nm: '৩d<sub>z²</sub>', d: 'z অক্ষে ডাম্বেল + xy তলে বলয় (ডোনাট)' }
};
const orbCache = {};
function sampleOrb(key, N = 4200) {
  if (orbCache[key]) return orbCache[key];
  const o = ORB[key], R = o.R, rnd = X.rng(97 + key.length * 13);
  let mx = 0; const ev = (x, y, z) => { const r = Math.sqrt(x * x + y * y + z * z); const v = o.f(x, y, z, r); return v * v; };
  for (let i = 0; i < 40000; i++) { const p = ev((rnd() * 2 - 1) * R, (rnd() * 2 - 1) * R, (rnd() * 2 - 1) * R); if (p > mx) mx = p; }
  for (let i = 0; i <= 400; i++) { const t = (i / 400 * 2 - 1) * R; mx = Math.max(mx, ev(t, 0, 0), ev(0, t, 0), ev(0, 0, t), ev(t * .7, t * .7, 0), ev(t * .7, 0, t * .7), ev(0, t * .7, t * .7)); }
  const pts = []; let tries = 0;
  while (pts.length < N && tries < 1.5e6) { tries++; const x = (rnd() * 2 - 1) * R, y = (rnd() * 2 - 1) * R, z = (rnd() * 2 - 1) * R; const r = Math.sqrt(x * x + y * y + z * z); const v = o.f(x, y, z, r); if (rnd() * mx < v * v) pts.push([x / R, y / R, z / R, v >= 0 ? 1 : -1]); }
  return (orbCache[key] = pts);
}
V.orbital3d = {
  t: '৩D অরবিটাল মডেল: ইলেকট্রন মেঘ (|ψ|² সম্ভাব্যতা ঘনত্ব)', k: ['3d', 'int'],
  cap: 'প্রতিটি বিন্দু ইলেকট্রন পাওয়ার একটি সম্ভাব্য অবস্থান — যেখানে বিন্দু ঘন, সেখানে ইলেকট্রন পাওয়ার সম্ভাবনা বেশি। দুই রং তরঙ্গ ফাংশন ψ-এর দুই চিহ্ন (+/−, দশা) বোঝায়। আঙুল দিয়ে টেনে ঘোরাও। হাইড্রোজেন পরমাণুর প্রকৃত তরঙ্গ ফাংশন থেকে বিন্দুগুলো তৈরি।',
  html: () => `<div class="ctl" style="margin:0 0 10px">${X.seg('orb', Object.keys(ORB).map(k => [k, ORB[k].nm]), '2pz')}</div>` + X.cv('৩D অরবিটাল') + `<div class="calc-out" data-out></div><div class="ctl"><button class="btn sm" data-pp></button><span class="small muted">ঘোরাতে টেনে ধরো</span></div>`,
  mount(el) {
    const c = el.querySelector('canvas'); const hf = W => Math.min(420, Math.max(260, W * 0.78)); let L = X.fit(c, hf);
    let key = '2pz', pts = sampleOrb(key), yaw = 0.6, pitch = -0.35;
    const out = el.querySelector('[data-out]');
    const info = () => { const o = ORB[key]; out.innerHTML = `<b>${o.nm}</b> · n = ${X.bn(o.n)}, l = ${X.bn(o.l)} (${'spd'[o.l]}) · রেডিয়াল নোড = n − l − 1 = <b>${X.bn(o.n - o.l - 1)}</b> · কৌণিক নোড = l = <b>${X.bn(o.l)}</b><br>${o.d}`; };
    X.onSeg(el, 'orb', k => { key = k; pts = sampleOrb(k); info(); A.draw(); });
    info();
    const dragging = X.drag(c, (dx, dy) => { yaw += dx * 0.01; pitch = Math.max(-1.5, Math.min(1.5, pitch + dy * 0.01)); A.draw(); });
    const A = X.anim(c, dt => {
      if (!dragging()) yaw += dt * 0.35;
      const C = X.C(), g = L.g, W = L.W, H = L.H, S = Math.min(W, H) * 0.44, cx = W / 2, cy = H / 2;
      const cy_ = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
      const P = (x, y, z) => { const X1 = x * cy_ + y * sy, Y1 = -x * sy + y * cy_; const Z2 = z * cp - Y1 * sp, Y2 = z * sp + Y1 * cp; const f = 3.2 / (3.2 + Y2); return [cx + X1 * S * f, cy - Z2 * S * f, Y2]; };
      g.clearRect(0, 0, W, H);
      g.lineWidth = 1; g.font = `12px ${C.mono}`;
      [[1, 0, 0, 'x'], [0, 1, 0, 'y'], [0, 0, 1, 'z']].forEach(([a, b, d, n]) => { const p1 = P(-a * 1.05, -b * 1.05, -d * 1.05), p2 = P(a * 1.12, b * 1.12, d * 1.12); g.strokeStyle = C.ln; g.beginPath(); g.moveTo(p1[0], p1[1]); g.lineTo(p2[0], p2[1]); g.stroke(); g.fillStyle = C.mu; g.fillText(n, p2[0] + 3, p2[1] - 3); });
      const pos = C.acc, neg = C.a2;
      for (const [x, y, z, s] of pts) { const p = P(x, y, z); const a = 0.35 + 0.4 * (1 - (p[2] + 1) / 2); g.globalAlpha = a; g.fillStyle = s > 0 ? pos : neg; g.fillRect(p[0] - 1, p[1] - 1, 2.1, 2.1); }
      g.globalAlpha = 1; g.fillStyle = C.fg; const o = P(0, 0, 0); g.beginPath(); g.arc(o[0], o[1], 2.5, 0, 6.283); g.fill();
      g.font = `12px ${C.font}`; g.fillStyle = C.acc; g.fillText('■ ψ ধনাত্মক', 10, H - 26); g.fillStyle = C.a2; g.fillText('■ ψ ঋণাত্মক', 10, H - 9);
    }, { paused: X.rm() });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

V.qnExplorer = {
  t: 'কোয়ান্টাম সংখ্যা এক্সপ্লোরার', k: ['int'],
  cap: 'n দিলে l = 0 থেকে n−1, প্রতিটি l-এর জন্য m = −l থেকে +l, এবং প্রতিটি অরবিটালে s = +½ ও −½। নিচে যেকোনো মৌলের শেষ (পার্থক্যকারী) ইলেকট্রনের চারটি কোয়ান্টাম সংখ্যা দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 8px"><label>প্রধান কোয়ান্টাম সংখ্যা n =</label>${X.seg('n', [1, 2, 3, 4].map(n => [n, X.bn(n) + ' (' + 'KLMN'[n - 1] + ')']), 3)}</div><div data-tab></div>
  <div class="divider" style="margin:12px 0"></div><div class="ctl" style="margin:0"><label>মৌল নির্বাচন</label><select class="inp" data-el>${X.EL.map((e, i) => `<option value="${i + 1}" ${i === 7 ? 'selected' : ''}>${X.bn(i + 1)} ${e[0]} — ${e[1]}</option>`).join('')}</select></div><div class="calc-out" data-q></div>`,
  mount(el) {
    const tab = el.querySelector('[data-tab]');
    const draw = n => {
      const rows = []; let orbs = 0, el2 = 0;
      for (let l = 0; l < n; l++) { const ms = []; for (let m = -l; m <= l; m++) ms.push(m); orbs += 2 * l + 1; el2 += 2 * (2 * l + 1); rows.push(`<tr><td><b>${n}${'spdf'[l]}</b></td><td class="c">${l}</td><td class="mono">${ms.map(m => (m > 0 ? '+' : '') + m).join(', ')}</td><td class="c">${2 * l + 1}</td><td class="c">${2 * (2 * l + 1)}</td><td><span style="display:inline-flex;gap:2px">${ms.map(() => '<span style="width:16px;height:16px;border:1.5px solid var(--line-strong);border-radius:3px;display:inline-block"></span>').join('')}</span></td></tr>`); }
      tab.innerHTML = `<div class="table-wrap"><table class="t"><thead><tr><th>উপস্তর</th><th class="c">l</th><th>m-এর মান</th><th class="c">অরবিটাল (2l+1)</th><th class="c">সর্বোচ্চ e⁻ 2(2l+1)</th><th>অরবিটাল বাক্স</th></tr></thead><tbody>${rows.join('')}<tr><td colspan="3"><b>মোট (n = ${n})</b></td><td class="c"><b>n² = ${orbs}</b></td><td class="c"><b>2n² = ${el2}</b></td><td></td></tr></tbody></table></div>`;
    };
    X.onSeg(el, 'n', k => draw(+k)); draw(3);
    const qo = el.querySelector('[data-q]');
    const last = () => {
      const Z = +el.querySelector('[data-el]').value; let left = Z, sub = null, idx = 0;
      for (const [s, c] of X.ORDER) { if (left <= c) { sub = s; idx = left; break; } left -= c; }
      const n = +sub[0], l = 'spd'.indexOf(sub[1]), k = 2 * l + 1; const i = idx - 1; const orb = i % k; const m = -l + orb; const s = i < k ? '+½' : '−½';
      const ex = (Z === 24 || Z === 29) ? '<br><span class="small">বিঃদ্রঃ Cr ও Cu-এর প্রকৃত বিন্যাসে একটি 4s ইলেকট্রন 3d-তে যায়; এখানে আউফবাউ ক্রমে শেষ ইলেকট্রন দেখানো হয়েছে।</span>' : '';
      qo.innerHTML = `${X.EL[Z - 1][0]}: ${X.cfg(Z, 'n')}<br>শেষ ইলেকট্রন <b>${sub}</b> উপস্তরে → n = <b>${n}</b>, l = <b>${l}</b>, m = <b>${m > 0 ? '+' + m : m}</b>, s = <b>${s}</b>${ex}<br><span class="small muted">প্রথা: m-এর মান −l থেকে +l ক্রমে পূরণ, প্রথমে s = +½। কিছু বইয়ে উল্টো ক্রম ধরা হয় — উত্তরে প্রথাটি উল্লেখ করো।</span>`;
    };
    el.querySelector('[data-el]').addEventListener('change', last); last();
  }
};

V.atom3d = {
  t: '৩D পরমাণু মডেল: নিউক্লিয়াস ও শক্তিস্তর', k: ['3d', 'int'],
  cap: 'লাল: প্রোটন, ধূসর: নিউট্রন, নীল: ইলেকট্রন। প্রতিটি বলয় একটি প্রধান শক্তিস্তর (K, L, M, N)। এটি বোঝার জন্য সরলীকৃত মডেল — প্রকৃতপক্ষে ইলেকট্রন অরবিটালে মেঘ আকারে থাকে এবং নিউক্লিয়াস পরমাণুর তুলনায় প্রায় ১০⁵ গুণ ছোট। টেনে ঘোরাও।',
  html: () => X.cv('৩D পরমাণু') + `<div class="ctl"><label style="flex:none">Z</label><input type="range" min="1" max="30" value="11" data-z style="flex:1;min-width:140px"><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'); const hf = W => Math.min(380, Math.max(250, W * 0.72)); let L = X.fit(c, hf);
    let Z = 11, nuc = [], yaw = 0.4, pitch = 0.35, t = 0;
    const build = () => {
      const e = X.EL[Z - 1], A_ = e[2], N = A_ - Z, rnd = X.rng(Z * 7 + 3); nuc = [];
      const R = 0.06 + 0.035 * Math.cbrt(A_);
      for (let i = 0; i < A_; i++) { let x, y, z; do { x = rnd() * 2 - 1; y = rnd() * 2 - 1; z = rnd() * 2 - 1; } while (x * x + y * y + z * z > 1); nuc.push([x * R, y * R, z * R, i < Z ? 1 : 0]); }
      for (let i = nuc.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [nuc[i], nuc[j]] = [nuc[j], nuc[i]]; }
      const sh = X.shells(Z);
      el.querySelector('[data-out]').innerHTML = `<b>${e[0]} · ${e[1]}</b> — Z = ${X.bn(Z)}, A = ${X.bn(A_)} · প্রোটন ${X.bn(Z)}, নিউট্রন ${X.bn(N)}, ইলেকট্রন ${X.bn(Z)}<br>শক্তিস্তরে বিন্যাস: ${sh.map((n, i) => 'KLMN'[i] + ' ' + X.bn(n)).join(', ')} · ${X.cfg(Z, 'n')}`;
    };
    el.querySelector('[data-z]').addEventListener('input', e => { Z = +e.target.value; build(); A.draw(); });
    build();
    const dragging = X.drag(c, (dx, dy) => { yaw += dx * 0.01; pitch = Math.max(-1.4, Math.min(1.4, pitch + dy * 0.01)); A.draw(); });
    const A = X.anim(c, dt => {
      t += dt; if (!dragging()) yaw += dt * 0.25;
      const C = X.C(), g = L.g, W = L.W, H = L.H, S = Math.min(W, H) * 0.44, cx = W / 2, cy = H / 2;
      const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
      const P = (x, y, z) => { const X1 = x * cyw + z * syw, Z1 = -x * syw + z * cyw; const Y2 = y * cp - Z1 * sp, Z2 = y * sp + Z1 * cp; const f = 3 / (3 + Z2); return [cx + X1 * S * f, cy - Y2 * S * f, Z2, f]; };
      const sh = X.shells(Z); g.clearRect(0, 0, W, H);
      const items = [];
      sh.forEach((cnt, i) => {
        const r = 0.32 + i * 0.22, tilt = 0.5 + i * 0.7, rot = i * 1.1;
        const pt = a => { let x = r * Math.cos(a), y = 0, z = r * Math.sin(a); const y1 = y * Math.cos(tilt) - z * Math.sin(tilt), z1 = y * Math.sin(tilt) + z * Math.cos(tilt); const x2 = x * Math.cos(rot) - z1 * Math.sin(rot), z2 = x * Math.sin(rot) + z1 * Math.cos(rot); return P(x2, y1, z2); };
        g.strokeStyle = C.ln; g.lineWidth = 1; g.beginPath(); for (let k = 0; k <= 72; k++) { const p = pt(k / 72 * 6.283); k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); } g.stroke();
        for (let k = 0; k < cnt; k++) { const p = pt(k / cnt * 6.283 + t * (1.2 / (i + 1))); items.push([p[2], 'e', p]); }
      });
      for (const n of nuc) { const p = P(n[0], n[1], n[2]); items.push([p[2], n[3] ? 'p' : 'n', p]); }
      items.sort((a, b) => b[0] - a[0]);
      for (const [, k, p] of items) {
        const rr = k === 'e' ? 4.5 * p[3] : 5.2 * p[3] * S / 160;
        const grd = g.createRadialGradient(p[0] - rr * .35, p[1] - rr * .35, rr * .1, p[0], p[1], rr);
        const base = k === 'e' ? C.acc : k === 'p' ? '#e0534a' : '#9aa0a8';
        grd.addColorStop(0, '#ffffff'); grd.addColorStop(0.35, base); grd.addColorStop(1, base);
        g.fillStyle = grd; g.beginPath(); g.arc(p[0], p[1], Math.max(1.5, rr), 0, 6.283); g.fill();
      }
      g.font = `12px ${C.font}`; g.fillStyle = C.mu;
      sh.forEach((cnt, i) => g.fillText('KLMN'[i] + ': ' + X.bn(cnt), 10, 18 + i * 16));
    }, { paused: X.rm() });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

V.nuclide = {
  t: 'নিউক্লাইড প্রতীক ও আইসো-সম্পর্ক', k: ['2d'],
  cap: 'ভর সংখ্যা উপরে বামে, পারমাণবিক সংখ্যা নিচে বামে। চারটি "আইসো" শব্দ মনে রাখার কৌশল: আইসোটোপ — প্রোটন (p) এক; আইসোটোন — নিউট্রন (n) এক; আইসোবার — ভর সংখ্যা (A) এক; আইসোইলেকট্রনিক — ইলেকট্রন সংখ্যা এক।',
  html() {
    const box = (x, y, t, a, b, d) => `<g transform="translate(${x},${y})"><rect width="190" height="74" rx="10" class="f-s2 s-ln"/><text x="10" y="20" class="tb" style="font-size:13px">${t}</text><text x="10" y="40" class="mono" style="font-size:12.5px">${a}</text><text x="10" y="58" class="tm">${b}</text>${d ? `<text x="180" y="20" text-anchor="end" class="tm">${d}</text>` : ''}</g>`;
    return X.svg(410, 300, `<defs>${X.arrow('nuA')}</defs>
      <text x="150" y="88" text-anchor="middle" style="font-size:64px;font-family:var(--font-display)">X</text>
      <text x="108" y="44" text-anchor="end" class="mono tb" style="font-size:22px;fill:var(--accent)">A</text>
      <text x="108" y="92" text-anchor="end" class="mono tb" style="font-size:22px;fill:var(--accent-2)">Z</text>
      <line x1="115" y1="36" x2="230" y2="26" class="s-fg" marker-end="url(#nuA)"/><text x="236" y="24" style="font-size:12.5px">ভর সংখ্যা A = p + n</text>
      <line x1="115" y1="86" x2="230" y2="96" class="s-fg" marker-end="url(#nuA)"/><text x="236" y="100" style="font-size:12.5px">পারমাণবিক সংখ্যা Z = p</text>
      <text x="236" y="62" style="font-size:12.5px">নিউট্রন n = A − Z</text>
      ${box(8, 124, 'আইসোটোপ', '¹H, ²H, ³H · ³⁵Cl, ³⁷Cl', 'Z সমান, A ভিন্ন', 'p সমান')}
      ${box(212, 124, 'আইসোবার', '⁴⁰Ar, ⁴⁰K, ⁴⁰Ca', 'A সমান, Z ভিন্ন', 'A সমান')}
      ${box(8, 210, 'আইসোটোন', '¹⁴C, ¹⁵N, ¹⁶O (n = 8)', 'নিউট্রন সংখ্যা সমান', 'n সমান')}
      ${box(212, 210, 'আইসোইলেকট্রনিক', 'Ne, Na⁺, Mg²⁺, F⁻, O²⁻', 'ইলেকট্রন সংখ্যা সমান (১০)', 'e⁻ সমান')}`, 'নিউক্লাইড প্রতীক');
  }
};

V.avgMass = {
  t: 'আইসোটোপের প্রাচুর্য থেকে গড় পারমাণবিক ভর', k: ['calc'],
  cap: 'গড় পারমাণবিক ভর = Σ(আইসোটোপের ভর × শতকরা প্রাচুর্য) / ১০০। উল্টো হিসাব: দুই আইসোটোপের ক্ষেত্রে x% = (M₂ − M̄)/(M₂ − M₁) × ১০০।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('pre', [['cl', 'Cl'], ['cl2', 'Cl (পূর্ণসংখ্যা)'], ['b', 'B'], ['mg', 'Mg'], ['cu', 'Cu']], 'cl2')}</div><div data-rows class="stack" style="gap:6px"></div>
  <div class="calc-out" data-out></div><div class="divider" style="margin:12px 0"></div><b class="small">উল্টো হিসাব (দুই আইসোটোপ)</b>
  <div class="grid3" style="margin-top:6px"><input class="inp" data-r1 type="number" value="35" aria-label="M1"><input class="inp" data-r2 type="number" value="37" aria-label="M2"><input class="inp" data-ra type="number" value="35.5" step="0.01" aria-label="গড়"></div><div class="small muted">M₁, M₂ ও গড় ভর লেখো</div><div class="calc-out" data-rev></div>`,
  mount(el) {
    const P = { cl: [[34.969, 75.77], [36.966, 24.23]], cl2: [[35, 75], [37, 25]], b: [[10.013, 19.9], [11.009, 80.1]], mg: [[23.985, 78.99], [24.986, 10.00], [25.983, 11.01]], cu: [[62.930, 69.15], [64.928, 30.85]] };
    const rows = el.querySelector('[data-rows]');
    const load = k => { rows.innerHTML = P[k].map(([m, a], i) => `<div class="grid2"><label class="row" style="gap:6px;flex-wrap:nowrap"><span class="small muted nowrap">ভর ${X.bn(i + 1)}</span><input class="inp" type="number" step="0.001" value="${m}" data-m style="width:100%"></label><label class="row" style="gap:6px;flex-wrap:nowrap"><span class="small muted nowrap">প্রাচুর্য %</span><input class="inp" type="number" step="0.01" value="${a}" data-a style="width:100%"></label></div>`).join(''); rows.querySelectorAll('input').forEach(i => i.addEventListener('input', run)); run(); };
    const run = () => { const ms = [...rows.querySelectorAll('[data-m]')].map(i => +i.value), as = [...rows.querySelectorAll('[data-a]')].map(i => +i.value); const sa = as.reduce((a, b) => a + b, 0); const avg = ms.reduce((s, m, i) => s + m * as[i], 0) / 100; el.querySelector('[data-out]').innerHTML = `M̄ = (${ms.map((m, i) => m + '×' + as[i]).join(' + ')}) / 100 = <b>${avg.toFixed(3)}</b>${Math.abs(sa - 100) > 0.05 ? `<br><span style="color:var(--bad)">প্রাচুর্যের যোগফল ${sa.toFixed(2)}% — ১০০% হওয়া উচিত</span>` : ''}`; };
    X.onSeg(el, 'pre', load); load('cl2');
    const rev = () => { const m1 = +el.querySelector('[data-r1]').value, m2 = +el.querySelector('[data-r2]').value, a = +el.querySelector('[data-ra]').value; const x = (m2 - a) / (m2 - m1) * 100; el.querySelector('[data-rev]').innerHTML = isFinite(x) && x >= 0 && x <= 100 ? `ধরি M₁-এর প্রাচুর্য x%। তাহলে ${m1}x + ${m2}(100 − x) = ${a}×100 ⇒ x = <b>${x.toFixed(2)}%</b>, M₂-এর প্রাচুর্য <b>${(100 - x).toFixed(2)}%</b>` : '<span style="color:var(--bad)">গড় ভর অবশ্যই M₁ ও M₂-এর মাঝে হবে।</span>'; };
    el.querySelectorAll('[data-r1],[data-r2],[data-ra]').forEach(i => i.addEventListener('input', rev)); rev();
  }
};

V.npBelt = {
  t: 'নিউক্লিয়াসের স্থিতিশীলতা: n/p অনুপাত ও স্থিতিশীলতার বেল্ট', k: ['2d'],
  cap: 'হালকা মৌলে স্থিতিশীল নিউক্লিয়াসে n/p ≈ ১; ভারী মৌলে প্রায় ১.৫। বেল্টের উপরে (নিউট্রন বেশি) নিউক্লিয়াস β⁻ নির্গমন করে, নিচে (প্রোটন বেশি) β⁺ নির্গমন বা ইলেকট্রন গ্রহণ করে, আর Z > ৮৩ হলে সাধারণত α নির্গমন করে।',
  html() {
    const x = Z => 52 + Z * 3.2, y = N => 262 - N * 1.5;
    let up = [], lo = []; for (let Z = 1; Z <= 92; Z += 1) { const Nc = Z + 0.0062 * Z * Z, w = 1.5 + 0.055 * Z; up.push(x(Z).toFixed(1) + ',' + y(Nc + w).toFixed(1)); lo.unshift(x(Z).toFixed(1) + ',' + y(Math.max(Z * 0.95, Nc - w)).toFixed(1)); }
    const pts = [[2, 2, '⁴He'], [6, 6, '¹²C'], [8, 8, '¹⁶O'], [20, 20, '⁴⁰Ca'], [26, 30, '⁵⁶Fe'], [50, 70, '¹²⁰Sn'], [82, 126, '²⁰⁸Pb'], [92, 146, '²³⁸U']];
    let ticks = ''; for (let Z = 0; Z <= 100; Z += 20) ticks += `<line x1="${x(Z)}" y1="262" x2="${x(Z)}" y2="266" class="s-fg"/><text x="${x(Z)}" y="278" text-anchor="middle" class="tm">${X.bn(Z)}</text>`;
    for (let N = 0; N <= 160; N += 40) ticks += `<line x1="48" y1="${y(N)}" x2="52" y2="${y(N)}" class="s-fg"/><text x="44" y="${y(N) + 4}" text-anchor="end" class="tm">${X.bn(N)}</text>`;
    return X.svg(400, 300, `${ticks}<line x1="52" y1="262" x2="380" y2="262" class="s-fg"/><line x1="52" y1="262" x2="52" y2="16" class="s-fg"/>
      <polygon points="${up.join(' ')} ${lo.join(' ')}" fill="var(--accent)" opacity=".22" stroke="var(--accent)" stroke-width="1"/>
      <line x1="${x(0)}" y1="${y(0)}" x2="${x(100)}" y2="${y(100)}" class="s-mu" stroke-dasharray="5 4"/><text x="${x(98)}" y="${y(100) + 16}" text-anchor="end" class="tm">n = p (n/p = ১)</text>
      <line x1="${x(83)}" y1="262" x2="${x(83)}" y2="20" stroke="var(--bad)" stroke-dasharray="3 3"/><text x="${x(84)}" y="34" class="tm">Z = ৮৩</text>
      ${pts.map(([Z, N, n]) => `<circle cx="${x(Z)}" cy="${y(N)}" r="3" class="f-fg"/><text x="${x(Z) + 5}" y="${y(N) - 4}" style="font-size:10.5px">${n}</text>`).join('')}
      <circle cx="${x(6)}" cy="${y(8)}" r="3" fill="var(--bad)"/><text x="${x(6) - 4}" y="${y(8) - 6}" text-anchor="end" style="font-size:10.5px">¹⁴C</text>
      <text x="${x(14)}" y="${y(82)}" style="font-size:11.5px;fill:var(--bad)">নিউট্রন বেশি → β⁻ নির্গমন</text>
      <text x="${x(46)}" y="${y(30)}" style="font-size:11.5px;fill:var(--accent-2)">প্রোটন বেশি → β⁺ / ইলেকট্রন গ্রহণ</text>
      <text x="${x(86)}" y="${y(58)}" style="font-size:11.5px">α</text>
      <text x="216" y="296" text-anchor="middle" style="font-size:12px">পারমাণবিক সংখ্যা Z (প্রোটন)</text>
      <text x="14" y="140" transform="rotate(-90 14 140)" text-anchor="middle" style="font-size:12px">নিউট্রন সংখ্যা N</text>`, 'স্থিতিশীলতার বেল্ট');
  }
};

V.decaySim = {
  t: 'অর্ধায়ু সিমুলেশন: তেজস্ক্রিয় ক্ষয়', k: ['anim', 'int'],
  cap: 'প্রতিটি পরমাণু কখন ভাঙবে তা অনিশ্চিত, কিন্তু অনেক পরমাণুর মধ্যে একটি নির্দিষ্ট সময় (অর্ধায়ু, t½) পরপর অর্ধেক ক্ষয় হয়: N = N₀(½)<sup>t/t½</sup>। বিন্দুরেখা তাত্ত্বিক বক্ররেখা, রঙিন বিন্দু সিমুলেশনের মান।',
  html: () => X.cv('অর্ধায়ু সিমুলেশন') + `<div class="ctl"><label>অর্ধায়ু</label>${X.seg('th', [[2, '২ সে.'], [4, '৪ সে.'], [8, '৮ সে.']], 4)}<button class="btn sm" data-pp></button><button class="btn sm" data-reset>${X.ico('repeat')}আবার</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'); const hf = W => W >= 560 ? 280 : Math.round(W * 0.92 + 190); let L = X.fit(c, hf);
    const N0 = 400; let th = 4, atoms, t, hist;
    const reset = () => { atoms = new Array(N0).fill(1); t = 0; hist = [[0, N0]]; };
    reset();
    const out = el.querySelector('[data-out]');
    X.onSeg(el, 'th', k => { th = +k; reset(); A.draw(); });
    el.querySelector('[data-reset]').onclick = () => { reset(); A.pause(false); X.pp(el, A); };
    const A = X.anim(c, dt => {
      if (dt && t < 5 * th) { t += dt; const p = 1 - Math.pow(0.5, dt / th); for (let i = 0; i < N0; i++) if (atoms[i] && Math.random() < p) atoms[i] = 0; const n = atoms.reduce((a, b) => a + b, 0); hist.push([t, n]); }
      const C = X.C(), g = L.g, W = L.W, H = L.H, side = W >= 560; g.clearRect(0, 0, W, H);
      const gs = side ? Math.min(H - 20, W * 0.42) : Math.min(W - 20, 220); const gx = side ? 10 : (W - gs) / 2, gy = 10, cell = gs / 20;
      for (let i = 0; i < N0; i++) { const r = Math.floor(i / 20), q = i % 20; g.fillStyle = atoms[i] ? C.a2 : C.s3; g.beginPath(); g.arc(gx + q * cell + cell / 2, gy + r * cell + cell / 2, cell * 0.36, 0, 6.283); g.fill(); }
      const px = side ? gx + gs + 46 : 48, py = side ? 16 : gy + gs + 22, pw = side ? W - px - 14 : W - 66, ph = side ? H - 48 : H - py - 34;
      g.strokeStyle = C.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(px, py); g.lineTo(px, py + ph); g.lineTo(px + pw, py + ph); g.stroke();
      const sx = v => px + v / (5 * th) * pw, sy = v => py + ph - v / N0 * ph;
      g.font = `11px ${C.mono}`; g.fillStyle = C.mu;
      for (let k = 0; k <= 5; k++) { g.fillText(k + 't½', sx(k * th) - 8, py + ph + 14); g.strokeStyle = C.line; g.beginPath(); g.moveTo(sx(k * th), py); g.lineTo(sx(k * th), py + ph); g.stroke(); }
      [400, 200, 100, 50].forEach(v => { g.fillText(String(v), px - 30, sy(v) + 4); g.strokeStyle = C.line; g.beginPath(); g.moveTo(px, sy(v)); g.lineTo(px + pw, sy(v)); g.stroke(); });
      g.setLineDash([4, 4]); g.strokeStyle = C.mu; g.beginPath(); for (let k = 0; k <= 100; k++) { const tt = k / 100 * 5 * th; const v = N0 * Math.pow(0.5, tt / th); k ? g.lineTo(sx(tt), sy(v)) : g.moveTo(sx(tt), sy(v)); } g.stroke(); g.setLineDash([]);
      g.strokeStyle = C.a2; g.lineWidth = 2; g.beginPath(); hist.forEach(([a, b], k) => k ? g.lineTo(sx(a), sy(b)) : g.moveTo(sx(a), sy(b))); g.stroke();
      const n = hist[hist.length - 1][1];
      out.innerHTML = `সময় t = <b>${X.bn(t.toFixed(1))} সে.</b> (${X.bn((t / th).toFixed(2))} অর্ধায়ু) · অবশিষ্ট N = <b>${X.bn(n)}</b> · তাত্ত্বিক N₀(½)<sup>t/t½</sup> = <b>${X.bn(Math.round(N0 * Math.pow(0.5, t / th)))}</b>`;
      if (t >= 5 * th && !A.paused) { A.pause(true); X.pp(el, A); }
    }, { paused: false });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

V.penetration = {
  t: 'α, β ও γ রশ্মির ভেদনক্ষমতা এবং তড়িৎক্ষেত্রে বিচ্যুতি', k: ['2d'],
  cap: 'উপরে: α কাগজে, β কয়েক মিলিমিটার অ্যালুমিনিয়ামে থেমে যায়; γ পুরু সীসায় শুধু দুর্বল হয়। নিচে: ধনাত্মক α ঋণাত্মক প্লেটের দিকে সামান্য বাঁকে (ভারী বলে কম), ঋণাত্মক β ধনাত্মক প্লেটের দিকে বেশি বাঁকে, চার্জহীন γ সোজা যায়।',
  html() {
    const a = '#e4572e', b = '#2f7fd6', gm = '#9b4dca';
    let wave = ''; for (let xx = 40; xx <= 300; xx += 2) wave += (xx === 40 ? 'M' : 'L') + xx + ' ' + (98 + 4 * Math.sin(xx / 4)).toFixed(1) + ' ';
    let wave2 = ''; for (let xx = 322; xx <= 392; xx += 2) wave2 += (xx === 322 ? 'M' : 'L') + xx + ' ' + (98 + 2 * Math.sin(xx / 4)).toFixed(1) + ' ';
    return X.svg(400, 300, `<defs>${X.arrowC('peA', a)}${X.arrowC('peB', b)}${X.arrowC('peG', gm)}</defs>
      <text x="8" y="18" class="tb" style="font-size:13px">ভেদনক্ষমতা</text>
      <rect x="8" y="34" width="30" height="80" rx="4" class="f-mu"/><text x="23" y="128" text-anchor="middle" class="tm">উৎস</text>
      <line x1="38" y1="50" x2="118" y2="50" stroke="${a}" stroke-width="3" marker-end="url(#peA)"/><text x="60" y="44" style="font-size:12px;fill:${a}">α</text>
      <line x1="38" y1="74" x2="208" y2="74" stroke="${b}" stroke-width="2.5" marker-end="url(#peB)"/><text x="60" y="68" style="font-size:12px;fill:${b}">β</text>
      <path d="${wave}" fill="none" stroke="${gm}" stroke-width="2"/><path d="${wave2}" fill="none" stroke="${gm}" stroke-width="1.2" opacity=".55"/><text x="60" y="114" style="font-size:12px;fill:${gm}">γ</text>
      <rect x="120" y="32" width="5" height="86" fill="#efe6c8" stroke="#b8a76a"/><text x="122" y="134" text-anchor="middle" class="tm">কাগজ</text>
      <rect x="210" y="32" width="9" height="86" fill="#b9c2cc" stroke="#7d8793"/><text x="214" y="134" text-anchor="middle" class="tm">অ্যালুমিনিয়াম</text><text x="214" y="148" text-anchor="middle" class="tm">(কয়েক mm)</text>
      <rect x="302" y="32" width="20" height="86" fill="#5c6670"/><text x="312" y="134" text-anchor="middle" class="tm">সীসা</text><text x="312" y="148" text-anchor="middle" class="tm">(কয়েক cm)</text>
      <line x1="0" y1="160" x2="400" y2="160" class="s-ln" stroke-dasharray="4 4"/>
      <text x="8" y="180" class="tb" style="font-size:13px">তড়িৎক্ষেত্রে বিচ্যুতি</text>
      <rect x="120" y="190" width="200" height="8" fill="#d9534f"/><text x="110" y="198" text-anchor="end" style="font-size:14px;font-weight:700">+</text>
      <rect x="120" y="282" width="200" height="8" fill="#3b6fd8"/><text x="110" y="290" text-anchor="end" style="font-size:14px;font-weight:700">−</text>
      <rect x="8" y="230" width="30" height="22" rx="4" class="f-mu"/>
      <path d="M38 241 L120 241 Q 260 241 380 268" fill="none" stroke="${a}" stroke-width="2.5" marker-end="url(#peA)"/><text x="384" y="282" style="font-size:12px;fill:${a}">α</text>
      <path d="M38 241 L120 241 Q 200 236 262 206" fill="none" stroke="${b}" stroke-width="2.2" marker-end="url(#peB)"/><text x="268" y="214" style="font-size:12px;fill:${b}">β</text>
      <line x1="38" y1="241" x2="384" y2="241" stroke="${gm}" stroke-width="2" marker-end="url(#peG)"/><text x="388" y="238" style="font-size:12px;fill:${gm}">γ</text>`, 'আলফা বিটা গামা');
  }
};

/* ======================= 2.3 ======================= */
V.orbShapes = {
  t: 's, p ও d অরবিটালের আকৃতি (২D, লেবেলসহ)', k: ['2d'],
  cap: 's গোলাকার (দিক-নিরপেক্ষ); p ডাম্বেল আকৃতির, তিনটি পরস্পর লম্ব অক্ষ বরাবর; d অরবিটাল পাঁচটি — চারটি "চার পাপড়ি" আকৃতির এবং d<sub>z²</sub> ডাম্বেল ও বলয়যুক্ত। দুই রং তরঙ্গ ফাংশনের দুই দশা (+ ও −)।',
  html() {
    const lobe = (cx, cy, ang, len, wid, ph) => `<path transform="translate(${cx},${cy}) rotate(${ang})" d="M0 0 C${len * 0.3} ${-wid} ${len} ${-wid} ${len} 0 C${len} ${wid} ${len * 0.3} ${wid} 0 0Z" fill="${ph > 0 ? 'var(--accent)' : 'var(--accent-2)'}" opacity=".78"/>`;
    const axes = (cx, cy, h, v, s = 34) => `<line x1="${cx - s}" y1="${cy}" x2="${cx + s}" y2="${cy}" class="s-mu" stroke-width=".8"/><line x1="${cx}" y1="${cy - s}" x2="${cx}" y2="${cy + s}" class="s-mu" stroke-width=".8"/><text x="${cx + s + 2}" y="${cy + 4}" class="tm" style="font-size:10px">${h}</text><text x="${cx + 3}" y="${cy - s + 2}" class="tm" style="font-size:10px">${v}</text>`;
    const P = (cx, cy, name, inner, h, v) => `${axes(cx, cy, h, v)}${inner}<text x="${cx}" y="${cy + 52}" text-anchor="middle" style="font-size:12.5px">${name}</text>`;
    const r1 = 52, r2 = 172;
    return X.svg(400, 250, `
      ${P(50, r1, 's', `<circle cx="50" cy="${r1}" r="22" fill="var(--accent)" opacity=".75"/>`, 'x', 'y')}
      ${P(150, r1, 'p<tspan baseline-shift="sub" style="font-size:9px">x</tspan>', lobe(150, r1, 0, 32, 13, 1) + lobe(150, r1, 180, 32, 13, -1), 'x', 'y')}
      ${P(250, r1, 'p<tspan baseline-shift="sub" style="font-size:9px">y</tspan>', lobe(250, r1, -90, 32, 13, 1) + lobe(250, r1, 90, 32, 13, -1), 'x', 'y')}
      ${P(350, r1, 'p<tspan baseline-shift="sub" style="font-size:9px">z</tspan>', lobe(350, r1, -90, 32, 13, 1) + lobe(350, r1, 90, 32, 13, -1), 'x', 'z')}
      ${P(40, r2, 'd<tspan baseline-shift="sub" style="font-size:9px">xy</tspan>', [45, 135, 225, 315].map((a, i) => lobe(40, r2, a, 28, 9, i % 2 ? -1 : 1)).join(''), 'x', 'y')}
      ${P(120, r2, 'd<tspan baseline-shift="sub" style="font-size:9px">yz</tspan>', [45, 135, 225, 315].map((a, i) => lobe(120, r2, a, 28, 9, i % 2 ? -1 : 1)).join(''), 'y', 'z')}
      ${P(200, r2, 'd<tspan baseline-shift="sub" style="font-size:9px">xz</tspan>', [45, 135, 225, 315].map((a, i) => lobe(200, r2, a, 28, 9, i % 2 ? -1 : 1)).join(''), 'x', 'z')}
      ${P(280, r2, 'd<tspan baseline-shift="sub" style="font-size:9px">x²−y²</tspan>', [0, 90, 180, 270].map((a, i) => lobe(280, r2, a, 28, 9, i % 2 ? -1 : 1)).join(''), 'x', 'y')}
      ${P(360, r2, 'd<tspan baseline-shift="sub" style="font-size:9px">z²</tspan>', lobe(360, r2, -90, 32, 10, 1) + lobe(360, r2, 90, 32, 10, 1) + `<ellipse cx="360" cy="${r2}" rx="17" ry="6" fill="none" stroke="var(--accent-2)" stroke-width="5" opacity=".8"/>`, 'x', 'z')}
      <text x="200" y="${r2 + 72}" text-anchor="middle" class="tm">নীল = ψ ধনাত্মক লোব, কমলা = ψ ঋণাত্মক লোব</text>`, 'অরবিটালের আকৃতি');
  }
};
V.energyOrder = {
  t: '(n + l) নিয়ম অনুযায়ী অরবিটালের শক্তিক্রম', k: ['2d'],
  cap: 'যার (n + l) কম তার শক্তি কম; (n + l) সমান হলে যার n কম তার শক্তি কম। তাই 4s (৪+০ = ৪) আগে, 3d (৩+২ = ৫) পরে; আবার 3d ও 4p দুটোরই n + l = ৫, কিন্তু 3d-এর n ছোট বলে 3d আগে।',
  html() {
    const L = [['1s', 1, 0], ['2s', 2, 0], ['2p', 2, 1], ['3s', 3, 0], ['3p', 3, 1], ['4s', 4, 0], ['3d', 3, 2], ['4p', 4, 1], ['5s', 5, 0], ['4d', 4, 2], ['5p', 5, 1], ['6s', 6, 0], ['4f', 4, 3]];
    const W = 340, rowH = 19.5;
    return X.svg(W, 300, `<defs>${X.arrow('eoA')}</defs><line x1="18" y1="285" x2="18" y2="14" class="s-fg" marker-end="url(#eoA)"/><text x="12" y="150" transform="rotate(-90 12 150)" text-anchor="middle" style="font-size:12px">শক্তি</text>
      ${L.map(([s, n, l], i) => { const y = 280 - i * rowH; const k = 2 * l + 1; return `<text x="32" y="${y + 4}" class="mono" style="font-size:12px">${s}</text>${Array.from({ length: k }, (_, j) => `<rect x="${64 + j * 18}" y="${y - 7}" width="15" height="14" rx="2" class="f-sf s-ln"/>`).join('')}<text x="${64 + 7 * 18 + 10}" y="${y + 4}" class="tm mono">n+l = ${n}+${l} = ${n + l}</text>`; }).join('')}
      <text x="336" y="14" text-anchor="end" class="tm">প্রতি বাক্স = ১টি অরবিটাল</text>`, 'শক্তিক্রম');
  }
};
V.orbitVsOrbital = {
  t: 'অরবিট বনাম অরবিটাল', k: ['2d'],
  cap: 'অরবিট (বোর): নিউক্লিয়াসকে ঘিরে নির্দিষ্ট দ্বিমাত্রিক বৃত্তাকার পথ — ইলেকট্রনের অবস্থান নিশ্চিতভাবে জানা যায় বলে ধরা হয়, যা হাইজেনবার্গের অনিশ্চয়তা নীতির বিরোধী। অরবিটাল: ত্রিমাত্রিক অঞ্চল যেখানে ইলেকট্রন পাওয়ার সম্ভাবনা সর্বোচ্চ (প্রায় ৯০–৯৫%)।',
  html() {
    const r = X.rng(11); let dots = '';
    for (let i = 0; i < 420; i++) { const a = r() * 6.283, d = -Math.log(1 - r() * 0.97) * 22; if (d > 78) continue; dots += `<circle cx="${(300 + d * Math.cos(a)).toFixed(1)}" cy="${(110 + d * Math.sin(a)).toFixed(1)}" r="1.4" class="f-acc" opacity=".65"/>`; }
    return X.svg(400, 230, `<circle cx="100" cy="110" r="70" fill="none" class="s-acc" stroke-width="2"/><circle cx="100" cy="110" r="6" class="f-a2"/><circle cx="170" cy="110" r="6" class="f-acc"/>
      <text x="100" y="208" text-anchor="middle" style="font-size:13px" class="tb">অরবিট (Orbit)</text><text x="100" y="224" text-anchor="middle" class="tm">নির্দিষ্ট বৃত্তাকার পথ, ২D</text>
      ${dots}<circle cx="300" cy="110" r="70" fill="none" class="s-mu" stroke-dasharray="4 4"/><circle cx="300" cy="110" r="5" class="f-a2"/>
      <text x="300" y="208" text-anchor="middle" style="font-size:13px" class="tb">অরবিটাল (Orbital)</text><text x="300" y="224" text-anchor="middle" class="tm">সম্ভাব্যতার মেঘ, ৩D (১s)</text>
      <line x1="200" y1="20" x2="200" y2="200" class="s-ln" stroke-dasharray="3 4"/>`, 'অরবিট ও অরবিটাল');
  }
};

/* ======================= 2.4 ======================= */
V.aufbauDiag = {
  t: 'আউফবাউ নীতির কর্ণ চিত্র (মোয়েলার চিত্র)', k: ['2d'],
  cap: 'তির্যক তীর অনুসরণ করে উপরে থেকে নিচে পড়ো: 1s → 2s → 2p → 3s → 3p → 4s → 3d → 4p → 5s → 4d → 5p → 6s → 4f → 5d → 6p → 7s → 5f → 6d → 7p। এটি (n + l) নিয়মের সহজ রূপ।',
  html() {
    const rows = [['1s'], ['2s', '2p'], ['3s', '3p', '3d'], ['4s', '4p', '4d', '4f'], ['5s', '5p', '5d', '5f'], ['6s', '6p', '6d'], ['7s', '7p']];
    const x = j => 60 + j * 70, y = i => 28 + i * 36;
    let t = rows.map((r, i) => r.map((s, j) => `<rect x="${x(j) - 20}" y="${y(i) - 13}" width="40" height="24" rx="6" class="f-s2 s-ln"/><text x="${x(j)}" y="${y(i) + 4}" text-anchor="middle" class="mono" style="font-size:13px">${s}</text>`).join('')).join('');
    let arr = '';
    const diag = []; for (let s = 0; s <= 12; s++) { const cells = []; for (let i = 0; i < 7; i++) for (let j = 0; j < 4; j++) if (rows[i][j] && i + j === s) cells.push([i, j]); if (cells.length) diag.push(cells.sort((a, b) => b[1] - a[1])); }
    arr = diag.map(cells => { const a = cells[0], b = cells[cells.length - 1]; const x1 = x(a[1]) + 26, y1 = y(a[0]) - 18, x2 = x(b[1]) - 24, y2 = y(b[0]) + 16; return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="var(--accent)" stroke-width="1.6" opacity=".75" marker-end="url(#auA)"/>`; }).join('');
    return X.svg(340, 280, `<defs>${X.arrowC('auA', 'var(--accent)')}</defs>${arr}${t}`, 'আউফবাউ চিত্র');
  }
};

V.fillSim = {
  t: 'অ্যানিমেশন: অরবিটাল পূরণ (আউফবাউ + হুন্ড + পাউলি)', k: ['anim', 'int'],
  cap: 'প্রতিটি ইলেকট্রন সর্বনিম্ন শক্তির খালি জায়গায় বসে (আউফবাউ), সমশক্তির অরবিটালে আগে একটি একটি করে সমান্তরাল স্পিনে বসে (হুন্ড), এবং একটি অরবিটালে বিপরীত স্পিনের সর্বোচ্চ দুটি (পাউলি)। Cr (২৪) ও Cu (২৯)-এ ব্যতিক্রমটি লক্ষ করো।',
  html: () => `<div class="ctl" style="margin:0 0 8px"><label style="flex:none">মৌল</label><select class="inp" data-z>${X.EL.map((e, i) => `<option value="${i + 1}" ${i === 25 ? 'selected' : ''}>${X.bn(i + 1)} ${e[0]} — ${e[1]}</option>`).join('')}</select><button class="btn sm primary" data-play>${X.ico('play')}পূরণ দেখাও</button><button class="btn sm" data-step>এক ধাপ</button></div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const svgBox = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    let Z = 26, k = 0, exc = false, timer = null;
    const SUB = [['1s', 1], ['2s', 1], ['2p', 3], ['3s', 1], ['3p', 3], ['4s', 1], ['3d', 5], ['4p', 3]];
    const occN = (n, ex) => { const o = {}; let left = n; for (const [s, c] of X.ORDER) { const kk = Math.min(c, Math.max(0, left)); o[s] = kk; left -= kk; } if (ex && n === 24) { o['4s'] = 1; o['3d'] = 5; } if (ex && n === 29) { o['4s'] = 1; o['3d'] = 10; } return o; };
    const draw = () => {
      const o = occN(k, exc); const rowH = 34, W = 400, H = SUB.length * rowH + 20;
      let s = `<defs>${X.arrow('fsA')}</defs><line x1="16" y1="${H - 8}" x2="16" y2="10" class="s-fg" marker-end="url(#fsA)"/><text x="10" y="${H / 2}" transform="rotate(-90 10 ${H / 2})" text-anchor="middle" class="tm">শক্তি</text>`;
      SUB.forEach(([name, orbs], i) => {
        const y = H - 20 - i * rowH; const e = o[name] || 0;
        s += `<text x="30" y="${y + 5}" class="mono" style="font-size:13px">${name}</text>`;
        for (let j = 0; j < orbs; j++) {
          const x = 64 + j * 36; const n = (j < e ? 1 : 0) + (j + orbs < e ? 1 : 0);
          s += `<rect x="${x}" y="${y - 13}" width="32" height="26" rx="4" class="f-sf s-ln" ${n ? 'style="stroke:var(--accent)"' : ''}/>`;
          if (n >= 1) s += `<path d="M${x + 11} ${y + 9} L${x + 11} ${y - 8} M${x + 7} ${y - 3} L${x + 11} ${y - 9} L${x + 15} ${y - 3}" class="s-acc" stroke-width="2" fill="none"/>`;
          if (n === 2) s += `<path d="M${x + 21} ${y - 9} L${x + 21} ${y + 8} M${x + 17} ${y + 3} L${x + 21} ${y + 9} L${x + 25} ${y + 3}" class="s-a2" stroke-width="2" fill="none"/>`;
        }
        if (e) s += `<text x="${64 + orbs * 36 + 8}" y="${y + 5}" class="tm mono">${name}${X.sup(e)}</text>`;
      });
      svgBox.innerHTML = X.svg(W, H, s, 'অরবিটাল পূরণ');
      const parts = Object.entries(o).filter(([, v]) => v);
      const msg = (k === Z && (Z === 24 || Z === 29)) ? (exc ? `<br><b style="color:var(--ok)">ব্যতিক্রম প্রয়োগ হয়েছে:</b> একটি 4s ইলেকট্রন 3d-তে গেছে → ${Z === 24 ? '3d⁵ (অর্ধপূর্ণ)' : '3d¹⁰ (পূর্ণ)'} বেশি স্থিতিশীল (প্রতিসাম্য ও বেশি বিনিময় শক্তি)।` : '<br><b style="color:var(--bad)">আউফবাউ অনুযায়ী বিন্যাস — কিন্তু প্রকৃত বিন্যাস আলাদা! আরেক ধাপ চাপো।</b>') : '';
      out.innerHTML = `${k ? X.EL[k - 1][0] : '—'} (ইলেকট্রন ${X.bn(k)}/${X.bn(Z)}): <b class="mono">${parts.map(([a, b]) => a + X.sup(b)).join(' ') || '—'}</b>${k === Z ? `<br>শক্তিস্তর ক্রমে: <span class="mono">${X.cfg(Z, 'n', exc || (Z !== 24 && Z !== 29))}</span> · সংক্ষেপে ${X.core(Z)} · অযুগ্ম ইলেকট্রন ${X.bn((exc || (Z !== 24 && Z !== 29)) ? X.unpaired(Z) : (Z === 24 ? 4 : 1))}` : ''}${msg}`;
    };
    const step = () => { if (k < Z) { k++; exc = false; } else if ((Z === 24 || Z === 29) && !exc) exc = true; else { stop(); return false; } draw(); return true; };
    const stop = () => { clearInterval(timer); timer = null; el.querySelector('[data-play]').innerHTML = X.ico('play') + 'পূরণ দেখাও'; };
    el.querySelector('[data-z]').addEventListener('change', e => { stop(); Z = +e.target.value; k = Z; exc = true; draw(); });
    el.querySelector('[data-step]').onclick = () => { stop(); if (k >= Z && (exc || (Z !== 24 && Z !== 29))) { k = 0; exc = false; } step(); };
    el.querySelector('[data-play]').onclick = () => { if (timer) { stop(); return; } if (k >= Z) { k = 0; exc = false; } el.querySelector('[data-play]').innerHTML = X.ico('pause') + 'থামাও'; timer = setInterval(() => { if (!step()) stop(); }, X.rm() ? 60 : 380); };
    k = Z; exc = true; draw();
    return () => clearInterval(timer);
  }
};

V.hundPauli = {
  t: 'হুন্ডের নীতি ও পাউলির বর্জন নীতি: সঠিক বনাম ভুল', k: ['2d'],
  cap: 'হুন্ড: সমশক্তির (ডিজেনারেট) অরবিটালে জোড় বাঁধার আগে প্রতিটিতে একটি করে সমান্তরাল স্পিনের ইলেকট্রন বসে। পাউলি: একটি অরবিটালে দুটি ইলেকট্রন থাকলে তাদের স্পিন অবশ্যই বিপরীত — কারণ কোনো দুটি ইলেকট্রনের চারটি কোয়ান্টাম সংখ্যাই এক হতে পারে না।',
  html() {
    const up = (x, y, c = 'var(--accent)') => `<path d="M${x} ${y + 9} L${x} ${y - 8} M${x - 4} ${y - 3} L${x} ${y - 9} L${x + 4} ${y - 3}" stroke="${c}" stroke-width="2" fill="none"/>`;
    const dn = (x, y, c = 'var(--accent-2)') => `<path d="M${x} ${y - 9} L${x} ${y + 8} M${x - 4} ${y + 3} L${x} ${y + 9} L${x + 4} ${y + 3}" stroke="${c}" stroke-width="2" fill="none"/>`;
    const boxes = (x, y, n, fill) => Array.from({ length: n }, (_, i) => `<rect x="${x + i * 30}" y="${y - 13}" width="28" height="26" rx="4" class="f-sf s-ln"/>`).join('') + fill;
    const ok = (x, y) => `<circle cx="${x}" cy="${y}" r="9" fill="var(--ok)"/><path d="M${x - 4} ${y} l3 3 l5 -6" stroke="#fff" stroke-width="2" fill="none"/>`;
    const no = (x, y) => `<circle cx="${x}" cy="${y}" r="9" fill="var(--bad)"/><path d="M${x - 3.5} ${y - 3.5} l7 7 m0 -7 l-7 7" stroke="#fff" stroke-width="2"/>`;
    return X.svg(400, 250, `
      <text x="8" y="18" class="tb" style="font-size:13px">হুন্ডের নীতি — নাইট্রোজেন (2p³)</text>
      ${boxes(20, 46, 3, up(30, 46) + up(60, 46) + up(90, 46))}${ok(128, 46)}<text x="20" y="74" class="tm">সঠিক: ↑ ↑ ↑ (সমান্তরাল)</text>
      ${boxes(160, 46, 3, up(170, 46) + dn(180, 46) + up(200, 46))}${no(268, 46)}<text x="160" y="74" class="tm">ভুল: আগেই জোড়</text>
      ${boxes(290, 46, 3, up(300, 46) + dn(330, 46) + up(360, 46))}${no(390, 32)}<text x="290" y="74" class="tm">ভুল: স্পিন অসমান্তরাল</text>
      <line x1="0" y1="92" x2="400" y2="92" class="s-ln" stroke-dasharray="4 4"/>
      <text x="8" y="114" class="tb" style="font-size:13px">পাউলির বর্জন নীতি — একটি অরবিটাল</text>
      ${boxes(20, 142, 1, up(29, 142) + dn(39, 142))}${ok(68, 142)}<text x="20" y="170" class="tm">↑↓ বিপরীত স্পিন</text>
      ${boxes(160, 142, 1, up(169, 142) + up(179, 142, 'var(--accent)'))}${no(208, 142)}<text x="160" y="170" class="tm">↑↑ চারটি সংখ্যাই এক</text>
      ${boxes(310, 142, 1, up(316, 142) + dn(324, 142) + up(332, 142))}${no(360, 142)}<text x="300" y="170" class="tm">৩টি e⁻ অসম্ভব</text>
      <line x1="0" y1="188" x2="400" y2="188" class="s-ln" stroke-dasharray="4 4"/>
      <text x="8" y="208" class="tb" style="font-size:13px">আউফবাউ — পটাশিয়াম (Z = 19)</text>
      <text x="8" y="230" class="mono" style="font-size:12.5px">…3p⁶ 4s¹ ✔  (4s: n+l = 4 &lt; 3d: n+l = 5)</text>
      <text x="8" y="246" class="mono tm" style="font-size:12px">…3p⁶ 3d¹ ✘</text>`, 'হুন্ড ও পাউলি');
  }
};

V.configTable = {
  t: 'প্রথম ৩০টি মৌলের ইলেকট্রন বিন্যাস (সারণি)', k: ['info'],
  cap: 'লাল দাগানো দুটি সারি (Cr, Cu) ব্যতিক্রম। শক্তিস্তর ক্রমে লেখা হয়েছে (3d আগে, 4s পরে) — পূরণের ক্রমে কিন্তু 4s আগে পূরণ হয়। আয়ন তৈরির সময় আগে 4s থেকে ইলেকট্রন সরে যায় (Fe²⁺ = [Ar] 3d⁶)।',
  html() {
    const rows = X.EL.map((e, i) => { const Z = i + 1, sp = Z === 24 || Z === 29; return `<tr ${sp ? 'style="background:var(--bad-soft)"' : ''}><td class="c mono">${Z}</td><td><b>${e[0]}</b></td><td>${e[1]}</td><td class="mono" style="white-space:nowrap">${X.cfg(Z, 'n')}</td><td class="mono" style="white-space:nowrap">${X.core(Z)}</td><td class="mono c">${X.shells(Z).join(', ')}</td><td class="c">${X.unpaired(Z)}</td></tr>`; }).join('');
    return `<div class="table-wrap" style="margin:0;max-height:440px;overflow:auto"><table class="t" style="min-width:640px"><thead><tr><th class="c">Z</th><th>প্রতীক</th><th>নাম</th><th>ইলেকট্রন বিন্যাস</th><th>সংক্ষিপ্ত রূপ</th><th class="c">K, L, M, N</th><th class="c">অযুগ্ম e⁻</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }
};
})();
/* radial probability distribution (2.2.1) */
(function () {
const V = window.VIS, X = window.VX;
const RF = {
  '1s': r => 2 * Math.exp(-r), '2s': r => (2 - r) * Math.exp(-r / 2) / (2 * Math.SQRT2), '2p': r => r * Math.exp(-r / 2) / (2 * Math.sqrt(6)),
  '3s': r => 2 * (27 - 18 * r + 2 * r * r) * Math.exp(-r / 3) / (81 * Math.sqrt(3)), '3p': r => 4 * r * (6 - r) * Math.exp(-r / 3) / (81 * Math.sqrt(6)), '3d': r => 4 * r * r * Math.exp(-r / 3) / (81 * Math.sqrt(30))
};
const COL = { '1s': 'var(--accent)', '2s': 'var(--accent)', '2p': 'var(--accent-2)', '3s': 'var(--accent)', '3p': 'var(--accent-2)', '3d': '#2f9e6f' };
V.radialDist = {
  t: 'রেডিয়াল সম্ভাব্যতা বণ্টন: নিউক্লিয়াস থেকে কত দূরে ইলেকট্রন পাওয়ার সম্ভাবনা বেশি', k: ['2d', 'int'],
  cap: 'উল্লম্ব অক্ষে 4πr²ψ² — নিউক্লিয়াস থেকে r দূরত্বে পাতলা গোলীয় খোলসে ইলেকট্রন পাওয়ার সম্ভাবনা। ১s-এর সর্বোচ্চ বিন্দু ঠিক r = a₀ = 0.529 Å, অর্থাৎ বোর ব্যাসার্ধে! বক্ররেখা যেখানে শূন্য ছুঁয়েছে সেগুলো রেডিয়াল নোড (n − l − 1টি)।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('set', [['1', '১s'], ['2', '২s ও ২p'], ['3', '৩s, ৩p, ৩d']], '2')}</div><div data-plot></div>`,
  mount(el) {
    const box = el.querySelector('[data-plot]');
    const draw = set => {
      const keys = set === '1' ? ['1s'] : set === '2' ? ['2s', '2p'] : ['3s', '3p', '3d'];
      const rmax = set === '1' ? 6 : set === '2' ? 14 : 26;
      let pmax = 0; keys.forEach(k => { for (let i = 1; i <= 400; i++) { const r = i / 400 * rmax, v = r * r * RF[k](r) ** 2; if (v > pmax) pmax = v; } });
      const x = r => 44 + r / rmax * 340, y = v => 200 - v / pmax * 172;
      let s = `<line x1="44" y1="200" x2="388" y2="200" class="s-fg"/><line x1="44" y1="200" x2="44" y2="18" class="s-fg"/>`;
      const step = rmax <= 6 ? 1 : rmax <= 14 ? 2 : 4;
      for (let r = 0; r <= rmax; r += step) s += `<line x1="${x(r)}" y1="200" x2="${x(r)}" y2="204" class="s-fg"/><text x="${x(r)}" y="218" text-anchor="middle" class="tm">${X.bn(r)}</text>`;
      s += `<text x="216" y="236" text-anchor="middle" style="font-size:12.5px">r (a₀ এককে; 1 a₀ = 0.529 Å)</text><text x="14" y="110" transform="rotate(-90 14 110)" text-anchor="middle" style="font-size:12.5px">4πr²ψ²</text>`;
      keys.forEach((k, i) => {
        let d = ''; let best = [0, 0];
        for (let j = 0; j <= 500; j++) { const r = j / 500 * rmax, v = r * r * RF[k](r) ** 2; if (v > best[1]) best = [r, v]; d += (j ? 'L' : 'M') + x(r).toFixed(1) + ' ' + y(v).toFixed(1); }
        s += `<path d="${d}" fill="none" stroke="${COL[k]}" stroke-width="2.4" ${k[1] === 'p' && keys.length > 2 ? 'stroke-dasharray="6 3"' : ''}/>`;
        s += `<text x="${Math.min(360, x(best[0]) + 6)}" y="${y(best[1]) - 6}" style="font-size:13px;font-weight:600;fill:${COL[k]}">${X.bn(k[0])}${k[1]}</text>`;
      });
      if (set === '1') s += `<line x1="${x(1)}" y1="200" x2="${x(1)}" y2="28" class="s-mu" stroke-dasharray="4 4"/><text x="${x(1) + 6}" y="40" class="tm">r = a₀ (বোর ব্যাসার্ধ)</text>`;
      if (set === '2') s += `<circle cx="${x(2)}" cy="200" r="4" fill="var(--bad)"/><text x="${x(2) + 6}" y="192" style="font-size:11.5px;fill:var(--bad)">২s এর নোড (r = 2a₀)</text>`;
      if (set === '3') { const n1 = (9 - Math.sqrt(27)) / 2, n2 = (9 + Math.sqrt(27)) / 2; [n1, n2, 6].forEach(r => s += `<circle cx="${x(r)}" cy="200" r="3.5" fill="var(--bad)"/>`); s += `<text x="${x(n2) + 6}" y="192" style="font-size:11.5px;fill:var(--bad)">লাল বিন্দু = রেডিয়াল নোড</text>`; }
      box.innerHTML = X.svg(400, 244, s, 'রেডিয়াল বণ্টন');
    };
    X.onSeg(el, 'set', draw); draw('2');
  }
};
})();

