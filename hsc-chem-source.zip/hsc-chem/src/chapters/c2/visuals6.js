/* Visuals part 6 — solvent extraction (2.17), chromatography (2.18), importance (2.19) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;
const f1 = v => (+v).toFixed(1);

/* ======================= 2.17 পৃথকীকরণ ফানেলে দ্রাবক নিষ্কাশন ======================= */
V.sepFunnel = {
  t: 'পৃথকীকরণ ফানেল: পানি থেকে আয়োডিন নিষ্কাশন (CCl₄)', k: ['anim', 'int'],
  cap: 'ধাপগুলো ক্রমে করো: CCl₄ যোগ → ঝাঁকাও → স্টপকক খুলে বায়ু বের করো → স্থির হতে দাও → নিচের স্তর বের করো। CCl₄ পানির চেয়ে ভারী (ঘনত্ব ১.৫৯ g/mL), তাই নিচে থাকে; আয়োডিন CCl₄ এ বেগুনি, পানিতে হলদে-বাদামি। বণ্টন সহগ K<sub>D</sub> = [I₂]<sub>CCl₄</sub>/[I₂]<sub>পানি</sub> ≈ ৮৫ (২৫°C)। একই দ্রাবক কয়েক ভাগে ভাগ করে বারবার নিষ্কাশন করলে বেশি দ্রব আলাদা হয়।',
  html: () => `<div data-svg></div><div class="ctl"><button class="btn sm" data-a="add">CCl₄ যোগ (১০ mL)</button><button class="btn sm" data-a="shake">ঝাঁকাও</button><button class="btn sm" data-a="vent">বায়ু বের করো</button><button class="btn sm" data-a="drain">নিচের স্তর বের করো</button><button class="btn sm" data-a="reset">নতুন করে</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const K = 85, Vaq = 50, Vo = 10, M0 = 100;
    let aq = M0, org = 0, vol = 0, col = 0, n = 0, pres = 0, mixed = false, shaking = 0, ang = 0, msg = 'শুরু: ৫০ mL পানিতে ১০০ mg I₂ দ্রবীভূত। প্রথমে CCl₄ যোগ করো।';
    const body = 'M162 40 C130 70 118 110 130 140 C140 165 160 185 166 200 L174 200 C180 185 200 165 210 140 C222 110 210 70 178 40Z';
    const draw = () => {
      const hO = vol ? vol * 1.9 : 0, hA = Vaq * 1.5, topA = 200 - hO - hA;
      const aA = (0.08 + 0.75 * aq / M0).toFixed(3), aO = vol ? (0.12 + 0.8 * Math.min(1, org / vol / 8)).toFixed(3) : 0;
      let liq;
      if (mixed && shaking > 0) { const r = X.rng(Math.abs(Math.floor(ang * 10)) + 3); liq = `<rect x="110" y="${f1(topA)}" width="120" height="${f1(hA + hO)}" fill="rgba(180,130,60,.35)"/>`; for (let i = 0; i < 40; i++) liq += `<circle cx="${f1(124 + r() * 92)}" cy="${f1(topA + 4 + r() * (hA + hO - 8))}" r="${f1(2 + r() * 2.5)}" fill="rgba(142,68,173,.6)"/>`; }
      else liq = `<rect x="110" y="${f1(topA)}" width="120" height="${f1(hA)}" fill="rgba(196,132,40,${aA})"/>` + (vol ? `<rect x="110" y="${f1(200 - hO)}" width="120" height="${f1(hO + 2)}" fill="rgba(142,68,173,${aO})"/><line x1="110" y1="${f1(200 - hO)}" x2="230" y2="${f1(200 - hO)}" class="s-mu" stroke-width="1"/>` : '');
      let s = `<defs><clipPath id="sfB"><path d="${body}"/></clipPath></defs>`;
      s += `<line x1="60" y1="20" x2="60" y2="290" class="s-mu" stroke-width="4"/><line x1="60" y1="120" x2="120" y2="120" class="s-mu" stroke-width="3"/>`;
      s += `<g transform="rotate(${f1(ang)} 170 120)"><g clip-path="url(#sfB)">${liq}</g><path d="${body}" fill="rgba(210,225,240,.18)" class="s-fg" stroke-width="2"/><rect x="161" y="26" width="18" height="14" rx="3" class="f-mu"/><rect x="166" y="200" width="8" height="10" class="s-fg" fill="none"/><line x1="170" y1="210" x2="170" y2="238" class="s-fg" stroke-width="4"/><rect x="156" y="201" width="28" height="7" rx="3" fill="#7a6b5d" transform="rotate(${shaking || mixed ? 0 : 0} 170 204)"/></g>`;
      s += `<path d="M138 244 L138 292 L202 292 L202 244" fill="none" class="s-fg" stroke-width="2"/>`;
      if (col > 0 || n > 0) { const hc = Math.min(44, n * 9); s += `<rect x="139.5" y="${f1(291 - hc)}" width="61" height="${f1(hc)}" fill="rgba(142,68,173,${(0.2 + 0.7 * Math.min(1, col / M0)).toFixed(2)})"/>`; }
      s += `<text x="210" y="290" class="tm" style="font-size:10px">সংগৃহীত CCl₄ স্তর</text>`;
      s += `<text x="236" y="${f1(topA + hA / 2)}" class="tm" style="font-size:10px">পানির স্তর</text>` + (vol ? `<text x="236" y="${f1(200 - hO / 2 + 4)}" class="tm" style="font-size:10px">CCl₄ স্তর</text>` : '') + `<text x="186" y="34" class="tm" style="font-size:10px">ছিপি</text><text x="190" y="214" class="tm" style="font-size:10px">স্টপকক</text>`;
      const ph = Math.min(1, pres / 3); s += `<rect x="330" y="40" width="22" height="120" rx="6" class="f-s2 s-ln"/><rect x="332" y="${f1(158 - 116 * ph)}" width="18" height="${f1(116 * ph)}" rx="5" fill="${ph > 0.66 ? '#e5484d' : ph > 0.33 ? '#f59e0b' : '#22c55e'}"/><text x="341" y="176" text-anchor="middle" class="tm" style="font-size:10px">ভেতরের</text><text x="341" y="189" text-anchor="middle" class="tm" style="font-size:10px">চাপ</text>`;
      box.innerHTML = X.svg(400, 300, s, 'পৃথকীকরণ ফানেল');
      out.innerHTML = `${msg}<br><span class="small">পানিতে I₂: <b>${aq.toFixed(1)} mg</b> · ফানেলের CCl₄ স্তরে: <b>${org.toFixed(1)} mg</b> · সংগৃহীত: <b>${col.toFixed(1)} mg</b> · নিষ্কাশন: ${X.bn(n)} বার</span>`;
    };
    let tm = null;
    const act = a => {
      if (shaking) return;
      if (a === 'reset') { aq = M0; org = 0; vol = 0; col = 0; n = 0; pres = 0; mixed = false; ang = 0; msg = 'শুরু: ৫০ mL পানিতে ১০০ mg I₂ দ্রবীভূত। প্রথমে CCl₄ যোগ করো।'; }
      else if (a === 'add') { if (vol) msg = 'ফানেলে আগেই CCl₄ আছে — আগে ঝাঁকিয়ে নিচের স্তর বের করো।'; else { vol = Vo; msg = '১০ mL CCl₄ যোগ হলো — ভারী বলে নিচে আলাদা স্তর। এখনো আয়োডিন পানিতে, কারণ দুই স্তর মেশেনি। ছিপি এঁটে ঝাঁকাও।'; } }
      else if (a === 'shake') {
        if (!vol) { msg = 'আগে CCl₄ যোগ করো।'; draw(); return; }
        if (pres >= 2) { msg = '<b style="color:var(--bad)">সতর্কতা:</b> ভেতরে বাষ্পচাপ বেশি জমেছে! আগে স্টপকক খুলে বায়ু বের করো — নইলে ছিপি ছিটকে দ্রাবক গায়ে পড়তে পারে।'; draw(); return; }
        mixed = true; shaking = 1; let t = 0;
        tm = setInterval(() => { t += 0.05; ang = Math.sin(t * 14) * 28 * (1 - t / 1.6) - 0 ; draw(); if (t >= 1.6) { clearInterval(tm); shaking = 0; ang = 0; pres += 1.5; const tot = aq + org; org = tot * K * vol / (Vaq + K * vol); aq = tot - org; mixed = false; msg = `ঝাঁকানোর ফলে দুই স্তরের সংস্পর্শ বেড়েছে, আয়োডিন বণ্টিত হয়েছে: [I₂]<sub>CCl₄</sub>/[I₂]<sub>পানি</sub> = (${org.toFixed(1)}/${vol})/(${aq.toFixed(1)}/${Vaq}) = <b>${((org / vol) / (aq / Vaq)).toFixed(0)}</b> = K<sub>D</sub>। ${pres >= 2 ? '<b>এখন বায়ু বের করো।</b>' : 'উদ্বায়ী দ্রাবকের বাষ্পে ভেতরে চাপ বাড়ছে — বায়ু বের করো।'}`; draw(); } }, 50);
        return;
      }
      else if (a === 'vent') { if (pres > 0) { pres = 0; msg = 'ফানেল উল্টো করে (নল উপরে, মানুষের দিক থেকে দূরে) স্টপকক খুলে বাষ্প বের করা হলো — চাপ স্বাভাবিক।'; } else msg = 'এখন চাপ স্বাভাবিক; ঝাঁকানোর পর বায়ু বের করতে হয়।'; }
      else if (a === 'drain') { if (!vol) msg = 'বের করার মতো CCl₄ স্তর নেই।'; else if (org === 0 && aq === M0) msg = 'আগে ঝাঁকাও — না ঝাঁকালে আয়োডিন CCl₄ এ যায়নি।'; else { col += org; org = 0; vol = 0; n++; msg = `ছিপি খুলে স্টপকক দিয়ে নিচের বেগুনি CCl₄ স্তর বের করা হলো। পানিতে অবশিষ্ট I₂ মূলের <b>${(aq / M0 * 100).toFixed(2)}%</b>। আবার CCl₄ যোগ করে নিষ্কাশন করলে আরও কমবে: অবশিষ্ট ভগ্নাংশ = [V<sub>পানি</sub>/(V<sub>পানি</sub> + K<sub>D</sub>V<sub>CCl₄</sub>)]ⁿ = (${Vaq}/${Vaq + K * Vo})<sup>${n}</sup>।`; } }
      draw();
    };
    el.querySelectorAll('[data-a]').forEach(b => b.onclick = () => act(b.dataset.a));
    draw();
    return () => clearInterval(tm);
  }
};

V.extCalc = {
  t: 'একবারে নাকি কয়েক ভাগে? নিষ্কাশন ক্যালকুলেটর', k: ['calc'],
  cap: 'বণ্টন সূত্র থেকে, Vₐ আয়তনের জলীয় দ্রবণ থেকে V₀ আয়তনের জৈব দ্রাবক দিয়ে n বার নিষ্কাশনের পর পানিতে অবশিষ্ট দ্রবের ভর: mₙ = m₀ [Vₐ/(Vₐ + K<sub>D</sub>V₀)]ⁿ। মোট একই পরিমাণ দ্রাবক কয়েক ভাগে ভাগ করে বারবার নিষ্কাশন করলে সবসময় বেশি দ্রব আলাদা হয়।',
  html: () => `<div class="grid3">${X.fld('K<sub>D</sub> (জৈব/পানি)', 'data-k', 10)}${X.fld('জলীয় দ্রবণ (mL)', 'data-va', 100)}${X.fld('মোট দ্রাবক (mL)', 'data-vo', 30)}</div><div class="grid2" style="margin-top:8px">${X.fld('কয় ভাগে (n)', 'data-n', 3)}${X.fld('প্রাথমিক দ্রব (g)', 'data-m', 1)}</div><div data-svg style="margin-top:8px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), q = s => +el.querySelector(s).value;
    const run = () => {
      const K = Math.max(0.01, q('[data-k]') || 1), Va = Math.max(1, q('[data-va]') || 1), Vo = Math.max(0.1, q('[data-vo]') || 1), n = Math.min(10, Math.max(1, Math.round(q('[data-n]') || 1))), m0 = Math.max(0, q('[data-m]') || 0);
      const f1x = Va / (Va + K * Vo), fn = Math.pow(Va / (Va + K * Vo / n), n);
      const e1 = (1 - f1x) * 100, en = (1 - fn) * 100;
      const bar = (y, lab, pct, c) => `<text x="4" y="${y + 15}" style="font-size:11px;font-weight:600">${lab}</text><rect x="150" y="${y}" width="230" height="22" rx="4" class="f-s2"/><rect x="150" y="${y}" width="${f1(2.3 * pct)}" height="22" rx="4" fill="${c}"/><text x="${f1(150 + Math.max(30, 2.3 * pct) - 4)}" y="${y + 15}" text-anchor="end" class="mono" style="font-size:11px;fill:#fff;font-weight:600">${pct.toFixed(1)}%</text>`;
      box.innerHTML = X.svg(400, 66, bar(6, `একবারে ${Vo} mL`, e1, '#94a3b8') + bar(38, `${X.bn(n)} বার × ${(Vo / n).toFixed(1)} mL`, en, '#3b82f6'), 'নিষ্কাশন তুলনা');
      let rows = '', m = m0; for (let i = 1; i <= n; i++) { const nm = m * Va / (Va + K * Vo / n); rows += `<tr><td>${X.bn(i)}</td><td class="mono">${(m - nm).toFixed(4)}</td><td class="mono">${nm.toFixed(4)}</td></tr>`; m = nm; }
      out.innerHTML = `একবারে: অবশিষ্ট = ${m0} × ${Va}/(${Va} + ${K}×${Vo}) = <b>${(m0 * f1x).toFixed(4)} g</b> → নিষ্কাশিত <b>${e1.toFixed(1)}%</b><br>${X.bn(n)} ভাগে: অবশিষ্ট = ${m0} × [${Va}/(${Va} + ${K}×${(Vo / n).toFixed(2)})]<sup>${n}</sup> = <b>${(m0 * fn).toFixed(4)} g</b> → নিষ্কাশিত <b>${en.toFixed(1)}%</b><div class="table-wrap" style="margin:6px 0 0"><table class="t sm"><thead><tr><th>ধাপ</th><th>নিষ্কাশিত (g)</th><th>পানিতে অবশিষ্ট (g)</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    };
    el.querySelectorAll('input').forEach(i => i.addEventListener('input', run)); run();
  }
};

/* ======================= 2.18 ক্রোমাটোগ্রাফির মূলনীতি ======================= */
V.chromaPrinciple = {
  t: 'ক্রোমাটোগ্রাফির মূলনীতি: স্থির ও চলমান দশা', k: ['anim', 'int'],
  cap: 'চলমান দশা (দ্রাবক) বাম থেকে ডানে প্রবাহিত হয়। প্রতিটি অণু বারবার স্থির দশায় আটকে যায় (অধিশোষণ বা দ্রবীভূতি) আবার ছাড়া পায়। যে উপাদানের স্থির দশার প্রতি আসক্তি কম (কমলা), সে বেশি সময় চলমান দশায় থাকে — দ্রুত এগোয়; যার আসক্তি বেশি (সবুজ), সে পিছিয়ে পড়ে। এভাবেই মিশ্রণ আলাদা ব্যান্ডে বিভক্ত হয়। স্লাইডার দিয়ে আসক্তির পার্থক্য বদলাও।',
  html: () => X.cv('ক্রোমাটোগ্রাফির অ্যানিমেশন') + `<div class="ctl"><label style="flex:none">আসক্তির পার্থক্য</label><input type="range" min="0" max="1" step="0.05" value="0.6" data-d style="flex:1"><button class="btn sm" data-rs>আবার চালাও</button><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const cv = el.querySelector('canvas'), hf = W => Math.min(230, W * 0.58); let L = X.fit(cv, hf);
    const out = el.querySelector('[data-out]'); let mol = [], t = 0, dif = 0.6;
    const init = () => { const r = X.rng(9); mol = []; for (let i = 0; i < 70; i++) ['A', 'B'].forEach(k => mol.push({ k, x: r() * 0.03, mob: r() < 0.5, y: r(), ph: r() * 6.28 })); t = 0; };
    const rates = k => { const fA = 0.5 + dif * 0.4, fB = 0.5 - dif * 0.4; const f = k === 'A' ? fA : fB; return { ps: 3 * (1 - f), pr: 3 * f, f }; };
    const info = () => { const a = rates('A').f, b = rates('B').f; out.innerHTML = `কমলা উপাদান সময়ের <b>${(a * 100).toFixed(0)}%</b> চলমান দশায় থাকে, সবুজ <b>${(b * 100).toFixed(0)}%</b>। গড় গতির অনুপাত ≈ এই ভগ্নাংশের অনুপাত — পেপার ক্রোমাটোগ্রাফিতে একেই R<sub>f</sub> মান হিসেবে মাপা হয় (কমলা ≈ ${a.toFixed(2)}, সবুজ ≈ ${b.toFixed(2)})। ${dif < 0.1 ? 'আসক্তি প্রায় সমান — পৃথক হয় না; অন্য দ্রাবক বা স্থির দশা লাগবে।' : ''}`; };
    init(); info();
    const r = X.rng(42);
    const A = X.anim(cv, dt => {
      const C = X.C(), g = L.g, W = L.W, H = L.H; g.clearRect(0, 0, W, H);
      const x0 = 14, x1 = W - 14, yM0 = H * 0.12, yM1 = H * 0.5, yS0 = H * 0.5, yS1 = H * 0.66, v = 0.12;
      t += dt;
      g.fillStyle = 'rgba(96,165,250,.12)'; g.fillRect(x0, yM0, x1 - x0, yM1 - yM0);
      g.fillStyle = 'rgba(148,128,100,.25)'; g.fillRect(x0, yS0, x1 - x0, yS1 - yS0);
      g.fillStyle = C.mu; g.font = `11px ${C.font}`; g.textAlign = 'left'; g.fillText('চলমান দশা (দ্রাবক) →', x0 + 4, yM0 - 3); g.fillText('স্থির দশা (সিলিকা / কাগজের পানি)', x0 + 4, yS1 + 13);
      const off = (t * 40) % 24; g.strokeStyle = 'rgba(59,130,246,.35)'; g.lineWidth = 1.2; for (let x = x0 + off; x < x1; x += 24) { g.beginPath(); g.moveTo(x, yM0 + 6); g.lineTo(x + 8, yM0 + 6); g.stroke(); }
      let done = false;
      mol.forEach(m => {
        const { ps, pr } = rates(m.k);
        if (dt > 0) { if (m.mob) { m.x += v * dt; if (r() < ps * dt) m.mob = false; } else if (r() < pr * dt) m.mob = true; }
        if (m.x > 0.97) { m.x = 0.97; done = true; }
        const px = x0 + m.x * (x1 - x0), py = m.mob ? yM0 + 8 + m.y * (yM1 - yM0 - 14) : yS0 + 3 + m.y * (yS1 - yS0 - 6);
        g.fillStyle = m.k === 'A' ? '#f08c2e' : '#22a35a'; g.beginPath(); g.arc(px, py, 3.2, 0, 6.283); g.fill();
      });
      const hist = k => { const b = new Array(40).fill(0); mol.forEach(m => { if (m.k === k) b[Math.min(39, Math.floor(m.x / 0.975 * 40))]++; }); return b; };
      const hy = H * 0.97, hs = (H * 0.24) / 18;
      [['A', '#f08c2e'], ['B', '#22a35a']].forEach(([k, c]) => { const b = hist(k); g.fillStyle = c + '99'; b.forEach((n, i) => { const bw = (x1 - x0) / 40; g.fillRect(x0 + i * bw, hy - Math.min(18, n) * hs, bw - 1, Math.min(18, n) * hs); }); });
      if (done) { A.pause(true); X.pp(el, A); }
    });
    X.pp(el, A);
    el.querySelector('[data-rs]').onclick = () => { init(); if (A.paused) A.pause(false); X.pp(el, A); A.draw(); };
    el.querySelector('[data-d]').addEventListener('input', e => { dif = +e.target.value; info(); init(); if (A.paused) A.pause(false); X.pp(el, A); A.draw(); });
    const ro = X.onResize(el, () => { L = X.fit(cv, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

/* ======================= 2.18.1 কলাম ক্রোমাটোগ্রাফি ======================= */
/* ======================= 2.18.1 উদ্ভিদের নির্যাস প্রস্তুতি ======================= */
const LXS = [
  ['পেষণ', 'কুচি করা তাজা পালং বা যেকোনো সবুজ পাতা, এক চিমটি পরিষ্কার বালু ও ৫–১০ mL অ্যাসিটোন খলে নিয়ে নুড়ি দিয়ে পেষা হয়। বালু কোষপ্রাচীর ভাঙতে সাহায্য করে; অ্যাসিটোন রঞ্জকগুলো (ক্যারোটিন, ক্লোরোফিল) দ্রবীভূত করে — দ্রবণ গাঢ় সবুজ হয়।'],
  ['ছাঁকন', 'মিশ্রণটি তুলা বা ফিল্টার কাগজে ছেঁকে পাতার কণা ও বালু আলাদা করা হয়। কাগজের নিচে গাঢ় সবুজ পরিস্রুত নির্যাস সংগ্রহ করা হয়।'],
  ['শুষ্ক ও ঘন করা', 'নির্যাসে অনার্দ্র Na₂SO₄ যোগ করে পাতা থেকে আসা পানি শোষণ করানো হয় (পানি থাকলে স্তম্ভে ব্যান্ড ছড়িয়ে যায়)। এরপর গরম পানির পাত্রে মৃদু উত্তাপে দ্রাবকের কিছু অংশ উড়িয়ে নির্যাস ঘন করা হয় — সরাসরি শিখা নয়, কারণ অ্যাসিটোন অত্যন্ত দাহ্য।'],
  ['স্তম্ভে প্রয়োগ', 'পেট্রোলিয়াম ইথারে ভেজানো অ্যালুমিনা বা সিলিকা জেলের স্তম্ভের মাথায় ড্রপার দিয়ে অল্প ঘন নির্যাস ধীরে দেওয়া হয়, যাতে একটি সরু সবুজ ব্যান্ড তৈরি হয়। এরপর ইলুশন শুরু — নিচের সিমুলেশনে দেখো কোন রঞ্জক আগে নামে।']
];
V.leafExtract = {
  t: 'উদ্ভিদের নির্যাস প্রস্তুতি: পেষণ থেকে স্তম্ভে প্রয়োগ', k: ['2d', 'int'],
  cap: 'কলাম ক্রোমাটোগ্রাফির আগে সবুজ পাতা থেকে রঞ্জকের নির্যাস তৈরির চারটি ধাপ। ওপরের বোতামে ধাপ বেছে নাও।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('st', LXS.map((x, i) => [String(i), X.bn(i + 1) + '. ' + x[0]]), '0')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const G = '#2f8f3a', GD = '#1d6a2b', LEAF = '#4caf50', SAND = '#d8b26e';
    const lab = (x, y, t, a = 'start') => `<text x="${x}" y="${y}" class="tm" text-anchor="${a}" style="font-size:11.5px">${t}</text>`;
    const ptr = (x1, y1, x2, y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="s-mu" stroke-width="1" stroke-dasharray="3 3"/>`;
    const bench = '<line x1="16" y1="200" x2="344" y2="200" class="s-ln" stroke-width="2"/>';
    const scenes = [
      () => {
        const r = X.rng(7); let bits = '';
        for (let i = 0; i < 14; i++) { const x = 132 + r() * 96, y = 132 + r() * 22; bits += `<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(4 + r() * 4).toFixed(1)}" ry="2.4" fill="${LEAF}" transform="rotate(${Math.round(r() * 180)} ${x.toFixed(1)} ${y.toFixed(1)})"/>`; }
        for (let i = 0; i < 22; i++) bits += `<circle cx="${(130 + r() * 100).toFixed(1)}" cy="${(140 + r() * 18).toFixed(1)}" r="1.6" fill="${SAND}"/>`;
        return `<path d="M104 122 Q180 222 256 122 Z" class="f-s3 s-fg" stroke-width="2"/><path d="M116 130 Q180 205 244 130 Z" fill="${G}" opacity=".78"/>${bits}
        <ellipse cx="180" cy="122" rx="76" ry="9" class="f-s2 s-fg" stroke-width="2"/><ellipse cx="180" cy="128" rx="62" ry="6" fill="${GD}" opacity=".85"/>
        <path d="M164 170 L154 210 L206 210 L196 170 Z" class="f-s3 s-fg" stroke-width="1.5"/>
        <line x1="236" y1="34" x2="196" y2="128" stroke="var(--muted)" stroke-width="13" stroke-linecap="round"/><line x1="236" y1="34" x2="196" y2="128" class="s-fg" stroke-width="1" opacity=".3"/>
        <rect x="290" y="128" width="30" height="66" rx="4" class="f-sf s-fg" stroke-width="1.5"/><rect x="298" y="114" width="14" height="14" class="f-s3 s-fg" stroke-width="1.5"/><rect x="292" y="150" width="26" height="42" rx="3" fill="rgba(160,200,255,.25)"/>
        ${lab(305, 108, 'অ্যাসিটোন', 'middle')}${lab(26, 92, 'খল ও নুড়ি')}${ptr(70, 96, 112, 124)}${lab(26, 176, 'পাতা + বালু')}${ptr(84, 172, 140, 148)}${lab(250, 64, 'নুড়ি')}${lab(180, 228, 'গাঢ় সবুজ নির্যাস তৈরি হচ্ছে', 'middle')}`;
      },
      () => `<line x1="80" y1="20" x2="80" y2="200" class="s-mu" stroke-width="4"/><line x1="80" y1="74" x2="140" y2="74" class="s-mu" stroke-width="3"/>
        <path d="M124 40 L236 40 L188 104 L172 104 Z" class="f-sf s-fg" stroke-width="2"/><path d="M134 46 L226 46 L182 100 L178 100 Z" fill="var(--surface-2)" stroke="var(--line-strong)" stroke-width="1.2"/>
        <path d="M146 60 L214 60 L182 98 L178 98 Z" fill="${G}" opacity=".7"/>
        ${(() => { const r = X.rng(11); let b = ''; for (let i = 0; i < 9; i++) b += `<ellipse cx="${(156 + r() * 48).toFixed(1)}" cy="${(64 + r() * 10).toFixed(1)}" rx="4" ry="2" fill="${LEAF}"/>`; for (let i = 0; i < 12; i++) b += `<circle cx="${(160 + r() * 40).toFixed(1)}" cy="${(70 + r() * 18).toFixed(1)}" r="1.5" fill="${SAND}"/>`; return b; })()}
        <rect x="174" y="104" width="12" height="40" class="f-sf s-fg" stroke-width="1.8"/>
        <circle cx="180" cy="152" r="3" fill="${G}" class="anim-drip"/>
        <path d="M150 162 L150 196 Q150 199 153 199 L207 199 Q210 199 210 196 L210 162" class="f-sf s-fg" stroke-width="2"/><rect x="152" y="178" width="56" height="19" fill="${G}" opacity=".75"/>
        ${lab(244, 52, 'ফিল্টার কাগজ')}${ptr(242, 48, 222, 50)}${lab(244, 84, 'পাতার কণা ও বালু')}${lab(244, 98, 'কাগজে আটকে থাকে')}${ptr(242, 80, 204, 70)}${lab(222, 186, 'পরিস্রুত নির্যাস')}${ptr(220, 182, 208, 186)}`,
      () => `<rect x="96" y="118" width="168" height="70" rx="4" fill="rgba(140,190,240,.28)" class="s-fg" stroke-width="2"/><rect x="88" y="188" width="184" height="10" rx="3" class="f-s3 s-fg" stroke-width="1.5"/>
        <path d="M168 60 L168 104 L140 160 Q136 170 146 170 L214 170 Q224 170 220 160 L192 104 L192 60" class="f-sf s-fg" stroke-width="2"/>
        <path d="M150 144 L210 144 L220 160 Q224 170 214 170 L146 170 Q136 170 140 160 Z" fill="${G}" opacity=".8"/>
        ${[0, 1, 2, 3, 4, 5, 6].map(i => `<rect x="${152 + i * 8}" y="${162 + (i % 2) * 3}" width="5" height="4" fill="#fff" stroke="var(--line-strong)" stroke-width=".6" transform="rotate(${i * 25} ${154 + i * 8} ${164})"/>`).join('')}
        ${[0, 1, 2].map(i => `<path class="anim-vap s-mu" style="animation-delay:${i * 0.6}s" d="M${172 + i * 8} 54 q-6 -10 0 -18 q6 -8 0 -16" fill="none" stroke-width="1.5"/>`).join('')}
        ${lab(232, 40, 'অ্যাসিটোনের বাষ্প')}${ptr(230, 36, 196, 40)}${lab(24, 100, 'গরম পানির পাত্র')}${lab(24, 114, '(খোলা শিখা নয়)')}${ptr(70, 118, 100, 132)}${lab(272, 144, 'অনার্দ্র')}${lab(272, 158, 'Na₂SO₄')}${lab(272, 172, '(শুষ্ককারক)')}${ptr(270, 154, 206, 165)}`,
      () => {
        let dots = ''; const r = X.rng(5); for (let i = 0; i < 70; i++) dots += `<circle cx="${(164 + r() * 32).toFixed(1)}" cy="${(96 + r() * 80).toFixed(1)}" r="1.1" class="f-mu" opacity=".45"/>`;
        return `<line x1="100" y1="16" x2="100" y2="200" class="s-mu" stroke-width="4"/><line x1="100" y1="120" x2="160" y2="120" class="s-mu" stroke-width="3"/>
        <rect x="162" y="38" width="36" height="148" rx="3" fill="rgba(160,200,255,.18)"/><rect x="162" y="96" width="36" height="84" class="f-s3"/>${dots}
        <rect x="162" y="90" width="36" height="6" fill="${SAND}"/><rect x="162" y="96" width="36" height="5" fill="${GD}" opacity=".9"/><rect x="162" y="180" width="36" height="6" fill="#eee" opacity=".9"/>
        <path d="M162 30 L162 186 L174 196 L186 196 L198 186 L198 30" fill="none" class="s-fg" stroke-width="2"/><rect x="176" y="196" width="8" height="10" class="f-sf s-fg" stroke-width="1.5"/><rect x="170" y="199" width="20" height="5" rx="2" class="f-mu"/>
        <path d="M176 6 L184 6 L183 30 L177 30 Z" class="f-sf s-fg" stroke-width="1.5"/><rect x="172" y="0" width="16" height="9" rx="3" class="f-mu"/><circle cx="180" cy="40" r="2.6" fill="${GD}" class="anim-drip"/>
        ${lab(214, 24, 'ড্রপারে ঘন নির্যাস')}${ptr(212, 20, 186, 14)}${lab(214, 66, 'পেট্রোলিয়াম ইথার')}${ptr(212, 62, 198, 72)}${lab(214, 90, 'বালুর পাতলা স্তর')}${ptr(212, 86, 198, 93)}${lab(214, 112, 'সরু সবুজ ব্যান্ড')}${ptr(212, 108, 198, 99)}${lab(214, 146, 'অ্যালুমিনা/সিলিকা জেল')}${ptr(212, 142, 198, 140)}${lab(20, 176, 'তুলা ও স্টপকক')}${ptr(92, 172, 166, 184)}`;
      }
    ];
    const draw = i => { box.innerHTML = X.svg(360, 236, bench.replace('y1="200" x2="344" y2="200"', 'y1="210" x2="344" y2="210"') + scenes[i](), 'নির্যাস প্রস্তুতির ধাপ ' + (i + 1)); out.innerHTML = `<b>ধাপ ${X.bn(i + 1)} · ${LXS[i][0]}:</b> ${LXS[i][1]}`; };
    X.onSeg(el, 'st', k => draw(+k));
    draw(0);
  }
};

const PIG = [['β-ক্যারোটিন', '#f08a24', { pe: 15, mix: 22, ace: 30 }], ['ক্লোরোফিল-a', '#1f8f6a', { pe: 0.8, mix: 7, ace: 19 }], ['ক্লোরোফিল-b', '#8cbf3f', { pe: 0.4, mix: 4.5, ace: 15 }]];
V.columnSim = {
  t: 'কলাম ক্রোমাটোগ্রাফি: পাতার রঞ্জক পৃথকীকরণ', k: ['anim', 'int'],
  cap: 'স্তম্ভে সিলিকা জেল বা অ্যালুমিনা (পোলার স্থির দশা) ঠাসা। উপরে পাতার নির্যাস দিয়ে দ্রাবক (চলমান দশা) ঢালা হয়। অপোলার β-ক্যারোটিন (হাইড্রোকার্বন) সবচেয়ে কম অধিশোষিত হয় — সবার আগে নামে; পোলার ক্লোরোফিলগুলো শক্তভাবে আটকে থাকে, আর ক্লোরোফিল-b (–CHO মূলক) ক্লোরোফিল-a (–CH₃) এর চেয়ে বেশি পোলার বলে সবার শেষে। হলুদ জ্যান্থোফিলের অবস্থান স্থির দশা ও দ্রাবকের ওপর নির্ভর করে, তাই এখানে দেখানো হয়নি। দ্রাবকের পোলারিটি বাড়ালে আটকে থাকা উপাদানগুলোও নামতে শুরু করে। স্তম্ভ থেকে বের হওয়া দ্রবণ (ইলুয়েট) আলাদা টেস্টটিউবে সংগ্রহ করা হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('el', [['pe', 'পেট্রোলিয়াম ইথার'], ['mix', 'ইথার + অ্যাসিটোন'], ['ace', 'অ্যাসিটোন']], 'pe')}</div><div data-svg></div><div class="ctl"><button class="btn sm" data-go>চালাও</button><button class="btn sm" data-rs>নতুন করে</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const TOP = 52, BOT = 236; let el_ = 'pe', run = false, pos = [], tubes = [];
    const reset = () => { pos = PIG.map(() => 0); tubes = []; run = false; el.querySelector('[data-go]').textContent = 'চালাও'; draw(); };
    const draw = () => {
      let s = `<rect x="150" y="${TOP - 26}" width="40" height="26" fill="rgba(160,200,235,.35)"/><path d="M146 20 L146 ${BOT + 4} L164 ${BOT + 18} L164 ${BOT + 30} L176 ${BOT + 30} L176 ${BOT + 18} L194 ${BOT + 4} L194 20" fill="none" class="s-fg" stroke-width="2"/>`;
      s += `<rect x="148" y="${TOP}" width="44" height="${BOT - TOP}" fill="#ece6d8"/>`;
      const r = X.rng(3); for (let i = 0; i < 90; i++) s += `<circle cx="${f1(150 + r() * 40)}" cy="${f1(TOP + 2 + r() * (BOT - TOP - 4))}" r="1" fill="#c9bfa8"/>`;
      let lastY = -99; PIG.map((p, i) => [p, i]).filter(([, i]) => pos[i] !== null).sort((a, b) => pos[b[1]] - pos[a[1]]).forEach(([[n, c], i]) => { const d = pos[i], h = 6 + d * 0.08, y = TOP + 2 + d; if (y - h / 2 > BOT) return; const y0 = Math.max(TOP, y - h / 2), y1 = Math.min(BOT, y + h / 2); s += `<rect x="148" y="${f1(y0)}" width="44" height="${f1(y1 - y0)}" fill="${c}" opacity=".85"/>`; if (y < BOT - 4 && Math.abs(lastY - y) > 11) { s += `<text x="198" y="${f1(y + 4)}" style="font-size:10px;fill:${c};font-weight:600">${n}</text>`; lastY = y; } });
      s += `<rect x="158" y="${BOT + 10}" width="24" height="6" rx="2" fill="#7a6b5d"/>`;
      if (run) s += `<circle class="anim-drip" cx="170" cy="${BOT + 32}" r="2.4" fill="${tubes.length && tubes[tubes.length - 1].active ? tubes[tubes.length - 1].c : '#bcd6ee'}"/>`;
      for (let i = 0; i < 3; i++) { const t = tubes[i], x = 280 + i * 36; s += `<path d="M${x - 9} 196 L${x - 9} 262 Q${x - 9} 272 ${x} 272 Q${x + 9} 272 ${x + 9} 262 L${x + 9} 196" fill="none" class="s-fg" stroke-width="1.8"/>`; if (t) s += `<path d="M${x - 7.5} ${f1(270 - t.f * 60)} L${x + 7.5} ${f1(270 - t.f * 60)} L${x + 7.5} 262 Q${x + 7.5} 270 ${x} 270 Q${x - 7.5} 270 ${x - 7.5} 262Z" fill="${t.c}" opacity=".85"/><text x="${x}" y="286" text-anchor="middle" style="font-size:8.5px;fill:${t.c};font-weight:600">${X.bn(i + 1)}</text>`; }
      s += `<text x="300" y="188" text-anchor="middle" class="tm" style="font-size:10px">সংগৃহীত অংশ (ইলুয়েট)</text><text x="140" y="${TOP + 70}" text-anchor="end" class="tm" style="font-size:10px">সিলিকা জেল</text><text x="140" y="${TOP - 10}" text-anchor="end" class="tm" style="font-size:10px">দ্রাবক</text><text x="140" y="${BOT + 16}" text-anchor="end" class="tm" style="font-size:10px">স্টপকক</text>`;
      box.innerHTML = X.svg(400, 292, s, 'কলাম ক্রোমাটোগ্রাফি');
      const el2 = tubes.map(t => t.n);
      out.innerHTML = `দ্রাবক: <b style="font-family:var(--font-body)">${{ pe: 'পেট্রোলিয়াম ইথার (অপোলার)', mix: 'পেট্রোলিয়াম ইথার + অ্যাসিটোন (মাঝারি)', ace: 'অ্যাসিটোন (পোলার)' }[el_]}</b>। ${el2.length ? 'বের হয়েছে (ক্রমে): ' + el2.join(' → ') + '।' : 'চালাও চাপো।'} ${el_ === 'pe' && pos[2] !== null && pos[0] === null ? 'ক্লোরোফিলগুলো প্রায় আটকে আছে — দ্রাবকের পোলারিটি বাড়াও।' : ''}`;
    };
    const A = X.anim(box, dt => {
      if (!run) return; let ch = false;
      PIG.forEach(([n, c, sp], i) => { if (pos[i] === null) return; pos[i] += sp[el_] * dt; ch = true; const h = 6 + pos[i] * 0.08; if (TOP + 2 + pos[i] - h / 2 > BOT) { pos[i] = null; const t = tubes.find(x => x.n === n); if (t) t.active = false; } else if (TOP + 2 + pos[i] + h / 2 > BOT) { let t = tubes.find(x => x.n === n); if (!t && tubes.length < 3) { tubes.forEach(x => x.active = false); t = { n, c, f: 0, active: true }; tubes.push(t); } if (t) t.f = Math.min(0.85, t.f + dt * sp[el_] / h * 0.8); } });
      if (pos.every(p => p === null)) { run = false; el.querySelector('[data-go]').textContent = 'চালাও'; }
      if (ch) draw();
    });
    el.querySelector('[data-go]').onclick = () => { if (pos.every(p => p === null)) reset(); run = !run; el.querySelector('[data-go]').textContent = run ? 'থামাও' : 'চালাও'; if (A.paused) A.pause(false); draw(); A.draw(); };
    el.querySelector('[data-rs]').onclick = reset;
    X.onSeg(el, 'el', k => { el_ = k; draw(); });
    reset();
    return () => A.stop();
  }
};

/* ======================= 2.18.2 পেপার ক্রোমাটোগ্রাফি ======================= */
const PC = {
  ink: { n: 'কালো কালি', lanes: [['কালো কালি', [['#2f5bd3', 0.78], ['#d23c3c', 0.47], ['#e2b714', 0.2]]], ['নীল', [['#2f5bd3', 0.78]]], ['লাল', [['#d23c3c', 0.47]]], ['হলুদ', [['#e2b714', 0.2]]]], res: 'কালো কালির দাগ তিনটি রঞ্জকে ভাগ হয়েছে; তাদের R<sub>f</sub> মান (০.৭৮, ০.৪৭, ০.২০) নীল, লাল ও হলুদ প্রমাণ রঞ্জকের সাথে মিলে যায় — কালিতে এই তিনটি রঞ্জকই আছে।' },
  food: { n: 'খাদ্য রং', lanes: [['সবুজ খাদ্য রং', [['#2563eb', 0.62], ['#eab308', 0.3]]], ['নীল (E133)', [['#2563eb', 0.62]]], ['হলুদ (E102)', [['#eab308', 0.3]]], ['লাল (E129)', [['#dc2626', 0.48]]]], res: 'সবুজ রং আসলে নীল (E133) ও হলুদ (E102) এর মিশ্রণ; লাল (E129) নেই। খাদ্যে অনুমোদিত নয় এমন রঞ্জক (যেমন কাপড়ের রং) এভাবে শনাক্ত করা যায়।' },
  amino: { n: 'অ্যামিনো এসিড', inv: true, lanes: [['অজানা মিশ্রণ', [['#7e22ce', 0.26], ['#7e22ce', 0.73]]], ['গ্লাইসিন', [['#7e22ce', 0.26]]], ['অ্যালানিন', [['#7e22ce', 0.38]]], ['লিউসিন', [['#7e22ce', 0.73]]]], res: 'অ্যামিনো এসিড বর্ণহীন — নিনহাইড্রিন দ্রবণ স্প্রে করে গরম করলে বেগুনি দাগ দেখা যায় (শনাক্তকারী বিকারক)। অজানা মিশ্রণে গ্লাইসিন (R<sub>f</sub> ০.২৬) ও লিউসিন (০.৭৩) আছে, অ্যালানিন নেই।' }
};
V.paperChrom = {
  t: 'পেপার ক্রোমাটোগ্রাফি ও Rf মান নির্ণয়', k: ['anim', 'int', 'calc'],
  cap: 'ক্রোমাটোগ্রাফি কাগজের নিচ থেকে ~২ cm উপরে পেনসিল দিয়ে মূলরেখা টেনে নমুনার ছোট দাগ দেওয়া হয়। দ্রাবকের তল মূলরেখার নিচে রেখে ঢাকনাযুক্ত পাত্রে কাগজ ঝোলানো হয়। কৈশিক ক্রিয়ায় দ্রাবক উপরে ওঠে; কাগজের সেলুলোজে আবদ্ধ পানি স্থির দশা, দ্রাবক চলমান দশা — উপাদানগুলো তাদের বণ্টন সহগ অনুযায়ী ভিন্ন দূরত্বে যায়। দ্রাবক শীর্ষে পৌঁছানোর আগে কাগজ তুলে দ্রাবকের শীর্ষরেখা চিহ্নিত করা হয়। কোনো দাগে ট্যাপ করে Rf মাপো। (Rf মানগুলো উদাহরণমূলক।)',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('pc', Object.keys(PC).map(k => [k, PC[k].n]), 'ink')}</div><div data-svg></div><div class="ctl"><button class="btn sm" data-go>চালাও</button><button class="btn sm" data-ny hidden>নিনহাইড্রিন স্প্রে</button><button class="btn sm" data-rs>নতুন করে</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), ny = el.querySelector('[data-ny]');
    const BASE = 216, SOL = 232, FMAX = 56, PX = 16; let m = 'ink', front = SOL, run = false, shown = true, sel = null;
    const lanesX = [150, 190, 230, 270];
    const draw = () => {
      const S = PC[m], df = Math.max(0, BASE - Math.min(BASE, front));
      let s = `<rect x="70" y="16" width="260" height="262" rx="10" fill="rgba(200,220,235,.15)" class="s-fg" stroke-width="2"/><rect x="62" y="10" width="276" height="10" rx="4" class="f-mu"/><line x1="200" y1="20" x2="200" y2="30" class="s-mu" stroke-width="2"/>`;
      s += `<rect x="72" y="${SOL}" width="256" height="${276 - SOL}" fill="rgba(120,170,220,.35)"/>`;
      s += `<rect x="126" y="30" width="168" height="${SOL + 10 - 30}" fill="#fbfaf6" stroke="#cfc8b8"/>`;
      if (front < SOL) s += `<rect x="126.5" y="${f1(front)}" width="167" height="${f1(SOL + 10 - front)}" fill="rgba(140,180,220,.18)"/>`;
      if (!run && front < BASE) s += `<line x1="126" y1="${f1(front)}" x2="294" y2="${f1(front)}" class="s-acc" stroke-dasharray="4 3" stroke-width="1.4"/><text x="298" y="${f1(front + 4)}" style="font-size:9.5px;fill:var(--accent)">দ্রাবক শীর্ষ</text>`;
      s += `<line x1="126" y1="${BASE}" x2="294" y2="${BASE}" stroke="#777" stroke-width="1" stroke-dasharray="2 2"/><text x="122" y="${BASE + 4}" text-anchor="end" class="tm" style="font-size:9.5px">মূলরেখা</text>`;
      S.lanes.forEach(([n, spots], i) => {
        const x = lanesX[i];
        spots.forEach(([c, rf], j) => { const d = rf * df, y = BASE - d, rr = 4 + d * 0.03, vis = !S.inv || shown; if (!vis && d > 0) return; s += `<ellipse data-sp="${i},${j}" cx="${x}" cy="${f1(y)}" rx="${f1(rr)}" ry="${f1(rr * (1 + d * 0.004))}" fill="${S.inv && !shown ? '#e9e5da' : c}" opacity="${S.inv && !shown ? 0.6 : 0.85}" style="cursor:pointer" ${sel === i + ',' + j ? 'stroke="#111" stroke-width="1.5"' : ''}/>`; });
        s += `<text x="${x}" y="${BASE + 14 + (i % 2) * 10}" text-anchor="middle" class="tm" style="font-size:8.5px">${n}</text>`;
      });
      if (sel && !run && front < BASE) { const [i, j] = sel.split(',').map(Number), rf = S.lanes[i][1][j][1], d = rf * df, x = lanesX[i] + 14; s += `<line x1="${x}" y1="${BASE}" x2="${x}" y2="${f1(BASE - d)}" stroke="#111" stroke-width="1.4"/><line x1="${x + 10}" y1="${BASE}" x2="${x + 10}" y2="${f1(front)}" class="s-acc" stroke-width="1.4"/>`; }
      s += `<text x="76" y="${SOL + 22}" class="tm" style="font-size:9.5px">দ্রাবক</text>`;
      box.innerHTML = X.svg(400, 284, s, 'পেপার ক্রোমাটোগ্রাফি');
      box.querySelectorAll('[data-sp]').forEach(e => e.onclick = () => { if (run || front >= BASE) return; sel = e.dataset.sp; draw(); info(); });
    };
    const info = () => {
      const S = PC[m], df = Math.max(0, BASE - front);
      if (front >= SOL - 0.5) { out.innerHTML = 'নমুনার দাগ মূলরেখায় দেওয়া আছে। "চালাও" চাপো।'; return; }
      if (run) { out.innerHTML = 'দ্রাবক কৈশিক ক্রিয়ায় উপরে উঠছে… উপাদানগুলো ভিন্ন গতিতে চলছে।'; return; }
      if (S.inv && !shown) { out.innerHTML = 'দ্রাবক শীর্ষ চিহ্নিত করা হয়েছে, কিন্তু কোনো দাগ দেখা যাচ্ছে না — অ্যামিনো এসিড বর্ণহীন। নিনহাইড্রিন স্প্রে করো।'; return; }
      let r = S.res;
      if (sel) { const [i, j] = sel.split(',').map(Number), rf = S.lanes[i][1][j][1], ds = rf * df / PX, dfc = df / PX; r = `<b style="font-family:var(--font-body)">${S.lanes[i][0]}</b> এর দাগ: দ্রবের অতিক্রান্ত দূরত্ব = <b>${ds.toFixed(1)} cm</b>, দ্রাবকের অতিক্রান্ত দূরত্ব = <b>${dfc.toFixed(1)} cm</b><br>R<sub>f</sub> = ${ds.toFixed(1)}/${dfc.toFixed(1)} = <b>${(ds / dfc).toFixed(2)}</b><br>` + r; }
      else r = 'কোনো দাগে ট্যাপ করে R<sub>f</sub> মাপো।<br>' + r;
      out.innerHTML = r;
    };
    const A = X.anim(box, dt => { if (!run) return; front -= dt * 30; if (front <= FMAX) { front = FMAX; run = false; el.querySelector('[data-go]').textContent = 'চালাও'; if (PC[m].inv && !shown) ny.hidden = false; info(); } draw(); });
    const reset = () => { front = SOL; run = false; sel = null; shown = !PC[m].inv; ny.hidden = true; el.querySelector('[data-go]').textContent = 'চালাও'; draw(); info(); };
    el.querySelector('[data-go]').onclick = () => { if (front <= FMAX) reset(); run = !run; el.querySelector('[data-go]').textContent = run ? 'থামাও' : 'চালাও'; if (A.paused) A.pause(false); info(); A.draw(); };
    ny.onclick = () => { shown = true; ny.hidden = true; draw(); info(); };
    el.querySelector('[data-rs]').onclick = reset;
    X.onSeg(el, 'pc', k => { m = k; reset(); });
    reset();
    return () => A.stop();
  }
};

/* ======================= 2.19 গুণগত বিশ্লেষণের গুরুত্ব ======================= */
const QA = [
  ['med', 'চিকিৎসা ও রোগনির্ণয়', 'রক্ত ও মূত্রে গ্লুকোজ (বেনেডিক্ট দ্রবণ — নীল থেকে ইটের লাল), প্রোটিন ও কিটোন শনাক্তকরণ; MRI দিয়ে টিস্যুর ছবি (২.১০); রক্তের ইলেক্ট্রোলাইট (Na⁺, K⁺, Ca²⁺) পরীক্ষা; ক্রোমাটোগ্রাফি দিয়ে ওষুধ ও মাদক শনাক্তকরণ।', 'MRI, বর্ণালিবীক্ষণ, ক্রোমাটোগ্রাফি, আয়ন শনাক্তকরণ'],
  ['food', 'খাদ্য নিরাপত্তা ও ভেজাল', 'মাছ-ফলে ফরমালিন, ফল পাকাতে ক্যালসিয়াম কার্বাইড, খাদ্যে কাপড়ের রং ও ক্ষতিকর রঞ্জক, দুধে পানি বা ডিটারজেন্ট, মসলায় ইটের গুঁড়া ও সীসা শনাক্তকরণ; নিরাপদ খাদ্য কর্তৃপক্ষ ও BSTI এর পরীক্ষাগারে এসব পরীক্ষা হয়।', 'পেপার ক্রোমাটোগ্রাফি, শিখা পরীক্ষা, রাসায়নিক পরীক্ষা কিট, UV-দৃশ্যমান বর্ণালি'],
  ['env', 'পরিবেশ ও পানি', 'নলকূপের পানিতে আর্সেনিক (বাংলাদেশে বড় জনস্বাস্থ্য সমস্যা), আয়রন, ম্যাঙ্গানিজ; নদীর পানিতে শিল্পবর্জ্যের ভারী ধাতু (Pb, Cr, Cd, Hg); বায়ুতে SO₂, NOₓ শনাক্তকরণ; লবণাক্ততা (Cl⁻) পরিমাপ।', 'আর্সেনিক কিট, AAS (২.৬), আয়ন শনাক্তকরণ (২.১৩)'],
  ['for', 'ফরেনসিক ও অপরাধ তদন্ত', 'ঘটনাস্থলের রক্তের দাগ, বিষ (আর্সেনিক, সায়ানাইড), মাদক ও বিস্ফোরকের অবশেষ শনাক্তকরণ; জাল নোট ও দলিলের কালি পরীক্ষা (UV আলো, ক্রোমাটোগ্রাফি); গুলির অবশেষে Pb, Ba, Sb শনাক্তকরণ।', 'UV (২.৮), পেপার ও গ্যাস ক্রোমাটোগ্রাফি, বর্ণালিবীক্ষণ'],
  ['ind', 'শিল্প ও মান নিয়ন্ত্রণ', 'কাঁচামাল ও উৎপাদিত পণ্যের বিশুদ্ধতা যাচাই; সিমেন্ট, সার, কাচ, সাবান, রং শিল্পে উপাদান পরীক্ষা; পেট্রোলিয়ামের অংশ পৃথকীকরণ ও মান যাচাই; বয়লারের পানির খরতা (Ca²⁺, Mg²⁺) নির্ণয়।', 'আংশিক পাতন, কেলাসায়ন, আয়ন শনাক্তকরণ, IR বর্ণালি (২.৯)'],
  ['agr', 'কৃষি ও মাটি', 'মাটিতে N, P, K, S ও অণুপুষ্টি (Zn, B) শনাক্তকরণ — সার সুপারিশের ভিত্তি; সারে ভেজাল (যেমন TSP তে মাটি) যাচাই; ফসল ও সবজিতে কীটনাশকের অবশেষ নির্ণয়।', 'আয়ন শনাক্তকরণ, শিখা পরীক্ষা (K, Na), ক্রোমাটোগ্রাফি'],
  ['min', 'খনিজ ও ধাতুবিদ্যা', 'আকরিকে কোন ধাতু আছে তা নির্ণয়; সংকর ধাতুর উপাদান (যেমন সোনার গয়নায় তামা ও রুপার অনুপাত); নতুন খনিজ ক্ষেত্র অনুসন্ধান।', 'শিখা পরীক্ষা (২.১১), রেখা বর্ণালি (২.৬), গ্রুপ বিশ্লেষণ'],
  ['pha', 'ওষুধ শিল্প ও গবেষণা', 'ওষুধের সক্রিয় উপাদান শনাক্তকরণ ও বিশুদ্ধতা যাচাই; ভেজাল ও নকল ওষুধ ধরা; নতুন যৌগের গঠন নির্ণয়; উদ্ভিদ থেকে ঔষধি উপাদান নিষ্কাশন।', 'কলাম ক্রোমাটোগ্রাফি, দ্রাবক নিষ্কাশন, বাষ্প পাতন, IR ও NMR বর্ণালি'],
  ['spc', 'মহাকাশ ও জ্যোতির্বিদ্যা', 'নক্ষত্রের আলোর রেখা বর্ণালি বিশ্লেষণ করে সেখানে কোন কোন মৌল আছে তা জানা — হিলিয়াম মৌল প্রথম সূর্যের বর্ণালিতেই আবিষ্কৃত হয়েছিল।', 'রেখা বর্ণালি ও শোষণ বর্ণালি (২.৫–২.৭)']
];
V.qaUses = {
  t: 'গুণগত বিশ্লেষণ কোথায় কাজে লাগে', k: ['info', 'int'],
  cap: 'একটি ক্ষেত্রে ট্যাপ করো — সেখানে কী শনাক্ত করা হয় এবং এই অধ্যায়ের কোন কৌশল ব্যবহৃত হয় তা দেখো। গুণগত বিশ্লেষণ প্রশ্নের উত্তর দেয় "নমুনায় কী আছে?" — পরিমাণগত বিশ্লেষণ বলে "কতটুকু আছে?"।',
  html: () => `<div data-g style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const g = el.querySelector('[data-g]'), out = el.querySelector('[data-out]'); let sel = 'env';
    const draw = () => {
      g.innerHTML = QA.map(([k, n]) => `<button class="btn sm" data-k="${k}" style="min-height:52px;white-space:normal;line-height:1.3;justify-content:center;text-align:center;${k === sel ? 'border-color:var(--accent);box-shadow:inset 0 0 0 1.5px var(--accent);font-weight:600' : ''}">${n}</button>`).join('');
      g.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { sel = b.dataset.k; draw(); });
      const q = QA.find(x => x[0] === sel);
      out.innerHTML = `<b style="font-family:var(--font-body)">${q[1]}:</b> ${q[2]}<br><span class="small muted">ব্যবহৃত কৌশল:</span> ${q[3]}`;
    };
    draw();
  }
};

const ASC = [[0, '#fbfbf6'], [10, '#f7f0b6'], [50, '#f2d56a'], [100, '#e9b44c'], [200, '#d98b3a'], [300, '#b8692c'], [500, '#7f4420']];
const asCol = v => { for (let i = 1; i < ASC.length; i++) if (v <= ASC[i][0]) { const a = ASC[i - 1], b = ASC[i], t = (v - a[0]) / (b[0] - a[0]); const h = c => [1, 3, 5].map(k => parseInt(c.substr(k, 2), 16)); const A = h(a[1]), B = h(b[1]); return `rgb(${A.map((x, j) => Math.round(x + (B[j] - x) * t)).join(',')})`; } return ASC[ASC.length - 1][1]; };
V.arsenicKit = {
  t: 'নলকূপের পানিতে আর্সেনিক: মাঠ পর্যায়ের পরীক্ষা কিট', k: ['int', 'anim'],
  cap: 'কিটে পানির নমুনার সাথে জিংক ও এসিড মেশানো হয়; আর্সেনিক যৌগ থেকে আর্সিন গ্যাস (AsH₃) তৈরি হয়, যা মারকিউরিক ব্রোমাইড (HgBr₂) মাখানো কাগজে হলুদ থেকে বাদামি দাগ ফেলে (গুটজাইট পদ্ধতির নীতি)। দাগের রং রঙের চার্টের সাথে মিলিয়ে আর্সেনিকের মাত্রা অনুমান করা হয়। বাংলাদেশের পানীয় জলের মান ৫০ ppb (μg/L), WHO নির্দেশিকা ১০ ppb। স্লাইডার দিয়ে আর্সেনিকের মাত্রা বদলাও।',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none">আর্সেনিক</label><input type="range" min="0" max="500" step="5" value="80" data-v style="flex:1"><span class="mono" data-vv style="min-width:64px;text-align:right"></span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sl = el.querySelector('[data-v]');
    const run = () => {
      const v = +sl.value; el.querySelector('[data-vv]').textContent = v + ' ppb';
      let s = `<path d="M60 70 L60 210 Q60 226 80 226 Q100 226 100 210 L100 70" fill="none" class="s-fg" stroke-width="2"/><rect x="61.5" y="130" width="37" height="80" fill="#d6e8f6"/><path d="M61.5 210 Q61.5 224 80 224 Q98.5 224 98.5 210Z" fill="#d6e8f6"/>`;
      for (let i = 0; i < 6; i++) s += `<circle class="anim-bub" cx="${68 + i * 5}" cy="${214 - (i % 2) * 6}" r="1.8" fill="#fff" stroke="#8fb0cc" stroke-width=".6" style="animation-delay:${(i * 0.3).toFixed(1)}s"/>`;
      s += `<rect x="56" y="60" width="48" height="12" rx="3" class="f-mu"/><rect x="72" y="20" width="16" height="44" fill="${asCol(v)}" stroke="#bbb"/><text x="110" y="40" class="tm" style="font-size:10px">HgBr₂ কাগজ</text><text x="110" y="150" class="tm" style="font-size:10px">নমুনা পানি + Zn + এসিড</text><text x="110" y="164" class="tm" style="font-size:10px">→ AsH₃ গ্যাস</text>`;
      s += `<text x="246" y="18" text-anchor="middle" style="font-size:10.5px;font-weight:600">রঙের চার্ট (ppb)</text>`;
      ASC.forEach(([p, c], i) => { const y = 26 + i * 28; s += `<rect x="216" y="${y}" width="34" height="22" rx="3" fill="${c}" stroke="#bbb"/><text x="256" y="${y + 15}" class="mono" style="font-size:11px">${p}</text>`; });
      const near = ASC.reduce((a, b) => Math.abs(b[0] - v) < Math.abs(a[0] - v) ? b : a);
      s += `<path d="M206 ${26 + ASC.indexOf(near) * 28 + 11} l-8 -6 v12z" class="f-acc"/>`;
      const safe = v <= 10, bd = v <= 50;
      s += `<rect x="296" y="60" width="16" height="70" rx="3" class="f-s3 s-fg"/><path d="M312 74 L346 74 L346 86 L326 86" fill="none" stroke="${bd ? '#16a34a' : '#dc2626'}" stroke-width="7" stroke-linecap="round"/><rect x="290" y="128" width="28" height="8" class="f-mu"/><text x="304" y="152" text-anchor="middle" class="tm" style="font-size:10px">নলকূপের মুখ</text><text x="304" y="165" text-anchor="middle" style="font-size:10px;font-weight:600;fill:${bd ? '#16a34a' : '#dc2626'}">${bd ? 'সবুজ রং' : 'লাল রং'}</text>`;
      box.innerHTML = X.svg(400, 236, s, 'আর্সেনিক পরীক্ষা কিট');
      out.innerHTML = `<b>${v} ppb</b> (= ${(v / 1000).toFixed(3)} mg/L) — ${safe ? '<b style="color:var(--ok)">নিরাপদ</b>: WHO নির্দেশিকার (১০ ppb) মধ্যে।' : bd ? '<b style="color:#b45309">বাংলাদেশের মান (৫০ ppb) এর মধ্যে, কিন্তু WHO নির্দেশিকা (১০ ppb) এর বেশি</b> — দীর্ঘমেয়াদে ঝুঁকি থাকে।' : '<b style="color:var(--bad)">অনিরাপদ</b>: বাংলাদেশের মান (৫০ ppb) অতিক্রম করেছে — নলকূপের মুখ লাল রং করে চিহ্নিত করা হয়; পান ও রান্নায় ব্যবহার নিষেধ।'}<br><span class="small">দীর্ঘদিন আর্সেনিকযুক্ত পানি পানে আর্সেনিকোসিস (ত্বকে কালো দাগ, হাত-পায়ের তালু শক্ত হওয়া), এমনকি ক্যান্সার হতে পারে। গুণগত বিশ্লেষণ এখানে সরাসরি জীবন বাঁচায়।</span>`;
    };
    sl.addEventListener('input', run); run();
  }
};


/* ======================= সারসংক্ষেপ: অধ্যায়ের ধারণা মানচিত্র ======================= */
const CMAPD = [
  ['A', ['পরমাণুর', 'গঠন'], 'var(--cat-a)', '২.১–২.৪', ['s1', 's2', 's3', 's4']],
  ['B', ['বর্ণালি', 'ও আলো'], 'var(--cat-b)', '২.৫–২.১১', ['s5', 's6', 's7', 's8', 's9', 's10', 's11']],
  ['C', ['দ্রাব্যতা', 'ও আয়ন'], 'var(--cat-c)', '২.১২–২.১৩', ['s12', 's13']],
  ['D', ['পৃথকীকরণ ও', 'বিশুদ্ধকরণ'], 'var(--cat-d)', '২.১৪–২.১৮', ['s14', 's15', 's16', 's17', 's18']],
  ['E', ['গুরুত্ব', 'ও প্রয়োগ'], 'var(--cat-e)', '২.১৯', ['s20']]
];
const KEYI = {
  s1: 'রাদারফোর্ডের আলফা কণা পরীক্ষায় ক্ষুদ্র ধনাত্মক নিউক্লিয়াস; বোর মডেলে নির্দিষ্ট শক্তিস্তর — mvr = nh/2π, Eₙ = −13.6Z²/n² eV, rₙ = 0.529n²/Z Å।',
  s2: 'দ্য ব্রগলি (λ = h/mv), হাইজেনবার্গ (Δx·Δp ≥ h/4π) ও স্রোডিঞ্জার সমীকরণ; চার কোয়ান্টাম সংখ্যা; মূল কণিকা, আইসোটোপ, গড় পারমাণবিক ভর ও তেজস্ক্রিয়তা।',
  s3: '(n + l) নিয়মে অরবিটালের শক্তিক্রম; s গোলাকার, p ডাম্বেল, d চার-পাপড়ি; অরবিট বনাম অরবিটাল।',
  s4: 'আউফবাউ, হুন্ড ও পাউলির নীতিতে ইলেকট্রন বিন্যাস; Cr ও Cu এর ব্যতিক্রম; অযুগ্ম ইলেকট্রন ও চৌম্বক ধর্ম।',
  s5: 'c = νλ, E = hν = hc/λ; গামা থেকে বেতার তরঙ্গ পর্যন্ত বর্ণালি; অবিচ্ছিন্ন, নির্গমন ও শোষণ বর্ণালি।',
  s6: 'প্রতিটি মৌলের রেখা বর্ণালি অনন্য — আঙুলের ছাপ; শিখা পরীক্ষা, AES ও AAS দিয়ে মৌল শনাক্তকরণ।',
  s7: 'লাইম্যান (UV), বামার (দৃশ্যমান), পাশেন-ব্র্যাকেট-ফুন্ড (IR) ধারা; 1/λ = R<sub>H</sub>Z²(1/n₁² − 1/n₂²)।',
  s8: 'UV আলোতে প্রতিপ্রভ আঁশ, সুতা ও কালি দেখে জাল নোট ও পাসপোর্ট শনাক্তকরণ; প্রতিপ্রভা বনাম অনুপ্রভা।',
  s9: 'IR শোষণে আণবিক কম্পন ও তাপ; ভীনের সূত্র; থার্মোগ্রাফি, IR থার্মোমিটার ও পালস অক্সিমিটার।',
  s10: 'চৌম্বকক্ষেত্রে ¹H নিউক্লিয়াসের বেতার তরঙ্গে অনুনাদ (f = 42.58 MHz T⁻¹ × B₀); T1, T2 শিথিলায়নে টিস্যুর ছবি।',
  s11: 'ধাতব আয়নের বৈশিষ্ট্যপূর্ণ শিখার রং — Na সোনালি হলুদ, K হালকা বেগুনি, Ca ইটের লাল, Ba আপেল সবুজ, Cu নীলাভ সবুজ।',
  s12: 'Ksp = আয়নের ঘনমাত্রার গুণফল; Q &gt; Ksp হলে অধঃক্ষেপ; সম-আয়ন প্রভাবে দ্রাব্যতা কমে; দ্রাব্যতা লেখ।',
  s13: 'NaOH/NH₄OH দিয়ে ক্যাটায়ন, AgNO₃/BaCl₂/বাদামি বলয় দিয়ে অ্যানায়ন শনাক্তকরণ; ছয় গ্রুপের বিশ্লেষণ; বিকারক প্রস্তুতি।',
  s14: 'পরিস্রাবণ, সেন্ট্রিফিউজ, শুষ্ককরণ; ধর্মের পার্থক্যে পদ্ধতি নির্বাচন; কেলাসায়নে বিশুদ্ধকরণ।',
  s15: 'সম্পৃক্ত লবণ দ্রবণে HCl গ্যাস — সম-আয়ন প্রভাবে বিশুদ্ধ NaCl; আংশিক কেলাসায়নে KNO₃ ও NaCl পৃথকীকরণ।',
  s16: 'সাধারণ, আংশিক, সমস্ফুটন, বাষ্প ও নিম্নচাপ পাতন এবং ঊর্ধ্বপাতন — স্ফুটনাঙ্ক ও উদ্বায়িতার পার্থক্যে পৃথকীকরণ।',
  s17: 'বণ্টন সূত্র K<sub>D</sub> = C₁/C₂; পৃথকীকরণ ফানেল; একই দ্রাবক কয়েক ভাগে বারবার নিষ্কাশন বেশি কার্যকর।',
  s18: 'স্থির ও চলমান দশায় ভিন্ন আসক্তি; কলাম (অধিশোষণ) ও পেপার (বণ্টন) ক্রোমাটোগ্রাফি; R<sub>f</sub> মান।',
  s20: 'চিকিৎসা, খাদ্য, পরিবেশ, ফরেনসিক, কৃষি ও শিল্পে গুণগত বিশ্লেষণ; আর্সেনিক ও খাদ্যে ভেজাল শনাক্তকরণ।'
};
const CLINK = ['শক্তিস্তর → রেখা বর্ণালি → মৌল শনাক্তকরণ', 'দ্রাব্যতা → Ksp → আয়ন শনাক্তকরণ', 'আয়ন শনাক্তকরণ → পৃথকীকরণ প্রয়োজন', 'বিশুদ্ধ পদার্থ → নির্ভুল বিশ্লেষণ → সমাজে প্রয়োগ', 'বর্ণালি → UV, IR, MRI এর প্রয়োগ'];
V.chapterMap = {
  t: 'অধ্যায় ২ এক নজরে: ধারণা মানচিত্র', k: ['2d', 'int'],
  cap: 'অধ্যায়টির পাঁচটি ধারণাগত অংশ এবং তাদের সংযোগ। একটি অংশে ট্যাপ করো — নিচে প্রতিটি অনুচ্ছেদের মূল কথা দেখাবে এবং "পড়তে যাও" চাপলে সেই অনুচ্ছেদে চলে যাবে। পুরো অধ্যায়ের সূত্র এক বাক্যে: পরমাণুর শক্তিস্তর বোঝা → সেই শক্তিস্তর থেকে আসা বর্ণালি দিয়ে মৌল চেনা → দ্রবণে আয়নের রাসায়নিক আচরণ দিয়ে আয়ন চেনা → মিশ্রণ পৃথক ও বিশুদ্ধ করা → সমাজে প্রয়োগ।',
  html: () => `<div data-svg></div><div data-list class="stack" style="gap:8px;margin-top:8px"></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), list = el.querySelector('[data-list]'); let sel = 'A';
    const SECS = {}; (window.SEC || []).forEach(s => SECS[s.id] = s);
    const draw = () => {
      const cx = 200, cy = 160, R = 112;
      let s = '';
      const pos = CMAPD.map((c, i) => { const a = (-90 + i * 72) * Math.PI / 180; return [cx + R * Math.cos(a), cy + R * Math.sin(a)]; });
      pos.forEach((p, i) => { const q = pos[(i + 1) % 5]; s += `<line x1="${f1(p[0])}" y1="${f1(p[1])}" x2="${f1(q[0])}" y2="${f1(q[1])}" class="s-ln" stroke-dasharray="4 4"/><line x1="${cx}" y1="${cy}" x2="${f1(p[0])}" y2="${f1(p[1])}" class="s-ln" stroke-width="1.6"/>`; });
      s += `<circle cx="${cx}" cy="${cy}" r="48" class="f-sf s-fg" stroke-width="2"/><text x="${cx}" y="${cy - 4}" text-anchor="middle" style="font-size:13px;font-weight:700">গুণগত রসায়ন</text><text x="${cx}" y="${cy + 14}" text-anchor="middle" class="tm" style="font-size:10.5px">অধ্যায় ২</text>`;
      CMAPD.forEach(([k, lab, col, rng], i) => { const [x, y] = pos[i], on = k === sel; s += `<g data-k="${k}" style="cursor:pointer"><circle cx="${f1(x)}" cy="${f1(y)}" r="${on ? 44 : 40}" style="fill:${col}" ${on ? 'stroke="var(--fg)" stroke-width="3"' : 'stroke="var(--surface)" stroke-width="2"'}/><text x="${f1(x)}" y="${f1(y - 8)}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:var(--bg)">${lab[0]}</text><text x="${f1(x)}" y="${f1(y + 6)}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:var(--bg)">${lab[1]}</text><text x="${f1(x)}" y="${f1(y + 21)}" text-anchor="middle" style="font-size:9.5px;fill:var(--bg);opacity:.9">${rng}</text></g>`; });
      box.innerHTML = X.svg(400, 316, s, 'অধ্যায়ের ধারণা মানচিত্র');
      box.querySelectorAll('[data-k]').forEach(g => g.onclick = () => { sel = g.dataset.k; draw(); });
      const c = CMAPD.find(x => x[0] === sel);
      list.innerHTML = `<div class="small muted">${c[1].join(' ')} · ${c[3]}</div>` + c[4].map(id => { const sc = SECS[id]; if (!sc) return ''; return `<div class="calc-out" style="margin:0;border-left:4px solid ${c[2]}"><div style="display:flex;gap:8px;align-items:baseline;justify-content:space-between"><b style="font-family:var(--font-body)">${sc.no} ${sc.t}</b><button class="btn sm" data-act="sec" data-id="${id}" style="flex:none">পড়তে যাও</button></div><div style="margin-top:4px">${KEYI[id] || ''}</div></div>`; }).join('') + `<div class="small muted" style="margin-top:4px">সংযোগ: ${CLINK.join(' · ')}</div>`;
    };
    draw();
  }
};

/* ======================= অনুশীলনী: সৃজনশীল প্রশ্নের গঠন ======================= */
const CQA = {
  k: { lv: 'জ্ঞানমূলক', mk: 1, q: 'দ্রাব্যতা গুণফল কাকে বলে?', want: 'সংজ্ঞা — পাঠ্যবইয়ের ভাষায় নির্ভুল ও সংক্ষিপ্ত। ব্যাখ্যা বা উদাহরণ লাগে না।', ans: 'নির্দিষ্ট তাপমাত্রায় কোনো স্বল্প দ্রবণীয় আয়নিক যৌগের সম্পৃক্ত দ্রবণে উপস্থিত আয়নগুলোর মোলার ঘনমাত্রার (প্রতিটি তার সহগের ঘাতে) গুণফলকে ঐ যৌগের দ্রাব্যতা গুণফল (Ksp) বলে।', mark: 'নির্ভুল সংজ্ঞা = ১', err: '"সম্পৃক্ত" ও "নির্দিষ্ট তাপমাত্রা" শব্দ বাদ দেওয়া।' },
  kh: { lv: 'অনুধাবনমূলক', mk: 2, q: 'শিখা পরীক্ষায় প্লাটিনাম তার গাঢ় HCl এ ভিজিয়ে নেওয়া হয় কেন?', want: 'কারণ ব্যাখ্যা — দুটি আলাদা যুক্তি (প্রতিটি ১)। প্রথমে মূল ধারণা, তারপর ব্যাখ্যা।', ans: '(১) গাঢ় HCl তারে লেগে থাকা আগের পরীক্ষার লবণ দ্রবীভূত করে তার পরিষ্কার করে — নইলে পুরোনো আয়নের রং ভুল ফল দিত। (২) নমুনার লবণকে ধাতব ক্লোরাইডে পরিণত করে; ক্লোরাইড বেশি উদ্বায়ী, তাই শিখায় সহজে বাষ্প হয়ে উত্তেজিত পরমাণু তৈরি করে — রং উজ্জ্বল ও স্পষ্ট হয়।', mark: 'জ্ঞান (একটি কারণ উল্লেখ) ১ + অনুধাবন (ব্যাখ্যা) ১', err: 'শুধু "তার পরিষ্কার করতে" লিখে থেমে যাওয়া — উদ্বায়ী ক্লোরাইডের কথা বাদ।' },
  g: { lv: 'প্রয়োগমূলক', mk: 3, q: 'অধঃক্ষেপ Y এর মোলার দ্রাব্যতা (mol L⁻¹ ও g L⁻¹ এ) নির্ণয় করো।', want: 'সূত্র লেখা, মান বসানো, একক সহ উত্তর। প্রতিটি ধাপ দেখাতে হবে।', ans: 'Y = BaSO₄ ⇌ Ba²⁺ + SO₄²⁻; Ksp = s²<br>s = √(1.1×10⁻¹⁰) = <b>1.05×10⁻⁵ mol L⁻¹</b><br>BaSO₄ এর মোলার ভর = 233.4 g mol⁻¹<br>দ্রাব্যতা = 1.05×10⁻⁵ × 233.4 = <b>2.45×10⁻³ g L⁻¹</b>', mark: 'সমীকরণ ও সূত্র ১ + mol L⁻¹ ১ + g L⁻¹ ১', err: 'Y শনাক্ত না করে সরাসরি হিসাব; Ksp = s² এর বদলে 4s³ ব্যবহার; একক না লেখা।' },
  gh: { lv: 'উচ্চতর দক্ষতামূলক', mk: 4, q: 'X লবণটি শনাক্ত করো এবং উদ্দীপকের পরীক্ষাগুলোর যৌক্তিকতা বিশ্লেষণ করো।', want: 'সিদ্ধান্ত + প্রতিটি পর্যবেক্ষণের যুক্তি + সমীকরণ + মূল্যায়ন/বিকল্প প্রমাণ। একাধিক তথ্য মিলিয়ে সিদ্ধান্তে পৌঁছানো।', ans: '<b>শিখা পরীক্ষা:</b> আপেল সবুজ শিখা Ba²⁺ এর বৈশিষ্ট্য — উত্তেজিত Ba পরমাণু/মূলকের ইলেকট্রন নিম্ন শক্তিস্তরে ফেরার সময় সবুজ অঞ্চলের নির্দিষ্ট তরঙ্গদৈর্ঘ্যের ফোটন নির্গত করে।<br><b>লঘু H₂SO₄:</b> Ba²⁺ + SO₄²⁻ → BaSO₄↓ (সাদা, এসিডে অদ্রবণীয়; Ksp অতি ক্ষুদ্র) — Ba²⁺ নিশ্চিত।<br><b>AgNO₃ + HNO₃:</b> Ag⁺ + Cl⁻ → AgCl↓ (সাদা), NH₄OH এ দ্রবণীয় [Ag(NH₃)₂]⁺ — Cl⁻ নিশ্চিত (Br⁻/I⁻ হলে হলুদাভ ও অদ্রবণীয় হতো)।<br><b>সিদ্ধান্ত:</b> X = <b>BaCl₂</b>। দুটি স্বাধীন পরীক্ষা ক্যাটায়ন ও দুটি অ্যানায়নের জন্য মিলিয়ে সিদ্ধান্ত নির্ভরযোগ্য; শিখা পরীক্ষা একা যথেষ্ট নয় (Cu²⁺ ও সবুজাভ শিখা দেয়), তাই রাসায়নিক নিশ্চিতকরণ প্রয়োজন ছিল।', mark: 'শনাক্তকরণ ১ + পর্যবেক্ষণের যুক্তি ও সমীকরণ ২ + মূল্যায়ন ১', err: 'শুধু "X = BaCl₂" লিখে থামা; সমীকরণ ও "কেন" না লেখা; শিখার রঙের পারমাণবিক কারণ বাদ।' }
};
V.cqAnatomy = {
  t: 'সৃজনশীল প্রশ্ন: গঠন, প্রত্যাশা ও আদর্শ উত্তর', k: ['info', 'int'],
  cap: 'প্রতিটি সৃজনশীল প্রশ্নে একটি উদ্দীপক ও চারটি অংশ থাকে — ক (জ্ঞান, ১), খ (অনুধাবন, ২), গ (প্রয়োগ, ৩), ঘ (উচ্চতর দক্ষতা, ৪)। একটি অংশ বেছে নাও: পরীক্ষক কী চান, আদর্শ উত্তর, নম্বর বণ্টন ও সাধারণ ভুল দেখো। উদ্দীপকটি এই অধ্যায়ের তিনটি অংশ (শিখা পরীক্ষা ২.১১, Ksp ২.১২, আয়ন শনাক্তকরণ ২.১৩) মিলিয়ে তৈরি।',
  html: () => `<div class="calc-out" style="margin:0 0 8px"><b style="font-family:var(--font-body)">উদ্দীপক:</b> একটি সাদা লবণ X শিখা পরীক্ষায় আপেল সবুজ রং দেয়। X এর দ্রবণে লঘু H₂SO₄ দিলে সাদা অধঃক্ষেপ Y পড়ে, যা লঘু HCl এ অদ্রবণীয়। X এর দ্রবণে লঘু HNO₃ ও AgNO₃ দিলে সাদা দই-সদৃশ অধঃক্ষেপ পড়ে, যা লঘু NH₄OH এ দ্রবীভূত হয়। ২৫°C এ Y এর Ksp = 1.1×10⁻¹⁰।</div><div class="ctl" style="margin:0 0 6px">${X.seg('cq', [['k', 'ক (১)'], ['kh', 'খ (২)'], ['g', 'গ (৩)'], ['gh', 'ঘ (৪)']], 'k')}</div><div data-out></div>`,
  mount(el) {
    const out = el.querySelector('[data-out]');
    const draw = k => { const c = CQA[k]; out.innerHTML = `<div class="stack" style="gap:8px"><div style="display:flex;gap:6px;flex-wrap:wrap"><span class="chip acc">${c.lv}</span><span class="chip">নম্বর: ${X.bn(c.mk)}</span></div><div style="font-weight:600">${c.q}</div><div class="small"><b style="font-family:var(--font-body)">পরীক্ষক যা চান:</b> ${c.want}</div><div class="calc-out" style="margin:0"><b style="font-family:var(--font-body)">আদর্শ উত্তর:</b><br>${c.ans}</div><div class="small"><b style="font-family:var(--font-body)">নম্বর বণ্টন:</b> ${c.mark}</div><div class="small" style="color:var(--bad)"><b style="font-family:var(--font-body)">সাধারণ ভুল:</b> ${c.err}</div></div>`; };
    X.onSeg(el, 'cq', draw); draw('k');
  }
};

})();
