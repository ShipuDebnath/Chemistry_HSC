/* Visuals part 3 — 2.8–2.9 extras, solubility & ions (2.12–2.13), lab techniques (2.14–2.19) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;

/* ======================= 2.8 প্রতিপ্রভা ======================= */
V.fluoro = {
  t: 'প্রতিপ্রভা ও অনুপ্রভা: শক্তিস্তর চিত্র', k: ['2d', 'int'],
  cap: 'অণু UV ফোটন শোষণ করে উত্তেজিত স্তরে যায় (বেগুনি তীর), কম্পনের মাধ্যমে কিছু শক্তি তাপ হিসেবে হারায় (ঢেউ খেলানো তীর), তারপর কম শক্তির দৃশ্যমান ফোটন নির্গত করে (সবুজ তীর)। তাই নির্গত আলোর তরঙ্গদৈর্ঘ্য শোষিত আলোর চেয়ে বেশি। অনুপ্রভায় ইলেকট্রন একটি "আটকে থাকার" স্তর (T₁) হয়ে ধীরে ফেরে — UV বন্ধ করার পরও আলো জ্বলে থাকে।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('fm', [['f', 'প্রতিপ্রভা'], ['p', 'অনুপ্রভা']], 'f')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = m => {
      const lv = (y, x1, x2, lab) => `<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" class="s-fg" stroke-width="2"/>${[1, 2, 3].map(k => `<line x1="${x1}" y1="${y - k * 9}" x2="${x2}" y2="${y - k * 9}" class="s-ln" stroke-dasharray="3 3"/>`).join('')}<text x="${x1 - 6}" y="${y + 4}" text-anchor="end" class="mono" style="font-size:12px">${lab}</text>`;
      let s = `<defs>${X.arrowC('flU', '#8e5de8')}${X.arrowC('flG', '#2fbf71')}${X.arrowC('flR', '#e0752d')}</defs>`;
      s += lv(230, 50, 200, 'S₀') + lv(80, 50, 200, 'S₁');
      if (m === 'p') s += lv(130, 230, 370, 'T₁');
      s += `<line x1="80" y1="228" x2="80" y2="58" stroke="#8e5de8" stroke-width="3" marker-end="url(#flU)" style="stroke-dasharray:180;stroke-dashoffset:180;animation:drawln .6s forwards"/><text x="86" y="150" style="font-size:12px;fill:#8e5de8">UV শোষণ</text><text x="86" y="165" class="tm" style="font-size:11px">365 nm</text>`;
      s += `<path d="M120 54 q5 4 0 8 q-5 4 0 8 q5 4 0 8" fill="none" class="s-mu" stroke-width="1.6"/><text x="128" y="66" class="tm" style="font-size:11px">তাপ</text>`;
      if (m === 'f') s += `<line x1="160" y1="82" x2="160" y2="226" stroke="#2fbf71" stroke-width="3" marker-end="url(#flG)" style="stroke-dasharray:160;stroke-dashoffset:160;animation:drawln .6s .5s forwards"/><text x="166" y="150" style="font-size:12px;fill:#2fbf71">দৃশ্যমান আলো</text><text x="166" y="165" class="tm" style="font-size:11px">~৫২০ nm, তাৎক্ষণিক</text>`;
      else s += `<path d="M190 84 Q215 95 236 124" fill="none" class="s-mu" stroke-dasharray="4 3" stroke-width="1.6"/><text x="206" y="98" class="tm" style="font-size:11px">স্পিন উল্টানো</text><line x1="300" y1="132" x2="300" y2="226" stroke="#e0752d" stroke-width="3" marker-end="url(#flR)" style="stroke-dasharray:100;stroke-dashoffset:100;animation:drawln 1.6s .6s forwards"/><text x="306" y="185" style="font-size:12px;fill:#e0752d">ধীরে নির্গমন</text><text x="306" y="200" class="tm" style="font-size:11px">সেকেন্ড–ঘণ্টা</text>`;
      box.innerHTML = X.svg(400, 250, s, 'প্রতিপ্রভার শক্তিস্তর চিত্র');
      out.innerHTML = m === 'f' ? 'শোষণ 365 nm → E = 1240/365 = <b>3.40 eV</b>; নির্গমন 520 nm → <b>2.38 eV</b>; তাপ হিসেবে হারায় <b>1.02 eV</b>। UV বন্ধ করলে প্রায় ১০⁻⁸ সেকেন্ডের মধ্যে আলো নিভে যায় — <b>প্রতিপ্রভা</b> (যেমন নোটের নিরাপত্তা আঁশ, ডিটারজেন্টের ব্রাইটেনার)।' : 'উত্তেজিত ইলেকট্রনের স্পিন উল্টে "ট্রিপলেট" স্তরে (T₁) চলে যায়; সেখান থেকে ভূমিস্তরে ফেরা "নিষিদ্ধ" বলে খুব ধীরে ঘটে। তাই UV সরিয়ে নেওয়ার পরও সেকেন্ড থেকে ঘণ্টা পর্যন্ত আলো জ্বলে — <b>অনুপ্রভা</b> (অন্ধকারে জ্বলা ঘড়ির কাঁটা, স্টিকার)।';
    };
    X.onSeg(el, 'fm', draw); draw('f');
  }
};

/* ======================= 2.9 IR: আণবিক কম্পন ======================= */
V.irVib = {
  t: 'IR শোষণে পানির অণুর কম্পন', k: ['anim', 'int'],
  cap: 'একটি কম্পন অবস্থা বেছে নাও। IR ফোটনের শক্তি ঠিক কম্পন শক্তিস্তরের ব্যবধানের সমান হলে অণু তা শোষণ করে আরও জোরে কাঁপতে থাকে — এভাবেই IR রশ্মি দেহের টিস্যু ও পানিকে গরম করে। যে কম্পনে অণুর দ্বিপোল ভ্রামক বদলায় কেবল সেগুলোই IR সক্রিয়। (কম্পনের বিস্তার বোঝার জন্য বাড়িয়ে দেখানো।)',
  html: () => X.cv('পানির অণুর কম্পন') + `<div class="ctl">${X.seg('vm', [['s', 'প্রতিসম প্রসারণ'], ['a', 'অপ্রতিসম প্রসারণ'], ['b', 'বাঁকন']], 's')}<button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const cv = el.querySelector('canvas'); const hf = W => Math.min(260, W * 0.62); let L = X.fit(cv, hf);
    const out = el.querySelector('[data-out]');
    const M = { s: ['প্রতিসম প্রসারণ', 3657], a: ['অপ্রতিসম প্রসারণ', 3756], b: ['বাঁকন (কাঁচির মতো)', 1595] };
    let mode = 's', t = 0;
    const info = () => { const nb = M[mode][1], lam = 1e4 / nb, E = 6.626e-34 * 2.998e10 * nb; out.innerHTML = `<b style="font-family:var(--font-body)">${M[mode][0]}</b>: ν̄ = <b>${nb} cm⁻¹</b> → λ = 1/ν̄ = <b>${lam.toFixed(2)} μm</b> (মধ্য-IR) · E = hcν̄ = <b>${X.sci(E)} J</b> = <b>${(E / 1.602e-19).toFixed(3)} eV</b>`; };
    X.onSeg(el, 'vm', k => { mode = k; info(); });
    info();
    const A = X.anim(cv, dt => {
      t += dt; const C = X.C(), g = L.g, W = L.W, H = L.H; g.clearRect(0, 0, W, H);
      const cx = W / 2, cy = H * 0.42, r0 = Math.min(W, H) * 0.3, half = 52.25 * Math.PI / 180;
      const w = mode === 'b' ? 5 : 8, ph = Math.sin(t * w);
      let a1 = half, a2 = half, d1 = r0, d2 = r0, ox = 0, oy = 0;
      if (mode === 's') { d1 = d2 = r0 * (1 + 0.16 * ph); oy = -ph * 4; }
      if (mode === 'a') { d1 = r0 * (1 + 0.18 * ph); d2 = r0 * (1 - 0.18 * ph); ox = ph * 5; }
      if (mode === 'b') { a1 = a2 = half * (1 + 0.28 * ph); oy = ph * 4; }
      const O = [cx + ox, cy + oy], H1 = [cx - d1 * Math.sin(a1), cy + d1 * Math.cos(a1)], H2 = [cx + d2 * Math.sin(a2), cy + d2 * Math.cos(a2)];
      g.strokeStyle = C.mu; g.lineWidth = 7; g.lineCap = 'round';
      [H1, H2].forEach(P => { g.beginPath(); g.moveTo(O[0], O[1]); g.lineTo(P[0], P[1]); g.stroke(); });
      const ball = (P, r, col, lab) => { const gr = g.createRadialGradient(P[0] - r / 3, P[1] - r / 3, r / 6, P[0], P[1], r); gr.addColorStop(0, '#fff'); gr.addColorStop(1, col); g.fillStyle = gr; g.beginPath(); g.arc(P[0], P[1], r, 0, 6.283); g.fill(); g.fillStyle = '#111'; g.font = `600 ${r * 0.8}px ${C.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(lab, P[0], P[1] + 1); };
      ball(O, 26, '#e74c3c', 'O'); ball(H1, 17, '#dfe6ee', 'H'); ball(H2, 17, '#dfe6ee', 'H');
      // incoming IR wave
      g.strokeStyle = '#c0392b'; g.lineWidth = 2; g.beginPath();
      for (let x = 8; x < cx - 70; x += 2) { const y = H * 0.86 + Math.sin(x * 0.12 - t * 10) * 7; x === 8 ? g.moveTo(x, y) : g.lineTo(x, y); } g.stroke();
      g.textAlign = 'left'; g.fillStyle = '#c0392b'; g.font = `12px ${C.font}`; g.fillText('IR ফোটন →', 8, H * 0.86 - 14);
      g.fillStyle = C.mu; g.textAlign = 'right'; g.fillText('দ্বিপোল ভ্রামক বদলায় → IR সক্রিয়', W - 8, H - 10);
    });
    X.pp(el, A);
    const ro = X.onResize(el, () => { L = X.fit(cv, hf); A.draw(); });
    return () => { A.stop(); ro(); };
  }
};

V.wienPlot = {
  t: 'ভীনের সূত্র: তাপমাত্রা অনুযায়ী বিকিরণের শীর্ষ', k: ['int', 'calc'],
  cap: 'কৃষ্ণবস্তুর বিকিরণ বক্ররেখা (প্ল্যাঙ্কের সূত্র)। তাপমাত্রা বাড়লে বক্ররেখার শীর্ষ ক্ষুদ্রতর তরঙ্গদৈর্ঘ্যের দিকে সরে (λ<sub>max</sub> = b/T) এবং মোট বিকিরণ বহুগুণ বাড়ে। মানবদেহ (~৩১০ K) প্রায় পুরোটাই IR দেয়; সূর্য (~৫৮০০ K) শীর্ষ দৃশ্যমান অঞ্চলে। প্রতিটি বক্ররেখা নিজের শীর্ষের সাপেক্ষে স্কেল করা।',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none">T (K)</label><input type="range" min="300" max="6000" step="10" value="310" data-t style="flex:1;min-width:150px"></div><div class="ctl" style="margin-top:4px">${X.seg('wp', [[310, 'মানবদেহ'], [1000, 'লাল-গরম লোহা'], [3000, 'বাল্বের ফিলামেন্ট'], [5800, 'সূর্য']], 310)}</div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sl = el.querySelector('[data-t]');
    const hc_k = 1.4388e-2; // m K
    const lx = lm => 30 + (Math.log10(lm) - Math.log10(0.2)) / (Math.log10(50) - Math.log10(0.2)) * 360; // lm in μm
    const draw = T => {
      T = +T; const lmax = 2898 / T; // μm
      const B = l => { const m = l * 1e-6; return 1 / (Math.pow(m, 5) * (Math.exp(hc_k / (m * T)) - 1)); };
      const Bm = B(lmax); let d = '';
      for (let i = 0; i <= 200; i++) { const l = Math.pow(10, Math.log10(0.2) + i / 200 * (Math.log10(50) - Math.log10(0.2))); const y = 170 - 140 * B(l) / Bm; d += (i ? 'L' : 'M') + lx(l).toFixed(1) + ' ' + y.toFixed(1); }
      let s = `<defs><linearGradient id="wpV" x1="0" x2="1">${[0, .25, .5, .75, 1].map((o, k) => `<stop offset="${o}" stop-color="${X.wl(400 + k * 75)}"/>`).join('')}</linearGradient></defs>`;
      s += `<rect x="${lx(0.4)}" y="22" width="${lx(0.7) - lx(0.4)}" height="150" fill="url(#wpV)" opacity=".25"/><text x="${(lx(0.4) + lx(0.7)) / 2}" y="18" text-anchor="middle" class="tm" style="font-size:10px">দৃশ্যমান</text>`;
      s += `<line x1="30" y1="170" x2="392" y2="170" class="s-ln"/><path d="${d}" fill="none" class="s-acc" stroke-width="2.4"/>`;
      s += `<line x1="${lx(lmax)}" y1="30" x2="${lx(lmax)}" y2="170" stroke="var(--bad)" stroke-dasharray="3 3"/><text x="${lx(lmax)}" y="${lmax > 10 ? 44 : 44}" text-anchor="${lmax > 12 ? 'end' : 'start'}" dx="${lmax > 12 ? -4 : 4}" style="font-size:11px;fill:var(--bad)">λmax</text>`;
      [0.5, 1, 2, 5, 10, 20, 50].forEach(v => s += `<text x="${lx(v)}" y="186" text-anchor="middle" class="tm mono" style="font-size:10px">${v}</text>`);
      s += `<text x="392" y="200" text-anchor="end" class="tm" style="font-size:10px">তরঙ্গদৈর্ঘ্য (μm, লগ স্কেল)</text>`;
      box.innerHTML = X.svg(400, 204, s, 'কৃষ্ণবস্তু বিকিরণ');
      const reg = lmax < 0.4 ? 'UV' : lmax <= 0.7 ? 'দৃশ্যমান' : 'অবলোহিত (IR)';
      out.innerHTML = `T = ${T} K → λ<sub>max</sub> = 2.898×10⁻³/${T} = <b>${lmax >= 1 ? lmax.toFixed(2) + ' μm' : (lmax * 1000).toFixed(0) + ' nm'}</b> (${reg})। মোট বিকিরণ T⁴ এর সমানুপাতিক — ৩১০ K এর তুলনায় <b>${X.sci(Math.pow(T / 310, 4))} গুণ</b>।`;
    };
    sl.addEventListener('input', e => draw(e.target.value));
    X.onSeg(el, 'wp', k => { sl.value = k; draw(k); });
    draw(310);
  }
};

/* ======================= 2.12 দ্রাব্যতা ও Ksp ======================= */
const KSP = [
  ['AgCl', 'AgCl', 1.8e-10, 1, 1, 143.32, 'সাদা'], ['AgBr', 'AgBr', 5.0e-13, 1, 1, 187.77, 'হালকা হলুদ'], ['AgI', 'AgI', 8.3e-17, 1, 1, 234.77, 'হলুদ'],
  ['BaSO4', 'BaSO₄', 1.1e-10, 1, 1, 233.39, 'সাদা'], ['CaCO3', 'CaCO₃', 3.4e-9, 1, 1, 100.09, 'সাদা'], ['CaF2', 'CaF₂', 3.5e-11, 1, 2, 78.07, 'সাদা'],
  ['PbI2', 'PbI₂', 9.8e-9, 1, 2, 461.0, 'হলুদ'], ['PbCl2', 'PbCl₂', 1.7e-5, 1, 2, 278.1, 'সাদা'], ['MgOH2', 'Mg(OH)₂', 5.6e-12, 1, 2, 58.32, 'সাদা'],
  ['Ag2CrO4', 'Ag₂CrO₄', 1.1e-12, 2, 1, 331.73, 'ইটের মতো লাল'], ['FeOH3', 'Fe(OH)₃', 2.8e-39, 1, 3, 106.87, 'লালচে বাদামি']
];
X.KSP = KSP;
const solFromKsp = (K, x, y) => Math.pow(K / (Math.pow(x, x) * Math.pow(y, y)), 1 / (x + y));
V.kspCalc = {
  t: 'দ্রাব্যতা ⇄ দ্রাব্যতা গুণফল ক্যালকুলেটর', k: ['calc'],
  cap: 'একটি লবণ বেছে নাও অথবা নিজের মান দাও। AₓBᵧ ⇌ xAʸ⁺ + yBˣ⁻ হলে Ksp = (xs)ˣ(ys)ʸ = xˣyʸ s⁽ˣ⁺ʸ⁾। লক্ষ করো: Ag₂CrO₄ এর Ksp AgCl এর চেয়ে কম হলেও এর মোলার দ্রাব্যতা বেশি — ভিন্ন ধরনের লবণের দ্রাব্যতা শুধু Ksp দেখে তুলনা করা যায় না। (মান ২৫°C এ, আসন্ন)',
  html: () => `<div class="grid2"><label class="stack" style="gap:4px"><span class="small muted">লবণ</span><select class="inp" data-salt>${KSP.map(k => `<option value="${k[0]}">${k[1]}</option>`).join('')}<option value="custom">নিজের মান</option></select></label><label class="stack" style="gap:4px"><span class="small muted">ধরন (x : y)</span><select class="inp" data-type><option value="1,1">AB (১:১)</option><option value="1,2">AB₂ (১:২)</option><option value="2,1">A₂B (২:১)</option><option value="1,3">AB₃ (১:৩)</option><option value="2,3">A₂B₃ (২:৩)</option></select></label></div>
  <div class="grid2" style="margin-top:8px"><label class="stack" style="gap:4px"><span class="small muted">Ksp</span><input class="inp mono" data-k value="1.8e-10"></label><label class="stack" style="gap:4px"><span class="small muted">অথবা দ্রাব্যতা s (mol L⁻¹)</span><input class="inp mono" data-s placeholder="যেমন 1.34e-5"></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const q = s => el.querySelector(s), out = q('[data-out]');
    const run = (from) => {
      const [x, y] = q('[data-type]').value.split(',').map(Number);
      const salt = KSP.find(k => k[0] === q('[data-salt]').value);
      let K = +q('[data-k]').value, s = +q('[data-s]').value;
      if (from === 's' && s > 0) { K = Math.pow(x, x) * Math.pow(y, y) * Math.pow(s, x + y); q('[data-k]').value = X.sci(K, 3).replace(/×10/, 'e').replace(/[⁻⁰¹²³⁴⁵⁶⁷⁸⁹]/g, c => ({ '⁻': '-', '⁰': 0, '¹': 1, '²': 2, '³': 3, '⁴': 4, '⁵': 5, '⁶': 6, '⁷': 7, '⁸': 8, '⁹': 9 }[c])); }
      else { if (!(K > 0)) { out.innerHTML = 'বৈধ Ksp দাও।'; return; } s = solFromKsp(K, x, y); q('[data-s]').value = ''; }
      const coef = Math.pow(x, x) * Math.pow(y, y), n = x + y;
      const pre = coef === 1 ? '' : X.bn(coef);
      let txt = `Ksp = ${x > 1 ? '(' + x + 's)' + X.sup(x) : 's'}${y > 1 ? ' × (' + y + 's)' + X.sup(y) : ' × s'} = <b>${pre}s${X.sup(n)}</b><br>s = (Ksp/${coef})<sup>1/${n}</sup> = <b>${X.sci(s)} mol L⁻¹</b>`;
      txt += `<br>[ক্যাটায়ন] = ${x}s = ${X.sci(x * s)} M · [অ্যানায়ন] = ${y}s = ${X.sci(y * s)} M`;
      if (salt && q('[data-salt]').value !== 'custom') txt += `<br>গ্রাম দ্রাব্যতা = s × ${salt[5]} = <b>${X.sci(s * salt[5])} g L⁻¹</b> · অধঃক্ষেপের রং: ${salt[6]}`;
      out.innerHTML = txt;
    };
    q('[data-salt]').addEventListener('change', e => { const s = KSP.find(k => k[0] === e.target.value); if (s) { q('[data-type]').value = s[3] + ',' + s[4]; q('[data-k]').value = s[2]; } run('k'); });
    q('[data-type]').addEventListener('change', () => run('k'));
    q('[data-k]').addEventListener('input', () => { q('[data-salt]').value = 'custom'; run('k'); });
    q('[data-s]').addEventListener('input', () => { q('[data-salt]').value = 'custom'; run('s'); });
    run('k');
  }
};

V.precipSim = {
  t: 'অধঃক্ষেপ পড়বে কি না: Q বনাম Ksp', k: ['anim', 'int'],
  cap: 'দুটি দ্রবণের ঘনমাত্রা ও আয়তন ঠিক করে "মেশাও" চাপো। মেশানোর পর প্রতিটি আয়নের নতুন ঘনমাত্রা = C × V / মোট আয়তন। Q &gt; Ksp হলে অতিপৃক্ত — অধঃক্ষেপ পড়ে; Q = Ksp হলে সম্পৃক্ত; Q &lt; Ksp হলে অসম্পৃক্ত — কিছুই পড়ে না।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('ps', [['AgCl', 'AgNO₃ + NaCl'], ['BaSO4', 'BaCl₂ + Na₂SO₄'], ['PbI2', 'Pb(NO₃)₂ + KI']], 'AgCl')}</div>
  <div data-svg></div>
  <div class="grid2" style="margin-top:6px"><label class="stack" style="gap:4px"><span class="small muted" data-la>দ্রবণ ১ (mol L⁻¹)</span><input class="inp mono" data-c1 value="1e-4"></label><label class="stack" style="gap:4px"><span class="small muted">আয়তন (mL)</span><input class="inp mono" data-v1 value="50"></label><label class="stack" style="gap:4px"><span class="small muted" data-lb>দ্রবণ ২ (mol L⁻¹)</span><input class="inp mono" data-c2 value="1e-4"></label><label class="stack" style="gap:4px"><span class="small muted">আয়তন (mL)</span><input class="inp mono" data-v2 value="50"></label></div>
  <div class="ctl"><button class="btn sm primary" data-mix>${X.ico('play')}মেশাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const q = s => el.querySelector(s); let sys = 'AgCl', t0 = 0, timer = null;
    const S = { AgCl: { a: 'AgNO₃', b: 'NaCl', ion: 'Ag⁺', ion2: 'Cl⁻', K: 1.8e-10, x: 1, y: 1, col: '#f3f3f3', n: 'AgCl (সাদা)', sa: 1, sb: 1 }, BaSO4: { a: 'BaCl₂', b: 'Na₂SO₄', ion: 'Ba²⁺', ion2: 'SO₄²⁻', K: 1.1e-10, x: 1, y: 1, col: '#f6f6f6', n: 'BaSO₄ (সাদা)', sa: 1, sb: 1 }, PbI2: { a: 'Pb(NO₃)₂', b: 'KI', ion: 'Pb²⁺', ion2: 'I⁻', K: 9.8e-9, x: 1, y: 2, col: '#f2cf2a', n: 'PbI₂ (হলুদ)', sa: 1, sb: 1 } };
    const draw = (state, k) => {
      const s = S[sys]; let ppt = '';
      if (state === 'ppt') { const rnd = X.rng(3); for (let i = 0; i < 46; i++) { const x = 150 + rnd() * 100, yy = 110 + rnd() * 70, fall = Math.min(1, k * 1.2); const y = yy + (186 - yy) * fall * (0.6 + rnd() * 0.4); ppt += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${(1.6 + rnd() * 1.6).toFixed(1)}" fill="${s.col}" stroke="#999" stroke-width=".4"/>`; } }
      const liq = state === 'idle' ? '' : `<path d="M143 92 L143 186 Q143 196 153 196 L247 196 Q257 196 257 186 L257 92Z" fill="#bfe3ff" opacity=".5"/>`;
      box.innerHTML = X.svg(400, 214, `<rect x="30" y="40" width="70" height="90" rx="6" fill="#d6ecff" opacity=".7"/><rect x="300" y="40" width="70" height="90" rx="6" fill="#e9ffd6" opacity=".7"/>
        <text x="65" y="34" text-anchor="middle" style="font-size:12px">${s.a}</text><text x="335" y="34" text-anchor="middle" style="font-size:12px">${s.b}</text>
        <path d="M140 70 L140 188 Q140 200 152 200 L248 200 Q260 200 260 188 L260 70" fill="none" class="s-fg" stroke-width="2"/>${liq}${ppt}
        ${state === 'idle' ? `<text x="200" y="140" text-anchor="middle" class="tm">মেশানোর অপেক্ষায়</text>` : ''}
        ${state === 'clear' ? `<text x="200" y="150" text-anchor="middle" style="font-size:12px">স্বচ্ছ দ্রবণ</text>` : ''}
        <path d="M100 85 Q120 85 138 98" fill="none" class="s-mu" stroke-dasharray="3 3"/><path d="M300 85 Q280 85 262 98" fill="none" class="s-mu" stroke-dasharray="3 3"/>`, 'অধঃক্ষেপণ');
    };
    const box = q('[data-svg]'), out = q('[data-out]');
    const labels = () => { const s = S[sys]; q('[data-la]').textContent = s.a + ' (mol L⁻¹)'; q('[data-lb]').textContent = s.b + ' (mol L⁻¹)'; };
    const mix = () => {
      clearInterval(timer); const s = S[sys];
      const c1 = +q('[data-c1]').value, v1 = +q('[data-v1]').value, c2 = +q('[data-c2]').value, v2 = +q('[data-v2]').value;
      if (!(c1 > 0 && c2 > 0 && v1 > 0 && v2 > 0)) { out.innerHTML = 'সব মান ধনাত্মক দাও।'; return; }
      const V = v1 + v2, A = c1 * v1 / V * s.sa, B = c2 * v2 / V * s.sb;
      const Q = Math.pow(A, s.x) * Math.pow(B, s.y);
      const rel = Q > s.K * 1.0001 ? 'gt' : Q < s.K * 0.9999 ? 'lt' : 'eq';
      out.innerHTML = `মেশানোর পর: [${s.ion}] = ${c1} × ${v1}/${V} = <b>${X.sci(A)} M</b> · [${s.ion2}] = ${c2} × ${v2}/${V} = <b>${X.sci(B)} M</b><br>Q = [${s.ion}]${s.x > 1 ? X.sup(s.x) : ''}[${s.ion2}]${s.y > 1 ? X.sup(s.y) : ''} = <b>${X.sci(Q)}</b> ${rel === 'gt' ? '&gt;' : rel === 'lt' ? '&lt;' : '='} Ksp (${X.sci(s.K)})<br>${rel === 'gt' ? `<b style="color:var(--bad)">অতিপৃক্ত — ${s.n} অধঃক্ষেপ পড়বে</b>, যতক্ষণ না Q = Ksp হয়।` : rel === 'lt' ? '<b style="color:var(--ok)">অসম্পৃক্ত — কোনো অধঃক্ষেপ পড়বে না।</b>' : '<b>ঠিক সম্পৃক্ত — অধঃক্ষেপ পড়ার সীমায়।</b>'}`;
      if (rel === 'gt') { let k = 0; timer = setInterval(() => { k += 0.06; draw('ppt', k); if (k >= 1) clearInterval(timer); }, 40); } else draw('clear');
    };
    X.onSeg(el, 'ps', k => { sys = k; labels(); if (k === 'PbI2') { q('[data-c1]').value = '1e-3'; q('[data-c2]').value = '1e-3'; } else { q('[data-c1]').value = '1e-4'; q('[data-c2]').value = '1e-4'; } draw('idle'); out.innerHTML = 'মান ঠিক করে "মেশাও" চাপো।'; });
    q('[data-mix]').onclick = mix; labels(); draw('idle'); out.innerHTML = 'মান ঠিক করে "মেশাও" চাপো।';
    return () => clearInterval(timer);
  }
};

V.commonIon = {
  t: 'সম-আয়ন প্রভাব: NaCl দ্রবণে AgCl এর দ্রাব্যতা', k: ['int', 'calc'],
  cap: 'স্লাইডার দিয়ে দ্রবণে আগে থেকে উপস্থিত Cl⁻ (সম-আয়ন) এর ঘনমাত্রা বাড়াও। লা শাতেলিয়ের নীতি অনুযায়ী AgCl(s) ⇌ Ag⁺ + Cl⁻ সাম্য বামে সরে, তাই AgCl এর দ্রাব্যতা নাটকীয়ভাবে কমে। উল্লম্ব অক্ষ লগারিদমিক।',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none">[Cl⁻]<sub>যোগকৃত</sub></label><input type="range" min="-7" max="0" step="0.05" value="-7" data-c style="flex:1;min-width:150px"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), K = 1.8e-10;
    const sol = c => (-c + Math.sqrt(c * c + 4 * K)) / 2;
    const xs = lc => 50 + (lc + 7) / 7 * 330, ys = ls => 20 + (-4 - ls) / 6 * 160; // ls from -4 to -10
    const draw = lc => {
      lc = +lc; const c = Math.pow(10, lc); let d = '';
      for (let i = 0; i <= 140; i++) { const l = -7 + i * 0.05; const s = sol(Math.pow(10, l)); d += (i ? 'L' : 'M') + xs(l).toFixed(1) + ' ' + ys(Math.log10(s)).toFixed(1); }
      const s = sol(c), s0 = sol(0);
      let g = `<line x1="50" y1="180" x2="385" y2="180" class="s-ln"/><line x1="50" y1="20" x2="50" y2="180" class="s-ln"/><path d="${d}" fill="none" class="s-acc" stroke-width="2.4"/>`;
      [-4, -6, -8, -10].forEach(v => g += `<text x="44" y="${ys(v) + 4}" text-anchor="end" class="tm mono" style="font-size:10px">10${X.sup(v)}</text>`);
      [-7, -5, -3, -1, 0].forEach(v => g += `<text x="${xs(v)}" y="194" text-anchor="middle" class="tm mono" style="font-size:10px">${v === 0 ? '1' : '10' + X.sup(v)}</text>`);
      g += `<circle cx="${xs(lc)}" cy="${ys(Math.log10(s))}" r="6" fill="var(--bad)"/><text x="385" y="208" text-anchor="end" class="tm" style="font-size:10px">যোগকৃত [Cl⁻] (mol L⁻¹)</text><text x="56" y="16" class="tm" style="font-size:10px">AgCl এর দ্রাব্যতা s (mol L⁻¹)</text>`;
      box.innerHTML = X.svg(400, 212, g, 'সম-আয়ন প্রভাব');
      out.innerHTML = `যোগকৃত [Cl⁻] = <b>${X.sci(c)} M</b> → s = <b>${X.sci(s)} M</b> (বিশুদ্ধ পানিতে ${X.sci(s0)} M)<br>${s0 / s < 1.05 ? 'দ্রাব্যতা প্রায় অপরিবর্তিত। ' : 'দ্রাব্যতা কমেছে প্রায় <b>' + X.sci(s0 / s) + ' গুণ</b>। '}${c > 100 * s0 ? 'এখানে s ≈ Ksp/[Cl⁻] = ' + X.sci(K / c) + ' M (আসন্ন সূত্র খাটে)।' : 'সম-আয়নের ঘনমাত্রা কম — দ্রাব্যতায় প্রভাব সামান্য।'}`;
    };
    el.querySelector('[data-c]').addEventListener('input', e => draw(e.target.value)); draw(-7);
  }
};

const SOLD = { T: [0, 20, 40, 60, 80, 100], KNO3: [13.3, 31.6, 63.9, 110, 169, 246], NH4Cl: [29.4, 37.2, 45.8, 55.2, 65.6, 77.3], KCl: [27.6, 34.0, 40.0, 45.5, 51.1, 56.7], NaCl: [35.7, 36.0, 36.6, 37.3, 38.4, 39.8] };
const solAt = (k, T) => { const a = SOLD.T; let i = Math.min(4, Math.floor(T / 20)); const f = (T - a[i]) / 20; return SOLD[k][i] + (SOLD[k][i + 1] - SOLD[k][i]) * f; };
X.solAt = solAt;
V.solCurve = {
  t: 'দ্রাব্যতা লেখ (দ্রাব্যতা বনাম তাপমাত্রা)', k: ['int', 'calc'],
  cap: 'প্রতি ১০০ g পানিতে সম্পৃক্ত দ্রবণে দ্রবীভূত লবণের ভর। KNO₃ এর দ্রাব্যতা তাপমাত্রায় দ্রুত বাড়ে, কিন্তু NaCl এর প্রায় অপরিবর্তিত — এ পার্থক্যই কেলাসায়ন ও আংশিক কেলাসায়নের ভিত্তি (২.১৪, ২.১৫)। দুটি তাপমাত্রা বেছে নিয়ে ঠান্ডা করলে কত কেলাস পড়বে দেখো।',
  html: () => `<div data-svg></div><div class="ctl"><label style="flex:none;min-width:64px">উচ্চ T</label><input type="range" min="20" max="100" step="1" value="80" data-h style="flex:1"><span class="mono" data-hv style="min-width:44px;text-align:right">80°C</span></div><div class="ctl"><label style="flex:none;min-width:64px">নিম্ন T</label><input type="range" min="0" max="80" step="1" value="20" data-l style="flex:1"><span class="mono" data-lv style="min-width:44px;text-align:right">20°C</span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const C = { KNO3: ['KNO₃', '#c0392b'], NH4Cl: ['NH₄Cl', '#8e44ad'], KCl: ['KCl', '#1f77b4'], NaCl: ['NaCl', '#2a9d55'] };
    const xs = T => 46 + T / 100 * 330, ys = v => 200 - v / 250 * 180;
    const draw = () => {
      let hi = +el.querySelector('[data-h]').value, lo = +el.querySelector('[data-l]').value; if (lo >= hi) lo = hi - 1;
      let g = `<line x1="46" y1="200" x2="380" y2="200" class="s-ln"/><line x1="46" y1="20" x2="46" y2="200" class="s-ln"/>`;
      [0, 50, 100, 150, 200, 250].forEach(v => g += `<text x="40" y="${ys(v) + 4}" text-anchor="end" class="tm mono" style="font-size:10px">${v}</text><line x1="46" y1="${ys(v)}" x2="380" y2="${ys(v)}" class="s-ln" opacity=".25"/>`);
      [0, 20, 40, 60, 80, 100].forEach(T => g += `<text x="${xs(T)}" y="214" text-anchor="middle" class="tm mono" style="font-size:10px">${T}</text>`);
      g += `<rect x="${xs(lo)}" y="20" width="${xs(hi) - xs(lo)}" height="180" class="f-accs" opacity=".5"/>`;
      Object.keys(C).forEach(k => { let d = ''; for (let T = 0; T <= 100; T += 2) d += (T ? 'L' : 'M') + xs(T).toFixed(1) + ' ' + ys(solAt(k, T)).toFixed(1); g += `<path d="${d}" fill="none" stroke="${C[k][1]}" stroke-width="2.2"/>`; const ly = k === 'KNO3' ? ys(200) : ys(solAt(k, 100)) + (k === 'KCl' ? -4 : k === 'NaCl' ? 10 : -4); g += `<text x="${k === 'KNO3' ? xs(88) - 6 : 382}" y="${ly}" text-anchor="${k === 'KNO3' ? 'end' : 'end'}" style="font-size:11px;fill:${C[k][1]};font-weight:600">${C[k][0]}</text>`; });
      g += `<text x="380" y="228" text-anchor="end" class="tm" style="font-size:10px">তাপমাত্রা (°C)</text><text x="50" y="16" class="tm" style="font-size:10px">g / 100 g পানি</text>`;
      box.innerHTML = X.svg(400, 232, g, 'দ্রাব্যতা লেখ'); el.querySelector('[data-hv]').textContent = hi + '°C'; el.querySelector('[data-lv]').textContent = lo + '°C';
      const rows = Object.keys(C).map(k => { const a = solAt(k, hi), b = solAt(k, lo); return `<tr><td>${C[k][0]}</td><td class="mono">${a.toFixed(1)}</td><td class="mono">${b.toFixed(1)}</td><td class="mono"><b>${(a - b).toFixed(1)} g</b></td><td class="mono">${((a - b) / a * 100).toFixed(0)}%</td></tr>`; }).join('');
      out.innerHTML = `${hi}°C এ সম্পৃক্ত দ্রবণ (১০০ g পানি) ${lo}°C এ ঠান্ডা করলে কেলাস পড়বে:<div class="table-wrap" style="margin:6px 0 0"><table class="t sm"><thead><tr><th>লবণ</th><th>${hi}°C</th><th>${lo}°C</th><th>কেলাস</th><th>আদায়</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    };
    el.querySelectorAll('input').forEach(i => i.addEventListener('input', draw)); draw();
  }
};

/* ======================= 2.13 আয়ন শনাক্তকরণ — ভার্চুয়াল ল্যাব ======================= */
const CAT = {
  'Cu2+': ['Cu²⁺', '#7fb6e6', { 'NaOH': ['#7cb8f0', 'হালকা নীল জেলির মতো অধঃক্ষেপ Cu(OH)₂', 'Cu²⁺ + 2OH⁻ → Cu(OH)₂↓'], 'NaOHx': ['#7cb8f0', 'অধঃক্ষেপ দ্রবীভূত হয় না (তাপ দিলে কালো CuO)', 'Cu(OH)₂ → CuO + H₂O (Δ)'], 'NH3': ['#7cb8f0', 'হালকা নীল অধঃক্ষেপ', 'Cu²⁺ + 2NH₄OH → Cu(OH)₂↓ + 2NH₄⁺'], 'NH3x': ['sol:#1f3fbf', 'অধঃক্ষেপ দ্রবীভূত হয়ে গাঢ় নীল দ্রবণ', 'Cu(OH)₂ + 4NH₃ → [Cu(NH₃)₄]²⁺ + 2OH⁻'], 'sp': ['#7a3e1d', 'K₄[Fe(CN)₆]: চকলেট বাদামি অধঃক্ষেপ', '2Cu²⁺ + [Fe(CN)₆]⁴⁻ → Cu₂[Fe(CN)₆]↓'] }],
  'Fe2+': ['Fe²⁺', '#cfe8c8', { 'NaOH': ['#5d7f4b', 'ময়লা সবুজ অধঃক্ষেপ Fe(OH)₂; বাতাসে ধীরে বাদামি হয়', 'Fe²⁺ + 2OH⁻ → Fe(OH)₂↓'], 'NaOHx': ['#5d7f4b', 'অতিরিক্তে দ্রবীভূত হয় না', '—'], 'NH3': ['#5d7f4b', 'ময়লা সবুজ অধঃক্ষেপ', 'Fe²⁺ + 2NH₄OH → Fe(OH)₂↓ + 2NH₄⁺'], 'NH3x': ['#5d7f4b', 'অতিরিক্তে দ্রবীভূত হয় না', '—'], 'sp': ['#1a2a8a', 'K₃[Fe(CN)₆]: গাঢ় নীল অধঃক্ষেপ (টার্নবুলস ব্লু)', 'Fe²⁺ + [Fe(CN)₆]³⁻ → গাঢ় নীল জটিল যৌগ'] }],
  'Fe3+': ['Fe³⁺', '#e8c27a', { 'NaOH': ['#8a3b12', 'লালচে বাদামি অধঃক্ষেপ Fe(OH)₃', 'Fe³⁺ + 3OH⁻ → Fe(OH)₃↓'], 'NaOHx': ['#8a3b12', 'অতিরিক্তে দ্রবীভূত হয় না', '—'], 'NH3': ['#8a3b12', 'লালচে বাদামি অধঃক্ষেপ', 'Fe³⁺ + 3NH₄OH → Fe(OH)₃↓ + 3NH₄⁺'], 'NH3x': ['#8a3b12', 'অতিরিক্তে দ্রবীভূত হয় না', '—'], 'sp': ['sol:#a40000', 'KSCN: রক্তলাল দ্রবণ (K₄[Fe(CN)₆] দিলে প্রুশিয়ান ব্লু)', 'Fe³⁺ + SCN⁻ → [Fe(SCN)]²⁺ (রক্তলাল)'] }],
  'Al3+': ['Al³⁺', '#eef3f7', { 'NaOH': ['#f4f4f4', 'সাদা জেলির মতো অধঃক্ষেপ Al(OH)₃', 'Al³⁺ + 3OH⁻ → Al(OH)₃↓'], 'NaOHx': ['sol:#eef3f7', 'অতিরিক্ত NaOH এ দ্রবীভূত হয় (বর্ণহীন)', 'Al(OH)₃ + OH⁻ → [Al(OH)₄]⁻'], 'NH3': ['#f4f4f4', 'সাদা জেলির মতো অধঃক্ষেপ', 'Al³⁺ + 3NH₄OH → Al(OH)₃↓ + 3NH₄⁺'], 'NH3x': ['#f4f4f4', 'অতিরিক্ত NH₄OH এ দ্রবীভূত হয় না', '— (Zn²⁺ থেকে পার্থক্য)'], 'sp': ['#f4f4f4', 'NH₄Cl + NH₄OH: সাদা অধঃক্ষেপ (গ্রুপ III)', 'Al(OH)₃ — অত্যন্ত ক্ষুদ্র Ksp'] }],
  'Zn2+': ['Zn²⁺', '#eef3f7', { 'NaOH': ['#f4f4f4', 'সাদা অধঃক্ষেপ Zn(OH)₂', 'Zn²⁺ + 2OH⁻ → Zn(OH)₂↓'], 'NaOHx': ['sol:#eef3f7', 'অতিরিক্তে দ্রবীভূত হয় (বর্ণহীন)', 'Zn(OH)₂ + 2OH⁻ → [Zn(OH)₄]²⁻'], 'NH3': ['#f4f4f4', 'সাদা অধঃক্ষেপ', 'Zn²⁺ + 2NH₄OH → Zn(OH)₂↓ + 2NH₄⁺'], 'NH3x': ['sol:#eef3f7', 'অতিরিক্ত NH₄OH এও দ্রবীভূত হয় (বর্ণহীন)', 'Zn(OH)₂ + 4NH₃ → [Zn(NH₃)₄]²⁺ + 2OH⁻'], 'sp': ['#f4f4f4', 'ক্ষারীয় মাধ্যমে H₂S: সাদা অধঃক্ষেপ ZnS (গ্রুপ IV)', 'Zn²⁺ + S²⁻ → ZnS↓'] }],
  'Ca2+': ['Ca²⁺', '#eef3f7', { 'NaOH': ['#f7f7f7', 'গাঢ় দ্রবণে সামান্য সাদা অধঃক্ষেপ (Ca(OH)₂ অল্প দ্রবণীয়)', 'Ca²⁺ + 2OH⁻ ⇌ Ca(OH)₂'], 'NaOHx': ['#f7f7f7', 'অতিরিক্তে দ্রবীভূত হয় না', '—'], 'NH3': ['sol:#eef3f7', 'কোনো অধঃক্ষেপ পড়ে না', '[OH⁻] যথেষ্ট নয়'], 'NH3x': ['sol:#eef3f7', 'কোনো অধঃক্ষেপ পড়ে না', '—'], 'sp': ['#f7f7f7', '(NH₄)₂C₂O₄: সাদা অধঃক্ষেপ CaC₂O₄ (ইথানোয়িক এসিডে অদ্রবণীয়)', 'Ca²⁺ + C₂O₄²⁻ → CaC₂O₄↓'] }],
  'Pb2+': ['Pb²⁺', '#eef3f7', { 'NaOH': ['#f4f4f4', 'সাদা অধঃক্ষেপ Pb(OH)₂', 'Pb²⁺ + 2OH⁻ → Pb(OH)₂↓'], 'NaOHx': ['sol:#eef3f7', 'অতিরিক্ত NaOH এ দ্রবীভূত হয়', 'Pb(OH)₂ + 2OH⁻ → [Pb(OH)₄]²⁻'], 'NH3': ['#f4f4f4', 'সাদা অধঃক্ষেপ', 'Pb²⁺ + 2NH₄OH → Pb(OH)₂↓ + 2NH₄⁺'], 'NH3x': ['#f4f4f4', 'অতিরিক্ত NH₄OH এ দ্রবীভূত হয় না', '—'], 'sp': ['#f2cf2a', 'KI: হলুদ অধঃক্ষেপ PbI₂ (গরম পানিতে দ্রবীভূত, ঠান্ডায় সোনালি চকচকে কেলাস)', 'Pb²⁺ + 2I⁻ → PbI₂↓'] }],
  'NH4+': ['NH₄⁺', '#eef3f7', { 'NaOH': ['gas', 'অধঃক্ষেপ নেই; গরম করলে ঝাঁঝালো NH₃ গ্যাস — ভেজা লাল লিটমাস নীল', 'NH₄⁺ + OH⁻ → NH₃↑ + H₂O (Δ)'], 'NaOHx': ['gas', 'NH₃ গ্যাস; গাঢ় HCl ভেজা কাচদণ্ড ধরলে সাদা ধোঁয়া (NH₄Cl)', 'NH₃ + HCl → NH₄Cl (সাদা ধোঁয়া)'], 'NH3': ['sol:#eef3f7', 'কোনো পরিবর্তন নেই', '—'], 'NH3x': ['sol:#eef3f7', 'কোনো পরিবর্তন নেই', '—'], 'sp': ['#9a4b12', 'নেসলার বিকারক: বাদামি অধঃক্ষেপ/রং', 'NH₃ + নেসলার বিকারক (K₂HgI₄ + KOH) → বাদামি'] }]
};
const ANI = {
  'Cl-': ['Cl⁻', { 'Ag': ['#f6f6f6', 'সাদা দই-সদৃশ অধঃক্ষেপ AgCl', 'Ag⁺ + Cl⁻ → AgCl↓'], 'AgN': ['sol:#eef3f7', 'লঘু NH₄OH এ সহজে দ্রবীভূত হয়', 'AgCl + 2NH₃ → [Ag(NH₃)₂]⁺ + Cl⁻'], 'Ba': ['sol:#eef3f7', 'কোনো অধঃক্ষেপ নেই', '—'], 'H': ['sol:#eef3f7', 'লঘু এসিডে কোনো গ্যাস নেই', '—'], 'sp': ['gas', 'গাঢ় H₂SO₄: HCl গ্যাস — NH₃ এর কাছে সাদা ধোঁয়া', 'NaCl + H₂SO₄ → NaHSO₄ + HCl↑'] }],
  'Br-': ['Br⁻', { 'Ag': ['#f3eab0', 'হালকা হলুদ অধঃক্ষেপ AgBr', 'Ag⁺ + Br⁻ → AgBr↓'], 'AgN': ['#f3eab0', 'লঘু NH₄OH এ প্রায় অদ্রবণীয় (গাঢ়তে আংশিক)', '—'], 'Ba': ['sol:#eef3f7', 'কোনো অধঃক্ষেপ নেই', '—'], 'H': ['sol:#eef3f7', 'কোনো গ্যাস নেই', '—'], 'sp': ['layer:#c8641e', 'ক্লোরিন পানি + CCl₄: জৈব স্তর কমলা-বাদামি (Br₂)', 'Cl₂ + 2Br⁻ → 2Cl⁻ + Br₂'] }],
  'I-': ['I⁻', { 'Ag': ['#efd23a', 'হলুদ অধঃক্ষেপ AgI', 'Ag⁺ + I⁻ → AgI↓'], 'AgN': ['#efd23a', 'NH₄OH এ অদ্রবণীয়', '—'], 'Ba': ['sol:#eef3f7', 'কোনো অধঃক্ষেপ নেই', '—'], 'H': ['sol:#eef3f7', 'কোনো গ্যাস নেই', '—'], 'sp': ['layer:#7b2ea8', 'ক্লোরিন পানি + CCl₄: জৈব স্তর বেগুনি (I₂); স্টার্চে নীল', 'Cl₂ + 2I⁻ → 2Cl⁻ + I₂'] }],
  'SO42-': ['SO₄²⁻', { 'Ag': ['sol:#eef3f7', 'লঘু দ্রবণে সাধারণত অধঃক্ষেপ নেই', '—'], 'AgN': ['sol:#eef3f7', '—', '—'], 'Ba': ['#f6f6f6', 'সাদা অধঃক্ষেপ BaSO₄ — লঘু HCl এ অদ্রবণীয়', 'Ba²⁺ + SO₄²⁻ → BaSO₄↓'], 'H': ['sol:#eef3f7', 'কোনো গ্যাস নেই', '—'], 'sp': ['#f6f6f6', 'লেড অ্যাসিটেট: সাদা অধঃক্ষেপ PbSO₄', 'Pb²⁺ + SO₄²⁻ → PbSO₄↓'] }],
  'CO32-': ['CO₃²⁻', { 'Ag': ['#f2f0e6', 'হালকা হলদে-সাদা Ag₂CO₃ (লঘু HNO₃ এ বুদবুদসহ দ্রবীভূত)', '2Ag⁺ + CO₃²⁻ → Ag₂CO₃↓'], 'AgN': ['sol:#eef3f7', '—', '—'], 'Ba': ['#f6f6f6', 'সাদা BaCO₃ — লঘু HCl এ বুদবুদসহ দ্রবীভূত (SO₄²⁻ থেকে পার্থক্য)', 'BaCO₃ + 2HCl → BaCl₂ + H₂O + CO₂↑'], 'H': ['bub', 'লঘু HCl এ বুদবুদ — CO₂; চুনের পানি ঘোলা', 'CO₃²⁻ + 2H⁺ → H₂O + CO₂↑; Ca(OH)₂ + CO₂ → CaCO₃↓ + H₂O'], 'sp': ['#f6f6f6', 'ঠান্ডায় MgSO₄: সাদা MgCO₃ অধঃক্ষেপ (HCO₃⁻ এ শুধু ফোটালে)', 'Mg²⁺ + CO₃²⁻ → MgCO₃↓'] }],
  'NO3-': ['NO₃⁻', { 'Ag': ['sol:#eef3f7', 'কোনো অধঃক্ষেপ নেই', '—'], 'AgN': ['sol:#eef3f7', '—', '—'], 'Ba': ['sol:#eef3f7', 'কোনো অধঃক্ষেপ নেই', '—'], 'H': ['sol:#eef3f7', 'লঘু এসিডে কোনো গ্যাস নেই', '—'], 'sp': ['ring', 'বাদামি বলয় পরীক্ষা: সদ্য প্রস্তুত FeSO₄ + নলের গা বেয়ে গাঢ় H₂SO₄ → সংযোগস্থলে বাদামি বলয়', 'NO₃⁻ + 3Fe²⁺ + 4H⁺ → NO + 3Fe³⁺ + 2H₂O; [Fe(H₂O)₆]²⁺ + NO → [Fe(H₂O)₅NO]²⁺ (বাদামি)'] }],
  'S2-': ['S²⁻', { 'Ag': ['#222', 'কালো অধঃক্ষেপ Ag₂S', '2Ag⁺ + S²⁻ → Ag₂S↓'], 'AgN': ['#222', 'অদ্রবণীয়', '—'], 'Ba': ['sol:#eef3f7', 'অধঃক্ষেপ নেই', '—'], 'H': ['bub', 'লঘু HCl: পচা ডিমের গন্ধযুক্ত H₂S; লেড অ্যাসিটেট কাগজ কালো', 'S²⁻ + 2H⁺ → H₂S↑; H₂S + Pb²⁺ → PbS↓ (কালো)'], 'sp': ['sol:#8a2be2', 'সোডিয়াম নাইট্রোপ্রুসাইড: বেগুনি রং', '—'] }],
  'SO32-': ['SO₃²⁻', { 'Ag': ['#f6f6f6', 'সাদা অধঃক্ষেপ Ag₂SO₃', '—'], 'AgN': ['sol:#eef3f7', '—', '—'], 'Ba': ['#f6f6f6', 'সাদা BaSO₃ — লঘু HCl এ দ্রবীভূত (SO₄²⁻ থেকে পার্থক্য)', 'Ba²⁺ + SO₃²⁻ → BaSO₃↓'], 'H': ['bub', 'লঘু HCl: ঝাঁঝালো SO₂ — অম্লীয় K₂Cr₂O₇ কাগজ কমলা থেকে সবুজ', 'SO₃²⁻ + 2H⁺ → SO₂↑ + H₂O'], 'sp': ['sol:#f1d5f0', 'অম্লীয় KMnO₄ এর বেগুনি রং বিবর্ণ হয়', '5SO₂ + 2MnO₄⁻ + 2H₂O → 5SO₄²⁻ + 2Mn²⁺ + 4H⁺'] }],
  'PO43-': ['PO₄³⁻', { 'Ag': ['#f2d34a', 'হলুদ অধঃক্ষেপ Ag₃PO₄ (লঘু HNO₃ এ দ্রবণীয়)', '3Ag⁺ + PO₄³⁻ → Ag₃PO₄↓'], 'AgN': ['sol:#eef3f7', '—', '—'], 'Ba': ['#f6f6f6', 'সাদা Ba₃(PO₄)₂ (লঘু এসিডে দ্রবণীয়)', '—'], 'H': ['sol:#eef3f7', 'কোনো গ্যাস নেই', '—'], 'sp': ['#f5d000', 'অ্যামোনিয়াম মলিবডেট + গাঢ় HNO₃, উষ্ণ: উজ্জ্বল হলুদ অধঃক্ষেপ', 'হলুদ অ্যামোনিয়াম ফসফোমলিবডেট'] }]
};
const RCAT = [['NaOH', 'NaOH (অল্প)'], ['NaOHx', 'NaOH (অতিরিক্ত)'], ['NH3', 'NH₄OH (অল্প)'], ['NH3x', 'NH₄OH (অতিরিক্ত)'], ['sp', 'নিশ্চিতকরণ']];
const RANI = [['Ag', 'AgNO₃ (+HNO₃)'], ['AgN', 'অধঃক্ষেপ + NH₄OH'], ['Ba', 'BaCl₂ (+লঘু HCl)'], ['H', 'লঘু HCl'], ['sp', 'নিশ্চিতকরণ']];
const tubeSVG = (base, res, k) => {
  let liq = base, ppt = '', extra = '';
  const kind = res[0];
  if (kind.startsWith('sol:')) liq = kind.slice(4);
  else if (kind === 'gas' || kind === 'bub') { const rnd = X.rng(7); for (let i = 0; i < 14; i++) { const y = 160 - ((i * 13 + k * 120) % 120); extra += `<circle cx="${(188 + rnd() * 24).toFixed(1)}" cy="${y.toFixed(1)}" r="${(2 + rnd() * 2).toFixed(1)}" fill="none" stroke="#6aa0c8"/>`; } if (kind === 'gas') extra += `<path d="M200 40 q-8 -10 0 -18 q8 -8 0 -16" fill="none" class="s-mu" stroke-dasharray="3 3"/>`; }
  else if (kind.startsWith('layer:')) { extra += `<path d="M178 168 L222 168 L222 188 Q222 202 200 202 Q178 202 178 188Z" fill="${kind.slice(6)}" opacity=".85"/>`; }
  else if (kind === 'ring') { extra += `<rect x="178" y="128" width="44" height="7" fill="#6b3a12" opacity=".9"/><rect x="178" y="135" width="44" height="60" fill="#d8d0ff" opacity=".35"/>`; }
  else { const rnd = X.rng(11); const f = Math.min(1, k * 1.3); for (let i = 0; i < 40; i++) { const x = 181 + rnd() * 38, y0 = 90 + rnd() * 80; const y = y0 + (196 - y0) * f * (0.5 + rnd() * 0.5); ppt += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${(1.8 + rnd() * 1.8).toFixed(1)}" fill="${kind}" stroke="rgba(0,0,0,.25)" stroke-width=".4"/>`; } }
  return `<path d="M176 30 L176 190 Q176 206 200 206 Q224 206 224 190 L224 30" fill="none" class="s-fg" stroke-width="2"/><path d="M178 80 L178 190 Q178 204 200 204 Q222 204 222 190 L222 80Z" fill="${liq}" opacity=".75"/>${ppt}${extra}`;
};
const labFactory = (DATA, R, isCat, title) => ({
  t: title, k: ['anim', 'int'],
  cap: isCat ? 'একটি ক্যাটায়ন বেছে নাও, তারপর বিকারক যোগ করো। "অল্প" মানে কয়েক ফোঁটা, "অতিরিক্ত" মানে বেশি পরিমাণে। ফলাফলের সাথে আয়নিক সমীকরণও দেখানো হবে। একই NaOH/NH₄OH পরীক্ষায় অনেক আয়ন সাদা অধঃক্ষেপ দেয় — অতিরিক্ত বিকারকে দ্রবণীয়তা দেখে এদের আলাদা করো।' : 'একটি অ্যানায়ন বেছে নাও, তারপর বিকারক যোগ করো। AgNO₃ এর আগে লঘু HNO₃ এবং BaCl₂ এর আগে লঘু HCl দেওয়া হয় যাতে CO₃²⁻, SO₃²⁻ ইত্যাদি ভুল অধঃক্ষেপ না দেয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('ion', Object.keys(DATA).map(k => [k, DATA[k][0]]), Object.keys(DATA)[0])}</div><div data-svg></div><div class="ctl">${R.map(([k, n]) => `<button class="btn sm" data-r="${k}">${n}</button>`).join('')}</div><div class="calc-out" data-out>বিকারক যোগ করো।</div>`,
  mount(el) {
    let ion = Object.keys(DATA)[0], timer = null; const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const base = () => isCat ? DATA[ion][1] : '#eef3f7';
    const res = r => isCat ? DATA[ion][2][r] : DATA[ion][1][r];
    const draw = (r, k) => { const rr = r ? res(r) : ['sol:' + base()]; box.innerHTML = X.svg(400, 214, tubeSVG(base(), rr, k) + `<text x="120" y="120" text-anchor="end" style="font-size:13px;font-weight:600">${DATA[ion][0]}</text><text x="120" y="138" text-anchor="end" class="tm" style="font-size:11px">${isCat ? 'লবণের দ্রবণ' : 'লবণের দ্রবণ'}</text>${r ? `<text x="240" y="60" style="font-size:11.5px">+ ${R.find(x => x[0] === r)[1]}</text><path d="M236 56 L226 70" class="s-mu"/>` : ''}`, 'টেস্টটিউব'); };
    const add = r => { clearInterval(timer); const rr = res(r); out.innerHTML = `<b style="font-family:var(--font-body)">${rr[1]}</b>${rr[2] && rr[2] !== '—' ? `<br><span class="mono small">${rr[2]}</span>` : ''}`; let k = 0; timer = setInterval(() => { k += 0.05; draw(r, k); if (k >= 1.2 && !/gas|bub/.test(rr[0])) clearInterval(timer); if (k > 6) clearInterval(timer); }, 50); };
    X.onSeg(el, 'ion', k => { ion = k; clearInterval(timer); draw(null, 0); out.innerHTML = 'বিকারক যোগ করো।'; });
    el.querySelectorAll('[data-r]').forEach(b => b.onclick = () => add(b.dataset.r));
    draw(null, 0);
    return () => clearInterval(timer);
  }
});
V.cationLab = labFactory(CAT, RCAT, true, 'ভার্চুয়াল ল্যাব: ক্যাটায়ন শনাক্তকরণ (NaOH, NH₄OH ও নিশ্চিতকরণ পরীক্ষা)');
V.anionLab = labFactory(ANI, RANI, false, 'ভার্চুয়াল ল্যাব: অ্যানায়ন শনাক্তকরণ');

V.groupFlow = {
  t: 'ক্যাটায়নের গ্রুপ বিশ্লেষণ: প্রবাহচিত্র', k: ['2d', 'info'],
  cap: 'মিশ্রণ থেকে গ্রুপ বিকারক ধাপে ধাপে যোগ করে ক্যাটায়নগুলোকে ছয়টি গ্রুপে আলাদা করা হয়। প্রতিটি ধাপে কেবল সেই আয়নগুলোই অধঃক্ষিপ্ত হয় যাদের আয়নিক গুণফল ঐ অবস্থায় Ksp ছাড়িয়ে যায় — সম-আয়ন প্রভাব দিয়ে [S²⁻] ও [OH⁻] নিয়ন্ত্রণ করা হয়।',
  html() {
    const G = [['I', 'লঘু HCl', 'Ag⁺, Pb²⁺, Hg₂²⁺', 'সাদা ক্লোরাইড'], ['II', 'HCl + H₂S', 'Cu²⁺, Pb²⁺, Cd²⁺, Hg²⁺, Bi³⁺…', 'সালফাইড (অতি ক্ষুদ্র Ksp)'], ['III', 'NH₄Cl + NH₄OH', 'Fe³⁺, Al³⁺, Cr³⁺', 'হাইড্রোক্সাইড'], ['IV', 'NH₄OH + H₂S', 'Zn²⁺, Mn²⁺, Ni²⁺, Co²⁺', 'সালফাইড (বড় Ksp)'], ['V', '(NH₄)₂CO₃ (+NH₄Cl)', 'Ca²⁺, Sr²⁺, Ba²⁺', 'কার্বনেট'], ['VI', 'বিকারক নেই', 'Mg²⁺, Na⁺, K⁺, NH₄⁺', 'আলাদা পরীক্ষা']];
    let s = `<defs>${X.arrow('gfA')}</defs><rect x="120" y="4" width="160" height="26" rx="13" class="f-accs s-acc"/><text x="200" y="22" text-anchor="middle" style="font-size:12px;font-weight:600">মিশ্র ক্যাটায়নের দ্রবণ</text>`;
    G.forEach(([n, r, ions, ppt], i) => {
      const y = 44 + i * 58;
      s += `<line x1="70" y1="${y - 14 + (i ? 0 : 0)}" x2="70" y2="${y + 2}" class="s-fg" marker-end="url(#gfA)"/>`;
      s += `<rect x="20" y="${y + 4}" width="100" height="40" rx="8" class="f-s2 s-ln"/><text x="70" y="${y + 20}" text-anchor="middle" style="font-size:11px;font-weight:700">গ্রুপ ${n}</text><text x="70" y="${y + 36}" text-anchor="middle" style="font-size:9.5px">${r.length > 18 ? r.slice(0, 18) + '…' : r}</text>`;
      s += `<line x1="120" y1="${y + 24}" x2="160" y2="${y + 24}" class="s-fg" marker-end="url(#gfA)"/><rect x="164" y="${y + 6}" width="226" height="36" rx="8" class="f-sf s-acc"/><text x="174" y="${y + 21}" style="font-size:11px;font-weight:600">${ions}</text><text x="174" y="${y + 36}" class="tm" style="font-size:10px">অধঃক্ষেপ: ${ppt}</text>`;
      if (i < G.length - 1) s += `<text x="76" y="${y + 56}" class="tm" style="font-size:9px">পরিস্রুত →</text>`;
    });
    s += `<line x1="70" y1="30" x2="70" y2="42" class="s-fg"/>`;
    return X.svg(400, 396, s, 'গ্রুপ বিশ্লেষণ');
  }
};

/* ======================= 2.13.1 বিকারক প্রস্তুতি ======================= */
const REAG = [['NaOH', 'NaOH', 40.00], ['AgNO3', 'AgNO₃', 169.87], ['BaCl2', 'BaCl₂·2H₂O', 244.26], ['KSCN', 'KSCN', 97.18], ['K4', 'K₄[Fe(CN)₆]·3H₂O', 422.39], ['NH4ox', '(NH₄)₂C₂O₄·H₂O', 142.11], ['KI', 'KI', 166.00], ['Na2CO3', 'Na₂CO₃', 105.99], ['FeSO4', 'FeSO₄·7H₂O', 278.01]];
const CONC = [['HCl', 'গাঢ় HCl (৩৭%, ১.১৮ g mL⁻¹)', 36.46, 0.37, 1.18], ['H2SO4', 'গাঢ় H₂SO₄ (৯৮%, ১.৮৪ g mL⁻¹)', 98.08, 0.98, 1.84], ['HNO3', 'গাঢ় HNO₃ (৭০%, ১.৪২ g mL⁻¹)', 63.01, 0.70, 1.42], ['NH3', 'গাঢ় NH₃ দ্রবণ (২৮%, ০.৯০ g mL⁻¹)', 17.03, 0.28, 0.90]];
V.reagentCalc = {
  t: 'বিকারক প্রস্তুতি ক্যালকুলেটর', k: ['calc'],
  cap: 'কঠিন থেকে: প্রয়োজনীয় ভর = মোলারিটি × আয়তন (L) × মোলার ভর। গাঢ় এসিড থেকে লঘুকরণ: C₁V₁ = C₂V₂; গাঢ় দ্রবণের মোলারিটি = (১০ × শতকরা মাত্রা × ঘনত্ব) / মোলার ভর। সবসময় এসিড পানিতে ধীরে ধীরে ঢালবে — কখনো পানি এসিডে নয়।',
  html: () => `<div class="ctl" style="margin:0 0 8px">${X.seg('rm', [['s', 'কঠিন থেকে'], ['d', 'গাঢ় এসিড/ক্ষার থেকে']], 's')}</div>
  <div data-s><div class="grid3"><label class="stack" style="gap:4px"><span class="small muted">বিকারক</span><select class="inp" data-r>${REAG.map(r => `<option value="${r[0]}">${r[1]}</option>`).join('')}</select></label><label class="stack" style="gap:4px"><span class="small muted">মোলারিটি (M)</span><input class="inp mono" data-m value="0.1"></label><label class="stack" style="gap:4px"><span class="small muted">আয়তন (mL)</span><input class="inp mono" data-v value="250"></label></div></div>
  <div data-d hidden><div class="grid3"><label class="stack" style="gap:4px"><span class="small muted">গাঢ় দ্রবণ</span><select class="inp" data-c>${CONC.map(r => `<option value="${r[0]}">${r[1]}</option>`).join('')}</select></label><label class="stack" style="gap:4px"><span class="small muted">কাঙ্ক্ষিত M</span><input class="inp mono" data-m2 value="2"></label><label class="stack" style="gap:4px"><span class="small muted">আয়তন (mL)</span><input class="inp mono" data-v2 value="500"></label></div></div>
  <div class="calc-out" data-out></div>`,
  mount(el) {
    const q = s => el.querySelector(s), out = q('[data-out]'); let mode = 's';
    const run = () => {
      if (mode === 's') { const r = REAG.find(x => x[0] === q('[data-r]').value), M = +q('[data-m]').value, V = +q('[data-v]').value; const g = M * V / 1000 * r[2]; out.innerHTML = `ভর = ${M} × ${V}/1000 × ${r[2]} = <b>${g.toFixed(3)} g</b> ${r[1]}<br><span class="small">${g.toFixed(2)} g ওজন করে অল্প পাতিত পানিতে দ্রবীভূত করো, তারপর ${V} mL আয়তনিক ফ্লাস্কে নিয়ে দাগ পর্যন্ত পাতিত পানি যোগ করো।${r[0] === 'AgNO3' ? ' AgNO₃ দ্রবণ আলোয় বিয়োজিত হয় — বাদামি বোতলে রাখো।' : r[0] === 'FeSO4' ? ' FeSO₄ বাতাসে জারিত হয় — সদ্য প্রস্তুত করো, কয়েক ফোঁটা লঘু H₂SO₄ যোগ করো।' : r[0] === 'NaOH' ? ' NaOH আর্দ্রতাগ্রাহী ও CO₂ শোষণ করে — দ্রুত ওজন করো, প্লাস্টিক বা রাবার ছিপির বোতলে রাখো।' : ''}</span>`; }
      else { const c = CONC.find(x => x[0] === q('[data-c]').value), M2 = +q('[data-m2]').value, V2 = +q('[data-v2]').value; const Mc = c[3] * c[4] * 1000 / c[2]; const V1 = M2 * V2 / Mc; out.innerHTML = `গাঢ় দ্রবণের মোলারিটি = (${(c[3] * 100).toFixed(0)}/100 × ${c[4]} × 1000)/${c[2]} = <b>${Mc.toFixed(1)} M</b><br>C₁V₁ = C₂V₂ ⟹ V₁ = ${M2} × ${V2}/${Mc.toFixed(1)} = <b>${V1.toFixed(1)} mL</b> গাঢ় দ্রবণ<br><span class="small">প্রায় ${(V2 * 0.6).toFixed(0)} mL পাতিত পানি নিয়ে তাতে ${V1.toFixed(1)} mL গাঢ় দ্রবণ নাড়তে নাড়তে ধীরে ঢালো, ঠান্ডা হলে ${V2} mL পর্যন্ত পানি যোগ করো।${c[0] === 'H2SO4' ? ' <b>গাঢ় H₂SO₄ পানিতে মেশালে প্রচুর তাপ উৎপন্ন হয় — এসিড পানিতে, কখনো পানি এসিডে নয়।</b>' : c[0] === 'NH3' ? ' ধোঁয়া-নিষ্কাশন কক্ষে কাজ করো।' : ''}</span>`; }
    };
    X.onSeg(el, 'rm', k => { mode = k; q('[data-s]').hidden = k !== 's'; q('[data-d]').hidden = k !== 'd'; run(); });
    el.querySelectorAll('input,select').forEach(i => i.addEventListener('input', run)); run();
  }
};

})();
