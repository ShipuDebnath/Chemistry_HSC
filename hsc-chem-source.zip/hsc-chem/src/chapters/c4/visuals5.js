/* Chapter 4 visuals part 5 — catalysis (4.4) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, f1 = C4.f1, INK = C4.INK, ball = C4.ball;
const TXR = C4.tx, TXB = C4.txb, sci = C4.sci, path = C4.path;
const lerp = C4.lerp, ease = C4.ease;

/* flask drawing on canvas */
const flask = (g, x, y, w, h, liquid, col, label) => {
  const neck = w * 0.28;
  g.beginPath(); g.moveTo(x + w / 2 - neck / 2, y); g.lineTo(x + w / 2 - neck / 2, y + h * 0.32); g.lineTo(x, y + h - 8); g.quadraticCurveTo(x, y + h, x + 8, y + h); g.lineTo(x + w - 8, y + h); g.quadraticCurveTo(x + w, y + h, x + w, y + h - 8); g.lineTo(x + w / 2 + neck / 2, y + h * 0.32); g.lineTo(x + w / 2 + neck / 2, y); g.closePath();
  g.save(); g.clip(); g.fillStyle = liquid; g.fillRect(x - 2, y + h * 0.55, w + 4, h); g.restore();
  g.strokeStyle = col.fg; g.lineWidth = 1.6; g.stroke();
  g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(x + w * 0.18, y + h * 0.5, 3, h * 0.4);
  if (label) { g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(label, x + w / 2, y + h + 15); }
};

/* ======================= ৪.৪ প্রভাবকের প্রকারভেদ: চারটি ভার্চুয়াল পরীক্ষা ======================= */
V.c4_catTypes = {
  t: 'প্রভাবকের প্রকারভেদ: ধনাত্মক, ঋণাত্মক, স্বপ্রভাবক এবং সহায়ক ও বিষ (ভার্চুয়াল পরীক্ষা)', k: ['anim', 'int', '2d'],
  cap: 'একটি পরীক্ষা বেছে "শুরু" চাপো — পাশাপাশি পাত্রে একই বিক্রিয়া ভিন্ন শর্তে চলে, নিচে উৎপাদ-সময় লেখচিত্রে তুলনা। ধনাত্মক: MnO₂ দিলে H₂O₂ দ্রুত O₂ ছাড়ে, শেষে নিক্তিতে MnO₂ এর ভর একই। ঋণাত্মক: H₃PO₄ বিয়োজন আরও ধীর করে। স্বপ্রভাবক: অম্লীয় KMnO₄ + অক্সালিক এসিডে গোলাপি রং প্রথমে ধীরে, পরে হঠাৎ দ্রুত মোছে (উৎপন্ন Mn²⁺) — S আকৃতির লেখচিত্র; শুরুতে Mn²⁺ দিলে আবেশ কাল থাকে না। সহায়ক ও বিষ: হেবার পদ্ধতিতে Fe, Fe + Mo, Fe + H₂S — সহায়কে দ্রুত, বিষে প্রায় থেমে যায়; কিন্তু সবাই একই সাম্য উৎপাদনের দিকে যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['pos', 'ধনাত্মক'], ['neg', 'ঋণাত্মক'], ['auto', 'স্বপ্রভাবক'], ['prom', 'সহায়ক ও বিষ']], 'pos')}</div>${X.cv('প্রভাবকের প্রকারভেদের ভার্চুয়াল পরীক্ষা')}<div class="ctl"><button class="btn sm primary" data-go>${X.ico('play')}শুরু</button><label class="small" data-mnl style="display:none"><input type="checkbox" data-mn> শুরুতে MnSO₄ (Mn²⁺) যোগ</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), mnBox = el.querySelector('[data-mn]');
    let L = X.fit(c, w => Math.min(440, w * 1.05)), mode = 'pos', t = 0, running = false, bubbles = [];
    const R = X.rng(4);
    const TM = { pos: 60, neg: 60, auto: 60, prom: 60 };
    // models: return product fraction (0..1) at time t for each vessel
    const MODELS = {
      pos: [['H₂O₂', t => 1 - Math.exp(-0.012 * t), '#9aa3ad'], ['H₂O₂ + MnO₂', t => 1 - Math.exp(-0.15 * t), '#2e9d4e']],
      neg: [['H₂O₂', t => 1 - Math.exp(-0.012 * t), '#9aa3ad'], ['H₂O₂ + H₃PO₄', t => 1 - Math.exp(-0.003 * t), '#e0402e']],
      auto: [['KMnO₄ + H₂C₂O₄', t => { const k = 0.18, x0 = 0.004; return 1 / (1 + (1 / x0 - 1) * Math.exp(-k * t)) - x0; }, '#b03a8c'], ['+ শুরুতে Mn²⁺', t => 1 - Math.exp(-0.16 * t), '#2e9d4e']],
      prom: [['Fe', t => 0.32 * (1 - Math.exp(-0.06 * t)), '#2d6fd6'], ['Fe + Mo (সহায়ক)', t => 0.32 * (1 - Math.exp(-0.16 * t)), '#2e9d4e'], ['Fe + H₂S (বিষ)', t => 0.32 * (1 - Math.exp(-0.006 * t)), '#e0402e']]
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const M = MODELS[mode], n = mode === 'auto' && !mnBox.checked ? 1 : M.length, fw = Math.min(110, (W - 30) / M.length - 16), fh = 120, top = 18;
      const list = mode === 'auto' ? (mnBox.checked ? M : [M[0]]) : M;
      list.forEach(([nm, fn, cc], i) => {
        const x = 15 + i * ((W - 30) / list.length) + ((W - 30) / list.length - fw) / 2, fr = fn(t);
        let liq = 'rgba(160,200,240,.45)';
        if (mode === 'auto') { const a = Math.max(0, 1 - fr); liq = `rgba(${Math.round(176 + 70 * (1 - a))},${Math.round(58 + 180 * (1 - a))},${Math.round(140 + 90 * (1 - a))},${0.35 + 0.5 * a})`; }
        if (mode === 'prom') liq = 'rgba(200,210,220,.35)';
        flask(g, x, top, fw, fh, liq, col, nm);
        // catalyst solid at bottom
        if (mode === 'pos' && i === 1) { g.fillStyle = '#3a3a3a'; for (let k = 0; k < 9; k++) g.fillRect(x + fw * 0.3 + (k * 7) % (fw * 0.4), top + fh - 7 - (k % 2) * 3, 4, 3); }
        if (mode === 'prom') { g.fillStyle = i === 2 ? '#c9a227' : '#6b6b6b'; for (let k = 0; k < 12; k++) g.fillRect(x + 10 + (k * 9) % (fw - 20), top + fh - 9 - (k % 3) * 3, 5, 4); }
        // bubbles: rate ∝ derivative
        const rate = (fn(t + 0.5) - fn(t)) * 2;
        if (running && (mode === 'pos' || mode === 'neg' || mode === 'auto') && R() < rate * 60) bubbles.push({ v: i, x: x + fw * (0.25 + R() * 0.5), y: top + fh - 10, r: 1.5 + R() * 2.5 });
        g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center';
        g.fillText(mode === 'prom' ? `NH₃ ${bn(Math.round(fr * 100))}%` : mode === 'auto' ? `বিক্রিয়া ${bn(Math.round(fr * 100))}%` : `O₂ ${bn(Math.round(fr * 100))}%`, x + fw / 2, top + fh + 28);
      });
      bubbles.forEach(b => { g.strokeStyle = 'rgba(255,255,255,.9)'; g.fillStyle = 'rgba(200,230,255,.5)'; g.lineWidth = 1; g.beginPath(); g.arc(b.x, b.y, b.r, 0, 7); g.fill(); g.stroke(); });
      // balance readout for MnO2
      if (mode === 'pos') { g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'right'; g.fillText(t >= TM.pos - 0.5 ? 'বিক্রিয়া শেষে ছেঁকে MnO₂ = ৫.০০ g (অপরিবর্তিত)' : 'MnO₂ নেওয়া হয়েছে: ৫.০০ g', W - 12, top + fh + 44); }
      // graph
      const gx = 46, gy = top + fh + 58, gw = W - gx - 16, gh = H - gy - 30;
      const ymax = mode === 'prom' ? 0.4 : 1.05;
      const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax: TM[mode], ymax, col, xt: [0, 20, 40, 60], yt: mode === 'prom' ? [0, 0.1, 0.2, 0.3] : [0, 0.5, 1], fy: v => bn(Math.round(v * 100)) + '%', xl: mode === 'prom' ? 'সময় (min)' : 'সময় (s)', yl: mode === 'prom' ? 'NH₃' : 'উৎপাদ', ylx: 38 });
      if (mode === 'prom') { g.strokeStyle = col.mu; g.setLineDash([4, 4]); g.beginPath(); g.moveTo(gx, P.Y(0.32)); g.lineTo(gx + gw, P.Y(0.32)); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('সাম্য উৎপাদন (সবার জন্য একই)', gx + gw, P.Y(0.32) - 4); }
      M.forEach(([nm, fn, cc], i) => { if (mode === 'auto' && i === 1 && !mnBox.checked) return; const pts = []; const tm = Math.min(t, TM[mode]); for (let k = 0; k <= 100; k++) { const tt = k / 100 * tm; pts.push([P.X(tt), P.Y(fn(tt))]); } if (pts.length > 1) path(g, pts, cc, 2.6); });
    };
    const info = () => {
      const msg = {
        pos: TXB('\\ce{2H2O2 ->[MnO2] 2H2O + O2 ^}') + '<div class="small">MnO₂ সক্রিয়ণ শক্তি কমায় — বুদবুদ অনেক বেশি; বিক্রিয়া শেষে MnO₂ এর ভর একই।</div>',
        neg: TXB('\\ce{2H2O2 ->[H3PO4] 2H2O + O2}\\quad(\\text{ধীর})') + '<div class="small">ঋণাত্মক প্রভাবক (নিরোধক) — বিয়োজন আরও ধীর করে; H₂O₂ সংরক্ষণে ব্যবহৃত।</div>',
        auto: TXB('\\ce{2MnO4- + 5H2C2O4 + 6H+ ->[Mn^2+] 2Mn^2+ + 10CO2 + 8H2O}') + '<div class="small">উৎপাদ Mn²⁺ নিজেই প্রভাবক — শুরুতে আবেশ কাল, পরে দ্রুত (S আকৃতির লেখচিত্র)।</div>',
        prom: TXB('\\ce{N2 + 3H2 <=>[Fe] 2NH3}') + '<div class="small">Mo সহায়ক কার্যক্ষমতা বাড়ায়; H₂S বিষ সক্রিয় কেন্দ্র দখল করে। প্রভাবক বা সহায়ক কেউই সাম্য উৎপাদন বদলায় না।</div>'
      }[mode];
      out.innerHTML = msg;
    };
    const A = X.anim(el, dt => {
      if (dt && running) { t = Math.min(TM[mode], t + dt * 6); if (t >= TM[mode]) running = false; }
      if (dt) { bubbles.forEach(b => { b.y -= dt * 60; b.x += Math.sin(b.y * 0.2) * 0.3; }); bubbles = bubbles.filter(b => b.y > 40); }
      draw();
    }, { paused: false });
    el.querySelector('[data-go]').onclick = () => { t = 0; bubbles = []; running = true; };
    mnBox.onchange = () => { t = 0; bubbles = []; running = true; };
    X.onSeg(el, 'm', m => { mode = m; t = 0; bubbles = []; running = true; el.querySelector('[data-mnl]').style.display = m === 'auto' ? '' : 'none'; info(); });
    running = true; info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(440, w * 1.05)); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৪.১ অধিশোষণ তত্ত্ব: Ni পৃষ্ঠে ইথিনের হাইড্রোজেনেশন ======================= */
V.c4_surfaceCat = {
  t: 'অধিশোষণ তত্ত্ব: Ni পৃষ্ঠে ইথিনের হাইড্রোজেনেশন (প্রভাবক বিষসহ)', k: ['anim', 'int', '2d'],
  cap: 'ধূসর বলগুলো Ni ধাতুর পৃষ্ঠের পরমাণু — প্রতিটি একটি সক্রিয় কেন্দ্র। H₂ অণু পৃষ্ঠে এসে দুটি H পরমাণুতে ভেঙে পাশাপাশি দুটি কেন্দ্রে অধিশোষিত হয় (বিযোজিত অধিশোষণ); ইথিন (CH₂=CH₂) π ইলেকট্রন দিয়ে দুটি কেন্দ্রে বসে। পাশাপাশি থাকা H একটি একটি করে কার্বনে যুক্ত হয় (প্রথমে C₂H₅ মধ্যবর্তী), তারপর ইথেন (C₂H₆) পৃষ্ঠ ছেড়ে চলে যায় (বিশোষণ) — কেন্দ্র আবার খালি। "প্রভাবক বিষ" বাড়ালে হলুদ S পরমাণু স্থায়ীভাবে কেন্দ্র দখল করে — টার্নওভার (প্রতি সেকেন্ডে উৎপন্ন ইথেন) কমে যায়।',
  html: () => `${X.cv('Ni পৃষ্ঠে অধিশোষণ ও হাইড্রোজেনেশনের সিমুলেশন')}<div class="grid2" style="margin-top:8px"><label class="small">প্রভাবক বিষ (S পরমাণু): <b data-pv></b><input type="range" min="0" max="24" step="2" value="0" data-p></label><label class="small">গতি<input type="range" min="0.5" max="2.5" step="0.25" value="1" data-sp></label></div><div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), sP = el.querySelector('[data-p]'), sS = el.querySelector('[data-sp]');
    let L = X.fit(c, w => Math.min(330, w * 0.8)), poison = 0, speed = 1, clock = 0, made = [], ev = [];
    const NI = 9, NJ = 5, R = X.rng(12);
    let site, ents, gas, log = [];
    const geom = () => { const W = L.W, H = L.H, dx = (W - 40) / (NI + NJ * 0.5), dy = dx * 0.48; return { x0: 20 + dx * 0.4, y0: H - 30 - (NJ - 1) * dy, dx, dy }; };
    const scr = (i, j, z = 0) => { const G = geom(); return [G.x0 + i * G.dx + j * G.dx * 0.5, G.y0 + j * G.dy - z]; };
    const reset = () => {
      site = Array.from({ length: NI * NJ }, () => null); ents = []; gas = []; made = []; ev = []; log = []; clock = 0;
      const free = [...site.keys()]; for (let k = 0; k < poison; k++) { const idx = free.splice(Math.floor(R() * free.length), 1)[0]; site[idx] = { t: 'S' }; }
    };
    const nb = idx => { const i = idx % NI, j = Math.floor(idx / NI), o = []; if (i > 0) o.push(idx - 1); if (i < NI - 1) o.push(idx + 1); if (j > 0) o.push(idx - NI); if (j < NJ - 1) o.push(idx + NI); return o; };
    const freePair = () => { const cand = []; site.forEach((s, idx) => { if (s) return; nb(idx).forEach(n => { if (!site[n] && n > idx) cand.push([idx, n]); }); }); return cand.length ? cand[Math.floor(R() * cand.length)] : null; };
    const note = s => { log.unshift(s); log = log.slice(0, 2); };
    const step = dt => {
      clock += dt;
      // spawn gas molecules
      if (gas.length < 3 && R() < dt * 1.6) { const pair = freePair(); if (pair) { const kind = R() < 0.55 ? 'H2' : 'E'; pair.forEach(p => { site[p] = { t: 'res' }; }); const [x1, y1] = scr(pair[0] % NI, Math.floor(pair[0] / NI)), [x2, y2] = scr(pair[1] % NI, Math.floor(pair[1] / NI)); gas.push({ kind, pair, x: (x1 + x2) / 2 + (R() - 0.5) * 60, z: 140, tx: (x1 + x2) / 2, ty: (y1 + y2) / 2, u: 0 }); } }
      gas.forEach(gm => { gm.u += dt * 0.9; });
      gas.filter(gm => gm.u >= 1).forEach(gm => {
        if (gm.kind === 'H2') { gm.pair.forEach(p => { site[p] = { t: 'H', age: 0 }; }); note('H₂ বিযোজিত হয়ে দুটি H অধিশোষিত'); }
        else { const e = { t: 'E', pair: gm.pair, stage: 0, age: 0 }; gm.pair.forEach(p => { site[p] = e; }); ents.push(e); note('ইথিন π বন্ধনে অধিশোষিত'); }
      });
      gas = gas.filter(gm => gm.u < 1);
      // reactions: adsorbed ethene grabs neighbouring H
      ents.forEach(e => {
        e.age += dt; if (e.age < 0.8) return;
        const hs = []; e.pair.forEach(p => nb(p).forEach(n => { if (site[n] && site[n].t === 'H' && !e.pair.includes(n)) hs.push(n); }));
        if (hs.length && R() < dt * 1.5) { site[hs[0]] = null; e.stage++; e.age = 0.3; ev.push(clock); note(e.stage === 1 ? 'একটি H যুক্ত — C₂H₅ মধ্যবর্তী' : 'দ্বিতীয় H যুক্ত — ইথেন তৈরি'); if (e.stage >= 2) { e.pair.forEach(p => { site[p] = null; }); const [x1, y1] = scr(e.pair[0] % NI, Math.floor(e.pair[0] / NI)), [x2, y2] = scr(e.pair[1] % NI, Math.floor(e.pair[1] / NI)); made.push({ x: (x1 + x2) / 2, y: (y1 + y2) / 2, z: 0, op: 1 }); e.done = true; note('ইথেন বিশোষিত — কেন্দ্র খালি'); } }
      });
      ents = ents.filter(e => !e.done);
      made.forEach(m => { m.z += dt * 70; m.op -= dt * 0.45; }); made = made.filter(m => m.op > 0);
      ev = ev.filter(t0 => clock - t0 < 6);
    };
    const drawEthene = (g, x, y, k, stage, a) => { const ca = Math.cos(a), sa = Math.sin(a), d = 8 * k; const C1 = [x - ca * d, y - sa * d * 0.5], C2 = [x + ca * d, y + sa * d * 0.5];
      g.strokeStyle = '#333'; g.lineWidth = 3 * k; g.beginPath(); g.moveTo(C1[0], C1[1]); g.lineTo(C2[0], C2[1]); g.stroke(); if (stage === 0) { g.lineWidth = 1.5 * k; g.beginPath(); g.moveTo(C1[0], C1[1] - 4 * k); g.lineTo(C2[0], C2[1] - 4 * k); g.stroke(); }
      const nH = [2, 2]; if (stage >= 1) nH[0] = 3; if (stage >= 2) nH[1] = 3;
      [C1, C2].forEach((C, q) => { for (let h = 0; h < nH[q]; h++) { const ang = (q ? 0 : Math.PI) + (h - (nH[q] - 1) / 2) * 1.0 - Math.PI / 2 * 0.3; ball(g, C[0] + Math.cos(ang) * 9 * k, C[1] - 6 * k + Math.sin(ang) * 6 * k, 3.4 * k, '#cfd3d8', '#fff'); } });
      ball(g, C1[0], C1[1], 5.2 * k, '#2a2a2a', '#8a8a8a'); ball(g, C2[0], C2[1], 5.2 * k, '#2a2a2a', '#8a8a8a'); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const G = geom();
      // slab
      const p00 = scr(-0.6, -0.6), p10 = scr(NI - 0.4, -0.6), p11 = scr(NI - 0.4, NJ - 0.4), p01 = scr(-0.6, NJ - 0.4);
      g.fillStyle = col.s3; g.beginPath(); g.moveTo(p00[0], p00[1]); g.lineTo(p10[0], p10[1]); g.lineTo(p11[0], p11[1]); g.lineTo(p01[0], p01[1]); g.closePath(); g.fill();
      g.fillStyle = 'rgba(120,130,140,.35)'; g.beginPath(); g.moveTo(p01[0], p01[1]); g.lineTo(p11[0], p11[1]); g.lineTo(p11[0], p11[1] + 14); g.lineTo(p01[0], p01[1] + 14); g.closePath(); g.fill();
      for (let j = 0; j < NJ; j++) for (let i = 0; i < NI; i++) {
        const idx = j * NI + i, [x, y] = scr(i, j), s = site[idx];
        ball(g, x, y, G.dx * 0.42, '#7d8794', '#e6ebf0');
        if (s && s.t === 'S') ball(g, x, y - G.dx * 0.25, G.dx * 0.32, '#b8920f', '#ffe27a');
        if (s && s.t === 'H') ball(g, x, y - G.dx * 0.3, G.dx * 0.22, '#c4c8ce', '#fff');
      }
      ents.forEach(e => { const [x1, y1] = scr(e.pair[0] % NI, Math.floor(e.pair[0] / NI)), [x2, y2] = scr(e.pair[1] % NI, Math.floor(e.pair[1] / NI)); drawEthene(g, (x1 + x2) / 2, (y1 + y2) / 2 - G.dx * 0.45, G.dx / 30, e.stage, Math.atan2(y2 - y1, x2 - x1)); });
      gas.forEach(gm => { const u = ease(gm.u), x = lerp(gm.x, gm.tx, u), y = gm.ty - lerp(gm.z, G.dx * 0.5, u); if (gm.kind === 'H2') { const sp = 4 + u * 6; ball(g, x - sp, y, G.dx * 0.22, '#c4c8ce', '#fff'); ball(g, x + sp, y, G.dx * 0.22, '#c4c8ce', '#fff'); } else drawEthene(g, x, y, G.dx / 30, 0, 0.3); });
      made.forEach(m => { g.globalAlpha = Math.max(0, m.op); drawEthene(g, m.x, m.y - G.dx * 0.5 - m.z, G.dx / 30, 2, 0.2); g.globalAlpha = 1; g.fillStyle = '#2e9d4e'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.globalAlpha = Math.max(0, m.op); g.fillText('C₂H₆ ↑', m.x, m.y - G.dx * 1.4 - m.z); g.globalAlpha = 1; });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText('Ni পৃষ্ঠ (সক্রিয় কেন্দ্র)', 10, 16);
      g.font = `10.5px ${col.font}`; g.fillStyle = col.mu; log.forEach((s, i) => g.fillText('• ' + s, 10, 32 + i * 14));
    };
    const info = () => {
      el.querySelector('[data-pv]').textContent = bn(poison);
      const tof = ev.length / Math.min(6, Math.max(1, clock)) / 2, freeN = site.filter(s => !s).length, poisoned = site.filter(s => s && s.t === 'S').length;
      out.innerHTML = TXB('\\ce{CH2=CH2(g) + H2(g) ->[Ni] CH3-CH3(g)}') + `<div>উৎপাদনের হার ≈ <b style="color:#2e9d4e">${bn(tof.toFixed(2))}</b> ইথেন/s · খালি কেন্দ্র ${bn(freeN)} · বিষাক্ত কেন্দ্র ${bn(poisoned)}/${bn(NI * NJ)}</div><div class="small">${poison ? 'S পরমাণু Ni পৃষ্ঠে বিক্রিয়কের চেয়ে অনেক শক্তভাবে বসে কেন্দ্র স্থায়ীভাবে দখল করেছে — H ও ইথিনের পাশাপাশি বসার সুযোগ কমে, হার কমে।' : 'ধাপ: ব্যাপন → অধিশোষণ (H–H ভাঙে, π বন্ধনে ইথিন) → পৃষ্ঠে বিক্রিয়া → বিশোষণ → ব্যাপন।'}</div>`;
    };
    let ti = 0;
    const A = X.anim(el, dt => { if (dt) step(dt * speed); draw(); ti += dt; if (ti > 0.5) { ti = 0; info(); } }, { paused: false });
    X.pp(el, A);
    sP.oninput = () => { poison = +sP.value; reset(); info(); };
    sS.oninput = () => { speed = +sS.value; };
    el.querySelector('[data-rs]').onclick = () => { reset(); info(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(330, w * 0.8)); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৪.২ প্রভাবিত বনাম অপ্রভাবিত পথ ======================= */
V.c4_catalystProfile = {
  t: 'প্রভাবিত বনাম অপ্রভাবিত বিক্রিয়ার পথ: সক্রিয়ণ শক্তি ও হার বৃদ্ধি', k: ['2d', 'int', 'calc', 'anim'],
  cap: '"সমসত্ত্ব" মোডে প্রভাবিত পথে মধ্যবর্তী যৌগের খাদসহ দুটি ছোট শীর্ষ; "অসমসত্ত্ব" মোডে অধিশোষণের খাদ ও পৃষ্ঠ-বিক্রিয়ার একটি নিচু শীর্ষ। স্লাইডারে প্রভাবক কতটা Ea কমায় ও তাপমাত্রা বদলাও — নিচে ম্যাক্সওয়েল-বোল্টজম্যান চিত্রে Ea ও Ea′ রেখার ডানের অংশ এবং হার বৃদ্ধির গুণক সাথে সাথে হিসাব হয়। লক্ষ্য করো ΔH (সবুজ তীর) কখনো বদলায় না।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['homo', 'সমসত্ত্ব (মধ্যবর্তী যৌগ)'], ['het', 'অসমসত্ত্ব (অধিশোষণ)']], 'homo')}</div><div data-svg></div><div class="grid2"><label class="small">প্রভাবক Ea কমায়: <b data-dv></b> kJ mol⁻¹<input type="range" min="5" max="60" step="1" value="30" data-d></label><label class="small">তাপমাত্রা <b data-tv></b> K<input type="range" min="250" max="600" step="5" value="298" data-t></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sD = el.querySelector('[data-d]'), sT = el.querySelector('[data-t]');
    let mode = 'homo', dE = 30, T = 298, ph = 0;
    const Ea = 100, dH = -40;
    const s = u => u <= 0 ? 0 : u >= 1 ? 1 : (1 - Math.cos(Math.PI * u)) / 2;
    const cat = x => {
      const Eap = Ea - dE;
      if (mode === 'homo') { const Ei = Math.max(dH + 10, Eap * 0.4); // intermediate level (above reactants for this example)
        if (x < 0.12) return 0; if (x < 0.32) return Eap * s((x - 0.12) / 0.2); if (x < 0.5) return Ei + (Eap - Ei) * s((0.5 - x) / 0.18); if (x < 0.68) return Ei + (Eap * 0.85 - Ei) * s((x - 0.5) / 0.18); if (x < 0.88) return dH + (Eap * 0.85 - dH) * s((0.88 - x) / 0.2); return dH; }
      const Ead = -18; // adsorbed well
      if (x < 0.1) return 0; if (x < 0.24) return Ead * s((x - 0.1) / 0.14); if (x < 0.5) return Ead + (Eap - Ead) * s((x - 0.24) / 0.26); if (x < 0.76) return dH - 18 + (Eap - dH + 18) * s((0.76 - x) / 0.26); if (x < 0.9) return dH - 18 * s((0.9 - x) / 0.14); return dH;
    };
    const draw = () => {
      const W = 400, H = 352, x0 = 46, x1 = 390, y0 = 18, y1 = 200;
      const emin = dH - 35, emax = Ea + 25, Xp = x => x0 + x * (x1 - x0), Yp = e => y1 - (e - emin) / (emax - emin) * (y1 - y0);
      let sv = `<defs>${X.arrow('c4cpA')}${X.arrowC('c4cpG', '#2e9d4e')}</defs>`;
      sv += `<line x1="${x0}" y1="${y1}" x2="${x1 + 4}" y2="${y1}" class="s-fg" stroke-width="1.2" marker-end="url(#c4cpA)"/><line x1="${x0}" y1="${y1}" x2="${x0}" y2="${y0 - 6}" class="s-fg" stroke-width="1.2" marker-end="url(#c4cpA)"/><text x="${(x0 + x1) / 2}" y="${y1 + 15}" text-anchor="middle" class="tm" style="font-size:10.5px">বিক্রিয়ার পথ →</text><text transform="translate(14 ${(y0 + y1) / 2}) rotate(-90)" text-anchor="middle" class="tm" style="font-size:10.5px">শক্তি</text>`;
      let d = '', dc = ''; for (let i = 0; i <= 160; i++) { const x = i / 160; d += (i ? 'L' : 'M') + f1(Xp(x)) + ' ' + f1(Yp(C4.prof(x, Ea, dH))); dc += (i ? 'L' : 'M') + f1(Xp(x)) + ' ' + f1(Yp(cat(x))); }
      sv += `<path d="${d}" fill="none" class="s-fg" stroke-width="2.8"/><path d="${dc}" fill="none" stroke="#2e9d4e" stroke-width="2.8" stroke-dasharray="8 5"/>`;
      // moving dots
      const xa = (ph % 1), xb = ((ph + 0.5) % 1);
      sv += `<circle cx="${f1(Xp(xa))}" cy="${f1(Yp(C4.prof(xa, Ea, dH)) - 6)}" r="5" fill="#8a8f96"/><circle cx="${f1(Xp(xb))}" cy="${f1(Yp(cat(xb)) - 6)}" r="5" fill="#2e9d4e"/>`;
      // labels
      sv += `<text x="${f1(Xp(0.5))}" y="${f1(Yp(Ea) - 6)}" text-anchor="middle" class="tb" style="font-size:11px;font-weight:700">অপ্রভাবিত (Ea = ${bn(Ea)})</text>`;
      sv += `<text x="${f1(Xp(mode === 'homo' ? 0.32 : 0.5))}" y="${f1(Yp(Ea - dE) - 6)}" text-anchor="middle" style="font-size:10.5px;fill:#2e9d4e;font-weight:700">প্রভাবিত (Ea′ = ${bn(Ea - dE)})</text>`;
      if (mode === 'homo') sv += `<text x="${f1(Xp(0.5))}" y="${f1(Yp(cat(0.5)) + 14)}" text-anchor="middle" style="font-size:9.5px;fill:#2e9d4e">মধ্যবর্তী যৌগ</text>`;
      else sv += `<text x="${f1(Xp(0.2))}" y="${f1(Yp(-18) + 14)}" text-anchor="middle" style="font-size:9.5px;fill:#2e9d4e">অধিশোষিত</text><text x="${f1(Xp(0.82))}" y="${f1(Yp(dH - 18) + 14)}" text-anchor="middle" style="font-size:9.5px;fill:#2e9d4e">অধিশোষিত উৎপাদ</text>`;
      sv += `<line x1="${f1(Xp(0.97))}" y1="${f1(Yp(0))}" x2="${f1(Xp(0.97))}" y2="${f1(Yp(dH) - 2)}" stroke="#2e9d4e" stroke-width="2" marker-end="url(#c4cpG)"/><line x1="${f1(Xp(0))}" y1="${f1(Yp(0))}" x2="${f1(Xp(0.99))}" y2="${f1(Yp(0))}" class="s-mu" stroke-dasharray="3 3"/><text x="${f1(Xp(0.95))}" y="${f1((Yp(0) + Yp(dH)) / 2 + 4)}" text-anchor="end" style="font-size:10.5px;fill:#2e9d4e;font-weight:700">ΔH (অপরিবর্তিত)</text>`;
      // log-scale Boltzmann fraction panel: f(E) ≈ e^(−E/RT)
      const mx0 = 58, my0 = 232, mw = 330, mh = 96, Emax = 120, RT = 8.314e-3 * T;
      const lf = E => -E / RT / Math.LN10; // log10 f
      const lmin = Math.floor(lf(Emax)) - 1;
      const Xm = E => mx0 + E / Emax * mw, Ym = l => my0 + (l / lmin) * mh;
      sv += `<line x1="${mx0}" y1="${my0 + mh}" x2="${mx0 + mw + 4}" y2="${my0 + mh}" class="s-fg" stroke-width="1.2" marker-end="url(#c4cpA)"/><line x1="${mx0}" y1="${my0 + mh}" x2="${mx0}" y2="${my0 - 4}" class="s-fg" stroke-width="1.2" marker-end="url(#c4cpA)"/>`;
      for (let l = 0; l >= lmin; l -= Math.max(2, Math.round(-lmin / 5))) sv += `<line x1="${mx0 - 3}" y1="${f1(Ym(l))}" x2="${mx0 + mw}" y2="${f1(Ym(l))}" class="s-ln" opacity=".5"/><text x="${mx0 - 5}" y="${f1(Ym(l) + 3.5)}" text-anchor="end" class="tm" style="font-size:9.5px">10${X.sup(l)}</text>`;
      let cur = ''; for (let i = 0; i <= 60; i++) { const E = i / 60 * Emax; cur += (i ? 'L' : 'M') + f1(Xm(E)) + ' ' + f1(Ym(lf(E))); }
      sv += `<path d="${cur}" fill="none" stroke="#2d6fd6" stroke-width="2.4"/>`;
      const pA = [Xm(Ea), Ym(lf(Ea))], pC = [Xm(Ea - dE), Ym(lf(Ea - dE))];
      sv += `<circle cx="${f1(pA[0])}" cy="${f1(pA[1])}" r="4.5" class="f-fg"/><circle cx="${f1(pC[0])}" cy="${f1(pC[1])}" r="4.5" fill="#2e9d4e"/><text x="${f1(pA[0] + 6)}" y="${f1(pA[1] + 4)}" class="tb" style="font-size:10px;font-weight:700">Ea</text><text x="${f1(pC[0] - 6)}" y="${f1(pC[1] - 4)}" text-anchor="end" style="font-size:10px;font-weight:700;fill:#2e9d4e">Ea′</text>`;
      sv += `<line x1="${f1(pA[0])}" y1="${f1(pA[1])}" x2="${f1(pA[0])}" y2="${f1(pC[1])}" stroke="#2e9d4e" stroke-width="1.6" stroke-dasharray="3 3"/><line x1="${f1(pC[0])}" y1="${f1(pC[1])}" x2="${f1(pA[0])}" y2="${f1(pC[1])}" stroke="#2e9d4e" stroke-width="1.6" stroke-dasharray="3 3"/><text x="${f1(pA[0] + 5)}" y="${f1((pA[1] + pC[1]) / 2 + 3)}" style="font-size:10px;fill:#2e9d4e;font-weight:700">×10${X.sup((dE * 1000 / (2.303 * 8.314 * T)).toFixed(1))}</text>`;
      sv += `<text x="${mx0 + mw / 2}" y="${my0 + mh + 15}" text-anchor="middle" class="tm" style="font-size:10px">শক্তি E (kJ mol⁻¹) — E এর বেশি শক্তির অণুর ভগ্নাংশ ≈ e<tspan baseline-shift="super" style="font-size:7px">−E/RT</tspan> (লগ স্কেল)</text>`;
      box.innerHTML = X.svg(W, H, sv, 'প্রভাবিত ও অপ্রভাবিত পথের শক্তি চিত্র');
    };
    const info = () => {
      el.querySelector('[data-dv]').textContent = bn(dE); el.querySelector('[data-tv]').textContent = bn(T);
      const lg = dE * 1000 / (2.303 * 8.314 * T), ratio = Math.pow(10, lg);
      out.innerHTML = TXB(`\\log\\dfrac{k'}{k} = \\dfrac{E_a - E_a'}{2.303RT} = \\dfrac{${dE * 1000}}{2.303\\times8.314\\times${T}} = ${lg.toFixed(2)}`) + TXB(`\\dfrac{k'}{k} = 10^{${lg.toFixed(2)}} \\approx ${sci(ratio, 2)}`) + `<div class="small">একই বৃদ্ধি তাপমাত্রা দিয়ে পেতে হলে অনেক বেশি তাপ লাগত; প্রভাবক কক্ষ তাপমাত্রাতেই তা দেয়। উচ্চ তাপমাত্রায় একই ΔEa এর প্রভাব তুলনামূলক কম।</div>`;
    };
    const A = X.anim(el, dt => { if (dt) ph = (ph + dt * 0.18) % 1; draw(); }, { paused: false });
    sD.oninput = () => { dE = +sD.value; info(); A.draw(); }; sT.oninput = () => { T = +sT.value; info(); A.draw(); };
    X.onSeg(el, 'm', v => { mode = v; A.draw(); });
    info(); draw();
    return () => A.stop();
  }
};

/* ======================= ৪.৪.৩ এনজাইম: তালা-চাবি, আবিষ্ট-খাপ ও কার্যকারিতার লেখচিত্র ======================= */
V.c4_enzyme = {
  t: 'এনজাইম: তালা-চাবি ও আবিষ্ট-খাপ মডেল এবং তাপমাত্রা, pH ও [S] এর প্রভাব', k: ['anim', 'int', '2d'],
  cap: 'উপরের অ্যানিমেশনে বেগুনি এনজাইম ও তার সক্রিয় স্থান (খাঁজ)। সঠিক আকৃতির সাবস্ট্রেট (সবুজ) খাঁজে বসে ES জটিল তৈরি করে, ভেঙে দুটি উৎপাদ হয়ে বেরিয়ে যায় — এনজাইম অপরিবর্তিত; ভুল আকৃতির অণু (কমলা) বসতে পারে না। "আবিষ্ট-খাপ" এ খাঁজ সাবস্ট্রেটকে ঘিরে আকৃতি বদলায়। তাপমাত্রা স্লাইডার ৪৫ °C এর বেশি করলে এনজাইম বিকৃত হতে শুরু করে — খাঁজ বেঁকে যায়, কাজ কমে। নিচে বেছে নাও: হার-তাপমাত্রা (ঘণ্টাকৃতি), হার-pH (পেপসিন, অ্যামাইলেজ, ট্রিপসিন) অথবা হার-[S] (মিকায়েলিস-মেন্টেন সম্পৃক্ততা)।',
  html: () => `<div class="ctl" style="margin:0 0 4px">${X.seg('md', [['lock', 'তালা-চাবি'], ['fit', 'আবিষ্ট-খাপ']], 'lock')}</div>${X.cv('এনজাইম-সাবস্ট্রেট অ্যানিমেশন ও কার্যকারিতার লেখচিত্র')}<div class="ctl" style="margin:6px 0 2px">${X.seg('gr', [['T', 'হার বনাম তাপমাত্রা'], ['pH', 'হার বনাম pH'], ['S', 'হার বনাম [S]']], 'T')}</div><div class="grid2"><label class="small">তাপমাত্রা <b data-tv></b> °C<input type="range" min="0" max="80" step="1" value="37" data-t></label><label class="small">pH <b data-hv></b><input type="range" min="1" max="12" step="0.1" value="6.8" data-h></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), sT = el.querySelector('[data-t]'), sH = el.querySelector('[data-h]');
    let L = X.fit(c, w => Math.min(420, w * 1.0)), md = 'lock', gr = 'T', T = 37, pH = 6.8, cyc = 0, prods = 0, clock = 0, wrongX = 0;
    const actT = t => Math.pow(2, (t - 37) / 10) / (1 + Math.exp((t - 42.5) / 2.4));
    const actpH = (p, opt = 6.8, wdt = 1.3) => Math.exp(-Math.pow((p - opt) / wdt, 2));
    const act = () => actT(T) * actpH(pH) / actT(37);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const top = H * 0.5, ecx = W / 2, ecy = top * 0.62, er = Math.min(W * 0.2, top * 0.38);
      const den = Math.max(0, Math.min(1, (T - 45) / 20));
      // phase of catalytic cycle
      const a = act(), ph = cyc % 1;
      const fitClose = md === 'fit' ? Math.max(0, Math.min(1, ph < 0.35 ? (ph - 0.25) / 0.1 : ph < 0.6 ? 1 : 1 - (ph - 0.6) / 0.1)) : 0;
      // enzyme blob with notch at top
      g.save(); g.translate(ecx, ecy);
      g.fillStyle = '#8e6cc4'; g.strokeStyle = '#4e3486'; g.lineWidth = 2;
      g.beginPath();
      const notchW = er * 0.55, notchD = er * 0.42;
      for (let i = 0; i <= 120; i++) {
        const th = -Math.PI / 2 + i / 120 * Math.PI * 2; let r = er * (1 + 0.06 * Math.sin(th * 3 + 0.5) + den * 0.18 * Math.sin(th * 5 + clock * 2));
        let x = Math.cos(th) * r, y = Math.sin(th) * r;
        const dx = Math.abs(x); if (y < -er * 0.5 && dx < notchW / 2 + 6) { const k = Math.max(0, 1 - Math.pow(dx / (notchW / 2 + 6), 4)); const close = fitClose * (dx / (notchW / 2)) * 6; y += k * notchD * (1 - den * 0.8) - close * (1 - k); }
        i ? g.lineTo(x, y) : g.moveTo(x, y);
      }
      g.closePath(); g.fill(); g.stroke();
      g.fillStyle = 'rgba(255,255,255,.18)'; g.beginPath(); g.ellipse(-er * 0.3, er * 0.1, er * 0.35, er * 0.22, -0.4, 0, 7); g.fill();
      g.fillStyle = '#fff'; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(den > 0.4 ? 'এনজাইম (বিকৃত)' : 'এনজাইম', 0, er * 0.45);
      g.fillStyle = 'rgba(255,255,255,.8)'; g.font = `10px ${col.font}`; g.fillText('সক্রিয় স্থান', 0, -er * 0.12);
      g.restore();
      // substrate path: approach -> bind -> split -> leave
      const sx0 = ecx - W * 0.42, sy0 = 18, sbx = ecx, sby = ecy - er + er * 0.42 * (1 - den * 0.8) - 10;
      const sw = notchW * 0.92, sh = 22;
      const drawSub = (x, y, split, op) => { g.globalAlpha = op; g.fillStyle = '#3fae5a'; g.strokeStyle = '#1f6e34'; g.lineWidth = 1.5;
        const halves = [[-sw / 2, 0], [0, 0]]; halves.forEach(([ox], k) => { const sep = split * (k ? 1 : -1) * 18; g.beginPath(); g.roundRect(x + ox + sep + (k ? 1 : -1), y - sh / 2 + Math.abs(sep) * 0.6 * (k ? 1 : 1) * 0, sw / 2 - 2, sh, 5); g.fill(); g.stroke(); });
        if (split < 0.1) { g.strokeStyle = '#1f6e34'; g.setLineDash([2, 2]); g.beginPath(); g.moveTo(x, y - sh / 2); g.lineTo(x, y + sh / 2); g.stroke(); g.setLineDash([]); }
        g.globalAlpha = 1; };
      if (a > 0.03 || den < 0.9) {
        let x, y, split = 0, op = 1;
        if (ph < 0.3) { const u = ease(ph / 0.3); x = lerp(sx0, sbx, u); y = lerp(sy0, sby - (den > 0.6 ? 18 : 0), u); }
        else if (ph < 0.6) { x = sbx; y = sby; split = ph > 0.5 ? (ph - 0.5) / 0.1 : 0; }
        else { const u = ease((ph - 0.6) / 0.4); x = sbx; y = sby - u * 60; split = 1 + u * 2.5; op = 1 - u; }
        if (den > 0.6 && ph >= 0.3) { x = sbx + (ph - 0.3) * 160; y = sby - 30 - (ph - 0.3) * 40; split = 0; op = Math.max(0, 1 - (ph - 0.3) * 2); }
        drawSub(x, y, Math.min(3.5, split), op);
        g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center';
        const lab = den > 0.6 && ph >= 0.3 ? 'বসতে পারছে না!' : ph < 0.3 ? 'সাবস্ট্রেট (S)' : ph < 0.5 ? 'ES জটিল' : ph < 0.6 ? 'বন্ধন ভাঙছে' : 'উৎপাদ (P) মুক্ত';
        g.globalAlpha = Math.max(0.2, op); g.fillText(lab, x, y - sh / 2 - 6); g.globalAlpha = 1;
      }
      // wrong-shape molecule bouncing
      const wx = ecx + W * 0.36 - Math.abs(Math.sin(wrongX)) * W * 0.12, wy = ecy - er * 0.9;
      g.fillStyle = '#e8902e'; g.strokeStyle = '#a4581a'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(wx, wy - 14); g.lineTo(wx + 14, wy + 10); g.lineTo(wx - 14, wy + 10); g.closePath(); g.fill(); g.stroke();
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('ভুল আকৃতি', wx, wy + 24);
      g.fillStyle = col.fg; g.font = `10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`উৎপাদ: ${bn(prods)}`, 10, top - 8);
      g.strokeStyle = col.line || col.mu; g.beginPath(); g.moveTo(8, top); g.lineTo(W - 8, top); g.stroke();
      // graph
      const gx = 44, gy = top + 18, gw = W - gx - 14, gh = H - gy - 32;
      if (gr === 'T') {
        const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax: 80, ymax: 1.45, col, xt: [0, 20, 40, 60, 80], yt: [], xl: 'তাপমাত্রা (°C)', yl: 'আপেক্ষিক হার', ylx: 20 });
        const pts = []; for (let i = 0; i <= 160; i++) { const t = i / 2; pts.push([P.X(t), P.Y(actT(t) / actT(37))]); } path(g, pts, '#8e6cc4', 2.8);
        const pa = []; for (let i = 0; i <= 80; i++) { const t = i; pa.push([P.X(t), P.Y(Math.min(1.45, Math.pow(2, (t - 37) / 10) * 0.45))]); } path(g, pa, 'rgba(140,140,140,.7)', 1.6, [5, 4]);
        g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.textAlign = 'right'; g.fillText('অজৈব প্রভাবক (আরহেনিয়াস) →', P.X(78), P.Y(1.38));
        let tb = 0, vb = 0; for (let t = 20; t < 60; t += 0.5) { const v = actT(t); if (v > vb) { vb = v; tb = t; } } g.fillStyle = '#8e6cc4'; g.textAlign = 'right'; g.fillText(`সর্বোত্তম ~${bn(Math.round(tb))} °C`, P.X(tb) - 6, P.Y(vb / actT(37)) - 4);
        g.fillStyle = '#e0402e'; g.beginPath(); g.arc(P.X(T), P.Y(actT(T) / actT(37)), 5.5, 0, 7); g.fill();
      } else if (gr === 'pH') {
        const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: 0, xmax: 12, ymax: 1.15, col, xt: [0, 2, 4, 6, 8, 10, 12], yt: [], xl: 'pH', yl: 'আপেক্ষিক হার', ylx: 20 });
        [['পেপসিন', 2, 1.0, '#e0402e'], ['অ্যামাইলেজ', 6.8, 1.3, '#8e6cc4'], ['ট্রিপসিন', 8, 1.1, '#2d6fd6']].forEach(([nm, o, w, cc]) => { const pts = []; for (let i = 0; i <= 120; i++) { const p = i / 10; pts.push([P.X(p), P.Y(actpH(p, o, w))]); } path(g, pts, cc, 2.4); g.fillStyle = cc; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, P.X(o), P.Y(1) - 6); });
        g.fillStyle = '#e0402e'; g.beginPath(); g.arc(P.X(pH), P.Y(actpH(pH)), 5, 0, 7); g.fill();
      } else {
        const Vm = 1, KM = 2, P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax: 20, ymax: 1.15, col, xt: [0, 5, 10, 15, 20], yt: [], xl: '[S] (mmol L⁻¹)', yl: 'হার v', ylx: 20 });
        const pts = []; for (let i = 0; i <= 100; i++) { const S = i / 5; pts.push([P.X(S), P.Y(Vm * S / (KM + S))]); } path(g, pts, '#8e6cc4', 2.8);
        g.strokeStyle = col.mu; g.setLineDash([4, 4]); g.lineWidth = 1; g.beginPath(); g.moveTo(gx, P.Y(1)); g.lineTo(gx + gw, P.Y(1)); g.moveTo(gx, P.Y(0.5)); g.lineTo(P.X(KM), P.Y(0.5)); g.lineTo(P.X(KM), P.Y(0)); g.stroke(); g.setLineDash([]);
        g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('Vmax (সব এনজাইম সম্পৃক্ত — শূন্য ক্রম)', gx + 6, P.Y(1) - 5); g.fillText('Vmax/2', gx + 4, P.Y(0.5) - 4); g.textAlign = 'center'; g.fillText('K_M', P.X(KM), gy + gh + 13 - 26); g.textAlign = 'left'; g.fillText('প্রথম ক্রম অংশ', P.X(0.4), P.Y(0.22));
      }
    };
    const info = () => {
      el.querySelector('[data-tv]').textContent = bn(T); el.querySelector('[data-hv]').textContent = bn(pH.toFixed(1));
      const a = act();
      out.innerHTML = TXB('\\ce{E + S <=> ES -> E + P}') + `<div>আপেক্ষিক কার্যকারিতা ≈ <b>${bn(Math.round(a * 100))}%</b> (অ্যামাইলেজ; সর্বোত্তম ৩৭ °C, pH ৬.৮)</div><div class="small">${T > 50 ? 'উচ্চ তাপে প্রোটিনের গঠন বিকৃত — সক্রিয় স্থানের আকৃতি নষ্ট; ঠান্ডা করলেও সাধারণত ফেরে না।' : T < 15 ? 'কম তাপমাত্রায় এনজাইম নিষ্ক্রিয় কিন্তু অক্ষত — উষ্ণ করলে আবার কাজ করবে।' : Math.abs(pH - 6.8) > 2 ? 'সর্বোত্তম pH থেকে দূরে — সক্রিয় স্থানের অ্যামিনো এসিডের চার্জ বদলে সাবস্ট্রেট বাঁধতে পারে না।' : md === 'fit' ? 'আবিষ্ট-খাপ: সাবস্ট্রেট এলে খাঁজ আকৃতি বদলে আঁকড়ে ধরে — বন্ধনে টান পড়ে, Ea কমে।' : 'তালা-চাবি: খাঁজের আকৃতি সাবস্ট্রেটের সাথে হুবহু মেলে — উচ্চ নির্দিষ্টতা।'}</div>`;
    };
    let ti = 0;
    const A = X.anim(el, dt => { if (dt) { clock += dt; wrongX += dt * 2.2; const a = act(); const before = Math.floor(cyc); cyc += dt * 0.45 * Math.max(0.04, a); if (Math.floor(cyc) > before && T <= 60) prods += 2; } draw(); ti += dt; if (ti > 0.5) { ti = 0; info(); } }, { paused: false });
    sT.oninput = () => { T = +sT.value; info(); A.draw(); }; sH.oninput = () => { pH = +sH.value; info(); A.draw(); };
    X.onSeg(el, 'md', v => { md = v; info(); }); X.onSeg(el, 'gr', v => { gr = v; A.draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(420, w * 1.0)); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
