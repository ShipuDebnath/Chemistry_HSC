/* Chapter 4 visuals part 3 — reaction rate, rate law, initial rates, factors (4.3–4.3.2) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, f1 = C4.f1, INK = C4.INK, ball = C4.ball;
const TXR = (tex, d) => (window.TX && TX.render(tex, d)) || tex;
const TXB = tex => `<div class="txb">${TXR(tex)}</div>`;
C4.tx = TXR; C4.txb = TXB;
const sci = (v, d = 2) => { if (!isFinite(v)) return '∞'; if (v === 0) return '0'; const e = Math.floor(Math.log10(Math.abs(v))); if (e >= -2 && e <= 3) return (+v.toPrecision(d + 1)).toString(); const m = v / Math.pow(10, e); return m.toFixed(d) + '\\times10^{' + e + '}'; };
C4.sci = sci;
/* canvas plot helper */
C4.cplot = (g, o) => {
  const { x0, y0, w, h, xmax, ymax, col } = o, xmin = o.xmin || 0, ymin = o.ymin || 0;
  const X_ = v => x0 + (v - xmin) / (xmax - xmin) * w, Y_ = v => y0 + h - (v - ymin) / (ymax - ymin) * h;
  g.strokeStyle = col.ln || col.mu; g.lineWidth = 1; g.font = `10px ${col.font}`; g.fillStyle = col.mu;
  (o.yt || []).forEach(v => { const y = Y_(v); g.globalAlpha = .35; g.beginPath(); g.moveTo(x0, y); g.lineTo(x0 + w, y); g.stroke(); g.globalAlpha = 1; g.textAlign = 'right'; g.fillText(o.fy ? o.fy(v) : bn(v), x0 - 4, y + 3.5); });
  (o.xt || []).forEach(v => { const x = X_(v); g.textAlign = 'center'; g.fillText(o.fx ? o.fx(v) : bn(v), x, y0 + h + 13); });
  g.strokeStyle = col.fg; g.lineWidth = 1.3; g.beginPath(); g.moveTo(x0, y0 - 4); g.lineTo(x0, y0 + h); g.lineTo(x0 + w + 4, y0 + h); g.stroke();
  g.fillStyle = col.fg; g.beginPath(); g.moveTo(x0, y0 - 8); g.lineTo(x0 - 3.5, y0 - 1); g.lineTo(x0 + 3.5, y0 - 1); g.fill(); g.beginPath(); g.moveTo(x0 + w + 8, y0 + h); g.lineTo(x0 + w + 1, y0 + h - 3.5); g.lineTo(x0 + w + 1, y0 + h + 3.5); g.fill();
  g.font = `11px ${col.font}`; g.fillStyle = col.fg;
  if (o.xl) { g.textAlign = 'center'; g.fillText(o.xl, x0 + w / 2, y0 + h + 27); }
  if (o.yl) { g.save(); g.translate(x0 - (o.ylx || 34), y0 + h / 2); g.rotate(-Math.PI / 2); g.textAlign = 'center'; g.fillText(o.yl, 0, 0); g.restore(); }
  return { X: X_, Y: Y_ };
};
const path = (g, pts, color, w = 2.2, dash) => { g.strokeStyle = color; g.lineWidth = w; g.setLineDash(dash || []); g.beginPath(); pts.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y)); g.stroke(); g.setLineDash([]); };
C4.path = path;
/* small molecule glyphs on canvas */
const MOL = {
  N2O5: (g, x, y, a) => { const c = Math.cos(a), s = Math.sin(a); ball(g, x + c * 7, y + s * 7, 5, '#2d5fb3', '#9cc0ff'); ball(g, x - c * 7, y - s * 7, 5, '#2d5fb3', '#9cc0ff'); ball(g, x, y, 4.2, '#c23b2a', '#ff9a8a'); ball(g, x + c * 9 - s * 7, y + s * 9 + c * 7, 3.6, '#c23b2a', '#ff9a8a'); ball(g, x - c * 9 + s * 7, y - s * 9 - c * 7, 3.6, '#c23b2a', '#ff9a8a'); },
  NO2: (g, x, y, a) => { const c = Math.cos(a), s = Math.sin(a); ball(g, x - c * 6 + s * 3, y - s * 6 - c * 3, 3.8, '#c23b2a', '#ff9a8a'); ball(g, x + c * 6 + s * 3, y + s * 6 - c * 3, 3.8, '#c23b2a', '#ff9a8a'); ball(g, x, y, 4.6, '#8a3a12', '#e09060'); },
  O2: (g, x, y, a) => { const c = Math.cos(a), s = Math.sin(a); ball(g, x - c * 3.5, y - s * 3.5, 4, '#c23b2a', '#ff9a8a'); ball(g, x + c * 3.5, y + s * 3.5, 4, '#c23b2a', '#ff9a8a'); }
};

/* ======================= ৪.৩ ঘনমাত্রা-সময় লেখচিত্র: গড় ও তাৎক্ষণিক হার ======================= */
V.c4_rateCurve = {
  t: 'বিক্রিয়ার হার: ঘনমাত্রা-সময় লেখচিত্র, গড় ও তাৎক্ষণিক হার', k: ['anim', 'int', '2d', 'calc'],
  cap: '{ce|2N2O5(g) -> 4NO2(g) + O2(g)} (৪৫ °C, k = 6.2×10⁻⁴ s⁻¹)। উপরে পাত্রে অণুগুলোর সংখ্যা সময়ের সাথে বদলাচ্ছে; নিচে তিনটি পদার্থের ঘনমাত্রা-সময় বক্ররেখা। স্লাইডার বা লেখচিত্রে আঙুল টেনে সময় t বদলাও — নির্বাচিত পদার্থের বক্ররেখায় স্পর্শক (লাল) দেখায় তাৎক্ষণিক হার, আর t থেকে t + Δt পর্যন্ত ছেদক (সবুজ ড্যাশ) দেখায় গড় হার। Δt ছোট করলে ছেদক স্পর্শকের দিকে যায় — তাৎক্ষণিক হারের সংজ্ঞা। নিচের হিসাবে দেখো তিনটি পদার্থের হার আলাদা হলেও সহগ দিয়ে ভাগ করলে একই বিক্রিয়ার হার।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('sp', [['A', 'N₂O₅'], ['B', 'NO₂'], ['C', 'O₂']], 'A')}</div>${X.cv('পাত্রে অণু ও ঘনমাত্রা-সময় লেখচিত্র')}<div class="ctl"><button class="btn sm" data-pp></button><label style="flex:1;min-width:140px">সময় t <input type="range" min="0" max="4000" step="10" value="800" data-t></label></div><div class="ctl"><label style="flex:1">ব্যবধান Δt <input type="range" min="20" max="2000" step="10" value="800" data-dt></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), st = el.querySelector('[data-t]'), sdt = el.querySelector('[data-dt]');
    const k = 6.2e-4, A0 = 0.40, TM = 4000, N0 = 24;
    let L = X.fit(c, w => Math.min(560, w * 1.2)), sp = 'A', t = 800, dt = 800, playing = false;
    const conc = (s, tt) => { const a = A0 * Math.exp(-k * tt); return s === 'A' ? a : s === 'B' ? 2 * (A0 - a) : 0.5 * (A0 - a); };
    // first order in N2O5: -d[N2O5]/dt = k[N2O5]; so d[NO2]/dt = 2k[A], d[O2]/dt = 0.5k[A]
    const dX = (s, tt) => { const a = A0 * Math.exp(-k * tt); return s === 'A' ? -k * a : s === 'B' ? 2 * k * a : 0.5 * k * a; };
    const COL = { A: '#2d6fd6', B: '#a0521d', C: '#d23b3b' }, NM = { A: 'N₂O₅', B: 'NO₂', C: 'O₂' }, TXN = { A: '\\ce{N2O5}', B: '\\ce{NO2}', C: '\\ce{O2}' }, CO = { A: 2, B: 4, C: 1 };
    const R = X.rng(3); const parts = []; const box = () => ({ x: 12, y: 10, w: L.W - 24, h: L.H * 0.3 });
    const spawn = (kind) => { const b = box(); parts.push({ k: kind, x: b.x + 12 + R() * (b.w - 24), y: b.y + 12 + R() * (b.h - 24), vx: (R() - .5) * 60, vy: (R() - .5) * 60, a: R() * 6.3, w: (R() - .5) * 2 }); };
    const syncParts = () => {
      const a = Math.round(N0 * Math.exp(-k * t)), d = N0 - a;
      const want = { N2O5: a, NO2: 2 * d, O2: Math.round(d / 2) };
      for (const kk of ['N2O5', 'NO2', 'O2']) { let have = parts.filter(p => p.k === kk).length; while (have < want[kk]) { spawn(kk); have++; } while (have > want[kk]) { const i = parts.findIndex(p => p.k === kk); parts.splice(i, 1); have--; } }
    };
    let plotBox;
    const draw = () => {
      const { g, W, H } = L, col = X.C(), b = box();
      g.clearRect(0, 0, W, H);
      g.fillStyle = col.s2; g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.roundRect(b.x, b.y, b.w, b.h, 10); g.fill(); g.stroke();
      g.save(); g.beginPath(); g.roundRect(b.x, b.y, b.w, b.h, 10); g.clip(); parts.forEach(p => MOL[p.k](g, p.x, p.y, p.a)); g.restore();
      g.font = `10.5px ${col.font}`; g.fillStyle = col.mu; g.textAlign = 'right'; g.fillText(`t = ${bn(Math.round(t))} s`, b.x + b.w - 8, b.y + 14);
      { let lx = b.x + 14; const ly = b.y + b.h + 12; g.textAlign = 'left'; g.font = `10.5px ${col.font}`; [['N2O5', 'N₂O₅'], ['NO2', 'NO₂'], ['O2', 'O₂']].forEach(([kk2, nm]) => { MOL[kk2](g, lx + 8, ly - 2, 0); g.fillStyle = col.fg; g.fillText(nm, lx + 22, ly + 2); lx += 70; }); }
      // graph
      const gx = 52, gy = b.y + b.h + 40, gw = W - gx - 16, gh = H - gy - 34; plotBox = { gx, gw };
      const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax: TM, ymax: 0.85, col, yt: [0, 0.2, 0.4, 0.6, 0.8], xt: [0, 1000, 2000, 3000, 4000], fy: v => bn(v.toFixed(1)), xl: 'সময় (s)', yl: 'ঘনমাত্রা (mol L⁻¹)', ylx: 40 });
      ['A', 'B', 'C'].forEach(s => { const pts = []; for (let i = 0; i <= 120; i++) { const tt = i / 120 * TM; pts.push([P.X(tt), P.Y(conc(s, tt))]); } path(g, pts, COL[s], s === sp ? 3 : 1.8); g.fillStyle = COL[s]; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(NM[s], P.X(TM) - 34, P.Y(conc(s, TM)) - 6); });
      // secant
      const t2 = Math.min(TM, t + dt), y1 = conc(sp, t), y2 = conc(sp, t2);
      path(g, [[P.X(t), P.Y(y1)], [P.X(t2), P.Y(y2)]], '#2e9d4e', 2.2, [6, 4]);
      g.fillStyle = '#2e9d4e'; g.beginPath(); g.arc(P.X(t2), P.Y(y2), 4, 0, 7); g.fill();
      // tangent
      const m = dX(sp, t), span = 650; const ta = Math.max(0, t - span), tb = Math.min(TM, t + span);
      path(g, [[P.X(ta), P.Y(y1 + m * (ta - t))], [P.X(tb), P.Y(y1 + m * (tb - t))]], '#e0402e', 2.4);
      // playhead
      g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(P.X(t), gy); g.lineTo(P.X(t), gy + gh); g.stroke(); g.setLineDash([]);
      g.fillStyle = COL[sp]; g.beginPath(); g.arc(P.X(t), P.Y(y1), 5.5, 0, 7); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = 1.5; g.stroke();
      // legend
      g.font = `10px ${col.font}`; g.textAlign = 'left'; const ly = gy + 6; let lx = gx + 10;
      [['#e0402e', 'স্পর্শক (তাৎক্ষণিক)', []], ['#2e9d4e', 'ছেদক (গড়)', [6, 4]]].forEach(([cc, tx, d]) => { path(g, [[lx, ly], [lx + 18, ly]], cc, 2.2, d); g.fillStyle = col.fg; g.fillText(tx, lx + 22, ly + 3.5); lx += 22 + g.measureText(tx).width + 14; });
    };
    const info = () => {
      const t2 = Math.min(TM, t + dt), y1 = conc(sp, t), y2 = conc(sp, t2), avg = (y2 - y1) / (t2 - t), inst = dX(sp, t), sign = sp === 'A' ? -1 : 1;
      const rr = k * conc('A', t) / 2; // reaction rate r = -(1/2) d[N2O5]/dt
      out.innerHTML = TXB(`[${TXN[sp]}]_{t} = ${(+y1).toFixed(3)}\\ \\mathrm{mol\\,L^{-1}}`) +
        `<div style="margin-top:6px;color:#2e9d4e;font-weight:700">গড় হার (t থেকে t + Δt)</div>` + TXB(`${sign < 0 ? '-' : ''}\\dfrac{\\Delta[${TXN[sp]}]}{\\Delta t} = ${sign < 0 ? '-' : ''}\\dfrac{${(y2 - y1).toFixed(3)}}{${Math.round(t2 - t)}} = ${sci(Math.abs(avg))}`) +
        `<div style="margin-top:6px;color:#e0402e;font-weight:700">তাৎক্ষণিক হার (t মুহূর্তে)</div>` + TXB(`${sign < 0 ? '-' : ''}\\dfrac{d[${TXN[sp]}]}{dt} = ${sci(Math.abs(inst))}\\ \\mathrm{mol\\,L^{-1}\\,s^{-1}}`) +
        `<div style="margin-top:6px;border-top:1px solid var(--line);padding-top:6px" class="small">বিক্রিয়ার হার — সহগ দিয়ে ভাগ করলে সব পদার্থের জন্য একই:</div>` + TXB(`r = -\\tfrac{1}{2}\\tfrac{d[\\ce{N2O5}]}{dt} = \\tfrac{1}{4}\\tfrac{d[\\ce{NO2}]}{dt} = \\tfrac{d[\\ce{O2}]}{dt} = ${sci(rr)}`);
    };
    const setT = v => { t = Math.max(0, Math.min(TM, v)); st.value = Math.round(t); syncParts(); };
    const A = X.anim(el, (d) => {
      if (d) { const b = box(); parts.forEach(p => { p.x += p.vx * d; p.y += p.vy * d; p.a += p.w * d; if (p.x < b.x + 10 || p.x > b.x + b.w - 10) p.vx *= -1; if (p.y < b.y + 10 || p.y > b.y + b.h - 10) p.vy *= -1; p.x = Math.max(b.x + 10, Math.min(b.x + b.w - 10, p.x)); p.y = Math.max(b.y + 10, Math.min(b.y + b.h - 10, p.y)); }); if (playing) { setT(t + d * 400); if (t >= TM) setT(0); info(); } }
      draw();
    }, { paused: false });
    const pp = el.querySelector('[data-pp]'); const upd = () => { pp.innerHTML = playing ? X.ico('pause') + 'থামাও' : X.ico('play') + 'সময় চালাও'; }; pp.onclick = () => { playing = !playing; upd(); }; upd();
    st.oninput = () => { setT(+st.value); info(); }; sdt.oninput = () => { dt = +sdt.value; info(); };
    X.onSeg(el, 'sp', s => { sp = s; info(); });
    let drag = false; const pick = e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left; if (!plotBox) return; setT((x - plotBox.gx) / plotBox.gw * TM); info(); };
    c.addEventListener('pointerdown', e => { const r = c.getBoundingClientRect(); if (e.clientY - r.top > box().y + box().h) { drag = true; pick(e); } });
    c.addEventListener('pointermove', e => { if (drag) pick(e); }); c.addEventListener('pointerup', () => { drag = false; }); c.addEventListener('pointerleave', () => { drag = false; });
    syncParts(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(560, w * 1.2)); parts.length = 0; syncParts(); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৩.১ ক্রম অনুসন্ধানী: শূন্য, প্রথম, দ্বিতীয় ক্রম ======================= */
V.c4_rateLaw = {
  t: 'বিক্রিয়ার ক্রম অনুসন্ধানী: সমাকলিত লেখচিত্র ও অর্ধায়ু', k: ['anim', 'int', '2d', 'calc'],
  cap: 'ক্রম (০, ১, ২), হার ধ্রুবক k ও প্রারম্ভিক ঘনমাত্রা [A]₀ বেছে নাও। "লেখচিত্র" বোতামে [A], ln[A] বা 1/[A] বনাম সময় দেখো — নির্বাচিত ক্রমের জন্য কেবল একটিই সরলরেখা হয় (শূন্য: [A]; প্রথম: ln[A]; দ্বিতীয়: 1/[A]); এভাবেই পরীক্ষার ডেটা থেকে ক্রম চেনা হয়। [A] বনাম t লেখচিত্রে ধারাবাহিক অর্ধায়ুগুলো চিহ্নিত: প্রথম ক্রমে সমান ব্যবধান, শূন্য ক্রমে ক্রমশ ছোট, দ্বিতীয় ক্রমে ক্রমশ বড়। [A]₀ বদলে দেখো কোন ক্রমের অর্ধায়ু বদলায় না।',
  html: () => `<div class="ctl" style="margin:0 0 4px">${X.seg('n', [['0', 'শূন্য ক্রম'], ['1', 'প্রথম ক্রম'], ['2', 'দ্বিতীয় ক্রম']], '1')}</div><div class="ctl" style="margin:0 0 6px">${X.seg('pl', [['c', '[A] বনাম t'], ['ln', 'ln[A] বনাম t'], ['inv', '1/[A] বনাম t']], 'c')}</div>${X.cv('ক্রম অনুযায়ী ঘনমাত্রা-সময় লেখচিত্র')}<div class="grid2" style="margin-top:8px"><label class="small">হার ধ্রুবক k <input type="range" min="0.2" max="2" step="0.05" value="1" data-k></label><label class="small">প্রারম্ভিক [A]₀ (mol L⁻¹) <input type="range" min="0.4" max="2" step="0.1" value="1" data-a></label></div><div class="ctl"><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), sk = el.querySelector('[data-k]'), sa = el.querySelector('[data-a]');
    let L = X.fit(c, w => Math.min(380, w * 0.82)), n = 1, pl = 'c', kk = 1, A0 = 1, tp = 0, playing = true;
    // time unit: "min"; k scaled so curves fit: zero order k0 = kk*0.1 mol/L/min, first k1 = kk*0.1 /min, second k2 = kk*0.1 L/mol/min
    const kv = () => kk * 0.1;
    const conc = t => { const k = kv(); if (n === 0) return Math.max(0, A0 - k * t); if (n === 1) return A0 * Math.exp(-k * t); return A0 / (1 + k * A0 * t); };
    const thalf = a => { const k = kv(); return n === 0 ? a / (2 * k) : n === 1 ? 0.693 / k : 1 / (k * a); };
    const TM = 40;
    const draw = () => {
      const { g, W, H } = L, col = X.C();
      g.clearRect(0, 0, W, H);
      const gx = 54, gy = 18, gw = W - gx - 18, gh = H - gy - 46;
      const fy = pl === 'c' ? conc : pl === 'ln' ? (t => { const v = conc(t); return v > 1e-4 ? Math.log(v) : NaN; }) : (t => { const v = conc(t); return v > 1e-4 ? 1 / v : NaN; });
      let ymin, ymax;
      if (pl === 'c') { ymin = 0; ymax = 2.1; } else if (pl === 'ln') { ymin = -4; ymax = 1; } else { ymin = 0; ymax = Math.max(4, ...Array.from({ length: 41 }, (_, i) => fy(i)).filter(isFinite)) * 1.05; ymax = Math.min(ymax, 40); }
      const yt = pl === 'c' ? [0, 0.5, 1, 1.5, 2] : pl === 'ln' ? [-4, -3, -2, -1, 0, 1] : [0, Math.round(ymax / 4), Math.round(ymax / 2), Math.round(3 * ymax / 4)];
      const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: 0, xmax: TM, ymin, ymax, col, yt, xt: [0, 10, 20, 30, 40], fy: v => bn(+v.toFixed(1)), xl: 'সময় (min)', yl: pl === 'c' ? '[A] (mol L⁻¹)' : pl === 'ln' ? 'ln [A]' : '1/[A] (L mol⁻¹)', ylx: 40 });
      const straight = (pl === 'c' && n === 0) || (pl === 'ln' && n === 1) || (pl === 'inv' && n === 2);
      const pts = []; for (let i = 0; i <= 200; i++) { const t = i / 200 * TM, v = fy(t); if (isFinite(v) && v >= ymin - 0.5 && v <= ymax * 1.2) pts.push([P.X(t), P.Y(Math.max(ymin, Math.min(ymax, v)))]); }
      g.save(); g.beginPath(); g.rect(gx, gy - 2, gw + 2, gh + 4); g.clip();
      path(g, pts, straight ? '#2e9d4e' : '#2d6fd6', 3);
      // half-life markers on [A] plot
      if (pl === 'c') {
        let t0 = 0, a = A0; const marks = [];
        for (let i = 0; i < 5; i++) { const th = thalf(a); if (!isFinite(th) || t0 + th > TM) break; t0 += th; a /= 2; marks.push([t0, a, th]); }
        let prev = 0;
        marks.forEach(([tm, a2, th], i) => { const x = P.X(tm), y = P.Y(a2); g.strokeStyle = 'rgba(224,64,46,.6)'; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(x, y); g.lineTo(x, gy + gh); g.moveTo(gx, y); g.lineTo(x, y); g.stroke(); g.setLineDash([]); g.fillStyle = '#e0402e'; g.beginPath(); g.arc(x, y, 3.5, 0, 7); g.fill();
          const xm = (P.X(prev) + x) / 2; g.strokeStyle = '#e0402e'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(P.X(prev) + 2, gy + gh - 8 - i * 0); g.lineTo(x - 2, gy + gh - 8); g.stroke(); g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; if (x - P.X(prev) > 22) g.fillText('t½', xm, gy + gh - 12); prev = tm; });
      }
      // moving dot
      const v = fy(tp); if (isFinite(v) && v >= ymin && v <= ymax) { g.fillStyle = '#e0402e'; g.beginPath(); g.arc(P.X(tp), P.Y(v), 6, 0, 7); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = 2; g.stroke(); }
      g.restore();
      g.font = `bold 11px ${col.font}`; g.fillStyle = straight ? '#2e9d4e' : col.mu; g.textAlign = 'right'; g.fillText(straight ? 'সরলরেখা ✓ — এই ক্রমের বৈশিষ্ট্যসূচক লেখচিত্র' : 'বক্ররেখা — এই ক্রমের জন্য সরলরেখা নয়', gx + gw, gy + 8);
      // remaining bar
      const frac = conc(tp) / A0; g.fillStyle = col.s3; g.fillRect(gx, H - 12, gw, 6); g.fillStyle = '#2d6fd6'; g.fillRect(gx, H - 12, gw * frac, 6); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`t = ${bn(tp.toFixed(1))} min · অবশিষ্ট ${bn(Math.round(frac * 100))}%`, gx, H - 16);
    };
    const info = () => {
      const k = kv(), u = n === 0 ? '\\mathrm{mol\\,L^{-1}\\,min^{-1}}' : n === 1 ? '\\mathrm{min^{-1}}' : '\\mathrm{L\\,mol^{-1}\\,min^{-1}}';
      const law = n === 0 ? `r = k` : n === 1 ? `r = k[\\ce{A}]` : `r = k[\\ce{A}]^2`;
      const integ = n === 0 ? `[\\ce{A}]_t = [\\ce{A}]_0 - kt` : n === 1 ? `\\ln[\\ce{A}]_t = \\ln[\\ce{A}]_0 - kt` : `\\dfrac{1}{[\\ce{A}]_t} = \\dfrac{1}{[\\ce{A}]_0} + kt`;
      const th = n === 0 ? `t_{1/2} = \\dfrac{[\\ce{A}]_0}{2k} = \\dfrac{${A0.toFixed(1)}}{2\\times${k.toFixed(3)}} = ${thalf(A0).toFixed(1)}\\ \\mathrm{min}` : n === 1 ? `t_{1/2} = \\dfrac{0.693}{k} = \\dfrac{0.693}{${k.toFixed(3)}} = ${thalf(A0).toFixed(1)}\\ \\mathrm{min}` : `t_{1/2} = \\dfrac{1}{k[\\ce{A}]_0} = \\dfrac{1}{${k.toFixed(3)}\\times${A0.toFixed(1)}} = ${thalf(A0).toFixed(1)}\\ \\mathrm{min}`;
      out.innerHTML = `<div>${TXR(law + `,\\quad k = ${k.toFixed(3)}\\ ${u}`)}</div><div style="margin-top:4px">${TXR(integ)}</div><div style="margin-top:4px">${TXR(th)}</div><div class="small" style="margin-top:4px">${n === 1 ? 'প্রথম ক্রম: [A]₀ বদলালেও অর্ধায়ু একই — প্রতিটি t½ এ অর্ধেক।' : n === 0 ? 'শূন্য ক্রম: অর্ধায়ু [A]₀ এর সমানুপাতিক — ঘনমাত্রা কমার সাথে পরবর্তী অর্ধায়ু ছোট হয়; সরলরেখায় নির্দিষ্ট সময়ে শেষ হয়।' : 'দ্বিতীয় ক্রম: অর্ধায়ু [A]₀ এর ব্যস্তানুপাতিক — প্রতিটি পরবর্তী অর্ধায়ু আগেরটির দ্বিগুণ।'}</div>`;
    };
    const A = X.anim(el, d => { if (d && playing) { tp += d * 6; if (tp > TM) tp = 0; } draw(); }, { paused: false });
    const pp = el.querySelector('[data-pp]'); const upd = () => { pp.innerHTML = playing ? X.ico('pause') + 'থামাও' : X.ico('play') + 'চালাও'; }; pp.onclick = () => { playing = !playing; upd(); A.draw(); }; upd();
    X.onSeg(el, 'n', v => { n = +v; info(); A.draw(); }); X.onSeg(el, 'pl', v => { pl = v; A.draw(); });
    sk.oninput = () => { kk = +sk.value; info(); A.draw(); }; sa.oninput = () => { A0 = +sa.value; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(380, w * 0.82)); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৩.১ প্রাথমিক হার পদ্ধতি: ভার্চুয়াল ল্যাব ======================= */
V.c4_initRate = {
  t: 'প্রাথমিক হার পদ্ধতি: ভার্চুয়াল ল্যাবে ক্রম ও k নির্ণয়', k: ['int', 'calc', 'anim'],
  cap: 'একটি "রহস্য বিক্রিয়া" A + B → উৎপাদ। [A] ও [B] বেছে "পরীক্ষা চালাও" চাপো — গ্যাস সিরিঞ্জের পিস্টন সরে উৎপন্ন গ্যাস দেখায় এবং প্রাথমিক হার টেবিলে যোগ হয় (সামান্য পরীক্ষণ ত্রুটিসহ)। কৌশল: একটি ঘনমাত্রা স্থির রেখে অন্যটি দ্বিগুণ বা তিনগুণ করো, হারের অনুপাত দেখো। এরপর তোমার উত্তর (x, y) যাচাই করো, অথবা "সমাধান দেখাও" চাপো। "নতুন রহস্য" প্রতিবার ভিন্ন ক্রম ও k দেয়।',
  html: () => `<div class="grid2"><label class="small">[A] (mol L⁻¹)<select class="inp" data-a>${[0.10, 0.20, 0.30, 0.40].map(v => `<option value="${v}">${v.toFixed(2)}</option>`).join('')}</select></label><label class="small">[B] (mol L⁻¹)<select class="inp" data-b>${[0.10, 0.20, 0.30, 0.40].map(v => `<option value="${v}">${v.toFixed(2)}</option>`).join('')}</select></label></div><div class="ctl"><button class="btn sm primary" data-run>পরীক্ষা চালাও</button><button class="btn sm" data-new>${X.ico('repeat')}নতুন রহস্য</button></div><div data-svg></div><div data-tbl style="margin-top:6px"></div><div class="grid2" style="margin-top:6px"><label class="small">A এর ক্রম x<select class="inp" data-x><option>0</option><option selected>1</option><option>2</option></select></label><label class="small">B এর ক্রম y<select class="inp" data-y><option>0</option><option selected>1</option><option>2</option></select></label></div><div class="ctl"><button class="btn sm" data-chk>উত্তর যাচাই</button><button class="btn sm" data-sol>সমাধান দেখাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const q = s => el.querySelector(s), box = q('[data-svg]'), tbl = q('[data-tbl]'), out = q('[data-out]');
    const R = X.rng(Date.now() % 100000 + 7);
    let ox, oy, kk, rows = [], anim = 0, lastRate = 0;
    const fresh = () => { ox = Math.floor(R() * 3); oy = Math.floor(R() * 3); if (ox + oy === 0) oy = 1; kk = +(0.5 + R() * 4).toFixed(2); rows = []; out.innerHTML = 'দুটি করে পরীক্ষা চালাও যেখানে একটি ঘনমাত্রা বদলায়।'; render(); drawSyr(0); };
    const render = () => {
      tbl.innerHTML = rows.length ? `<div class="table-wrap"><table class="t sm"><thead><tr><th>#</th><th>[A]</th><th>[B]</th><th>প্রাথমিক হার (mol L⁻¹ s⁻¹)</th></tr></thead><tbody>${rows.map((r, i) => `<tr><td>${bn(i + 1)}</td><td>${r[0].toFixed(2)}</td><td>${r[1].toFixed(2)}</td><td>${TXR(sci(r[2], 2))}</td></tr>`).join('')}</tbody></table></div>` : '<div class="small muted">এখনো কোনো পরীক্ষা চালানো হয়নি।</div>';
    };
    const drawSyr = (f) => {
      const W = 400, H = 120, fill = Math.min(1, f);
      let s = `<rect x="20" y="40" width="120" height="58" rx="6" fill="rgba(140,190,240,.25)" class="s-fg" stroke-width="1.4"/><path d="M30 98 q50 -12 100 0" fill="rgba(120,170,230,.5)"/><text x="80" y="114" text-anchor="middle" class="tm" style="font-size:10px">বিক্রিয়া পাত্র</text>`;
      for (let i = 0; i < 8; i++) { const yy = 92 - ((anim * 40 + i * 13) % 50); s += `<circle cx="${40 + (i * 37) % 90}" cy="${f1(yy)}" r="2.5" fill="rgba(255,255,255,.8)" stroke="rgba(80,120,180,.6)"/>`; }
      s += `<path d="M140 60 h36" class="s-fg" stroke-width="3"/><rect x="176" y="46" width="200" height="28" rx="4" fill="var(--surface)" class="s-fg" stroke-width="1.4"/>`;
      for (let i = 0; i <= 10; i++) s += `<line x1="${176 + i * 20}" y1="46" x2="${176 + i * 20}" y2="${i % 5 ? 52 : 56}" class="s-fg"/>`;
      const px = 178 + fill * 190; s += `<rect x="178" y="49" width="${f1(px - 178)}" height="22" fill="rgba(140,190,240,.35)"/><rect x="${f1(px)}" y="47" width="6" height="26" fill="#7b8794"/><line x1="${f1(px + 6)}" y1="60" x2="392" y2="60" stroke="#7b8794" stroke-width="3"/><text x="276" y="40" text-anchor="middle" class="tm" style="font-size:10px">গ্যাস সিরিঞ্জ — প্রথম ১০ s এ উৎপন্ন গ্যাস</text>`;
      box.innerHTML = X.svg(W, H, s, 'গ্যাস সিরিঞ্জ');
    };
    let raf = 0;
    q('[data-run]').onclick = () => {
      const a = +q('[data-a]').value, b = +q('[data-b]').value, r = kk * Math.pow(a, ox) * Math.pow(b, oy) * (1 + (R() - 0.5) * 0.04);
      rows.push([a, b, r]); render(); lastRate = r;
      const maxR = kk * Math.pow(0.4, ox) * Math.pow(0.4, oy), target = Math.min(1, r / maxR * 0.95 + 0.05);
      cancelAnimationFrame(raf); const t0 = performance.now();
      const step = now => { const u = Math.min(1, (now - t0) / 1600); anim = u * 3; drawSyr(target * (1 - Math.pow(1 - u, 2))); if (u < 1) raf = requestAnimationFrame(step); };
      raf = requestAnimationFrame(step);
    };
    q('[data-new]').onclick = fresh;
    const solve = () => {
      const find = (vary) => { for (let i = 0; i < rows.length; i++) for (let j = 0; j < rows.length; j++) { if (i === j) continue; const [a1, b1, r1] = rows[i], [a2, b2, r2] = rows[j]; if (vary === 'A' && b1 === b2 && a2 > a1) return [i, j, a2 / a1, r2 / r1]; if (vary === 'B' && a1 === a2 && b2 > b1) return [i, j, b2 / b1, r2 / r1]; } return null; };
      return { A: find('A'), B: find('B') };
    };
    q('[data-chk]').onclick = () => {
      const x = +q('[data-x]').value, y = +q('[data-y]').value;
      if (rows.length < 2) { out.innerHTML = 'আগে অন্তত তিনটি পরীক্ষা চালাও।'; return; }
      const ok = x === ox && y === oy;
      out.innerHTML = ok ? `<b style="color:var(--ok)">সঠিক!</b> ${TXR(`r = k[\\ce{A}]^{${ox}}[\\ce{B}]^{${oy}}`)} · মোট ক্রম ${bn(ox + oy)}। এবার "সমাধান দেখাও" চেপে k যাচাই করো।` : `<b style="color:var(--bad)">এখনো মেলেনি।</b> এমন দুটি পরীক্ষা তুলনা করো যেখানে কেবল [A] (বা কেবল [B]) বদলেছে: হারের অনুপাত = (ঘনমাত্রার অনুপাত)<sup>ক্রম</sup>।`;
    };
    q('[data-sol]').onclick = () => {
      const s = solve(); let h = '';
      const line = (pair, nm, ord) => pair ? TXR(`\\dfrac{r_{${pair[1] + 1}}}{r_{${pair[0] + 1}}} = ${pair[3].toFixed(2)} = (${pair[2].toFixed(2)})^{${nm}} \\Rightarrow ${nm} = ${Math.round(Math.log(pair[3]) / Math.log(pair[2]))}`) : `<span class="small">${nm === 'x' ? '[A]' : '[B]'} বদলানো দুটি পরীক্ষা (অন্যটি স্থির) এখনো নেই।</span>`;
      h += `<div>${line(s.A, 'x', ox)}</div><div style="margin-top:4px">${line(s.B, 'y', oy)}</div>`;
      if (s.A && s.B && rows.length) { const [a, b, r] = rows[0]; const k = r / (Math.pow(a, ox) * Math.pow(b, oy)); const u = ox + oy === 0 ? '\\mathrm{mol\\,L^{-1}\\,s^{-1}}' : ox + oy === 1 ? '\\mathrm{s^{-1}}' : ox + oy === 2 ? '\\mathrm{L\\,mol^{-1}\\,s^{-1}}' : ox + oy === 3 ? '\\mathrm{L^{2}\\,mol^{-2}\\,s^{-1}}' : '\\mathrm{L^{3}\\,mol^{-3}\\,s^{-1}}'; h += `<div style="margin-top:4px">${TXR(`k = \\dfrac{r_1}{[\\ce{A}]^{${ox}}[\\ce{B}]^{${oy}}} = \\dfrac{${sci(r, 2)}}{(${a.toFixed(2)})^{${ox}}(${b.toFixed(2)})^{${oy}}} \\approx ${k.toFixed(2)}\\ ${u}`)}</div><div class="small muted">প্রকৃত k = ${kk.toFixed(2)} (পরীক্ষণ ত্রুটি ±২%)</div>`; }
      out.innerHTML = h;
    };
    fresh();
    return () => cancelAnimationFrame(raf);
  }
};

/* ======================= ৪.৩.২ হারের নিয়ামক: কণা-সিমুলেশন ======================= */
V.c4_factors = {
  t: 'বিক্রিয়ার হারের নিয়ামক: তাপমাত্রা, ঘনমাত্রা, পৃষ্ঠতল ও প্রভাবক (কণা-সিমুলেশন)', k: ['anim', 'int', '2d'],
  cap: '"গ্যাস" মোডে A (নীল) ও B (কমলা) কণা ছুটোছুটি করে; কোনো সংঘর্ষে আপেক্ষিক গতিশক্তি সক্রিয়ণ শক্তির সমান বা বেশি হলে AB তৈরি হয় (সবুজ ঝলক), কম হলে কণাগুলো শুধু ছিটকে যায় (ধূসর বলয়)। তাপমাত্রা বাড়লে কণা দ্রুত ছোটে এবং বেশি সংঘর্ষ Ea অতিক্রম করে; ঘনমাত্রা বাড়ালে সংঘর্ষ বেশি; প্রভাবক Ea কমায়। "কঠিন + এসিড" মোডে মার্বেলের খণ্ড বনাম গুঁড়া — কেবল পৃষ্ঠের কণাই এসিডের সাথে বিক্রিয়া করে; নিচে CO₂ আয়তন-সময় লেখচিত্রে আগের রান ধূসর রেখায় থাকে, যাতে তুলনা করা যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['gas', 'গ্যাস A + B'], ['solid', 'কঠিন + এসিড']], 'gas')}</div>${X.cv('হারের নিয়ামকের কণা-সিমুলেশন')}<div class="grid2" style="margin-top:8px"><label class="small">তাপমাত্রা <b data-tv></b><input type="range" min="250" max="450" step="10" value="300" data-T></label><label class="small" data-cl>ঘনমাত্রা (কণা) <b data-cv></b><input type="range" min="6" max="30" step="2" value="14" data-c></label></div><div class="ctl"><label class="small" data-catl><input type="checkbox" data-cat> প্রভাবক (Ea কমায়)</label><span data-sa style="display:none">${X.seg('sa', [['lump', 'বড় খণ্ড'], ['chunks', '৪ খণ্ড'], ['powder', 'গুঁড়া']], 'lump')}</span><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), sT = el.querySelector('[data-T]'), sC = el.querySelector('[data-c]'), cat = el.querySelector('[data-cat]');
    let L = X.fit(c, w => Math.min(470, w * 1.05)), mode = 'gas', T = 300, N = 14, catOn = false, sa = 'lump';
    const R = X.rng(9);
    let P = [], fx = [], ev = [], clock = 0, prodHist = [], prev = null, solid = [], co2 = 0;
    const EA = () => (catOn ? 0.45 : 1.0); // relative threshold (in units of mean KE at 300K * factor)
    const box = () => ({ x: 10, y: 10, w: L.W - 20, h: L.H * 0.56 });
    const V0 = 105, vT = () => Math.sqrt(T / 300) * V0;
    const rv = () => { // Maxwell-ish 2D speed
      const s = vT(); const a = R() * 6.283, u = Math.sqrt(-2 * Math.log(Math.max(1e-6, R()))) * s * 0.75; return [Math.cos(a) * u, Math.sin(a) * u];
    };
    const reset = () => {
      if (prodHist.length > 5) prev = prodHist.slice(); prodHist = []; clock = 0; fx = []; ev = []; co2 = 0;
      const b = box(); P = [];
      if (mode === 'gas') { for (let i = 0; i < N; i++) for (const t of ['A', 'B']) { const [vx, vy] = rv(); P.push({ t, x: b.x + 12 + R() * (b.w - 24), y: b.y + 12 + R() * (b.h - 24), vx, vy }); } }
      else {
        for (let i = 0; i < 26; i++) { const [vx, vy] = rv(); P.push({ t: 'H', x: b.x + 12 + R() * (b.w - 24), y: b.y + 12 + R() * (b.h * 0.55), vx, vy }); }
        // marble: grid of cells at bottom; arrangement by sa
        solid = []; const cs = 9, base = b.y + b.h - 8;
        const block = (cx, cols, rows) => { for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) solid.push({ x: cx + i * cs, y: base - (j + 1) * cs, alive: true }); };
        if (sa === 'lump') block(b.x + b.w / 2 - 6 * cs, 12, 6);
        else if (sa === 'chunks') { const gap = (b.w - 4 * 6 * cs) / 5; for (let q = 0; q < 4; q++) block(b.x + gap + q * (6 * cs + gap), 6, 3); }
        else { for (let q = 0; q < 72; q++) solid.push({ x: b.x + 14 + R() * (b.w - 28), y: base - cs - R() * b.h * 0.35, alive: true, free: true }); }
      }
    };
    const exposed = s => { if (s.free) return true; const cs = 9; return !solid.some(o => o.alive && o !== s && o.x === s.x && Math.abs(o.y - (s.y - cs)) < 1) || !solid.some(o => o.alive && o.y === s.y && Math.abs(o.x - (s.x - cs)) < 1) || !solid.some(o => o.alive && o.y === s.y && Math.abs(o.x - (s.x + cs)) < 1); };
    const step = dt => {
      clock += dt; const b = box();
      P.forEach(p => { p.x += p.vx * dt; p.y += p.vy * dt; if (p.x < b.x + 6) { p.x = b.x + 6; p.vx = Math.abs(p.vx); } if (p.x > b.x + b.w - 6) { p.x = b.x + b.w - 6; p.vx = -Math.abs(p.vx); } if (p.y < b.y + 6) { p.y = b.y + 6; p.vy = Math.abs(p.vy); } if (p.y > b.y + b.h - 6) { p.y = b.y + b.h - 6; p.vy = -Math.abs(p.vy); } });
      if (mode === 'gas') {
        const thrAbs = EA() * 2.6 * 4 * Math.pow(0.75 * V0, 2); // fixed Ea (absolute), ≈7% of collisions at 300 K
        for (let i = 0; i < P.length; i++) { const a = P[i]; if (a.t === 'AB' || a.cool > 0) continue; for (let j = i + 1; j < P.length; j++) { const d = P[j]; if (d.t === 'AB' || d.cool > 0) continue; const dx = a.x - d.x, dy = a.y - d.y; if (dx * dx + dy * dy > 130) continue; if (a.t === d.t) { [a.vx, d.vx] = [d.vx, a.vx]; [a.vy, d.vy] = [d.vy, a.vy]; a.cool = d.cool = 0.15; continue; }
          const rvx = a.vx - d.vx, rvy = a.vy - d.vy, e = rvx * rvx + rvy * rvy; ev.push([clock, 'c']);
          if (e >= thrAbs) { a.t = 'AB'; a.vx = (a.vx + d.vx) / 2; a.vy = (a.vy + d.vy) / 2; d.dead = true; fx.push({ x: a.x, y: a.y, k: 1, t: 0 }); ev.push([clock, 'e']); }
          else { [a.vx, d.vx] = [d.vx, a.vx]; [a.vy, d.vy] = [d.vy, a.vy]; a.cool = d.cool = 0.15; fx.push({ x: (a.x + d.x) / 2, y: (a.y + d.y) / 2, k: 0, t: 0 }); }
          break; } }
        P = P.filter(p => !p.dead); P.forEach(p => { if (p.cool > 0) p.cool -= dt; });
      } else {
        const pReact = 0.35 * Math.exp(-(EA() * 3500) * (1 / T - 1 / 300)) * (catOn ? 1.6 : 1);
        P.forEach(p => { for (const s of solid) { if (!s.alive) continue; if (Math.abs(p.x - s.x - 4.5) < 7 && Math.abs(p.y - s.y - 4.5) < 7) { ev.push([clock, 'c']); if (exposed(s) && R() < pReact) { s.alive = false; co2++; fx.push({ x: s.x + 4.5, y: s.y, k: 1, t: 0 }); ev.push([clock, 'e']); } p.vy = -Math.abs(p.vy); p.vx += (R() - .5) * 30; break; } } });
      }
      fx.forEach(f => { f.t += dt; }); fx = fx.filter(f => f.t < 0.5);
      ev = ev.filter(e => clock - e[0] < 2);
      if (!prodHist.length || clock - prodHist[prodHist.length - 1][0] > 0.2) prodHist.push([clock, mode === 'gas' ? P.filter(p => p.t === 'AB').length : co2]);
      if (prodHist.length > 300) prodHist.shift();
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(), b = box();
      g.clearRect(0, 0, W, H);
      g.fillStyle = mode === 'solid' ? 'rgba(140,190,240,.16)' : col.s2; g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.roundRect(b.x, b.y, b.w, b.h, 10); g.fill(); g.stroke();
      g.save(); g.beginPath(); g.roundRect(b.x, b.y, b.w, b.h, 10); g.clip();
      if (mode === 'solid') solid.forEach(s => { if (!s.alive) return; g.fillStyle = exposed(s) ? '#e9e4d8' : '#d3ccbb'; g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 0.8; g.fillRect(s.x, s.y, 8.4, 8.4); g.strokeRect(s.x, s.y, 8.4, 8.4); });
      fx.forEach(f => { g.strokeStyle = f.k ? `rgba(46,157,78,${1 - f.t * 2})` : `rgba(140,140,140,${0.7 - f.t * 1.4})`; g.lineWidth = f.k ? 2.4 : 1.2; g.beginPath(); g.arc(f.x, f.y, 5 + f.t * (f.k ? 26 : 12), 0, 7); g.stroke(); });
      P.forEach(p => { if (p.t === 'A') ball(g, p.x, p.y, 5, '#2d5fb3', '#9cc0ff'); else if (p.t === 'B') ball(g, p.x, p.y, 5, '#c66a12', '#ffc27a'); else if (p.t === 'H') ball(g, p.x, p.y, 3.6, '#c23b2a', '#ff9a8a'); else { ball(g, p.x - 3.5, p.y, 5, '#2d5fb3', '#9cc0ff'); ball(g, p.x + 3.5, p.y, 5, '#c66a12', '#ffc27a'); } });
      g.restore();
      // graph
      const gx = 46, gy = b.y + b.h + 22, gw = W - gx - 16, gh = H - gy - 30;
      const ymax = mode === 'gas' ? N : Math.max(20, solid.length);
      const Pp = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax: 30, ymax, col, yt: [0, Math.round(ymax / 2), ymax], xt: [0, 10, 20, 30], xl: 'সময় (s)', yl: mode === 'gas' ? 'AB সংখ্যা' : 'CO₂ (একক)', ylx: 34 });
      const line = (h, color, w, dash) => path(g, h.filter(q => q[0] <= 30).map(([t, v]) => [Pp.X(t), Pp.Y(Math.min(ymax, v))]), color, w, dash);
      if (prev) line(prev, 'rgba(140,140,140,.8)', 1.8, [5, 4]);
      line(prodHist, '#2e9d4e', 2.6);
      g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.textAlign = 'left'; if (prev) g.fillText('- - আগের রান', gx + 8, gy + 8);
    };
    const info = () => {
      const col = ev.filter(e => e[1] === 'c').length / 2, eff = ev.filter(e => e[1] === 'e').length / 2;
      el.querySelector('[data-tv]').textContent = bn(T) + ' K'; el.querySelector('[data-cv]').textContent = bn(N);
      const fr = Math.exp(-EA() * 2.6 * 4 * Math.pow(0.75 * V0, 2) / (4 * Math.pow(0.75 * vT(), 2)));
      out.innerHTML = `সংঘর্ষ ≈ <b>${bn(col.toFixed(1))}</b>/s · কার্যকর সংঘর্ষ ≈ <b style="color:#2e9d4e">${bn(eff.toFixed(1))}</b>/s${col > 0 ? ` (${bn(Math.round(eff / col * 100))}%)` : ''}<br><span class="small">${mode === 'gas' ? `Ea অতিক্রমকারী সংঘর্ষের আনুমানিক ভগ্নাংশ ∝ e<sup>−Ea/RT</sup> ≈ ${bn((fr * 100).toFixed(1))}% — তাপমাত্রা ${T > 300 ? 'বাড়ানোয় অনেক বেড়েছে' : T < 300 ? 'কমানোয় কমে গেছে' : 'কক্ষ তাপমাত্রায়'}${catOn ? '; প্রভাবক Ea কমিয়েছে' : ''}।` : `উন্মুক্ত (হালকা রঙের) পৃষ্ঠ কণা: ${bn(solid.filter(s => s.alive && exposed(s)).length)} টি — ${sa === 'powder' ? 'গুঁড়ায় প্রায় সব কণাই উন্মুক্ত' : sa === 'chunks' ? '৪ খণ্ডে পৃষ্ঠ বেড়েছে' : 'বড় খণ্ডে কেবল বাইরের স্তর'}।`}</span>`;
    };
    let ti = 0;
    const A = X.anim(el, d => { if (d) step(d); draw(); ti += d; if (ti > 0.4) { ti = 0; info(); } }, { paused: false });
    let Tprev = 300;
    sT.oninput = () => { T = +sT.value; const scale = Math.sqrt(T / Tprev); Tprev = T; P.forEach(p => { p.vx *= scale; p.vy *= scale; }); info(); };
    sC.oninput = () => { N = +sC.value; reset(); info(); };
    cat.onchange = () => { catOn = cat.checked; info(); };
    X.onSeg(el, 'm', m => { mode = m; prev = null; el.querySelector('[data-sa]').style.display = m === 'solid' ? '' : 'none'; el.querySelector('[data-cl]').style.display = m === 'gas' ? '' : 'none'; reset(); info(); });
    X.onSeg(el, 'sa', v => { sa = v; reset(); info(); });
    el.querySelector('[data-rs]').onclick = () => { reset(); info(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(470, w * 1.05)); reset(); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
