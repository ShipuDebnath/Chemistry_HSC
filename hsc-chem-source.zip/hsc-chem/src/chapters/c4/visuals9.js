/* Chapter 4 visuals part 9 — ionic equilibrium: Kw, Ostwald dilution, Ka, Kb (4.10) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, TX = C4.tx, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
const pKwT = Tc => { const T = Tc + 273.15; return 4470.99 / T - 6.0875 + 0.01706 * T; };
const lerp = C4.lerp;
const sciTxt = v => { if (!isFinite(v) || v <= 0) return '০'; const e = Math.floor(Math.log10(v)); if (e >= -2 && e <= 2) return bn(+v.toPrecision(3)); return bn((v / Math.pow(10, e)).toFixed(2)) + '×১০' + X.sup(e); };

/* water molecule glyph */
const water = (g, x, y, a, s, tag) => {
  const ca = Math.cos(a), sa = Math.sin(a), d = 7 * s;
  const h1 = [x + Math.cos(a - 0.91) * d, y + Math.sin(a - 0.91) * d], h2 = [x + Math.cos(a + 0.91) * d, y + Math.sin(a + 0.91) * d];
  if (tag === 'H3O') { const h3 = [x - ca * d, y - sa * d]; ball(g, h3[0], h3[1], 3 * s, '#d8dde3', '#fff'); }
  if (tag !== 'OH') { ball(g, h1[0], h1[1], 3 * s, '#d8dde3', '#fff'); }
  ball(g, h2[0], h2[1], 3 * s, '#d8dde3', '#fff');
  ball(g, x, y, 5 * s, '#c0392b', '#ff9f8f');
};

/* ======================= ৪.১০.১ পানির স্ব-আয়নীকরণ ও Kw এর তাপমাত্রা নির্ভরতা ======================= */
V.c4_kwTemp = {
  t: 'পানির স্ব-আয়নীকরণ: H₃O⁺ ও OH⁻ এর ক্ষণস্থায়ী জন্ম, প্রোটন লাফ এবং Kw ও নিরপেক্ষ pH এর তাপমাত্রা নির্ভরতা', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে পানির অণুর আণবিক দৃশ্য (লাল O, সাদা H)। মাঝে মাঝে দুটি অণুর মধ্যে প্রোটন স্থানান্তরে H₃O⁺ (হলুদ বলয়, +) ও OH⁻ (নীল বলয়, −) জন্ম নেয়; H₃O⁺ এর প্রোটন পাশের অণুতে লাফ দিয়ে চার্জ সরিয়ে নেয় (গ্রটথাস কৌশল), শেষে আয়ন জোড়া মিলে আবার পানি হয়। আয়নের সংখ্যা ব্যাখ্যার জন্য বহুগুণ বাড়িয়ে দেখানো — বাস্তবে প্রায় ৫৫ কোটি অণুতে একটি। তাপমাত্রা বাড়ালে আয়ন জোড়া বেশি দেখা যায় (তাপহারী)। ডানে pK_w ও নিরপেক্ষ pH (= ½pK_w) বনাম তাপমাত্রা — ১০০ °C এ নিরপেক্ষ pH ৬.১৩।',
  html: () => `${X.cv('পানির স্ব-আয়নীকরণ ও Kw এর তাপমাত্রা নির্ভরতা')}<label class="small" style="display:block;margin-top:8px">তাপমাত্রা = <b data-tv></b> °C<input type="range" min="0" max="100" step="1" value="25" data-t></label><div class="ctl"><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : w * 0.75 + 230;
    let L = X.fit(c, hf), T = 25, M = [], ions = [], acc = 0, outT = 0;
    const R = X.rng(51), N = 56;
    for (let i = 0; i < N; i++) M.push({ x: R(), y: R(), vx: (R() - 0.5) * 0.12, vy: (R() - 0.5) * 0.12, a: R() * 6.28, va: (R() - 0.5) * 2, tag: null });
    const nearest = (m, excl) => { let b = null, bd = 1e9; M.forEach(o => { if (o === m || o.tag || (excl && excl.includes(o))) return; const d = (o.x - m.x) ** 2 + (o.y - m.y) ** 2; if (d < bd) { bd = d; b = o; } }); return b; };
    const step = dt => {
      const sp = Math.sqrt((T + 273) / 298);
      M.forEach(m => { m.x += m.vx * dt * sp; m.y += m.vy * dt * sp; m.a += m.va * dt * sp; if (m.x < 0.03 || m.x > 0.97) { m.vx *= -1; m.x = Math.max(0.03, Math.min(0.97, m.x)); } if (m.y < 0.04 || m.y > 0.96) { m.vy *= -1; m.y = Math.max(0.04, Math.min(0.96, m.y)); } });
      const target = 0.6 * Math.pow(10, (14 - pKwT(T)) / 2) * 1.2; // visible pairs (exaggerated)
      acc += dt;
      if (acc > 0.2) { acc = 0; if (ions.length < target && R() < 0.5) { const a = M.filter(m => !m.tag)[Math.floor(R() * (N - 2 * ions.length))]; if (a) { const b = nearest(a); if (b) { a.tag = 'H3O'; b.tag = 'OH'; ions.push({ p: a, o: b, life: 2.5 + R() * 2, hop: 0.6, fl: 1 }); } } } }
      ions.forEach(I => {
        I.life -= dt; I.hop -= dt; I.fl = Math.max(0, I.fl - dt * 1.5);
        if (I.hop <= 0 && I.life > 0.8) { const nb = nearest(I.p, [I.o]); if (nb) { I.p.tag = null; nb.tag = 'H3O'; I.trail = { from: [I.p.x, I.p.y], to: nb, t: 1 }; I.p = nb; } I.hop = 0.5 + R() * 0.6; }
        if (I.trail) I.trail.t -= dt * 3;
      });
      ions.filter(I => I.life <= 0).forEach(I => { I.p.tag = null; I.o.tag = null; });
      ions = ions.filter(I => I.life > 0);
    };
    const geo = () => { const W = L.W, H = L.H; return wide(W) ? { box: [10, 12, W * 0.46, H - 40], g: [W * 0.46 + 68, 16, W * 0.54 - 86, H - 62] } : { box: [10, 12, W - 20, W * 0.75 - 20], g: [52, W * 0.75 + 22, W - 72, 160] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo(), [bx, by, bw, bh] = G.box;
      g.fillStyle = 'rgba(120,180,230,.14)'; g.fillRect(bx, by, bw, bh); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.strokeRect(bx, by, bw, bh);
      const s = Math.max(0.8, Math.min(1.25, bw / 320));
      M.forEach(m => { const x = bx + m.x * bw, y = by + m.y * bh; water(g, x, y, m.a, s, m.tag); if (m.tag) { g.strokeStyle = m.tag === 'H3O' ? '#f2b705' : '#2d6fd6'; g.lineWidth = 2.2; g.beginPath(); g.arc(x, y, 12 * s, 0, 7); g.stroke(); g.fillStyle = m.tag === 'H3O' ? '#b07d00' : '#1d55b8'; g.font = `bold ${Math.round(12 * s)}px ${col.font}`; g.textAlign = 'center'; g.fillText(m.tag === 'H3O' ? '+' : '−', x + 12 * s, y - 9 * s); } });
      ions.forEach(I => { if (I.trail && I.trail.t > 0) { g.strokeStyle = `rgba(242,183,5,${I.trail.t.toFixed(2)})`; g.setLineDash([3, 3]); g.lineWidth = 2; g.beginPath(); g.moveTo(bx + I.trail.from[0] * bw, by + I.trail.from[1] * bh); g.lineTo(bx + I.trail.to.x * bw, by + I.trail.to.y * bh); g.stroke(); g.setLineDash([]); } });
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`দৃশ্যমান আয়ন জোড়া: ${bn(ions.length)} (ব্যাখ্যার জন্য বহুগুণ বর্ধিত)`, bx, by + bh + 16);
      const [gx, gy, gw, gh] = G.g, P = cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: 0, xmax: 100, ymin: 6, ymax: 15, col, xt: [0, 25, 50, 75, 100], yt: [6, 7, 8, 10, 12, 14], xl: 'তাপমাত্রা (°C)', yl: 'pK_w / নিরপেক্ষ pH', ylx: 36 });
      const p1 = [], p2 = []; for (let t = 0; t <= 100; t += 2) { p1.push([P.X(t), P.Y(pKwT(t))]); p2.push([P.X(t), P.Y(pKwT(t) / 2)]); }
      path(g, p1, '#7b3fa0', 2.6); path(g, p2, '#2e9d4e', 2.6);
      g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(gx, P.Y(7)); g.lineTo(gx + gw, P.Y(7)); g.stroke(); g.setLineDash([]);
      g.fillStyle = '#7b3fa0'; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText('pK_w', gx + gw, P.Y(pKwT(100)) - 6); g.fillStyle = '#2e9d4e'; g.fillText('নিরপেক্ষ pH = ½pK_w', gx + gw, P.Y(pKwT(100) / 2) + 14);
      [[pKwT(T), '#7b3fa0'], [pKwT(T) / 2, '#2e9d4e']].forEach(([v, cc]) => ball(g, P.X(T), P.Y(v), 5, cc, '#fff'));
      g.strokeStyle = col.mu; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(P.X(T), gy); g.lineTo(P.X(T), gy + gh); g.stroke(); g.setLineDash([]);
    };
    const info = () => {
      const pk = pKwT(T), Kw = Math.pow(10, -pk), h = Math.sqrt(Kw);
      q('[data-tv]').textContent = bn(T);
      out.innerHTML = TXB(`\\ce{H2O + H2O <=> H3O+ + OH-}\\quad \\Delta H = +55.8\\ \\mathrm{kJ\\,mol^{-1}}`) + TXB(`K_w(${T}\\,^\\circ\\mathrm{C}) = ${sci(Kw, 2)},\\quad \\mathrm{p}K_w = ${pk.toFixed(2)}`) +
        TXB(`[\\ce{H+}] = [\\ce{OH-}] = \\sqrt{K_w} = ${sci(h, 2)}\\ \\mathrm{M},\\quad \\mathrm{pH}_{\\text{নিরপেক্ষ}} = ${(pk / 2).toFixed(2)}`) +
        `<div class="small">${Math.abs(T - 25) < 1 ? '২৫ °C এ নিরপেক্ষ pH ঠিক ৭.০০।' : T > 25 ? `pH ${fx(pk / 2, 2)} হলেও পানি নিরপেক্ষ — [H⁺] = [OH⁻]। "pH ৭ = নিরপেক্ষ" কেবল ২৫ °C এ।` : `ঠান্ডা পানিতে K_w কম, নিরপেক্ষ pH ৭ এর বেশি (${fx(pk / 2, 2)}), তবু নিরপেক্ষ।`}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { step(dt); outT += dt; } draw(); }, { paused: false });
    X.pp(el, A);
    q('[data-t]').oninput = e => { T = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ---------- acids/bases data ---------- */
const ACIDS = [['HF', 6.8e-4], ['HNO₂', 4.5e-4], ['HCOOH', 1.8e-4], ['C₆H₅COOH', 6.3e-5], ['CH₃COOH', 1.8e-5], ['H₂CO₃', 4.3e-7], ['HCN', 4.9e-10], ['C₆H₅OH', 1.3e-10]];
const alphaExact = (K, c) => (-K + Math.sqrt(K * K + 4 * K * c)) / (2 * c);
const hWeak = (K, c) => { let lo = 1e-14, hi = c + 1e-6; for (let i = 0; i < 100; i++) { const h = Math.sqrt(lo * hi), f = K * c / (K + h) + 1e-14 / h - h; if (f > 0) lo = h; else hi = h; } return Math.sqrt(lo * hi); };

/* ======================= ৪.১০.২ অসওয়াল্ডের লঘূকরণ সূত্র ======================= */
V.c4_ostwald = {
  t: 'অসওয়াল্ডের লঘূকরণ সূত্র: লঘু করলে বিয়োজন মাত্রা বাড়ে, [H⁺] কমে (কণা-দৃশ্য ও লেখচিত্র)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বিকারে একই পরিমাণ দুর্বল এসিড (৪০টি HA অণু প্রতিনিধি)। ঘনমাত্রা স্লাইডার কমালে (লঘু করলে) বিকার বড় হয় এবং বেশি অণু বিয়োজিত হয়ে H₃O⁺ (হলুদ +) ও A⁻ (বেগুনি −) হয় — α বাড়ে। কিন্তু আয়তন বেশি বেড়ে যাওয়ায় প্রতি লিটারে H⁺ কমে। ডানে উপরে α (%) বনাম log c — পুরু রেখা পূর্ণ (দ্বিঘাত) সমাধান, ড্যাশ রেখা আসন্ন সূত্র α = √(K_a/c); তীব্র এসিড (HCl) সবসময় ~১০০%। নিচে pH বনাম log c। লাল ছায়া অঞ্চলে α > ৫% — আসন্ন সূত্র অচল।',
  html: () => `<label class="small">এসিড: <select data-a>${ACIDS.map((a, i) => `<option value="${i}" ${i === 4 ? 'selected' : ''}>${a[0]} (K<sub>a</sub> = ${sci(a[1], 1).replace('\\times10^{', ' × 10^').replace('}', '')})</option>`).join('')}</select></label>${X.cv('অসওয়াল্ডের লঘূকরণ সূত্রের কণা-দৃশ্য ও লেখচিত্র')}<label class="small" style="display:block;margin-top:8px">ঘনমাত্রা c = <b data-cv></b> mol L⁻¹<input type="range" min="-4" max="0" step="0.05" value="-1" data-c></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), sel = q('[data-a]');
    const hf = w => wide(w) ? 330 : w * 0.8 + 320;
    let L = X.fit(c, hf), ai = 4, lc = -1, P = [], vis = 1;
    const R = X.rng(61); for (let i = 0; i < 40; i++) P.push({ x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, a: R() * 6, d: false, f: 0 });
    const step = dt => {
      const K = ACIDS[ai][1], cc = Math.pow(10, lc), al = alphaExact(K, cc), nd = Math.round(al * 40);
      let cur = P.filter(p => p.d).length; P.forEach(p => { if (cur < nd && !p.d && R() < 0.05) { p.d = true; p.f = 1; cur++; } else if (cur > nd && p.d && R() < 0.05) { p.d = false; p.f = 1; cur--; } });
      P.forEach(p => { p.x += p.vx * dt * 0.15; p.y += p.vy * dt * 0.15; p.a += dt; p.f = Math.max(0, p.f - dt * 1.5); if (p.x < 0.04 || p.x > 0.96) p.vx *= -1; if (p.y < 0.06 || p.y > 0.94) p.vy *= -1; });
      vis += ((-lc) - vis) * Math.min(1, dt * 3);
    };
    const geo = () => { const W = L.W, H = L.H; return wide(W) ? { bk: [10, 10, W * 0.42, H - 30], g1: [W * 0.42 + 66, 14, W * 0.58 - 84, (H - 90) / 2], g2: [W * 0.42 + 66, 14 + (H - 90) / 2 + 46, W * 0.58 - 84, (H - 90) / 2] } : { bk: [10, 10, W - 20, W * 0.8 - 10], g1: [52, W * 0.8 + 18, W - 72, 120], g2: [52, W * 0.8 + 186, W - 72, 100] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo(), [bx, by, bw, bh] = G.bk;
      // beaker size grows with dilution (log scale)
      const f = 0.35 + 0.65 * (vis / 4), w = bw * f, h = bh * (0.45 + 0.55 * vis / 4), x0 = bx + (bw - w) / 2, y0 = by + bh - h;
      g.fillStyle = 'rgba(120,180,230,.18)'; g.fillRect(x0, y0 + 8, w, h - 8); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x0 - 4, y0); g.lineTo(x0, y0 + 4); g.lineTo(x0, by + bh); g.lineTo(x0 + w, by + bh); g.lineTo(x0 + w, y0 + 4); g.lineTo(x0 + w + 4, y0); g.stroke();
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(`V = ${fx(Math.pow(10, -lc), Math.pow(10, -lc) < 10 ? 1 : 0)} L (১ mol এসিড)`, x0 + w / 2, y0 - 4);
      const s = Math.max(0.8, Math.min(1.1, w / 200));
      P.forEach(p => { const x = x0 + 6 + p.x * (w - 12), y = y0 + 12 + p.y * (h - 20); if (!p.d) { const ca = Math.cos(p.a) * 4 * s, sa = Math.sin(p.a) * 4 * s; ball(g, x - ca, y - sa, 3 * s, '#d8dde3', '#fff'); ball(g, x + ca, y + sa, 5 * s, '#5b2a86', '#c7a2ec'); } else { ball(g, x - 8 * s, y, 5 * s, '#5b2a86', '#c7a2ec'); g.fillStyle = '#5b2a86'; g.font = `bold ${Math.round(10 * s)}px ${col.font}`; g.textAlign = 'center'; g.fillText('−', x - 8 * s, y - 7 * s); ball(g, x + 8 * s, y + 3, 4 * s, '#f2b705', '#fff1b8'); g.fillStyle = '#b07d00'; g.fillText('+', x + 8 * s, y - 4 * s); } if (p.f > 0) { g.strokeStyle = `rgba(46,157,78,${p.f.toFixed(2)})`; g.lineWidth = 1.5; g.beginPath(); g.arc(x, y, 12 * s, 0, 7); g.stroke(); } });
      const K = ACIDS[ai][1];
      const [x1, y1, w1, h1] = G.g1, P1 = cplot(g, { x0: x1, y0: y1, w: w1, h: h1, xmin: -4, xmax: 0, ymax: 100, col, xt: [-4, -3, -2, -1, 0], yt: [0, 25, 50, 75, 100], fy: v => bn(v) + '%', yl: 'α', ylx: 36 });
      const lim = Math.log10(K / 0.0025); if (lim > -4) { g.fillStyle = 'rgba(224,64,46,.08)'; g.fillRect(x1, y1, P1.X(Math.min(0, lim)) - x1, h1); }
      const pe = [], pa = []; for (let v = -4; v <= 0.001; v += 0.04) { const cc = Math.pow(10, v); pe.push([P1.X(v), P1.Y(alphaExact(K, cc) * 100)]); pa.push([P1.X(v), P1.Y(Math.min(100, Math.sqrt(K / cc) * 100))]); }
      path(g, [[x1, P1.Y(100)], [x1 + w1, P1.Y(100)]], '#9aa3ad', 1.6, [2, 2]); path(g, pa, '#7b3fa0', 1.6, [5, 3]); path(g, pe, '#7b3fa0', 2.8);
      g.fillStyle = '#8a96a3'; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('HCl (তীব্র) ≈ ১০০%', x1 + w1, P1.Y(100) + 12);
      ball(g, P1.X(lc), P1.Y(alphaExact(K, Math.pow(10, lc)) * 100), 5, '#c0392b', '#ffb3a8');
      const [x2, y2, w2, h2] = G.g2, P2 = cplot(g, { x0: x2, y0: y2, w: w2, h: h2, xmin: -4, xmax: 0, ymin: 0, ymax: 8, col, xt: [-4, -3, -2, -1, 0], yt: [0, 2, 4, 6, 8], xl: 'log c', yl: 'pH', ylx: 30 });
      const ph = []; for (let v = -4; v <= 0.001; v += 0.04) ph.push([P2.X(v), P2.Y(-Math.log10(hWeak(K, Math.pow(10, v))))]); path(g, ph, '#d06a1e', 2.6);
      const phs = []; for (let v = -4; v <= 0.001; v += 0.04) phs.push([P2.X(v), P2.Y(-v)]); path(g, phs, '#9aa3ad', 1.4, [2, 2]);
      ball(g, P2.X(lc), P2.Y(-Math.log10(hWeak(K, Math.pow(10, lc)))), 5, '#c0392b', '#ffb3a8');
    };
    const info = () => {
      const [nm, K] = ACIDS[ai], cc = Math.pow(10, lc), ap = Math.sqrt(K / cc), ex = alphaExact(K, cc), h = hWeak(K, cc);
      q('[data-cv]').textContent = cc >= 0.01 ? fx(cc, 3) : sciTxt(cc);
      out.innerHTML = TXB(`\\alpha_{\\text{আসন্ন}} = \\sqrt{\\dfrac{K_a}{c}} = \\sqrt{\\dfrac{${sci(K, 1)}}{${sci(cc, 2)}}} = ${(ap * 100).toFixed(2)}\\%`) + TXB(`\\alpha_{\\text{পূর্ণ}} = \\dfrac{-K_a + \\sqrt{K_a^2 + 4K_ac}}{2c} = ${(ex * 100).toFixed(2)}\\%`) +
        TXB(`[\\ce{H+}] = ${sci(h, 2)}\\ \\mathrm{M},\\quad \\mathrm{pH} = ${(-Math.log10(h)).toFixed(2)}`) +
        `<div class="small">${ap > 0.05 ? '<b>α > ৫%</b> — আসন্ন সূত্রে ত্রুটি উল্লেখযোগ্য, দ্বিঘাত সমাধান ব্যবহার করো। ' : 'α < ৫% — আসন্ন সূত্র গ্রহণযোগ্য। '}লঘু করলে α বাড়ে কিন্তু pH ও বাড়ে (কম অম্লীয়); ধূসর ড্যাশ রেখা = একই ঘনমাত্রার তীব্র এসিডের pH।</div>`;
    };
    const A = X.anim(el, dt => { if (dt) step(dt); draw(); }, { paused: false });
    sel.onchange = () => { ai = +sel.value; info(); };
    q('[data-c]').oninput = e => { lc = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.১০.৩ Ka: দুর্বল এসিডের pH ও বহুক্ষারকীয় এসিডের প্রজাতি বণ্টন ======================= */
const POLY = {
  h3po4: { nm: 'H₃PO₄', K: [7.5e-3, 6.2e-8, 4.8e-13], sp: ['H₃PO₄', 'H₂PO₄⁻', 'HPO₄²⁻', 'PO₄³⁻'] },
  h2co3: { nm: 'H₂CO₃', K: [4.3e-7, 4.8e-11], sp: ['H₂CO₃', 'HCO₃⁻', 'CO₃²⁻'] },
  ac: { nm: 'CH₃COOH', K: [1.8e-5], sp: ['CH₃COOH', 'CH₃COO⁻'] }
};
const fracs = (K, h) => { const t = [1]; for (let i = 0; i < K.length; i++) t.push(t[i] * K[i] / h); const s = t.reduce((a, b) => a + b, 0); return t.map(v => v / s); };
V.c4_kaCalc = {
  t: 'Ka এর প্রয়োগ: দুর্বল এসিডের pH (আসন্ন বনাম পূর্ণ সমাধান) ও বহুক্ষারকীয় এসিডের প্রজাতি বণ্টন লেখচিত্র', k: ['int', '2d', 'calc'],
  cap: '"pH হিসাব" এ একটি এসিড ও ঘনমাত্রা বেছে নাও: আসন্ন সূত্র, পূর্ণ সমাধান (পানির H⁺ সহ) এবং লগ স্কেলে [HA], [A⁻], [H⁺], [OH⁻] এর দণ্ড। pK_a ছোট এসিডে [A⁻] বড়। "প্রজাতি বণ্টন" এ H₃PO₄, H₂CO₃ বা CH₃COOH এর প্রতিটি রূপের ভগ্নাংশ pH এর বিপরীতে — দুটি রেখা যেখানে কাটে সেখানে pH = pK_a (সমান পরিমাণ)। pH স্লাইডারে দেখো কোন pH এ কোন রূপ প্রধান: রক্তের pH ৭.৪ এ ফসফেট প্রধানত H₂PO₄⁻/HPO₄²⁻ এবং কার্বনেট প্রধানত HCO₃⁻।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['ph', 'pH হিসাব'], ['dist', 'প্রজাতি বণ্টন']], 'ph')}</div><div data-p1><label class="small">এসিড: <select data-a>${ACIDS.map((a, i) => `<option value="${i}" ${i === 4 ? 'selected' : ''}>${a[0]}</option>`).join('')}</select></label> <label class="small" style="display:block">ঘনমাত্রা log c = <b data-cv></b><input type="range" min="-5" max="0" step="0.05" value="-1" data-c></label></div><div data-p2 style="display:none">${X.seg('pa', [['h3po4', 'H₃PO₄'], ['h2co3', 'H₂CO₃'], ['ac', 'CH₃COOH']], 'h3po4')}<label class="small" style="display:block">pH = <b data-phv></b><input type="range" min="0" max="14" step="0.05" value="7.4" data-ph></label></div>${X.cv('দুর্বল এসিডের pH ও প্রজাতি বণ্টন')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 280 : 300;
    let L = X.fit(c, hf), mode = 'ph', ai = 4, lc = -1, pk = 'h3po4', pH = 7.4;
    const cols = ['#c0392b', '#d06a1e', '#2e9d4e', '#2d6fd6'];
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      if (mode === 'ph') {
        const K = ACIDS[ai][1], cc = Math.pow(10, lc), h = hWeak(K, cc), A_ = cc * K / (K + h), HA = cc - A_, OH = 1e-14 / h;
        const items = [['[HA]', HA, '#5b2a86'], ['[A⁻]', A_, '#a46cd6'], ['[H⁺]', h, '#f2b705'], ['[OH⁻]', OH, '#2d6fd6']];
        const P = cplot(g, { x0: 52, y0: 14, w: W - 72, h: H - 52, xmax: 4, ymin: -14, ymax: 0, col, yt: [-14, -12, -10, -8, -6, -4, -2, 0], fy: v => `১০${X.sup(v)}`, yl: 'ঘনমাত্রা (mol L⁻¹, লগ স্কেল)', ylx: 40 });
        items.forEach(([nm, v, cc2], i) => { const x = 52 + (W - 72) * (i + 0.5) / 4, w = Math.min(60, (W - 72) / 4 * 0.5), lv = Math.max(-14, Math.log10(Math.max(v, 1e-16))); g.fillStyle = cc2; g.fillRect(x - w / 2, P.Y(lv), w, P.Y(-14) - P.Y(lv)); g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x, H - 22); g.font = `10px ${col.font}`; g.fillText(sciTxt(v), x, P.Y(lv) - 4); });
      } else {
        const S = POLY[pk], P = cplot(g, { x0: 52, y0: 14, w: W - 72, h: H - 52, xmin: 0, xmax: 14, ymax: 1, col, xt: [0, 2, 4, 6, 7.4, 8, 10, 12, 14].filter(v => v !== 7.4), yt: [0, 0.5, 1], fy: v => fx(v, 1), xl: 'pH', yl: 'ভগ্নাংশ α', ylx: 36 });
        g.fillStyle = 'rgba(192,57,43,.08)'; g.fillRect(P.X(7.35), 14, P.X(7.45) - P.X(7.35), H - 52); g.fillStyle = '#c0392b'; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText('রক্ত', P.X(7.4), 24);
        S.sp.forEach((nm, i) => { const pts = []; for (let p = 0; p <= 14; p += 0.05) pts.push([P.X(p), P.Y(fracs(S.K, Math.pow(10, -p))[i])]); path(g, pts, cols[i], 2.6); const pkv = i < S.K.length ? -Math.log10(S.K[i]) : 14; const lx = i === 0 ? Math.max(0.6, -Math.log10(S.K[0]) - 1.2) : i === S.sp.length - 1 ? Math.min(13.4, -Math.log10(S.K[i - 1]) + 1.2) : (-Math.log10(S.K[i - 1]) - Math.log10(S.K[i])) / 2; const fy0 = fracs(S.K, Math.pow(10, -lx))[i]; g.fillStyle = cols[i]; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, P.X(lx), P.Y(fy0) + (fy0 > 0.85 ? 16 : -8)); });
        S.K.forEach(k => { const p = -Math.log10(k); g.strokeStyle = col.mu; g.setLineDash([2, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(P.X(p), P.Y(0.5)); g.lineTo(P.X(p), 14 + H - 52); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(`pK_a = ${fx(p, 2)}`, P.X(p), P.Y(0.5) - 6); });
        g.strokeStyle = col.acc; g.lineWidth = 1.6; g.beginPath(); g.moveTo(P.X(pH), 14); g.lineTo(P.X(pH), 14 + H - 52); g.stroke();
        fracs(S.K, Math.pow(10, -pH)).forEach((f, i) => ball(g, P.X(pH), P.Y(f), 4.5, cols[i], '#fff'));
      }
    };
    const info = () => {
      q('[data-p1]').style.display = mode === 'ph' ? '' : 'none'; q('[data-p2]').style.display = mode === 'dist' ? '' : 'none';
      if (mode === 'ph') {
        const [nm, K] = ACIDS[ai], cc = Math.pow(10, lc), ha = Math.sqrt(K * cc), h = hWeak(K, cc);
        q('[data-cv]').textContent = fx(lc, 2);
        out.innerHTML = TXB(`K_a(\\text{${nm}}) = ${sci(K, 1)},\\ \\mathrm{p}K_a = ${(-Math.log10(K)).toFixed(2)},\\ c = ${sci(cc, 2)}\\ \\mathrm{M}`) + TXB(`\\text{আসন্ন}: \\mathrm{pH} = \\tfrac{1}{2}(\\mathrm{p}K_a - \\log c) = ${(-Math.log10(ha)).toFixed(2)}`) + TXB(`\\text{পূর্ণ (পানিসহ)}: \\mathrm{pH} = ${(-Math.log10(h)).toFixed(2)},\\quad \\alpha = ${(100 * K / (K + h)).toFixed(2)}\\%`) +
          `<div class="small">${Math.abs(Math.log10(ha / h)) > 0.02 ? 'আসন্ন ও পূর্ণ সমাধানে পার্থক্য উল্লেখযোগ্য — খুব লঘু দ্রবণ বা বড় K_a এ দ্বিঘাত সমাধান (বা পানির H⁺) বিবেচনা জরুরি।' : 'আসন্ন সূত্র এখানে নির্ভুল।'}</div>`;
      } else {
        const S = POLY[pk], f = fracs(S.K, Math.pow(10, -pH)); q('[data-phv]').textContent = fx(pH, 2);
        out.innerHTML = TXB(S.K.map((k, i) => `K_{a${i + 1}} = ${sci(k, 1)}`).join(',\\ ')) + `<div class="small">pH ${fx(pH, 2)} এ: ${S.sp.map((nm, i) => `${nm} ${fx(f[i] * 100, 1)}%`).join(', ')}। দুটি সংলগ্ন রূপ সমান হয় যখন pH = pK_a — এটিই বাফারের সবচেয়ে কার্যকর বিন্দু (৪.১৩)।</div>`;
      }
    };
    X.onSeg(el, 'm', v => { mode = v; info(); draw(); });
    X.onSeg(el, 'pa', v => { pk = v; info(); draw(); });
    q('[data-a]').onchange = e => { ai = +e.target.value; info(); draw(); };
    q('[data-c]').oninput = e => { lc = +e.target.value; info(); draw(); };
    q('[data-ph]').oninput = e => { pH = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৪.১০.৪ Kb: ক্ষারকের প্রোটন গ্রহণ (৩D) ও ক্ষারকত্বের তুলনা ======================= */
const BASES = [['(CH₃)₂NH', 5.4e-4], ['CH₃NH₂', 4.4e-4], ['(CH₃)₃N', 6.4e-5], ['NH₃', 1.8e-5], ['C₅H₅N', 1.7e-9], ['C₆H₅NH₂', 4.3e-10]];
V.c4_kbBase = {
  t: 'দুর্বল ক্ষারকের বিয়োজন: পানি থেকে প্রোটন গ্রহণের ৩D অ্যানিমেশন, নিঃসঙ্গ জোড়ের প্রাপ্যতা ও Kb তুলনা', k: ['anim', 'int', '3d', 'calc'],
  cap: 'উপরে ৩D মডেলে (টেনে ঘোরাও) ক্ষারকের N পরমাণুর নিঃসঙ্গ ইলেকট্রন জোড় (গোলাপি মেঘ) পানির একটি H⁺ টেনে নেয় — তৈরি হয় BH⁺ (+) ও OH⁻ (−)। NH₃, CH₃NH₂ ও অ্যানিলিন বেছে তুলনা করো: মিথাইলের +I প্রভাবে মেঘ ঘন — প্রোটন স্থানান্তর সম্পূর্ণ ও ঘন ঘন; অ্যানিলিনে নিঃসঙ্গ জোড় বেনজিন বলয়ে ছড়িয়ে পড়ে (অনুরণন) — মেঘ পাতলা, প্রোটন প্রায়ই ফিরে যায় (সাম্য বামে)। নিচে ছয়টি ক্ষারকের pK_b দণ্ড এবং নির্বাচিত ঘনমাত্রায় pH।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('b', [['nh3', 'NH₃'], ['me', 'CH₃NH₂'], ['an', 'C₆H₅NH₂ (অ্যানিলিন)']], 'nh3')}</div>${X.cv('ক্ষারকের প্রোটন গ্রহণের ৩D মডেল ও pKb তুলনা')}<label class="small" style="display:block;margin-top:8px">ঘনমাত্রা log c = <b data-cv></b><input type="range" min="-3" max="0" step="0.05" value="-1" data-c></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 420 : 470;
    let L = X.fit(c, hf), b = 'nh3', lc = -1, t = 0;
    const view = { yaw: -0.35, pitch: 0.28, scale: 1.4, dx: 0, dy: 6 };
    C4.drag3d(c, view, () => A.draw());
    const BI = { nh3: 3, me: 1, an: 5 };
    const dirs = [0, 1, 2].map(k => { const th = k * 2.094; return [-0.33, 0.943 * Math.cos(th), 0.943 * Math.sin(th)]; });
    const add = (p, v, s) => [p[0] + v[0] * s, p[1] + v[1] * s, p[2] + v[2] * s];
    const scene = u => {
      const atoms = [{ el: 'N', p: [0, 0, 0] }], bonds = [], clouds = [];
      const amp = b === 'an' ? 0.45 : 1;
      dirs.forEach((d, k) => {
        if (k === 0 && b === 'me') { const C = add([0, 0, 0], d, 1.47); atoms.push({ el: 'C', p: C }); bonds.push([0, atoms.length - 1, 1]); const ci = atoms.length - 1; [[0.3, 0.9, 0.3], [-0.6, 0.5, -0.6], [-0.3, 0.6, 0.8]].forEach(v => { const n = Math.hypot(...v); atoms.push({ el: 'H', p: add(C, v.map(z => z / n), 1.09) }); bonds.push([ci, atoms.length - 1, 1]); }); }
        else if (k === 0 && b === 'an') { const C1 = add([0, 0, 0], d, 1.4), cen = add(C1, d, 1.4), e = [0.943, 0.33, 0]; const ids = []; for (let j = 0; j < 6; j++) { const a = Math.PI + j * Math.PI / 3, p = [cen[0] + 1.4 * (Math.cos(a) * d[0] + Math.sin(a) * e[0]), cen[1] + 1.4 * (Math.cos(a) * d[1] + Math.sin(a) * e[1]), cen[2] + 1.4 * (Math.cos(a) * d[2] + Math.sin(a) * e[2])]; atoms.push({ el: 'C', p }); ids.push(atoms.length - 1); if (j) { const o = [p[0] - cen[0], p[1] - cen[1], p[2] - cen[2]], n = Math.hypot(...o); atoms.push({ el: 'H', p: add(p, o.map(z => z / n), 1.08) }); bonds.push([atoms.length - 2, atoms.length - 1, 1]); } } bonds.push([0, ids[0], 1]); for (let j = 0; j < 6; j++) bonds.push([ids[j], ids[(j + 1) % 6], j % 2 ? 1 : 2]); clouds.push({ p: cen, r: 1.9, color: 'rgba(236,72,153,A)', a: 0.16 }); }
        else { atoms.push({ el: 'H', p: add([0, 0, 0], d, 1.01) }); bonds.push([0, atoms.length - 1, 1]); }
      });
      // water + proton transfer
      const ph = u < 0.3 ? 0 : u < 0.6 ? (u - 0.3) / 0.3 : u < 0.85 ? 1 : 1 - (u - 0.85) / 0.15 * (b === 'an' ? 1 : 0);
      const tr = Math.min(1, ph) * amp, sep = u < 0.6 ? 0 : u < 0.85 ? (u - 0.6) / 0.25 : 1 - (u - 0.85) / 0.15;
      const ox = 2.75 + (b === 'an' ? 0 : sep * 1.2) * (tr > 0.9 ? 1 : 0.3), O = [ox, 0, 0];
      const Hp = [lerp(ox - 0.96, 1.02, C4.ease(tr)), 0, 0];
      atoms.push({ el: 'O', p: O }); const oi = atoms.length - 1; atoms.push({ el: 'H', p: add(O, [0.25, 0.93, 0], 0.96) }); bonds.push([oi, atoms.length - 1, 1]);
      atoms.push({ el: 'H', p: Hp }); const hi = atoms.length - 1;
      bonds.push([oi, hi, tr < 0.5 ? 1 : 'p', 1 - tr * 0.6]); bonds.push([0, hi, tr > 0.5 ? 1 : 'p', 0.3 + tr * 0.7]);
      clouds.push({ p: [0.6 + tr * 0.3, 0, 0], r: 0.75 * (1 - tr * 0.7), color: 'rgba(236,72,153,A)', a: b === 'an' ? 0.28 : b === 'me' ? 0.62 : 0.5 });
      return { s: { atoms, bonds, clouds }, tr, O };
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const top = wide(W) ? 230 : 250; g.save(); g.beginPath(); g.rect(0, 0, W, top); g.clip();
      view.dx = -W * 0.06; view.dy = b === 'an' ? top * 0.3 : b === 'me' ? top * 0.12 : 0; view.scale = (b === 'an' ? 0.85 : 1.35) * (wide(W) ? 1 : 0.8);
      const u = (t % 4) / 4, S = scene(u), P = C4.r3d(g, W, top, S.s, view);
      if (S.tr > 0.9) { const pn = P([0, 0, 0]), po = P(S.O); g.font = `bold 16px ${col.font}`; g.textAlign = 'center'; g.fillStyle = '#2d6fd6'; g.fillText('+', pn[0] - 18, pn[1] - 18); g.fillStyle = '#c0392b'; g.fillText('−', po[0] + 18, po[1] - 16); }
      g.restore();
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('টেনে ঘোরাও · গোলাপি মেঘ = N এর নিঃসঙ্গ জোড়', 10, 14);
      // pKb bars
      const by = top + 16, bh = H - by - 10, P2 = cplot(g, { x0: 120, y0: by, w: W - 150, h: bh - 18, xmin: 0, xmax: 10, ymax: BASES.length, col, xt: [0, 2, 4, 6, 8, 10], xl: 'pK_b (ছোট = তীব্র ক্ষারক)' });
      const rh = (bh - 18) / BASES.length;
      BASES.forEach(([nm, K], i) => { const y = by + i * rh + rh * 0.18, pk = -Math.log10(K), sel = i === BI[b]; g.fillStyle = sel ? '#7b3fa0' : 'rgba(123,63,160,.35)'; g.fillRect(120, y, P2.X(pk) - 120, rh * 0.64); g.fillStyle = col.fg; g.font = `${sel ? 'bold ' : ''}10.5px ${col.font}`; g.textAlign = 'right'; g.fillText(nm, 114, y + rh * 0.45); g.textAlign = 'left'; g.fillText(fx(pk, 2), P2.X(pk) + 4, y + rh * 0.45); });
    };
    const info = () => {
      const [nm, K] = BASES[BI[b]], cc = Math.pow(10, lc), oh = (-K + Math.sqrt(K * K + 4 * K * cc)) / 2, poh = -Math.log10(oh);
      q('[data-cv]').textContent = fx(lc, 2);
      const eq = { nh3: '\\ce{NH3 + H2O <=> NH4+ + OH-}', me: '\\ce{CH3NH2 + H2O <=> CH3NH3+ + OH-}', an: '\\ce{C6H5NH2 + H2O <=> C6H5NH3+ + OH-}' }[b];
      out.innerHTML = TXB(eq) + TXB(`K_b = ${sci(K, 1)},\\ \\mathrm{p}K_b = ${(-Math.log10(K)).toFixed(2)},\\ c = ${sci(cc, 2)}\\ \\mathrm{M}`) + TXB(`[\\ce{OH-}] = ${sci(oh, 2)}\\ \\mathrm{M},\\ \\mathrm{pOH} = ${poh.toFixed(2)},\\ \\mathrm{pH} = ${(14 - poh).toFixed(2)},\\ \\alpha = ${(100 * oh / cc).toFixed(2)}\\%`) +
        `<div class="small">${{ nh3: 'অ্যামোনিয়া: তিনটি H — কোনো ইলেকট্রন দানকারী বা আকর্ষী মূলক নেই; মাঝারি দুর্বল ক্ষারক।', me: 'মিথাইলঅ্যামিন: CH₃ এর +I প্রভাব N এ ইলেকট্রন ঘনত্ব বাড়ায় — নিঃসঙ্গ জোড় বেশি প্রাপ্য, K_b প্রায় ২৪ গুণ বড়।', an: 'অ্যানিলিন: নিঃসঙ্গ জোড় বেনজিন বলয়ের π ব্যবস্থায় অনুরণনে বিস্তৃত — প্রোটন গ্রহণে অনিচ্ছুক, K_b NH₃ এর প্রায় ৪০,০০০ ভাগের এক ভাগ।' }[b]}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (!view.user) view.yaw = -0.35 + Math.sin(t * 0.25) * 0.35; } draw(); }, { paused: false });
    X.onSeg(el, 'b', v => { b = v; t = 0; info(); });
    q('[data-c]').oninput = e => { lc = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
