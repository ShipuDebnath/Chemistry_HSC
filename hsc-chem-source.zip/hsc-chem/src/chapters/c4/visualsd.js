/* Chapter 4 visuals part 13 — carbonate buffer lab (4.14), blood pH (4.15), concept map & predictor quiz (summary) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, TX = C4.tx, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
const UI = [[0, [190, 20, 30]], [2, [230, 70, 40]], [3.5, [245, 140, 40]], [5, [240, 215, 50]], [6.5, [150, 200, 60]], [7.5, [50, 160, 70]], [9, [30, 140, 160]], [11, [40, 80, 200]], [14, [100, 40, 150]]];
const uiCol = (p, a = 1) => { p = Math.max(0, Math.min(14, p)); let i = 0; while (i < UI.length - 2 && p > UI[i + 1][0]) i++; const [p0, c0] = UI[i], [p1, c1] = UI[i + 1], f = (p - p0) / (p1 - p0); return `rgba(${c0.map((v, k) => Math.round(v + (c1[k] - v) * f)).join(',')},${a})`; };
const rr = (g, x, y, w, h, r) => { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); };

/* ======================= ৪.১৪ ভার্চুয়াল ব্যবহারিক: কার্বনেট বাফার ======================= */
const LABSTEPS = [
  ['নিক্তিতে 0.84 g NaHCO₃ ওজন করো', 'w1'], ['নিক্তিতে 1.06 g Na₂CO₃ ওজন করো', 'w2'], ['বিকারে দ্রবীভূত করে ১০০ mL আয়তনমিতিক ফ্লাস্কে দাগ পর্যন্ত পূরণ করো', 'fl'],
  ['A, B তে ২৫ mL পাতিত পানি; C, D তে ২৫ mL বাফার নাও', 'bk'], ['সার্বজনীন নির্দেশক দিয়ে প্রাথমিক pH মাপো', 'p0'], ['A ও C তে ১ mL 0.1 M HCl; B ও D তে ১ mL 0.1 M NaOH যোগ করো', 'add'], ['চূড়ান্ত pH মেপে সারণি পূরণ করো ও সিদ্ধান্ত নাও', 'p1']
];
V.c4_bufferLab = {
  t: 'ভার্চুয়াল ব্যবহারিক: কার্বনেট বাফার তৈরি (নিক্তি, আয়তনমিতিক ফ্লাস্ক) ও পানির সাথে তুলনায় কার্যকারিতা প্রমাণ', k: ['anim', 'int', '2d', 'calc'],
  cap: 'পরীক্ষাটি সাত ধাপে: "পরের ধাপ" চাপলে নিক্তিতে NaHCO₃ ও Na₂CO₃ ওজন হয় (ডিজিটাল পাঠ), দ্রবণ আয়তনমিতিক ফ্লাস্কে দাগ পর্যন্ত পূরণ হয়, চারটি বিকারে পানি ও বাফার নেওয়া হয়, সার্বজনীন নির্দেশকে প্রাথমিক রং ও pH মিটারের পাঠ আসে, তারপর ১ mL করে HCl/NaOH ফোঁটায় ফোঁটায় পড়ে। পানির বিকারগুলোর রং নাটকীয়ভাবে বদলায় (লাল/বেগুনি), বাফারের প্রায় একই থাকে। নিচের পর্যবেক্ষণ সারণি ধাপে ধাপে পূরণ হয়। অতিরিক্ত HCl যোগ করে বাফারের সীমাও পরীক্ষা করো।',
  html: () => `${X.cv('কার্বনেট বাফারের ভার্চুয়াল ব্যবহারিক')}<div class="ctl"><button class="btn sm" data-prev>← আগের ধাপ</button><button class="btn sm primary" data-next>পরের ধাপ →</button><button class="btn sm" data-more>C তে আরও ৫ mL HCl</button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div data-tbl style="overflow-x:auto"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), tbl = q('[data-tbl]');
    const hf = w => wide(w) ? 300 : 360;
    let L = X.fit(c, hf), st = 0, t = 0, tStep = 0, extra = 0;
    const pKa = 10.32;
    const phB = (nAdd) => { const x = -nAdd; if (x < 0) { const y = -x; return y < 2.49 ? pKa + Math.log10((2.5 + y) / (2.5 - y)) : 12; } if (x < 2.49) return pKa + Math.log10((2.5 - x) / (2.5 + x)); const h2 = x - 2.5, hc = 5 - h2; return Math.min(8.35, 6.37 + Math.log10(hc / Math.max(h2, 1e-3))); };
    const phW = (nAdd, V) => { const c = Math.abs(nAdd) / V, h = (c + Math.sqrt(c * c + 4e-14)) / 2; return nAdd < 0 ? -Math.log10(h) : 14 + Math.log10(h); };
    const vals = () => { const add = st >= 5 ? 1 : 0, f = st >= 5 ? Math.min(1, (t - tStep) / 2) : 0; return { A: st >= 5 ? phW(-0.1 * f, 25 + f) : 7, B: st >= 5 ? phW(0.1 * f, 25 + f) : 7, C: st >= 5 ? phB(-0.1 * f - extra * 0.5) : pKa, D: st >= 5 ? phB(0.1 * f) : pKa, add }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const e = Math.min(1, (t - tStep) / 1.5);
      // step banner
      g.fillStyle = col.acc; rr(g, 10, 8, W - 20, 24, 6); g.fill(); g.fillStyle = '#fff'; g.font = `bold 11px ${col.font}`; g.textAlign = 'left'; g.fillText(`ধাপ ${bn(st + 1)}/${bn(LABSTEPS.length)}: ${LABSTEPS[st][0]}`, 18, 24);
      const kind = LABSTEPS[st][1], top = 46;
      if (kind === 'w1' || kind === 'w2') {
        const bx = W / 2 - 90, by = top + 120; g.fillStyle = col.s3; rr(g, bx, by, 180, 50, 8); g.fill(); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.stroke();
        g.fillStyle = '#103020'; g.fillRect(bx + 50, by + 14, 80, 24); g.fillStyle = '#6dff9e'; g.font = `bold 15px ${col.mono}`; g.textAlign = 'center'; g.fillText(`${(e * (kind === 'w1' ? 0.84 : 1.06)).toFixed(2)} g`, bx + 90, by + 32);
        g.fillStyle = col.s2; g.fillRect(bx + 40, by - 8, 100, 8); g.strokeRect(bx + 40, by - 8, 100, 8);
        g.fillStyle = '#f4f4f0'; g.beginPath(); g.ellipse(W / 2, by - 12, 28 * e + 2, 10 * e + 1, 0, Math.PI, 0); g.fill(); g.strokeStyle = '#aaa'; g.stroke();
        // spatula + jar
        g.fillStyle = col.s2; rr(g, W / 2 + 120, by - 50, 46, 60, 6); g.fill(); g.strokeStyle = col.fg; g.stroke(); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.fillText(kind === 'w1' ? 'NaHCO₃' : 'Na₂CO₃', W / 2 + 143, by - 16);
        g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.fillText(kind === 'w1' ? 'm = 0.10 × 0.100 × 84 = 0.84 g' : 'm = 0.10 × 0.100 × 106 = 1.06 g', W / 2, by + 70);
      } else if (kind === 'fl') {
        const fx0 = W / 2 - 40, fy = top + 20; const fill = e; g.save(); g.beginPath(); g.moveTo(fx0 + 32, fy); g.lineTo(fx0 + 32, fy + 70); g.bezierCurveTo(fx0 - 30, fy + 90, fx0 - 30, fy + 190, fx0 + 40, fy + 190); g.bezierCurveTo(fx0 + 110, fy + 190, fx0 + 110, fy + 90, fx0 + 48, fy + 70); g.lineTo(fx0 + 48, fy); g.closePath(); g.clip(); g.fillStyle = 'rgba(160,200,235,.5)'; const ly = fy + 190 - fill * 160; g.fillRect(fx0 - 40, ly, 160, 200); g.restore();
        g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(fx0 + 32, fy); g.lineTo(fx0 + 32, fy + 70); g.bezierCurveTo(fx0 - 30, fy + 90, fx0 - 30, fy + 190, fx0 + 40, fy + 190); g.bezierCurveTo(fx0 + 110, fy + 190, fx0 + 110, fy + 90, fx0 + 48, fy + 70); g.lineTo(fx0 + 48, fy); g.stroke();
        g.strokeStyle = '#c0392b'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(fx0 + 30, fy + 30); g.lineTo(fx0 + 50, fy + 30); g.stroke(); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('দাগ (১০০ mL)', fx0 + 56, fy + 34);
        g.fillText('[HCO₃⁻] = [CO₃²⁻] = ০.১০ M', fx0 + 110, fy + 120); g.fillText('pH = pKa₂ = ১০.৩২', fx0 + 110, fy + 136);
      } else {
        const v = vals(), names = ['A: পানি', 'B: পানি', 'C: বাফার', 'D: বাফার'], ph = [v.A, v.B, v.C, v.D], showCol = st >= 4, bw = Math.min(90, (W - 60) / 4 - 14);
        names.forEach((nm, k) => {
          const x = 20 + k * (W - 40) / 4 + ((W - 40) / 4 - bw) / 2, y = top + 70, h = 120;
          g.fillStyle = showCol ? uiCol(ph[k], 0.8) : (k < 2 ? 'rgba(170,205,235,.4)' : 'rgba(170,205,235,.55)'); g.fillRect(x, y + 30, bw, h - 30); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x - 3, y + 6); g.lineTo(x, y + 9); g.lineTo(x, y + h); g.lineTo(x + bw, y + h); g.lineTo(x + bw, y + 9); g.lineTo(x + bw + 3, y + 6); g.stroke();
          g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, x + bw / 2, y + h + 15);
          if (st >= 4) { g.fillStyle = '#103020'; g.fillRect(x + bw / 2 - 26, y - 22, 52, 20); g.fillStyle = '#6dff9e'; g.font = `bold 12px ${col.mono}`; g.fillText(ph[k].toFixed(2), x + bw / 2, y - 7); }
          if (st === 5 && t - tStep < 2) { const add = k % 2 === 0 ? 'HCl' : 'NaOH'; g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.fillText(`+১ mL ${add}`, x + bw / 2, y - 30); const dy = ((t - tStep) * 3) % 1; g.fillStyle = k % 2 === 0 ? '#e0402e' : '#2d6fd6'; g.beginPath(); g.arc(x + bw * 0.3, y - 2 + dy * 40, 3, 0, 7); g.fill(); }
        });
      }
    };
    const table = () => {
      const v = vals(), row = (b, s, a, p0, p1) => `<tr><td>${b}</td><td>${s}</td><td>${a}</td><td>${st >= 4 ? fx(p0, 2) : '—'}</td><td>${st >= 6 ? fx(p1, 2) : '—'}</td><td>${st >= 6 ? (p1 - p0 >= 0 ? '+' : '−') + fx(Math.abs(p1 - p0), 2) : '—'}</td></tr>`;
      tbl.innerHTML = `<table class="t" style="margin:8px 0;min-width:420px"><thead><tr><th>বিকার</th><th>দ্রবণ</th><th>যোগ</th><th>প্রাথমিক pH</th><th>চূড়ান্ত pH</th><th>ΔpH</th></tr></thead><tbody>${row('A', 'পানি', '১ mL HCl', 7, v.A)}${row('B', 'পানি', '১ mL NaOH', 7, v.B)}${row('C', 'বাফার', `${bn(1 + extra * 5)} mL HCl`, 10.32, v.C)}${row('D', 'বাফার', '১ mL NaOH', 10.32, v.D)}</tbody></table>`;
    };
    const info = () => {
      const v = vals();
      out.innerHTML = st < 3 ? TXB(`m = C\\times V\\times M:\\quad m(\\ce{NaHCO3}) = 0.84\\ \\mathrm{g},\\quad m(\\ce{Na2CO3}) = 1.06\\ \\mathrm{g}`) :
        TXB(`\\mathrm{pH}_{\\text{বাফার}} = 10.32 + \\log\\dfrac{[\\ce{CO3^2-}]}{[\\ce{HCO3-}]}`) + (st >= 5 ? TXB(`\\ce{CO3^2- + H+ -> HCO3-}\\qquad \\ce{HCO3- + OH- -> CO3^2- + H2O}`) : '') +
          `<div class="small">${st >= 6 ? (extra ? `C তে মোট ${bn(1 + extra * 5)} mL HCl (${fx(0.1 + extra * 0.5, 1)} mmol) — CO₃²⁻ মজুত ২.৫ mmol; ${v.C < 9.3 ? 'মজুত প্রায় শেষ, বাফার কার্যকর পরিসরের বাইরে — pH দ্রুত নামছে।' : 'বাফার এখনো কাজ করছে।'}` : `<b>সিদ্ধান্ত:</b> পানির ΔpH ≈ ${fx(Math.abs(v.A - 7), 1)}, বাফারের মাত্র ≈ ${fx(Math.abs(v.C - 10.32), 2)} — প্রস্তুত দ্রবণটি কার্যকর বাফার।`) : 'ধাপে ধাপে এগোও।'}</div>`;
      q('[data-more]').disabled = st < 6;
      table();
    };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); if (dt && st >= 5 && t - tStep < 2.2) info(); }, { paused: false });
    q('[data-next]').onclick = () => { if (st < LABSTEPS.length - 1) { st++; tStep = t; if (st === 6) tStep = t - 2; info(); } };
    q('[data-prev]').onclick = () => { if (st > 0) { st--; tStep = t - 2; extra = 0; info(); } };
    q('[data-more]').onclick = () => { if (st >= 6 && extra < 5) { extra++; info(); } };
    q('[data-rs]').onclick = () => { st = 0; tStep = t; extra = 0; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.১৫ রক্তের pH: ডেভেনপোর্ট চিত্র ======================= */
const SCEN = [
  ['স্বাভাবিক', 24, 40, ''],
  ['হাঁপানি (শ্বাসরোধ)', 25, 64, 'শ্বাসজনিত অ্যাসিডোসিস: CO₂ জমে সাম্য ডানে — [H⁺] বাড়ে। বৃক্ক দিনে দিনে HCO₃⁻ ধরে রেখে ক্ষতিপূরণ করে।'],
  ['হাইপারভেন্টিলেশন', 22, 25, 'শ্বাসজনিত অ্যালকালোসিস: CO₂ বেশি বের হয়ে সাম্য বামে — [H⁺] কমে। কাগজের ব্যাগে শ্বাস নিলে CO₂ ফিরে আসে।'],
  ['কিটোঅ্যাসিডোসিস', 10, 40, 'বিপাকজনিত অ্যাসিডোসিস: কিটো এসিড HCO₃⁻ খরচ করে। দ্রুত গভীর শ্বাসে CO₂ কমিয়ে ফুসফুস ক্ষতিপূরণ করে।'],
  ['দীর্ঘ বমি', 38, 40, 'বিপাকজনিত অ্যালকালোসিস: পাকস্থলীর HCl হারিয়ে HCO₃⁻ বাড়ে। শ্বাস ধীর করে CO₂ জমিয়ে আংশিক ক্ষতিপূরণ।']
];
const COMP = { 1: [36, 64], 2: [16, 25], 3: [10, 22], 4: [38, 52] };
V.c4_bloodPh = {
  t: 'রক্তের pH নিয়ন্ত্রণ: বাইকার্বনেট বাফার, ডেভেনপোর্ট চিত্র, অ্যাসিডোসিস/অ্যালকালোসিস ও ফুসফুস-বৃক্কের ক্ষতিপূরণ', k: ['anim', 'int', '2d', 'calc'],
  cap: 'স্লাইডারে রক্তরসের [HCO₃⁻] (বৃক্ক নিয়ন্ত্রিত) ও pCO₂ (ফুসফুস নিয়ন্ত্রিত) বদলাও — হেন্ডারসন সমীকরণে pH নির্ণয় হয়। ডানে ডেভেনপোর্ট চিত্র: x অক্ষে pH, y অক্ষে [HCO₃⁻]; বক্ররেখাগুলো সমান pCO₂ (২০–৮০ mmHg); সবুজ আয়তক্ষেত্র স্বাভাবিক অঞ্চল। পাঁচটি ক্লিনিক্যাল অবস্থা বেছে দেখো বিন্দু কোন অঞ্চলে যায়, তারপর "ক্ষতিপূরণ" চাপলে অ্যানিমেশনে ফুসফুস বা বৃক্ক বিন্দুটিকে স্বাভাবিকের দিকে ফেরায়। বামে দাঁড়িপাল্লায় HCO₃⁻ : H₂CO₃ অনুপাত — স্বাভাবিক ২০ : ১।',
  html: () => `<div class="ctl" style="flex-wrap:wrap;gap:6px;margin:0 0 6px">${SCEN.map((s, i) => `<button class="btn sm" data-sc="${i}">${s[0]}</button>`).join('')}<button class="btn sm primary" data-comp>ক্ষতিপূরণ ▶</button></div>${X.cv('রক্তের pH ও ডেভেনপোর্ট চিত্র')}<div class="grid2" style="margin-top:8px"><label class="small">[HCO₃⁻] = <b data-hv></b> mM<input type="range" min="5" max="45" step="0.5" value="24" data-h></label><label class="small">pCO₂ = <b data-pv></b> mmHg<input type="range" min="15" max="90" step="1" value="40" data-p></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), sH = q('[data-h]'), sP = q('[data-p]');
    const hf = w => wide(w) ? 330 : 520;
    let L = X.fit(c, hf), hc = 24, pc = 40, sc = 0, anim = null, t = 0;
    const pH = (h, p) => 6.1 + Math.log10(h / (0.03 * p));
    const status = p => p < 7.35 ? 'অ্যাসিডোসিস' : p > 7.45 ? 'অ্যালকালোসিস' : 'স্বাভাবিক';
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const p = pH(hc, pc);
      // left: balance + body
      const lw = wide(W) ? W * 0.38 : W - 20, lx = 10, ly = 10, lh = wide(W) ? H - 20 : 190;
      const cx = lx + lw / 2, cy = ly + 80, ratio = hc / (0.03 * pc), tilt = Math.max(-0.35, Math.min(0.35, (Math.log10(ratio) - Math.log10(20)) * 0.6));
      g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx, cy + 70); g.stroke(); g.fillStyle = col.fg; g.beginPath(); g.moveTo(cx - 20, cy + 76); g.lineTo(cx + 20, cy + 76); g.lineTo(cx, cy + 66); g.fill();
      const arm = lw * 0.36; g.save(); g.translate(cx, cy); g.rotate(tilt); g.lineWidth = 3; g.beginPath(); g.moveTo(-arm, 0); g.lineTo(arm, 0); g.stroke();
      [[-arm, 'H₂CO₃', 0.03 * pc, '#c0392b'], [arm, 'HCO₃⁻', hc, '#2d6fd6']].forEach(([x, nm, v, cc]) => { g.save(); g.translate(x, 0); g.rotate(-tilt); g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(-18, 30); g.lineTo(0, 0); g.lineTo(18, 30); g.stroke(); g.fillStyle = cc; const r = Math.min(26, 4 + Math.sqrt(v) * 4.2); g.beginPath(); g.arc(0, 30 - r * 0.2 + 8, 0, 0, 0); g.fill(); g.beginPath(); g.ellipse(0, 34, 24, 6, 0, 0, 7); g.fillStyle = col.s3; g.fill(); g.stroke(); g.fillStyle = cc; g.beginPath(); g.arc(0, 32 - r, r, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 9px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, 0, 35 - r); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.fillText(`${fx(v, 2)} mM`, 0, 50); g.restore(); });
      g.restore();
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`অনুপাত = ${fx(ratio, 1)} : ১ (স্বাভাবিক ২০ : ১)`, cx, ly + 14);
      g.font = `bold 15px ${col.font}`; const stc = status(p); g.fillStyle = stc === 'স্বাভাবিক' ? col.ok : col.bad; g.fillText(`pH ${fx(p, 2)} — ${stc}`, cx, ly + 40);
      // organs labels
      g.font = `9.5px ${col.font}`; g.fillStyle = col.mu; g.fillText('ফুসফুস ↔ pCO₂ (মিনিট)', cx - arm * 0.6, cy + 100); g.fillText('বৃক্ক ↔ HCO₃⁻ (দিন)', cx + arm * 0.6, cy + 100);
      // Davenport
      const gx = wide(W) ? lw + 60 : 52, gy = wide(W) ? 16 : lh + 30, gw = wide(W) ? W - gx - 20 : W - 72, gh = wide(W) ? H - 60 : H - gy - 46;
      const P = cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: 6.9, xmax: 7.8, ymin: 0, ymax: 50, col, xt: [7.0, 7.2, 7.4, 7.6, 7.8], yt: [0, 10, 20, 30, 40, 50], fx: v => fx(v, 1), xl: 'pH', yl: '[HCO₃⁻] (mM)', ylx: 34 });
      g.fillStyle = 'rgba(46,157,78,.15)'; g.fillRect(P.X(7.35), P.Y(26), P.X(7.45) - P.X(7.35), P.Y(22) - P.Y(26));
      g.fillStyle = 'rgba(224,64,46,.06)'; g.fillRect(gx, gy, P.X(7.35) - gx, gh); g.fillStyle = 'rgba(45,111,214,.06)'; g.fillRect(P.X(7.45), gy, gx + gw - P.X(7.45), gh);
      g.fillStyle = '#c0392b'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('অ্যাসিডোসিস', gx + 4, gy + 12); g.fillStyle = '#2d6fd6'; g.textAlign = 'right'; g.fillText('অ্যালকালোসিস', gx + gw - 4, gy + 12);
      [20, 40, 60, 80].forEach(pp => { const pts = []; for (let x = 6.9; x <= 7.8; x += 0.01) { const h = 0.03 * pp * Math.pow(10, x - 6.1); if (h <= 50) pts.push([P.X(x), P.Y(h)]); } path(g, pts, pp === 40 ? '#7b3fa0' : 'rgba(123,63,160,.45)', pp === 40 ? 2 : 1.2, pp === 40 ? null : [4, 3]); const lp = pts[pts.length - 1]; if (lp) { g.fillStyle = '#7b3fa0'; g.font = `9px ${col.font}`; g.textAlign = 'right'; g.fillText(`${bn(pp)} mmHg`, lp[0] - 3, lp[1] + 10); } });
      if (anim && anim.trail) path(g, anim.trail.map(([h, p2]) => [P.X(pH(h, p2)), P.Y(h)]), col.acc, 1.6, [3, 3]);
      ball(g, P.X(Math.max(6.9, Math.min(7.8, p))), P.Y(hc), 6.5, '#c0392b', '#ffb3a8');
    };
    const sync = () => { sH.value = hc; sP.value = pc; q('[data-hv]').textContent = fx(hc, 1); q('[data-pv]').textContent = bn(Math.round(pc)); };
    const info = () => {
      const p = pH(hc, pc); sync();
      out.innerHTML = TXB(`\\ce{CO2 + H2O <=> H2CO3 <=> H+ + HCO3-}`) + TXB(`\\mathrm{pH} = 6.1 + \\log\\dfrac{[\\ce{HCO3-}]}{0.03\\times p_{\\ce{CO2}}} = 6.1 + \\log\\dfrac{${hc.toFixed(1)}}{${(0.03 * pc).toFixed(2)}} = ${p.toFixed(2)}`) +
        `<div class="small">${SCEN[sc] && SCEN[sc][3] ? SCEN[sc][3] : 'স্বাভাবিক অবস্থা: [HCO₃⁻] ২৪ mM, pCO₂ ৪০ mmHg, অনুপাত ২০ : ১, pH ৭.৪০।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (anim) { anim.u = Math.min(1, anim.u + dt * 0.35); const e = C4.ease(anim.u); hc = anim.h0 + (anim.h1 - anim.h0) * e; pc = anim.p0 + (anim.p1 - anim.p0) * e; anim.trail.push([hc, pc]); info(); if (anim.u >= 1) anim.done = true; } } draw(); }, { paused: false });
    el.querySelectorAll('[data-sc]').forEach(b => b.onclick = () => { sc = +b.dataset.sc; anim = null; hc = SCEN[sc][1]; pc = SCEN[sc][2]; info(); });
    q('[data-comp]').onclick = () => { const tg = COMP[sc]; if (!tg) return; anim = { u: 0, h0: hc, p0: pc, h1: tg[0], p1: tg[1], trail: [[hc, pc]] }; };
    sH.oninput = () => { hc = +sH.value; anim = null; info(); }; sP.oninput = () => { pc = +sP.value; anim = null; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= সারসংক্ষেপ: ধারণা মানচিত্র ======================= */
const NODES = [
  ['rate', 'বিক্রিয়ার হার', 0.14, 0.18, 'r = k[A]^m[B]^n; ক্রম পরীক্ষালব্ধ; প্রথম ক্রমে t½ = 0.693/k', 'c4s3a'],
  ['arr', 'সংঘর্ষ তত্ত্ব ও Ea', 0.14, 0.45, 'k = Ae^(−Ea/RT); কার্যকর সংঘর্ষ = যথেষ্ট শক্তি + সঠিক অভিমুখ', 'c4s3d'],
  ['cat', 'প্রভাবক ও এনজাইম', 0.14, 0.75, 'Ea কমায়; ΔH, K ও সাম্য অপরিবর্তিত; অধিশোষণ ও মধ্যবর্তী যৌগ তত্ত্ব', 'c4s4a'],
  ['rev', 'উভমুখী বিক্রিয়া', 0.40, 0.12, 'বদ্ধ পাত্রে দুই দিকে চলে; কখনো সম্পূর্ণ হয় না', 'c4s2a'],
  ['eq', 'গতিশীল সাম্যাবস্থা', 0.40, 0.40, 'r_f = r_b; K = k_f/k_b; আইসোটোপ প্রমাণ; Q = K', 'c4s5a'],
  ['lc', 'লা-শাতেলিয়ার', 0.40, 0.70, 'পরিবর্তনের প্রভাব প্রশমনের দিকে সরণ; K কেবল T তে বদলায়', 'c4s6a'],
  ['ind', 'শিল্প (হেবার, স্পর্শ)', 0.40, 0.92, 'আপস শর্ত: সাম্য উৎপাদন বনাম হার বনাম খরচ', 'c4s7a'],
  ['k', 'Kc, Kp ও ICE', 0.64, 0.25, 'K_p = K_c(RT)^Δn; ICE; উল্টো 1/K, ×n হলে Kⁿ', 'c4s8b'],
  ['kw', 'Kw ও অসওয়াল্ড', 0.64, 0.55, 'K_w = 10⁻¹⁴; α = √(K/c); [H⁺] = √(K_a c)', 'c4s10a'],
  ['ab', 'Ka, Kb ও অনুবন্ধী জোড়', 0.86, 0.18, 'K_a·K_b = K_w; pK_a + pK_b = 14; ক্ষারকত্ব', 'c4s11b'],
  ['ph', 'pH ও আর্দ্র বিশ্লেষণ', 0.86, 0.45, 'pH = −log[H⁺]; K_h = K_w/K_a; লবণের pH', 'c4s12a'],
  ['buf', 'বাফার', 0.86, 0.70, 'pH = pK_a + log([লবণ]/[এসিড]); পরিসর pK_a ± ১', 'c4s13a'],
  ['blood', 'রক্তের pH', 0.86, 0.92, '৭.৪ = ৬.১ + log ২০; ফুসফুস ও বৃক্ক', 'c4s15a']
];
const EDGES = [['rate', 'arr', 'তাপমাত্রা'], ['arr', 'cat', 'Ea কমানো'], ['rate', 'rev', ''], ['rev', 'eq', 'r_f = r_b'], ['rate', 'eq', 'K = k_f/k_b'], ['eq', 'lc', 'বিঘ্ন'], ['lc', 'ind', 'প্রয়োগ'], ['cat', 'ind', ''], ['eq', 'k', 'ভরক্রিয়া'], ['k', 'kw', 'জলীয় সাম্য'], ['kw', 'ab', ''], ['ab', 'ph', ''], ['ph', 'buf', 'সাধারণ আয়ন'], ['buf', 'blood', ''], ['lc', 'blood', 'CO₂ সাম্য']];
V.c4_conceptMap = {
  t: 'অধ্যায় ৪ এর ধারণা মানচিত্র: হার → সাম্য → লা-শাতেলিয়ার → K → আয়নিক সাম্য → pH → বাফার', k: ['int', '2d'],
  cap: 'অধ্যায়ের ১৩টি মূল ধারণা চারটি স্তম্ভে সাজানো: বাম স্তম্ভ "কত দ্রুত" (হার, Ea, প্রভাবক), মাঝের দুই স্তম্ভ "কতদূর" (সাম্য, লা-শাতেলিয়ার, শিল্প, K), ডান স্তম্ভ জলীয় দ্রবণের আয়নিক সাম্য (Ka/Kb, pH, বাফার, রক্ত)। তীরের লেবেল দেখায় একটি ধারণা থেকে অন্যটিতে কীভাবে যাওয়া যায়। যেকোনো বৃত্তে চাপ দিলে সেটির মূল সূত্র নিচে আসে এবং সংযুক্ত ধারণাগুলো উজ্জ্বল হয়; "পাঠে যাও" দিয়ে সংশ্লিষ্ট পাঠ খোলো।',
  html: () => `${X.cv('অধ্যায় ৪ এর ধারণা মানচিত্র')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    const hf = w => wide(w) ? 400 : 560;
    let L = X.fit(c, hf), sel = 'eq';
    const pos = (n) => { const { W, H } = L; if (wide(W)) return [20 + n[2] * (W - 40), 20 + n[3] * (H - 40)]; const col = n[2] < 0.3 ? 0 : n[2] < 0.5 ? 1 : n[2] < 0.75 ? 2 : 3; const map = [[0.25, 0.08], [0.25, 0.30], [0.25, 0.52]]; void map; const xs = [0.2, 0.42, 0.58, 0.8][col]; return [20 + (col % 2 === 0 ? 0.27 : 0.73) * (W - 40), 20 + ((col < 2 ? 0 : 0.5) + n[3] * 0.48) * (H - 40)]; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      if (wide(W)) { [['কত দ্রুত?', 0.14], ['কতদূর?', 0.40], ['পরিমাণগত সাম্য', 0.64], ['আয়নিক সাম্য', 0.86]].forEach(([nm, x]) => { g.fillStyle = col.mu; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, 20 + x * (W - 40), 12); }); }
      const P = {}; NODES.forEach(n => { P[n[0]] = pos(n); });
      const nb = new Set([sel]); EDGES.forEach(([a, b]) => { if (a === sel) nb.add(b); if (b === sel) nb.add(a); });
      EDGES.forEach(([a, b, lab]) => { const [x1, y1] = P[a], [x2, y2] = P[b], on = a === sel || b === sel; g.strokeStyle = on ? col.acc : (col.line || col.mu); g.lineWidth = on ? 2.4 : 1.2; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); const ang = Math.atan2(y2 - y1, x2 - x1), ex = x2 - Math.cos(ang) * 34, ey = y2 - Math.sin(ang) * 22; g.fillStyle = on ? col.acc : col.mu; g.beginPath(); g.moveTo(ex, ey); g.lineTo(ex - 7 * Math.cos(ang - 0.4), ey - 7 * Math.sin(ang - 0.4)); g.lineTo(ex - 7 * Math.cos(ang + 0.4), ey - 7 * Math.sin(ang + 0.4)); g.fill(); if (lab && on) { g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; const mx = (x1 + x2) / 2, my = (y1 + y2) / 2; g.fillStyle = col.sf; const tw = g.measureText(lab).width; g.fillRect(mx - tw / 2 - 3, my - 9, tw + 6, 13); g.fillStyle = col.acc; g.fillText(lab, mx, my + 1); } });
      NODES.forEach(n => { const [x, y] = P[n[0]], on = nb.has(n[0]), me = n[0] === sel; g.font = `${me ? 'bold ' : ''}10.5px ${col.font}`; const tw = Math.max(70, g.measureText(n[1]).width + 18); g.fillStyle = me ? col.acc : on ? col.s3 : col.s2; g.strokeStyle = me ? col.acc : col.fg; g.lineWidth = me ? 2 : 1; rr(g, x - tw / 2, y - 14, tw, 28, 14); g.fill(); g.stroke(); g.fillStyle = me ? '#fff' : col.fg; g.textAlign = 'center'; g.fillText(n[1], x, y + 4); n.bb = [x - tw / 2, y - 14, tw, 28]; });
    };
    const info = () => { const n = NODES.find(z => z[0] === sel); out.innerHTML = `<div><b>${n[1]}</b>: ${n[4]}</div><div class="ctl" style="margin-top:6px"><button class="btn sm" data-act="lesson" data-id="${n[5]}">পাঠে যাও →</button></div>`; };
    c.addEventListener('click', e => { const r = c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; const n = NODES.find(z => z.bb && x >= z.bb[0] && x <= z.bb[0] + z.bb[2] && y >= z.bb[1] && y <= z.bb[1] + z.bb[3]); if (n) { sel = n[0]; draw(); info(); } });
    c.style.cursor = 'pointer';
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= অনুশীলনী: লা-শাতেলিয়ার পূর্বাভাস চর্চা ======================= */
const QRX = [
  { e: '\\ce{N2(g) + 3H2(g) <=> 2NH3(g)}', dh: -92, dn: -2, R: 'N₂', P: 'NH₃' },
  { e: '\\ce{N2O4(g) <=> 2NO2(g)}', dh: 57, dn: 1, R: 'N₂O₄', P: 'NO₂' },
  { e: '\\ce{H2(g) + I2(g) <=> 2HI(g)}', dh: -9.5, dn: 0, R: 'H₂', P: 'HI' },
  { e: '\\ce{2SO2(g) + O2(g) <=> 2SO3(g)}', dh: -196, dn: -1, R: 'O₂', P: 'SO₃' },
  { e: '\\ce{PCl5(g) <=> PCl3(g) + Cl2(g)}', dh: 88, dn: 1, R: 'PCl₅', P: 'Cl₂' },
  { e: '\\ce{CaCO3(s) <=> CaO(s) + CO2(g)}', dh: 178, dn: 1, R: 'CaCO₃ (কঠিন)', P: 'CO₂', solidR: true },
  { e: '\\ce{N2(g) + O2(g) <=> 2NO(g)}', dh: 180, dn: 0, R: 'O₂', P: 'NO' }
];
const QCH = [['tu', 'তাপমাত্রা বাড়ানো হলো'], ['td', 'তাপমাত্রা কমানো হলো'], ['pu', 'চাপ বাড়ানো হলো (আয়তন কমিয়ে)'], ['pd', 'চাপ কমানো হলো'], ['ar', 'বিক্রিয়ক যোগ করা হলো'], ['rp', 'উৎপাদ সরিয়ে নেওয়া হলো'], ['ca', 'প্রভাবক যোগ করা হলো'], ['in', 'স্থির আয়তনে নিষ্ক্রিয় গ্যাস যোগ']];
const answer = (r, ch) => {
  let d = 0, K = 0, why = '';
  if (ch === 'tu' || ch === 'td') { const up = ch === 'tu'; d = (r.dh > 0) === up ? 1 : -1; K = d; why = `ΔH ${r.dh > 0 ? '> 0 (তাপহারী)' : '< 0 (তাপোৎপাদী)'}; তাপমাত্রা ${up ? 'বাড়লে তাপহারী' : 'কমলে তাপোৎপাদী'} দিকে সরে — ${d > 0 ? 'ডানে' : 'বামে'}; K ${K > 0 ? 'বাড়ে' : 'কমে'}।`; }
  else if (ch === 'pu' || ch === 'pd') { const up = ch === 'pu'; d = r.dn === 0 ? 0 : ((r.dn < 0) === up ? 1 : -1); why = r.dn === 0 ? 'Δn_g = 0 — চাপের প্রভাব নেই।' : `Δn_g = ${r.dn > 0 ? '+' : ''}${r.dn}; চাপ ${up ? 'বাড়লে কম' : 'কমলে বেশি'} গ্যাস মোলের দিকে — ${d > 0 ? 'ডানে' : 'বামে'}। K অপরিবর্তিত।`; }
  else if (ch === 'ar') { d = r.solidR ? 0 : 1; why = r.solidR ? 'বিক্রিয়ক বিশুদ্ধ কঠিন — সক্রিয় ভর ধ্রুব, সাম্য সরে না।' : `${r.R} যোগে Q < K — ডানে। K অপরিবর্তিত।`; }
  else if (ch === 'rp') { d = 1; why = `${r.P} সরালে Q < K — ডানে। K অপরিবর্তিত।`; }
  else if (ch === 'ca') { d = 0; why = 'প্রভাবক দুই দিকের হার সমান গুণে বাড়ায় — সাম্য সরে না, K অপরিবর্তিত।'; }
  else { d = 0; why = 'স্থির আয়তনে আংশিক চাপ অপরিবর্তিত — সাম্য সরে না।'; }
  return { d, K, why };
};
V.c4_eqQuiz = {
  t: 'লা-শাতেলিয়ার পূর্বাভাস চর্চা: এলোমেলো সাম্য ও পরিবর্তন — সাম্যের দিক ও K এর পরিবর্তন অনুমান করো', k: ['int', '2d'],
  cap: 'প্রতিবার একটি সাম্য বিক্রিয়া (ΔH ও দশাসহ) এবং একটি পরিবর্তন দেওয়া হয়। দুটি প্রশ্নের উত্তর বেছে নাও: সাম্য কোন দিকে সরবে এবং K এর কী হবে। উত্তর দিলে দাঁড়িপাল্লা অ্যানিমেশনে সঠিক দিকে হেলে, ব্যাখ্যা আসে এবং স্কোর হালনাগাদ হয়। কঠিন ফাঁদগুলো: Δn = ০, কঠিন বিক্রিয়ক, প্রভাবক ও নিষ্ক্রিয় গ্যাস।',
  html: () => `${X.cv('সাম্যের দাঁড়িপাল্লা', 150)}<div class="calc-out" data-q></div><div class="ctl" style="flex-wrap:wrap;gap:6px"><b class="small">সাম্য:</b>${X.seg('d', [['1', 'ডানে'], ['-1', 'বামে'], ['0', 'সরে না']], '')}</div><div class="ctl" style="flex-wrap:wrap;gap:6px"><b class="small">K:</b>${X.seg('k', [['1', 'বাড়ে'], ['-1', 'কমে'], ['0', 'অপরিবর্তিত']], '')}</div><div class="ctl"><button class="btn sm primary" data-chk>যাচাই করো</button><button class="btn sm" data-nx>পরের প্রশ্ন →</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), qq = el.querySelector('[data-q]'), q = s => el.querySelector(s);
    let L = X.fit(c, () => 150), cur, ud = null, uk = null, shown = false, tilt = 0, target = 0, score = 0, tot = 0, seed = 7;
    const R = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    const next = () => { const r = QRX[Math.floor(R() * QRX.length)]; let ch = QCH[Math.floor(R() * QCH.length)][0]; if (r.solidR && ch === 'ar' && R() < 0.3) ch = 'ar'; cur = { r, ch, a: answer(r, ch) }; ud = uk = null; shown = false; target = 0; el.querySelectorAll('[data-seg] button').forEach(b => b.classList.remove('on')); qq.innerHTML = TXB(r.e) + TXB(`\\Delta H = ${r.dh}\\ \\mathrm{kJ\\,mol^{-1}}`) + `<div><b>পরিবর্তন:</b> ${QCH.find(z => z[0] === ch)[1]}${ch === 'ar' ? ` (${r.R})` : ch === 'rp' ? ` (${r.P})` : ''}</div>`; out.innerHTML = `<div class="small">স্কোর: ${bn(score)}/${bn(tot)}</div>`; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const cx = W / 2, cy = 50, arm = Math.min(160, W * 0.32);
      g.fillStyle = col.fg; g.beginPath(); g.moveTo(cx - 22, H - 12); g.lineTo(cx + 22, H - 12); g.lineTo(cx, cy); g.closePath(); g.globalAlpha = 0.85; g.fill(); g.globalAlpha = 1;
      g.save(); g.translate(cx, cy); g.rotate(tilt * 0.3); g.strokeStyle = col.fg; g.lineWidth = 4; g.beginPath(); g.moveTo(-arm, 0); g.lineTo(arm, 0); g.stroke();
      [[-arm, 'বিক্রিয়ক', '#2d6fd6'], [arm, 'উৎপাদ', '#d06a1e']].forEach(([x, nm, cc], i) => { g.save(); g.translate(x, 0); g.rotate(-tilt * 0.3); g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(-26, 34); g.lineTo(0, 0); g.lineTo(26, 34); g.stroke(); g.fillStyle = col.s3; g.beginPath(); g.ellipse(0, 36, 32, 7, 0, 0, 7); g.fill(); g.stroke(); const n = 3 + Math.round((i ? 1 : -1) * tilt * 2.5); for (let k = 0; k < Math.max(1, n); k++) ball(g, -18 + (k % 4) * 12, 26 - Math.floor(k / 4) * 10, 5.5, cc, '#fff'); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, 0, 60); g.restore(); });
      g.restore();
    };
    const A = X.anim(el, dt => { if (dt) tilt += (target - tilt) * Math.min(1, dt * 4); draw(); }, { paused: false });
    X.onSeg(el, 'd', v => { ud = +v; }); X.onSeg(el, 'k', v => { uk = +v; });
    q('[data-chk]').onclick = () => { if (shown) return; if (ud === null || uk === null) { out.innerHTML = '<div class="small">দুটি প্রশ্নেরই উত্তর বেছে নাও।</div>'; return; } shown = true; tot++; const ok = ud === cur.a.d && uk === cur.a.K; if (ok) score++; target = cur.a.d; out.innerHTML = `<div style="font-weight:700;color:${ok ? 'var(--ok)' : 'var(--bad)'}">${ok ? '✓ সঠিক!' : `✗ সঠিক উত্তর: সাম্য ${cur.a.d > 0 ? 'ডানে' : cur.a.d < 0 ? 'বামে' : 'সরে না'}, K ${cur.a.K > 0 ? 'বাড়ে' : cur.a.K < 0 ? 'কমে' : 'অপরিবর্তিত'}`}</div><div class="small">${cur.a.why}</div><div class="small">স্কোর: ${bn(score)}/${bn(tot)}</div>`; };
    q('[data-nx]').onclick = next;
    next(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, () => 150); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
