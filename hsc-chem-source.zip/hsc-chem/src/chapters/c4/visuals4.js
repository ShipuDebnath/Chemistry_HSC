/* Chapter 4 visuals part 4 — energy profile, 3D collision, Maxwell–Boltzmann, Arrhenius, SN2 transition state (4.3.3–4.3.5) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, f1 = C4.f1, INK = C4.INK;
const TXR = C4.tx, TXB = C4.txb, sci = C4.sci, path = C4.path;

/* ---------- small 3D renderer (perspective, depth-sorted balls, partial bonds, charge clouds) ---------- */
const CPK = { H: '#f2f2f2', C: '#4a4a4a', N: '#3d63d6', O: '#e0402e', Br: '#a8452a', Cl: '#3fbf4f', I: '#7b3fa0', S: '#e6c228' };
const RAD = { H: 0.26, C: 0.42, N: 0.42, O: 0.42, Br: 0.6, Cl: 0.55, I: 0.65, S: 0.55 };
const shade = (hex, k) => { const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255; if (k > 0) { r += (255 - r) * k; g += (255 - g) * k; b += (255 - b) * k; } else { r *= 1 + k; g *= 1 + k; b *= 1 + k; } return `rgb(${r | 0},${g | 0},${b | 0})`; };
C4.r3d = (g, W, H, scene, view) => {
  const { yaw, pitch } = view, S = (view.scale || 1) * Math.min(W, H) * 0.16, cx = W / 2 + (view.dx || 0), cy = H / 2 + (view.dy || 0), Dd = 14;
  const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const P = ([x, y, z]) => { const x1 = x * cyw + z * syw, z1 = -x * syw + z * cyw; const y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp; const f = Dd / (Dd + z2); return [cx + x1 * S * f, cy - y2 * S * f, z2, f]; };
  const A = scene.atoms.map(a => Object.assign({}, a, { q: P(a.p) }));
  const items = [];
  A.forEach((a, i) => items.push({ z: a.q[2], t: 'a', i }));
  (scene.bonds || []).forEach((b, k) => { items.push({ z: A[b[0]].q[2] + 0.002, t: 'b', k, h: 0 }); items.push({ z: A[b[1]].q[2] + 0.002, t: 'b', k, h: 1 }); });
  (scene.clouds || []).forEach((c, k) => items.push({ z: P(c.p)[2] - 0.5, t: 'c', k }));
  items.sort((p, q) => q.z - p.z);
  for (const it of items) {
    if (it.t === 'c') { const c = scene.clouds[it.k], q = P(c.p), r = c.r * S * q[3]; const gr = g.createRadialGradient(q[0], q[1], r * 0.1, q[0], q[1], r); gr.addColorStop(0, c.color.replace('A', String(c.a))); gr.addColorStop(1, c.color.replace('A', '0')); g.fillStyle = gr; g.beginPath(); g.arc(q[0], q[1], r, 0, 7); g.fill(); if (c.label) { g.fillStyle = '#b3261e'; g.font = `bold ${Math.round(12 * q[3])}px sans-serif`; g.textAlign = 'center'; g.fillText(c.label, q[0], q[1] - r * 0.75); } continue; }
    if (it.t === 'b') {
      const [i, j, ord, alpha] = scene.bonds[it.k], a = A[i], b = A[j];
      const op = alpha == null ? 1 : alpha; if (op < 0.03) continue;
      const dx = b.q[0] - a.q[0], dy = b.q[1] - a.q[1], L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L;
      const f = (a.q[3] + b.q[3]) / 2, w = (ord === 2 || ord === 3 ? 0.13 : 0.2) * S * f;
      const mx = (a.q[0] + b.q[0]) / 2, my = (a.q[1] + b.q[1]) / 2, at = it.h ? b : a;
      g.globalAlpha = op;
      if (ord === 'p') { g.strokeStyle = '#555'; g.lineWidth = Math.max(1.5, w * 0.35); g.setLineDash([4, 4]); g.beginPath(); g.moveTo(at.q[0], at.q[1]); g.lineTo(mx, my); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; continue; }
      const offs = ord === 1 ? [0] : ord === 2 ? [-0.7, 0.7] : [-1.3, 0, 1.3];
      offs.forEach(k0 => { const ox = nx * k0 * w * 1.2, oy = ny * k0 * w * 1.2; g.lineCap = 'round';
        g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = w + 1.5; g.beginPath(); g.moveTo(at.q[0] + ox, at.q[1] + oy); g.lineTo(mx + ox, my + oy); g.stroke();
        g.strokeStyle = shade(CPK[at.el] || '#999', -0.08); g.lineWidth = w; g.beginPath(); g.moveTo(at.q[0] + ox, at.q[1] + oy); g.lineTo(mx + ox, my + oy); g.stroke();
        g.strokeStyle = 'rgba(255,255,255,.3)'; g.lineWidth = w * 0.3; g.beginPath(); g.moveTo(at.q[0] + ox - nx * w * 0.2, at.q[1] + oy - ny * w * 0.2); g.lineTo(mx + ox - nx * w * 0.2, my + oy - ny * w * 0.2); g.stroke(); });
      g.globalAlpha = 1; continue;
    }
    const a = A[it.i], r = (a.r || RAD[a.el] || 0.4) * S * a.q[3], col = CPK[a.el] || '#999';
    g.globalAlpha = a.alpha == null ? 1 : a.alpha;
    const gr = g.createRadialGradient(a.q[0] - r * 0.38, a.q[1] - r * 0.42, r * 0.08, a.q[0], a.q[1], r);
    gr.addColorStop(0, shade(col, 0.75)); gr.addColorStop(0.45, col); gr.addColorStop(1, shade(col, -0.45));
    g.fillStyle = gr; g.beginPath(); g.arc(a.q[0], a.q[1], r, 0, 6.283); g.fill(); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 0.8; g.stroke();
    if (a.el !== 'H' && r > 8) { g.fillStyle = ['C', 'N', 'Br', 'I', 'O'].includes(a.el) ? '#fff' : INK; g.font = `600 ${Math.round(r * 0.75)}px sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(a.label || a.el, a.q[0], a.q[1] + 1); g.textBaseline = 'alphabetic'; }
    g.globalAlpha = 1;
  }
  return P;
};
C4.drag3d = (c, view, onChange) => { X.drag(c, (dx, dy) => { view.yaw += dx * 0.01; view.pitch = Math.max(-1.4, Math.min(1.4, view.pitch + dy * 0.01)); view.user = true; onChange(); }); };
const lerp = C4.lerp, ease = C4.ease;
const lerp3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

/* ======================= ৪.৩.৩ শক্তি চিত্র: তাপোৎপাদী ও তাপহারী ======================= */
const prof = (x, ea, dh) => { const s = u => u <= 0 ? 0 : u >= 1 ? 1 : (1 - Math.cos(Math.PI * u)) / 2; return x < 0.5 ? ea * s((x - 0.12) / 0.38) : dh + (ea - dh) * s((0.88 - x) / 0.38); };
C4.prof = prof;
V.c4_energyProfile = {
  t: 'শক্তি চিত্র: সক্রিয়ণ শক্তি, ΔH ও অবস্থান্তর অবস্থা', k: ['anim', 'int', '2d', 'calc'],
  cap: 'স্লাইডারে সম্মুখ সক্রিয়ণ শক্তি Ea(f) ও ΔH বদলাও, অথবা উদাহরণ বেছে নাও। চিত্রে Ea(f) (নীল তীর), Ea(b) (কমলা তীর) ও ΔH (সবুজ তীর) স্বয়ংক্রিয়ভাবে মাপা হয় — ΔH = Ea(f) − Ea(b)। অ্যানিমেশনে বিভিন্ন শক্তির কণা (বল) পাহাড়ে ওঠার চেষ্টা করছে: যাদের শক্তি Ea এর কম তারা ফিরে আসে, যারা Ea অতিক্রম করে তারা উৎপাদে পৌঁছায়। "প্রভাবক" চালু করলে ড্যাশ রেখায় নিচু পথ দেখায় — দুই দিকের Ea সমান পরিমাণে কমে, ΔH একই থাকে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('ex', [['exo', 'তাপোৎপাদী'], ['endo', 'তাপহারী'], ['hi', '2HI → H₂ + I₂']], 'exo')}</div><div data-svg></div><div class="grid2"><label class="small">Ea(f) <b data-ev></b> kJ mol⁻¹<input type="range" min="20" max="250" step="1" value="120" data-ea></label><label class="small">ΔH <b data-hv></b> kJ mol⁻¹<input type="range" min="-150" max="150" step="1" value="-60" data-dh></label></div><div class="ctl"><label class="small"><input type="checkbox" data-cat> প্রভাবক</label><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sE = el.querySelector('[data-ea]'), sH = el.querySelector('[data-dh]'), cat = el.querySelector('[data-cat]');
    let ea = 120, dh = -60, catOn = false, balls = [], clock = 0;
    const R = X.rng(5);
    const fixEa = () => { if (ea < Math.max(0, dh) + 5) { ea = Math.max(0, dh) + 5; sE.value = ea; } };
    const draw = () => {
      const W = 400, H = 280, x0 = 50, x1 = 386, y0 = 22, y1 = 238;
      const emin = Math.min(0, dh) - 30, emax = Math.max(ea, 0) + 40;
      const Xp = x => x0 + x * (x1 - x0), Yp = e => y1 - (e - emin) / (emax - emin) * (y1 - y0);
      let s = `<defs>${X.arrowC('c4epB', '#2d6fd6')}${X.arrowC('c4epO', '#d9782a')}${X.arrowC('c4epG', '#2e9d4e')}${X.arrow('c4epA')}</defs>`;
      s += `<line x1="${x0}" y1="${y1}" x2="${x1 + 6}" y2="${y1}" class="s-fg" stroke-width="1.3" marker-end="url(#c4epA)"/><line x1="${x0}" y1="${y1}" x2="${x0}" y2="${y0 - 8}" class="s-fg" stroke-width="1.3" marker-end="url(#c4epA)"/>`;
      s += `<text x="${(x0 + x1) / 2}" y="${H - 22}" text-anchor="middle" class="tm" style="font-size:11px">বিক্রিয়ার পথ →</text><text transform="translate(16 ${(y0 + y1) / 2}) rotate(-90)" text-anchor="middle" class="tm" style="font-size:11px">স্থিতিশক্তি (kJ mol⁻¹)</text>`;
      let d = ''; for (let i = 0; i <= 120; i++) { const x = i / 120; d += (i ? 'L' : 'M') + f1(Xp(x)) + ' ' + f1(Yp(prof(x, ea, dh))); }
      const eac = Math.max(Math.max(0, dh) + 3, ea * 0.55);
      if (catOn) { let dc = ''; for (let i = 0; i <= 120; i++) { const x = i / 120; dc += (i ? 'L' : 'M') + f1(Xp(x)) + ' ' + f1(Yp(prof(x, eac, dh))); } s += `<path d="${dc}" fill="none" stroke="#2e9d4e" stroke-width="2.4" stroke-dasharray="7 5"/><text x="${f1(Xp(0.5))}" y="${f1(Yp(eac) - 6)}" text-anchor="middle" style="font-size:10px;fill:#2e9d4e;font-weight:700">প্রভাবিত পথ</text>`; }
      s += `<path d="${d}" fill="none" class="s-fg" stroke-width="3"/>`;
      // levels
      s += `<line x1="${x0}" y1="${f1(Yp(0))}" x2="${f1(Xp(0.62))}" y2="${f1(Yp(0))}" class="s-mu" stroke-dasharray="3 3"/><line x1="${f1(Xp(0.38))}" y1="${f1(Yp(dh))}" x2="${x1}" y2="${f1(Yp(dh))}" class="s-mu" stroke-dasharray="3 3"/><line x1="${f1(Xp(0.3))}" y1="${f1(Yp(ea))}" x2="${f1(Xp(0.95))}" y2="${f1(Yp(ea))}" class="s-mu" stroke-dasharray="3 3"/>`;
      s += `<text x="${f1(Xp(0.07))}" y="${f1(Yp(0) - 8)}" text-anchor="middle" class="tb" style="font-size:11px;font-weight:700">বিক্রিয়ক</text><text x="${f1(Xp(0.93))}" y="${f1(Yp(dh) - 8)}" text-anchor="middle" class="tb" style="font-size:11px;font-weight:700">উৎপাদ</text><text x="${f1(Xp(0.5))}" y="${f1(Yp(ea) - 8)}" text-anchor="middle" class="tb" style="font-size:12px;font-weight:700">‡ অবস্থান্তর অবস্থা</text>`;
      // arrows
      const ax = Xp(0.24), bx = Xp(0.76), hx = Xp(0.97);
      s += `<line x1="${f1(ax)}" y1="${f1(Yp(0))}" x2="${f1(ax)}" y2="${f1(Yp(ea) + 2)}" stroke="#2d6fd6" stroke-width="2" marker-end="url(#c4epB)"/><text x="${f1(ax - 5)}" y="${f1((Yp(0) + Yp(ea)) / 2)}" text-anchor="end" style="font-size:11px;fill:#2d6fd6;font-weight:700">Ea(f)</text>`;
      s += `<line x1="${f1(bx)}" y1="${f1(Yp(dh))}" x2="${f1(bx)}" y2="${f1(Yp(ea) + 2)}" stroke="#d9782a" stroke-width="2" marker-end="url(#c4epO)"/><text x="${f1(bx + 5)}" y="${f1((Yp(dh) + Yp(ea)) / 2)}" style="font-size:11px;fill:#d9782a;font-weight:700">Ea(b)</text>`;
      if (Math.abs(dh) > 4) s += `<line x1="${f1(hx)}" y1="${f1(Yp(0))}" x2="${f1(hx)}" y2="${f1(Yp(dh) + (dh < 0 ? -2 : 2))}" stroke="#2e9d4e" stroke-width="2" marker-end="url(#c4epG)"/><line x1="${f1(Xp(0.62))}" y1="${f1(Yp(0))}" x2="${f1(hx + 4)}" y2="${f1(Yp(0))}" class="s-mu" stroke-dasharray="3 3"/><text x="${f1(hx - 5)}" y="${f1((Yp(0) + Yp(dh)) / 2 + 4)}" text-anchor="end" style="font-size:11px;fill:#2e9d4e;font-weight:700">ΔH</text>`;
      // balls
      balls.forEach(b => { const e = prof(b.x, ea, dh); s += `<circle cx="${f1(Xp(b.x))}" cy="${f1(Yp(e) - 7)}" r="6" fill="${b.ok ? '#2e9d4e' : '#e0402e'}" stroke="#fff" stroke-width="1.5" opacity="${f1(b.op)}"/>`; });
      box.innerHTML = X.svg(W, H, s, 'শক্তি চিত্র');
    };
    const info = () => {
      el.querySelector('[data-ev]').textContent = bn(ea); el.querySelector('[data-hv]').textContent = (dh > 0 ? '+' : '') + bn(dh);
      const eab = ea - dh;
      out.innerHTML = TXB(`E_{a(f)} = ${ea}\\ \\mathrm{kJ\\,mol^{-1}}`) + TXB(`E_{a(b)} = E_{a(f)} - \\Delta H = ${ea} - (${dh}) = ${eab}\\ \\mathrm{kJ\\,mol^{-1}}`) + `<div class="small" style="margin-top:4px">${dh < 0 ? 'তাপোৎপাদী: উৎপাদ বিক্রিয়কের নিচে, Ea(f) < Ea(b)।' : dh > 0 ? 'তাপহারী: উৎপাদ উপরে, Ea(f) > Ea(b), এবং Ea(f) ≥ ΔH।' : 'ΔH = 0: দুই দিকের Ea সমান।'}${catOn ? ' প্রভাবক উভয় দিকের Ea সমান পরিমাণে কমিয়েছে; ΔH অপরিবর্তিত।' : ''}</div>`;
    };
    const presets = { exo: [120, -60], endo: [140, 70], hi: [183, 9.5] };
    const A = X.anim(el, dt => {
      if (dt) {
        clock += dt;
        if (clock > 0.55 && balls.length < 7) { clock = 0; const e = (catOn ? Math.max(Math.max(0, dh) + 3, ea * 0.55) : ea) * (0.55 + R() * 0.8); balls.push({ x: 0.04, v: 0.32, emax: e, ok: null, op: 1, dir: 1 }); }
        const eaEff = catOn ? Math.max(Math.max(0, dh) + 3, ea * 0.55) : ea;
        balls.forEach(b => { const e = prof(b.x, eaEff, dh) * (ea === eaEff ? 1 : 1); if (b.dir > 0 && b.x < 0.5 && e >= b.emax) { b.dir = -1; b.ok = false; } if (b.x >= 0.5 && b.ok === null) b.ok = true; b.x += b.dir * dt * 0.38; if (b.x < 0.02 || b.x > 0.98) b.op -= dt * 2.5; });
        balls = balls.filter(b => b.op > 0);
      }
      draw();
    }, { paused: false });
    X.pp(el, A);
    sE.oninput = () => { ea = +sE.value; fixEa(); info(); A.draw(); };
    sH.oninput = () => { dh = +sH.value; fixEa(); info(); A.draw(); };
    cat.onchange = () => { catOn = cat.checked; info(); A.draw(); };
    X.onSeg(el, 'ex', k => { [ea, dh] = presets[k]; sE.value = ea; sH.value = dh; balls = []; info(); A.draw(); });
    info(); draw();
    return () => A.stop();
  }
};

/* ======================= ৪.৩.৪ সংঘর্ষ তত্ত্ব: CO + NO₂ (৩D) ======================= */
V.c4_collision = {
  t: 'সংঘর্ষ তত্ত্ব ৩D: শক্তি ও অভিমুখ — CO + NO₂ → CO₂ + NO', k: ['3d', 'anim', 'int'],
  cap: 'অভিমুখ ও সংঘর্ষের শক্তি বেছে "সংঘর্ষ ঘটাও" চাপো। কেবল যখন CO এর কার্বন NO₂ এর একটি অক্সিজেনকে আঘাত করে এবং শক্তি সক্রিয়ণ শক্তির (Ea ≈ 134 kJ mol⁻¹) সমান বা বেশি, তখনই সংঘর্ষের মুহূর্তে C···O আংশিক বন্ধন (ড্যাশ) তৈরি হয়, N–O বন্ধন দুর্বল হয় এবং O পরমাণু স্থানান্তরিত হয়ে CO₂ ও NO তৈরি করে। ভুল অভিমুখে বা কম শক্তিতে অণুগুলো শুধু ছিটকে যায়। আঙুল দিয়ে টেনে মডেল ঘোরাও।',
  html: () => `<div class="ctl" style="margin:0 0 4px">${X.seg('o', [['ok', 'C → O (সঠিক)'], ['oend', 'O → O (ভুল)'], ['nside', 'C → N (ভুল)']], 'ok')}</div><div class="ctl" style="margin:0 0 6px">${X.seg('e', [['lo', 'কম শক্তি (< Ea)'], ['hi', 'বেশি শক্তি (≥ Ea)']], 'hi')}</div>${X.cv('CO ও NO2 এর সংঘর্ষের ৩D মডেল')}<div class="ctl"><button class="btn sm primary" data-go>সংঘর্ষ ঘটাও</button><button class="btn sm" data-auto>${X.ico('repeat')}স্বয়ংক্রিয় পুনরাবৃত্তি</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]');
    let L = X.fit(c, w => Math.min(330, w * 0.8)), ori = 'ok', en = 'hi', t = 0, run = true, auto = true;
    const view = { yaw: 0.35, pitch: 0.28, scale: 1.05 };
    // geometry at rest (units ≈ Å): NO2 with N at origin, target O (Oa) toward −x
    const N0 = [1.5, 0, 0], Oa0 = [0.35, 0, 0], Ob0 = [1.5 + 0.8, 0.83, 0];
    const scene = tt => {
      const success = ori === 'ok' && en === 'hi';
      const appr = ease(Math.min(1, tt / 0.45)), sep = ease(Math.max(0, (tt - 0.55) / 0.45));
      const gapStart = 4.2, gapHit = ori === 'ok' ? 1.55 : 1.5;
      let C, O1, N = N0.slice(), Oa = Oa0.slice(), Ob = Ob0.slice();
      const hitX = Oa0[0] - gapHit, shake = (tt > 0.45 && tt < 0.55) ? Math.sin((tt - 0.45) * 120) * 0.04 : 0;
      if (ori === 'nside') { // approach from below toward N
        const y = lerp(-gapStart, -1.55, appr) - (success ? 0 : 0);
        C = [N0[0], y + shake, 0]; O1 = [N0[0], y - 1.13, 0];
        if (tt > 0.55) { const back = sep * 2.6; C[1] -= back; O1[1] -= back; N[1] += sep * 0.6; Oa[1] += sep * 0.6; Ob[1] += sep * 0.6; }
      } else {
        const x = lerp(hitX - gapStart, hitX, appr) + shake;
        if (ori === 'ok') { C = [x, 0, 0]; O1 = [x - 1.13, 0, 0]; } else { O1 = [x + 0.15, 0, 0]; C = [x - 0.98, 0, 0]; }
        if (tt > 0.55) {
          if (success) { // O transfers: CO2 = O1–C–Oa linear moving left ; NO = N–Ob moving right
            const OaT = [C[0] + 1.16, 0, 0]; Oa = lerp3(Oa0, OaT, Math.min(1, sep * 3)); const mv = sep * 2.8; C = [C[0] - mv, 0, 0]; O1 = [O1[0] - mv, 0, 0]; Oa = [Oa[0] - mv * Math.min(1, sep * 3), 0, 0]; N = [N0[0] + mv, 0.1 * sep, 0]; Ob = [Ob0[0] + mv, Ob0[1] + 0.1 * sep, 0];
          } else { const back = sep * 2.6; C[0] -= back; O1[0] -= back; N[0] += sep * 0.6; Oa[0] += sep * 0.6; Ob[0] += sep * 0.6; }
        }
      }
      const atoms = [{ el: 'C', p: C }, { el: 'O', p: O1 }, { el: 'N', p: N }, { el: 'O', p: Oa }, { el: 'O', p: Ob }];
      const contact = tt > 0.42 && tt < 0.6;
      const bonds = [[0, 1, 3], [2, 4, 2]];
      if (success) { const k = tt < 0.42 ? 0 : tt < 0.6 ? 1 : 2; if (k === 0) bonds.push([2, 3, 1]); else if (k === 1) { bonds.push([2, 3, 'p'], [0, 3, 'p']); } else { bonds.push([0, 3, 2]); bonds[0] = [0, 1, 2]; } }
      else bonds.push([2, 3, 1]);
      const clouds = [];
      if (contact) { const cp = ori === 'nside' ? [N0[0], (C[1] + N[1]) / 2, 0] : [ori === 'ok' ? (C[0] + Oa[0]) / 2 : (O1[0] + Oa[0]) / 2, 0, 0]; clouds.push({ p: cp, r: 0.95, color: success ? 'rgba(255,200,60,A)' : 'rgba(150,150,150,A)', a: 0.55 }); }
      return { atoms, bonds, clouds, success };
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const sc = scene(t); C4.r3d(g, W, H, sc, view);
      g.font = `11px ${col.font}`; g.fillStyle = col.mu; g.textAlign = 'left';
      const phase = t < 0.42 ? 'কাছে আসছে' : t < 0.6 ? 'সংঘর্ষ!' : sc.success ? 'কার্যকর সংঘর্ষ — CO₂ + NO' : 'অকার্যকর — ছিটকে গেল';
      g.fillStyle = t >= 0.6 ? (sc.success ? '#2e9d4e' : '#e0402e') : col.fg; g.font = `bold 12px ${col.font}`; g.fillText(phase, 10, 18);
      // energy bar
      const bx = W - 26, by = 14, bh = H - 40, frac = en === 'hi' ? 0.82 : 0.45, eaf = 0.62;
      g.fillStyle = col.s3; g.fillRect(bx, by, 12, bh); g.fillStyle = en === 'hi' ? '#2e9d4e' : '#e0402e'; g.fillRect(bx, by + bh * (1 - frac), 12, bh * frac);
      g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(bx - 4, by + bh * (1 - eaf)); g.lineTo(bx + 16, by + bh * (1 - eaf)); g.stroke();
      g.font = `10px ${col.font}`; g.fillStyle = col.fg; g.textAlign = 'right'; g.fillText('Ea', bx - 6, by + bh * (1 - eaf) + 4); g.textAlign = 'center'; g.fillText('শক্তি', bx + 6, H - 8);
    };
    const info = () => {
      const msg = { ok: 'C পরমাণু NO₂ এর O এর দিকে — O স্থানান্তরের জন্য সঠিক জ্যামিতি।', oend: 'CO এর O প্রান্ত আগে — C···O বন্ধন গঠনের সুযোগ নেই।', nside: 'C আঘাত করছে N কে — O স্থানান্তর সম্ভব নয়।' }[ori];
      const ok = ori === 'ok' && en === 'hi';
      out.innerHTML = `<div>${msg}</div><div class="small" style="margin-top:4px">${ok ? '<b style="color:var(--ok)">শক্তি ≥ Ea এবং অভিমুখ সঠিক → কার্যকর সংঘর্ষ।</b>' : ori === 'ok' ? '<b style="color:var(--bad)">অভিমুখ সঠিক, কিন্তু শক্তি Ea এর কম → বন্ধন পুনর্বিন্যাস হয় না।</b>' : '<b style="color:var(--bad)">' + (en === 'hi' ? 'শক্তি যথেষ্ট, কিন্তু অভিমুখ ভুল → অকার্যকর।' : 'শক্তি ও অভিমুখ — দুটোই অপর্যাপ্ত।') + '</b>'}</div>` + TXB(`r = Z\\cdot e^{-E_a/RT}\\cdot P`);
    };
    let hold = 0;
    const A = X.anim(el, dt => {
      if (dt) { if (!view.user) view.yaw += dt * 0.15; if (run) { t += dt * 0.32; if (t >= 1) { t = 1; run = false; hold = 0; } } else if (auto) { hold += dt; if (hold > 1.4) { t = 0; run = true; } } }
      draw();
    }, { paused: false });
    C4.drag3d(c, view, () => A.draw());
    el.querySelector('[data-go]').onclick = () => { t = 0; run = true; A.draw(); };
    const ab = el.querySelector('[data-auto]'); const upd = () => { ab.classList.toggle('primary', auto); }; ab.onclick = () => { auto = !auto; upd(); }; upd();
    X.onSeg(el, 'o', v => { ori = v; t = 0; run = true; info(); }); X.onSeg(el, 'e', v => { en = v; t = 0; run = true; info(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(330, w * 0.8)); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৩.৪ ম্যাক্সওয়েল-বোল্টজম্যান বণ্টন (২D ও ৩D তল) ======================= */
const Rg = 8.314e-3; // kJ/mol/K
const mb = (E, T) => { const kT = Rg * T; return 2 / Math.sqrt(Math.PI) * Math.pow(1 / kT, 1.5) * Math.sqrt(Math.max(0, E)) * Math.exp(-E / kT); };
const erfc = x => { const t = 1 / (1 + 0.5 * Math.abs(x)); const y = t * Math.exp(-x * x - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277))))))))); return x >= 0 ? y : 2 - y; };
const fracAbove = (Ea, T) => { const x = Ea / (Rg * T); return erfc(Math.sqrt(x)) + 2 * Math.sqrt(x / Math.PI) * Math.exp(-x); };
C4.mb = mb; C4.fracAbove = fracAbove;
V.c4_maxwell = {
  t: 'ম্যাক্সওয়েল-বোল্টজম্যান শক্তি বণ্টন: তাপমাত্রা ও প্রভাবকের প্রভাব (২D ও ৩D)', k: ['2d', '3d', 'int', 'calc'],
  cap: '২D চিত্রে নীল বক্ররেখা T₁ এবং লাল বক্ররেখা T₂ তাপমাত্রায় অণুর শক্তি বণ্টন। Ea রেখার ডানের ছায়াযুক্ত অংশ = সক্রিয়ণ শক্তি অতিক্রমকারী অণুর ভগ্নাংশ (নিচে সংখ্যায়)। T₂ বাড়ালে বক্ররেখা চওড়া ও নিচু হয়, শীর্ষ ডানে সরে, মোট ক্ষেত্রফল একই থাকে — কিন্তু Ea এর ডানের অংশ বহুগুণ বাড়ে। প্রভাবক চালু করলে বণ্টন একই থাকে, Ea রেখা বামে সরে। "৩D তল" এ শক্তি (x), তাপমাত্রা (y) ও ভগ্নাংশ (z) একসাথে — টেনে ঘোরাও; লাল রেখা হলো Ea।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('v', [['2d', '২D লেখচিত্র'], ['3d', '৩D তল']], '2d')}</div>${X.cv('ম্যাক্সওয়েল-বোল্টজম্যান বণ্টন')}<div class="grid2" style="margin-top:8px"><label class="small">T₁ = <b data-t1v></b> K<input type="range" min="200" max="600" step="10" value="300" data-t1></label><label class="small">T₂ = <b data-t2v></b> K<input type="range" min="200" max="800" step="10" value="400" data-t2></label></div><div class="grid2"><label class="small">Ea = <b data-eav></b> kJ mol⁻¹<input type="range" min="5" max="40" step="0.5" value="15" data-ea></label><label class="small" style="align-self:end"><input type="checkbox" data-cat> প্রভাবক (Ea × ০.৬)</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    let L = X.fit(c, w => Math.min(340, w * 0.82)), mode = '2d', T1 = 300, T2 = 400, Ea = 15, catOn = false;
    const view = { yaw: -0.7, pitch: 0.55 };
    const Emax = 30;
    const draw2 = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const gx = 44, gy = 16, gw = W - gx - 14, gh = H - gy - 42;
      const ymax = mb(Rg * Math.min(T1, T2) / 2, Math.min(T1, T2)) * 1.15;
      const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax: Emax, ymax, col, xt: [0, 5, 10, 15, 20, 25, 30], yt: [], xl: 'শক্তি E (kJ mol⁻¹)', yl: 'অণুর ভগ্নাংশ', ylx: 22 });
      const eaE = catOn ? Ea * 0.6 : Ea;
      const area = (T, color) => { g.fillStyle = color; g.beginPath(); g.moveTo(P.X(eaE), P.Y(0)); for (let i = 0; i <= 80; i++) { const E = eaE + i / 80 * (Emax - eaE); g.lineTo(P.X(E), P.Y(mb(E, T))); } g.lineTo(P.X(Emax), P.Y(0)); g.closePath(); g.fill(); };
      area(T2, 'rgba(224,64,46,.28)'); area(T1, 'rgba(45,111,214,.35)');
      [[T1, '#2d6fd6'], [T2, '#e0402e']].forEach(([T, cc]) => { const pts = []; for (let i = 0; i <= 160; i++) { const E = i / 160 * Emax; pts.push([P.X(E), P.Y(mb(E, T))]); } path(g, pts, cc, 2.6); const Ep = Rg * T / 2; g.fillStyle = cc; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText((T === T1 ? 'T₁' : 'T₂') + ' = ' + bn(T) + ' K', P.X(Ep) + 6, P.Y(mb(Ep, T)) - 4); });
      const drawEa = (E, cc, lab, dash) => { g.strokeStyle = cc; g.lineWidth = 2; g.setLineDash(dash); g.beginPath(); g.moveTo(P.X(E), gy - 2); g.lineTo(P.X(E), gy + gh); g.stroke(); g.setLineDash([]); g.fillStyle = cc; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(lab, P.X(E), gy + 8); };
      if (catOn) { drawEa(Ea, 'rgba(120,120,120,.8)', 'Ea', [4, 4]); drawEa(eaE, '#2e9d4e', "Ea′", []); g.strokeStyle = '#2e9d4e'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(P.X(Ea) - 3, gy + 20); g.lineTo(P.X(eaE) + 6, gy + 20); g.stroke(); g.beginPath(); g.moveTo(P.X(eaE) + 6, gy + 16); g.lineTo(P.X(eaE), gy + 20); g.lineTo(P.X(eaE) + 6, gy + 24); g.fill(); }
      else drawEa(Ea, col.fg, 'Ea', []);
    };
    const draw3 = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const S = Math.min(W, H) * 0.42, cx = W / 2, cy = H * 0.58;
      const cyw = Math.cos(view.yaw), syw = Math.sin(view.yaw), cp = Math.cos(view.pitch), sp = Math.sin(view.pitch);
      const Tmin = 200, Tmax = 800, zmax = mb(Rg * Tmin / 2, Tmin);
      const P = (E, T, z) => { const x = (E / Emax - 0.5) * 2, y = ((T - Tmin) / (Tmax - Tmin) - 0.5) * 2, zz = z / zmax * 1.1; const x1 = x * cyw - y * syw, y1 = x * syw + y * cyw; const sy = zz * cp - y1 * sp; return [cx + x1 * S, cy - sy * S, y1 * cp + zz * sp]; };
      // axes box base
      g.strokeStyle = col.mu; g.lineWidth = 1; const base = [[0, Tmin], [Emax, Tmin], [Emax, Tmax], [0, Tmax], [0, Tmin]]; g.beginPath(); base.forEach(([E, T], i) => { const p = P(E, T, 0); i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); }); g.stroke();
      // mesh: lines of constant T
      const nT = 13, nE = 40;
      const rows = []; for (let j = 0; j < nT; j++) { const T = Tmin + j / (nT - 1) * (Tmax - Tmin); rows.push({ T, pts: Array.from({ length: nE + 1 }, (_, i) => { const E = i / nE * Emax; return P(E, T, mb(E, T)); }) }); }
      rows.sort((a, b) => b.pts[20][2] - a.pts[20][2]);
      const eaE = catOn ? Ea * 0.6 : Ea;
      rows.forEach(r => { const t = (r.T - Tmin) / (Tmax - Tmin); // fill under curve for occlusion
        g.fillStyle = col.bg; g.beginPath(); r.pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); const b1 = P(Emax, r.T, 0), b0 = P(0, r.T, 0); g.lineTo(b1[0], b1[1]); g.lineTo(b0[0], b0[1]); g.closePath(); g.globalAlpha = 0.85; g.fill(); g.globalAlpha = 1;
        // shaded part above Ea
        g.fillStyle = `rgba(${Math.round(45 + 180 * t)},${Math.round(111 - 47 * t)},${Math.round(214 - 168 * t)},.35)`; g.beginPath(); const i0 = Math.ceil(eaE / Emax * nE); const pe = P(eaE, r.T, 0); g.moveTo(pe[0], pe[1]); const pz = P(eaE, r.T, mb(eaE, r.T)); g.lineTo(pz[0], pz[1]); for (let i = i0; i <= nE; i++) g.lineTo(r.pts[i][0], r.pts[i][1]); g.lineTo(b1[0], b1[1]); g.closePath(); g.fill();
        g.strokeStyle = `rgb(${Math.round(45 + 180 * t)},${Math.round(111 - 47 * t)},${Math.round(214 - 168 * t)})`; g.lineWidth = 1.6; g.beginPath(); r.pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.stroke(); });
      // Ea line on base
      const a0 = P(eaE, Tmin, 0), a1 = P(eaE, Tmax, 0); g.strokeStyle = '#e0402e'; g.lineWidth = 2.4; g.beginPath(); g.moveTo(a0[0], a0[1]); g.lineTo(a1[0], a1[1]); g.stroke();
      g.font = `11px ${col.font}`; g.fillStyle = col.fg; g.textAlign = 'center';
      const le = P(Emax * 0.5, Tmin - 70, 0); g.fillText('শক্তি E →', le[0], le[1]); const lt = P(Emax + 3, (Tmin + Tmax) / 2, 0); g.fillText('T (K) →', lt[0], lt[1]); const lea = P(eaE, Tmax + 40, 0); g.fillStyle = '#e0402e'; g.fillText(catOn ? "Ea′" : 'Ea', lea[0], lea[1]);
      g.fillStyle = col.mu; g.textAlign = 'left'; g.fillText('টেনে ঘোরাও', 8, 14);
    };
    const draw = () => mode === '2d' ? draw2() : draw3();
    const info = () => {
      q('[data-t1v]').textContent = bn(T1); q('[data-t2v]').textContent = bn(T2); q('[data-eav]').textContent = bn(Ea);
      const eaE = catOn ? Ea * 0.6 : Ea, f1v = fracAbove(eaE, T1), f2v = fracAbove(eaE, T2);
      out.innerHTML = TXB(`f(T_1) = ${(f1v * 100).toFixed(2)}\\%,\\quad f(T_2) = ${(f2v * 100).toFixed(2)}\\%`) + TXB(`\\dfrac{f(T_2)}{f(T_1)} = ${(f2v / f1v).toFixed(2)}`) + `<div class="small">অথচ সংঘর্ষ সংখ্যা বাড়ে মাত্র ${TXR(`\\sqrt{T_2/T_1} = ${Math.sqrt(T2 / T1).toFixed(2)}`)} গুণ।</div>` + `<div class="small" style="margin-top:4px">ভগ্নাংশের হিসাব: ${TXR('f = \\operatorname{erfc}\\sqrt{x} + 2\\sqrt{x/\\pi}\\,e^{-x},\\ x = E_a/RT')} — বড় x এ প্রায় ${TXR('e^{-E_a/RT}')} এর সমানুপাতিক।${catOn ? ' প্রভাবক Ea কমানোয় একই তাপমাত্রায় ভগ্নাংশ অনেক বেশি।' : ''}</div>`;
    };
    q('[data-t1]').oninput = e => { T1 = +e.target.value; info(); draw(); };
    q('[data-t2]').oninput = e => { T2 = +e.target.value; info(); draw(); };
    q('[data-ea]').oninput = e => { Ea = +e.target.value; info(); draw(); };
    q('[data-cat]').onchange = e => { catOn = e.target.checked; info(); draw(); };
    X.onSeg(el, 'v', v => { mode = v; draw(); });
    X.drag(c, (dx, dy) => { if (mode !== '3d') return; view.yaw += dx * 0.01; view.pitch = Math.max(0.05, Math.min(1.4, view.pitch + dy * 0.01)); draw(); });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(340, w * 0.82)); draw(); });
    return () => un();
  }
};

/* ======================= ৪.৩.৪ আরহেনিয়াস সমীকরণ: লেখচিত্র ও ক্যালকুলেটর ======================= */
V.c4_arrhenius = {
  t: 'আরহেনিয়াস সমীকরণ: k বনাম T, ln k বনাম 1/T ও Ea ক্যালকুলেটর', k: ['2d', 'int', 'calc'],
  cap: 'Ea ও A বদলাও: "k বনাম T" এ সূচকীয় বৃদ্ধি, "ln k বনাম 1/T" এ সরলরেখা — ঢাল = −Ea/R, ছেদক = ln A। উচ্চ Ea এর রেখা বেশি খাড়া: তাপমাত্রার প্রতি বেশি সংবেদনশীল। ক্যালকুলেটরে দুটি তাপমাত্রায় k দিলে Ea, অথবা Ea দিলে নতুন তাপমাত্রায় k — ধাপে ধাপে সমাধানসহ।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('p', [['kt', 'k বনাম T'], ['ln', 'ln k বনাম 1/T']], 'ln')}</div>${X.cv('আরহেনিয়াস লেখচিত্র')}<div class="grid2" style="margin-top:8px"><label class="small">Ea = <b data-eav></b> kJ mol⁻¹<input type="range" min="20" max="150" step="1" value="55" data-ea></label><label class="small">log A = <b data-av></b><input type="range" min="6" max="14" step="0.5" value="10" data-a></label></div>
  <div class="ctl" style="margin-top:10px">${X.seg('cm', [['ea', 'Ea নির্ণয়'], ['k2', 'k₂ নির্ণয়']], 'ea')}</div><div class="grid2"><label class="small">T₁ (K)<input class="inp" type="number" value="300" data-T1></label><label class="small">T₂ (K)<input class="inp" type="number" value="310" data-T2></label><label class="small">k₁<input class="inp" type="number" value="0.0015" step="any" data-k1></label><label class="small" data-k2l>k₂<input class="inp" type="number" value="0.003" step="any" data-k2></label><label class="small" data-eal style="display:none">Ea (kJ mol⁻¹)<input class="inp" type="number" value="75" data-eai></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    let L = X.fit(c, w => Math.min(300, w * 0.72)), pl = 'ln', Ea = 55, logA = 10, cm = 'ea';
    const kOf = (T, ea = Ea) => Math.pow(10, logA) * Math.exp(-ea * 1000 / (8.314 * T));
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const gx = 54, gy = 14, gw = W - gx - 14, gh = H - gy - 44;
      const set = [[Ea, '#2d6fd6', 'Ea'], [Ea * 0.5, 'rgba(46,157,78,.85)', 'Ea/2'], [Ea * 1.5, 'rgba(224,64,46,.85)', '1.5 Ea']];
      if (pl === 'kt') {
        const T0 = 280, T1 = 380, ymax = kOf(T1) * 1.1;
        const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: T0, xmax: T1, ymax, col, xt: [280, 300, 320, 340, 360, 380], yt: [0, ymax / 2, ymax], fy: v => v ? sci(v, 1).replace(/\\times10\^\{(-?\d+)\}/, (m, e) => '×10' + X.sup(e)) : '0', xl: 'T (K)', yl: 'k', ylx: 46 });
        const pts = []; for (let i = 0; i <= 100; i++) { const T = T0 + i / 100 * (T1 - T0); pts.push([P.X(T), P.Y(kOf(T))]); } path(g, pts, '#2d6fd6', 3);
        [300, 310].forEach((T, i) => { const x = P.X(T), y = P.Y(kOf(T)); g.fillStyle = '#e0402e'; g.beginPath(); g.arc(x, y, 4, 0, 7); g.fill(); });
        g.fillStyle = col.fg; g.font = `10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`300 K → 310 K: k × ${(kOf(310) / kOf(300)).toFixed(2)}`, gx + 8, gy + 12);
      } else {
        const x0 = 1 / 400, x1 = 1 / 280; const lnk = (ea, x) => logA * Math.LN10 - ea * 1000 / 8.314 * x;
        let ymin = Infinity, ymax = -Infinity; set.forEach(([ea]) => { [x0, x1].forEach(x => { const v = lnk(ea, x); ymin = Math.min(ymin, v); ymax = Math.max(ymax, v); }); });
        ymin = Math.floor(ymin - 1); ymax = Math.ceil(ymax + 1);
        const P = C4.cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: x0 * 1000, xmax: x1 * 1000, ymin, ymax, col, xt: [2.6, 2.8, 3.0, 3.2, 3.4], yt: [ymin, Math.round((ymin + ymax) / 2), ymax], fx: v => bn(v.toFixed(1)), fy: v => bn(v), xl: '1/T (×10⁻³ K⁻¹)', yl: 'ln k', ylx: 40 });
        set.forEach(([ea, cc, lab], i) => { const a = [P.X(x0 * 1000), P.Y(lnk(ea, x0))], b = [P.X(x1 * 1000), P.Y(lnk(ea, x1))]; path(g, [a, b], cc, i ? 1.8 : 3, i ? [6, 4] : []); g.fillStyle = cc; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(lab, b[0] - 34, b[1] + (i === 2 ? 12 : -6)); });
        // slope triangle on main line
        const xa = 3.0e-3, xb = 3.3e-3, ya = lnk(Ea, xa), yb = lnk(Ea, xb);
        g.strokeStyle = '#2d6fd6'; g.lineWidth = 1.2; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(P.X(xa * 1000), P.Y(ya)); g.lineTo(P.X(xb * 1000), P.Y(ya)); g.lineTo(P.X(xb * 1000), P.Y(yb)); g.stroke(); g.setLineDash([]);
        g.fillStyle = '#2d6fd6'; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('ঢাল = −Ea/R', P.X(xb * 1000) + 4, P.Y((ya + yb) / 2));
      }
    };
    const calc = () => {
      q('[data-eav]').textContent = bn(Ea); q('[data-av]').textContent = bn(logA);
      const T1 = +q('[data-T1]').value, T2 = +q('[data-T2]').value, k1 = +q('[data-k1]').value;
      let h = TXB(`k = A\\,e^{-E_a/RT}\\;\\Rightarrow\\;\\log\\dfrac{k_2}{k_1} = \\dfrac{E_a}{2.303R}\\left(\\dfrac{T_2-T_1}{T_1T_2}\\right)`);
      if (!(T1 > 0 && T2 > 0 && k1 > 0) || T1 === T2) { out.innerHTML = h + '<div class="small">ধনাত্মক ও ভিন্ন তাপমাত্রা এবং k দাও।</div>'; return; }
      const fac = (T2 - T1) / (T1 * T2);
      if (cm === 'ea') {
        const k2 = +q('[data-k2]').value; if (!(k2 > 0)) { out.innerHTML = h; return; }
        const lg = Math.log10(k2 / k1), ea = lg * 2.303 * 8.314 / fac;
        h += TXB(`\\log\\dfrac{${k2}}{${k1}} = ${lg.toFixed(3)} = \\dfrac{E_a}{19.147}\\times${sci(fac, 3)}`) + TXB(`E_a = \\dfrac{${lg.toFixed(3)}\\times19.147}{${sci(fac, 3)}} = ${(ea / 1000).toFixed(1)}\\ \\mathrm{kJ\\,mol^{-1}}`);
      } else {
        const ea = +q('[data-eai]').value * 1000; const lg = ea / (2.303 * 8.314) * fac, k2 = k1 * Math.pow(10, lg);
        h += TXB(`\\log\\dfrac{k_2}{k_1} = \\dfrac{${ea}}{19.147}\\times${sci(fac, 3)} = ${lg.toFixed(3)}`) + TXB(`k_2 = ${k1}\\times10^{${lg.toFixed(3)}} = ${sci(k2, 3)}`);
      }
      out.innerHTML = h;
    };
    q('[data-ea]').oninput = e => { Ea = +e.target.value; calc(); draw(); }; q('[data-a]').oninput = e => { logA = +e.target.value; calc(); draw(); };
    ['T1', 'T2', 'k1', 'k2', 'eai'].forEach(k => q(`[data-${k}]`).addEventListener('input', calc));
    X.onSeg(el, 'p', v => { pl = v; draw(); });
    X.onSeg(el, 'cm', v => { cm = v; q('[data-k2l]').style.display = v === 'ea' ? '' : 'none'; q('[data-eal]').style.display = v === 'k2' ? '' : 'none'; calc(); });
    calc(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(300, w * 0.72)); draw(); });
    return () => un();
  }
};

/* ======================= ৪.৩.৫ অবস্থান্তর অবস্থা: SN2 বিক্রিয়া (৩D) ======================= */
V.c4_transition = {
  t: 'অবস্থান্তর অবস্থা ৩D: OH⁻ + CH₃Br → [HO···CH₃···Br]⁻‡ → CH₃OH + Br⁻', k: ['3d', 'anim', 'int', '2d'],
  cap: 'উপরে ৩D মডেল, নিচে শক্তি চিত্র — দুটি একসাথে চলে। OH⁻ কার্বনের পেছন দিক (Br এর বিপরীতে) থেকে আসে; শীর্ষবিন্দুতে (‡) C–O ও C–Br দুটিই আংশিক বন্ধন (ড্যাশ), তিনটি H এক সমতলে (ত্রিকোণীয় দ্বি-পিরামিড) এবং ঋণাত্মক চার্জ O ও Br এ ভাগ হয়ে থাকে (δ−, লাল মেঘ)। এরপর Br⁻ বেরিয়ে যায় এবং H গুলো ছাতার মতো উল্টে যায় (ওয়ালডেন বিপরীতকরণ)। স্লাইডারে যেকোনো বিন্দুতে থামাও; মডেল টেনে ঘোরাও।',
  html: () => `${X.cv('SN2 বিক্রিয়ার ৩D মডেল ও শক্তি চিত্র')}<div class="ctl"><button class="btn sm" data-pp></button><label style="flex:1;min-width:150px">বিক্রিয়ার পথ ξ <input type="range" min="0" max="100" value="0" data-x></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), sx = el.querySelector('[data-x]');
    let L = X.fit(c, w => Math.min(500, w * 1.2)), xi = 0, clock = 0;
    const view = { yaw: 0.5, pitch: 0.32, scale: 1.08 };
    const geo = s => {
      // s in [0,1]; TS at 0.5
      const u = ease(s);
      const dCO = s < 0.5 ? lerp(3.6, 2.0, ease(s / 0.5)) : lerp(2.0, 1.43, ease((s - 0.5) / 0.5));
      const dCBr = s < 0.5 ? lerp(1.94, 2.45, ease(s / 0.5)) : lerp(2.45, 4.0, ease((s - 0.5) / 0.5));
      const hx = lerp(-0.36, 0.36, u) * 1.09, hr = Math.sqrt(Math.max(0, 1.09 * 1.09 - hx * hx));
      const atoms = [{ el: 'C', p: [0, 0, 0] }, { el: 'O', p: [-dCO, 0, 0] }, { el: 'H', p: [-dCO - 0.55, 0.75, 0] }, { el: 'Br', p: [dCBr, 0, 0] }];
      for (let i = 0; i < 3; i++) { const a = i * 2.094 + 0.3; atoms.push({ el: 'H', p: [hx, hr * Math.cos(a), hr * Math.sin(a)] }); }
      const bonds = [[1, 2, 1], [0, 4, 1], [0, 5, 1], [0, 6, 1]];
      const pCO = s < 0.3 ? 0 : s < 0.72 ? 'p' : 1, pCBr = s < 0.28 ? 1 : s < 0.7 ? 'p' : 0;
      if (pCO) bonds.push([0, 1, pCO, pCO === 'p' ? Math.min(1, (s - 0.3) / 0.1) : 1]);
      if (pCBr) bonds.push([0, 3, pCBr, pCBr === 'p' ? Math.min(1, (0.7 - s) / 0.1) : 1]);
      const qO = s < 0.3 ? 1 : s < 0.7 ? lerp(1, 0, (s - 0.3) / 0.4) : 0, qBr = 1 - qO;
      const clouds = [];
      if (qO > 0.05) clouds.push({ p: atoms[1].p, r: 0.9 + qO * 0.4, color: 'rgba(224,64,46,A)', a: 0.45 * qO + 0.05, label: qO > 0.95 ? '−' : 'δ−' });
      if (qBr > 0.05) clouds.push({ p: atoms[3].p, r: 1.0 + qBr * 0.4, color: 'rgba(224,64,46,A)', a: 0.45 * qBr + 0.05, label: qBr > 0.95 ? '−' : 'δ−' });
      return { atoms, bonds, clouds };
    };
    const Ea = 80, dH = -75;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const top = H * 0.6;
      g.save(); g.beginPath(); g.rect(0, 0, W, top); g.clip();
      view.dx = -0.15 * Math.min(W, top) * 0.16; C4.r3d(g, W, top, geo(xi), view); g.restore();
      const stage = xi < 0.2 ? 'বিক্রিয়ক: OH⁻ + CH₃Br' : xi < 0.4 ? 'OH⁻ পেছন দিক থেকে কাছে আসছে' : xi < 0.6 ? '‡ অবস্থান্তর অবস্থা — আংশিক বন্ধন' : xi < 0.8 ? 'Br⁻ বেরিয়ে যাচ্ছে, H উল্টে যাচ্ছে' : 'উৎপাদ: CH₃OH + Br⁻ (বিপরীত বিন্যাস)';
      g.fillStyle = xi > 0.4 && xi < 0.6 ? '#b3261e' : col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'left'; g.fillText(stage, 10, 18);
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.fillText('টেনে ঘোরাও', 10, top - 8);
      g.strokeStyle = col.line || col.mu; g.beginPath(); g.moveTo(8, top + 2); g.lineTo(W - 8, top + 2); g.stroke();
      // energy profile
      const gx = 46, gy = top + 18, gw = W - gx - 14, gh = H - gy - 26;
      const emin = dH - 15, emax = Ea + 20, Xp = x => gx + x * gw, Yp = e => gy + gh - (e - emin) / (emax - emin) * gh;
      g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(gx, gy - 4); g.lineTo(gx, gy + gh); g.lineTo(gx + gw, gy + gh); g.stroke();
      const pts = []; for (let i = 0; i <= 100; i++) { const x = i / 100; pts.push([Xp(x), Yp(C4.prof(x, Ea, dH))]); } path(g, pts, col.fg, 2.4);
      const e = C4.prof(xi, Ea, dH); g.fillStyle = '#e0402e'; g.beginPath(); g.arc(Xp(xi), Yp(e), 6, 0, 7); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = 2; g.stroke();
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('‡', Xp(0.5), Yp(Ea) - 6);
      g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.fillText('বিক্রিয়ার পথ →', gx + gw / 2, H - 6); g.save(); g.translate(14, gy + gh / 2); g.rotate(-Math.PI / 2); g.fillText('শক্তি', 0, 0); g.restore();
      g.textAlign = 'left'; g.fillText('বিক্রিয়ক', Xp(0.01), Yp(0) - 5); g.textAlign = 'right'; g.fillText('উৎপাদ', Xp(0.99), Yp(dH) - 5);
    };
    const info = () => {
      const s = xi;
      out.innerHTML = s > 0.38 && s < 0.62 ? TXB(`\\left[\\ce{HO\\cdots CH3\\cdots Br}\\right]^{-\\,\\ddagger}`) + '<div class="small">কার্বন প্রায় sp² — তিনটি H এক সমতলে (ত্রিকোণীয় দ্বি-পিরামিড); C–O ও C–Br দুটিই আংশিক; চার্জ O ও Br এ ভাগাভাগি। আয়ু ~10⁻¹³ s — পৃথক করা যায় না।</div>' : s <= 0.38 ? TXB(`\\ce{OH- + CH3Br}`) + '<div class="small">OH⁻ এর ঋণাত্মক চার্জ O তে; C–Br পূর্ণ বন্ধন; H গুলো OH⁻ এর দিকে হেলানো।</div>' : TXB(`\\ce{CH3OH + Br-}`) + '<div class="small">C–O পূর্ণ বন্ধন; ঋণাত্মক চার্জ এখন Br⁻ এ; H গুলো উল্টো দিকে হেলানো — বিন্যাস বিপরীত (ওয়ালডেন বিপরীতকরণ)।</div>';
    };
    let playing = true, last = '';
    const A = X.anim(el, dt => {
      if (dt) { if (!view.user) view.yaw += dt * 0.12; if (playing) { clock = (clock + dt * 0.11) % 1.3; xi = Math.min(1, clock); sx.value = Math.round(xi * 100); } }
      draw(); const key = xi < 0.38 ? 'a' : xi < 0.62 ? 'b' : 'c'; if (key !== last) { last = key; info(); }
    }, { paused: false });
    const pp = el.querySelector('[data-pp]'); const upd = () => { pp.innerHTML = playing ? X.ico('pause') + 'থামাও' : X.ico('play') + 'চালাও'; }; pp.onclick = () => { playing = !playing; upd(); A.draw(); }; upd();
    sx.oninput = () => { playing = false; upd(); xi = sx.value / 100; clock = xi; info(); A.draw(); };
    C4.drag3d(c, view, () => A.draw());
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(500, w * 1.2)); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
