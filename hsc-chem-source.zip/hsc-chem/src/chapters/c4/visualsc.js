/* Chapter 4 visuals part 12 — buffer solutions (4.13) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, TX = C4.tx, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
const UI = [[0, [190, 20, 30]], [2, [230, 70, 40]], [3.5, [245, 140, 40]], [5, [240, 215, 50]], [6.5, [150, 200, 60]], [7.5, [50, 160, 70]], [9, [30, 140, 160]], [11, [40, 80, 200]], [14, [100, 40, 150]]];
const uiCol = (p, a = 1) => { p = Math.max(0, Math.min(14, p)); let i = 0; while (i < UI.length - 2 && p > UI[i + 1][0]) i++; const [p0, c0] = UI[i], [p1, c1] = UI[i + 1], f = (p - p0) / (p1 - p0); return `rgba(${c0.map((v, k) => Math.round(v + (c1[k] - v) * f)).join(',')},${a})`; };

/* buffer systems: acid-form charge z, pKa, Q from composition */
const BUF = {
  ac: { nm: 'CH₃COOH / CH₃COONa', pKa: 4.74, z: 0, Q: (cs, ca) => cs, acid: 'CH₃COOH', base: 'CH₃COO⁻', ca: 'CH3COOH', cb: 'CH3COO-' },
  nh: { nm: 'NH₃ / NH₄Cl', pKa: 9.26, z: 1, Q: (cs, ca) => -cs, acid: 'NH₄⁺', base: 'NH₃', ca: 'NH4+', cb: 'NH3' },
  ph: { nm: 'NaH₂PO₄ / Na₂HPO₄', pKa: 7.21, z: -1, Q: (cs, ca) => ca + 2 * cs, acid: 'H₂PO₄⁻', base: 'HPO₄²⁻', ca: 'H2PO4-', cb: 'HPO4^2-' }
};
// returns pH for buffer (acid form conc ca, base form cs, in V0 mL) after adding net strong base mmol nb (negative = acid)
const bufPH = (B, ca, cs, V0, nb) => {
  const Vt = (V0 + Math.abs(nb) * 0) / 1000, Ct = (ca + cs) * V0 / 1000 / Vt, Q = (B.Q(cs, ca) * V0 / 1000 + nb / 1000) / Vt, Ka = Math.pow(10, -B.pKa);
  let lo = 1e-15, hi = 10; for (let i = 0; i < 90; i++) { const h = Math.sqrt(lo * hi), aHA = h / (h + Ka), aA = 1 - aHA, f = Q + h + Ct * (B.z * aHA + (B.z - 1) * aA) - 1e-14 / h; if (f > 0) hi = h; else lo = h; } return -Math.log10(Math.sqrt(lo * hi));
};
const waterPH = (V0, nb) => { const c = nb / V0; const x = Math.abs(c); const h = (x + Math.sqrt(x * x + 4e-14)) / 2; return nb >= 0 ? 14 + Math.log10(h) : -Math.log10(h); };

/* ======================= ৪.১৩ বাফার বনাম পানি ======================= */
V.c4_buffer = {
  t: 'বাফার বনাম পানি: এসিড ও ক্ষার যোগে pH মিটারের পাঠ, বাফার ক্ষমতা এবং হেন্ডারসন সমীকরণ', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে ১০০ mL বিশুদ্ধ পানি, ডানে ১০০ mL বাফার (ধরন, ঘনমাত্রা ও অনুপাত স্লাইডারে)। "+ HCl" বা "+ NaOH" চাপলে প্রতিবার ০.৫ mmol তীব্র এসিড/ক্ষার ফোঁটা হিসেবে দুটিতেই পড়ে — ডিজিটাল pH মিটার ও সার্বজনীন নির্দেশকের রং দেখো: পানির pH এক ফোঁটাতেই কয়েক একক লাফায়, বাফারের প্রায় স্থির। নিচের লেখচিত্রে সম্পূর্ণ বক্ররেখা — বাফারের সমতল অঞ্চল (pK_a ± ১) এবং মজুত শেষ হলে খাড়া পতন/উত্থান; বিন্দুগুলো তোমার যোগ করা অবস্থা। ঘনমাত্রা বাড়ালে সমতল অঞ্চল চওড়া হয় — বাফার ক্ষমতা বেশি।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('b', [['ac', 'অ্যাসিটেট'], ['nh', 'অ্যামোনিয়া'], ['ph', 'ফসফেট']], 'ac')}</div><div class="grid2"><label class="small">প্রতিটি উপাদানের গড় ঘনমাত্রা = <b data-cv></b> M<input type="range" min="0.01" max="0.3" step="0.01" value="0.1" data-c></label><label class="small">log([লবণ]/[এসিড]) = <b data-rv></b><input type="range" min="-1" max="1" step="0.05" value="0" data-r></label></div>${X.cv('বাফার ও পানিতে এসিড-ক্ষার যোগের তুলনা')}<div class="ctl"><button class="btn sm" data-a>+ HCl (০.৫ mmol)</button><button class="btn sm" data-bb>+ NaOH (০.৫ mmol)</button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 400 : 480;
    let L = X.fit(c, hf), key = 'ac', cm = 0.1, lr = 0, nb = 0, drops = [], disp = [7, 4.74];
    const comp = () => { const r = Math.pow(10, lr), ca = 2 * cm / (1 + r), cs = 2 * cm - ca; return { ca, cs }; };
    const cur = () => { const { ca, cs } = comp(); return [waterPH(100, nb), bufPH(BUF[key], ca, cs, 100, nb)]; };
    const geo = () => { const W = L.W, H = L.H, bw = Math.min(150, W / 2 - 50); return { b: [[W / 4 - bw / 2, 60, bw, 120], [3 * W / 4 - bw / 2, 60, bw, 120]], g: [52, 228, W - 72, H - 270] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo();
      ['বিশুদ্ধ পানি', 'বাফার'].forEach((nm, k) => {
        const [x, y, w, h] = G.b[k], p = disp[k];
        g.fillStyle = uiCol(p, 0.75); g.fillRect(x, y + 20, w, h - 20); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x - 4, y + 2); g.lineTo(x, y + 6); g.lineTo(x, y + h); g.lineTo(x + w, y + h); g.lineTo(x + w, y + 6); g.lineTo(x + w + 4, y + 2); g.stroke();
        // pH meter
        const mx = x + w - 6, my = y - 46; g.fillStyle = col.s2; g.strokeStyle = col.fg; g.lineWidth = 1.2; if (g.roundRect) { g.beginPath(); g.roundRect(mx - 56, my, 64, 30, 5); g.fill(); g.stroke(); } else { g.fillRect(mx - 56, my, 64, 30); g.strokeRect(mx - 56, my, 64, 30); }
        g.fillStyle = '#103020'; g.fillRect(mx - 52, my + 4, 56, 22); g.fillStyle = '#6dff9e'; g.font = `bold 14px ${col.mono}`; g.textAlign = 'center'; g.fillText(p.toFixed(2), mx - 24, my + 20);
        g.strokeStyle = col.fg; g.beginPath(); g.moveTo(mx - 24, my + 30); g.lineTo(x + w * 0.7, y + 40); g.lineTo(x + w * 0.7, y + h - 14); g.stroke(); g.fillStyle = col.s3; g.fillRect(x + w * 0.7 - 3, y + h - 22, 6, 10);
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.fillText(nm, x + w / 2, y + h + 16); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(k ? BUF[key].nm : '১০০ mL', x + w / 2, y + h + 29);
      });
      drops.forEach(d => { const [x, y, w] = G.b[d.k]; g.fillStyle = d.acid ? '#e0402e' : '#2d6fd6'; g.beginPath(); g.arc(x + w * 0.35, y - 40 + d.y * 64, 4, 0, 7); g.fill(); });
      // full curves
      const { ca, cs } = comp(), [gx, gy, gw, gh] = G.g, xm = 30;
      const P = cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: -xm, xmax: xm, ymin: 0, ymax: 14, col, xt: [-30, -20, -10, 0, 10, 20, 30], yt: [0, 2, 4, 6, 8, 10, 12, 14], fx: v => v < 0 ? `HCl ${bn(-v)}` : v > 0 ? `NaOH ${bn(v)}` : '০', xl: 'যোগ করা mmol', yl: 'pH', ylx: 30 });
      const pk = BUF[key].pKa; g.fillStyle = 'rgba(46,157,78,.1)'; g.fillRect(gx, P.Y(pk + 1), gw, P.Y(pk - 1) - P.Y(pk + 1)); g.fillStyle = '#2e9d4e'; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('pK_a ± ১', gx + 4, P.Y(pk + 1) + 10);
      const pw = [], pb = []; for (let v = -xm; v <= xm + 0.001; v += 0.25) { pw.push([P.X(v), P.Y(waterPH(100, v))]); pb.push([P.X(v), P.Y(bufPH(BUF[key], ca, cs, 100, v))]); }
      path(g, pw, '#9aa3ad', 2); path(g, pb, '#7b3fa0', 2.8);
      const cp = cur(); ball(g, P.X(nb), P.Y(cp[0]), 5, '#9aa3ad', '#fff'); ball(g, P.X(nb), P.Y(cp[1]), 5.5, '#7b3fa0', '#e2c7ff');
      g.fillStyle = '#7b3fa0'; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText('বাফার', gx + gw, P.Y(bufPH(BUF[key], ca, cs, 100, xm)) - 6); g.fillStyle = '#8a96a3'; g.fillText('পানি', gx + gw, P.Y(waterPH(100, xm)) + 14);
      const cap = BUF[key].z === 1 ? cs * 100 : ca * 100; void cap;
    };
    const info = () => {
      const { ca, cs } = comp(), cp = cur(), B = BUF[key];
      q('[data-cv]').textContent = fx(cm, 2); q('[data-rv]').textContent = fx(lr, 2);
      const nS = cs * 100, nA = ca * 100;
      out.innerHTML = TXB(`\\mathrm{pH} = \\mathrm{p}K_a + \\log\\dfrac{[\\ce{${B.cb}}]}{[\\ce{${B.ca}}]} = ${B.pKa} + \\log\\dfrac{${(nS + nb).toFixed(1)}}{${(nA - nb).toFixed(1)}}`) +
        TXB(`\\text{যোগ}: ${nb < 0 ? `${(-nb).toFixed(1)}\\ \\mathrm{mmol\\ HCl}` : nb > 0 ? `${nb.toFixed(1)}\\ \\mathrm{mmol\\ NaOH}` : '\\text{কিছু না}'}\\quad \\mathrm{pH}_{\\text{পানি}} = ${cp[0].toFixed(2)},\\ \\mathrm{pH}_{\\text{বাফার}} = ${cp[1].toFixed(2)}`) +
        `<div class="small">মজুত: ${B.acid} ${fx(nA, 1)} mmol (ক্ষার শোষক), ${B.base} ${fx(nS, 1)} mmol (এসিড শোষক)। ${(nb < 0 && -nb >= nS * 0.9) || (nb > 0 && nb >= nA * 0.9) ? '<b>মজুত প্রায় শেষ — বাফার ব্যর্থ হচ্ছে, pH দ্রুত বদলাচ্ছে!</b>' : 'বাফার কার্যকর — pH পরিবর্তন সামান্য।'}</div>`;
    };
    const add = (acid) => { drops.push({ k: 0, acid, y: 0 }, { k: 1, acid, y: 0 }); setTimeout(() => { nb += acid ? -0.5 : 0.5; nb = Math.max(-30, Math.min(30, nb)); info(); }, 500); };
    const A = X.anim(el, dt => { if (dt) { drops.forEach(d => { d.y += dt * 2; }); drops = drops.filter(d => d.y < 1); const cp = cur(); disp = disp.map((v, k) => v + (cp[k] - v) * Math.min(1, dt * 4)); } draw(); }, { paused: false });
    q('[data-a]').onclick = () => add(true); q('[data-bb]').onclick = () => add(false);
    q('[data-rs]').onclick = () => { nb = 0; info(); };
    X.onSeg(el, 'b', v => { key = v; nb = 0; info(); });
    q('[data-c]').oninput = e => { cm = +e.target.value; info(); };
    q('[data-r]').oninput = e => { lr = +e.target.value; info(); };
    disp = cur(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.১৩.১ বাফারের ক্রিয়া কৌশল: কণা-দৃশ্য ======================= */
V.c4_bufferMech = {
  t: 'বাফারের ক্রিয়া কৌশল: যোগ করা H⁺ কে CH₃COO⁻ এবং OH⁻ কে CH₃COOH কীভাবে আটকে ফেলে (কণা-অ্যানিমেশন)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'অ্যাসিটেট বাফারে বেগুনি ডাম্বেল = CH₃COOH (অবিয়োজিত), সবুজ = CH₃COO⁻ (লবণ থেকে), ধূসর = Na⁺ (দর্শক আয়ন)। "+ H⁺" চাপলে হলুদ H⁺ আয়ন ঢোকে এবং সবচেয়ে কাছের CH₃COO⁻ এর সাথে যুক্ত হয়ে CH₃COOH হয়ে যায়; "+ OH⁻" চাপলে নীল OH⁻ একটি CH₃COOH থেকে H টেনে নিয়ে পানি তৈরি করে, পেছনে CH₃COO⁻ থাকে। ডানে দুই রূপের সংখ্যা ও হেন্ডারসন সমীকরণে pH — অনুপাত সামান্য বদলায়, pH প্রায় স্থির। একটি রূপের মজুত শেষ হলে যোগ করা আয়ন মুক্ত থেকে যায় এবং pH হঠাৎ বদলে যায় — বাফার ব্যর্থ।',
  html: () => `${X.cv('বাফারের ক্রিয়া কৌশলের কণা-অ্যানিমেশন')}<div class="ctl"><button class="btn sm" data-h>+ H⁺ (এসিড)</button><button class="btn sm" data-o>+ OH⁻ (ক্ষার)</button><button class="btn sm" data-h5>+ ৫ H⁺</button><button class="btn sm" data-o5>+ ৫ OH⁻</button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : w * 0.8 + 210;
    let L = X.fit(c, hf), P = [], inc = [], log = [], fl = [];
    const R = X.rng(91), N0 = 10;
    const reset = () => { P = []; for (let i = 0; i < N0; i++) P.push({ k: 'HA', x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, a: R() * 6 }); for (let i = 0; i < N0; i++) P.push({ k: 'A', x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, a: R() * 6 }); for (let i = 0; i < N0; i++) P.push({ k: 'Na', x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5 }); inc = []; log = []; fl = []; };
    const cnt = k => P.filter(p => p.k === k).length;
    const freeH = () => P.filter(p => p.k === 'H').length, freeOH = () => P.filter(p => p.k === 'OH').length;
    const pH = () => { const ha = cnt('HA'), a = cnt('A'), h = freeH(), oh = freeOH(); if (h > 0) return Math.max(0.8, 2.6 - Math.log10(h)); if (oh > 0) return Math.min(13.2, 11.4 + Math.log10(oh)); if (a === 0) return 2.9; if (ha === 0) return 8.9; return 4.74 + Math.log10(a / ha); };
    const addIon = k => { inc.push({ k, x: k === 'H' ? 0.02 : 0.98, y: 0.1 + R() * 0.8, tgt: null, t: 0 }); };
    const step = dt => {
      P.forEach(p => { p.x += p.vx * dt * 0.1; p.y += p.vy * dt * 0.12; if (p.a != null) p.a += dt; if (p.x < 0.04 || p.x > 0.96) p.vx *= -1; if (p.y < 0.06 || p.y > 0.94) p.vy *= -1; });
      inc.forEach(I => {
        if (!I.tgt) { const want = I.k === 'H' ? 'A' : 'HA'; let best = null, bd = 9; P.forEach(p => { if (p.k !== want || p.busy) return; const d = (p.x - I.x) ** 2 + (p.y - I.y) ** 2; if (d < bd) { bd = d; best = p; } }); if (best) { I.tgt = best; best.busy = true; } else { P.push({ k: I.k, x: I.x, y: I.y, vx: R() - 0.5, vy: R() - 0.5 }); I.done = true; log.unshift(I.k === 'H' ? 'CH₃COO⁻ মজুত শেষ — H⁺ মুক্ত থাকল!' : 'CH₃COOH মজুত শেষ — OH⁻ মুক্ত থাকল!'); return; } }
        const T = I.tgt, dx = T.x - I.x, dy = T.y - I.y, d = Math.hypot(dx, dy); I.x += dx / (d || 1) * Math.min(d, dt * 0.6); I.y += dy / (d || 1) * Math.min(d, dt * 0.6);
        if (d < 0.02) { T.busy = false; I.done = true; fl.push({ x: T.x, y: T.y, a: 1, c: I.k === 'H' ? '#f2b705' : '#2d6fd6' }); if (I.k === 'H') { T.k = 'HA'; log.unshift('CH₃COO⁻ + H⁺ → CH₃COOH'); } else { T.k = 'A'; P.push({ k: 'W', x: T.x + 0.03, y: T.y, vx: R() - 0.5, vy: R() - 0.5, a: 0, life: 3 }); log.unshift('CH₃COOH + OH⁻ → CH₃COO⁻ + H₂O'); } }
      });
      inc = inc.filter(I => !I.done); log = log.slice(0, 3);
      P.forEach(p => { if (p.k === 'W') p.life -= dt; }); P = P.filter(p => p.k !== 'W' || p.life > 0);
      // free H+ and OH- neutralize each other
      const hs = P.filter(p => p.k === 'H'), os = P.filter(p => p.k === 'OH'); const n = Math.min(hs.length, os.length); for (let i = 0; i < n; i++) { P.splice(P.indexOf(hs[i]), 1); P.splice(P.indexOf(os[i]), 1); }
      // free H+ grabbed by any A- that appears; free OH- by HA
      fl.forEach(f => { f.a -= dt * 1.5; }); fl = fl.filter(f => f.a > 0);
    };
    const geo = () => { const W = L.W, H = L.H; return wide(W) ? { b: [10, 10, W * 0.58, H - 20], r: [W * 0.58 + 30, 10, W * 0.42 - 40, H - 20] } : { b: [10, 10, W - 20, W * 0.8 - 10], r: [10, W * 0.8 + 10, W - 20, H - W * 0.8 - 20] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo(), [bx, by, bw, bh] = G.b, p = pH();
      g.fillStyle = uiCol(p, 0.22); g.fillRect(bx, by, bw, bh); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.strokeRect(bx, by, bw, bh);
      const s = Math.max(0.85, Math.min(1.15, bw / 360)), X_ = v => bx + 10 + v * (bw - 20), Y_ = v => by + 10 + v * (bh - 20);
      P.forEach(q0 => {
        const x = X_(q0.x), y = Y_(q0.y);
        if (q0.k === 'HA') { const ca = Math.cos(q0.a) * 6 * s, sa = Math.sin(q0.a) * 6 * s; ball(g, x - ca, y - sa, 6 * s, '#5b2a86', '#c7a2ec'); ball(g, x + ca, y + sa, 3.5 * s, '#e8ecf0', '#fff'); }
        else if (q0.k === 'A') { ball(g, x, y, 7 * s, '#2e9d4e', '#c8f0d4'); g.fillStyle = col.fg; g.font = `bold ${Math.round(11 * s)}px ${col.font}`; g.textAlign = 'center'; g.fillText('−', x + 9 * s, y - 6 * s); }
        else if (q0.k === 'Na') { ball(g, x, y, 4.5 * s, '#9aa3ad', '#e4e8ec'); }
        else if (q0.k === 'H') { ball(g, x, y, 5 * s, '#f2b705', '#fff1b8'); g.strokeStyle = '#e0402e'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, 9 * s, 0, 7); g.stroke(); }
        else if (q0.k === 'OH') { ball(g, x, y, 5.5 * s, '#2d6fd6', '#a9c8ff'); g.strokeStyle = '#e0402e'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, 9 * s, 0, 7); g.stroke(); }
        else if (q0.k === 'W') { g.globalAlpha = Math.min(1, q0.life); ball(g, x, y, 4 * s, '#c0392b', '#ff9f8f'); ball(g, x - 5 * s, y + 3 * s, 2.4 * s, '#e8ecf0', '#fff'); ball(g, x + 5 * s, y + 3 * s, 2.4 * s, '#e8ecf0', '#fff'); g.globalAlpha = 1; }
      });
      inc.forEach(I => { const x = X_(I.x), y = Y_(I.y); if (I.k === 'H') ball(g, x, y, 5 * s, '#f2b705', '#fff1b8'); else ball(g, x, y, 5.5 * s, '#2d6fd6', '#a9c8ff'); g.fillStyle = col.fg; g.font = `bold ${Math.round(9 * s)}px ${col.font}`; g.textAlign = 'center'; g.fillText(I.k === 'H' ? 'H⁺' : 'OH⁻', x, y - 9 * s); });
      fl.forEach(f => { g.strokeStyle = f.c; g.globalAlpha = f.a; g.lineWidth = 2.2; g.beginPath(); g.arc(X_(f.x), Y_(f.y), 10 + (1 - f.a) * 14, 0, 7); g.stroke(); g.globalAlpha = 1; });
      // right panel: bars + pH gauge
      const [rx, ry, rw, rh] = G.r, ha = cnt('HA'), a = cnt('A'), mx = Math.max(20, ha, a);
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('মজুত', rx, ry + 12);
      [['CH₃COOH (ক্ষার শোষক)', ha, '#5b2a86'], ['CH₃COO⁻ (এসিড শোষক)', a, '#2e9d4e'], ['মুক্ত H⁺ / OH⁻', freeH() + freeOH(), '#e0402e']].forEach(([nm, v, cc], i) => { const y = ry + 22 + i * 30; g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.fillText(`${nm}: ${bn(v)}`, rx, y + 8); g.fillStyle = col.s3; g.fillRect(rx, y + 12, rw, 9); g.fillStyle = cc; g.fillRect(rx, y + 12, rw * v / mx, 9); });
      const gy = ry + 120; g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.fillText(`pH ≈ ${fx(p, 2)}`, rx, gy);
      for (let k = 0; k < 140; k++) { g.fillStyle = uiCol(k / 10); g.fillRect(rx + k / 140 * rw, gy + 8, rw / 140 + 1, 10); }
      g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText('▲', rx + p / 14 * rw, gy + 32);
      g.textAlign = 'left'; g.font = `9.5px ${col.font}`; g.fillStyle = col.mu; log.forEach((t, i) => g.fillText(t, rx, gy + 50 + i * 14));
    };
    const info = () => {
      const ha = cnt('HA'), a = cnt('A');
      out.innerHTML = TXB(`\\mathrm{pH} = 4.74 + \\log\\dfrac{n(\\ce{CH3COO-})}{n(\\ce{CH3COOH})} = 4.74 + \\log\\dfrac{${a}}{${ha}}${a && ha ? ` = ${(4.74 + Math.log10(a / ha)).toFixed(2)}` : ''}`) + TXB(`\\ce{CH3COO- + H+ -> CH3COOH}\\qquad \\ce{CH3COOH + OH- -> CH3COO- + H2O}`) +
        `<div class="small">${freeH() ? 'এসিড শোষক (CH₃COO⁻) শেষ — মুক্ত H⁺ জমছে, pH হঠাৎ নেমে গেছে। এটিই বাফার ক্ষমতার সীমা।' : freeOH() ? 'ক্ষার শোষক (CH₃COOH) শেষ — মুক্ত OH⁻ জমছে, pH হঠাৎ বেড়ে গেছে।' : 'প্রতিটি যোগ করা আয়ন দুর্বল এসিড বা পানিতে আবদ্ধ — অনুপাত সামান্য বদলায়, pH প্রায় স্থির।'}</div>`;
    };
    let it = 0;
    const A = X.anim(el, dt => { if (dt) { step(dt); it += dt; if (it > 0.3) { it = 0; info(); } } draw(); }, { paused: false });
    q('[data-h]').onclick = () => addIon('H'); q('[data-o]').onclick = () => addIon('OH');
    q('[data-h5]').onclick = () => { for (let i = 0; i < 5; i++) setTimeout(() => addIon('H'), i * 150); };
    q('[data-o5]').onclick = () => { for (let i = 0; i < 5; i++) setTimeout(() => addIon('OH'), i * 150); };
    q('[data-rs]').onclick = () => { reset(); info(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
