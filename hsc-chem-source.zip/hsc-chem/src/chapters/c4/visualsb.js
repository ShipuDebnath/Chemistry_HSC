/* Chapter 4 visuals part 11 — pH scale, pH calculations, salt hydrolysis (4.12) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, TX = C4.tx, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
const UI = [[0, [190, 20, 30]], [2, [230, 70, 40]], [3.5, [245, 140, 40]], [5, [240, 215, 50]], [6.5, [150, 200, 60]], [7.5, [50, 160, 70]], [9, [30, 140, 160]], [11, [40, 80, 200]], [14, [100, 40, 150]]];
const uiCol = (p, a = 1) => { p = Math.max(0, Math.min(14, p)); let i = 0; while (i < UI.length - 2 && p > UI[i + 1][0]) i++; const [p0, c0] = UI[i], [p1, c1] = UI[i + 1], f = (p - p0) / (p1 - p0); return `rgba(${c0.map((v, k) => Math.round(v + (c1[k] - v) * f)).join(',')},${a})`; };
const sup = e => '১০' + X.sup(e);
const sciTxt = v => { if (!isFinite(v) || v <= 0) return '০'; const e = Math.floor(Math.log10(v)); if (e >= -2 && e <= 1) return bn(+v.toPrecision(3)); return bn((v / Math.pow(10, e)).toFixed(2)) + '×১০' + X.sup(e); };
const INDS = [['মিথাইল অরেঞ্জ', 3.1, 4.4, [220, 40, 40], [240, 200, 40]], ['মিথাইল রেড', 4.4, 6.2, [220, 40, 60], [240, 210, 50]], ['লিটমাস', 5.0, 8.0, [210, 50, 60], [60, 80, 200]], ['ব্রোমোথাইমল ব্লু', 6.0, 7.6, [235, 210, 50], [40, 90, 200]], ['ফেনলফথ্যালিন', 8.2, 10.0, [250, 250, 250], [230, 60, 160]]];
const indCol = (I, p) => { const f = Math.max(0, Math.min(1, (p - I[1]) / (I[2] - I[1]))); return `rgb(${I[3].map((v, k) => Math.round(v + (I[4][k] - v) * f)).join(',')})`; };

/* ======================= ৪.১২ pH স্কেল ======================= */
const ITEMS = [[0, '১ M HCl'], [1.5, 'পাকস্থলীর রস'], [2.3, 'লেবুর রস'], [2.9, 'ভিনেগার'], [3.2, 'কোমল পানীয়'], [4.2, 'টমেটো'], [5, 'কফি'], [5.6, 'বৃষ্টির পানি'], [6.6, 'দুধ'], [7, 'বিশুদ্ধ পানি'], [7.4, 'রক্ত'], [8.1, 'সমুদ্রের পানি'], [8.3, 'খাবার সোডা'], [10.5, 'মিল্ক অব ম্যাগনেশিয়া'], [11.5, 'অ্যামোনিয়া'], [12.5, 'ব্লিচ'], [14, '১ M NaOH']];
V.c4_phScale = {
  t: 'pH স্কেল: দৈনন্দিন পদার্থ, [H⁺] ও [OH⁻] এর লগ স্কেল, সার্বজনীন ও অন্যান্য নির্দেশকের বর্ণ', k: ['int', '2d', 'calc'],
  cap: 'উপরের রঙিন স্কেলটি সার্বজনীন নির্দেশকের বর্ণ (লাল → সবুজ → বেগুনি); নিচে দৈনন্দিন পদার্থের pH চিহ্নিত। স্লাইডারে pH বদলালে বিকারের দ্রবণের রং, [H⁺] ও [OH⁻] এর দণ্ড (লগ স্কেলে — একটি বাড়লে অন্যটি কমে, গুণফল সবসময় ১০⁻¹⁴) এবং পাঁচটি নির্দেশকের বর্ণ দেখা যায়। প্রতিটি নির্দেশক কেবল তার নির্দিষ্ট পরিসরে রং বদলায়। "তুলনা" স্লাইডারে দ্বিতীয় pH দিলে দুটির অম্লত্বের অনুপাত (১০ এর ঘাত) দেখায়।',
  html: () => `${X.cv('pH স্কেল ও নির্দেশকের বর্ণ')}<div class="grid2" style="margin-top:8px"><label class="small">pH = <b data-pv></b><input type="range" min="0" max="14" step="0.1" value="2.9" data-p></label><label class="small">তুলনা pH = <b data-qv></b><input type="range" min="0" max="14" step="0.1" value="5" data-q></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : 470;
    let L = X.fit(c, hf), pH = 2.9, p2 = 5;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const x0 = 20, x1 = W - 20, XP = p => x0 + p / 14 * (x1 - x0), sy = 26;
      for (let p = 0; p < 14; p += 0.05) { g.fillStyle = uiCol(p); g.fillRect(XP(p), sy, XP(0.05) - x0 + 1, 22); }
      g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(x0, sy, x1 - x0, 22);
      for (let p = 0; p <= 14; p++) { g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(p), XP(p), sy - 5); }
      g.font = `9px ${col.font}`; g.fillStyle = col.mu; g.textAlign = 'left'; g.fillText('← অম্লীয়', x0, sy + 34); g.textAlign = 'right'; g.fillText('ক্ষারীয় →', x1, sy + 34); g.textAlign = 'center'; g.fillText('নিরপেক্ষ', XP(7), sy + 34);
      // items staggered
      const iy = sy + 44, rows = wide(W) ? 3 : 4;
      ITEMS.forEach(([p, nm], i) => { const r = i % rows, y = iy + r * 13; g.strokeStyle = col.line || col.mu; g.lineWidth = 0.8; g.beginPath(); g.moveTo(XP(p), sy + 22); g.lineTo(XP(p), y - 8); g.stroke(); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = p < 1 ? 'left' : p > 13 ? 'right' : 'center'; g.fillText(nm, XP(p), y); });
      // markers
      [[pH, col.fg, '▼'], [p2, col.mu, '▽']].forEach(([p, cc, s]) => { g.fillStyle = cc; g.font = `bold 13px ${col.font}`; g.textAlign = 'center'; g.fillText(s, XP(p), sy - 13 + 0); });
      // lower panel
      const ly = iy + rows * 13 + 12, lh = H - ly - 6;
      const bw = Math.min(110, W * 0.22), bx = x0;
      g.fillStyle = uiCol(pH, 0.85); g.fillRect(bx, ly + lh * 0.3, bw, lh * 0.7 - 4); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(bx - 4, ly + lh * 0.2); g.lineTo(bx, ly + lh * 0.24); g.lineTo(bx, ly + lh - 4); g.lineTo(bx + bw, ly + lh - 4); g.lineTo(bx + bw, ly + lh * 0.24); g.lineTo(bx + bw + 4, ly + lh * 0.2); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('সার্বজনীন নির্দেশক', bx + bw / 2, ly + lh * 0.16);
      // H+ / OH- log bars
      const gx = bx + bw + 30, gw = wide(W) ? (W - gx) * 0.45 : W - gx - 20, bh = 14;
      [['[H⁺]', -pH, '#f2b705'], ['[OH⁻]', -(14 - pH), '#2d6fd6']].forEach(([nm, e, cc], i) => { const y = ly + 10 + i * 34; g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`${nm} = ${sciTxt(Math.pow(10, e))} M`, gx, y); g.fillStyle = col.s3; g.fillRect(gx, y + 5, gw, bh); g.fillStyle = cc; g.fillRect(gx, y + 5, gw * (14 + e) / 14, bh); g.strokeStyle = col.fg; g.lineWidth = 0.8; g.strokeRect(gx, y + 5, gw, bh); });
      g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'left'; g.fillText('দণ্ডের দৈর্ঘ্য: log স্কেল, ১০⁻¹⁴ থেকে ১', gx, ly + 82);
      // indicators
      const ix = wide(W) ? gx + gw + 24 : gx, iyy = wide(W) ? ly + 2 : ly + 96, iw = wide(W) ? W - ix - 20 : W - ix - 20;
      INDS.forEach((I, k) => { const y = iyy + k * 17; g.fillStyle = indCol(I, pH); g.fillRect(ix, y, 26, 12); g.strokeStyle = col.fg; g.strokeRect(ix, y, 26, 12); g.fillStyle = col.fg; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`${I[0]} (${fx(I[1], 1)}–${fx(I[2], 1)})`, ix + 32, y + 10); });
    };
    const info = () => {
      q('[data-pv]').textContent = fx(pH, 1); q('[data-qv]').textContent = fx(p2, 1);
      const d = p2 - pH, r = Math.pow(10, Math.abs(d));
      out.innerHTML = TXB(`\\mathrm{pH} = ${pH.toFixed(1)}\\;\\Rightarrow\\;[\\ce{H+}] = 10^{-${pH.toFixed(1)}} = ${sci(Math.pow(10, -pH), 2)}\\ \\mathrm{M},\\quad \\mathrm{pOH} = ${(14 - pH).toFixed(1)}`) +
        TXB(`\\dfrac{[\\ce{H+}]_{\\mathrm{pH}\\,${Math.min(pH, p2).toFixed(1)}}}{[\\ce{H+}]_{\\mathrm{pH}\\,${Math.max(pH, p2).toFixed(1)}}} = 10^{${Math.abs(d).toFixed(1)}} = ${sci(r, 2)}`) +
        `<div class="small">${pH < 7 ? 'অম্লীয়' : pH > 7 ? 'ক্ষারীয়' : 'নিরপেক্ষ'} দ্রবণ। ${Math.abs(d) >= 0.1 ? `pH ${fx(Math.min(pH, p2), 1)} এর দ্রবণ pH ${fx(Math.max(pH, p2), 1)} এর চেয়ে ${r >= 1000 ? sciTxt(r) : fx(r, r < 10 ? 1 : 0)} গুণ বেশি অম্লীয়।` : ''}</div>`;
    };
    q('[data-p]').oninput = e => { pH = +e.target.value; info(); draw(); };
    q('[data-q]').oninput = e => { p2 = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৪.১২ pH হিসাব: মিশ্রণ ও লঘুকরণ ======================= */
const hStrong = c => (c + Math.sqrt(c * c + 4e-14)) / 2;
const hWeak = (K, c) => { let lo = 1e-14, hi = c + 1e-6; for (let i = 0; i < 80; i++) { const h = Math.sqrt(lo * hi), f = K * c / (K + h) + 1e-14 / h - h; if (f > 0) lo = h; else hi = h; } return Math.sqrt(lo * hi); };
V.c4_phCalc = {
  t: 'pH হিসাব কর্মশালা: তীব্র এসিড-ক্ষার মিশ্রণ ও লঘুকরণে তীব্র বনাম দুর্বল এসিডের pH (১০⁻⁸ M HCl সহ)', k: ['anim', 'int', '2d', 'calc'],
  cap: '"মিশ্রণ" এ এসিড ও ক্ষারের ঘনমাত্রা ও আয়তন বেছে নাও — দণ্ডচিত্রে H⁺ ও OH⁻ এর mmol পরস্পরকে বাতিল করে, আধিক্য অংশ মোট আয়তনে ছড়িয়ে pH ঠিক করে; মিশ্রিত দ্রবণের রং সার্বজনীন নির্দেশকে। H₂SO₄ ও Ba(OH)₂ এ প্রতি অণুতে দুটি H⁺/OH⁻। "লঘুকরণ" এ 0.1 M HCl ও 0.1 M CH₃COOH কে ১০ⁿ গুণ লঘু করলে pH কীভাবে বদলায়: HCl প্রতি ১০ গুণে ১ একক, অ্যাসিটিক প্রায় ½ একক; দুটিই ৭ এর দিকে এগোয় কিন্তু কখনো ৭ পার হয় না (পানির H⁺)।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['mix', 'মিশ্রণ'], ['dil', 'লঘুকরণ']], 'mix')}</div><div data-p1 class="grid2"><label class="small">এসিড ${X.seg('a', [['1', 'HCl'], ['2', 'H₂SO₄']], '1')}</label><label class="small">ক্ষার ${X.seg('b', [['1', 'NaOH'], ['2', 'Ba(OH)₂']], '1')}</label><label class="small">এসিড: <b data-cav></b> M, <b data-vav></b> mL<input type="range" min="0.01" max="0.5" step="0.01" value="0.1" data-ca><input type="range" min="5" max="50" step="1" value="25" data-va></label><label class="small">ক্ষার: <b data-cbv></b> M, <b data-vbv></b> mL<input type="range" min="0.01" max="0.5" step="0.01" value="0.1" data-cb><input type="range" min="0" max="60" step="0.5" value="15" data-vb></label></div><div data-p2 style="display:none"><label class="small">লঘুকরণ: ১০ⁿ গুণ, n = <b data-nv></b><input type="range" min="0" max="10" step="0.1" value="7" data-n></label></div>${X.cv('pH হিসাব: মিশ্রণ ও লঘুকরণ')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = () => 260;
    let L = X.fit(c, hf), mode = 'mix', na = 1, nb = 1, ca = 0.1, va = 25, cb = 0.1, vb = 15, n = 7;
    const mixCalc = () => { const H = na * ca * va, OH = nb * cb * vb, Vt = va + vb, ex = H - OH; let h; if (Math.abs(ex) / Vt < 1e-6) h = 1e-7; else if (ex > 0) h = hStrong(ex / Vt); else h = 1e-14 / hStrong(-ex / Vt); return { H, OH, Vt, ex, pH: -Math.log10(h) }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      if (mode === 'mix') {
        const m = mixCalc(), mx = Math.max(m.H, m.OH, 1), bx = 30, bw = W - 200 > 200 ? W - 200 : W - 60, by = 30;
        const sc = v => v / mx * bw;
        g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`H⁺ = ${fx(m.H, 2)} mmol`, bx, by - 6);
        g.fillStyle = '#f2b705'; g.fillRect(bx, by, sc(m.H), 22); g.fillStyle = col.fg; g.fillText(`OH⁻ = ${fx(m.OH, 2)} mmol`, bx, by + 50);
        g.fillStyle = '#2d6fd6'; g.fillRect(bx, by + 56, sc(m.OH), 22);
        const cm = Math.min(m.H, m.OH); g.fillStyle = 'rgba(128,128,128,.55)'; g.fillRect(bx, by, sc(cm), 22); g.fillRect(bx, by + 56, sc(cm), 22);
        g.strokeStyle = col.fg; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(bx + sc(cm), by - 2); g.lineTo(bx + sc(cm), by + 80); g.stroke(); g.setLineDash([]);
        g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(`প্রশমিত (H⁺ + OH⁻ → H₂O): ${fx(cm, 2)} mmol`, bx, by + 96);
        g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.fillText(m.ex > 1e-9 ? `আধিক্য H⁺ = ${fx(m.ex, 2)} mmol` : m.ex < -1e-9 ? `আধিক্য OH⁻ = ${fx(-m.ex, 2)} mmol` : 'সম্পূর্ণ প্রশমন', bx, by + 114);
        // beaker result
        const rx = W - 130, rw = 100, ry = 40, rh = 150; if (W - 200 > 200) { g.fillStyle = uiCol(m.pH, 0.85); g.fillRect(rx, ry + rh * (1 - Math.min(1, m.Vt / 110)), rw, rh * Math.min(1, m.Vt / 110)); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(rx - 4, ry - 4); g.lineTo(rx, ry); g.lineTo(rx, ry + rh); g.lineTo(rx + rw, ry + rh); g.lineTo(rx + rw, ry); g.lineTo(rx + rw + 4, ry - 4); g.stroke(); g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText(`pH ${fx(m.pH, 2)}`, rx + rw / 2, ry + rh + 18); g.font = `10px ${col.font}`; g.fillText(`${fx(m.Vt, 1)} mL`, rx + rw / 2, ry - 10); }
        // pH strip
        const sy = H - 34, x0 = 30, x1 = W - 30; for (let p = 0; p < 14; p += 0.1) { g.fillStyle = uiCol(p); g.fillRect(x0 + p / 14 * (x1 - x0), sy, (x1 - x0) / 140 + 1, 10); } g.fillStyle = col.fg; g.font = `bold 12px ${col.font}`; g.textAlign = 'center'; g.fillText('▲', x0 + m.pH / 14 * (x1 - x0), sy + 24); [0, 7, 14].forEach(p => { g.font = `9px ${col.font}`; g.fillText(bn(p), x0 + p / 14 * (x1 - x0), sy - 3); });
      } else {
        const P = cplot(g, { x0: 52, y0: 14, w: W - 72, h: H - 52, xmin: 0, xmax: 10, ymin: 0, ymax: 8, col, xt: [0, 2, 4, 6, 8, 10], yt: [0, 1, 2, 3, 4, 5, 6, 7, 8], fx: v => sup(v), xl: 'লঘুকরণ (গুণ)', yl: 'pH', ylx: 30 });
        g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(52, P.Y(7)); g.lineTo(W - 20, P.Y(7)); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('pH ৭ — কখনো পার হয় না', W - 22, P.Y(7) - 4);
        const a = [], b = [], wrong = []; for (let k = 0; k <= 10.001; k += 0.05) { const cc = 0.1 / Math.pow(10, k); a.push([P.X(k), P.Y(-Math.log10(hStrong(cc)))]); b.push([P.X(k), P.Y(-Math.log10(hWeak(1.8e-5, cc)))]); wrong.push([P.X(k), P.Y(Math.min(8, 1 + k))]); }
        path(g, wrong, '#e0402e', 1.2, [2, 3]); path(g, a, '#2e9d4e', 2.6); path(g, b, '#7b3fa0', 2.6);
        g.fillStyle = '#e0402e'; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('ভুল: −log c (পানির H⁺ বাদে)', P.X(6.2), P.Y(7.7));
        const cc = 0.1 / Math.pow(10, n); ball(g, P.X(n), P.Y(-Math.log10(hStrong(cc))), 5, '#2e9d4e', '#c8f0d4'); ball(g, P.X(n), P.Y(-Math.log10(hWeak(1.8e-5, cc))), 5, '#7b3fa0', '#e2c7ff');
        g.fillStyle = '#2e9d4e'; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('HCl', P.X(0.3), P.Y(1.4)); g.fillStyle = '#7b3fa0'; g.fillText('CH₃COOH', P.X(0.3), P.Y(3.3));
      }
    };
    const info = () => {
      q('[data-p1]').style.display = mode === 'mix' ? '' : 'none'; q('[data-p2]').style.display = mode === 'dil' ? '' : 'none';
      if (mode === 'mix') {
        const m = mixCalc(); q('[data-cav]').textContent = fx(ca, 2); q('[data-vav]').textContent = bn(va); q('[data-cbv]').textContent = fx(cb, 2); q('[data-vbv]').textContent = fx(vb, 1);
        out.innerHTML = TXB(`n(\\ce{H+}) = ${na}\\times${ca.toFixed(2)}\\times${va} = ${m.H.toFixed(2)}\\ \\mathrm{mmol};\\quad n(\\ce{OH-}) = ${nb}\\times${cb.toFixed(2)}\\times${vb} = ${m.OH.toFixed(2)}\\ \\mathrm{mmol}`) +
          (Math.abs(m.ex) < 1e-9 ? TXB(`\\text{সম্পূর্ণ প্রশমন}\\;\\Rightarrow\\;\\mathrm{pH} = 7.00`) : TXB(`[\\ce{${m.ex > 0 ? 'H+' : 'OH-'}}] = \\dfrac{${Math.abs(m.ex).toFixed(2)}}{${m.Vt.toFixed(1)}} = ${sci(Math.abs(m.ex) / m.Vt, 2)}\\ \\mathrm{M}\\;\\Rightarrow\\;\\mathrm{pH} = ${m.pH.toFixed(2)}`)) +
          `<div class="small">মিশ্রণে মোট আয়তন (${fx(m.Vt, 1)} mL) দিয়ে ভাগ করতে ভুলবে না। ${na === 2 || nb === 2 ? 'দ্বিক্ষারকীয়/দ্বি-অম্লিক পদার্থে mmol গণনায় ২ দিয়ে গুণ করা হয়েছে।' : ''}</div>`;
      } else {
        const cc = 0.1 / Math.pow(10, n), hs = hStrong(cc), hw = hWeak(1.8e-5, cc); q('[data-nv]').textContent = fx(n, 1);
        out.innerHTML = TXB(`c = ${sci(cc, 2)}\\ \\mathrm{M}:\\quad \\mathrm{pH}_{\\ce{HCl}} = ${(-Math.log10(hs)).toFixed(2)},\\quad \\mathrm{pH}_{\\ce{CH3COOH}} = ${(-Math.log10(hw)).toFixed(2)}`) + TXB(`[\\ce{H+}]_{\\ce{HCl}} = \\dfrac{c + \\sqrt{c^2 + 4K_w}}{2}`) +
          `<div class="small">${cc < 1e-6 ? 'এত লঘু দ্রবণে পানির নিজস্ব H⁺ (১০⁻⁷ M) প্রধান — pH ৭ এর খুব কাছে, কিন্তু এসিডের দ্রবণ কখনো ক্ষারীয় হয় না।' : 'তীব্র এসিড প্রতি ১০ গুণ লঘুতে pH ১ একক বাড়ে; দুর্বল এসিড প্রায় ০.৫ একক (√১০ গুণ [H⁺] কমে)।'}</div>`;
      }
    };
    X.onSeg(el, 'm', v => { mode = v; info(); draw(); });
    X.onSeg(el, 'a', v => { na = +v; info(); draw(); }); X.onSeg(el, 'b', v => { nb = +v; info(); draw(); });
    [['ca', v => ca = v], ['va', v => va = v], ['cb', v => cb = v], ['vb', v => vb = v], ['n', v => n = v]].forEach(([k, f]) => { q(`[data-${k}]`).oninput = e => { f(+e.target.value); info(); draw(); }; });
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৪.১২.১ লবণের আর্দ্র বিশ্লেষণ ======================= */
// [name, type, Ka (of conjugate acid of anion) , Kb (of conjugate base of cation), cation label, anion label, cation hydrolyses?, anion hydrolyses?]
const SALTS = [
  { nm: 'NaCl', t: 'তীব্র এসিড + তীব্র ক্ষারক', cat: 'Na⁺', an: 'Cl⁻', Ka: null, Kb: null, eq: '\\ce{Na+ + Cl- + H2O -> \\text{কোনো বিক্রিয়া নেই}}' },
  { nm: 'CH₃COONa', t: 'দুর্বল এসিড + তীব্র ক্ষারক', cat: 'Na⁺', an: 'CH₃COO⁻', Ka: 1.8e-5, Kb: null, eq: '\\ce{CH3COO- + H2O <=> CH3COOH + OH-}' },
  { nm: 'NaCN', t: 'দুর্বল এসিড + তীব্র ক্ষারক', cat: 'Na⁺', an: 'CN⁻', Ka: 4.9e-10, Kb: null, eq: '\\ce{CN- + H2O <=> HCN + OH-}' },
  { nm: 'Na₂CO₃', t: 'দুর্বল এসিড + তীব্র ক্ষারক', cat: 'Na⁺', an: 'CO₃²⁻', Ka: 4.8e-11, Kb: null, eq: '\\ce{CO3^2- + H2O <=> HCO3- + OH-}' },
  { nm: 'NH₄Cl', t: 'তীব্র এসিড + দুর্বল ক্ষারক', cat: 'NH₄⁺', an: 'Cl⁻', Ka: null, Kb: 1.8e-5, eq: '\\ce{NH4+ + H2O <=> NH3 + H3O+}' },
  { nm: 'CH₃COONH₄', t: 'দুর্বল এসিড + দুর্বল ক্ষারক', cat: 'NH₄⁺', an: 'CH₃COO⁻', Ka: 1.8e-5, Kb: 1.8e-5, eq: '\\ce{CH3COO- + NH4+ + H2O <=> CH3COOH + NH4OH}' },
  { nm: 'NH₄CN', t: 'দুর্বল এসিড + দুর্বল ক্ষারক', cat: 'NH₄⁺', an: 'CN⁻', Ka: 4.9e-10, Kb: 1.8e-5, eq: '\\ce{CN- + NH4+ + H2O <=> HCN + NH4OH}' }
];
const saltPH = (S, c) => {
  if (!S.Ka && !S.Kb) return { pH: 7, h: 0, Kh: 0 };
  if (S.Ka && !S.Kb) { const Kh = 1e-14 / S.Ka, h = (-Kh + Math.sqrt(Kh * Kh + 4 * Kh * c)) / (2 * c), oh = c * h; return { pH: 14 + Math.log10(oh + 1e-7 * 0), h, Kh }; }
  if (!S.Ka && S.Kb) { const Kh = 1e-14 / S.Kb, h = (-Kh + Math.sqrt(Kh * Kh + 4 * Kh * c)) / (2 * c), hp = c * h; return { pH: -Math.log10(hp), h, Kh }; }
  const Kh = 1e-14 / (S.Ka * S.Kb), r = Math.sqrt(Kh), h = r / (1 + r); return { pH: 7 + 0.5 * (-Math.log10(S.Ka)) - 0.5 * (-Math.log10(S.Kb)), h, Kh };
};
V.c4_hydrolysis = {
  t: 'লবণের আর্দ্র বিশ্লেষণ: আয়নের সাথে পানির বিক্রিয়া, দ্রবণের রং, Kh, h ও pH (চার প্রকার লবণ)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'একটি লবণ বেছে নাও। বিকারে লবণের আয়ন ও পানির অণু; দুর্বল এসিডের অ্যানায়ন (যেমন CH₃COO⁻) পানির অণু থেকে H⁺ টেনে নিয়ে দুর্বল এসিড হয় এবং OH⁻ (নীল বলয়) ছাড়ে; দুর্বল ক্ষারকের ক্যাটায়ন (NH₄⁺) পানিকে H⁺ দিয়ে H₃O⁺ (হলুদ বলয়) তৈরি করে; Na⁺ ও Cl⁻ কিছুই করে না। আর্দ্র বিশ্লেষিত আয়নের সংখ্যা বোঝার সুবিধার জন্য বর্ধিত। দ্রবণের রং সার্বজনীন নির্দেশকের। ডানের লেখচিত্রে ঘনমাত্রার সাথে pH — CH₃COONH₄ এর pH ঘনমাত্রা নিরপেক্ষ (অনুভূমিক রেখা)।',
  html: () => `<label class="small">লবণ: <select data-s>${SALTS.map((s, i) => `<option value="${i}" ${i === 1 ? 'selected' : ''}>${s.nm} — ${s.t}</option>`).join('')}</select></label>${X.cv('লবণের আর্দ্র বিশ্লেষণের কণা-দৃশ্য ও pH লেখচিত্র')}<label class="small" style="display:block;margin-top:8px">ঘনমাত্রা log c = <b data-cv></b><input type="range" min="-3" max="0" step="0.05" value="-1" data-c></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : w * 0.75 + 230;
    let L = X.fit(c, hf), si = 1, lc = -1, P = [], t = 0;
    const R = X.rng(81);
    const reset = () => { P = []; for (let i = 0; i < 8; i++) { P.push({ k: 'cat', x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, h: 0 }); P.push({ k: 'an', x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, h: 0 }); } for (let i = 0; i < 22; i++) P.push({ k: 'w', x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, a: R() * 6, h: 0 }); };
    const step = dt => {
      t += dt; const S = SALTS[si], r = saltPH(S, Math.pow(10, lc));
      const vis = S.Ka || S.Kb ? Math.max(1, Math.min(6, Math.round(1 + Math.log10(r.h * 1e5 + 1)))) : 0;
      ['an', 'cat'].forEach(kind => { const can = kind === 'an' ? !!S.Ka : !!S.Kb; const list = P.filter(p => p.k === kind); let cur = list.filter(p => p.h).length; list.forEach(p => { if (can && cur < vis && !p.h && R() < 0.02) { p.h = 1; cur++; } else if ((!can || cur > vis) && p.h && R() < 0.05) { p.h = 0; cur--; } }); });
      P.forEach(p => { p.x += p.vx * dt * 0.1; p.y += p.vy * dt * 0.1; if (p.a != null) p.a += dt; if (p.x < 0.05 || p.x > 0.95) p.vx *= -1; if (p.y < 0.06 || p.y > 0.94) p.vy *= -1; });
    };
    const geo = () => { const W = L.W, H = L.H; return wide(W) ? { b: [14, 10, W * 0.48, H - 30], g: [W * 0.48 + 72, 16, W * 0.52 - 92, H - 60] } : { b: [14, 10, W - 28, W * 0.75 - 20], g: [52, W * 0.75 + 20, W - 72, 160] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo(), [bx, by, bw, bh] = G.b, S = SALTS[si], r = saltPH(S, Math.pow(10, lc));
      g.fillStyle = uiCol(r.pH, 0.3); g.fillRect(bx, by + 10, bw, bh - 10); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(bx - 4, by); g.lineTo(bx, by + 4); g.lineTo(bx, by + bh); g.lineTo(bx + bw, by + bh); g.lineTo(bx + bw, by + 4); g.lineTo(bx + bw + 4, by); g.stroke();
      const s = Math.max(0.85, Math.min(1.15, bw / 300));
      P.forEach(p => {
        const x = bx + 10 + p.x * (bw - 20), y = by + 18 + p.y * (bh - 30);
        if (p.k === 'w') { const ca = Math.cos(p.a), sa = Math.sin(p.a); ball(g, x + Math.cos(p.a - 0.9) * 6 * s, y + Math.sin(p.a - 0.9) * 6 * s, 2.6 * s, '#d8dde3', '#fff'); ball(g, x + Math.cos(p.a + 0.9) * 6 * s, y + Math.sin(p.a + 0.9) * 6 * s, 2.6 * s, '#d8dde3', '#fff'); ball(g, x, y, 4.2 * s, '#c0392b', '#ff9f8f'); return; }
        const isCat = p.k === 'cat', lab = isCat ? S.cat : S.an, rr = 9 * s;
        ball(g, x, y, rr, isCat ? '#6c7ae0' : '#2e9d4e', isCat ? '#d3d8ff' : '#c8f0d4');
        g.fillStyle = '#fff'; g.font = `bold ${Math.round(7.5 * s)}px ${col.font}`; g.textAlign = 'center'; g.fillText(lab.replace(/[⁺⁻²]/g, ''), x, y + 3);
        g.fillStyle = col.fg; g.font = `bold ${Math.round(10 * s)}px ${col.font}`; g.fillText(isCat ? (lab.includes('²') ? '2+' : '+') : (lab.includes('²') ? '2−' : '−'), x + rr + 3, y - rr + 4);
        if (p.h) { // show product species and released ion
          const ox = x + 18 * s, oy = y + 10 * s; g.strokeStyle = isCat ? '#f2b705' : '#2d6fd6'; g.lineWidth = 2; g.setLineDash([2, 2]); g.beginPath(); g.moveTo(x, y); g.lineTo(ox, oy); g.stroke(); g.setLineDash([]);
          ball(g, ox, oy, 5 * s, isCat ? '#f2b705' : '#2d6fd6', '#fff'); g.strokeStyle = isCat ? '#f2b705' : '#2d6fd6'; g.beginPath(); g.arc(ox, oy, 9 * s, 0, 7); g.stroke(); g.fillStyle = col.fg; g.font = `bold ${Math.round(8 * s)}px ${col.font}`; g.fillText(isCat ? 'H₃O⁺' : 'OH⁻', ox, oy + 17 * s);
        }
      });
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(`${S.nm} · pH ${fx(r.pH, 2)}`, bx + bw / 2, by + bh + 16);
      const [gx, gy, gw, gh] = G.g, PL = cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: -3, xmax: 0, ymin: 3, ymax: 13, col, xt: [-3, -2, -1, 0], yt: [3, 5, 7, 9, 11, 13], xl: 'log c', yl: 'pH', ylx: 30 });
      g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(gx, PL.Y(7)); g.lineTo(gx + gw, PL.Y(7)); g.stroke(); g.setLineDash([]);
      SALTS.forEach((S2, i) => { const pts = []; for (let v = -3; v <= 0.001; v += 0.05) pts.push([PL.X(v), PL.Y(Math.max(3, Math.min(13, saltPH(S2, Math.pow(10, v)).pH)))]); path(g, pts, i === si ? col.acc : 'rgba(128,128,128,.35)', i === si ? 3 : 1.2); if (i !== si) { const lp = pts[pts.length - 1]; g.fillStyle = col.mu; g.font = `8.5px ${col.font}`; g.textAlign = 'left'; g.fillText(S2.nm, lp[0] + 2, lp[1] + 3); } });
      ball(g, PL.X(lc), PL.Y(r.pH), 5.5, '#c0392b', '#ffb3a8');
    };
    const info = () => {
      const S = SALTS[si], cc = Math.pow(10, lc), r = saltPH(S, cc); q('[data-cv]').textContent = fx(lc, 2);
      let f = '';
      if (S.Ka && !S.Kb) f = TXB(`K_h = \\dfrac{K_w}{K_a} = \\dfrac{10^{-14}}{${sci(S.Ka, 1)}} = ${sci(r.Kh, 2)},\\quad h = ${sci(r.h, 2)}`) + TXB(`\\mathrm{pH} = 7 + \\tfrac{1}{2}\\mathrm{p}K_a + \\tfrac{1}{2}\\log c = ${r.pH.toFixed(2)}`);
      else if (!S.Ka && S.Kb) f = TXB(`K_h = \\dfrac{K_w}{K_b} = \\dfrac{10^{-14}}{${sci(S.Kb, 1)}} = ${sci(r.Kh, 2)},\\quad h = ${sci(r.h, 2)}`) + TXB(`\\mathrm{pH} = 7 - \\tfrac{1}{2}\\mathrm{p}K_b - \\tfrac{1}{2}\\log c = ${r.pH.toFixed(2)}`);
      else if (S.Ka && S.Kb) f = TXB(`K_h = \\dfrac{K_w}{K_aK_b} = ${sci(r.Kh, 2)},\\quad h \\approx \\sqrt{K_h} = ${sci(Math.sqrt(r.Kh), 2)}`) + TXB(`\\mathrm{pH} = 7 + \\tfrac{1}{2}\\mathrm{p}K_a - \\tfrac{1}{2}\\mathrm{p}K_b = ${r.pH.toFixed(2)}`);
      else f = TXB(`\\mathrm{pH} = 7.00\\quad(h = 0)`);
      out.innerHTML = TXB(S.eq) + f + `<div class="small"><b>${S.t}</b> — ${!S.Ka && !S.Kb ? 'কোনো আয়নই আর্দ্র বিশ্লেষিত হয় না; দ্রবণ নিরপেক্ষ।' : S.Ka && S.Kb ? (Math.abs(r.pH - 7) < 0.05 ? 'দুটি আয়নই আর্দ্র বিশ্লেষিত, কিন্তু K_a = K_b বলে প্রভাব কাটাকাটি — নিরপেক্ষ; আর্দ্র বিশ্লেষণ মাত্রা ঘনমাত্রা নিরপেক্ষ।' : 'দুটি আয়নই আর্দ্র বিশ্লেষিত; K_b > K_a বলে OH⁻ এর প্রভাব বেশি — ক্ষারীয়।') : S.Ka ? 'দুর্বল এসিডের অ্যানায়ন পানি থেকে H⁺ নেয় — OH⁻ আধিক্যে ক্ষারীয়। অনুবন্ধী এসিড যত দুর্বল, দ্রবণ তত ক্ষারীয়।' : 'দুর্বল ক্ষারকের ক্যাটায়ন পানিকে H⁺ দেয় — H₃O⁺ আধিক্যে অম্লীয়।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) step(dt); draw(); }, { paused: false });
    q('[data-s]').onchange = e => { si = +e.target.value; P.forEach(p => { p.h = 0; }); info(); };
    q('[data-c]').oninput = e => { lc = +e.target.value; info(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
