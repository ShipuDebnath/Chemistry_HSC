/* Chapter 4 visuals part 8 — law of mass action, Kc & Kp, ICE tables, significance and properties of K (4.8) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, TX = C4.tx, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
const tsci = v => sci(v, 2);

/* ======================= ৪.৮ ভরক্রিয়ার সূত্র: সংঘর্ষ হার ∝ [A][B] ======================= */
V.c4_massAction = {
  t: 'ভরক্রিয়ার সূত্রের ভিত্তি: সংঘর্ষের হার ∝ [A][B] — কণা-সিমুলেশন ও পরিমাপ', k: ['anim', 'int', '2d', 'calc'],
  cap: 'পাত্রে নীল A ও লাল B অণু ছুটছে; প্রতিটি A–B সংঘর্ষে হলুদ ঝলক। স্লাইডারে A ও B এর সংখ্যা (ঘনমাত্রা) বদলাও — প্রতি ৪ সেকেন্ড পরপর প্রতি সেকেন্ডে সংঘর্ষ সংখ্যা মেপে ডানের লেখচিত্রে n_A × n_B এর বিপরীতে একটি বিন্দু বসে। বিন্দুগুলো মূলবিন্দুগামী একটি সরলরেখার কাছে থাকে: সংঘর্ষ হার ∝ [A][B]। "2A → সংঘর্ষ" অবস্থায় কেবল A–A সংঘর্ষ গোনা হয় — হার ∝ [A]², তাই সহগ ২ হলে ঘাত ২। এটিই গুল্ডবার্গ-ওয়াগের ভরক্রিয়ার সূত্রের আণবিক ব্যাখ্যা।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['ab', 'A + B সংঘর্ষ'], ['aa', '2A সংঘর্ষ']], 'ab')}</div>${X.cv('A ও B অণুর সংঘর্ষ হার পরিমাপ')}<div class="grid2" style="margin-top:8px"><label class="small">A অণুর সংখ্যা = <b data-av></b><input type="range" min="4" max="40" step="2" value="20" data-a></label><label class="small" data-bl>B অণুর সংখ্যা = <b data-bv></b><input type="range" min="4" max="40" step="2" value="20" data-b></label></div><div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-clr>${X.ico('repeat')}বিন্দু মুছো</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 320 : w * 0.7 + 260;
    let L = X.fit(c, hf), mode = 'ab', nA = 20, nB = 20, P = [], fl = [], win = 0, cnt = 0, pts = { ab: [], aa: [] }, last = null;
    const R = X.rng(23), r = 0.022;
    const spawn = () => { const want = [nA, mode === 'ab' ? nB : 0]; [0, 1].forEach(k => { const have = P.filter(p => p.k === k); for (let i = have.length; i < want[k]; i++) { const a = R() * 6.28; P.push({ k, x: R(), y: R(), vx: Math.cos(a) * 0.35, vy: Math.sin(a) * 0.35, cd: {} }); } for (let i = want[k]; i < have.length; i++) P.splice(P.indexOf(have[i]), 1); }); };
    const geo = () => { const W = L.W, H = L.H; return wide(W) ? { box: [10, 16, Math.min(300, W * 0.46), H - 40], g: [Math.min(300, W * 0.46) + 70, 20, W - Math.min(300, W * 0.46) - 90, H - 70] } : { box: [10, 16, W - 20, W * 0.7 - 20], g: [52, W * 0.7 + 30, W - 72, 170] }; };
    const step = dt => {
      const G = geo(), asp = G.box[3] / G.box[2];
      P.forEach(p => { p.x += p.vx * dt; p.y += p.vy * dt / asp; if (p.x < r || p.x > 1 - r) { p.vx *= -1; p.x = Math.max(r, Math.min(1 - r, p.x)); } if (p.y < r / asp || p.y > 1 - r / asp) { p.vy *= -1; p.y = Math.max(r / asp, Math.min(1 - r / asp, p.y)); } });
      for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) {
        const a = P[i], b = P[j]; const dx = a.x - b.x, dy = (a.y - b.y) * asp; if (dx * dx + dy * dy > 4 * r * r) continue;
        const key = j; if (a.cd[key] > 0) continue; a.cd[key] = 0.25;
        // elastic swap of velocity components along the line (equal mass)
        const d = Math.hypot(dx, dy) || 1e-6, nx = dx / d, ny = dy / d, rel = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny;
        if (rel < 0) { a.vx -= rel * nx; a.vy -= rel * ny; b.vx += rel * nx; b.vy += rel * ny; }
        const counts = mode === 'ab' ? a.k !== b.k : a.k === 0 && b.k === 0;
        if (counts) { cnt++; fl.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, t: 1 }); }
      }
      P.forEach(p => { for (const k in p.cd) { p.cd[k] -= dt; if (p.cd[k] <= 0) delete p.cd[k]; } });
      fl.forEach(f => { f.t -= dt * 2.5; }); fl = fl.filter(f => f.t > 0);
      win += dt; if (win >= 4) { const xv = mode === 'ab' ? nA * nB : nA * (nA - 1) / 2; last = [xv, cnt / win]; pts[mode].push(last); if (pts[mode].length > 40) pts[mode].shift(); win = 0; cnt = 0; info(); }
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo(), [bx, by, bw, bh] = G.box;
      g.fillStyle = 'rgba(180,210,235,.12)'; g.fillRect(bx, by, bw, bh); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.strokeRect(bx, by, bw, bh);
      const rr = r * bw;
      P.forEach(p => { const x = bx + p.x * bw, y = by + p.y * bh; if (p.k === 0) ball(g, x, y, rr, '#1d55b8', '#9cc4ff'); else ball(g, x, y, rr, '#c0392b', '#ffb3a8'); });
      fl.forEach(f => { g.fillStyle = `rgba(255,200,40,${(f.t * 0.85).toFixed(2)})`; g.beginPath(); g.arc(bx + f.x * bw, by + f.y * bh, rr * (1.4 + (1 - f.t) * 1.6), 0, 7); g.fill(); });
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(`পরিমাপ চলছে: ${fx(win, 1)} / ৪.০ s · সংঘর্ষ ${bn(cnt)}`, bx, by + bh + 16);
      const [gx, gy, gw, gh] = G.g, ps = pts[mode], xmax = mode === 'ab' ? 1600 : 800, ymax = Math.max(20, ...ps.map(p => p[1])) * 1.15;
      const PL = cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax, ymax, col, xt: mode === 'ab' ? [0, 400, 800, 1200, 1600] : [0, 200, 400, 600, 800], yt: [0, Math.round(ymax / 2), Math.round(ymax)], xl: mode === 'ab' ? 'n_A × n_B (∝ [A][B])' : 'n_A(n_A − 1)/2 (∝ [A]²)', yl: 'সংঘর্ষ প্রতি সেকেন্ডে', ylx: 36 });
      if (ps.length >= 2) { const s = ps.reduce((a, p) => a + p[0] * p[1], 0) / ps.reduce((a, p) => a + p[0] * p[0], 0), xe = Math.min(xmax, ymax / s); path(g, [[PL.X(0), PL.Y(0)], [PL.X(xe), PL.Y(s * xe)]], col.acc, 1.6, [5, 3]); }
      ps.forEach((p, i) => ball(g, PL.X(p[0]), PL.Y(Math.min(ymax, p[1])), i === ps.length - 1 ? 5 : 3.8, mode === 'ab' ? '#7b3fa0' : '#1d55b8', '#e9d8ff'));
    };
    const info = () => {
      q('[data-av]').textContent = bn(nA); q('[data-bv]').textContent = bn(nB); q('[data-bl]').style.visibility = mode === 'ab' ? '' : 'hidden';
      out.innerHTML = (mode === 'ab' ? TXB(`\\ce{A + B -> \\text{উৎপাদ}}\\qquad r = k[\\ce{A}][\\ce{B}]`) : TXB(`\\ce{2A -> \\text{উৎপাদ}}\\qquad r = k[\\ce{A}]^2`)) +
        `<div class="small">${last ? `শেষ পরিমাপ: ${mode === 'ab' ? `n_A × n_B = ${bn(last[0])}` : `A–A জোড়া = ${bn(last[0])}`} → প্রতি সেকেন্ডে ${fx(last[1], 1)} সংঘর্ষ। ` : ''}বিভিন্ন সংখ্যায় কয়েকটি বিন্দু নাও — বিন্দুগুলো মূলবিন্দুগামী সরলরেখায় পড়ে, অর্থাৎ সংঘর্ষ হার সক্রিয় ভরের গুণফলের সমানুপাতিক।</div>`;
    };
    const A = X.anim(el, dt => { if (dt) step(Math.min(dt, 0.03)); draw(); }, { paused: false });
    X.pp(el, A);
    q('[data-a]').oninput = e => { nA = +e.target.value; spawn(); win = 0; cnt = 0; info(); };
    q('[data-b]').oninput = e => { nB = +e.target.value; spawn(); win = 0; cnt = 0; info(); };
    q('[data-clr]').onclick = () => { pts[mode] = []; last = null; info(); };
    X.onSeg(el, 'm', v => { mode = v; spawn(); win = 0; cnt = 0; last = null; info(); });
    spawn(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ---------- reaction library for 4.8.1 / 4.8.2 ---------- */
// species: [tex formula, coefficient (−react, +prod), phase]
const RX = [
  { nm: 'H₂ + I₂ ⇌ 2HI', sp: [['H2', -1, 'g'], ['I2', -1, 'g'], ['HI', 2, 'g']] },
  { nm: 'N₂ + 3H₂ ⇌ 2NH₃', sp: [['N2', -1, 'g'], ['H2', -3, 'g'], ['NH3', 2, 'g']] },
  { nm: 'PCl₅ ⇌ PCl₃ + Cl₂', sp: [['PCl5', -1, 'g'], ['PCl3', 1, 'g'], ['Cl2', 1, 'g']] },
  { nm: '2SO₂ + O₂ ⇌ 2SO₃', sp: [['SO2', -2, 'g'], ['O2', -1, 'g'], ['SO3', 2, 'g']] },
  { nm: 'N₂O₄ ⇌ 2NO₂', sp: [['N2O4', -1, 'g'], ['NO2', 2, 'g']] },
  { nm: 'CaCO₃ ⇌ CaO + CO₂', sp: [['CaCO3', -1, 's'], ['CaO', 1, 's'], ['CO2', 1, 'g']] },
  { nm: '3Fe + 4H₂O ⇌ Fe₃O₄ + 4H₂', sp: [['Fe', -3, 's'], ['H2O', -4, 'g'], ['Fe3O4', 1, 's'], ['H2', 4, 'g']] },
  { nm: 'NH₄HS ⇌ NH₃ + H₂S', sp: [['NH4HS', -1, 's'], ['NH3', 1, 'g'], ['H2S', 1, 'g']] },
  { nm: 'CH₃COOH ⇌ CH₃COO⁻ + H⁺', sp: [['CH3COOH', -1, 'aq'], ['CH3COO-', 1, 'aq'], ['H+', 1, 'aq']] },
  { nm: 'Fe³⁺ + SCN⁻ ⇌ [Fe(SCN)]²⁺', sp: [['Fe^3+', -1, 'aq'], ['SCN-', -1, 'aq'], ['[Fe(SCN)]^2+', 1, 'aq']] }
];
const eqTex = r => { const L_ = r.sp.filter(s => s[1] < 0).map(s => (s[1] < -1 ? -s[1] : '') + s[0] + `(${s[2]})`).join(' + '), R_ = r.sp.filter(s => s[1] > 0).map(s => (s[1] > 1 ? s[1] : '') + s[0] + `(${s[2]})`).join(' + '); return `\\ce{${L_} <=> ${R_}}`; };
const unitTex = (dn, u) => dn === 0 ? '\\text{এককহীন}' : u === 'c' ? (dn === 1 ? '\\mathrm{mol\\,L^{-1}}' : dn === -1 ? '\\mathrm{L\\,mol^{-1}}' : dn > 0 ? `\\mathrm{mol^{${dn}}\\,L^{-${dn}}}` : `\\mathrm{L^{${-dn}}\\,mol^{-${-dn}}}`) : (dn === 1 ? '\\mathrm{atm}' : `\\mathrm{atm^{${dn}}}`);

/* ======================= ৪.৮.১ Kc ও Kp রাশিমালা নির্মাতা ======================= */
V.c4_kExpr = {
  t: 'Kc ও Kp এর রাশিমালা নির্মাতা: দশা অনুযায়ী অন্তর্ভুক্তি, Δn ও একক', k: ['int', 'calc'],
  cap: 'একটি বিক্রিয়া বেছে নাও। উপরে প্রতিটি পদার্থের টালি: সবুজ = গ্যাস, নীল = দ্রবীভূত (aq), ধূসর কাটা = বিশুদ্ধ কঠিন/তরল (সক্রিয় ভর ১, রাশিমালায় নেই)। টালির নিচের তীর দেখায় পদার্থটি লবে (উৎপাদ) না হরে (বিক্রিয়ক) যাবে এবং কোন ঘাতে। নিচে স্বয়ংক্রিয়ভাবে তৈরি K_c ও K_p এর রাশিমালা, Δn এর হিসাব, দুটির একক এবং K_p = K_c(RT)^Δn সম্পর্ক। দ্রবণীয় সাম্যে K_p প্রযোজ্য নয়।',
  html: () => `<label class="small">বিক্রিয়া: <select data-r style="max-width:100%">${RX.map((r, i) => `<option value="${i}">${r.nm}</option>`).join('')}</select></label><div data-tiles style="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 6px;align-items:flex-start"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const out = el.querySelector('[data-out]'), tl = el.querySelector('[data-tiles]'), sel = el.querySelector('[data-r]');
    const render = () => {
      const r = RX[+sel.value];
      const act = r.sp.filter(s => s[2] === 'g' || s[2] === 'aq'), gas = r.sp.filter(s => s[2] === 'g'), aq = r.sp.some(s => s[2] === 'aq');
      tl.innerHTML = r.sp.map(s => { const inc = s[2] === 'g' || s[2] === 'aq', bg = s[2] === 'g' ? 'rgba(46,157,78,.16)' : s[2] === 'aq' ? 'rgba(45,111,214,.16)' : 'rgba(128,128,128,.14)', bd = s[2] === 'g' ? '#2e9d4e' : s[2] === 'aq' ? '#2d6fd6' : '#8a8a8a'; return `<div style="border:1.5px solid ${bd};background:${bg};border-radius:10px;padding:6px 10px;text-align:center;min-width:74px;${inc ? '' : 'opacity:.7'}"><div style="${inc ? '' : 'text-decoration:line-through'}">${TX(`\\ce{${Math.abs(s[1]) > 1 ? Math.abs(s[1]) : ''}${s[0]}(${s[2]})}`)}</div><div class="small" style="margin-top:3px">${inc ? (s[1] > 0 ? '↑ লবে' : '↓ হরে') + `, ঘাত ${bn(Math.abs(s[1]))}` : 'সক্রিয় ভর = ১'}</div></div>`; }).join('');
      const num = act.filter(s => s[1] > 0), den = act.filter(s => s[1] < 0);
      const term = (s, p) => p ? `p_{\\ce{${s[0]}}}${Math.abs(s[1]) > 1 ? '^{' + Math.abs(s[1]) + '}' : ''}` : `[\\ce{${s[0]}}]${Math.abs(s[1]) > 1 ? '^{' + Math.abs(s[1]) + '}' : ''}`;
      const frac = (n, d, p) => { const N = n.map(s => term(s, p)).join('') || '1', D = d.map(s => term(s, p)).join(''); return D ? `\\dfrac{${N}}{${D}}` : N; };
      const dnG = gas.reduce((a, s) => a + s[1], 0), dnC = act.reduce((a, s) => a + s[1], 0);
      const dnTxt = `\\Delta n = (${gas.filter(s => s[1] > 0).map(s => s[1]).join('+') || 0}) - (${gas.filter(s => s[1] < 0).map(s => -s[1]).join('+') || 0}) = ${dnG > 0 ? '+' : ''}${dnG}`;
      out.innerHTML = TXB(eqTex(r)) + TXB(`K_c = ${frac(num, den, false)}\\qquad \\text{একক: } ${unitTex(dnC, 'c')}`) +
        (aq ? `<div class="small">দ্রবণীয় সাম্য — গ্যাস নেই, তাই K<sub>p</sub> প্রযোজ্য নয়; K<sub>c</sub> এর Δn = দ্রবীভূত প্রজাতির সহগের পার্থক্য = ${bn(dnC)}।</div>` :
          TXB(`K_p = ${frac(num.filter(s => s[2] === 'g'), den.filter(s => s[2] === 'g'), true)}\\qquad \\text{একক: } ${unitTex(dnG, 'p')}`) + TXB(`${dnTxt}\\;\\Rightarrow\\; K_p = K_c(RT)^{${dnG}}${dnG === 0 ? ' = K_c' : ''}`) +
          `<div class="small">${r.sp.some(s => s[2] === 's') ? 'কঠিন পদার্থ Δn এর হিসাবে ও রাশিমালায় গোনা হয়নি। ' : ''}${dnG === 0 ? 'Δn = 0 — K এককহীন এবং K_p = K_c।' : dnG > 0 ? 'Δn > 0 — K_p > K_c (RT > 1)।' : 'Δn < 0 — K_p < K_c।'}</div>`);
    };
    sel.onchange = render; render();
    return () => {};
  }
};

/* ======================= ৪.৮.২ Kp ↔ Kc রূপান্তরক ও তাপমাত্রা নির্ভরতা ======================= */
V.c4_kcKp = {
  t: 'Kp = Kc(RT)^Δn: রূপান্তর গণনা ও তাপমাত্রার সাথে Kp/Kc অনুপাত (Δn = −২ থেকে +২)', k: ['int', '2d', 'calc'],
  cap: 'বিক্রিয়া, তাপমাত্রা ও K_c বেছে নাও — ধাপে ধাপে K_p নির্ণয় দেখানো হয়। লেখচিত্রে log(K_p/K_c) = Δn·log(RT) পাঁচটি Δn এর জন্য তাপমাত্রার বিপরীতে: Δn = ০ রেখা অনুভূমিক শূন্যে (K_p = K_c); Δn ধনাত্মক হলে অনুপাত ১ এর বেশি, ঋণাত্মক হলে কম। সব রেখা মিলিত হয় T = ১/R ≈ ১২.২ K এ (RT = ১)। লাল বিন্দু নির্বাচিত অবস্থা।',
  html: () => `<label class="small">বিক্রিয়া: <select data-r>${[1, 3, 0, 2, 5, 6].map(i => `<option value="${i}">${RX[i].nm}</option>`).join('')}<option value="x">2NH₃ ⇌ N₂ + 3H₂ (Δn = +২)</option></select></label>${X.cv('Kp ও Kc অনুপাতের তাপমাত্রা নির্ভরতা')}<div class="grid2" style="margin-top:8px"><label class="small">T = <b data-tv></b> K<input type="range" min="200" max="1200" step="10" value="500" data-t></label><label class="small">log K<sub>c</sub> = <b data-kv></b><input type="range" min="-6" max="6" step="0.1" value="-1.2" data-k></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), sel = q('[data-r]');
    const hf = w => wide(w) ? 250 : 230;
    let L = X.fit(c, hf), T = 500, lk = -1.2;
    const rx = () => sel.value === 'x' ? { nm: '2NH₃ ⇌ N₂ + 3H₂', sp: [['NH3', -2, 'g'], ['N2', 1, 'g'], ['H2', 3, 'g']] } : RX[+sel.value];
    const dn = () => rx().sp.filter(s => s[2] === 'g').reduce((a, s) => a + s[1], 0);
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const P1 = cplot(g, { x0: 52, y0: 14, w: W - 72, h: H - 52, xmin: 0, xmax: 1200, ymin: -10, ymax: 10, col, xt: [0, 200, 400, 600, 800, 1000, 1200], yt: [-10, -5, 0, 5, 10], xl: 'T (K)', yl: 'log(K_p/K_c)', ylx: 36 });
      const cs = { '-2': '#c0392b', '-1': '#d06a1e', '0': '#8a96a3', '1': '#2d6fd6', '2': '#7b3fa0' }, d = dn();
      [-2, -1, 0, 1, 2].forEach(n => { const pts = []; for (let t = 12; t <= 1200; t += 6) pts.push([P1.X(t), P1.Y(n * Math.log10(0.0821 * t))]); path(g, pts, cs[n], n === d ? 3.2 : 1.4, n === d ? null : [4, 3]); const lp = pts[pts.length - 1]; g.fillStyle = cs[n]; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText(`Δn = ${n > 0 ? '+' : ''}${bn(n)}`, lp[0] - 2, lp[1] + (n >= 0 ? -6 : 13)); });
      ball(g, P1.X(T), P1.Y(d * Math.log10(0.0821 * T)), 5.5, '#c0392b', '#ffb3a8');
      g.strokeStyle = col.mu; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(P1.X(12.2), 14); g.lineTo(P1.X(12.2), H - 38); g.stroke(); g.setLineDash([]);
    };
    const info = () => {
      const r = rx(), d = dn(), Kc = Math.pow(10, lk), RT = 0.0821 * T, Kp = Kc * Math.pow(RT, d);
      q('[data-tv]').textContent = bn(T); q('[data-kv]').textContent = fx(lk, 1);
      out.innerHTML = TXB(eqTex(r)) + TXB(`\\Delta n = ${d > 0 ? '+' : ''}${d},\\quad RT = 0.0821\\times${T} = ${RT.toFixed(2)}`) +
        TXB(`K_p = K_c(RT)^{${d}} = ${tsci(Kc)}\\times(${RT.toFixed(2)})^{${d}} = ${tsci(Kp)}\\ ${unitTex(d, 'p')}`) +
        TXB(`K_c = ${tsci(Kc)}\\ ${unitTex(d, 'c')}`) + `<div class="small">${d === 0 ? 'Δn = 0: যেকোনো তাপমাত্রায় K_p = K_c।' : `${TX(`K_p/K_c = (RT)^{\\Delta n} = ${tsci(Math.pow(RT, d))}`)} — ${d > 0 ? 'K_p বড়' : 'K_c বড়'}।`}</div>`;
    };
    sel.onchange = () => { info(); draw(); };
    q('[data-t]').oninput = e => { T = +e.target.value; info(); draw(); };
    q('[data-k]').oninput = e => { lk = +e.target.value; info(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৪.৮.৩ ICE টেবিল সমাধানকারী ======================= */
const ICEP = {
  hi: { nm: 'H₂ + I₂ ⇌ 2HI (৪৪৫ °C)', sp: ['H_2', 'I_2', 'HI'], ce: ['H2', 'I2', 'HI'], nu: [-1, -1, 2], n0: [1, 2, 0], K: 50, V: 1, rng: [[0.1, 3], [0.1, 3], [0, 3]], col: ['#9aa3ad', '#7b3fa0', '#2e9d4e'] },
  pcl: { nm: 'PCl₅ ⇌ PCl₃ + Cl₂ (২৫০ °C)', sp: ['PCl_5', 'PCl_3', 'Cl_2'], ce: ['PCl5', 'PCl3', 'Cl2'], nu: [-1, 1, 1], n0: [1, 0, 0], K: 0.0415, V: 10, rng: [[0.1, 3], [0, 2], [0, 2]], col: ['#d08a1e', '#e2c24a', '#3fae5a'] },
  n2o4: { nm: 'N₂O₄ ⇌ 2NO₂ (২৫ °C)', sp: ['N_2O_4', 'NO_2'], ce: ['N2O4', 'NO2'], nu: [-1, 2], n0: [0.1, 0], K: 4.6e-3, V: 1, rng: [[0.01, 0.5], [0, 0.5]], col: ['#9aa3ad', '#8c3e14'] },
  est: { nm: 'এসিড + অ্যালকোহল ⇌ এস্টার + পানি', sp: ['এসিড', 'অ্যালকোহল', 'এস্টার', 'পানি'], ce: ['CH3COOH', 'C2H5OH', 'CH3COOC2H5', 'H2O'], nu: [-1, -1, 1, 1], n0: [1, 1, 0, 0], K: 4, V: 1, rng: [[0.1, 3], [0.1, 3], [0, 2], [0, 2]], col: ['#d06a1e', '#2d6fd6', '#7b3fa0', '#6fa8dc'] }
};
V.c4_iceTable = {
  t: 'ICE টেবিল সমাধানকারী: প্রাথমিক → পরিবর্তন → সাম্য (ধাপে ধাপে, দিক নির্ণয়সহ)', k: ['anim', 'int', 'calc'],
  cap: 'একটি সাম্য বেছে নাও এবং প্রাথমিক মোল, পাত্রের আয়তন বদলাও। "ধাপে ধাপে" চাপলে ICE টেবিলের সারিগুলো একে একে পূরণ হয়: প্রথমে প্রাথমিক মোল, তারপর Q নির্ণয় করে দিক (Q < K হলে x ধনাত্মক — ডানে; Q > K হলে x ঋণাত্মক — বামে), স্টয়কিওমেট্রি অনুযায়ী পরিবর্তন, সাম্য মোল ও ঘনমাত্রা, শেষে K এর সমীকরণ ও সমাধান। নিচের দণ্ডচিত্রে প্রাথমিক (হালকা) ও সাম্য (গাঢ়) মোল পাশাপাশি — দণ্ডগুলো অ্যানিমেশনে নতুন মানে পৌঁছায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('p', [['hi', 'H₂ + I₂'], ['pcl', 'PCl₅'], ['n2o4', 'N₂O₄'], ['est', 'এস্টারীকরণ']], 'hi')}</div><div data-sl class="grid2"></div><div class="ctl"><button class="btn sm primary" data-go>${X.ico('play')}ধাপে ধাপে সমাধান</button><button class="btn sm" data-all>সব একসাথে</button></div><div data-tbl style="overflow-x:auto"></div>${X.cv('প্রাথমিক ও সাম্য মোলের দণ্ডচিত্র', 170)}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), tbl = q('[data-tbl]'), sl = q('[data-sl]');
    let L = X.fit(c, () => 170), key = 'hi', pr, n0, Vv, stage = 5, anim = 1, tmr = null;
    const load = () => {
      pr = ICEP[key]; n0 = pr.n0.slice(); Vv = pr.V;
      sl.innerHTML = pr.sp.map((s, i) => `<label class="small">প্রাথমিক ${pr.ce[i].length < 8 ? TX(`\\ce{${pr.ce[i]}}`) : s} = <b data-nv="${i}"></b> mol<input type="range" min="${pr.rng[i][0]}" max="${pr.rng[i][1]}" step="${pr.rng[i][1] <= 0.5 ? 0.01 : 0.1}" value="${n0[i]}" data-n="${i}"></label>`).join('') + (pr.nu.reduce((a, b) => a + b, 0) !== 0 ? `<label class="small">আয়তন V = <b data-vv></b> L<input type="range" min="0.5" max="20" step="0.5" value="${Vv}" data-v></label>` : '');
      sl.querySelectorAll('[data-n]').forEach(inp => inp.oninput = () => { n0[+inp.dataset.n] = +inp.value; stage = 5; anim = 1; render(); });
      const vi = sl.querySelector('[data-v]'); if (vi) vi.oninput = () => { Vv = +vi.value; stage = 5; anim = 1; render(); };
    };
    const solve = () => {
      const lnQ = x => { let s = 0; for (let i = 0; i < n0.length; i++) { const n = n0[i] + pr.nu[i] * x; s += pr.nu[i] * Math.log(Math.max(1e-300, n / Vv)); } return s; };
      let lo = -Infinity, hi = Infinity; pr.nu.forEach((nu, i) => { const lim = -n0[i] / nu; if (nu < 0) hi = Math.min(hi, lim); else lo = Math.max(lo, lim); });
      lo += 1e-12; hi -= 1e-12; const lnK = Math.log(pr.K);
      for (let k = 0; k < 200; k++) { const m = (lo + hi) / 2; if (lnQ(m) < lnK) lo = m; else hi = m; }
      const x = (lo + hi) / 2; const Q0 = (() => { const z = n0.map((n, i) => n / Vv); if (z.some((v, i) => v === 0 && pr.nu[i] < 0)) return Infinity; if (z.some((v, i) => v === 0 && pr.nu[i] > 0)) return 0; return Math.exp(pr.nu.reduce((a, nu, i) => a + nu * Math.log(z[i]), 0)); })();
      return { x, Q0, ne: n0.map((n, i) => n + pr.nu[i] * x) };
    };
    const coefX = nu => (nu > 0 ? '+' : '-') + (Math.abs(nu) > 1 ? Math.abs(nu) : '') + 'x';
    const eqm = i => n0[i] ? `${n0[i]}${coefX(pr.nu[i])}` : coefX(pr.nu[i]).replace(/^\+/, '');
    const render = () => {
      sl.querySelectorAll('[data-nv]').forEach(b => { b.textContent = fx(n0[+b.dataset.nv], n0[+b.dataset.nv] < 1 && pr.rng[+b.dataset.nv][1] <= 0.5 ? 2 : 1); }); const vv = sl.querySelector('[data-vv]'); if (vv) vv.textContent = fx(Vv, 1);
      const S = solve(), dn = pr.nu.reduce((a, b) => a + b, 0);
      const hd = pr.sp.map((s, i) => `<th>${pr.ce[i].length < 8 ? TX(`\\ce{${Math.abs(pr.nu[i]) > 1 ? Math.abs(pr.nu[i]) : ''}${pr.ce[i]}}`) : (Math.abs(pr.nu[i]) > 1 ? Math.abs(pr.nu[i]) : '') + s}</th>`).join('');
      const row = (lab, cells, on) => `<tr style="${on ? '' : 'opacity:.12'}"><td><b>${lab}</b></td>${cells.map(cl => `<td>${cl}</td>`).join('')}</tr>`;
      tbl.innerHTML = `<table class="t" style="margin:8px 0;min-width:320px"><thead><tr><th></th>${hd}</tr></thead><tbody>` +
        row('প্রাথমিক (mol)', n0.map(v => fx(v, v < 1 && v > 0 ? 3 : 2)), stage >= 1) +
        row('পরিবর্তন', pr.nu.map(nu => TX(coefX(nu))), stage >= 2) +
        row('সাম্য (mol)', pr.nu.map((nu, i) => TX(eqm(i))), stage >= 3) +
        row(`সাম্য (mol L⁻¹)`, S.ne.map(v => fx(v / Vv, 4)), stage >= 4) + `</tbody></table>`;
      const num = pr.nu.map((nu, i) => nu > 0 ? `\\left(\\dfrac{${eqm(i)}}{V}\\right)${nu > 1 ? '^{' + nu + '}' : ''}` : '').join(''), den = pr.nu.map((nu, i) => nu < 0 ? `\\left(\\dfrac{${eqm(i)}}{V}\\right)${-nu > 1 ? '^{' + (-nu) + '}' : ''}` : '').join('');
      const dir = S.Q0 < pr.K * 0.999 ? 'Q < K \\Rightarrow \\text{সম্মুখ দিকে},\\ x > 0' : S.Q0 > pr.K * 1.001 ? 'Q > K \\Rightarrow \\text{পশ্চাৎ দিকে},\\ x < 0' : 'Q = K \\Rightarrow \\text{ইতিমধ্যে সাম্যে}';
      out.innerHTML = (stage >= 2 ? TXB(`Q_0 = ${isFinite(S.Q0) ? tsci(S.Q0) : '\\infty'},\\ K_c = ${tsci(pr.K)}\\;\\Rightarrow\\; ${dir}`) : '') +
        (stage >= 5 ? TXB(`K_c = \\dfrac{${num || '1'}}{${den || '1'}} = ${tsci(pr.K)}${dn === 0 ? '\\quad(V\\text{ কেটে যায়})' : `\\quad(V = ${Vv}\\ \\mathrm{L})`}`) + TXB(`x = ${S.x.toFixed(4)}\\ \\mathrm{mol}`) +
          `<div class="small">সাম্যে: ${pr.sp.map((s, i) => `${s.replace(/_(\d)/g, (m, d) => '₀₁₂₃₄₅₆₇₈₉'[d])} = ${fx(S.ne[i], 4)} mol`).join(', ')}। যাচাই: ${TX(`Q_{\\text{সাম্য}} = ${tsci(Math.exp(pr.nu.reduce((a, nu, i) => a + nu * Math.log(Math.max(1e-300, S.ne[i] / Vv)), 0)))} \\approx K`)} ✓</div>` : '');
      drawBars(S);
    };
    const drawBars = S => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const n = n0.length, ymax = Math.max(...n0, ...S.ne) * 1.2 || 1, gw = W - 70, P = cplot(g, { x0: 52, y0: 10, w: gw, h: H - 40, xmax: n, ymax, col, yt: [0, ymax / 2, ymax].map(v => +v.toFixed(2)), fy: v => fx(v, 2), yl: 'মোল', ylx: 36 });
      const e = C4.ease(anim);
      for (let i = 0; i < n; i++) {
        const x = 52 + gw * (i + 0.5) / n, w = Math.min(36, gw / n * 0.3), v0 = n0[i], v1 = stage >= 5 ? v0 + (S.ne[i] - v0) * e : v0;
        g.fillStyle = pr.col[i] + '55'; g.fillRect(x - w - 2, P.Y(v0), w, P.Y(0) - P.Y(v0));
        g.fillStyle = pr.col[i]; g.fillRect(x + 2, P.Y(v1), w, P.Y(0) - P.Y(v1));
        g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(pr.sp[i].replace(/_(\d)/g, (m, d) => '₀₁₂₃₄₅₆₇₈₉'[d]), x, H - 16);
        g.font = `9px ${col.font}`; g.fillStyle = col.mu; g.fillText('প্রা.', x - w / 2 - 2, P.Y(v0) - 3); g.fillText('সা.', x + w / 2 + 2, P.Y(v1) - 3);
      }
    };
    const A = X.anim(el, dt => { if (dt && anim < 1 && stage >= 5) { anim = Math.min(1, anim + dt * 0.9); drawBars(solve()); } }, { paused: false });
    const run = () => { clearInterval(tmr); stage = 0; anim = 0; render(); tmr = setInterval(() => { stage++; render(); if (stage >= 5) clearInterval(tmr); }, 900); };
    q('[data-go]').onclick = run;
    q('[data-all]').onclick = () => { clearInterval(tmr); stage = 5; anim = 0; render(); };
    X.onSeg(el, 'p', v => { key = v; load(); stage = 5; anim = 0; render(); });
    load(); render();
    const un = X.onResize(el, () => { L = X.fit(c, () => 170); render(); });
    return () => { A.stop(); un(); clearInterval(tmr); };
  }
};

/* ======================= ৪.৮.৪ K এর মান: ব্যাপ্তি, দিক (Q) ও ΔG° ======================= */
V.c4_kMagnitude = {
  t: 'সাম্যধ্রুবকের তাৎপর্য: K এর মান ও বিক্রিয়ার ব্যাপ্তি, Q বনাম K দিয়ে দিক, ΔG°', k: ['anim', 'int', '2d', 'calc'],
  cap: 'A ⇌ B এর জন্য log K স্লাইডার সরাও। উপরে লগারিদমিক স্কেলে বাস্তব বিক্রিয়ার K চিহ্নিত — H₂ + Cl₂ (১০³³), এস্টারীকরণ (৪), N₂ + O₂ (১০⁻³¹) ইত্যাদি। মাঝে সাম্যে বিক্রিয়ক (নীল) ও উৎপাদের (কমলা) অনুপাত কণায় ও দণ্ডে; ২৫ °C এ ΔG° = −2.303RT log K। নিচের সংখ্যারেখায় Q এর মার্কার টেনে আনো (স্লাইডার): Q < K হলে সবুজ তীর ডানে (সম্মুখ), Q > K হলে লাল তীর বামে; "সাম্যে যাও" চাপলে Q অ্যানিমেশনে K এর দিকে সরে।',
  html: () => `${X.cv('K এর মান ও Q বনাম K সংখ্যারেখা')}<div class="grid2" style="margin-top:8px"><label class="small">log K = <b data-kv></b><input type="range" min="-35" max="35" step="0.5" value="0.6" data-k></label><label class="small">log Q = <b data-qv></b><input type="range" min="-35" max="35" step="0.5" value="-3" data-q></label></div><div class="ctl"><button class="btn sm primary" data-go>${X.ico('play')}সাম্যে যাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), sK = q('[data-k]'), sQ = q('[data-q]');
    const hf = w => wide(w) ? 330 : 360;
    let L = X.fit(c, hf), lk = 0.6, lq = -3, moving = false, P = [];
    const R = X.rng(41); for (let i = 0; i < 60; i++) P.push({ x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, s: 0 });
    const EX = [[33, 'H₂ + Cl₂ → 2HCl'], [10.4, '2SO₂ + O₂ (৫০০ K)'], [0.6, 'এস্টারীকরণ'], [-9.75, 'AgCl দ্রাব্যতা'], [-14, 'পানির K_w'], [-30.3, 'N₂ + O₂ → 2NO']];
    const draw = (dt) => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const x0 = 30, x1 = W - 30, XL = v => x0 + (v + 35) / 70 * (x1 - x0);
      // ruler
      const ry = 46; g.strokeStyle = col.fg; g.lineWidth = 1.4; g.beginPath(); g.moveTo(x0, ry); g.lineTo(x1, ry); g.stroke();
      for (let v = -35; v <= 35; v += 5) { g.beginPath(); g.moveTo(XL(v), ry - 4); g.lineTo(XL(v), ry + 4); g.stroke(); if (v % 10 === 0 || !wide(W) && false) { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(v === 0 ? '১' : `১০${X.sup(v).replace(/\d/g, d => d)}`.replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[d]), XL(v), ry + 15); } }
      g.fillStyle = 'rgba(45,111,214,.12)'; g.fillRect(x0, ry - 9, XL(-3) - x0, 18); g.fillStyle = 'rgba(208,106,30,.12)'; g.fillRect(XL(3), ry - 9, x1 - XL(3), 18);
      g.font = `9px ${col.font}`; g.fillStyle = '#2d6fd6'; g.textAlign = 'left'; g.fillText('বিক্রিয়ক প্রধান', x0, ry - 12); g.fillStyle = '#d06a1e'; g.textAlign = 'right'; g.fillText('উৎপাদ প্রধান', x1, ry - 12);
      EX.forEach(([v, nm], i) => { if (!wide(W) && (i === 1 || i === 4)) return; g.fillStyle = col.mu; g.beginPath(); g.arc(XL(v), ry, 2.5, 0, 7); g.fill(); g.save(); g.translate(XL(v), ry + 22); g.rotate(wide(W) ? 0 : 0); g.font = `8.5px ${col.font}`; g.textAlign = 'center'; g.fillText(nm, 0, (i % 2) * 10 + 8); g.restore(); });
      g.fillStyle = col.acc; g.beginPath(); g.moveTo(XL(lk), ry - 2); g.lineTo(XL(lk) - 6, ry - 14); g.lineTo(XL(lk) + 6, ry - 14); g.closePath(); g.fill();
      // particle box
      const fB = 1 / (1 + Math.pow(10, -lk)), by = 92, bh = wide(W) ? 110 : 120, bw = wide(W) ? W * 0.45 : W - 40, bx = 20;
      g.fillStyle = 'rgba(180,210,235,.12)'; g.fillRect(bx, by, bw, bh); g.strokeStyle = col.fg; g.strokeRect(bx, by, bw, bh);
      const nB = Math.round(fB * P.length); P.forEach((p, i) => { p.s = i < nB ? 1 : 0; if (dt) { p.x += p.vx * dt * 0.2; p.y += p.vy * dt * 0.3; if (p.x < 0.03 || p.x > 0.97) p.vx *= -1; if (p.y < 0.05 || p.y > 0.95) p.vy *= -1; } const x = bx + p.x * bw, y = by + p.y * bh; if (p.s) ball(g, x, y, 4.5, '#c4621a', '#ffc58a'); else ball(g, x, y, 4.5, '#1d55b8', '#9cc4ff'); });
      // bars + ΔG
      const gx = wide(W) ? bx + bw + 30 : 20, gy = wide(W) ? by : by + bh + 14, gw = wide(W) ? W - gx - 20 : W - 40;
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText('সাম্যে সংযুতি', gx, gy + 10);
      g.fillStyle = '#1d55b8'; g.fillRect(gx, gy + 18, gw * (1 - fB), 14); g.fillStyle = '#c4621a'; g.fillRect(gx + gw * (1 - fB), gy + 18, gw * fB, 14); g.strokeStyle = col.fg; g.strokeRect(gx, gy + 18, gw, 14);
      g.font = `10px ${col.font}`; g.fillStyle = col.fg; g.fillText(`A: ${(1 - fB) < 1e-4 ? '≈ ০' : fx((1 - fB) * 100, 2) + '%'}   B: ${fB < 1e-4 ? '≈ ০' : fx(fB * 100, 2) + '%'}`, gx, gy + 46);
      const dG = -2.303 * 8.314 * 298 * lk / 1000; g.fillText(`ΔG° (২৫ °C) = ${dG < 0 ? '−' : '+'}${fx(Math.abs(dG), 1)} kJ mol⁻¹`, gx, gy + 62);
      // Q number line
      const qy = H - 34; g.strokeStyle = col.fg; g.lineWidth = 1.4; g.beginPath(); g.moveTo(x0, qy); g.lineTo(x1, qy); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('log Q সংখ্যারেখা', x0, qy - 26);
      g.strokeStyle = col.acc; g.lineWidth = 2.5; g.beginPath(); g.moveTo(XL(lk), qy - 12); g.lineTo(XL(lk), qy + 12); g.stroke(); g.fillStyle = col.acc; g.textAlign = 'center'; g.fillText('K', XL(lk), qy + 24);
      const d = lk - lq; if (Math.abs(d) > 0.25) { const cc = d > 0 ? '#2e9d4e' : '#e0402e', xa = XL(lq), xb = XL(lq) + Math.sign(d) * Math.min(60, Math.abs(XL(lk) - XL(lq)) - 6); g.strokeStyle = cc; g.lineWidth = 3; g.beginPath(); g.moveTo(xa, qy - 6); g.lineTo(xb, qy - 6); g.stroke(); g.fillStyle = cc; g.beginPath(); g.moveTo(xb + Math.sign(d) * 8, qy - 6); g.lineTo(xb, qy - 11); g.lineTo(xb, qy - 1); g.fill(); }
      ball(g, XL(lq), qy, 6, '#7b3fa0', '#e2c7ff'); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('Q', XL(lq), qy + 22);
    };
    const info = () => {
      q('[data-kv]').textContent = fx(lk, 1); q('[data-qv]').textContent = fx(lq, 1);
      const d = lk - lq;
      out.innerHTML = TXB(`K = 10^{${lk}},\\quad Q = 10^{${lq}}\\;\\Rightarrow\\; ${Math.abs(d) <= 0.25 ? 'Q \\approx K:\\ \\text{সাম্যাবস্থা}' : d > 0 ? 'Q < K:\\ \\text{সম্মুখ দিকে (উৎপাদ বাড়বে)}' : 'Q > K:\\ \\text{পশ্চাৎ দিকে (বিক্রিয়ক বাড়বে)}'}`) +
        TXB(`\\Delta G^\\circ = -2.303RT\\log K = ${(-2.303 * 8.314 * 298 * lk / 1000).toFixed(1)}\\ \\mathrm{kJ\\,mol^{-1}}`) +
        `<div class="small">${lk > 3 ? 'K > ১০³: সাম্যে প্রায় সব উৎপাদ — বিক্রিয়া কার্যত সম্পূর্ণ।' : lk < -3 ? 'K < ১০⁻³: সাম্যে প্রায় সব বিক্রিয়ক — বিক্রিয়া কার্যত হয় না।' : 'মাঝারি K: বিক্রিয়ক ও উৎপাদ উভয়ই উল্লেখযোগ্য।'} মনে রাখো — K যত বড়ই হোক, তা বিক্রিয়ার হার সম্পর্কে কিছু বলে না।</div>`;
    };
    const A = X.anim(el, dt => { if (dt && moving) { const d = lk - lq; if (Math.abs(d) < 0.05) { lq = lk; moving = false; } else lq += d * Math.min(1, dt * 1.6); sQ.value = lq; info(); } draw(dt); }, { paused: false });
    sK.oninput = () => { lk = +sK.value; info(); }; sQ.oninput = () => { lq = +sQ.value; moving = false; info(); };
    q('[data-go]').onclick = () => { moving = true; };
    info(); draw(0);
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৮.৫ K এর বৈশিষ্ট্য: উল্টানো, গুণ ও যোগ ======================= */
V.c4_kProps = {
  t: 'সাম্যধ্রুবকের বৈশিষ্ট্য: বিক্রিয়া উল্টানো, সহগ গুণ ও বিক্রিয়া যোগে K (ইন্টারঅ্যাকটিভ)', k: ['int', '2d', 'calc'],
  cap: '"রূপান্তর" অংশে H₂ + I₂ ⇌ 2HI (K = ৫০, ৪৪৫ °C) কে উল্টাও বা ½, ২, ৩ দিয়ে গুণ করো — নতুন সমীকরণ, K এর রাশিমালা, মান ও একক সাথে সাথে বদলায়; ডানের দণ্ডে log K এর পরিবর্তন: উল্টালে চিহ্ন বদলায়, n দিয়ে গুণ করলে log K এর n গুণ। "যোগ" অংশে দুটি ধাপের সমীকরণ যোগ করে সামগ্রিক বিক্রিয়া — মধ্যবর্তী পদার্থ কেটে যায় এবং K₁ × K₂ = K, ঠিক যেমন হেসের সূত্রে ΔH যোগ হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['t', 'রূপান্তর'], ['s', 'যোগ']], 't')}</div><div data-ctl class="ctl" style="flex-wrap:wrap;gap:6px"><button class="btn sm" data-rev>⇄ উল্টাও</button>${X.seg('n', [['0.5', '× ½'], ['1', '× ১'], ['2', '× ২'], ['3', '× ৩']], '1')}</div><div data-sc class="ctl" style="display:none;flex-wrap:wrap;gap:6px">${X.seg('s', [['no2', 'N₂ → NO → NO₂'], ['co3', 'H₂CO₃ → CO₃²⁻'], ['nh3', 'NH₃ + H₂O, NH₄⁺']], 'no2')}</div>${X.cv('log K এর দণ্ডচিত্র', 150)}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    let L = X.fit(c, () => 150), mode = 't', rev = false, n = 1, sk = 'no2';
    const K0 = 50;
    const SUMS = {
      no2: { a: ['\\ce{N2(g) + O2(g) <=> 2NO(g)}', 4.6e-31], b: ['\\ce{2NO(g) + O2(g) <=> 2NO2(g)}', 1.4e12], s: '\\ce{N2(g) + 2O2(g) <=> 2NO2(g)}', cut: '\\ce{2NO}' },
      co3: { a: ['\\ce{H2CO3 <=> H+ + HCO3-}', 4.3e-7], b: ['\\ce{HCO3- <=> H+ + CO3^2-}', 4.8e-11], s: '\\ce{H2CO3 <=> 2H+ + CO3^2-}', cut: '\\ce{HCO3-}' },
      nh3: { a: ['\\ce{NH3 + H2O <=> NH4+ + OH-}', 1.8e-5], b: ['\\ce{H+ + OH- <=> H2O}', 1e14], s: '\\ce{NH3 + H+ <=> NH4+}', cut: '\\ce{OH-},\\ \\ce{H2O}' }
    };
    const cf = v => v === 1 ? '' : v === 0.5 ? '1/2' : v === 1.5 ? '3/2' : String(v);
    const draw = (vals) => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const mx = Math.max(5, ...vals.map(v => Math.abs(v[1]))) * 1.15, x0 = 20, x1 = W - 20, cx = (x0 + x1) / 2, XS = v => cx + v / mx * (x1 - x0) / 2;
      g.strokeStyle = col.fg; g.lineWidth = 1; g.beginPath(); g.moveTo(cx, 8); g.lineTo(cx, H - 18); g.stroke(); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('log K = ০', cx, H - 4);
      const bh = Math.min(26, (H - 30) / vals.length - 6);
      vals.forEach(([nm, v, cc], i) => { const y = 10 + i * (bh + 8); g.fillStyle = cc; g.fillRect(Math.min(cx, XS(v)), y, Math.abs(XS(v) - cx), bh); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = v >= 0 ? 'left' : 'right'; g.fillText(`${nm}: log K = ${v < 0 ? '−' : ''}${fx(Math.abs(v), 2)}`, XS(v) + (v >= 0 ? 6 : -6), y + bh / 2 + 4); });
    };
    const render = () => {
      q('[data-ctl]').style.display = mode === 't' ? '' : 'none'; q('[data-sc]').style.display = mode === 's' ? '' : 'none';
      if (mode === 't') {
        const a = cf(n), b = cf(2 * n), L_ = `${a}H2(g) + ${a}I2(g)`, R_ = `${b}HI(g)`, eqn = rev ? `\\ce{${R_} <=> ${L_}}` : `\\ce{${L_} <=> ${R_}}`;
        const pw = v => v === 1 ? '' : `^{${v === 0.5 ? '1/2' : v}}`;
        const expr = rev ? `\\dfrac{[\\ce{H2}]${pw(n)}[\\ce{I2}]${pw(n)}}{[\\ce{HI}]${pw(2 * n)}}` : `\\dfrac{[\\ce{HI}]${pw(2 * n)}}{[\\ce{H2}]${pw(n)}[\\ce{I2}]${pw(n)}}`;
        const e = (rev ? -1 : 1) * n, K = Math.pow(K0, e);
        out.innerHTML = TXB(`\\text{মূল: }\\ce{H2(g) + I2(g) <=> 2HI(g)},\\quad K = 50`) + TXB(`\\text{নতুন: }${eqn}`) +
          TXB(`K' = ${expr} = 50^{${e === 0.5 ? '1/2' : e === -0.5 ? '-1/2' : e}} = ${tsci(K)}`) +
          `<div class="small">${rev ? 'উল্টানোয় লব ও হর অদলবদল — K\' = 1/K। ' : ''}${n !== 1 ? `সব সহগ ${bn(n)} গুণ — প্রতিটি ঘাতও ${bn(n)} গুণ, তাই K' = Kⁿ। ` : ''}Δn = ০ বলে এখানে K এককহীন থাকে; Δn ≠ ০ বিক্রিয়ায় এককও একই ঘাতে বদলায়।</div>`;
        draw([['মূল', Math.log10(K0), '#8a96a3'], ['নতুন', Math.log10(K), rev ? '#e0402e' : '#2d6fd6']]);
      } else {
        const S = SUMS[sk], K = S.a[1] * S.b[1];
        out.innerHTML = TXB(`(১)\\ ${S.a[0]}\\qquad K_1 = ${tsci(S.a[1])}`) + TXB(`(২)\\ ${S.b[0]}\\qquad K_2 = ${tsci(S.b[1])}`) +
          TXB(`(১) + (২):\\ ${S.s}`) + TXB(`K = K_1\\times K_2 = ${tsci(S.a[1])}\\times${tsci(S.b[1])} = ${tsci(K)}`) +
          `<div class="small">মধ্যবর্তী ${TX(S.cut)} দুই পাশে কেটে যায়। log K যোগ হয় (log K₁ + log K₂) — তাই দণ্ডচিত্রে দুটি দণ্ড জোড়া লাগালে তৃতীয়টি পাওয়া যায়। ΔG° = −RT ln K বলে ΔG° ও যোগ হয়, ঠিক হেসের সূত্রের মতো।</div>`;
        draw([['K₁', Math.log10(S.a[1]), '#2d6fd6'], ['K₂', Math.log10(S.b[1]), '#d06a1e'], ['K = K₁K₂', Math.log10(K), '#7b3fa0']]);
      }
    };
    q('[data-rev]').onclick = () => { rev = !rev; render(); };
    X.onSeg(el, 'n', v => { n = +v; render(); });
    X.onSeg(el, 'm', v => { mode = v; render(); });
    X.onSeg(el, 's', v => { sk = v; render(); });
    render();
    const un = X.onResize(el, () => { L = X.fit(c, () => 150); render(); });
    return () => { un(); };
  }
};
})();
