/* Chapter 4 visuals part 1 — shared helpers + reaction types, green chemistry (4.1) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;
const bn = X.bn, f1 = v => (+v).toFixed(1);
const INK = '#1b1b1f';
const C4 = window.C4V = window.C4V || {};
C4.INK = INK;
C4.f1 = f1;
C4.ease = t => t < 0 ? 0 : t > 1 ? 1 : t * t * (3 - 2 * t);
C4.lerp = (a, b, t) => a + (b - a) * t;
/* textbook atom: flat fill + soft highlight + outline; dark fills get white text */
C4.atom = (x, y, r, fill, label, op = 1, fs) => {
  const hx = /^#([0-9a-f]{6})$/i.exec(fill), n = hx ? parseInt(hx[1], 16) : 0xffffff, dark = hx ? (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) < 110 : false;
  const size = fs || (label.length > 3 ? Math.max(8, r * 0.62) : Math.max(9, r * 0.85));
  return `<g opacity="${(+op).toFixed(2)}"><circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="${fill}" stroke="rgba(0,0,0,.45)" stroke-width="1"/>` +
    `<circle cx="${f1(x - r * 0.32)}" cy="${f1(y - r * 0.34)}" r="${f1(r * 0.36)}" fill="#fff" opacity=".38"/>` +
    `<text x="${f1(x)}" y="${f1(y + size * 0.36)}" text-anchor="middle" style="font-size:${f1(size)}px;font-weight:700;fill:${dark ? '#fff' : INK}">${label}</text></g>`;
};
/* generic linear plot frame. returns {s (svg string of axes), X(v), Y(v)} */
C4.frame = (o) => {
  const { x0, x1, y0, y1, xmin, xmax, ymin, ymax } = o;
  const X_ = v => x0 + (v - xmin) / (xmax - xmin) * (x1 - x0), Y_ = v => y1 - (v - ymin) / (ymax - ymin) * (y1 - y0);
  let s = `<line x1="${x0}" y1="${y1}" x2="${x1 + 6}" y2="${y1}" class="s-fg" stroke-width="1.2" marker-end="url(#${o.aid || 'c4ax'})"/><line x1="${x0}" y1="${y1}" x2="${x0}" y2="${y0 - 6}" class="s-fg" stroke-width="1.2" marker-end="url(#${o.aid || 'c4ax'})"/>`;
  (o.xt || []).forEach(v => { const x = X_(v); s += `<line x1="${f1(x)}" y1="${y1}" x2="${f1(x)}" y2="${y1 + 4}" class="s-fg"/><text x="${f1(x)}" y="${y1 + 15}" text-anchor="middle" class="tm" style="font-size:10px">${o.fx ? o.fx(v) : bn(v)}</text>`; if (o.grid) s += `<line x1="${f1(x)}" y1="${y0}" x2="${f1(x)}" y2="${y1}" class="s-ln" stroke-dasharray="2 3" opacity=".6"/>`; });
  (o.yt || []).forEach(v => { const y = Y_(v); s += `<line x1="${x0 - 4}" y1="${f1(y)}" x2="${x0}" y2="${f1(y)}" class="s-fg"/><text x="${x0 - 6}" y="${f1(y + 3.5)}" text-anchor="end" class="tm" style="font-size:10px">${o.fy ? o.fy(v) : bn(v)}</text>`; if (o.grid) s += `<line x1="${x0}" y1="${f1(y)}" x2="${x1}" y2="${f1(y)}" class="s-ln" stroke-dasharray="2 3" opacity=".6"/>`; });
  if (o.xlab) s += `<text x="${(x0 + x1) / 2}" y="${y1 + 30}" text-anchor="middle" class="tm" style="font-size:11px">${o.xlab}</text>`;
  if (o.ylab) s += `<text transform="translate(${o.ylx || x0 - 34} ${(y0 + y1) / 2}) rotate(-90)" text-anchor="middle" class="tm" style="font-size:11px">${o.ylab}</text>`;
  return { s, X: X_, Y: Y_ };
};

/* ======================= ৪.১ রাসায়নিক বিক্রিয়ার শ্রেণি: কণা-স্তরের অ্যানিমেশন ======================= */
const CL = { H: '#F4F4F4', O: '#E5533D', C: '#4A4A4A', Ca: '#8FD3C8', Cu: '#D08A4E', Zn: '#A9B4C2', SO4: '#EDCB4C', Ag: '#C9CBD3', NO3: '#6E9BEF', Na: '#B07CEB', Cl: '#53C46B' };
/* atom: [label0, label1, color, r0, x0, y0, x1, y1, r1?]; bonds: [i, j, order] (0 = ionic/dashed) */
const RX = {
  syn: { n: 'সংযোজন', eq: '2H₂ + O₂ → 2H₂O', tags: ['সংযোজন', 'রেডক্স', 'তাপোৎপাদী'], note: 'দুটি বিক্রিয়ক মিলে একটিমাত্র উৎপাদ: A + B → AB। H–H ও O=O বন্ধন ভেঙে নতুন O–H বন্ধন গঠিত হয়; প্রতিটি পরমাণু গোনো — দুই পাশে ৪টি H ও ২টি O (ভরের নিত্যতা)।',
    at: [['H', 'H', CL.H, 12, 60, 62, 138, 98], ['H', 'H', CL.H, 12, 96, 62, 202, 98], ['H', 'H', CL.H, 12, 60, 152, 218, 154], ['H', 'H', CL.H, 12, 96, 152, 282, 154], ['O', 'O', CL.O, 18, 282, 106, 170, 74], ['O', 'O', CL.O, 18, 328, 106, 250, 130]],
    b0: [[0, 1, 1], [2, 3, 1], [4, 5, 2]], b1: [[4, 0, 1], [4, 1, 1], [5, 2, 1], [5, 3, 1]] },
  dec: { n: 'বিয়োজন', eq: 'CaCO₃ →(Δ) CaO + CO₂', tags: ['বিয়োজন', 'তাপহারী', 'রেডক্স নয়'], note: 'একটি যৌগ ভেঙে একাধিক সরল পদার্থ: AB → A + B। তাপ শোষণ করে (ΔH = +178 kJ mol⁻¹) C–O বন্ধন ভাঙে; CO₂ গ্যাস হয়ে উড়ে যায়, কঠিন CaO পড়ে থাকে।',
    at: [['Ca²⁺', 'Ca²⁺', CL.Ca, 20, 126, 106, 96, 142], ['O', 'O²⁻', CL.O, 16, 178, 106, 148, 142], ['C', 'C', CL.C, 15, 220, 106, 300, 58], ['O', 'O', CL.O, 16, 241, 70, 258, 58], ['O', 'O', CL.O, 16, 241, 142, 342, 58]],
    b0: [[0, 1, 0], [1, 2, 1], [2, 3, 2], [2, 4, 1]], b1: [[0, 1, 0], [2, 3, 2], [2, 4, 2]], heat: true },
  sub: { n: 'প্রতিস্থাপন', eq: 'Zn + CuSO₄ → ZnSO₄ + Cu', tags: ['প্রতিস্থাপন', 'রেডক্স'], note: 'অধিক সক্রিয় Zn কম সক্রিয় Cu কে যৌগ থেকে সরিয়ে দেয়: A + BC → AC + B। Zn দুটি ইলেকট্রন ত্যাগ করে (জারণ), Cu²⁺ তা গ্রহণ করে ধাতব Cu হয় (বিজারণ)। আয়ন হলে আকার ছোট হয়, পরমাণু হলে বড় — লক্ষ্য করো।',
    at: [['Zn', 'Zn²⁺', CL.Zn, 19, 70, 104, 230, 104, 14, -34], ['Cu²⁺', 'Cu', CL.Cu, 13, 222, 104, 118, 168, 18], ['SO₄²⁻', 'SO₄²⁻', CL.SO4, 26, 284, 104, 284, 104]],
    b0: [[1, 2, 0]], b1: [[0, 2, 0]], el: [[0, 1], [0, 1]] },
  dbl: { n: 'দ্বি-প্রতিস্থাপন', eq: 'AgNO₃ + NaCl → AgCl↓ + NaNO₃', tags: ['দ্বি-প্রতিস্থাপন', 'অধঃক্ষেপণ', 'রেডক্স নয়'], note: 'দুটি যৌগের আয়ন সঙ্গী বদল করে: AB + CD → AD + CB। অদ্রবণীয় AgCl সাদা অধঃক্ষেপ হিসেবে নিচে জমে; কোনো আয়নের চার্জ বদলায় না।',
    at: [['Ag⁺', 'Ag⁺', CL.Ag, 16, 60, 76, 170, 156], ['NO₃⁻', 'NO₃⁻', CL.NO3, 22, 110, 76, 294, 66, 0, -46], ['Na⁺', 'Na⁺', CL.Na, 14, 262, 76, 246, 66], ['Cl⁻', 'Cl⁻', CL.Cl, 20, 310, 76, 212, 156]],
    b0: [[0, 1, 0], [2, 3, 0]], b1: [[0, 3, 0], [2, 1, 0]], ppt: true },
  neu: { n: 'প্রশমন', eq: 'HCl + NaOH → NaCl + H₂O', tags: ['প্রশমন', 'দ্বি-প্রতিস্থাপন', 'তাপোৎপাদী'], note: 'এসিডের H⁺ ও ক্ষারের OH⁻ মিলে পানি: H⁺ + OH⁻ → H₂O (ΔH = −57.3 kJ mol⁻¹)। Na⁺ ও Cl⁻ দ্রবণে অপরিবর্তিত থাকে — এরা দর্শক আয়ন।',
    at: [['H⁺', 'H', CL.H, 12, 56, 70, 168, 116], ['Cl⁻', 'Cl⁻', CL.Cl, 20, 104, 70, 92, 162], ['Na⁺', 'Na⁺', CL.Na, 14, 348, 70, 314, 162], ['O⁻', 'O', CL.O, 18, 262, 70, 200, 92], ['H', 'H', CL.H, 12, 302, 70, 232, 116]],
    b0: [[3, 4, 1]], b1: [[3, 4, 1], [3, 0, 1]], spect: [1, 2] },
  red: { n: 'রেডক্স', eq: '2Na + Cl₂ → 2NaCl', tags: ['রেডক্স', 'সংযোজন', 'তাপোৎপাদী'], note: 'প্রতিটি Na পরমাণু একটি ইলেকট্রন ত্যাগ করে (জারণ: Na → Na⁺ + e⁻) এবং প্রতিটি Cl তা গ্রহণ করে (বিজারণ: Cl + e⁻ → Cl⁻)। লক্ষ্য করো — Na⁺ আয়ন Na পরমাণুর চেয়ে অনেক ছোট, Cl⁻ আয়ন Cl পরমাণুর চেয়ে বড়।',
    at: [['Na', 'Na⁺', CL.Na, 20, 64, 64, 160, 80, 12], ['Na', 'Na⁺', CL.Na, 20, 64, 146, 160, 146, 12], ['Cl', 'Cl⁻', CL.Cl, 15, 290, 106, 218, 80, 20], ['Cl', 'Cl⁻', CL.Cl, 15, 328, 106, 218, 146, 20]],
    b0: [[2, 3, 1]], b1: [[0, 2, 0], [1, 3, 0]], el: [[0, 2], [1, 3]] }
};
V.c4_rxnTypes = {
  t: 'রাসায়নিক বিক্রিয়ার শ্রেণি: পরমাণুর পুনর্বিন্যাস', k: ['anim', 'int', '2d'],
  cap: 'একটি শ্রেণি বেছে নাও। অ্যানিমেশনে দেখো বিক্রিয়ক অণুর বন্ধন ভেঙে (রেখা মিলিয়ে যায়) পরমাণুগুলো নতুনভাবে সাজে ও নতুন বন্ধন গঠন করে। নীল বিন্দু = স্থানান্তরিত ইলেকট্রন (রেডক্স)। কাটা রেখা = আয়নিক আকর্ষণ। স্লাইডার টেনে যেকোনো মুহূর্তে থামিয়ে দেখো — প্রতিটি পরমাণু উৎপাদেও উপস্থিত থাকে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('r', Object.keys(RX).map(k => [k, RX[k].n]), 'syn')}</div><div data-svg></div><div class="ctl"><button class="btn sm" data-pp></button><input type="range" min="0" max="100" value="0" data-t aria-label="বিক্রিয়ার অগ্রগতি" style="flex:1"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sl = el.querySelector('[data-t]');
    let key = 'syn', clock = 0, t = 0;
    const W = 400, H = 210, E = C4.ease;
    const info = () => { const R = RX[key]; out.innerHTML = `<div style="font-size:1.08em;font-weight:700;margin-bottom:4px">${R.eq}</div><div style="margin-bottom:6px">${R.tags.map(s => `<span class="chip" style="display:inline-block;padding:1px 8px;margin:0 4px 3px 0;border-radius:10px;background:var(--surface-3);font-size:.86em">${s}</span>`).join('')}</div><div class="small">${R.note}</div>`; };
    const draw = () => {
      const R = RX[key], m = E((t - 0.18) / 0.6);
      const P = R.at.map(a => [C4.lerp(a[4], a[6], m), C4.lerp(a[5], a[7], m) + (a[9] || 0) * Math.sin(Math.PI * m), a[8] ? C4.lerp(a[3], a[8], E((t - 0.2) / 0.45)) : a[3]]);
      const o0 = 1 - E(t / 0.22), o1 = E((t - 0.72) / 0.22);
      let s = '';
      const head = t < 0.5 ? 'বিক্রিয়ক' : 'উৎপাদ', hop = Math.abs(t - 0.5) * 2;
      s += `<text x="${W / 2}" y="18" text-anchor="middle" class="tb" style="font-size:13px;font-weight:700" opacity="${(0.25 + 0.75 * hop).toFixed(2)}">${head}</text>`;
      const bond = (i, j, ord, op) => {
        if (op < 0.02) return '';
        const [xa, ya] = P[i], [xb, yb] = P[j], dx = xb - xa, dy = yb - ya, L = Math.hypot(dx, dy) || 1, nx = -dy / L * 3.2, ny = dx / L * 3.2;
        if (ord === 0) return `<line x1="${f1(xa)}" y1="${f1(ya)}" x2="${f1(xb)}" y2="${f1(yb)}" class="s-mu" stroke-width="1.6" stroke-dasharray="3 3" opacity="${op.toFixed(2)}"/>`;
        if (ord === 2) return [1, -1].map(k => `<line x1="${f1(xa + k * nx)}" y1="${f1(ya + k * ny)}" x2="${f1(xb + k * nx)}" y2="${f1(yb + k * ny)}" class="s-fg" stroke-width="2.4" opacity="${op.toFixed(2)}"/>`).join('');
        return `<line x1="${f1(xa)}" y1="${f1(ya)}" x2="${f1(xb)}" y2="${f1(yb)}" class="s-fg" stroke-width="3" opacity="${op.toFixed(2)}"/>`;
      };
      R.b0.forEach(b => { s += bond(b[0], b[1], b[2], o0); });
      R.b1.forEach(b => { s += bond(b[0], b[1], b[2], o1); });
      // heat source for decomposition
      if (R.heat) { const ho = 1 - E((t - 0.6) / 0.3); s += `<g opacity="${(0.25 + 0.75 * ho).toFixed(2)}"><path d="M178 196 q-10 -14 2 -26 q-2 10 6 12 q4 -10 0 -18 q14 10 10 24 q-2 8 -18 8z" fill="#F08A3C"/><path d="M184 196 q-4 -8 2 -14 q2 6 6 6 q2 6 -8 8z" fill="#FFD25A"/><text x="206" y="194" class="tm" style="font-size:11px">তাপ (Δ)</text></g>`; }
      // precipitate tray
      if (R.ppt) { const po = E((t - 0.65) / 0.3); s += `<g opacity="${po.toFixed(2)}"><path d="M120 184 h140" stroke="#bbb" stroke-width="5" stroke-linecap="round"/><text x="191" y="202" text-anchor="middle" class="tm" style="font-size:10.5px">AgCl↓ সাদা অধঃক্ষেপ</text></g>`; }
      R.at.forEach((a, i) => {
        const lb = t < 0.5 ? a[0] : a[1], [x, y, r] = P[i];
        s += C4.atom(x, y, r, a[2], lb);
      });
      if (R.spect) { const so = E((t - 0.8) / 0.18); R.spect.forEach(i => { const [x, y, r] = P[i]; s += `<text x="${f1(x)}" y="${f1(y + r + 13)}" text-anchor="middle" class="tm" style="font-size:9.5px" opacity="${so.toFixed(2)}">দর্শক আয়ন</text>`; }); }
      // electrons
      if (R.el) {
        const te = (t - 0.08) / 0.5;
        if (te > -0.15 && te < 1.1) {
          R.el.forEach(([d, a], k) => {
            const u = E(te - k * 0.06), [xd, yd, rd] = P[d], [xa, ya] = P[a];
            const sx = xd + rd * 0.9, sy = yd - rd * 0.6 + k * 4;
            const x = C4.lerp(sx, xa, u), y = C4.lerp(sy, ya, u) - Math.sin(u * Math.PI) * 26;
            const op = te < 0 ? 1 + te / 0.15 : te > 0.95 ? Math.max(0, 1 - (te - 0.95) / 0.15) : 1;
            s += `<g opacity="${Math.max(0, op).toFixed(2)}"><circle cx="${f1(x)}" cy="${f1(y)}" r="5" fill="#2F6FB5" stroke="#fff" stroke-width="1"/><text x="${f1(x + 7)}" y="${f1(y - 5)}" style="font-size:10px;font-weight:700;fill:#2F6FB5">e⁻</text></g>`;
          });
        }
      }
      // progress strip
      s += `<rect x="40" y="${H - 6}" width="${W - 80}" height="3" rx="1.5" class="f-s3"/><rect x="40" y="${H - 6}" width="${f1((W - 80) * t)}" height="3" rx="1.5" class="f-acc"/>`;
      box.innerHTML = X.svg(W, H, s, 'বিক্রিয়ার কণা-চিত্র: ' + RX[key].eq);
    };
    const A = X.anim(el, dt => {
      if (dt) { clock = (clock + dt) % 6.5; t = clock < 1 ? 0 : clock < 4.2 ? (clock - 1) / 3.2 : 1; sl.value = Math.round(t * 100); }
      draw();
    });
    X.pp(el, A);
    sl.addEventListener('input', () => { if (!A.paused) { A.pause(true); X.pp(el, A); } t = sl.value / 100; clock = 1 + t * 3.2; draw(); });
    X.onSeg(el, 'r', k => { key = k; clock = 0; t = 0; sl.value = 0; info(); draw(); });
    info(); draw();
    return () => A.stop();
  }
};

/* ======================= ৪.১.১ অ্যাটম ইকোনমি: ভরের হিসাব ======================= */
const AE = {
  hyd: { n: 'C₂H₄ + H₂O', type: 'সংযোজন', r: [['C₂H₄', 28, '#7FB3E6'], ['H₂O', 18, '#9AD0EC']], p: [['C₂H₅OH', 46, 1]], eq: 'C₂H₄ + H₂O → C₂H₅OH' },
  dehy: { n: 'C₂H₅OH → C₂H₄', type: 'অপসারণ', r: [['C₂H₅OH', 46, '#7FB3E6']], p: [['C₂H₄', 28, 1], ['H₂O', 18, 0]], eq: 'C₂H₅OH → C₂H₄ + H₂O' },
  chl: { n: 'CH₄ + Cl₂', type: 'প্রতিস্থাপন', r: [['CH₄', 16, '#7FB3E6'], ['Cl₂', 71, '#9AD0EC']], p: [['CH₃Cl', 50.5, 1], ['HCl', 36.5, 0]], eq: 'CH₄ + Cl₂ → CH₃Cl + HCl' },
  lime: { n: 'CaCO₃', type: 'বিয়োজন', r: [['CaCO₃', 100, '#7FB3E6']], p: [['CaO', 56, 1], ['CO₂', 44, 0]], eq: 'CaCO₃ → CaO + CO₂' },
  iron: { n: 'Fe₂O₃ + 3CO', type: 'বিজারণ', r: [['Fe₂O₃', 159.7, '#7FB3E6'], ['3CO', 84, '#9AD0EC']], p: [['2Fe', 111.7, 1], ['3CO₂', 132, 0]], eq: 'Fe₂O₃ + 3CO → 2Fe + 3CO₂' },
  boots: { n: 'আইবুপ্রোফেন (বুটস)', type: '৬ ধাপ', r: [['৬ ধাপের সব বিকারক', 514.5, '#7FB3E6']], p: [['আইবুপ্রোফেন', 206, 1], ['উপজাত', 308.5, 0]], eq: 'বুটস পদ্ধতি (১৯৬০ এর দশক) — প্রতি মোল আইবুপ্রোফেন' },
  bhc: { n: 'আইবুপ্রোফেন (BHC)', type: '৩ ধাপ, প্রভাবক', r: [['৩ ধাপের সব বিকারক', 266.3, '#7FB3E6']], p: [['আইবুপ্রোফেন', 206, 1], ['CH₃COOH', 60.3, 0]], eq: 'BHC পদ্ধতি (১৯৯২) — প্রতি মোল আইবুপ্রোফেন' }
};
V.c4_atomEconomy = {
  t: 'অ্যাটম ইকোনমি: বিক্রিয়কের কত ভর কাঙ্ক্ষিত উৎপাদে যায়?', k: ['2d', 'int', 'calc'],
  cap: 'একটি বিক্রিয়া বেছে নাও। উপরের দণ্ড = সব বিক্রিয়কের মোট মোলার ভর (সহগসহ); নিচের দণ্ড = উৎপাদ — সবুজ অংশ কাঙ্ক্ষিত উৎপাদ, ধূসর ডোরাকাটা অংশ উপজাত/বর্জ্য। দুটি দণ্ড সমান দৈর্ঘ্যের — ভরের নিত্যতা। অ্যাটম ইকোনমি = সবুজ অংশ ÷ মোট × ১০০। আইবুপ্রোফেনের দুই পদ্ধতি তুলনা করে দেখো কেন BHC পদ্ধতি গ্রিন কেমিস্ট্রি পুরস্কার (১৯৯৭) পেয়েছিল। নিচে নিজের সংখ্যা দিয়েও হিসাব করা যায়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('r', Object.keys(AE).map(k => [k, AE[k].n]), 'hyd')}</div><div data-svg></div>
  <div class="grid2" style="margin-top:8px"><label class="small">বিক্রিয়কের মোট ভর (g mol⁻¹)<input class="inp" type="number" data-m1 value="87" min="0" step="any"></label><label class="small">কাঙ্ক্ষিত উৎপাদের ভর (g mol⁻¹)<input class="inp" type="number" data-m2 value="50.5" min="0" step="any"></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), i1 = el.querySelector('[data-m1]'), i2 = el.querySelector('[data-m2]');
    let key = 'hyd';
    const draw = () => {
      const R = AE[key], tot = R.r.reduce((a, b) => a + b[1], 0), want = R.p.filter(p => p[2]).reduce((a, b) => a + b[1], 0), ae = want / tot * 100;
      const W = 400, Hh = 214, x0 = 78, x1 = 384, sc = (x1 - x0) / tot;
      let s = `<defs><pattern id="c4aeH" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="6" height="6" fill="#B7BCC4"/><line x1="0" y1="0" x2="0" y2="6" stroke="#8E949E" stroke-width="2.4"/></pattern></defs>`;
      s += `<text x="${W / 2}" y="16" text-anchor="middle" class="tb" style="font-size:12.5px;font-weight:700">${R.eq}</text><text x="${W / 2}" y="31" text-anchor="middle" class="tm" style="font-size:10.5px">বিক্রিয়ার ধরন: ${R.type}</text>`;
      const bar = (y, segs, lab) => {
        let x = x0, t = `<text x="${x0 - 8}" y="${y + 21}" text-anchor="end" class="tb" style="font-size:11.5px;font-weight:700">${lab}</text>`;
        segs.forEach(([nm, m, fill]) => {
          const w = m * sc;
          t += `<rect x="${f1(x)}" y="${y}" width="${f1(w)}" height="32" fill="${fill}" stroke="rgba(0,0,0,.35)"/>`;
          const txt = `${nm}`, sub = `${bn(+m.toFixed(1))} g`;
          if (w > 62) t += `<text x="${f1(x + w / 2)}" y="${y + 14}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:${INK}">${txt}</text><text x="${f1(x + w / 2)}" y="${y + 27}" text-anchor="middle" style="font-size:10px;fill:${INK}">${sub}</text>`;
          else t += `<text x="${f1(x + w / 2)}" y="${y + 20}" text-anchor="middle" style="font-size:9.5px;font-weight:700;fill:${INK}">${txt}</text><text x="${f1(x + w / 2)}" y="${y + 44}" text-anchor="middle" class="tm" style="font-size:9.5px">${sub}</text>`;
          x += w;
        });
        return t;
      };
      s += bar(44, R.r, 'বিক্রিয়ক');
      // conservation arrows
      s += `<text x="${(x0 + x1) / 2}" y="98" text-anchor="middle" class="tm" style="font-size:10.5px">↓ মোট ভর অপরিবর্তিত = ${bn(+tot.toFixed(1))} g ↓</text>`;
      s += bar(106, R.p.map(p => [p[0], p[1], p[2] ? '#5DBB63' : 'url(#c4aeH)']), 'উৎপাদ');
      // legend
      s += `<rect x="${x0}" y="156" width="12" height="10" fill="#5DBB63" stroke="rgba(0,0,0,.35)"/><text x="${x0 + 16}" y="165" class="tm" style="font-size:10px">কাঙ্ক্ষিত উৎপাদ</text><rect x="${x0 + 118}" y="156" width="12" height="10" fill="url(#c4aeH)" stroke="rgba(0,0,0,.35)"/><text x="${x0 + 134}" y="165" class="tm" style="font-size:10px">উপজাত (বর্জ্য)</text>`;
      // meter
      const my = 182, mw = x1 - x0;
      s += `<rect x="${x0}" y="${my}" width="${mw}" height="14" rx="7" class="f-s3"/><rect x="${x0}" y="${my}" width="${f1(mw * ae / 100)}" height="14" rx="7" fill="${ae > 90 ? '#3FA34D' : ae > 60 ? '#8CC152' : ae > 45 ? '#E9B949' : '#E07B53'}"/>`;
      [0, 25, 50, 75, 100].forEach(v => { s += `<text x="${f1(x0 + mw * v / 100)}" y="${my + 27}" text-anchor="middle" class="tm" style="font-size:9.5px">${bn(v)}%</text>`; });
      s += `<text x="${x0 - 8}" y="${my + 11}" text-anchor="end" class="tb" style="font-size:11px;font-weight:700">AE</text>`;
      box.innerHTML = X.svg(W, Hh, s, 'অ্যাটম ইকোনমি দণ্ডচিত্র');
      return { tot, want, ae };
    };
    const calc = () => {
      const r = draw(), m1 = +i1.value, m2 = +i2.value;
      let own = '';
      if (m1 > 0 && m2 >= 0 && m2 <= m1) own = `<div style="margin-top:6px;border-top:1px solid var(--line);padding-top:6px">তোমার হিসাব: AE = ${bn(m2)} ÷ ${bn(m1)} × ১০০ = <b>${bn((m2 / m1 * 100).toFixed(1))}%</b> · উপজাত ${bn((m1 - m2).toFixed(1))} g</div>`;
      else if (m2 > m1) own = `<div style="margin-top:6px" class="small">কাঙ্ক্ষিত উৎপাদের ভর বিক্রিয়কের মোট ভরের চেয়ে বেশি হতে পারে না (ভরের নিত্যতা)।</div>`;
      out.innerHTML = `অ্যাটম ইকোনমি = ${bn(+r.want.toFixed(1))} ÷ ${bn(+r.tot.toFixed(1))} × ১০০ = <b>${bn(r.ae.toFixed(1))}%</b>${r.ae > 99.9 ? ' — কোনো উপজাত নেই, সব পরমাণু কাজে লেগেছে।' : ' — বাকি ' + bn((100 - r.ae).toFixed(1)) + '% ভর উপজাত হিসেবে যায়।'}${own}`;
    };
    X.onSeg(el, 'r', k => { key = k; calc(); });
    i1.addEventListener('input', calc); i2.addEventListener('input', calc);
    calc();
    const un = X.onResize(el, calc);
    return () => un();
  }
};
})();
