/* Chapter 4 visuals part 2 — reversible reactions & interconversion (4.2) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, f1 = C4.f1, INK = C4.INK;

/* ball with radial shading on canvas */
function ball(g, x, y, r, base, hi) {
  const gr = g.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
  gr.addColorStop(0, hi); gr.addColorStop(1, base);
  g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 0.7; g.stroke();
}
C4.ball = ball;

/* ======================= ৪.২ উভমুখী বিক্রিয়া: বদ্ধ পাত্রে H₂ + I₂ ⇌ 2HI ======================= */
V.c4_reversible = {
  t: 'বদ্ধ পাত্রে উভমুখী বিক্রিয়া: H₂ + I₂ ⇌ 2HI (কণা-সিমুলেশন)', k: ['anim', 'int', '2d'],
  cap: 'বদ্ধ পাত্রে অণুগুলো ছুটোছুটি করছে। H₂ (সাদা) ও I₂ (বেগুনি) এর কার্যকর সংঘর্ষে 2HI তৈরি হয় (সবুজ ঝলক = সম্মুখ বিক্রিয়া); দুটি HI এর সংঘর্ষে আবার H₂ ও I₂ ফিরে আসে (কমলা ঝলক = পশ্চাৎ বিক্রিয়া)। নিচের বাম লেখচিত্রে অণুর সংখ্যা, ডানে প্রতি সেকেন্ডে সম্মুখ ও পশ্চাৎ বিক্রিয়ার সংখ্যা (হার)। কিছুক্ষণ পর দুটি হার সমান হয় — সংখ্যা আর বদলায় না, অথচ ঝলক চলতেই থাকে: গতিশীল সাম্যাবস্থা। "শুধু HI দিয়ে শুরু" চাপলে দেখবে উল্টো দিক থেকেও একই সাম্য মিশ্রণে পৌঁছায়। "খোলা পাত্র" চালু করলে HI অণু বেরিয়ে যায় — পশ্চাৎ বিক্রিয়া বন্ধ, বিক্রিয়া একমুখী হয়ে সম্পূর্ণ হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('st', [['r', 'H₂ + I₂ দিয়ে শুরু'], ['p', 'শুধু HI দিয়ে শুরু']], 'r')}${X.seg('lid', [['c', 'বদ্ধ পাত্র'], ['o', 'খোলা পাত্র']], 'c')}</div>${X.cv('বদ্ধ পাত্রে H₂, I₂ ও HI অণুর সিমুলেশন ও লেখচিত্র')}<div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button><label style="flex:1;min-width:150px">গতি <input type="range" min="0.5" max="3" step="0.25" value="1.5" data-sp></label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), sp = el.querySelector('[data-sp]');
    let start = 'r', open = false, M = [], T = 0, hist = [], fx = [], ev = [], speed = 1.5, rf = 0, rb = 0, lastLog = 0;
    const N0 = 36, PF = 0.55, PB = 0.055;
    let L = X.fit(c, w => Math.min(560, w * 1.05));
    const R = X.rng(7);
    const box = () => { const W = L.W, pad = 10; return { x: pad, y: 26, w: W - 2 * pad, h: L.H * 0.52 - 26 }; };
    const mk = (t, b) => ({ t, x: b.x + 14 + R() * (b.w - 28), y: b.y + 14 + R() * (b.h - 28), vx: (R() - .5) * 70, vy: (R() - .5) * 70, a: R() * 6.28, w: (R() - .5) * 3 });
    const reset = () => {
      const b = box(); M = []; T = 0; hist = []; fx = []; ev = []; rf = rb = 0; lastLog = 0;
      if (start === 'r') { for (let i = 0; i < N0; i++) { M.push(mk('H', b)); M.push(mk('I', b)); } }
      else for (let i = 0; i < 2 * N0; i++) M.push(mk('HI', b));
    };
    const cnt = () => { const o = { H: 0, I: 0, HI: 0 }; M.forEach(m => o[m.t]++); return o; };
    const step = dt => {
      const b = box(); dt *= speed; T += dt;
      M.forEach(m => {
        m.x += m.vx * dt; m.y += m.vy * dt; m.a += m.w * dt;
        if (m.x < b.x + 8) { m.x = b.x + 8; m.vx = Math.abs(m.vx); } if (m.x > b.x + b.w - 8) { m.x = b.x + b.w - 8; m.vx = -Math.abs(m.vx); }
        if (m.y > b.y + b.h - 8) { m.y = b.y + b.h - 8; m.vy = -Math.abs(m.vy); }
        if (m.y < b.y + 8) { if (open && m.t === 'HI' && m.x > b.x + b.w * 0.3 && m.x < b.x + b.w * 0.7) { m.gone = true; } else { m.y = b.y + 8; m.vy = Math.abs(m.vy); } }
      });
      M = M.filter(m => !m.gone || m.y > b.y - 40);
      M.forEach(m => { if (m.gone) { m.vy = -60; } });
      M = M.filter(m => !(m.gone && m.y < b.y - 30));
      // reactions
      const act = M.filter(m => !m.gone);
      for (let i = 0; i < act.length; i++) {
        const a = act[i]; if (a.used) continue;
        for (let j = i + 1; j < act.length; j++) {
          const d = act[j]; if (d.used) continue;
          const dx = a.x - d.x, dy = a.y - d.y; if (dx * dx + dy * dy > 196) continue;
          const pair = a.t + d.t;
          if ((pair === 'HI' || pair === 'IH') && R() < PF * dt * 8) { a.t = 'HI'; d.t = 'HI'; a.used = d.used = true; fx.push({ x: (a.x + d.x) / 2, y: (a.y + d.y) / 2, k: 'f', t: 0 }); ev.push([T, 'f']); }
          else if (pair === 'HIHI' && R() < PB * dt * 8) { a.t = 'H'; d.t = 'I'; a.used = d.used = true; fx.push({ x: (a.x + d.x) / 2, y: (a.y + d.y) / 2, k: 'b', t: 0 }); ev.push([T, 'b']); }
          // elastic-ish bounce for non-reacting close pairs
          if (!a.used) { const tvx = a.vx; a.vx = d.vx; d.vx = tvx; const tvy = a.vy; a.vy = d.vy; d.vy = tvy; }
        }
      }
      act.forEach(m => { m.used = false; });
      fx.forEach(f => { f.t += dt; }); fx = fx.filter(f => f.t < 0.6);
      ev = ev.filter(e => T - e[0] < 3);
      const win = Math.min(3, T || 1);
      rf = ev.filter(e => e[1] === 'f').length / win; rb = ev.filter(e => e[1] === 'b').length / win;
      if (T - lastLog > 0.25) { lastLog = T; const o = cnt(); hist.push([T, o.H, o.I, o.HI, rf, rb]); if (hist.length > 400) hist.shift(); }
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(), b = box();
      g.clearRect(0, 0, W, H);
      // container
      g.fillStyle = col.s2; g.strokeStyle = col.fg; g.lineWidth = 2.2;
      g.beginPath(); g.roundRect(b.x, b.y, b.w, b.h, 10); g.fill();
      g.save(); g.beginPath(); g.roundRect(b.x, b.y, b.w, b.h, 10); g.clip();
      fx.forEach(f => { const r = 6 + f.t * 30; g.strokeStyle = f.k === 'f' ? `rgba(60,170,80,${1 - f.t / 0.6})` : `rgba(235,130,40,${1 - f.t / 0.6})`; g.lineWidth = 2.4; g.beginPath(); g.arc(f.x, f.y, r, 0, 7); g.stroke(); });
      M.forEach(m => {
        const ca = Math.cos(m.a), sa = Math.sin(m.a);
        if (m.t === 'H') { const d = 3.6; ball(g, m.x - ca * d, m.y - sa * d, 4.6, '#cfd3d8', '#ffffff'); ball(g, m.x + ca * d, m.y + sa * d, 4.6, '#cfd3d8', '#ffffff'); }
        else if (m.t === 'I') { const d = 5.4; ball(g, m.x - ca * d, m.y - sa * d, 6.6, '#6a3c96', '#c7a2ee'); ball(g, m.x + ca * d, m.y + sa * d, 6.6, '#6a3c96', '#c7a2ee'); }
        else { const d = 4.4; ball(g, m.x - ca * d * 1.2, m.y - sa * d * 1.2, 6.6, '#6a3c96', '#c7a2ee'); ball(g, m.x + ca * d * 1.3, m.y + sa * d * 1.3, 4.6, '#cfd3d8', '#ffffff'); }
      });
      g.restore();
      g.strokeStyle = col.fg; g.lineWidth = 2.2; g.beginPath(); g.roundRect(b.x, b.y, b.w, b.h, 10); g.stroke();
      if (open) { g.fillStyle = col.bg; g.fillRect(b.x + b.w * 0.3, b.y - 3, b.w * 0.4, 6); g.fillStyle = col.mu; g.font = `11px ${col.font}`; g.textAlign = 'center'; g.fillText('খোলা মুখ — HI বেরিয়ে যায়', b.x + b.w / 2, b.y - 8); }
      else { g.fillStyle = col.mu; g.font = `11px ${col.font}`; g.textAlign = 'center'; g.fillText('বদ্ধ পাত্র (৪৪৫ °C)', b.x + b.w / 2, b.y - 8); }
      // legend
      const ly = b.y + b.h + 16; g.textAlign = 'left'; g.font = `11px ${col.font}`;
      const lg = [['H₂', 'H'], ['I₂', 'I'], ['HI', 'HI']]; let lx = b.x + 4;
      lg.forEach(([n, t]) => { if (t === 'H') { ball(g, lx + 4, ly - 4, 4, '#cfd3d8', '#fff'); ball(g, lx + 10, ly - 4, 4, '#cfd3d8', '#fff'); } else if (t === 'I') { ball(g, lx + 4, ly - 4, 5.5, '#6a3c96', '#c7a2ee'); ball(g, lx + 13, ly - 4, 5.5, '#6a3c96', '#c7a2ee'); } else { ball(g, lx + 4, ly - 4, 5.5, '#6a3c96', '#c7a2ee'); ball(g, lx + 12, ly - 4, 4, '#cfd3d8', '#fff'); } g.fillStyle = col.fg; g.fillText(n, lx + 22, ly); lx += 54; });
      g.strokeStyle = 'rgba(60,170,80,1)'; g.lineWidth = 2; g.beginPath(); g.arc(lx + 5, ly - 4, 5, 0, 7); g.stroke(); g.fillStyle = col.fg; g.fillText('সম্মুখ', lx + 14, ly); lx += 52;
      g.strokeStyle = 'rgba(235,130,40,1)'; g.beginPath(); g.arc(lx + 5, ly - 4, 5, 0, 7); g.stroke(); g.fillText('পশ্চাৎ', lx + 14, ly);
      // graphs
      const gy0 = ly + 22, gh = H - gy0 - 26, gw = (W - 60) / 2;
      const plot = (x0, title, series, ymax, yl) => {
        g.strokeStyle = col.fg; g.lineWidth = 1.1; g.beginPath(); g.moveTo(x0, gy0); g.lineTo(x0, gy0 + gh); g.lineTo(x0 + gw, gy0 + gh); g.stroke();
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(title, x0 + gw / 2, gy0 - 6);
        g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.fillText('সময় →', x0 + gw / 2, gy0 + gh + 14);
        g.save(); g.translate(x0 - 8, gy0 + gh / 2); g.rotate(-Math.PI / 2); g.fillText(yl, 0, 0); g.restore();
        if (hist.length < 2) return;
        const t0 = hist[0][0], t1 = Math.max(hist[hist.length - 1][0], t0 + 10);
        series.forEach(([idx, color, dash]) => {
          g.strokeStyle = color; g.lineWidth = 2; g.setLineDash(dash || []); g.beginPath();
          hist.forEach((h, i) => { const x = x0 + (h[0] - t0) / (t1 - t0) * gw, y = gy0 + gh - Math.min(1, h[idx] / ymax) * gh; i ? g.lineTo(x, y) : g.moveTo(x, y); });
          g.stroke(); g.setLineDash([]);
          const hl = hist[hist.length - 1], ly2 = gy0 + gh - Math.min(1, hl[idx] / ymax) * gh; if (series.lab) { g.fillStyle = color; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText(series.lab[idx], x0 + gw, ly2 + (idx === 1 ? 12 : -5)); }
        });
      };
      const s1 = [[1, '#9aa3ad', [4, 3]], [2, '#7B4FA6'], [3, '#2E8B57']]; s1.lab = { 1: 'H₂', 2: 'I₂', 3: 'HI' }; plot(40, 'অণুর সংখ্যা', s1, 2 * N0, 'সংখ্যা');
      const rmax = Math.max(6, ...hist.map(h => Math.max(h[4], h[5]))) * 1.1;
      const s2 = [[4, 'rgba(60,170,80,1)'], [5, 'rgba(235,130,40,1)', [5, 3]]]; s2.lab = { 4: 'r_f', 5: 'r_b' }; plot(40 + gw + 28, 'বিক্রিয়ার হার', s2, rmax, 'হার');
    };
    const info = () => {
      const o = cnt(), tot = o.H + o.I + o.HI;
      const eq = hist.length > 30 && Math.abs(rf - rb) < Math.max(1.2, 0.25 * rf) && !open;
      out.innerHTML = `H₂: <b>${bn(o.H)}</b> · I₂: <b>${bn(o.I)}</b> · HI: <b>${bn(o.HI)}</b>${tot ? ` (HI ${bn(Math.round(o.HI / Math.max(1, o.HI + 2 * o.H) * 100))}%)` : ''}<br>সম্মুখ হার ≈ <b style="color:#3a9a4e">${bn(rf.toFixed(1))}</b> /s · পশ্চাৎ হার ≈ <b style="color:#d9782a">${bn(rb.toFixed(1))}</b> /s — ${open ? 'খোলা পাত্র: উৎপাদ বেরিয়ে যাচ্ছে, পশ্চাৎ বিক্রিয়া প্রায় বন্ধ — একমুখী।' : eq ? '<b>সাম্যাবস্থা:</b> r<sub>f</sub> ≈ r<sub>b</sub>, সংখ্যা প্রায় স্থির, কিন্তু বিক্রিয়া থামেনি।' : start === 'r' ? 'সম্মুখ হার বেশি — HI বাড়ছে।' : 'পশ্চাৎ হার বেশি — HI ভেঙে H₂ ও I₂ তৈরি হচ্ছে।'}`;
    };
    let ti = 0;
    const A = X.anim(el, dt => { if (dt) step(dt); draw(); ti += dt; if (ti > 0.3 || !dt) { ti = 0; info(); } }, { paused: false });
    X.pp(el, A);
    X.onSeg(el, 'st', k => { start = k; reset(); A.draw(); });
    X.onSeg(el, 'lid', k => { open = k === 'o'; A.draw(); });
    el.querySelector('[data-rs]').onclick = () => { reset(); A.draw(); };
    sp.oninput = () => { speed = +sp.value; };
    reset(); draw(); info();
    const un = X.onResize(el, () => { L = X.fit(c, w => Math.min(560, w * 1.05)); reset(); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.২.১ পারস্পরিক রূপান্তর: পরীক্ষাগারের দৃশ্য ======================= */
const lerpC = (a, b, t) => { const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return `rgb(${A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(',')})`; };
const EXP = {
  cu: { n: 'নীল তুঁতে', eq: 'CuSO₄·5H₂O(s, নীল) ⇌ CuSO₄(s, সাদা) + 5H₂O(g)', hot: 'উত্তপ্ত করো', cold: 'পানি দাও', dh: 'সম্মুখ ΔH = +78 kJ mol⁻¹', c0: '#2F7FD8', c1: '#F1F1EE' },
  co: { n: 'CoCl₂ দ্রবণ', eq: '[Co(H₂O)₆]²⁺ (গোলাপি) + 4Cl⁻ ⇌ [CoCl₄]²⁻ (নীল) + 6H₂O', hot: 'উত্তপ্ত করো', cold: 'বরফ-পানিতে রাখো', dh: 'সম্মুখ দিক তাপহারী', c0: '#E9A0BF', c1: '#2C55C9' },
  nh: { n: 'NH₄Cl', eq: 'NH₄Cl(s) ⇌ NH₃(g) + HCl(g)', hot: 'উত্তপ্ত করো', cold: 'থামাও', dh: 'সম্মুখ ΔH = +176 kJ mol⁻¹', c0: '#F4F4F2', c1: '#F4F4F2' },
  no: { n: 'N₂O₄ ⇌ 2NO₂', eq: 'N₂O₄(g, বর্ণহীন) ⇌ 2NO₂(g, বাদামি)', hot: 'গরম পানিতে রাখো', cold: 'বরফ-পানিতে রাখো', dh: 'সম্মুখ ΔH = +57.2 kJ mol⁻¹', c0: '#F3EFE6', c1: '#8A3E12' }
};
V.c4_interconvert = {
  t: 'পারস্পরিক রূপান্তর: চারটি পরীক্ষা (পরীক্ষাগারের দৃশ্য)', k: ['anim', 'int', '2d'],
  cap: 'একটি পরীক্ষা বেছে নিয়ে বোতাম চাপো। নীল তুঁতে: উত্তাপে কেলাস পানি বাষ্প হয়ে মুখের কাছে ফোঁটা জমে, কেলাস সাদা হয় (টিউবের মুখ সামান্য নিচু রাখা হয় যাতে ফোঁটা গরম তলায় না পড়ে টিউব ফাটায়); পানি দিলে নীল ফিরে আসে এবং থার্মোমিটারে তাপমাত্রা বাড়ে। CoCl₂: গরমে নীল, ঠান্ডায় গোলাপি। NH₄Cl: নিচের কঠিন উধাও হয়ে উপরের ঠান্ডা অংশে আবার জমে; মুখের ভেজা লিটমাস আগে নীল (হালকা NH₃ দ্রুত আসে) পরে লাল (ভারী HCl)। N₂O₄: বদ্ধ নলে গরমে গাঢ় বাদামি, ঠান্ডায় ফিকে — বৃত্তের ভেতরে অণু-স্তরের দৃশ্য।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('e', Object.keys(EXP).map(k => [k, EXP[k].n]), 'cu')}</div><div data-svg></div><div class="ctl"><button class="btn sm primary" data-hot></button><button class="btn sm" data-cold></button><button class="btn sm" data-rs>${X.ico('repeat')}শুরুর অবস্থা</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), bh = el.querySelector('[data-hot]'), bc = el.querySelector('[data-cold]');
    let key = 'cu', h = 0, mode = 0, clock = 0, temp = 25, drops = [], lit = 0, gas = [], deposit = 0; // mode: 1 heat, -1 cool/water, 0 idle
    const R = X.rng(11);
    const crystals = Array.from({ length: 26 }, () => [R(), R(), 0.6 + R() * 0.6, R() * 6.28]);
    const reset = () => { h = 0; mode = 0; temp = 25; drops = []; lit = 0; gas = []; deposit = 0; clock = 0; };
    const labels = () => { const E = EXP[key]; bh.innerHTML = X.ico('fire') + E.hot; bc.innerHTML = E.cold; };
    const step = dt => {
      clock += dt;
      if (mode === 1) { h = Math.min(1, h + dt * (key === 'nh' ? 0.09 : 0.16)); temp = Math.min(key === 'no' ? 80 : 160, temp + dt * 30); }
      else if (mode === -1) {
        if (key === 'cu') { if (drops.length < 6 && R() < dt * 3) drops.push({ y: 0 }); }
        else if (key !== 'nh') { h = Math.max(0, h - dt * 0.18); temp = Math.max(key === 'no' || key === 'co' ? 2 : 25, temp - dt * 35); }
        else { temp = Math.max(25, temp - dt * 25); }
      } else temp += (25 - temp) * Math.min(1, dt * 0.3);
      drops.forEach(d => { d.y += dt * 1.4; if (d.y >= 1 && !d.done) { d.done = true; h = Math.max(0, h - 0.22); temp = Math.min(70, temp + 9); } });
      drops = drops.filter(d => d.y < 1.05);
      if (key === 'nh') {
        if (mode === 1 && h < 1 && R() < dt * 9) { gas.push({ k: 'n', y: 0, x: R() }); if (R() < 0.9) gas.push({ k: 'h', y: 0, x: R() }); }
        gas.forEach(p => { p.y += dt * (p.k === 'n' ? 0.55 : 0.38); });
        gas.forEach(p => { if (p.y > 0.62 && !p.dep) { p.dep = true; deposit = Math.min(1, deposit + 0.012); } if (p.y > 1 && !p.lit) { p.lit = true; lit += p.k === 'n' ? 1 : -1.4; } });
        gas = gas.filter(p => p.y < 1.02 && !(p.dep && R() < 0.75));
      }
    };
    const draw = () => {
      const E = EXP[key], W = 400, H = 270;
      let s = `<defs><linearGradient id="c4icG" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".25" stop-color="#fff" stop-opacity=".08"/><stop offset=".8" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity=".25"/></linearGradient>
      <radialGradient id="c4icF" cx=".5" cy=".85" r=".8"><stop offset="0" stop-color="#bfe3ff"/><stop offset=".45" stop-color="#4c8ff0"/><stop offset="1" stop-color="#2a56c9" stop-opacity=".1"/></radialGradient>
      <linearGradient id="c4icB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cfd5dc"/><stop offset="1" stop-color="#8d96a1"/></linearGradient></defs>`;
      // bench
      s += `<rect x="0" y="252" width="${W}" height="18" fill="#b98a5a" opacity=".55"/><line x1="0" y1="252" x2="${W}" y2="252" stroke="#7a5532" stroke-width="1.2"/>`;
      // stand
      s += `<rect x="20" y="244" width="90" height="8" rx="2" fill="url(#c4icB)" stroke="#5f6670"/><rect x="34" y="38" width="6" height="206" fill="url(#c4icB)" stroke="#5f6670"/>`;
      const sealed = key === 'no', bath = key === 'no' || (key === 'co' && mode === -1);
      const tilt = key === 'cu' ? -14 : 0, tx = 190, ty = 46, tw = 36, tl = sealed ? 150 : 160;
      // burner (not for bath experiments when cooling)
      const heating = mode === 1 && key !== 'no';
      if (!(key === 'no')) {
        s += `<g transform="translate(${tx - 12} 0)"><rect x="-14" y="236" width="52" height="16" rx="3" fill="url(#c4icB)" stroke="#5f6670"/><rect x="4" y="200" width="16" height="38" fill="url(#c4icB)" stroke="#5f6670"/><rect x="2" y="196" width="20" height="6" rx="1" fill="#6b737d"/>`;
        if (heating) { const fl = 1 + 0.08 * Math.sin(clock * 22); s += `<path d="M12 196 C ${f1(-2)} ${f1(196 - 28 * fl)} 6 ${f1(196 - 44 * fl)} 12 ${f1(196 - 58 * fl)} C 18 ${f1(196 - 44 * fl)} 26 ${f1(196 - 28 * fl)} 12 196Z" fill="url(#c4icF)" opacity=".95"/><path d="M12 196 C 7 186 10 176 12 ${f1(196 - 30 * fl)} C 14 176 17 186 12 196Z" fill="#e8f6ff"/>`; }
        s += `</g>`;
      }
      // water bath
      if (bath) {
        const hot = key === 'no' ? mode === 1 : false, bw = 92, bx = tx - bw / 2 + tw / 2 - 18, by = 120;
        const wc = hot ? 'rgba(240,120,80,.28)' : 'rgba(110,170,235,.30)';
        s += `<path d="M${bx} ${by} v122 q0 10 10 10 h${bw - 20} q10 0 10 -10 v-122" fill="none" class="s-fg" stroke-width="1.6"/><rect x="${bx + 1}" y="${by + 22}" width="${bw - 2}" height="109" rx="8" fill="${wc}"/>`;
        if (!hot && (mode === -1)) for (let i = 0; i < 5; i++) s += `<rect x="${bx + 8 + i * 15}" y="${by + 26 + (i % 2) * 8}" width="12" height="11" rx="2" fill="rgba(235,248,255,.85)" stroke="rgba(120,170,220,.9)" transform="rotate(${(i * 23) % 30 - 12} ${bx + 14 + i * 15} ${by + 32})"/>`;
        if (hot) for (let i = 0; i < 3; i++) { const yy = by + 10 - ((clock * 18 + i * 9) % 26); s += `<path d="M${bx + 20 + i * 24} ${f1(yy + 14)} q4 -5 0 -10 q-4 -5 0 -10" fill="none" stroke="rgba(230,110,70,.6)" stroke-width="1.5"/>`; }
        s += `<text x="${bx + bw / 2}" y="${by + 124}" text-anchor="middle" style="font-size:10px;font-weight:600;fill:${INK}">${hot ? 'গরম পানি (~৮০ °C)' : 'বরফ-পানি (~০ °C)'}</text>`;
      }
      // clamp arm
      s += `<rect x="40" y="${ty + 38}" width="${tx - 40 + 6}" height="6" fill="url(#c4icB)" stroke="#5f6670"/><rect x="${tx - 8}" y="${ty + 30}" width="${tw + 16}" height="22" rx="4" fill="none" stroke="#5f6670" stroke-width="3"/>`;
      // tube group
      s += `<g transform="rotate(${tilt} ${tx + tw / 2} ${ty + 40})">`;
      const inner = (x, y, w, l) => sealed ? `M${x} ${y + w / 2} a${w / 2} ${w / 2} 0 0 1 ${w} 0 v${l - w} a${w / 2} ${w / 2} 0 0 1 ${-w} 0z` : `M${x} ${y} v${l - w / 2} a${w / 2} ${w / 2} 0 0 0 ${w} 0 v${-(l - w / 2)}`;
      // contents
      const bot = ty + tl;
      if (key === 'cu') {
        const fillTop = bot - 40;
        crystals.forEach(([a, b, sz, rot], i) => { const cx = tx + 6 + a * (tw - 12), cy = fillTop + 8 + b * 26, k = Math.min(1, Math.max(0, h * 1.25 - (1 - b) * 0.25)); s += `<rect x="${f1(cx - 4 * sz)}" y="${f1(cy - 3 * sz)}" width="${f1(8 * sz)}" height="${f1(6 * sz)}" fill="${lerpC(E.c0, E.c1, k)}" stroke="rgba(0,0,0,.25)" stroke-width=".6" transform="rotate(${f1(rot * 30)} ${f1(cx)} ${f1(cy)})"/>`; });
        // condensed droplets near mouth
        const dn = Math.round(h * 9); for (let i = 0; i < dn; i++) s += `<ellipse cx="${f1(tx + 4 + (i % 2) * (tw - 8))}" cy="${f1(ty + 14 + i * 5)}" rx="2.4" ry="3.2" fill="rgba(120,180,240,.75)" stroke="rgba(60,120,200,.6)" stroke-width=".5"/>`;
        if (mode === 1 && h < 1) for (let i = 0; i < 4; i++) { const yy = bot - 46 - ((clock * 40 + i * 22) % 90); s += `<circle cx="${f1(tx + tw / 2 + Math.sin(clock * 3 + i) * 8)}" cy="${f1(yy)}" r="2" fill="rgba(160,190,220,.55)"/>`; }
      } else if (key === 'co') {
        const lvl = bot - 70; s += `<path d="M${tx + 1} ${lvl} v${70 - tw / 2} a${tw / 2 - 1} ${tw / 2 - 1} 0 0 0 ${tw - 2} 0 v${-(70 - tw / 2)}z" fill="${lerpC(E.c0, E.c1, h)}" opacity=".92"/><ellipse cx="${tx + tw / 2}" cy="${lvl}" rx="${tw / 2 - 1}" ry="3" fill="rgba(255,255,255,.35)"/>`;
      } else if (key === 'nh') {
        const amt = Math.max(0, 1 - h); const sh = 26 * amt;
        if (sh > 0.5) s += `<path d="M${tx + 1} ${f1(bot - sh - 6)} q${tw / 4} -4 ${tw / 2} 0 t${tw / 2 - 2} 0 v${f1(sh + 6 - tw / 2)} a${tw / 2 - 1} ${tw / 2 - 1} 0 0 1 ${-(tw - 2)} 0z" fill="#f5f5f2" stroke="#bbb" stroke-width=".8"/>`;
        // deposit band at cool upper part
        if (deposit > 0.01) s += `<rect x="${tx + 1}" y="${ty + 34}" width="3.5" height="${f1(10 + 30 * deposit)}" fill="#f2f2ee" stroke="#c5c5c0" stroke-width=".5"/><rect x="${tx + tw - 4.5}" y="${ty + 34}" width="3.5" height="${f1(10 + 30 * deposit)}" fill="#f2f2ee" stroke="#c5c5c0" stroke-width=".5"/>`;
        gas.forEach(p => { const y = bot - 20 - p.y * (tl - 10), x = tx + 6 + p.x * (tw - 12); s += `<circle cx="${f1(x)}" cy="${f1(y)}" r="2.6" fill="${p.k === 'n' ? '#3b74d9' : '#d9443b'}"/>`; });
        // litmus at mouth
        const lc = lit > 1.5 ? (lit > 4 ? '#3B6FD0' : '#7f74c9') : lit < -2 ? '#D04A3B' : '#9b7fb3';
        s += `<rect x="${tx + tw / 2 - 5}" y="${ty - 30}" width="10" height="34" rx="1.5" fill="${lc}" stroke="rgba(0,0,0,.35)"/>`;
      } else {
        // sealed gas tube + molecule inset
        s += `<path d="${inner(tx + 1, ty + 1, tw - 2, tl - 2)}" fill="rgba(138,62,18,${f1(0.04 + 0.78 * h)})"/>`;
      }
      // glass
      s += `<path d="${inner(tx, ty, tw, tl)}" fill="url(#c4icG)" class="s-fg" stroke-width="1.6"/>`;
      if (!sealed) s += `<ellipse cx="${tx + tw / 2}" cy="${ty}" rx="${tw / 2 + 2}" ry="3" fill="none" class="s-fg" stroke-width="1.4"/>`;
      // dropper
      if (key === 'cu' && mode === -1) {
        s += `<g><rect x="${tx + tw / 2 - 4}" y="${ty - 58}" width="8" height="40" rx="2" fill="rgba(220,235,250,.8)" class="s-fg" stroke-width="1"/><path d="M${tx + tw / 2 - 2} ${ty - 18} l2 8 l2 -8z" class="f-fg"/><rect x="${tx + tw / 2 - 7}" y="${ty - 74}" width="14" height="18" rx="6" fill="#d24b4b"/></g>`;
        drops.forEach(d => { s += `<ellipse cx="${tx + tw / 2}" cy="${f1(ty - 8 + d.y * (tl - 34))}" rx="2.6" ry="3.6" fill="rgba(80,150,230,.85)"/>`; });
      }
      s += `</g>`;
      // thermometer
      const thx = 300, thy = 54, thl = 150, tf = Math.max(0, Math.min(1, (temp + 10) / 180));
      s += `<rect x="${thx - 5}" y="${thy}" width="10" height="${thl}" rx="5" fill="var(--surface)" class="s-fg" stroke-width="1.2"/><circle cx="${thx}" cy="${thy + thl + 8}" r="9" fill="#d23b3b" class="s-fg" stroke-width="1.2"/><rect x="${thx - 2.2}" y="${f1(thy + thl - tf * (thl - 6))}" width="4.4" height="${f1(tf * (thl - 6) + 6)}" fill="#d23b3b"/>`;
      [0, 50, 100, 150].forEach(v => { const yy = thy + thl - (v + 10) / 180 * (thl - 6); s += `<line x1="${thx + 5}" y1="${f1(yy)}" x2="${thx + 10}" y2="${f1(yy)}" class="s-fg"/><text x="${thx + 13}" y="${f1(yy + 3.5)}" class="tm" style="font-size:9.5px">${bn(v)}°</text>`; });
      s += `<text x="${thx}" y="${thy - 8}" text-anchor="middle" class="tb" style="font-size:11px;font-weight:700">${bn(Math.round(temp))} °C</text>`;
      // molecular inset for N2O4 / CoCl2
      if (key === 'no' || key === 'co') {
        const ix = 352, iy = 190, ir = 34;
        s += `<circle cx="${ix}" cy="${iy}" r="${ir}" fill="var(--surface)" class="s-fg" stroke-width="1.2"/><line x1="${tx + tw}" y1="${ty + tl * 0.6}" x2="${ix - ir}" y2="${iy}" class="s-mu" stroke-dasharray="3 3"/><text x="${ix}" y="${iy - ir - 5}" text-anchor="middle" class="tm" style="font-size:9.5px">অণু-দৃশ্য</text>`;
        const RR = X.rng(5), nU = 6;
        for (let i = 0; i < nU; i++) {
          const a = i / nU * 6.28 + 0.3, rr = 10 + (i % 2) * 11, cx = ix + Math.cos(a) * rr, cy = iy + Math.sin(a) * rr, split = RR() < h * 1.05 && h > 0.05;
          if (key === 'no') {
            if (split) { s += `<circle cx="${f1(cx - 6)}" cy="${f1(cy)}" r="4.2" fill="#9b4a1a"/><circle cx="${f1(cx + 6)}" cy="${f1(cy + 2)}" r="4.2" fill="#9b4a1a"/>`; }
            else s += `<circle cx="${f1(cx - 3)}" cy="${f1(cy)}" r="4.2" fill="#e8dfcf" stroke="#999" stroke-width=".6"/><circle cx="${f1(cx + 3)}" cy="${f1(cy)}" r="4.2" fill="#e8dfcf" stroke="#999" stroke-width=".6"/>`;
          } else s += `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="5.2" fill="${split ? '#2C55C9' : '#E9A0BF'}" stroke="rgba(0,0,0,.3)" stroke-width=".6"/>`;
        }
        s += `<text x="${ix}" y="${iy + ir + 12}" text-anchor="middle" class="tm" style="font-size:9px">${key === 'no' ? 'সাদা জোড়া: N₂O₄' : 'গোলাপি: [Co(H₂O)₆]²⁺'}</text><text x="${ix}" y="${iy + ir + 23}" text-anchor="middle" class="tm" style="font-size:9px">${key === 'no' ? 'বাদামি: NO₂' : 'নীল: [CoCl₄]²⁻'}</text>`;
      }
      if (key === 'nh') s += `<text x="${tx + tw / 2 + 12}" y="${ty - 24}" class="tm" style="font-size:9.5px">ভেজা লিটমাস</text><text x="${tx + tw + 8}" y="${ty + 64}" class="tm" style="font-size:9.5px">ঠান্ডা অংশে</text><text x="${tx + tw + 8}" y="${ty + 76}" class="tm" style="font-size:9.5px">NH₄Cl জমে</text><circle cx="${tx + tw + 10}" cy="${ty + 92}" r="3" fill="#3b74d9"/><text x="${tx + tw + 16}" y="${ty + 95}" class="tm" style="font-size:9.5px">NH₃</text><circle cx="${tx + tw + 10}" cy="${ty + 104}" r="3" fill="#d9443b"/><text x="${tx + tw + 16}" y="${ty + 107}" class="tm" style="font-size:9.5px">HCl</text>`;
      box.innerHTML = X.svg(W, H, s, 'পারস্পরিক রূপান্তরের পরীক্ষা: ' + E.n);
    };
    const info = () => {
      const E = EXP[key];
      const st = {
        cu: h > 0.9 ? 'কেলাস প্রায় সম্পূর্ণ সাদা — অনার্দ্র CuSO₄; মুখে পানির ফোঁটা।' : h > 0.1 ? 'কেলাস পানি বের হচ্ছে, নীল রং ফিকে হচ্ছে।' : 'নীল কেলাস (CuSO₄·5H₂O)।',
        co: h > 0.6 ? 'নীল — [CoCl₄]²⁻ প্রাধান্য (সম্মুখ দিক)।' : h > 0.3 ? 'বেগুনি — দুটি আয়নের মিশ্রণ।' : 'গোলাপি — [Co(H₂O)₆]²⁺ প্রাধান্য।',
        nh: lit < -2 ? 'লিটমাস লাল — HCl পৌঁছেছে; উপরে সাদা NH₄Cl জমেছে।' : lit > 1.5 ? 'লিটমাস নীল — দ্রুতগামী NH₃ আগে পৌঁছেছে।' : h > 0.05 ? 'NH₄Cl বিযোজিত হচ্ছে।' : 'টিউবের তলায় সাদা NH₄Cl।',
        no: h > 0.6 ? 'গাঢ় বাদামি — NO₂ বেশি।' : h > 0.25 ? 'হালকা বাদামি।' : 'প্রায় বর্ণহীন — N₂O₄ বেশি।'
      }[key];
      out.innerHTML = `<b style="font-family:var(--font-body)">${E.eq}</b><br><span class="small">${E.dh}</span><div style="margin-top:4px">${st}${key === 'cu' && mode === -1 && drops.length ? ' পানিযোজন তাপোৎপাদী — তাপমাত্রা বাড়ছে।' : ''}</div>`;
    };
    let ti = 0;
    const A = X.anim(el, dt => { if (dt) step(dt); draw(); ti += dt; if (ti > 0.25) { ti = 0; info(); } }, { paused: false });
    bh.onclick = () => { mode = 1; if (key === 'nh') { lit = 0; } A.draw(); };
    bc.onclick = () => { mode = key === 'nh' ? 0 : -1; A.draw(); };
    el.querySelector('[data-rs]').onclick = () => { reset(); A.draw(); info(); };
    X.onSeg(el, 'e', k => { key = k; reset(); labels(); info(); A.draw(); });
    labels(); draw(); info();
    return () => A.stop();
  }
};
})();
