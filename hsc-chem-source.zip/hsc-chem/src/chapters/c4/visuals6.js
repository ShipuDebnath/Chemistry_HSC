/* Chapter 4 visuals part 6 — chemical equilibrium (4.5) and Le Chatelier (4.6) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
const legend = (g, items, x, y, col) => { g.font = `10.5px ${col.font}`; g.textAlign = 'left'; let cx = x; items.forEach(([nm, cc, dash]) => { g.strokeStyle = cc; g.lineWidth = 2.6; g.setLineDash(dash ? [5, 3] : []); g.beginPath(); g.moveTo(cx, y); g.lineTo(cx + 16, y); g.stroke(); g.setLineDash([]); g.fillStyle = col.fg; g.fillText(nm, cx + 20, y + 3.5); cx += 26 + g.measureText(nm).width + 10; }); };
const ring = (g, x, y, r, c, a) => { g.strokeStyle = c; g.globalAlpha = Math.max(0, a); g.lineWidth = 2; g.beginPath(); g.arc(x, y, r, 0, 7); g.stroke(); g.globalAlpha = 1; };
const glassBox = (g, x, y, w, h, col) => {
  const gr = g.createLinearGradient(x, y, x + w, y); gr.addColorStop(0, 'rgba(180,210,235,.16)'); gr.addColorStop(0.5, 'rgba(255,255,255,.04)'); gr.addColorStop(1, 'rgba(180,210,235,.16)');
  g.fillStyle = gr; g.fillRect(x, y, w, h); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.strokeRect(x, y, w, h);
  g.fillStyle = 'rgba(255,255,255,.22)'; g.fillRect(x + 5, y + 6, 3, h - 12);
};

/* ======================= ৪.৫ সাম্যাবস্থায় পৌঁছানো: A ⇌ B কণা-সিমুলেশন ======================= */
V.c4_equilibriumSim = {
  t: 'সাম্যাবস্থায় পৌঁছানো: A ⇌ B (কণা-সিমুলেশন, ঘনমাত্রা-সময় ও হার-সময় লেখচিত্র)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'পাত্রে ১০০টি অণু: নীল = A, কমলা (জোড়া বল) = B। প্রতি মুহূর্তে প্রতিটি A অণু k_f হারে B তে এবং প্রতিটি B অণু k_b হারে A তে রূপান্তরিত হয় (সবুজ বলয় = সম্মুখ, লাল বলয় = পশ্চাৎ)। ডানে উপরে ঘনমাত্রা-সময়: পুরু রেখা = কণা গণনা, ড্যাশ রেখা = তাত্ত্বিক বক্ররেখা। নিচে হার-সময়: সম্মুখ হার k_f[A] কমে, পশ্চাৎ হার k_b[B] বাড়ে — যেখানে দুটি মেলে সেখানেই সাম্য (খাড়া ড্যাশ রেখা)। "শুধু B" দিয়ে শুরু করলে উল্টো দিক থেকে একই সাম্য সংযুতিতে পৌঁছায়। স্লাইডারে k_f বা k_b বদলালে K = k_f/k_b বদলায় এবং নতুন সাম্য সংযুতি তৈরি হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('st', [['a', 'শুধু A দিয়ে শুরু'], ['b', 'শুধু B দিয়ে শুরু'], ['m', 'A ও B সমান']], 'a')}</div>${X.cv('A ⇌ B সাম্যাবস্থায় পৌঁছানোর সিমুলেশন')}<div class="grid2" style="margin-top:8px"><label class="small">k<sub>f</sub> (সম্মুখ) = <b data-kfv></b> s⁻¹<input type="range" min="0.04" max="0.6" step="0.02" value="0.3" data-kf></label><label class="small">k<sub>b</sub> (পশ্চাৎ) = <b data-kbv></b> s⁻¹<input type="range" min="0.04" max="0.6" step="0.02" value="0.1" data-kb></label></div><div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 330 : w * 0.62 + 300;
    let L = X.fit(c, hf), st = 'a', kf = 0.3, kb = 0.1, t = 0, P = [], hist = [], a = 1, teq = null, acc = 0, outT = 0;
    const N = 100, R = X.rng(7), TW = 40;
    const reset = () => {
      P = []; for (let i = 0; i < N; i++) P.push({ x: R(), y: R(), vx: (R() - 0.5) * 0.5, vy: (R() - 0.5) * 0.5, s: st === 'a' ? 0 : st === 'b' ? 1 : i % 2, fl: 0, fd: 0, ang: R() * 6.28 });
      a = st === 'a' ? 1 : st === 'b' ? 0 : 0.5; t = 0; hist = []; teq = null; acc = 0; rec();
    };
    const cnt = () => P.reduce((s, p) => s + (p.s === 0), 0) / N;
    const rec = () => hist.push([t, cnt(), a]);
    const geo = () => { const W = L.W, H = L.H; if (wide(W)) { const bw = Math.min(250, W * 0.4); return { box: [10, 22, bw, H - 70], g1: [bw + 62, 16, W - bw - 80, (H - 90) / 2], g2: [bw + 62, 16 + (H - 90) / 2 + 42, W - bw - 80, (H - 90) / 2] }; } const bh = W * 0.62 - 30; return { box: [10, 22, W - 20, bh], g1: [52, bh + 52, W - 70, 100], g2: [52, bh + 196, W - 70, 80] }; };
    const step = dt => {
      const sd = dt; t += sd; acc += sd;
      P.forEach(p => {
        p.x += p.vx * sd * 0.35; p.y += p.vy * sd * 0.35; p.ang += sd * 1.5;
        if (p.x < 0.02 || p.x > 0.98) { p.vx *= -1; p.x = Math.max(0.02, Math.min(0.98, p.x)); }
        if (p.y < 0.03 || p.y > 0.97) { p.vy *= -1; p.y = Math.max(0.03, Math.min(0.97, p.y)); }
        const k = p.s === 0 ? kf : kb; if (R() < k * sd) { p.s = 1 - p.s; p.fl = 1; p.fd = p.s; }
        p.fl = Math.max(0, p.fl - sd * 2.2);
      });
      for (let i = 0; i < 10; i++) a += (-kf * a + kb * (1 - a)) * sd / 10;
      const aeq = kb / (kf + kb);
      if (teq === null && Math.abs(a - aeq) < 0.02 * Math.max(aeq, 1 - aeq)) teq = t;
      if (acc >= 0.1) { acc = 0; rec(); }
      while (hist.length && hist[0][0] < t - TW) hist.shift();
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo();
      const [bx, by, bw, bh] = G.box; glassBox(g, bx, by, bw, bh, col);
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('বদ্ধ পাত্র (১০০টি অণু)', bx + bw / 2, by - 7);
      const r = Math.max(4, Math.min(6.5, bw / 40));
      P.forEach(p => {
        const x = bx + 8 + p.x * (bw - 16), y = by + 6 + p.y * (bh - 12);
        if (p.s === 0) ball(g, x, y, r, '#1d55b8', '#9cc4ff');
        else { const ca = Math.cos(p.ang) * r * 0.75, sa = Math.sin(p.ang) * r * 0.75; ball(g, x - ca, y - sa, r * 0.8, '#c4621a', '#ffc58a'); ball(g, x + ca, y + sa, r * 0.8, '#c4621a', '#ffc58a'); }
        if (p.fl > 0) ring(g, x, y, r + 3 + (1 - p.fl) * 8, p.fd ? '#2e9d4e' : '#e0402e', p.fl);
      });
      const na = Math.round(cnt() * N);
      g.font = `11px ${col.font}`; g.textAlign = 'left'; ball(g, bx + 10, by + bh + 16, 5, '#1d55b8', '#9cc4ff'); g.fillStyle = col.fg; g.fillText(`A: ${bn(na)}`, bx + 20, by + bh + 20);
      ball(g, bx + bw / 2 - 8, by + bh + 16, 4, '#c4621a', '#ffc58a'); ball(g, bx + bw / 2, by + bh + 16, 4, '#c4621a', '#ffc58a'); g.fillText(`B: ${bn(N - na)}`, bx + bw / 2 + 8, by + bh + 20);
      g.fillStyle = col.mu; g.textAlign = 'right'; g.fillText(`t = ${fx(t, 1)} s`, bx + bw, by + bh + 20);
      // concentration graph
      const t0 = Math.max(0, t - TW), [x1, y1, w1, h1] = G.g1;
      const P1 = cplot(g, { x0: x1, y0: y1, w: w1, h: h1, xmin: t0, xmax: t0 + TW, ymax: 1.05, col, xt: [0, 10, 20, 30, 40].map(v => Math.round(t0 / 10) * 10 + v).filter(v => v >= t0 && v <= t0 + TW), yt: [0, 0.5, 1], fy: v => fx(v, 1), yl: 'ঘনমাত্রা (mol L⁻¹)', ylx: 36 });
      const aeq = kb / (kf + kb);
      g.setLineDash([2, 4]); g.strokeStyle = col.mu; g.lineWidth = 1; [aeq, 1 - aeq].forEach(v => { g.beginPath(); g.moveTo(x1, P1.Y(v)); g.lineTo(x1 + w1, P1.Y(v)); g.stroke(); }); g.setLineDash([]);
      if (hist.length > 1) {
        path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[1])]), '#1d55b8', 2.4); path(g, hist.map(h => [P1.X(h[0]), P1.Y(1 - h[1])]), '#d06a1e', 2.4);
        path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[2])]), '#1d55b8', 1.3, [5, 3]); path(g, hist.map(h => [P1.X(h[0]), P1.Y(1 - h[2])]), '#d06a1e', 1.3, [5, 3]);
      }
      legend(g, [['[A]', '#1d55b8'], ['[B]', '#d06a1e'], ['তাত্ত্বিক', col.mu, true]], x1 + 6, y1 + 2, col);
      // rate graph
      const [x2, y2, w2, h2] = G.g2, rmax = Math.max(kf, kb) * 1.08;
      const P2 = cplot(g, { x0: x2, y0: y2, w: w2, h: h2, xmin: t0, xmax: t0 + TW, ymax: rmax, col, xt: [0, 10, 20, 30, 40].map(v => Math.round(t0 / 10) * 10 + v).filter(v => v >= t0 && v <= t0 + TW), yt: [0, rmax / 2, rmax], fy: v => fx(v, 2), xl: 'সময় (s)', yl: 'হার', ylx: 36 });
      if (hist.length > 1) { path(g, hist.map(h => [P2.X(h[0]), P2.Y(kf * h[2])]), '#2e9d4e', 2.4); path(g, hist.map(h => [P2.X(h[0]), P2.Y(kb * (1 - h[2]))]), '#e0402e', 2.4); }
      legend(g, [['সম্মুখ হার k_f[A]', '#2e9d4e'], ['পশ্চাৎ হার k_b[B]', '#e0402e']], x2 + 6, y2 + 2, col);
      if (teq !== null && teq >= t0) { [[P1, y1, h1], [P2, y2, h2]].forEach(([PP, yy, hh]) => { g.strokeStyle = col.acc; g.setLineDash([4, 3]); g.lineWidth = 1.2; g.beginPath(); g.moveTo(PP.X(teq), yy); g.lineTo(PP.X(teq), yy + hh); g.stroke(); g.setLineDash([]); }); g.fillStyle = col.acc; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('সাম্য', P2.X(teq) + 4, y2 + h2 - 6); }
    };
    const info = () => {
      const K = kf / kb, aeq = kb / (kf + kb), Q = (1 - a) / Math.max(a, 1e-6), done = teq !== null;
      q('[data-kfv]').textContent = fx(kf, 2); q('[data-kbv]').textContent = fx(kb, 2);
      out.innerHTML = TXB(`\\ce{A <=>[k_f][k_b] B}`) + TXB(`K_c = \\dfrac{k_f}{k_b} = \\dfrac{${kf.toFixed(2)}}{${kb.toFixed(2)}} = ${K.toFixed(2)}`) +
        TXB(`[\\ce{A}]_{\\text{সাম্য}} = \\dfrac{k_b}{k_f + k_b} = ${aeq.toFixed(3)}`) + TXB(`[\\ce{B}]_{\\text{সাম্য}} = ${(1 - aeq).toFixed(3)}\\ \\mathrm{mol\\,L^{-1}}`) +
        TXB(`Q = \\dfrac{[\\ce{B}]}{[\\ce{A}]} = ${Q > 999 ? '\\infty' : Q.toFixed(2)}\\ ${done ? '\\approx K_c' : Q < K ? '< K_c\\ \\Rightarrow\\ \\text{সম্মুখ দিকে}' : '> K_c\\ \\Rightarrow\\ \\text{পশ্চাৎ দিকে}'}`) +
        `<div class="small">${done ? `সাম্যাবস্থা (t ≈ ${fx(teq, 1)} s): সম্মুখ হার = পশ্চাৎ হার; কণা গণনা গড় মানের চারপাশে সামান্য ওঠানামা করে, কিন্তু রূপান্তর থামে না — গতিশীল সাম্য।` : 'সাম্যের দিকে এগোচ্ছে — দুই হারের পার্থক্য ক্রমশ কমছে।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { step(dt); outT += dt; if (outT > 0.3) { outT = 0; info(); } } draw(); }, { paused: false });
    X.pp(el, A);
    q('[data-rs]').onclick = () => { reset(); info(); A.draw(); };
    X.onSeg(el, 'st', v => { st = v; reset(); info(); A.draw(); });
    q('[data-kf]').oninput = e => { kf = +e.target.value; teq = null; info(); A.draw(); };
    q('[data-kb]').oninput = e => { kb = +e.target.value; teq = null; info(); A.draw(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৫.১ গতিশীল সাম্যের প্রমাণ: আইসোটোপ চিহ্নিতকরণ ======================= */
V.c4_dynamicEq = {
  t: 'সাম্যাবস্থা গতিশীল — আইসোটোপ চিহ্নিতকরণ পরীক্ষা (¹³¹I ও ডিউটেরিয়াম)', k: ['anim', 'int', '2d'],
  cap: 'H₂ + I₂ ⇌ 2HI সাম্য মিশ্রণ (K = ৪৯)। "¹³¹I লেবেল" অবস্থায় সাম্য মিশ্রণের সব I₂ অণুর জায়গায় সমপরিমাণ তেজস্ক্রিয় ¹³¹I₂ (হলুদ বলয়যুক্ত বেগুনি) বসানো হয়েছে। সাম্য যদি স্থির হতো, তেজস্ক্রিয়তা কেবল I₂ তেই থাকত। কিন্তু কিছুক্ষণের মধ্যে HI অণুতেও তেজস্ক্রিয় I দেখা যায়, অথচ H₂, I₂, HI এর মোট সংখ্যা (উপরের লেখচিত্র) প্রায় স্থির — অর্থাৎ সম্মুখ ও পশ্চাৎ বিক্রিয়া সমান হারে চলছে। "D মিশ্রণ" অবস্থায় বাম পাশে H₂/I₂/HI ও ডানে D₂/I₂/DI এর দুটি আলাদা সাম্য মিশ্রণ; বিভাজক সরালে HD ও নতুন DI/HI অণু তৈরি হয় — আবারও মোট পরিমাণ স্থির কিন্তু পরমাণুর অদলবদল চলতে থাকে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['i', '¹³¹I লেবেল'], ['d', 'D (ডিউটেরিয়াম) মিশ্রণ']], 'i')}</div>${X.cv('আইসোটোপ চিহ্নিতকরণে গতিশীল সাম্যের প্রমাণ')}<div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button><button class="btn sm primary" data-part style="display:none">বিভাজক সরাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), bPart = q('[data-part]');
    const hf = w => w * 0.4 + (wide(w) ? 175 : 330);
    let L = X.fit(c, hf), mode = 'i', M = [], t = 0, part = false, hist = [], acc = 0, fl = [], outT = 0;
    const R = X.rng(31), TW = 60;
    const KB = { i: 0.0014, d: 0.0019 }, KEQ = 49;
    const mk = (type, a1, a2, side) => ({ type, a: [a1, a2], x: side === 1 ? 0.52 + R() * 0.45 : side === 0 ? 0.03 + R() * 0.45 : 0.03 + R() * 0.94, y: 0.05 + R() * 0.9, vx: (R() - 0.5), vy: (R() - 0.5), ang: R() * 6.3, side });
    const at = (el_, iso) => ({ el: el_, iso });
    const reset = () => {
      M = []; t = 0; hist = []; acc = 0; fl = [];
      if (mode === 'i') { part = false; for (let k = 0; k < 5; k++) M.push(mk('H2', at('H', 0), at('H', 0), -1)); for (let k = 0; k < 5; k++) M.push(mk('I2', at('I', 1), at('I', 1), -1)); for (let k = 0; k < 35; k++) M.push(mk('HI', at('H', 0), at('I', 0), -1)); }
      else { part = true; [0, 1].forEach(s => { for (let k = 0; k < 3; k++) M.push(mk('H2', at('H', s), at('H', s), s)); for (let k = 0; k < 3; k++) M.push(mk('I2', at('I', 0), at('I', 0), s)); for (let k = 0; k < 21; k++) M.push(mk('HI', at('H', s), at('I', 0), s)); }); }
      bPart.style.display = mode === 'd' ? '' : 'none'; bPart.disabled = false; rec();
    };
    const stats = () => {
      const s = { H2: 0, I2: 0, HI: 0, HH: 0, HD: 0, DD: 0, HIh: 0, DI: 0, Ilab: 0, IlabHI: 0, mixed: 0 };
      M.forEach(m => { s[m.type]++; if (m.type === 'H2') { const d = m.a[0].iso + m.a[1].iso; s[['HH', 'HD', 'DD'][d]]++; if (d === 1) s.mixed++; } if (m.type === 'HI') { if (m.a[0].iso) s.DI++; else s.HIh++; } m.a.forEach(x => { if (x.el === 'I' && x.iso) { s.Ilab++; if (m.type === 'HI') s.IlabHI++; } }); });
      return s;
    };
    const rec = () => { const s = stats(); hist.push([t, s.H2, s.I2, s.HI, mode === 'i' ? s.IlabHI / Math.max(1, s.Ilab) : (s.HD), s.DI]); };
    const pick = arr => arr.splice(Math.floor(R() * arr.length), 1)[0];
    const react = (side, vol, sd) => {
      const pool = m => part ? m.side === side : true;
      const H2 = M.filter(m => m.type === 'H2' && pool(m)), I2 = M.filter(m => m.type === 'I2' && pool(m)), HI = M.filter(m => m.type === 'HI' && pool(m));
      const kb = KB[mode], kf = kb * KEQ;
      const rf = kf * H2.length * I2.length / vol, rb = kb * HI.length * (HI.length - 1) / vol;
      if (H2.length && I2.length && R() < rf * sd) { const h = pick(H2), i = pick(I2); M = M.filter(m => m !== h && m !== i); const hs = R() < 0.5 ? [0, 1] : [1, 0]; const n1 = mk('HI', h.a[hs[0]], i.a[0], h.side), n2 = mk('HI', h.a[hs[1]], i.a[1], h.side); n1.x = h.x; n1.y = h.y; n2.x = i.x; n2.y = i.y; M.push(n1, n2); fl.push({ x: h.x, y: h.y, c: '#2e9d4e', a: 1 }, { x: i.x, y: i.y, c: '#2e9d4e', a: 1 }); }
      if (HI.length > 1 && R() < rb * sd) { const p1 = pick(HI), p2 = pick(HI); M = M.filter(m => m !== p1 && m !== p2); const n1 = mk('H2', p1.a[0], p2.a[0], p1.side), n2 = mk('I2', p1.a[1], p2.a[1], p1.side); n1.x = p1.x; n1.y = p1.y; n2.x = p2.x; n2.y = p2.y; M.push(n1, n2); fl.push({ x: p1.x, y: p1.y, c: '#e0802e', a: 1 }, { x: p2.x, y: p2.y, c: '#e0802e', a: 1 }); }
    };
    const step = dt => {
      t += dt; acc += dt;
      M.forEach(m => { m.x += m.vx * dt * 0.12; m.y += m.vy * dt * 0.2; m.ang += dt * 2; const lo = part ? (m.side === 1 ? 0.53 : 0.02) : 0.02, hi = part ? (m.side === 0 ? 0.47 : 0.98) : 0.98; if (m.x < lo || m.x > hi) { m.vx *= -1; m.x = Math.max(lo, Math.min(hi, m.x)); } if (m.y < 0.05 || m.y > 0.95) { m.vy *= -1; m.y = Math.max(0.05, Math.min(0.95, m.y)); } });
      for (let k = 0; k < 4; k++) { if (part) { react(0, 1, dt / 4); react(1, 1, dt / 4); } else react(-1, mode === 'd' ? 2 : 1, dt / 4); }
      fl.forEach(f => { f.a -= dt * 1.8; }); fl = fl.filter(f => f.a > 0);
      if (acc > 0.25) { acc = 0; rec(); } while (hist.length && hist[0][0] < t - TW) hist.shift();
    };
    const atomCol = a => a.el === 'I' ? ['#5b2a86', '#c7a2ec'] : a.iso ? ['#c0392b', '#ffb3a8'] : ['#c9ced6', '#ffffff'];
    const drawMol = (g, m, x, y, s) => {
      const big = e => e.el === 'I' ? 7 * s : 4.4 * s, r0 = big(m.a[0]), r1 = big(m.a[1]), d = (r0 + r1) * 0.62, ca = Math.cos(m.ang), sa = Math.sin(m.ang);
      const p0 = [x - ca * d * 0.5, y - sa * d * 0.5], p1 = [x + ca * d * 0.5, y + sa * d * 0.5];
      [[m.a[0], p0, r0], [m.a[1], p1, r1]].forEach(([a, p, r]) => { const [b, h] = atomCol(a); ball(g, p[0], p[1], r, b, h); if (a.el === 'I' && a.iso) { g.strokeStyle = '#f2c230'; g.lineWidth = 2; g.beginPath(); g.arc(p[0], p[1], r + 2, 0, 7); g.stroke(); } });
    };
    const geo = () => { const W = L.W, H = L.H, bh = W * 0.4; return { box: [10, 18, W - 20, bh], g1: wide(W) ? [50, bh + 62, (W - 120) / 2, H - bh - 110] : [50, bh + 62, W - 70, 95], g2: wide(W) ? [50 + (W - 120) / 2 + 52, bh + 62, (W - 120) / 2 - 2, H - bh - 110] : [50, bh + 222, W - 70, 75] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo(), [bx, by, bw, bh] = G.box;
      glassBox(g, bx, by, bw, bh, col);
      if (part) { g.fillStyle = col.s3; g.fillRect(bx + bw / 2 - 3, by, 6, bh); g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(bx + bw / 2 - 3, by, 6, bh); g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('H₂ + I₂ ⇌ 2HI', bx + bw / 4, by + bh - 6); g.fillText('D₂ + I₂ ⇌ 2DI', bx + bw * 0.75, by + bh - 6); }
      const s = Math.max(0.75, Math.min(1.15, bw / 560));
      M.forEach(m => drawMol(g, m, bx + m.x * bw, by + m.y * bh, s));
      fl.forEach(f => ring(g, bx + f.x * bw, by + f.y * bh, 14 + (1 - f.a) * 10, f.c, f.a));
      // key
      g.font = `10.5px ${col.font}`; g.textAlign = 'left'; let kx = bx + 4; const ky = by + bh + 16;
      const key = mode === 'i' ? [['H', ['#c9ced6', '#fff'], 4], ['I', ['#5b2a86', '#c7a2ec'], 6], ['¹³¹I (তেজস্ক্রিয়)', ['#5b2a86', '#c7a2ec'], 6, 1]] : [['H', ['#c9ced6', '#fff'], 4], ['D', ['#c0392b', '#ffb3a8'], 4], ['I', ['#5b2a86', '#c7a2ec'], 6]];
      key.forEach(([nm, cc, r, lab]) => { ball(g, kx + r, ky - 3, r, cc[0], cc[1]); if (lab) { g.strokeStyle = '#f2c230'; g.lineWidth = 2; g.beginPath(); g.arc(kx + r, ky - 3, r + 2, 0, 7); g.stroke(); } g.fillStyle = col.fg; g.fillText(nm, kx + 2 * r + 5, ky + 1); kx += 2 * r + 14 + g.measureText(nm).width; });
      g.fillStyle = col.mu; g.textAlign = 'right'; g.fillText(`t = ${fx(t, 1)} s`, bx + bw, ky + 1);
      // graph 1 totals
      const t0 = Math.max(0, t - TW), xt = [0, 20, 40, 60].map(v => Math.floor(t0 / 20) * 20 + v).filter(v => v >= t0 && v <= t0 + TW);
      const [x1, y1, w1, h1] = G.g1, ymax = mode === 'i' ? 45 : 50;
      const P1 = cplot(g, { x0: x1, y0: y1, w: w1, h: h1, xmin: t0, xmax: t0 + TW, ymax, col, xt, yt: [0, 20, 40], xl: 'সময় (s)', yl: 'অণুর সংখ্যা', ylx: 34 });
      if (hist.length > 1) { path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[3])]), '#2e9d4e', 2.2); path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[1])]), '#8a96a3', 2.2); path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[2])]), '#7b3fa0', 2.2, [5, 3]); }
      legend(g, [[mode === 'i' ? 'HI' : 'HI + DI', '#2e9d4e'], [mode === 'i' ? 'H₂' : 'H₂ + HD + D₂', '#8a96a3'], ['I₂', '#7b3fa0', true]], x1 + 4, y1 - 8, col);
      // graph 2 label spread
      const [x2, y2, w2, h2] = G.g2;
      if (mode === 'i') {
        const P2 = cplot(g, { x0: x2, y0: y2, w: w2, h: h2, xmin: t0, xmax: t0 + TW, ymax: 1, col, xt, yt: [0, 0.5, 1], fy: v => bn(Math.round(v * 100)) + '%', xl: 'সময় (s)', yl: 'HI তে ¹³¹I', ylx: 36 });
        g.setLineDash([3, 4]); g.strokeStyle = col.mu; g.lineWidth = 1; g.beginPath(); g.moveTo(x2, P2.Y(70 / 80)); g.lineTo(x2 + w2, P2.Y(70 / 80)); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('সম্পূর্ণ মিশ্রণে ৮৭.৫%', x2 + w2, P2.Y(70 / 80) + 12);
        if (hist.length > 1) path(g, hist.map(h => [P2.X(h[0]), P2.Y(h[4])]), '#e0a020', 2.6);
      } else {
        const P2 = cplot(g, { x0: x2, y0: y2, w: w2, h: h2, xmin: t0, xmax: t0 + TW, ymax: 25, col, xt, yt: [0, 10, 20], xl: 'সময় (s)', yl: 'নতুন অণু', ylx: 34 });
        if (hist.length > 1) { path(g, hist.map(h => [P2.X(h[0]), P2.Y(h[4])]), '#c0392b', 2.4); path(g, hist.map(h => [P2.X(h[0]), P2.Y(h[5])]), '#b0621e', 2.2, [5, 3]); }
        legend(g, [['HD', '#c0392b'], ['DI', '#b0621e', true]], x2 + 4, y2 - 8, col);
      }
    };
    const info = () => {
      const s = stats();
      if (mode === 'i') out.innerHTML = TXB(`\\ce{H2 + {}^{131}I2 <=> 2H{}^{131}I}`) + TXB(`K_c = \\dfrac{[\\ce{HI}]^2}{[\\ce{H2}][\\ce{I2}]} = 49`) + `<div class="small">এখন: H₂ = ${bn(s.H2)}, I₂ = ${bn(s.I2)}, HI = ${bn(s.HI)} — মোট সংখ্যা প্রায় স্থির। তেজস্ক্রিয় I পরমাণুর <b>${bn(Math.round(100 * s.IlabHI / Math.max(1, s.Ilab)))}%</b> এখন HI অণুতে। স্থির সাম্য হলে এটি ০% থাকত — তাই সাম্যাবস্থায় সম্মুখ ও পশ্চাৎ বিক্রিয়া চলমান।</div>`;
      else out.innerHTML = TXB(`\\ce{HI + DI <=> HD + I2}`) + `<div class="small">${part ? 'বিভাজক এখনো আছে — দুই পাশে আলাদা সাম্য। "বিভাজক সরাও" চাপো।' : `এখন: HD = ${bn(s.HD)}, H₂ = ${bn(s.HH)}, D₂ = ${bn(s.DD)}, HI = ${bn(s.HIh)}, DI = ${bn(s.DI)}। হাইড্রোজেন-জাতীয় অণুর মোট সংখ্যা (${bn(s.H2)}) ও I₂ (${bn(s.I2)}) প্রায় স্থির, অথচ HD এর মতো নতুন অণু তৈরি হচ্ছে — পরমাণুর অবিরাম অদলবদল প্রমাণ করে সাম্য গতিশীল।`}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { step(dt * 1.2); outT += dt; if (outT > 0.4) { outT = 0; info(); } } draw(); }, { paused: false });
    X.pp(el, A);
    bPart.onclick = () => { part = false; bPart.disabled = true; info(); };
    q('[data-rs]').onclick = () => { reset(); info(); A.draw(); };
    X.onSeg(el, 'm', v => { mode = v; reset(); info(); A.draw(); });
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৬ সাম্যে বিঘ্ন: হেবার মিশ্রণের ঘনমাত্রা-সময় ও হার-সময় লেখচিত্র ======================= */
V.c4_leGraphs = {
  t: 'সাম্যে বিঘ্ন ও পুনঃসাম্য: N₂ + 3H₂ ⇌ 2NH₃ এর ঘনমাত্রা-সময় ও হার-সময় লেখচিত্র', k: ['anim', 'int', '2d', 'calc'],
  cap: 'হেবার বিক্রিয়ার মিশ্রণ সাম্যে পৌঁছানোর পর নিচের বোতামগুলো দিয়ে বিঘ্ন ঘটাও এবং লেখচিত্রে প্রতিক্রিয়া দেখো। ঘনমাত্রা পরিবর্তনে কেবল একটি রেখায় খাড়া লাফ; চাপ বৃদ্ধিতে (আয়তন অর্ধেক) তিনটি রেখাই একসাথে দ্বিগুণ লাফ দেয়; তাপমাত্রা পরিবর্তনে কোনো লাফ নেই, রেখাগুলো ধীরে সরে, কারণ K নিজেই বদলায়। নিচের হার-সময় লেখচিত্রে বিঘ্নের মুহূর্তে সম্মুখ (সবুজ) ও পশ্চাৎ (লাল) হার আলাদা হয়ে যায় এবং আবার মিলিত হয়। প্রভাবক দুই হারকেই সমান অনুপাতে বাড়ায় — সংযুতি বদলায় না। প্রতিটি বিঘ্ন লেখচিত্রে নম্বর দিয়ে চিহ্নিত।',
  html: () => `${X.cv('হেবার সাম্যে বিঘ্নের লেখচিত্র')}<div class="ctl" style="flex-wrap:wrap;gap:6px;margin-top:8px"><button class="btn sm" data-d="n2">+ N₂</button><button class="btn sm" data-d="h2">+ H₂</button><button class="btn sm" data-d="rm">NH₃ সরাও</button><button class="btn sm" data-d="pu">চাপ ↑ (V/2)</button><button class="btn sm" data-d="pd">চাপ ↓ (2V)</button><button class="btn sm" data-d="tu">T ↑ ৫০ K</button><button class="btn sm" data-d="td">T ↓ ৫০ K</button><button class="btn sm" data-d="cat">প্রভাবক</button></div><div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 380 : 420;
    let L = X.fit(c, hf), st, hist, ev, t, T, cat, last = null, acc = 0, outT = 0;
    const TW = 60, K700 = 0.183, KF700 = 0.005, DH = -92000, EA = 60000, Rg = 8.314;
    const Kof = T_ => K700 * Math.exp(-DH / Rg * (1 / T_ - 1 / 700));
    const kfo = () => KF700 * Math.exp(-EA / Rg * (1 / T - 1 / 700)) * (cat ? 3 : 1);
    const reset = () => { st = { n: 1, h: 3, a: 0 }; hist = []; ev = []; t = 0; T = 700; cat = false; last = null; acc = 0; rec(); };
    const rates = () => { const kf = kfo(), kb = kf / Kof(T); return [kf * st.n * st.h ** 3, kb * st.a * st.a]; };
    const rec = () => { const [f, b] = rates(); hist.push([t, st.n, st.h, st.a, f, b]); };
    const step = dt => {
      const n = 40; for (let i = 0; i < n; i++) { const [f, b] = rates(), r = (f - b) * dt / n; st.n -= r; st.h -= 3 * r; st.a += 2 * r; st.n = Math.max(st.n, 1e-6); st.h = Math.max(st.h, 1e-6); st.a = Math.max(st.a, 0); }
      t += dt; acc += dt; if (acc >= 0.1) { acc = 0; rec(); }
      while (hist.length && hist[0][0] < t - TW) hist.shift(); while (ev.length && ev[0].t < t - TW) ev.shift();
    };
    const Q = () => st.a * st.a / (st.n * st.h ** 3);
    const D = {
      n2: ['N₂ যোগ (+০.৫০ M)', () => { st.n += 0.5; }, 'বিক্রিয়ক বাড়ায় Q < K — সাম্য ডানে: N₂ ও H₂ কিছুটা কমে, NH₃ বাড়ে। নতুন [N₂] আগের চেয়ে বেশি থাকে (আংশিক প্রশমন)।'],
      h2: ['H₂ যোগ (+১.০ M)', () => { st.h += 1; }, 'Q < K — সাম্য ডানে; NH₃ বাড়ে, N₂ কমে।'],
      rm: ['NH₃ অপসারণ (অর্ধেক)', () => { st.a *= 0.5; }, 'উৎপাদ কমায় Q < K — সাম্য ডানে সরে NH₃ আংশিক পূরণ হয়। শিল্পে NH₃ তরলীকরণ করে সরানো হয় ঠিক এই কারণে।'],
      pu: ['চাপ দ্বিগুণ (আয়তন অর্ধেক)', () => { st.n *= 2; st.h *= 2; st.a *= 2; }, 'তিনটি ঘনমাত্রাই একসাথে দ্বিগুণ: Q = 2⁻² K = K/4 < K — কম গ্যাস মোলের দিকে (ডানে, Δn = −২) সাম্য সরে। K অপরিবর্তিত।'],
      pd: ['চাপ অর্ধেক (আয়তন দ্বিগুণ)', () => { st.n /= 2; st.h /= 2; st.a /= 2; }, 'সব ঘনমাত্রা অর্ধেক: Q = 4K > K — বেশি গ্যাস মোলের দিকে (বামে) সাম্য সরে; NH₃ ভাঙে।'],
      tu: ['তাপমাত্রা +৫০ K', () => { T = Math.min(900, T + 50); }, 'বিক্রিয়া তাপোৎপাদী (ΔH = −৯২ kJ mol⁻¹) — T বাড়লে K কমে, তাই এখন Q > K নতুন: সাম্য বামে (তাপহারী দিকে) সরে, NH₃ কমে। লক্ষ্য করো, কোনো রেখায় লাফ নেই; দুই হারই বাড়ে, পশ্চাৎ হার বেশি।'],
      td: ['তাপমাত্রা −৫০ K', () => { T = Math.max(550, T - 50); }, 'T কমলে K বাড়ে — Q < K: সাম্য ডানে (তাপোৎপাদী দিকে), NH₃ বাড়ে; কিন্তু হার কমে যায় বলে পুনঃসাম্যে বেশি সময় লাগে।'],
      cat: ['প্রভাবক (চালু/বন্ধ)', () => { cat = !cat; }, 'প্রভাবক সম্মুখ ও পশ্চাৎ দুই হারকেই ৩ গুণ করে — সাম্যে থাকলে ঘনমাত্রায় কোনো পরিবর্তন নেই, K অপরিবর্তিত। পরের বিঘ্নে দেখবে পুনঃসাম্য দ্রুত হয়।']
    };
    el.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { const d = D[b.dataset.d]; d[1](); ev.push({ t, no: ev.length ? ev[ev.length - 1].no + 1 : 1, nm: d[0] }); last = b.dataset.d; rec(); info(); A.draw(); });
    const geo = () => { const W = L.W, H = L.H; return { g1: [52, 26, W - 70, (H - 110) * 0.6], g2: [52, 26 + (H - 110) * 0.6 + 56, W - 70, (H - 110) * 0.4] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo();
      const t0 = Math.max(0, t - TW), xt = [0, 10, 20, 30, 40, 50, 60].map(v => Math.floor(t0 / 10) * 10 + v).filter(v => v >= t0 && v <= t0 + TW);
      const ymax = Math.max(3.2, ...hist.map(h => h[2])) * 1.05;
      const [x1, y1, w1, h1] = G.g1, P1 = cplot(g, { x0: x1, y0: y1, w: w1, h: h1, xmin: t0, xmax: t0 + TW, ymax, col, xt, yt: [0, 1, 2, 3, 4, 5, 6].filter(v => v <= ymax), yl: 'ঘনমাত্রা (mol L⁻¹)', ylx: 36 });
      const rmax = Math.max(0.05, ...hist.map(h => Math.max(h[4], h[5]))) * 1.08;
      const [x2, y2, w2, h2] = G.g2, P2 = cplot(g, { x0: x2, y0: y2, w: w2, h: h2, xmin: t0, xmax: t0 + TW, ymax: rmax, col, xt, yt: [0, rmax / 2, rmax], fy: v => fx(v, 2), xl: 'সময় (s)', yl: 'হার', ylx: 36 });
      ev.forEach(e => { [[P1, y1, h1], [P2, y2, h2]].forEach(([PP, yy, hh]) => { g.strokeStyle = col.mu; g.setLineDash([2, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(PP.X(e.t), yy); g.lineTo(PP.X(e.t), yy + hh); g.stroke(); g.setLineDash([]); }); g.fillStyle = col.acc; g.beginPath(); g.arc(P1.X(e.t), y1 + 8, 8, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(e.no), P1.X(e.t), y1 + 11.5); });
      if (hist.length > 1) {
        path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[2])]), '#8a96a3', 2.4); path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[1])]), '#2d6fd6', 2.4); path(g, hist.map(h => [P1.X(h[0]), P1.Y(h[3])]), '#7b3fa0', 2.6);
        path(g, hist.map(h => [P2.X(h[0]), P2.Y(h[4])]), '#2e9d4e', 2.2); path(g, hist.map(h => [P2.X(h[0]), P2.Y(h[5])]), '#e0402e', 2.2, [5, 3]);
      }
      legend(g, [['[H₂]', '#8a96a3'], ['[N₂]', '#2d6fd6'], ['[NH₃]', '#7b3fa0']], x1 + 24, y1 - 12, col);
      legend(g, [['সম্মুখ হার', '#2e9d4e'], ['পশ্চাৎ হার', '#e0402e', true]], x2 + 6, y2 - 10, col);
      g.fillStyle = col.mu; g.font = `10.5px ${col.font}`; g.textAlign = 'right'; g.fillText(`T = ${bn(T)} K${cat ? ' · প্রভাবক চালু' : ''}`, W - 16, G.g2[1] - 7);
    };
    const info = () => {
      const K = Kof(T), Qv = Q(), r = Qv / K, dir = Math.abs(r - 1) < 0.03 ? '\\approx K_c\\ \\Rightarrow\\ \\text{সাম্যাবস্থা}' : r < 1 ? '< K_c\\ \\Rightarrow\\ \\text{সম্মুখ দিকে (ডানে)}' : '> K_c\\ \\Rightarrow\\ \\text{পশ্চাৎ দিকে (বামে)}';
      out.innerHTML = TXB(`\\ce{N2(g) + 3H2(g) <=> 2NH3(g)}`) + TXB(`\\Delta H = -92\\ \\mathrm{kJ\\,mol^{-1}}`) +
        TXB(`Q_c = \\dfrac{[\\ce{NH3}]^2}{[\\ce{N2}][\\ce{H2}]^3} = \\dfrac{(${st.a.toFixed(2)})^2}{(${st.n.toFixed(2)})(${st.h.toFixed(2)})^3}`) + TXB(`Q_c = ${sci(Qv)},\\quad K_c(${T}\\,\\mathrm{K}) = ${sci(K)}`) +
        TXB(`Q_c ${dir}`) +
        (last ? `<div class="small"><b>${bn(ev[ev.length - 1].no)}. ${D[last][0]}:</b> ${D[last][2]}</div>` : '<div class="small">মিশ্রণ সাম্যে পৌঁছানোর অপেক্ষা করো, তারপর একটি বিঘ্ন বেছে নাও।</div>');
    };
    const A = X.anim(el, dt => { if (dt) { step(dt); outT += dt; if (outT > 0.35) { outT = 0; info(); } } draw(); }, { paused: false });
    X.pp(el, A);
    q('[data-rs]').onclick = () => { reset(); info(); A.draw(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৬.১ N₂O₄ ⇌ 2NO₂ সিরিঞ্জ: তাপমাত্রা ও চাপ ======================= */
V.c4_leChatelier = {
  t: 'N₂O₄ ⇌ 2NO₂ সিরিঞ্জ পরীক্ষা: পানিগাহের তাপমাত্রা ও পিস্টনের চাপ', k: ['anim', 'int', '2d', 'calc'],
  cap: 'কাচের সিরিঞ্জে ১০ mmol N₂O₄ সমতুল্য গ্যাস। বাদামি রং কেবল NO₂ এর — রঙের গাঢ়ত্ব [NO₂] এর সমানুপাতিক। পানিগাহ বদলাও: বরফ-পানিতে সাম্য বামে (প্রায় বর্ণহীন), গরম পানিতে সাম্য ডানে (গাঢ় বাদামি) — কারণ সম্মুখ বিক্রিয়া তাপহারী এবং K নিজেই বদলায়। পিস্টন ঠেলে আয়তন কমালে প্রথমে রং হঠাৎ গাঢ় হয় (সব ঘনমাত্রা বাড়ে), তারপর সাম্য কম গ্যাস মোলের দিকে (বামে) সরায় কিছুটা ফিকে হয় — আংশিক প্রশমন। নিচে বামে মোল সংখ্যা, ডানে [NO₂]-সময় লেখচিত্রে লাফ ও পুনঃসমন্বয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('b', [['273', 'বরফ-পানি ০ °C'], ['298', 'কক্ষ তাপমাত্রা ২৫ °C'], ['353', 'গরম পানি ৮০ °C']], '298')}</div>${X.cv('N₂O₄ ও NO₂ সাম্যের সিরিঞ্জ পরীক্ষা')}<div class="grid2" style="margin-top:8px"><label class="small">আয়তন V = <b data-vv></b> mL<input type="range" min="20" max="100" step="5" value="50" data-v></label><div class="ctl" style="margin:0;align-self:end"><button class="btn sm" data-half>দ্রুত চাপ দাও (V/2)</button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), sV = q('[data-v]');
    const hf = w => (wide(w) ? 210 : 190) + 150;
    let L = X.fit(c, hf), Tb = 298, T = 298, Vt = 0.05, Vc = 0.05, al, hist = [], t = 0, acc = 0, mols = [], outT = 0, bub = [];
    const n0 = 0.01, R = X.rng(5), TW = 30;
    const Kc = T_ => 4.6e-3 * Math.exp(-57200 / 8.314 * (1 / T_ - 1 / 298));
    const aeq = (T_, V) => { const kv = Kc(T_) * V; return (-kv + Math.sqrt(kv * kv + 16 * n0 * kv)) / (8 * n0); };
    const reset = () => { Tb = T = 298; Vt = Vc = 0.05; sV.value = 50; al = aeq(T, Vc); hist = []; t = 0; acc = 0; mols = []; syncMols(); el.querySelectorAll('[data-seg="b"] button').forEach(b => b.classList.toggle('on', b.dataset.k === '298')); rec(); };
    const no2 = () => 2 * n0 * al / Vc;
    const rec = () => hist.push([t, no2()]);
    const syncMols = () => {
      const tgtD = Math.round(24 * (1 - al)), tgtN = 48 - 2 * tgtD;
      let d = mols.filter(m => m.k === 'D'), nn = mols.filter(m => m.k === 'N');
      while (d.length > tgtD) { const m = d.pop(); m.k = 'N'; const m2 = { k: 'N', x: m.x + 0.02, y: m.y, vx: -m.vx, vy: -m.vy, a: R() * 6, f: 1 }; m.f = 1; mols.push(m2); d = mols.filter(m => m.k === 'D'); }
      nn = mols.filter(m => m.k === 'N');
      while (d.length < tgtD && nn.length >= 2) { const m1 = nn.pop(), m2 = nn.pop(); mols = mols.filter(m => m !== m2); m1.k = 'D'; m1.f = 1; d = mols.filter(m => m.k === 'D'); nn = mols.filter(m => m.k === 'N'); }
      while (mols.length < tgtD + tgtN && mols.filter(m => m.k === 'D').length + mols.filter(m => m.k === 'N').length / 2 < 24) mols.push({ k: mols.filter(m => m.k === 'D').length < tgtD ? 'D' : 'N', x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, a: R() * 6, f: 0 });
    };
    const step = dt => {
      T += (Tb - T) * (1 - Math.exp(-dt / 1.6));
      Vc += (Vt - Vc) * (1 - Math.exp(-dt / 0.18));
      al += (aeq(T, Vc) - al) * (1 - Math.exp(-dt / 0.9));
      syncMols();
      const sp = 0.25 * Math.sqrt(T / 298);
      mols.forEach(m => { m.x += m.vx * dt * sp; m.y += m.vy * dt * sp * 2; m.a += dt * 2; m.f = Math.max(0, m.f - dt * 2); if (m.x < 0.02 || m.x > 0.98) { m.vx *= -1; m.x = Math.max(0.02, Math.min(0.98, m.x)); } if (m.y < 0.08 || m.y > 0.92) { m.vy *= -1; m.y = Math.max(0.08, Math.min(0.92, m.y)); } });
      if (Tb === 353 && R() < dt * 8) bub.push({ x: R(), y: 1, r: 1.5 + R() * 2 }); bub.forEach(b => { b.y -= dt * 0.5; }); bub = bub.filter(b => b.y > 0.1);
      t += dt; acc += dt; if (acc >= 0.1) { acc = 0; rec(); } while (hist.length && hist[0][0] < t - TW) hist.shift();
    };
    const drawNO2 = (g, x, y, a, s) => { const ca = Math.cos(a), sa = Math.sin(a); ball(g, x - ca * 5 * s + sa * 3 * s, y - sa * 5 * s - ca * 3 * s, 3.3 * s, '#c23b2a', '#ff9a8a'); ball(g, x + ca * 5 * s + sa * 3 * s, y + sa * 5 * s - ca * 3 * s, 3.3 * s, '#c23b2a', '#ff9a8a'); ball(g, x, y, 4 * s, '#2d5fb3', '#9cc0ff'); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const sh = wide(W) ? 210 : 190, sx = 30, sw = W - 90, sy = 40, sht = 70;
      // water bath trough
      const wc = Tb === 273 ? 'rgba(150,200,240,.55)' : Tb === 353 ? 'rgba(235,120,100,.22)' : 'rgba(160,200,230,.35)';
      g.fillStyle = wc; g.fillRect(sx - 14, sy + 18, sw + 28, sh - sy - 18 - 12); g.strokeStyle = col.fg; g.lineWidth = 1.5; g.beginPath(); g.moveTo(sx - 14, sy + 4); g.lineTo(sx - 14, sh - 12); g.lineTo(sx + sw + 14, sh - 12); g.lineTo(sx + sw + 14, sy + 4); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 1; g.beginPath(); for (let xx = sx - 14; xx < sx + sw + 14; xx += 4) g.lineTo(xx, sy + 18 + Math.sin(xx * 0.15 + t * 3) * 1.5); g.stroke();
      if (Tb === 273) { for (let k = 0; k < 7; k++) { const ix = sx + k * sw / 7 + 6, iy = sy + 22 + (k % 2) * 6; g.fillStyle = 'rgba(235,248,255,.9)'; g.strokeStyle = 'rgba(120,170,210,.9)'; g.save(); g.translate(ix, iy); g.rotate(0.3 * (k % 3 - 1)); g.fillRect(-7, -6, 14, 12); g.strokeRect(-7, -6, 14, 12); g.restore(); } }
      bub.forEach(b => { g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 1; g.beginPath(); g.arc(sx + b.x * sw, sy + 18 + b.y * (sh - sy - 34), b.r, 0, 7); g.stroke(); });
      // syringe barrel
      const bx = sx + 10, bw = sw - 70, by = sy + 40, bh = sht * 0.75;
      const gx = bx + bw * (1 - Vc / 0.1), gl = bx + bw - gx; // gas from piston (gx) to nozzle end
      const conc = no2(), alpha = 1 - Math.exp(-conc * 18);
      g.fillStyle = `rgba(140,62,20,${alpha.toFixed(3)})`; g.fillRect(gx, by, gl, bh);
      const sc = Math.max(0.7, Math.min(1.1, W / 600));
      mols.forEach(m => { const x = gx + 6 + m.x * (gl - 12), y = by + 4 + m.y * (bh - 8); if (m.k === 'N') drawNO2(g, x, y, m.a, sc * 0.85); else { const ca = Math.cos(m.a) * 6 * sc; drawNO2(g, x - ca, y, m.a + 1.6, sc * 0.75); drawNO2(g, x + ca, y, m.a - 1.6, sc * 0.75); } if (m.f > 0) ring(g, x, y, 10 + (1 - m.f) * 6, m.k === 'N' ? '#2e9d4e' : '#e0802e', m.f); });
      const gr = g.createLinearGradient(0, by, 0, by + bh); gr.addColorStop(0, 'rgba(255,255,255,.35)'); gr.addColorStop(0.25, 'rgba(255,255,255,.05)'); gr.addColorStop(1, 'rgba(255,255,255,.12)'); g.fillStyle = gr; g.fillRect(bx, by, bw, bh);
      g.strokeStyle = col.fg; g.lineWidth = 1.6; g.strokeRect(bx, by, bw, bh);
      for (let k = 1; k < 10; k++) { const tx = bx + bw * k / 10; g.beginPath(); g.moveTo(tx, by); g.lineTo(tx, by + (k % 2 ? 5 : 9)); g.stroke(); if (k % 2 === 0) { g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(100 - k * 10), tx, by - 3); } }
      // nozzle + cap
      g.fillStyle = col.s3; g.fillRect(bx + bw, by + bh * 0.35, 18, bh * 0.3); g.strokeRect(bx + bw, by + bh * 0.35, 18, bh * 0.3); g.fillStyle = '#b33'; g.fillRect(bx + bw + 18, by + bh * 0.28, 8, bh * 0.44);
      // piston
      g.fillStyle = '#3a3a3a'; g.fillRect(gx - 8, by + 1, 8, bh - 2); g.fillStyle = col.s3; g.fillRect(bx - 40, by + bh * 0.42, gx - 8 - (bx - 40), bh * 0.16); g.strokeRect(bx - 40, by + bh * 0.42, gx - 8 - (bx - 40), bh * 0.16); g.fillStyle = col.s3; g.fillRect(bx - 46, by - 6, 8, bh + 12); g.strokeRect(bx - 46, by - 6, 8, bh + 12);
      // thermometer
      const tx = sx + sw + 34, ty0 = sy - 4, tl = sh - sy - 20; g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.roundRect ? g.roundRect(tx - 4, ty0, 8, tl, 4) : g.rect(tx - 4, ty0, 8, tl); g.fill(); g.stroke();
      const fr = (T - 260) / 110; g.fillStyle = '#d33'; g.fillRect(tx - 2, ty0 + tl - fr * (tl - 8), 4, fr * (tl - 8)); g.beginPath(); g.arc(tx, ty0 + tl + 4, 6, 0, 7); g.fill(); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText(`${bn(Math.round(T - 273))} °C`, tx, ty0 - 6);
      g.textAlign = 'left'; g.font = `bold 11px ${col.font}`; g.fillText(`রঙের তীব্রতা ∝ [NO₂] = ${fx(conc * 1000, 1)} × ১০⁻³ mol L⁻¹`, sx - 10, 16);
      // bars
      const gy = sh + 14, gh = H - gy - 34, bwid = wide(W) ? 170 : 96;
      const nD = n0 * (1 - al) * 1000, nN = 2 * n0 * al * 1000;
      cplot(g, { x0: 44, y0: gy, w: bwid, h: gh, xmax: 2, ymax: 20, col, yt: [0, 10, 20], yl: 'মোল (mmol)', ylx: 32 });
      [[nD, '#9aa3ad', 'N₂O₄'], [nN, '#8c3e14', 'NO₂']].forEach(([v, cc, nm], i) => { const x = 44 + bwid * (0.15 + i * 0.5), w = bwid * 0.3, y = gy + gh - v / 20 * gh; g.fillStyle = cc; g.fillRect(x, y, w, gy + gh - y); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(fx(v, 1), x + w / 2, y - 3); g.fillText(nm, x + w / 2, gy + gh + 13); });
      const x3 = 44 + bwid + (wide(W) ? 56 : 48), w3 = W - x3 - 16, t0 = Math.max(0, t - TW);
      const ym = Math.max(0.05, ...hist.map(h => h[1])) * 1.1;
      const P3 = cplot(g, { x0: x3, y0: gy, w: w3, h: gh, xmin: t0, xmax: t0 + TW, ymax: ym * 1000, col, xt: [0, 10, 20, 30].map(v => Math.floor(t0 / 10) * 10 + v).filter(v => v >= t0 && v <= t0 + TW), yt: [0, Math.round(ym * 500), Math.round(ym * 1000)], xl: 'সময় (s)', yl: '[NO₂] (×১০⁻³ M)', ylx: 36 });
      if (hist.length > 1) path(g, hist.map(h => [P3.X(h[0]), P3.Y(h[1] * 1000)]), '#8c3e14', 2.4);
    };
    const info = () => {
      const K = Kc(T), cD = n0 * (1 - al) / Vc, cN = no2(), Qv = cN * cN / cD, r = Qv / K;
      q('[data-vv]').textContent = bn(Math.round(Vt * 1000));
      out.innerHTML = TXB(`\\ce{\\underset{\\text{বর্ণহীন}}{N2O4(g)} <=> \\underset{\\text{বাদামি}}{2NO2(g)}}`) + TXB(`\\Delta H = +57.2\\ \\mathrm{kJ\\,mol^{-1}},\\quad K_c(${Math.round(T)}\\,\\mathrm{K}) = ${sci(K)}`) +
        TXB(`Q_c = \\dfrac{[\\ce{NO2}]^2}{[\\ce{N2O4}]} = \\dfrac{(${sci(cN)})^2}{${sci(cD)}} = ${sci(Qv)}`) +
        TXB(`\\alpha = ${(al * 100).toFixed(1)}\\%\\qquad ${Math.abs(r - 1) < 0.03 ? 'Q_c \\approx K_c\\ \\text{(সাম্য)}' : r > 1 ? 'Q_c > K_c\\ \\Rightarrow\\ \\text{বামে সরছে}' : 'Q_c < K_c\\ \\Rightarrow\\ \\text{ডানে সরছে}'}`) +
        `<div class="small">${Math.abs(T - Tb) > 2 ? (Tb > T ? 'উত্তপ্ত হচ্ছে — K বাড়ছে, সাম্য তাপহারী (ডান) দিকে সরছে।' : 'ঠান্ডা হচ্ছে — K কমছে, সাম্য তাপোৎপাদী (বাম) দিকে সরছে।') : r > 1.03 ? 'সংকোচনের পর Q > K: NO₂ জোড়ায় মিলে N₂O₄ হচ্ছে — রং কিছুটা ফিকে হচ্ছে।' : r < 0.97 ? 'প্রসারণের পর Q < K: N₂O₄ ভেঙে NO₂ হচ্ছে।' : 'সাম্যাবস্থা। পানিগাহ বদলাও বা পিস্টন সরাও।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { step(dt); outT += dt; if (outT > 0.3) { outT = 0; info(); } } draw(); }, { paused: false });
    X.onSeg(el, 'b', v => { Tb = +v; info(); });
    sV.oninput = () => { Vt = +sV.value / 1000; info(); };
    q('[data-half]').onclick = () => { Vt = Math.max(0.02, Vt / 2); sV.value = Math.round(Vt * 1000); info(); };
    q('[data-rs]').onclick = () => { reset(); info(); A.draw(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৬.৩ Fe³⁺ + SCN⁻ ⇌ [Fe(SCN)]²⁺ টেস্টটিউব পরীক্ষা ======================= */
V.c4_feSCN = {
  t: 'ঘনমাত্রার প্রভাব: Fe³⁺ + SCN⁻ ⇌ [Fe(SCN)]²⁺ পাঁচ টেস্টটিউবের ভার্চুয়াল পরীক্ষা', k: ['anim', 'int', '2d', 'calc'],
  cap: 'প্রতিটি টিউবে ৫.০ mL দ্রবণ: [Fe³⁺]মোট = [SCN⁻]মোট = ১.০ × ১০⁻³ M, সাম্যে হালকা লাল। একটি টিউব বেছে বিকারক যোগ করো: FeCl₃ বা KSCN দিলে রক্তলাল গাঢ় হয় (সাম্য ডানে); NaF দিলে F⁻ বর্ণহীন [FeF₆]³⁻ গঠন করে Fe³⁺ সরিয়ে নেয় — রং ফিকে; AgNO₃ দিলে সাদা AgSCN অধঃক্ষেপ পড়ে, SCN⁻ সরে — রং ফিকে; পানি দিলে লঘুকরণের চেয়েও বেশি ফিকে হয়, কারণ সাম্য বেশি কণার দিকে (বামে) সরে। নিচে নির্বাচিত টিউবের আয়নগুলোর সাম্য ঘনমাত্রা এবং যোগের ঠিক পরের Q বনাম K।',
  html: () => `<div class="ctl" style="margin:0 0 6px">টিউব: ${X.seg('tb', [['0', '১'], ['1', '২'], ['2', '৩'], ['3', '৪'], ['4', '৫']], '1')}</div>${X.cv('আয়রন থায়োসায়ানেট সাম্যের টেস্টটিউব পরীক্ষা')}<div class="ctl" style="flex-wrap:wrap;gap:6px;margin-top:8px"><button class="btn sm" data-r="fe">FeCl₃ (৩ ফোঁটা)</button><button class="btn sm" data-r="scn">KSCN (৩ ফোঁটা)</button><button class="btn sm" data-r="f">NaF (এক চিমটি)</button><button class="btn sm" data-r="ag">AgNO₃ (৩ ফোঁটা)</button><button class="btn sm" data-r="w">পানি (১ mL)</button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 440 : 450;
    let L = X.fit(c, hf), sel = 1, tubes, drop = null, lastQ = null, lastMsg = '', outT = 0;
    const KF = 890, R = X.rng(9);
    const RG = { fe: ['FeCl₃', 0.15, { fe: 0.1 }, '#d8b84a'], scn: ['KSCN', 0.15, { scn: 0.1 }, '#e8eef2'], f: ['NaF', 0, { f: 0.06e-3 }, '#f4f4f4'], ag: ['AgNO₃', 0.15, { ag: 0.02 }, '#e8eef2'], w: ['পানি', 1.0, {}, '#cfe6f7'] };
    const solve = tb => {
      const V = tb.V / 1000, fe = tb.fe / V, scn = tb.scn / V, fcap = tb.f / V / 6, ag = tb.ag / V;
      const feA = Math.max(0, fe - fcap), scnA = Math.max(0, scn - ag), ppt = Math.min(scn, ag) * V;
      // x/((feA-x)(scnA-x)) = KF
      const a = KF, b = -(KF * (feA + scnA) + 1), cc = KF * feA * scnA, x = a ? (-b - Math.sqrt(Math.max(0, b * b - 4 * a * cc))) / (2 * a) : 0;
      return { fe: feA - x, scn: scnA - x, x, ppt, V };
    };
    const tubeInit = () => ({ V: 5, fe: 5e-6, scn: 5e-6, f: 0, ag: 0 });
    const reset = () => { tubes = [0, 1, 2, 3, 4].map(() => { const tb = tubeInit(); tb.eq = solve(tb); tb.show = tb.eq.x; tb.ppt = 0; tb.mix = 1; tb.log = []; return tb; }); drop = null; lastQ = null; lastMsg = ''; };
    const colorOf = (x, fe) => { const tr = 1 - Math.exp(-x * 2600), ty = 1 - Math.exp(-fe * 260); const base = [248, 248, 244], red = [150, 12, 14], yel = [232, 196, 70]; const m = base.map((v, i) => v + (yel[i] - v) * ty * 0.55); return m.map((v, i) => Math.round(v + (red[i] - v) * tr)); };
    const add = k => {
      const tb = tubes[sel], rg = RG[k]; if (tb.V + rg[1] > 9.2) { lastMsg = 'টিউব প্রায় ভর্তি — আর যোগ করা যাবে না।'; info(); return; }
      const before = tb.eq; tb.V += rg[1]; const mol = rg[2];
      if (mol.fe) tb.fe += mol.fe * rg[1] / 1000; if (mol.scn) tb.scn += mol.scn * rg[1] / 1000; if (mol.ag) tb.ag += mol.ag * rg[1] / 1000; if (mol.f) tb.f += mol.f * 5;
      // Q right after mixing (complex amount unchanged in moles, before re-equilibration)
      const V = tb.V / 1000, nx = before.x * before.V, feA = Math.max(0, tb.fe / V - tb.f / V / 6) - nx / V, scnA = Math.max(0, tb.scn / V - tb.ag / V) - nx / V;
      const Qv = feA > 1e-9 && scnA > 1e-9 ? (nx / V) / (feA * scnA) : Infinity;
      tb.eq = solve(tb); tb.from = tb.show; tb.mix = 0; tb.log.push(rg[0]);
      lastQ = Qv; lastMsg = { fe: 'Fe³⁺ বাড়ল → Q < K → সাম্য ডানে → রক্তলাল গাঢ়।', scn: 'SCN⁻ বাড়ল → Q < K → সাম্য ডানে → রক্তলাল গাঢ়।', f: 'F⁻ Fe³⁺ কে বর্ণহীন [FeF₆]³⁻ রূপে বেঁধে ফেলে → মুক্ত Fe³⁺ কমে → Q > K → সাম্য বামে → রং ফিকে।', ag: 'Ag⁺ + SCN⁻ → AgSCN↓ (সাদা) → SCN⁻ কমে → Q > K → সাম্য বামে → রং ফিকে।', w: 'লঘুকরণে সব ঘনমাত্রা কমে; Q = x/(ab) এ হর বেশি কমে → Q > K → সাম্য বামে (বেশি আয়নের দিকে) — রং কেবল লঘুকরণের চেয়েও বেশি ফিকে।' }[k];
      drop = { k, y: 0, col: rg[3], solid: k === 'f' };
      info();
    };
    const geo = () => { const W = L.W, H = L.H, n = 5, tw = Math.min(46, (W - 40) / n * 0.5), gap = (W - 40) / n; return { tw, gap, top: 70, th: 170, gy: 318, H }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo();
      // rack
      g.fillStyle = '#9b7653'; g.fillRect(14, G.top + G.th - 60, W - 28, 10); g.fillRect(14, G.top + G.th + 4, W - 28, 8); g.fillStyle = '#7a5a3c'; g.fillRect(20, G.top + G.th - 50, 6, 62); g.fillRect(W - 26, G.top + G.th - 50, 6, 62);
      tubes.forEach((tb, i) => {
        const cx = 20 + G.gap * (i + 0.5), x = cx - G.tw / 2, y = G.top, w = G.tw, h = G.th;
        const fill = tb.V / 10, ly = y + h - fill * (h - 10);
        const show = tb.mix < 1 ? tb.from + (tb.eq.x - tb.from) * C4.ease(tb.mix) : tb.eq.x;
        const [r, gg, b] = colorOf(show, tb.eq.fe);
        g.save(); g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + h - w / 2); g.arc(cx, y + h - w / 2, w / 2, Math.PI, 0, true); g.lineTo(x + w, y); g.closePath(); g.clip();
        g.fillStyle = `rgb(${r},${gg},${b})`; g.fillRect(x, ly, w, h);
        if (tb.mix < 1) { const [r2, g2, b2] = colorOf(tb.eq.x, tb.eq.fe); const pl = g.createRadialGradient(cx, ly + 6, 2, cx, ly + 6, (h - (ly - y)) * C4.ease(tb.mix) + 6); pl.addColorStop(0, `rgba(${r2},${g2},${b2},.95)`); pl.addColorStop(1, `rgba(${r2},${g2},${b2},0)`); g.fillStyle = pl; g.fillRect(x, ly, w, h); }
        if (tb.eq.ppt > 0) { const np = Math.min(60, Math.round(tb.eq.ppt * 9e6)); const R2 = X.rng(100 + i); for (let k = 0; k < np; k++) { const px = x + 4 + R2() * (w - 8), settle = Math.min(1, tb.mix * 1.2 + (tb.mix >= 1 ? 1 : 0)), py = lerpN(ly + 10 + R2() * (h - (ly - y) - 14), y + h - 4 - R2() * 10, settle); g.fillStyle = '#ffffff'; g.strokeStyle = 'rgba(90,90,90,.7)'; g.lineWidth = 0.6; g.fillRect(px, py, 2.6, 2.6); g.strokeRect(px, py, 2.6, 2.6); } }
        g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(x + 4, y + 6, 3, h - 18); g.restore();
        g.strokeStyle = col.fg; g.lineWidth = i === sel ? 2.4 : 1.4; g.beginPath(); g.moveTo(x, y - 4); g.lineTo(x, y + h - w / 2); g.arc(cx, y + h - w / 2, w / 2, Math.PI, 0, true); g.lineTo(x + w, y - 4); g.stroke();
        g.beginPath(); g.ellipse(cx, y - 4, w / 2 + 2, 3, 0, 0, 7); g.stroke();
        g.fillStyle = i === sel ? col.acc : col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(i + 1) + (i === 0 ? ' (তুলনা)' : ''), cx, y + h + 26);
        g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.fillText(tb.log.length ? tb.log.slice(-2).join(', ') : '—', cx, y + h + 38);
      });
      // dropper
      const cx = 20 + G.gap * (sel + 0.5);
      g.fillStyle = '#444'; g.beginPath(); g.ellipse(cx, 10, 8, 9, 0, 0, 7); g.fill(); g.fillStyle = 'rgba(220,235,245,.7)'; g.strokeStyle = col.fg; g.lineWidth = 1; g.fillRect(cx - 4, 18, 8, 26); g.strokeRect(cx - 4, 18, 8, 26); g.beginPath(); g.moveTo(cx - 4, 44); g.lineTo(cx - 1, 54); g.lineTo(cx + 1, 54); g.lineTo(cx + 4, 44); g.stroke();
      if (drop) { const yy = 56 + drop.y * (G.top + G.th - (tubes[sel].V / 10) * (G.th - 10) - 56); if (drop.solid) { g.fillStyle = '#f6f6f6'; g.strokeStyle = '#999'; for (let k = 0; k < 6; k++) { g.fillRect(cx - 6 + k * 2.2, yy + (k % 3) * 3, 3, 3); g.strokeRect(cx - 6 + k * 2.2, yy + (k % 3) * 3, 3, 3); } } else { g.fillStyle = drop.col; g.strokeStyle = col.fg; g.beginPath(); g.moveTo(cx, yy - 5); g.quadraticCurveTo(cx + 4, yy + 1, cx, yy + 4); g.quadraticCurveTo(cx - 4, yy + 1, cx, yy - 5); g.fill(); g.stroke(); } }
      // bars for selected tube
      const e = tubes[sel].eq, by0 = G.gy, bh = H - by0 - 30, bw = Math.min(330, W - 80);
      const ymax = Math.max(1.2, e.fe * 1e3, e.scn * 1e3, e.x * 1e3) * 1.15;
      cplot(g, { x0: 52, y0: by0, w: bw, h: bh, xmax: 3, ymax, col, yt: [0, +(ymax / 2).toFixed(1), +ymax.toFixed(1)], fy: v => fx(v, 1), yl: '×১০⁻³ M', ylx: 38 });
      [[e.fe * 1e3, '#d8a830', 'Fe³⁺'], [e.scn * 1e3, '#9aa3ad', 'SCN⁻'], [e.x * 1e3, '#a3121a', '[Fe(SCN)]²⁺']].forEach(([v, cc, nm], i) => { const x = 52 + bw * (0.08 + i / 3), w = bw / 3 * 0.6, y = by0 + bh - v / ymax * bh; g.fillStyle = cc; g.fillRect(x, y, w, by0 + bh - y); g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(fx(v, 2), x + w / 2, y - 3); g.fillText(nm, x + w / 2, by0 + bh + 13); });
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`টিউব ${bn(sel + 1)}: সাম্য ঘনমাত্রা (V = ${fx(tubes[sel].V, 2)} mL)`, 52 + bw + 14 > W - 120 ? 52 : 52 + bw + 14, by0 + (52 + bw + 14 > W - 120 ? -8 : 10));
    };
    const lerpN = (a, b, t) => a + (b - a) * t;
    const info = () => {
      const e = tubes[sel].eq, Qe = e.x / Math.max(1e-12, e.fe * e.scn);
      out.innerHTML = TXB(`\\ce{\\underset{\\text{হালকা হলুদ}}{Fe^3+(aq)} + \\underset{\\text{বর্ণহীন}}{SCN-(aq)} <=> \\underset{\\text{রক্তলাল}}{[Fe(SCN)]^2+(aq)}}`) + TXB(`K_c = \\dfrac{[\\ce{[Fe(SCN)]^2+}]}{[\\ce{Fe^3+}][\\ce{SCN-}]} \\approx 8.9\\times10^{2}`) +
        TXB(`[\\ce{Fe^3+}] = ${sci(e.fe)},\\ [\\ce{SCN-}] = ${sci(e.scn)}`) + TXB(`[\\ce{[Fe(SCN)]^2+}] = ${sci(e.x)}\\ \\mathrm{mol\\,L^{-1}}`) +
        (lastQ !== null ? TXB(`Q_{\\text{যোগের পর}} = ${isFinite(lastQ) ? sci(lastQ) : '\\infty'}\\ ${lastQ < KF * 0.97 ? '< K_c\\ \\Rightarrow\\ \\text{ডানে}' : lastQ > KF * 1.03 ? '> K_c\\ \\Rightarrow\\ \\text{বামে}' : '\\approx K_c'}`) + TXB(`Q_{\\text{এখন}} = ${sci(Qe)} \\approx K_c`) : '') +
        `<div class="small">${lastMsg || 'একটি টিউব বেছে বিকারক যোগ করো। টিউব ১ তুলনার জন্য অপরিবর্তিত রাখা ভালো।'}</div>`;
    };
    const A = X.anim(el, dt => {
      if (dt) { if (drop) { drop.y += dt * 2.2; if (drop.y >= 1) drop = null; } tubes.forEach(tb => { if (tb.mix < 1 && !drop) tb.mix = Math.min(1, tb.mix + dt * 0.7); }); }
      draw();
    }, { paused: false });
    el.querySelectorAll('[data-r]').forEach(b => b.onclick = () => { if (drop) return; add(b.dataset.r); });
    X.onSeg(el, 'tb', v => { sel = +v; lastQ = null; lastMsg = ''; info(); A.draw(); });
    q('[data-rs]').onclick = () => { reset(); info(); A.draw(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
/* ======================= ৪.৫.২ সাম্যের শর্ত: বদ্ধ বনাম খোলা পাত্র ও মুক্ত শক্তি বক্ররেখা ======================= */
V.c4_eqConditions = {
  t: 'সাম্যাবস্থার শর্ত: বদ্ধ বনাম খোলা পাত্রে CaCO₃ এর বিয়োজন এবং মুক্ত শক্তি (G) বনাম বিক্রিয়ার অগ্রগতি', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে চুল্লিতে ৮০০ °C এ CaCO₃ উত্তপ্ত হচ্ছে। "বদ্ধ পাত্র" অবস্থায় CO₂ জমতে থাকে, চাপমাপক যন্ত্রে p(CO₂) বেড়ে একটি নির্দিষ্ট মানে (K_p) স্থির হয় — বাকি CaCO₃ আর ভাঙে না: সাম্যাবস্থা। "খোলা পাত্র" এ CO₂ বেরিয়ে যায়, p(CO₂) কখনো K_p তে পৌঁছায় না — সব CaCO₃ ভেঙে যায়, সাম্য হয় না। ডানে মুক্ত শক্তি বনাম অগ্রগতি (ξ) বক্ররেখা: বিন্দুটি সবসময় ঢাল বেয়ে নিচে নামে; সর্বনিম্ন বিন্দুতে ঢাল ΔG = 0 এবং Q = K — যেকোনো দিক থেকে শুরু করলে সেখানেই থামে। স্লাইডারে শুরু করার বিন্দু বদলাও।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('v', [['c', 'বদ্ধ পাত্র'], ['o', 'খোলা পাত্র']], 'c')}</div>${X.cv('বদ্ধ ও খোলা পাত্রে সাম্য এবং মুক্ত শক্তি বক্ররেখা')}<div class="grid2" style="margin-top:8px"><label class="small">G-বক্ররেখায় শুরুর বিন্দু ξ₀ = <b data-xv></b><input type="range" min="0" max="1" step="0.05" value="0.05" data-x></label><div class="ctl" style="margin:0;align-self:end"><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 300 : 560;
    let L = X.fit(c, hf), open = false, p = 0, dec = 0, xi = 0.05, xi0 = 0.05, t = 0, gas = [], outT = 0;
    const KP = 0.22, R = X.rng(3), GK = 0.62; // G-curve equilibrium extent
    const Gf = x => { const e = Math.min(0.999, Math.max(0.001, x)); return 1.0 * (1 - e) + 0.7 * e + 0.5 * (e * Math.log(e) + (1 - e) * Math.log(1 - e)); };
    const dG = x => (Gf(x + 0.002) - Gf(x - 0.002)) / 0.004;
    const xeq = (() => { let a = 0.01, b = 0.99; for (let i = 0; i < 50; i++) { const m = (a + b) / 2; if (dG(m) < 0) a = m; else b = m; } return (a + b) / 2; })();
    const reset = () => { p = 0; dec = 0; t = 0; gas = []; xi = xi0; };
    const step = dt => {
      t += dt;
      const rate = 0.06 * (1 - dec > 0.001 ? 1 : 0) * Math.max(0, 1 - p / KP);
      if (!open) { dec = Math.min(1, dec + rate * dt * 0.8); p = Math.min(KP, p + rate * dt * 0.8 * 3.2); }
      else { dec = Math.min(1, dec + 0.05 * dt * (dec < 1 ? 1 : 0)); p = 0.02 * (dec < 1 ? 1 : 0); }
      if (R() < dt * (open ? (dec < 1 ? 6 : 0) : 2 + p * 30)) gas.push({ x: R(), y: 0.85, vx: (R() - 0.5) * 0.3, vy: -0.25 - R() * 0.2, life: 1 });
      gas.forEach(gm => { gm.x += gm.vx * dt; gm.y += gm.vy * dt; if (!open) { if (gm.y < 0.05) { gm.vy = Math.abs(gm.vy); } if (gm.y > 0.75) gm.vy = -Math.abs(gm.vy); if (gm.x < 0.03 || gm.x > 0.97) gm.vx *= -1; } else if (gm.y < -0.4) gm.life = 0; });
      const maxG = open ? 30 : Math.round(6 + p / KP * 34); gas = gas.filter(gm => gm.life > 0); while (gas.length > maxG) gas.shift();
      xi += -dG(xi) * dt * 0.1; xi = Math.max(0.001, Math.min(0.999, xi));
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const pw = wide(W) ? W * 0.46 : W - 20, ph = wide(W) ? H - 20 : 270;
      const vx0 = 20, vy0 = 34, vw = Math.min(170, pw - 140), vh = ph - 90;
      // furnace
      g.fillStyle = '#5a4636'; g.fillRect(vx0 - 10, vy0 + vh - 10, vw + 20, 36); g.fillStyle = '#e8702a'; for (let k = 0; k < 6; k++) { const fxp = vx0 + 8 + k * (vw - 16) / 5, fl = 8 + Math.sin(t * 9 + k) * 3; g.beginPath(); g.moveTo(fxp - 5, vy0 + vh + 14); g.quadraticCurveTo(fxp, vy0 + vh + 14 - fl * 2, fxp + 5, vy0 + vh + 14); g.fill(); }
      glassBox(g, vx0, vy0, vw, vh - 10, col);
      if (!open) { g.fillStyle = col.s3; g.fillRect(vx0 - 4, vy0 - 8, vw + 8, 8); g.strokeStyle = col.fg; g.strokeRect(vx0 - 4, vy0 - 8, vw + 8, 8); } else { g.clearRect(vx0 + vw * 0.3, vy0 - 2, vw * 0.4, 4); }
      // solid heap: CaCO3 white, CaO light grey
      const heapH = 30, hx = vx0 + 10, hw = vw - 20, hy = vy0 + vh - 12;
      g.fillStyle = '#f2f0ea'; g.beginPath(); g.moveTo(hx, hy); g.quadraticCurveTo(hx + hw / 2, hy - heapH * 2 * (1 - dec * 0.4), hx + hw, hy); g.fill(); g.strokeStyle = '#a49e90'; g.stroke();
      g.save(); g.beginPath(); g.moveTo(hx, hy); g.quadraticCurveTo(hx + hw / 2, hy - heapH * 2 * (1 - dec * 0.4), hx + hw, hy); g.clip(); g.fillStyle = '#c9cdd3'; g.fillRect(hx, hy - heapH * dec * 1.1, hw, heapH * 2); g.restore();
      g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(`CaCO₃ ${bn(Math.round((1 - dec) * 100))}% · CaO ${bn(Math.round(dec * 100))}%`, vx0 + vw / 2, vy0 + vh + 40);
      gas.forEach(gm => { const x = vx0 + 6 + gm.x * (vw - 12), y = vy0 + gm.y * (vh - 40); ball(g, x - 4, y, 3, '#c23b2a', '#ff9a8a'); ball(g, x, y, 3.6, '#333', '#999'); ball(g, x + 4, y, 3, '#c23b2a', '#ff9a8a'); });
      // gauge
      const gx = vx0 + vw + 48, gy = vy0 + 40, gr = 30; g.fillStyle = col.sf; g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.arc(gx, gy, gr, 0, 7); g.fill(); g.stroke();
      for (let k = 0; k <= 5; k++) { const a = Math.PI * (0.75 + k * 0.3); g.beginPath(); g.moveTo(gx + Math.cos(a) * (gr - 3), gy + Math.sin(a) * (gr - 3)); g.lineTo(gx + Math.cos(a) * (gr - 8), gy + Math.sin(a) * (gr - 8)); g.stroke(); }
      const aK = Math.PI * (0.75 + 1.5 * KP / 0.3); g.strokeStyle = '#e0402e'; g.lineWidth = 2; g.beginPath(); g.moveTo(gx + Math.cos(aK) * (gr - 2), gy + Math.sin(aK) * (gr - 2)); g.lineTo(gx + Math.cos(aK) * (gr - 10), gy + Math.sin(aK) * (gr - 10)); g.stroke();
      const an = Math.PI * (0.75 + 1.5 * p / 0.3); g.strokeStyle = col.fg; g.lineWidth = 2; g.beginPath(); g.moveTo(gx, gy); g.lineTo(gx + Math.cos(an) * (gr - 6), gy + Math.sin(an) * (gr - 6)); g.stroke(); g.fillStyle = col.fg; g.beginPath(); g.arc(gx, gy, 3, 0, 7); g.fill();
      g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(vx0 + vw, gy); g.lineTo(gx - gr, gy); g.stroke();
      g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(`p(CO₂) = ${fx(p, 3)} atm`, gx, gy + gr + 14); g.fillStyle = '#e0402e'; g.fillText(`K_p = ${fx(KP, 2)}`, gx, gy + gr + 28);
      g.fillStyle = open ? col.bad : col.ok; g.font = `bold 11px ${col.font}`; g.fillText(open ? (dec >= 1 ? 'সম্পূর্ণ বিয়োজিত — সাম্য নেই' : 'CO₂ বেরিয়ে যাচ্ছে') : (p >= KP * 0.995 ? 'সাম্যাবস্থা: p(CO₂) = K_p' : 'CO₂ জমছে…'), vx0 + vw / 2, 18);
      // G curve
      const cx0 = wide(W) ? pw + 60 : 56, cy0 = wide(W) ? 30 : ph + 40, cw = wide(W) ? W - pw - 80 : W - 76, ch = wide(W) ? H - 80 : H - ph - 90;
      const P = cplot(g, { x0: cx0, y0: cy0, w: cw, h: ch, xmax: 1, ymin: 0, ymax: 1.5, col, xt: [0, 0.5, 1], fx: v => v === 0 ? 'শুধু বিক্রিয়ক' : v === 1 ? 'শুধু উৎপাদ' : '', xl: 'বিক্রিয়ার অগ্রগতি ξ', yl: 'মুক্ত শক্তি G', ylx: 18 });
      const pts = []; for (let k = 0; k <= 120; k++) { const x = k / 120; pts.push([P.X(x), P.Y(Gf(x) + 0.35)]); } path(g, pts, col.acc, 2.6);
      g.setLineDash([3, 3]); g.strokeStyle = col.mu; g.lineWidth = 1; g.beginPath(); g.moveTo(P.X(xeq), P.Y(Gf(xeq) + 0.35)); g.lineTo(P.X(xeq), cy0 + ch); g.stroke(); g.setLineDash([]);
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText('সাম্য: ΔG = 0, Q = K', P.X(xeq), P.Y(Gf(xeq) + 0.35) + 18);
      const sl = dG(xi), xp = P.X(xi), yp = P.Y(Gf(xi) + 0.35), dx = 30, k = (P.Y(Gf(xi + 0.01) + 0.35) - yp) / (P.X(xi + 0.01) - xp);
      g.strokeStyle = '#e0402e'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(xp - dx, yp - k * dx); g.lineTo(xp + dx, yp + k * dx); g.stroke();
      ball(g, xp, yp - 6, 6, '#c0392b', '#ffb3a8');
      g.fillStyle = col.fg; g.font = `10.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`ঢাল ΔG ${Math.abs(sl) < 0.03 ? '≈ 0' : sl < 0 ? '< 0 → সম্মুখ স্বতঃস্ফূর্ত' : '> 0 → পশ্চাৎ স্বতঃস্ফূর্ত'}`, cx0 + 16, cy0 + 12);
    };
    const info = () => {
      q('[data-xv]').textContent = fx(xi0, 2);
      out.innerHTML = TXB(`\\ce{CaCO3(s) <=>[\\Delta] CaO(s) + CO2(g)}`) + TXB(`K_p = p_{\\ce{CO2}} = ${KP.toFixed(2)}\\ \\mathrm{atm}\\ (800\\,^\\circ\\mathrm{C})`) +
        TXB(`\\Delta G = \\Delta G^\\circ + RT\\ln Q`) + TXB(`\\text{সাম্যে } \\Delta G = 0 \\Rightarrow Q = K`) +
        `<div class="small">${open ? 'খোলা পাত্রে বিক্রিয়ক/উৎপাদ বেরিয়ে যায় — শর্ত "বদ্ধ ব্যবস্থা" পূরণ হয় না, বিক্রিয়া একমুখী হয়ে সম্পূর্ণ হয়। চুনভাটায় ঠিক এটাই চাওয়া হয়।' : 'বদ্ধ পাত্রে নির্দিষ্ট তাপমাত্রায় p(CO₂) স্থির মান K_p তে পৌঁছায়; CaCO₃ এর পরিমাণ যত বেশিই হোক, এই চাপ একই।'} ডানের বক্ররেখায় যেকোনো ξ₀ থেকে শুরু করলেও বিন্দু G এর সর্বনিম্ন বিন্দুতে (ξ ≈ ${fx(xeq, 2)}) পৌঁছে থামে।</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { step(dt); outT += dt; if (outT > 0.4) { outT = 0; info(); } } draw(); }, { paused: false });
    X.onSeg(el, 'v', v => { open = v === 'o'; reset(); info(); });
    q('[data-x]').oninput = e => { xi0 = +e.target.value; xi = xi0; info(); };
    q('[data-rs]').onclick = () => { reset(); info(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.৬.২ চাপের প্রভাব: তিনটি সিলিন্ডার (Δn < 0, = 0, > 0) ও নিষ্ক্রিয় গ্যাস ======================= */
V.c4_pressureEq = {
  t: 'চাপের প্রভাব: Δn < ০, Δn = ০ ও Δn > ০ বিক্রিয়ার পিস্টন-সিলিন্ডার এবং নিষ্ক্রিয় গ্যাস', k: ['anim', 'int', '2d', 'calc'],
  cap: 'তিনটি সিলিন্ডারে তিনটি গ্যাসীয় সাম্য একই তাপমাত্রায়। চাপ স্লাইডার বাড়ালে পিস্টন নামে (আয়তন কমে): বামে N₂ + 3H₂ ⇌ 2NH₃ (Δn = −২) — NH₃ (বেগুনি) বাড়ে; মাঝে H₂ + I₂ ⇌ 2HI (Δn = ০) — সংযুতি অপরিবর্তিত; ডানে PCl₅ ⇌ PCl₃ + Cl₂ (Δn = +১) — PCl₅ বাড়ে। নিচের দণ্ডে প্রতিটি পাত্রে উৎপাদের মোল ভগ্নাংশ। "নিষ্ক্রিয় গ্যাস" যোগ করলে ধূসর Ar পরমাণু ঢোকে: স্থির আয়তনে আংশিক চাপ বদলায় না — সাম্য সরে না; স্থির চাপে পিস্টন উঠে যায় (আয়তন বাড়ে) — প্রভাব চাপ কমানোর মতো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('ar', [['0', 'নিষ্ক্রিয় গ্যাস নেই'], ['v', 'Ar যোগ — স্থির আয়তনে'], ['p', 'Ar যোগ — স্থির চাপে']], '0')}</div>${X.cv('তিনটি গ্যাসীয় সাম্যে চাপের প্রভাব')}<label class="small" style="display:block;margin-top:8px">মোট চাপ P = <b data-pv></b> atm<input type="range" min="1" max="10" step="0.5" value="2" data-p></label><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 360 : 400;
    let L = X.fit(c, hf), P = 2, ar = '0', outT = 0, t = 0;
    const R = X.rng(17);
    // systems: species [name, stoich(-react,+prod), initial moles, colors]
    const SYS = [
      { nm: 'N₂ + 3H₂ ⇌ 2NH₃', dn: -2, sp: [['N₂', -1, 1, '#2d6fd6'], ['H₂', -3, 3, '#c9ced6'], ['NH₃', 2, 0, '#7b3fa0']], Kp: 0.05, prod: 2 },
      { nm: 'H₂ + I₂ ⇌ 2HI', dn: 0, sp: [['H₂', -1, 1, '#c9ced6'], ['I₂', -1, 1, '#5b2a86'], ['HI', 2, 0, '#2e9d4e']], Kp: 49, prod: 2 },
      { nm: 'PCl₅ ⇌ PCl₃ + Cl₂', dn: 1, sp: [['PCl₅', -1, 1, '#d08a1e'], ['PCl₃', 1, 0, '#e2c24a'], ['Cl₂', 1, 0, '#3fae5a']], Kp: 1.8, prod: 1 }
    ];
    const nAr = 2;
    const moles = (s, x) => s.sp.map(([, nu, n0]) => n0 + nu * x);
    const solveX = (s, Pr) => { // Pr = partial pressure scale of reacting gases
      const xmax = Math.min(...s.sp.filter(z => z[1] < 0).map(z => z[2] / -z[1]));
      const f = x => { const n = moles(s, x), nt = n.reduce((a, b) => a + b, 0); let lq = 0; s.sp.forEach(([, nu], i) => { lq += nu * Math.log(Math.max(1e-12, n[i] / nt * Pr)); }); return lq - Math.log(s.Kp); };
      let a = 1e-9, b = xmax - 1e-9; for (let i = 0; i < 80; i++) { const m = (a + b) / 2; if (f(m) < 0) a = m; else b = m; } return (a + b) / 2;
    };
    const target = s => { const nt = x => moles(s, x).reduce((a, b) => a + b, 0); if (ar === 'p') { // P total fixed, reacting partial pressure = P * n_r/(n_r+nAr)
        let x = solveX(s, P); for (let i = 0; i < 30; i++) { const nr = nt(x); x = solveX(s, P * nr / (nr + nAr)); } return x; }
      return solveX(s, P); }; // const V: adding Ar doesn't change partial pressures (P = reacting pressure)
    SYS.forEach(s => { s.x = target(s); s.mol = []; });
    const volOf = s => { const n = moles(s, s.x).reduce((a, b) => a + b, 0); return ar === 'p' ? (n + nAr) / P : n / P; };
    SYS.forEach(s => { s.v = volOf(s); });
    const sync = s => { const n = moles(s, s.x).map(v => Math.round(v * 8)); s.sp.forEach((z, i) => { const have = s.mol.filter(m => m.i === i); for (let k = have.length; k < n[i]; k++) s.mol.push({ i, x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, f: 1 }); for (let k = n[i]; k < have.length; k++) s.mol.splice(s.mol.indexOf(have[k]), 1); }); const arH = s.mol.filter(m => m.i === 9); const wantAr = ar === '0' ? 0 : nAr * 8; for (let k = arH.length; k < wantAr; k++) s.mol.push({ i: 9, x: R(), y: R() * 0.2, vx: R() - 0.5, vy: R() - 0.5, f: 0 }); for (let k = wantAr; k < arH.length; k++) s.mol.splice(s.mol.indexOf(arH[k]), 1); };
    const step = dt => { t += dt; SYS.forEach(s => { s.x += (target(s) - s.x) * (1 - Math.exp(-dt / 0.8)); s.v += (volOf(s) - s.v) * (1 - Math.exp(-dt / 0.25)); sync(s); s.mol.forEach(m => { m.x += m.vx * dt * 0.4; m.y += m.vy * dt * 0.4; m.f = Math.max(0, m.f - dt * 1.5); if (m.x < 0.03 || m.x > 0.97) { m.vx *= -1; m.x = Math.max(0.03, Math.min(0.97, m.x)); } if (m.y < 0.04 || m.y > 0.96) { m.vy *= -1; m.y = Math.max(0.04, Math.min(0.96, m.y)); } }); }); };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const cw = (W - 40) / 3, top = 50, ch = H - (wide(W) ? 170 : 200);
      const vmax = Math.max(...SYS.map(s => (s.sp.reduce((a, z) => a + z[2], 0) + nAr) / 1));
      SYS.forEach((s, k) => {
        const x0 = 20 + k * cw + 10, w = cw - 20, vf = Math.min(1, s.v / vmax), gh = Math.max(24, vf * (ch - 20)), py = top + ch - gh;
        g.fillStyle = col.fg; g.textAlign = 'center'; if (wide(W)) { g.font = `bold 10.5px ${col.font}`; g.fillText(s.nm, x0 + w / 2, 13); } else { const pr = s.nm.split(' ⇌ '); g.font = `bold 9.5px ${col.font}`; g.fillText(pr[0] + ' ⇌', x0 + w / 2, 9); g.fillText(pr[1], x0 + w / 2, 19); } g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.fillText(`Δn = ${s.dn > 0 ? '+' : ''}${bn(s.dn)}`, x0 + w / 2, wide(W) ? 27 : 31);
        g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x0, top); g.lineTo(x0, top + ch); g.lineTo(x0 + w, top + ch); g.lineTo(x0 + w, top); g.stroke();
        g.fillStyle = 'rgba(180,210,235,.12)'; g.fillRect(x0, py, w, gh);
        g.fillStyle = '#4a4a4a'; g.fillRect(x0 + 1, py - 8, w - 2, 8); g.fillStyle = col.s3; g.fillRect(x0 + w / 2 - 4, top - 6, 8, py - 8 - top + 6); g.strokeStyle = col.fg; g.lineWidth = 1; g.strokeRect(x0 + w / 2 - 4, top - 6, 8, py - 8 - top + 6);
        const r = Math.max(3, Math.min(5, w / 26));
        s.mol.forEach(m => { const x = x0 + 4 + m.x * (w - 8), y = py + 4 + m.y * (gh - 8); const cc = m.i === 9 ? ['#8e959c', '#e4e8ec'] : [s.sp[m.i][3], '#fff']; ball(g, x, y, m.i === 9 ? r * 0.9 : r * (m.i === s.sp.length - 1 || s.sp[m.i][1] > 0 ? 1.15 : 1), cc[0], cc[1]); });
        // bar: product mole fraction
        const n = moles(s, s.x), nt = n.reduce((a, b) => a + b, 0), yp = s.sp.reduce((a, z, i) => a + (z[1] > 0 ? n[i] : 0), 0) / nt;
        const by = top + ch + (wide(W) ? 30 : 56), bw = w; g.fillStyle = col.s3; g.fillRect(x0, by, bw, 12); g.fillStyle = s.sp.find(z => z[1] > 0)[3]; g.fillRect(x0, by, bw * yp, 12); g.strokeStyle = col.fg; g.strokeRect(x0, by, bw, 12);
        g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(`${wide(W) ? 'উৎপাদের মোল ভগ্নাংশ' : 'উৎপাদ'} ${bn(Math.round(yp * 100))}%`, x0 + w / 2, by + 26);
        let lx = x0; g.textAlign = 'left'; s.sp.forEach((z, j) => { const ly = top + ch + 12 + (wide(W) ? 0 : j * 13); if (!wide(W)) lx = x0; ball(g, lx + 4, ly, 3.5, z[3], '#fff'); g.fillStyle = col.fg; g.fillText(z[0], lx + 10, ly + 3.5); lx += 14 + g.measureText(z[0]).width + 4; });
      });
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'center'; g.fillText(ar === '0' ? '' : ar === 'v' ? 'Ar যোগ: আয়তন স্থির — আংশিক চাপ অপরিবর্তিত' : (wide(W) ? 'Ar যোগ: চাপ স্থির — আয়তন বাড়ে, বিক্রিয়ক গ্যাসের আংশিক চাপ কমে' : 'Ar: চাপ স্থির — আয়তন বাড়ে'), W / 2, H - 6);
    };
    const info = () => {
      q('[data-pv]').textContent = fx(P, 1);
      out.innerHTML = TXB(`\\text{আয়তন } V \\to V/x:\\quad Q = x^{\\Delta n_g} K`) + TXB(`\\begin{cases}\\Delta n_g < 0: Q < K \\Rightarrow \\text{ডানে}\\\\ \\Delta n_g = 0: Q = K \\Rightarrow \\text{প্রভাব নেই}\\\\ \\Delta n_g > 0: Q > K \\Rightarrow \\text{বামে}\\end{cases}`) +
        TXB(`K_p = K_c(RT)^{\\Delta n_g}\\quad(\\text{চাপে } K \\text{ অপরিবর্তিত})`) +
        `<div class="small">চাপ বাড়লে NH₃ এর মোল ভগ্নাংশ বাড়ে, HI অপরিবর্তিত, PCl₃/Cl₂ কমে। ${ar === 'v' ? 'স্থির আয়তনে Ar যোগে কোনো সিলিন্ডারে সংযুতি বদলায়নি।' : ar === 'p' ? 'স্থির চাপে Ar যোগে আয়তন বেড়েছে — NH₃ কমেছে, PCl₅ বেশি ভেঙেছে, HI অপরিবর্তিত।' : ''}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { step(dt); outT += dt; if (outT > 0.4) { outT = 0; info(); } } draw(); }, { paused: false });
    q('[data-p]').oninput = e => { P = +e.target.value; info(); };
    X.onSeg(el, 'ar', v => { ar = v; info(); });
    SYS.forEach(sync); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
