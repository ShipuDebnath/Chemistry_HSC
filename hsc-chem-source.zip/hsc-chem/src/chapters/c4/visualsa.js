/* Chapter 4 visuals part 10 — acid/base strength, conjugate pairs, basicity (4.11) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, TX = C4.tx, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;
const hWeak = (K, c) => { if (c <= 0) return 1e-7; let lo = 1e-14, hi = c + 1e-6; for (let i = 0; i < 80; i++) { const h = Math.sqrt(lo * hi), f = K * c / (K + h) + 1e-14 / h - h; if (f > 0) lo = h; else hi = h; } return Math.sqrt(lo * hi); };

/* ======================= ৪.১১ তীব্র বনাম দুর্বল এসিড ======================= */
const WEAK = [['CH₃COOH', 1.8e-5], ['HCOOH', 1.8e-4], ['HF', 6.8e-4], ['HCN', 4.9e-10]];
V.c4_strength = {
  t: 'তীব্র বনাম দুর্বল এসিড: একই ঘনমাত্রায় আয়নের সংখ্যা, পরিবাহিতা বাল্ব ও Mg এর সাথে বিক্রিয়ার হার (মোট H₂ সমান)', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে HCl, ডানে একটি দুর্বল এসিড — দুটিই একই ঘনমাত্রায়। কণা-দৃশ্যে HCl এর সব অণু H₃O⁺ (হলুদ +) ও Cl⁻ (সবুজ −) এ বিভক্ত; দুর্বল এসিডের অধিকাংশ অণু অবিয়োজিত। উপরের বাল্বের উজ্জ্বলতা আয়নের ঘনমাত্রার (পরিবাহিতা) সমানুপাতিক। "Mg যোগ করো" চাপলে দুটিতে একই Mg ফিতা পড়ে — HCl এ বুদবুদ ঝড়ের মতো, দুর্বল এসিডে ধীরে; নিচের লেখচিত্রে উৎপন্ন H₂ এর আয়তন: হার ভিন্ন, কিন্তু শেষ পর্যন্ত দুটিতে একই পরিমাণ H₂ — কারণ H⁺ খরচ হলে দুর্বল এসিডের সাম্য ডানে সরে নতুন H⁺ জোগায়।',
  html: () => `<div class="grid2"><label class="small">দুর্বল এসিড: <select data-w>${WEAK.map((w, i) => `<option value="${i}">${w[0]}</option>`).join('')}</select></label><label class="small">ঘনমাত্রা c = <b data-cv></b> M<input type="range" min="0.01" max="1" step="0.01" value="0.1" data-c></label></div>${X.cv('তীব্র ও দুর্বল এসিডের তুলনামূলক পরীক্ষা')}<div class="ctl"><button class="btn sm primary" data-mg>${X.ico('play')}Mg যোগ করো</button><button class="btn sm" data-rs>${X.ico('repeat')}আবার শুরু</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? 400 : 520;
    let L = X.fit(c, hf), wi = 0, cc = 0.1, run = false, t = 0, st, bub = [], hist = [], acc = 0;
    const R = X.rng(71), N = 30;
    const parts = [0, 1].map(() => Array.from({ length: N }, () => ({ x: R(), y: R(), vx: R() - 0.5, vy: R() - 0.5, a: R() * 6, d: false })));
    const reset = () => { st = [{ n: 1, h2: 0 }, { n: 1, h2: 0 }]; run = false; t = 0; bub = []; hist = [[0, 0, 0]]; };
    const hOf = k => k === 0 ? cc * st[0].n : hWeak(WEAK[wi][1], cc * st[1].n);
    const step = dt => {
      const K = WEAK[wi][1], al = Math.min(1, hWeak(K, cc) / cc), nd = [N, Math.max(Math.round(al * N), al > 0.005 ? 1 : 0)];
      parts.forEach((P, k) => { let cur = P.filter(p => p.d).length; P.forEach(p => { if (cur < nd[k] && !p.d && R() < 0.06) { p.d = true; cur++; } else if (cur > nd[k] && p.d && R() < 0.06) { p.d = false; cur--; } p.x += p.vx * dt * 0.12; p.y += p.vy * dt * 0.12; p.a += dt; if (p.x < 0.05 || p.x > 0.95) p.vx *= -1; if (p.y < 0.1 || p.y > 0.95) p.vy *= -1; }); });
      if (run) {
        if (st[0].n < 1e-3) dt *= 10;
        t += dt; acc += dt;
        [0, 1].forEach(k => { const h = hOf(k), r = 2.2 * h / 0.1 * (st[k].n > 1e-4 ? 1 : 0), dn = Math.min(st[k].n, r * dt * 0.1 / Math.max(cc, 1e-3) * 0.6); st[k].n -= dn; st[k].h2 += dn / 2; if (R() < Math.min(1, r * dt * 6)) bub.push({ k, x: 0.35 + R() * 0.3, y: 0.92, r: 1.5 + R() * 2 }); });
        if (acc > 0.15) { acc = 0; hist.push([t, st[0].h2, st[1].h2]); }
      }
      bub.forEach(b => { b.y -= dt * 0.5; }); bub = bub.filter(b => b.y > 0.12);
    };
    const geo = () => { const W = L.W, H = L.H, bw = Math.min(220, (W - 60) / 2), gh = wide(W) ? 110 : 150; return { b: [[(W / 2 - bw) / 2 + 4, 70, bw, H - gh - 140], [W / 2 + (W / 2 - bw) / 2 - 4, 70, bw, H - gh - 140]], g: [52, H - gh - 30, W - 72, gh] }; };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const G = geo();
      [0, 1].forEach(k => {
        const [x, y, w, h] = G.b[k], hc = hOf(k), ion = k === 0 ? cc * st[0].n * 2 : hc * 2, br = Math.min(1, Math.log10(1 + ion * 400) / Math.log10(1 + 400 * 2));
        // bulb
        const bx = x + w / 2, by = 30; const gr = g.createRadialGradient(bx, by, 2, bx, by, 34); gr.addColorStop(0, `rgba(255,220,80,${(0.15 + 0.85 * br).toFixed(2)})`); gr.addColorStop(1, 'rgba(255,220,80,0)'); g.fillStyle = gr; g.beginPath(); g.arc(bx, by, 34, 0, 7); g.fill();
        g.fillStyle = `rgba(255,${Math.round(200 + 50 * br)},${Math.round(90 * br)},${(0.3 + 0.7 * br).toFixed(2)})`; g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.arc(bx, by, 11, 0, 7); g.fill(); g.stroke(); g.fillStyle = col.s3; g.fillRect(bx - 6, by + 10, 12, 8); g.strokeRect(bx - 6, by + 10, 12, 8);
        g.strokeStyle = col.mu; g.beginPath(); g.moveTo(bx - 4, by + 18); g.lineTo(x + w * 0.3, y + 10); g.lineTo(x + w * 0.3, y + h * 0.7); g.moveTo(bx + 4, by + 18); g.lineTo(x + w * 0.7, y + 10); g.lineTo(x + w * 0.7, y + h * 0.7); g.stroke();
        // beaker
        g.fillStyle = 'rgba(160,200,235,.2)'; g.fillRect(x, y + 14, w, h - 14); g.strokeStyle = col.fg; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x - 4, y); g.lineTo(x, y + 4); g.lineTo(x, y + h); g.lineTo(x + w, y + h); g.lineTo(x + w, y + 4); g.lineTo(x + w + 4, y); g.stroke();
        const s = Math.max(0.8, Math.min(1.05, w / 200));
        parts[k].forEach((p, i) => { if (run && i >= Math.round(N * st[k].n)) return; const px = x + 8 + p.x * (w - 16), py = y + 18 + p.y * (h - 30); if (!p.d) { ball(g, px - 4 * s, py, 3 * s, '#d8dde3', '#fff'); ball(g, px + 4 * s, py, 5 * s, k === 0 ? '#3fae5a' : '#5b2a86', k === 0 ? '#b6f0c4' : '#c7a2ec'); } else { ball(g, px - 7 * s, py, 5 * s, k === 0 ? '#3fae5a' : '#5b2a86', k === 0 ? '#b6f0c4' : '#c7a2ec'); ball(g, px + 7 * s, py + 2, 3.6 * s, '#f2b705', '#fff1b8'); g.fillStyle = col.fg; g.font = `bold ${Math.round(9 * s)}px ${col.font}`; g.textAlign = 'center'; g.fillText('−', px - 7 * s, py - 6 * s); g.fillText('+', px + 7 * s, py - 4 * s); } });
        if (run || t > 0) { g.fillStyle = '#8f9aa6'; g.fillRect(x + w * 0.38, y + h - 10 - 26 * Math.max(0.15, 1 - (1 - st[0].n) * 0.6), w * 0.24, 4); }
        bub.filter(b => b.k === k).forEach(b => { g.strokeStyle = 'rgba(255,255,255,.95)'; g.fillStyle = 'rgba(210,235,255,.4)'; g.lineWidth = 1; g.beginPath(); g.arc(x + b.x * w, y + b.y * h, b.r, 0, 7); g.fill(); g.stroke(); });
        g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText(k === 0 ? 'HCl (তীব্র)' : `${WEAK[wi][0]} (দুর্বল)`, x + w / 2, y + h + 15); g.font = `10px ${col.font}`; g.fillStyle = col.mu; g.fillText(`pH = ${fx(-Math.log10(hOf(k)), 2)} · α = ${k === 0 ? '≈১০০' : fx(100 * hWeak(WEAK[wi][1], cc) / cc, 2)}%`, x + w / 2, y + h + 28);
      });
      const [gx, gy, gw, gh] = G.g, tm = Math.max(20, t), P = cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmax: tm, ymax: 0.55, col, xt: [0, Math.round(tm / 2), Math.round(tm)], yt: [0, 0.25, 0.5], fy: v => fx(v * 100, 0) + '%', xl: 'সময় (s)', yl: 'H₂ (সর্বোচ্চের %)', ylx: 36 });
      if (hist.length > 1) { path(g, hist.map(h => [P.X(h[0]), P.Y(h[1])]), '#3fae5a', 2.6); path(g, hist.map(h => [P.X(h[0]), P.Y(h[2])]), '#7b3fa0', 2.6); }
      g.setLineDash([3, 3]); g.strokeStyle = col.mu; g.beginPath(); g.moveTo(gx, P.Y(0.5)); g.lineTo(gx + gw, P.Y(0.5)); g.stroke(); g.setLineDash([]);
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'right'; g.fillText('সম্পূর্ণ বিক্রিয়ায় H₂ (দুটিতেই সমান)', gx + gw, P.Y(0.5) - 4); if (run && st[0].n < 1e-3) { g.fillStyle = col.acc; g.textAlign = 'left'; g.fillText('⏩ HCl শেষ — সময় ১০ গুণ দ্রুত চলছে', gx + 8, P.Y(0.5) + 16); }
    };
    const info = () => {
      const [nm, K] = WEAK[wi], hw = hWeak(K, cc);
      q('[data-cv]').textContent = fx(cc, 2);
      out.innerHTML = TXB(`\\ce{HCl + H2O -> H3O+ + Cl-}`) + TXB(`[\\ce{H+}]_{\\ce{HCl}} = c = ${cc.toFixed(2)}\\ \\mathrm{M}`) + TXB(`[\\ce{H+}]_{\\text{${nm}}} = ${sci(hw, 2)}\\ \\mathrm{M}`) + TXB(`\\dfrac{[\\ce{H+}]_{\\ce{HCl}}}{[\\ce{H+}]_{\\text{দুর্বল}}} = ${(cc / hw).toFixed(cc / hw > 100 ? 0 : 1)}`) +
        `<div class="small">${run || t > 0 ? `H₂ উৎপাদন: HCl ${fx(st[0].h2 * 200, 0)}%, দুর্বল এসিড ${fx(st[1].h2 * 200, 0)}% (সর্বোচ্চের)। হার ভিন্ন — মোট পরিমাণ শেষে সমান।` : 'Mg যোগ করে দুটির বিক্রিয়ার হার তুলনা করো।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { step(dt); if (run && (st[0].n < 1e-3 && st[1].n < 1e-3 || t > 240)) run = false; } draw(); if (dt && run && Math.round(t * 10) % 3 === 0) info(); }, { paused: false });
    q('[data-mg]').onclick = () => { reset(); run = true; info(); };
    q('[data-rs]').onclick = () => { reset(); info(); };
    q('[data-w]').onchange = e => { wi = +e.target.value; reset(); info(); };
    q('[data-c]').oninput = e => { cc = +e.target.value; reset(); info(); };
    reset(); info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ======================= ৪.১১.১ অনুবন্ধী জোড়: pKa + pKb = 14 মই ও বিক্রিয়ার দিক ======================= */
const PAIRS = [['HCl', 'Cl⁻', -7], ['H₃O⁺', 'H₂O', -1.74], ['HSO₄⁻', 'SO₄²⁻', 1.92], ['H₃PO₄', 'H₂PO₄⁻', 2.12], ['HF', 'F⁻', 3.17], ['CH₃COOH', 'CH₃COO⁻', 4.74], ['H₂CO₃', 'HCO₃⁻', 6.37], ['NH₄⁺', 'NH₃', 9.26], ['HCN', 'CN⁻', 9.31], ['HCO₃⁻', 'CO₃²⁻', 10.32], ['H₂O', 'OH⁻', 15.74]];
V.c4_conjugate = {
  t: 'অনুবন্ধী এসিড-ক্ষারক মই: pKa + pKb = 14 এবং এসিড-ক্ষার বিক্রিয়ার দিক নির্ণয়', k: ['int', '2d', 'calc'],
  cap: 'মাঝের মইয়ের বামে এসিড (উপরে তীব্রতম), ডানে তার অনুবন্ধী ক্ষারক (নিচে তীব্রতম) — প্রতিটি জোড় একই সারিতে, কারণ pK_a + pK_b = ১৪। এসিড যত উপরে (তীব্র), অনুবন্ধী ক্ষারক তত দুর্বল। একটি এসিড ও একটি ক্ষারক বেছে নাও: সংযোগকারী তীর দেখায় প্রোটন কোন দিকে যায়; সাম্যধ্রুবক K = K_a(এসিড)/K_a(ক্ষারকের অনুবন্ধী এসিড)। এসিড যদি মইয়ে ক্ষারকের অনুবন্ধী এসিডের উপরে থাকে, K > ১ — বিক্রিয়া ডানে (দুর্বলতর জোড়ের দিকে)।',
  html: () => `<div class="grid2"><label class="small">এসিড: <select data-a>${PAIRS.map((p, i) => `<option value="${i}" ${i === 5 ? 'selected' : ''}>${p[0]}</option>`).join('')}</select></label><label class="small">ক্ষারক: <select data-b>${PAIRS.map((p, i) => `<option value="${i}" ${i === 8 ? 'selected' : ''}>${p[1]}</option>`).join('')}</select></label></div>${X.cv('অনুবন্ধী এসিড-ক্ষারক মই')}<div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = () => 380;
    let L = X.fit(c, hf), ai = 5, bi = 8;
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H);
      const cx = W / 2, top = 30, bot = H - 26, Y = pk => top + (pk + 8) / 25 * (bot - top), lw = wide(W) ? 150 : 100;
      const gr = g.createLinearGradient(0, top, 0, bot); gr.addColorStop(0, 'rgba(224,64,46,.35)'); gr.addColorStop(1, 'rgba(224,64,46,.03)'); g.fillStyle = gr; g.fillRect(cx - 34, top, 14, bot - top);
      const gr2 = g.createLinearGradient(0, top, 0, bot); gr2.addColorStop(0, 'rgba(45,111,214,.03)'); gr2.addColorStop(1, 'rgba(45,111,214,.35)'); g.fillStyle = gr2; g.fillRect(cx + 20, top, 14, bot - top);
      g.strokeStyle = col.fg; g.lineWidth = 1.4; g.beginPath(); g.moveTo(cx - 20, top); g.lineTo(cx - 20, bot); g.moveTo(cx + 20, top); g.lineTo(cx + 20, bot); g.stroke();
      g.fillStyle = col.fg; g.font = `bold 10.5px ${col.font}`; g.textAlign = 'center'; g.fillText('এসিড (pK_a)', cx - lw / 2 - 30, 14); g.fillText('অনুবন্ধী ক্ষারক (pK_b)', cx + lw / 2 + 30, 14);
      g.font = `9.5px ${col.font}`; g.fillStyle = '#c0392b'; g.save(); g.translate(14, (top + bot) / 2); g.rotate(-Math.PI / 2); g.fillText('← এসিড তীব্রতা বাড়ে', 0, 0); g.restore(); g.fillStyle = '#2d6fd6'; g.save(); g.translate(W - 14, (top + bot) / 2); g.rotate(Math.PI / 2); g.fillText('← ক্ষারক তীব্রতা বাড়ে', 0, 0); g.restore();
      const ly = []; PAIRS.forEach(([a, b, pk], i) => { let y = Y(pk); if (i && y < ly[i - 1] + 13) y = ly[i - 1] + 13; ly.push(y); });
      PAIRS.forEach(([a, b, pk], i) => { const y0 = Y(pk), y = ly[i], sel = i === ai || i === bi; if (Math.abs(y - y0) > 1) { g.strokeStyle = col.mu; g.lineWidth = 0.8; g.beginPath(); g.moveTo(cx - 22, y0); g.lineTo(cx - 48, y); g.moveTo(cx + 22, y0); g.lineTo(cx + 48, y); g.stroke(); } g.strokeStyle = sel ? col.acc : col.line || col.mu; g.lineWidth = sel ? 2 : 1; g.beginPath(); g.moveTo(cx - 20, y0); g.lineTo(cx + 20, y0); g.stroke(); g.fillStyle = i === ai ? '#c0392b' : col.fg; g.font = `${i === ai ? 'bold ' : ''}10.5px ${col.font}`; g.textAlign = 'right'; g.fillText(`${a}  ${pk < 0 ? '−' : ''}${fx(Math.abs(pk), 2)}`, cx - 52, y + 4); g.fillStyle = i === bi ? '#2d6fd6' : col.fg; g.font = `${i === bi ? 'bold ' : ''}10.5px ${col.font}`; g.textAlign = 'left'; const pkb = 14 - pk; g.fillText(`${pkb < 0 ? '−' : ''}${fx(Math.abs(pkb), 2)}  ${b}`, cx + 52, y + 4); });
      // proton transfer arrow from acid (left at Y(pa)) to base (right at Y(pb))
      const ya = Y(PAIRS[ai][2]), yb = Y(PAIRS[bi][2]), down = ya < yb;
      g.strokeStyle = down ? '#2e9d4e' : '#e0402e'; g.lineWidth = 2.4; g.beginPath(); g.moveTo(cx - 20, ya); g.bezierCurveTo(cx, ya, cx, yb, cx + 20, yb); g.stroke();
      const a = Math.atan2(yb - ya, 40); g.fillStyle = down ? '#2e9d4e' : '#e0402e'; g.beginPath(); g.moveTo(cx + 20, yb); g.lineTo(cx + 12, yb - 5); g.lineTo(cx + 12, yb + 5); g.fill();
      g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillStyle = down ? '#2e9d4e' : '#e0402e'; g.fillText('H⁺', cx, (ya + yb) / 2 - 6);
    };
    const info = () => {
      const [a, ab, pa] = PAIRS[ai], [bA, b, pb] = PAIRS[bi], lk = pb - pa, K = Math.pow(10, lk);
      const ce = z => z.replace(/[₀-₉]/g, d => '0123456789'['₀₁₂₃₄₅₆₇₈₉'.indexOf(d)]).replace(/([²³])([⁺⁻])/g, (m, n, sg) => '^' + (n === '²' ? 2 : 3) + (sg === '⁺' ? '+' : '-')).replace(/⁺/g, '+').replace(/⁻/g, '-');
      out.innerHTML = TXB(`\\ce{${ce(a)} + ${ce(b)} <=> ${ce(ab)} + ${ce(bA)}}`) +
        TXB(`K = \\dfrac{K_a(\\text{এসিড})}{K_a(\\text{ক্ষারকের অনুবন্ধী এসিড})}`) + TXB(`K = 10^{\\,${pb.toFixed(2)} - (${pa.toFixed(2)})} = ${sci(K, 2)}`) +
        `<div class="small">${ai === bi ? 'একই জোড় — K = ১।' : lk > 0 ? `K > ১: সাম্য ডানে — তীব্রতর এসিড (${a}) ও তীব্রতর ক্ষারক (${b}) বিক্রিয়া করে দুর্বলতর এসিড (${bA}) ও দুর্বলতর ক্ষারক (${ab}) তৈরি করে।` : `K < ১: সাম্য বামে — ${a} এর চেয়ে ${bA} তীব্রতর এসিড, তাই প্রোটন স্থানান্তর অল্পই ঘটে।`} প্রতিটি জোড়ে K_a × K_b = ১০⁻¹⁴।</div>`;
    };
    q('[data-a]').onchange = e => { ai = +e.target.value; info(); draw(); };
    q('[data-b]').onchange = e => { bi = +e.target.value; info(); draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); draw(); });
    return () => { un(); };
  }
};

/* ======================= ৪.১১.২ ফসফরাসের অক্সিএসিডের ক্ষারকত্ব: গঠন ও টাইট্রেশন লেখচিত্র ======================= */
const PACID = {
  h3po4: { nm: 'H₃PO₄', K: [7.5e-3, 6.2e-8, 4.8e-13], oh: 3, ph: 0, b: 3 },
  h3po3: { nm: 'H₃PO₃', K: [5.0e-2, 2.0e-7], oh: 2, ph: 1, b: 2 },
  h3po2: { nm: 'H₃PO₂', K: [5.9e-2], oh: 1, ph: 2, b: 1 },
  h3bo3: { nm: 'H₃BO₃', K: [5.8e-10], oh: 3, ph: 0, b: 1, boron: true }
};
V.c4_basicity = {
  t: 'অম্লের ক্ষারকত্ব: H₃PO₄, H₃PO₃, H₃PO₂ ও H₃BO₃ এর গঠন, আয়নযোগ্য H এবং NaOH দিয়ে টাইট্রেশন লেখচিত্র', k: ['anim', 'int', '2d', 'calc'],
  cap: 'বামে এসিডের গঠন: সবুজ বলয়ের H গুলো O এর সাথে যুক্ত (পোলার O–H) — প্রতিস্থাপনযোগ্য; ধূসর H গুলো সরাসরি P এর সাথে (প্রায় অপোলার P–H) — আয়নিত হয় না। NaOH স্লাইডার বাড়ালে (এসিডের প্রতি মোলে কত মোল OH⁻) আয়নযোগ্য H একে একে Na⁺ দিয়ে প্রতিস্থাপিত হয়, আর ডানে টাইট্রেশন লেখচিত্রে pH বাড়ে — প্রতিটি সমতুল্য বিন্দুতে লাফ। H₃PO₃ এ দুটি, H₃PO₂ এ একটি ধাপ — তিনটি H থাকা সত্ত্বেও। H₃BO₃ অত্যন্ত দুর্বল একক্ষারকীয় লুইস এসিড — B এর খালি অরবিটাল পানির OH⁻ গ্রহণ করে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('a', [['h3po4', 'H₃PO₄'], ['h3po3', 'H₃PO₃'], ['h3po2', 'H₃PO₂'], ['h3bo3', 'H₃BO₃']], 'h3po4')}</div>${X.cv('ফসফরাসের অক্সিএসিডের গঠন ও টাইট্রেশন লেখচিত্র')}<label class="small" style="display:block;margin-top:8px">যোগ করা NaOH = <b data-nv></b> mol / mol এসিড<input type="range" min="0" max="3.5" step="0.02" value="0" data-n></label><div class="ctl"><button class="btn sm primary" data-go>${X.ico('play')}টাইট্রেশন চালাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s), sN = q('[data-n]');
    const hf = w => wide(w) ? 320 : 600;
    let L = X.fit(c, hf), key = 'h3po4', nOH = 0, auto = false;
    const pHat = (S, eq) => { // 25 mL 0.10 M acid + eq × 2.5 mmol NaOH (0.10 M)
      const Va = 0.025, Vb = eq * 0.025, Vt = Va + Vb, Ca = 0.1 * Va / Vt, Na = 0.1 * Vb / Vt;
      let lo = 1e-14, hi = 1; for (let i = 0; i < 80; i++) { const h = Math.sqrt(lo * hi); const t = [1]; for (let j = 0; j < S.K.length; j++) t.push(t[j] * S.K[j] / h); const s = t.reduce((a, b) => a + b, 0); let ch = 0; t.forEach((v, j) => { ch += j * v / s; }); const f = Na + h - 1e-14 / h - Ca * ch; if (f > 0) hi = h; else lo = h; } return -Math.log10(Math.sqrt(lo * hi));
    };
    const drawStruct = (g, col, x0, y0, sz, S) => {
      const cx = x0 + sz / 2, cy = y0 + sz / 2, Rb = sz * 0.22, rH = 7;
      const cen = S.boron ? 'B' : 'P';
      const sub = []; // positions around centre
      if (!S.boron) { sub.push({ t: 'O=', ang: -Math.PI / 2 }); const n = S.oh + S.ph; const angs = n === 3 ? [Math.PI / 6, Math.PI * 5 / 6, Math.PI / 2] : []; let k = 0; for (let i = 0; i < S.oh; i++) sub.push({ t: 'OH', ang: angs[k++] }); for (let i = 0; i < S.ph; i++) sub.push({ t: 'H', ang: angs[k++] }); }
      else { [-Math.PI / 2, Math.PI / 6, Math.PI * 5 / 6].forEach(a => sub.push({ t: 'OH', ang: a })); }
      let replaced = Math.min(S.b, Math.floor(nOH + 1e-6)), ri = 0;
      sub.forEach(s => {
        const ox = cx + Math.cos(s.ang) * Rb, oy = cy + Math.sin(s.ang) * Rb;
        g.strokeStyle = col.fg; g.lineWidth = 2.4; if (s.t === 'O=') { const nx = -Math.sin(s.ang) * 3, ny = Math.cos(s.ang) * 3; g.beginPath(); g.moveTo(cx + nx, cy + ny); g.lineTo(ox + nx, oy + ny); g.moveTo(cx - nx, cy - ny); g.lineTo(ox - nx, oy - ny); g.stroke(); ball(g, ox, oy, 11, '#c0392b', '#ff9f8f'); g.fillStyle = '#fff'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('O', ox, oy + 4); }
        else if (s.t === 'OH') { g.beginPath(); g.moveTo(cx, cy); g.lineTo(ox, oy); g.stroke(); const hx = cx + Math.cos(s.ang) * Rb * 1.75, hy = cy + Math.sin(s.ang) * Rb * 1.75; const isRep = !S.boron && ri < replaced || (S.boron && ri === 0 && nOH >= 0.999); const ionz = !S.boron || ri === 0; ri++;
          g.beginPath(); g.moveTo(ox, oy); g.lineTo(hx, hy); g.stroke(); ball(g, ox, oy, 11, '#c0392b', '#ff9f8f'); g.fillStyle = '#fff'; g.font = `bold 11px ${col.font}`; g.textAlign = 'center'; g.fillText('O', ox, oy + 4);
          if (isRep) { ball(g, hx, hy, 9, '#7a5af5', '#d8ccff'); g.fillStyle = '#fff'; g.font = `bold 9px ${col.font}`; g.fillText('Na', hx, hy + 3); g.fillStyle = '#c0392b'; g.font = `bold 12px ${col.font}`; g.fillText('−', ox + 13, oy - 8); }
          else { ball(g, hx, hy, rH, '#e8ecf0', '#fff'); g.fillStyle = '#333'; g.font = `bold 9px ${col.font}`; g.fillText('H', hx, hy + 3); if (ionz && !S.boron) { g.strokeStyle = '#2e9d4e'; g.lineWidth = 2; g.beginPath(); g.arc(hx, hy, rH + 4, 0, 7); g.stroke(); } } }
        else { g.beginPath(); g.moveTo(cx, cy); g.lineTo(ox, oy); g.stroke(); ball(g, ox, oy, rH, '#c9ced6', '#fff'); g.fillStyle = '#333'; g.font = `bold 9px ${col.font}`; g.textAlign = 'center'; g.fillText('H', ox, oy + 3); g.strokeStyle = '#9aa3ad'; g.setLineDash([2, 2]); g.lineWidth = 1.2; g.beginPath(); g.arc(ox, oy, rH + 4, 0, 7); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText('P–H (অপোলার)', ox, oy + 22); }
      });
      if (S.boron && nOH > 0.05) { const ox = cx - Rb * 1.6, oy = cy + Rb * 0.9; g.strokeStyle = '#2d6fd6'; g.setLineDash([3, 3]); g.lineWidth = 1.6; g.beginPath(); g.moveTo(ox + 10, oy - 6); g.lineTo(cx - 8, cy + 6); g.stroke(); g.setLineDash([]); ball(g, ox, oy, 10, '#2d6fd6', '#a9c8ff'); g.fillStyle = '#fff'; g.font = `bold 9px ${col.font}`; g.textAlign = 'center'; g.fillText('OH⁻', ox, oy + 3); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText('খালি p অরবিটালে OH⁻', ox, oy + 22); }
      ball(g, cx, cy, 15, S.boron ? '#e0a37a' : '#e08a2a', S.boron ? '#ffd9bf' : '#ffd29a'); g.fillStyle = '#fff'; g.font = `bold 13px ${col.font}`; g.textAlign = 'center'; g.fillText(cen, cx, cy + 5);
      g.fillStyle = col.fg; g.font = `bold 11px ${col.font}`; g.fillText(`${S.nm} · ক্ষারকত্ব ${bn(S.b)}`, cx, y0 + sz + 4);
    };
    const draw = () => {
      const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); const S = PACID[key];
      const sz = wide(W) ? Math.min(250, W * 0.36) : Math.min(260, W - 40), sx = wide(W) ? 14 : (W - sz) / 2, sy = 10;
      drawStruct(g, col, sx, sy, sz, S);
      const gx = wide(W) ? sx + sz + 60 : 52, gy = wide(W) ? 16 : sz + 50, gw = wide(W) ? W - gx - 20 : W - 72, gh = wide(W) ? H - 60 : H - gy - 40;
      const P = cplot(g, { x0: gx, y0: gy, w: gw, h: gh, xmin: 0, xmax: 3.5, ymin: 0, ymax: 14, col, xt: [0, 1, 2, 3], yt: [0, 2, 4, 6, 8, 10, 12, 14], xl: 'NaOH (mol / mol এসিড)', yl: 'pH', ylx: 30 });
      for (let k = 1; k <= S.b; k++) { g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(P.X(k), gy); g.lineTo(P.X(k), gy + gh); g.stroke(); g.setLineDash([]); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(`সমতুল্য ${bn(k)}`, P.X(k), gy + 10); }
      const pts = []; for (let e = 0; e <= 3.5; e += 0.01) pts.push([P.X(e), P.Y(pHat(S, e))]); path(g, pts, '#7b3fa0', 2.6);
      ball(g, P.X(nOH), P.Y(pHat(S, nOH)), 5.5, '#c0392b', '#ffb3a8');
    };
    const info = () => {
      const S = PACID[key];
      q('[data-nv]').textContent = fx(nOH, 2);
      const eqs = { h3po4: '\\ce{H3PO4 + 3NaOH -> Na3PO4 + 3H2O}', h3po3: '\\ce{H3PO3 + 2NaOH -> Na2HPO3 + 2H2O}', h3po2: '\\ce{H3PO2 + NaOH -> NaH2PO2 + H2O}', h3bo3: '\\ce{B(OH)3 + H2O <=> [B(OH)4]- + H+}' };
      out.innerHTML = TXB(eqs[key]) + TXB(S.K.map((k, i) => `K_{a${S.K.length > 1 ? i + 1 : ''}} = ${sci(k, 1)}`).join(',\\ ') + `,\\quad \\mathrm{pH} = ${pHat(S, nOH).toFixed(2)}`) +
        `<div class="small">${{ h3po4: 'তিনটি P–O–H — ত্রিক্ষারকীয়। লেখচিত্রে প্রথম দুটি লাফ স্পষ্ট; তৃতীয়টি অস্পষ্ট কারণ K_a3 অতি ক্ষুদ্র (HPO₄²⁻ খুব দুর্বল এসিড) — তবু অতিরিক্ত NaOH এ Na₃PO₄ তৈরি হয়।', h3po3: 'দুটি P–O–H ও একটি P–H — দ্বিক্ষারকীয়। দুটি সমতুল্য বিন্দুর পরে আর কোনো ধাপ নেই; Na₃PO₃ তৈরি হয় না।', h3po2: 'একটি P–O–H ও দুটি P–H — একক্ষারকীয়। কেবল একটি সমতুল্য বিন্দু।', h3bo3: 'তিনটি B–O–H থাকলেও প্রোটন দাতা নয়; B এর খালি p অরবিটাল OH⁻ গ্রহণ করে [B(OH)₄]⁻ তৈরি করে — একক্ষারকীয় অতি দুর্বল লুইস এসিড; লেখচিত্রে প্রায় কোনো লাফ নেই।' }[key]}</div>`;
    };
    const A = X.anim(el, dt => { if (dt && auto) { nOH = Math.min(3.5, nOH + dt * 0.45); sN.value = nOH; info(); if (nOH >= 3.5) auto = false; } draw(); }, { paused: false });
    X.onSeg(el, 'a', v => { key = v; info(); });
    sN.oninput = () => { nOH = +sN.value; auto = false; info(); };
    q('[data-go]').onclick = () => { nOH = 0; auto = true; };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
