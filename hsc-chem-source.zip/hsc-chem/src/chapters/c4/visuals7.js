/* Chapter 4 visuals part 7 — industrial applications of Le Chatelier (4.7): Haber and Contact processes */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C4 = window.C4V;
const bn = X.bn, ball = C4.ball, TXB = C4.txb, sci = C4.sci, path = C4.path, cplot = C4.cplot;
const fx = (v, d) => bn((+v).toFixed(d));
const wide = W => W >= 560;

/* ---------- process-flow helpers ---------- */
const unit = (g, col, x, y, w, h, title, sub, fill, shape) => {
  g.save();
  g.fillStyle = fill || col.s2; g.strokeStyle = col.fg; g.lineWidth = 1.4;
  g.beginPath();
  if (shape === 'tower') { g.moveTo(x, y + 8); g.quadraticCurveTo(x + w / 2, y - 6, x + w, y + 8); g.lineTo(x + w, y + h - 8); g.quadraticCurveTo(x + w / 2, y + h + 6, x, y + h - 8); g.closePath(); }
  else if (g.roundRect) g.roundRect(x, y, w, h, 6); else g.rect(x, y, w, h);
  g.fill(); g.stroke();
  g.fillStyle = col.fg; g.textAlign = 'center'; g.font = `bold 10px ${col.font}`;
  const lines = title.split('\n'); lines.forEach((ln, i) => g.fillText(ln, x + w / 2, y + h / 2 - (lines.length - 1) * 6 + i * 12 + (sub ? -4 : 3)));
  if (sub) { g.font = `9px ${col.font}`; g.fillStyle = col.mu; g.fillText(sub, x + w / 2, y + h / 2 + (lines.length - 1) * 6 + 10); }
  g.restore();
};
const pipe = (g, col, pts, flowCol, t, speed = 1, dash = false) => {
  g.strokeStyle = col.ln || col.mu; g.lineWidth = 5; g.lineJoin = 'round'; g.setLineDash(dash ? [6, 4] : []);
  g.beginPath(); pts.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y)); g.stroke(); g.setLineDash([]);
  g.strokeStyle = col.sf; g.lineWidth = 2.6; g.beginPath(); pts.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y)); g.stroke();
  // moving dots
  let len = 0; const seg = []; for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(l); len += l; }
  const n = Math.max(2, Math.floor(len / 18));
  const cols = Array.isArray(flowCol) ? flowCol : [flowCol];
  for (let k = 0; k < n; k++) {
    let d = ((k / n) * len + t * 28 * speed) % len, i = 0; while (i < seg.length - 1 && d > seg[i]) { d -= seg[i]; i++; }
    const f = seg[i] ? d / seg[i] : 0, x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f;
    g.fillStyle = cols[k % cols.length]; g.beginPath(); g.arc(x, y, 2.2, 0, 7); g.fill();
  }
  // arrow head at end
  const [x1, y1] = pts[pts.length - 2], [x2, y2] = pts[pts.length - 1], a = Math.atan2(y2 - y1, x2 - x1);
  g.fillStyle = col.fg; g.beginPath(); g.moveTo(x2, y2); g.lineTo(x2 - 8 * Math.cos(a - 0.45), y2 - 8 * Math.sin(a - 0.45)); g.lineTo(x2 - 8 * Math.cos(a + 0.45), y2 - 8 * Math.sin(a + 0.45)); g.closePath(); g.fill();
};
const meter = (g, col, x, y, w, label, v, c, txt) => {
  g.fillStyle = col.fg; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText(label, x, y - 4);
  g.fillStyle = col.s3; g.fillRect(x, y, w, 9); g.fillStyle = c; g.fillRect(x, y, w * Math.max(0, Math.min(1, v)), 9); g.strokeStyle = col.fg; g.lineWidth = 0.8; g.strokeRect(x, y, w, 9);
  g.textAlign = 'right'; g.fillStyle = col.fg; g.fillText(txt, x + w, y - 4);
};
/* simple 3D surface (painter's algorithm) */
const surf3d = (g, W, H, view, fz, nx, ny, colorOf, axes, mark) => {
  const { yaw, pitch } = view, S = Math.min(W * 0.55, H * 0.62), cx = W / 2, cy = H / 2 + 22;
  const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const P = (x, y, z) => { const x1 = x * cyw - y * syw, y1 = x * syw + y * cyw; const yy = y1 * cp + z * sp, zz = -y1 * sp + z * cp; return [cx + x1 * S, cy - zz * S, yy]; };
  const q = [];
  for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) {
    const u0 = i / nx, u1 = (i + 1) / nx, v0 = j / ny, v1 = (j + 1) / ny;
    const c = [[u0, v0], [u1, v0], [u1, v1], [u0, v1]].map(([u, v]) => { const z = fz(u, v); return P(u - 0.5, v - 0.5, z * 0.8 - 0.4); });
    q.push({ c, d: c.reduce((s, p) => s + p[2], 0) / 4, val: fz((u0 + u1) / 2, (v0 + v1) / 2) });
  }
  // floor box
  const fl = [[-0.5, -0.5], [0.5, -0.5], [0.5, 0.5], [-0.5, 0.5]].map(([x, y]) => P(x, y, -0.4));
  g.fillStyle = 'rgba(128,128,128,.08)'; g.strokeStyle = 'rgba(128,128,128,.6)'; g.lineWidth = 1; g.beginPath(); fl.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.fill(); g.stroke();
  g.strokeStyle = 'rgba(128,128,128,.35)'; for (let k = 1; k < 4; k++) { const a = P(-0.5 + k / 4, -0.5, -0.4), b = P(-0.5 + k / 4, 0.5, -0.4), c2 = P(-0.5, -0.5 + k / 4, -0.4), d = P(0.5, -0.5 + k / 4, -0.4); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.moveTo(c2[0], c2[1]); g.lineTo(d[0], d[1]); g.stroke(); }
  [[-0.5, 0.5], [0.5, 0.5], [-0.5, -0.5]].forEach(([x, y]) => { const a = P(x, y, -0.4), b = P(x, y, 0.4); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); });
  q.sort((a, b) => b.d - a.d).forEach(f => { g.fillStyle = colorOf(f.val); g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 0.5; g.beginPath(); f.c.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.fill(); g.stroke(); });
  axes(P);
  if (mark) { const [u, v] = mark, z = fz(u, v), p = P(u - 0.5, v - 0.5, z * 0.8 - 0.4), b = P(u - 0.5, v - 0.5, -0.4); g.strokeStyle = '#e0402e'; g.setLineDash([3, 3]); g.lineWidth = 1.2; g.beginPath(); g.moveTo(b[0], b[1]); g.lineTo(p[0], p[1]); g.stroke(); g.setLineDash([]); ball(g, p[0], p[1], 5.5, '#c0392b', '#ffb3a8'); }
};
const heat = v => { const t = Math.max(0, Math.min(1, v)); const st = [[68, 1, 84], [59, 82, 139], [33, 145, 140], [94, 201, 98], [253, 231, 37]]; const k = Math.min(3, Math.floor(t * 4)), f = t * 4 - k; return `rgb(${st[k].map((c, i) => Math.round(c + (st[k + 1][i] - c) * f)).join(',')})`; };

/* ---------- Haber model (fitted to equilibrium data, 3:1 feed) ---------- */
const haberY = (Tc, P) => {
  const T = Tc + 273.15, Kp = Math.pow(10, -4.38) * Math.exp(106000 / 8.314 * (1 / T - 1 / 723)) * Math.exp(0.002 * P);
  let lo = 1e-9, hi = 1 - 1e-9; for (let i = 0; i < 70; i++) { const x = (lo + hi) / 2, nt = 4 - 2 * x, qv = (2 * x / nt) ** 2 / ((1 - x) / nt * ((3 - 3 * x) / nt) ** 3 * P * P); if (qv < Kp) lo = x; else hi = x; }
  const x = (lo + hi) / 2; return 2 * x / (4 - 2 * x);
};
const haberRate = (Tc, P, cat) => 3 * Math.exp(-100000 / 8.314 * (1 / (Tc + 273.15) - 1 / 723)) * (P / 200) * (cat ? 1 : 0.004);

/* ======================= ৪.৭ হেবার পদ্ধতি ======================= */
V.c4_haber = {
  t: 'হেবার-বশ পদ্ধতি: প্রবাহচিত্র, তাপমাত্রা-চাপ-উৎপাদন লেখচিত্র ও ৩D তল', k: ['anim', 'int', '2d', '3d', 'calc'],
  cap: '"প্রবাহচিত্র" এ অ্যামোনিয়া কারখানার ধাপগুলো চলমান: N₂ (বাতাস থেকে) ও H₂ (প্রাকৃতিক গ্যাস থেকে) ১ : ৩ অনুপাতে মিশে কম্প্রেসরে ২০০ atm এ সংকুচিত হয়, তাপ বিনিময়ক পেরিয়ে Fe প্রভাবকের স্তরে ৪৫০ °C এ বিক্রিয়া করে। এক পাসে মাত্র ~১৫% রূপান্তর হয়; শীতলীকরণে NH₃ তরল হয়ে আলাদা হয় (উৎপাদ অপসারণ — সাম্য ডানে) এবং অবিক্রিত N₂/H₂ পুনঃচক্রে ফিরে যায় — মোট রূপান্তর প্রায় ৯৮%। "লেখচিত্র" এ বিভিন্ন চাপে তাপমাত্রার সাথে সাম্য NH₃ (%) কীভাবে কমে, আর "৩D তল" এ একসাথে T ও P এর প্রভাব (টেনে ঘোরাও)। স্লাইডারে T ও P বদলে দেখো: সাম্য উৎপাদন, বিক্রিয়ার হার, এক পাসে প্রকৃত উৎপাদন ও সংকোচন খরচ — কেন ৪০০–৪৫০ °C ও ১৫০–৩০০ atm "আপস শর্ত"।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('v', [['plant', 'প্রবাহচিত্র'], ['graph', 'লেখচিত্র'], ['3d', '৩D তল']], 'plant')}</div>${X.cv('হেবার পদ্ধতির প্রবাহচিত্র ও উৎপাদন লেখচিত্র')}<div class="grid2" style="margin-top:8px"><label class="small">তাপমাত্রা T = <b data-tv></b> °C<input type="range" min="300" max="600" step="10" value="450" data-t></label><label class="small">চাপ P = <b data-pv></b> atm<input type="range" min="25" max="400" step="25" value="200" data-p></label></div><div class="ctl"><label class="small"><input type="checkbox" data-cat checked> Fe প্রভাবক (K₂O, Al₂O₃ সহায়কসহ)</label></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? Math.max(340, w * 0.52 + 20) : 640;
    let L = X.fit(c, hf), view = 'plant', T = 450, P = 200, cat = true, t = 0;
    const v3 = { yaw: 3.75, pitch: 0.42 };
    C4.drag3d(c, v3, () => A.draw());
    const calc = () => { const ye = haberY(T, P), r = haberRate(T, P, cat), ap = 1 - Math.exp(-r), yp = ye * ap; return { ye, r, ap, yp }; };
    const meters = (g, col, x, y, w) => {
      const m = calc();
      meter(g, col, x, y, w, 'সাম্য NH₃', m.ye / 0.8, '#7b3fa0', fx(m.ye * 100, 1) + '%');
      meter(g, col, x, y + 30, w, 'বিক্রিয়ার হার (৪৫০ °C, ২০০ atm = ১)', Math.log10(1 + m.r / 3 * 9) / Math.log10(1 + 9 * 8), '#2e9d4e', m.r / 3 < 0.01 ? sci(m.r / 3).replace('\\times10^{', '×১০^').replace('}', '') : fx(m.r / 3, 2));
      meter(g, col, x, y + 60, w, 'এক পাসে প্রকৃত NH₃', m.yp / 0.4, '#d06a1e', fx(m.yp * 100, 1) + '%');
      meter(g, col, x, y + 90, w, 'সংকোচন খরচ', P / 400, '#e0402e', P <= 100 ? 'কম' : P <= 250 ? 'মাঝারি' : 'অনেক বেশি');
    };
    const drawPlant = (g, W, H, col) => {
      const fN = '#2d6fd6', fH = '#9aa3ad', fA = '#7b3fa0';
      if (wide(W)) {
        const s = W / 760;
        const U = (x, y, w, h, ti, sub, fill, sh) => unit(g, col, x * s, y * s, w * s, h * s, ti, sub, fill, sh);
        const p = a => a.map(([x, y]) => [x * s, y * s]);
        pipe(g, col, p([[100, 50], [140, 50], [140, 100]]), fN, t); pipe(g, col, p([[100, 160], [140, 160], [140, 130]]), fH, t);
        pipe(g, col, p([[170, 115], [215, 115]]), [fN, fH, fH, fH], t); pipe(g, col, p([[305, 115], [345, 115]]), [fN, fH, fH, fH], t);
        pipe(g, col, p([[415, 115], [450, 115], [450, 60], [480, 60]]), [fN, fH, fH, fH], t);
        pipe(g, col, p([[560, 230], [600, 230], [600, 180], [625, 180]]), [fN, fH, fA, fH], t);
        pipe(g, col, p([[675, 225], [675, 285]]), fA, t * 0.6);
        pipe(g, col, p([[650, 140], [650, 20], [260, 20], [260, 80]]), [fN, fH, fH, fH], t, 1, true);
        U(20, 30, 80, 40, 'N₂', 'বাতাস থেকে', '#dbe8fb'); U(20, 140, 80, 40, 'H₂', 'CH₄ + H₂O থেকে', '#eef0f3');
        U(110, 95, 60, 40, 'মিশ্রক', '১ : ৩');
        U(215, 80, 90, 70, 'কম্প্রেসর', '২০০ atm', '#e9e4f5');
        U(345, 85, 70, 60, 'তাপ\nবিনিময়ক', '');
        // reactor
        const rx = 480 * s, ry = 40 * s, rw = 80 * s, rh = 210 * s; unit(g, col, rx, ry, rw, rh, '', '', '#f3ece4', 'tower');
        for (let k = 0; k < 3; k++) { const by = ry + (34 + k * 60) * s, bh = 34 * s; g.fillStyle = '#6b6b6b'; g.fillRect(rx + 6 * s, by, rw - 12 * s, bh); g.fillStyle = '#9a9a9a'; for (let i = 0; i < 14; i++) { g.beginPath(); g.arc(rx + (12 + (i * 9.3) % 58) * s, by + (6 + (i * 7) % 24) * s, 2.4 * s, 0, 7); g.fill(); } }
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('রূপান্তরক', rx + rw / 2, ry - 8 * s); g.font = `9px ${col.font}`; g.fillStyle = col.mu; g.fillText('Fe প্রভাবক স্তর · ৪৫০ °C', rx + rw / 2, ry + rh + 14 * s);
        U(625, 140, 100, 85, 'শীতলীকরণ ও\nকনডেনসার', 'NH₃ তরল হয়', '#dff0f7');
        U(630, 285, 90, 40, 'তরল NH₃', 'ট্যাংক', '#ece2f5');
        g.fillStyle = col.acc; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('পুনঃচক্র: অবিক্রিত N₂ + H₂ (≈ ৮৫%)', 455 * s, 14 * s);
        g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('এক পাসে ~১৫% · পুনঃচক্রে মোট ~৯৮%', 420 * s, 290 * s);
        meters(g, col, 30, 230 * s + 30, Math.min(380, 420 * s));
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`নির্বাচিত শর্ত: ${bn(T)} °C, ${bn(P)} atm${cat ? ', Fe প্রভাবক' : ', প্রভাবক নেই'}`, 30, 230 * s + 10);
      } else {
        const s = W / 360;
        const U = (x, y, w, h, ti, sub, fill, sh) => unit(g, col, x * s, y * s, w * s, h * s, ti, sub, fill, sh);
        const p = a => a.map(([x, y]) => [x * s, y * s]);
        pipe(g, col, p([[60, 50], [60, 80], [120, 80], [120, 95]]), fN, t); pipe(g, col, p([[180, 50], [180, 80], [120, 80]]), fH, t);
        pipe(g, col, p([[120, 135], [120, 160]]), [fN, fH, fH, fH], t); pipe(g, col, p([[120, 215], [120, 240]]), [fN, fH, fH, fH], t);
        pipe(g, col, p([[160, 262], [215, 262]]), [fN, fH, fH, fH], t);
        pipe(g, col, p([[255, 340], [255, 360]]), [fN, fH, fA, fH], t);
        pipe(g, col, p([[255, 420], [255, 445]]), fA, t * 0.6);
        pipe(g, col, p([[300, 390], [340, 390], [340, 140], [175, 140], [175, 180], [165, 180]]), [fN, fH, fH, fH], t, 1, true);
        U(20, 15, 80, 35, 'N₂', 'বাতাস'); U(140, 15, 80, 35, 'H₂', 'CH₄ + H₂O');
        U(80, 95, 80, 40, 'মিশ্রক', '১ : ৩');
        U(75, 160, 90, 55, 'কম্প্রেসর', '২০০ atm', '#e9e4f5');
        U(80, 240, 80, 45, 'তাপ বিনিময়ক', '');
        const rx = 215 * s, ry = 205 * s, rw = 80 * s, rh = 135 * s; unit(g, col, rx, ry, rw, rh, '', '', '#f3ece4', 'tower');
        for (let k = 0; k < 3; k++) { const by = ry + (18 + k * 40) * s; g.fillStyle = '#6b6b6b'; g.fillRect(rx + 6 * s, by, rw - 12 * s, 24 * s); }
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('রূপান্তরক (Fe, ৪৫০ °C)', rx + rw / 2, ry - 6);
        U(205, 360, 95, 60, 'কনডেনসার', 'NH₃ তরল', '#dff0f7'); U(205, 445, 95, 35, 'তরল NH₃', '', '#ece2f5');
        g.fillStyle = col.acc; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('পুনঃচক্র (অবিক্রিত গ্যাস)', 258 * s, 133 * s);
        meters(g, col, 20, 505 * s + 12, W - 40);
      }
    };
    const drawGraph = (g, W, H, col) => {
      const gh = wide(W) ? H - 70 : H - 230, P1 = cplot(g, { x0: 52, y0: 20, w: W - 72, h: gh, xmin: 300, xmax: 600, ymax: 80, col, xt: [300, 350, 400, 450, 500, 550, 600], yt: [0, 20, 40, 60, 80], xl: 'তাপমাত্রা (°C)', yl: 'সাম্যে NH₃ (%)', ylx: 36 });
      g.fillStyle = 'rgba(46,157,78,.12)'; g.fillRect(P1.X(400), 20, P1.X(450) - P1.X(400), gh); g.fillStyle = '#2e9d4e'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText('শিল্প অবস্থা', P1.X(425), 32);
      const Ps = [50, 100, 200, 300, 400], cs = ['#9aa3ad', '#2d6fd6', '#7b3fa0', '#d06a1e', '#c0392b'];
      Ps.forEach((pp, i) => { const pts = []; for (let Tc = 300; Tc <= 600; Tc += 5) pts.push([P1.X(Tc), P1.Y(haberY(Tc, pp) * 100)]); path(g, pts, cs[i], pp === P ? 3.4 : 1.8); const lp = pts[Math.round(pts.length * 0.12)]; g.fillStyle = cs[i]; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'left'; g.fillText(`${bn(pp)} atm`, lp[0] + 4, lp[1] - 4); });
      if (!Ps.includes(P)) { const pts = []; for (let Tc = 300; Tc <= 600; Tc += 5) pts.push([P1.X(Tc), P1.Y(haberY(Tc, P) * 100)]); path(g, pts, col.acc, 2.6, [5, 3]); }
      const yv = haberY(T, P) * 100; g.strokeStyle = col.mu; g.setLineDash([3, 3]); g.lineWidth = 1; g.beginPath(); g.moveTo(P1.X(T), 20 + gh); g.lineTo(P1.X(T), P1.Y(yv)); g.lineTo(52, P1.Y(yv)); g.stroke(); g.setLineDash([]);
      ball(g, P1.X(T), P1.Y(yv), 6, '#c0392b', '#ffb3a8');
      g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText(`${fx(yv, 1)}%`, P1.X(T) + 9, P1.Y(yv) - 6);
      if (!wide(W)) meters(g, col, 20, gh + 80, W - 40);
    };
    const draw3d = (g, W, H, col) => {
      const hh = wide(W) ? H : H - 170;
      g.save(); g.beginPath(); g.rect(0, 0, W, hh); g.clip();
      surf3d(g, W, hh, v3, (u, v) => haberY(300 + u * 300, 25 + v * 375) / 0.8, 22, 18, heat, P3 => {
        const lab = (a, b, txt) => { const p = P3(...a), p2 = P3(...b); g.strokeStyle = col.fg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(p2[0], p2[1]); g.stroke(); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText(txt, p2[0] + (p2[0] - p[0]) * 0.12, p2[1] + (p2[1] - p[1]) * 0.12 + 4); };
        lab([-0.5, -0.5, -0.4], [0.62, -0.5, -0.4], 'T (৩০০→৬০০ °C)'); lab([-0.5, -0.5, -0.4], [-0.5, 0.64, -0.4], 'P (২৫→৪০০ atm)'); lab([-0.5, -0.5, -0.4], [-0.5, -0.5, 0.5], 'সাম্যে NH₃ (০→৮০%)');
      }, [(T - 300) / 300, (P - 25) / 375]);
      g.restore();
      g.fillStyle = col.mu; g.font = `10px ${col.font}`; g.textAlign = 'left'; g.fillText('টেনে ঘোরাও · লাল বিন্দু = নির্বাচিত T, P', 10, 14);
      if (!wide(W)) meters(g, col, 20, hh + 22, W - 40);
    };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); if (view === 'plant') drawPlant(g, W, H, col); else if (view === 'graph') drawGraph(g, W, H, col); else draw3d(g, W, H, col); };
    const info = () => {
      const m = calc();
      q('[data-tv]').textContent = bn(T); q('[data-pv]').textContent = bn(P);
      out.innerHTML = TXB(`\\ce{N2(g) + 3H2(g) <=>[\\text{Fe, 450 °C}][\\text{200 atm}] 2NH3(g)}`) + TXB(`\\Delta H = -92\\ \\mathrm{kJ\\,mol^{-1}},\\quad \\Delta n_g = 2 - 4 = -2`) +
        TXB(`\\text{সাম্যে NH}_3 = ${(m.ye * 100).toFixed(1)}\\%,\\quad \\text{এক পাসে প্রকৃত} = ${(m.yp * 100).toFixed(1)}\\%`) +
        `<div class="small">${T < 400 ? 'নিম্ন তাপমাত্রায় সাম্য উৎপাদন অনেক বেশি, কিন্তু হার এত ধীর যে নির্দিষ্ট সময়ে খুব কম NH₃ তৈরি হয়।' : T > 500 ? 'উচ্চ তাপমাত্রায় হার দ্রুত, সাম্যে পৌঁছায়, কিন্তু সাম্য বামে সরে যাওয়ায় NH₃ কম।' : 'আপস তাপমাত্রা: যুক্তিসংগত হার ও গ্রহণযোগ্য সাম্য উৎপাদন।'} ${P > 300 ? 'চাপ বেশি হলে উৎপাদন বাড়ে, কিন্তু পুরু ইস্পাতের পাত্র ও কম্প্রেসরের শক্তি খরচ অত্যধিক।' : P < 100 ? 'চাপ কম হলে সাম্য NH₃ কম।' : ''} ${cat ? '' : 'প্রভাবক ছাড়া এই তাপমাত্রায় বিক্রিয়া কার্যত হয় না — প্রভাবক সাম্য বদলায় না কিন্তু হার বহুগুণ বাড়ায়।'}</div>`;
    };
    const A = X.anim(el, dt => { if (dt) t += dt; draw(); }, { paused: false });
    X.onSeg(el, 'v', v => { view = v; A.draw(); });
    q('[data-t]').oninput = e => { T = +e.target.value; info(); A.draw(); };
    q('[data-p]').oninput = e => { P = +e.target.value; info(); A.draw(); };
    q('[data-cat]').onchange = e => { cat = e.target.checked; info(); A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};

/* ---------- Contact model: 10% SO2, 11% O2, 79% N2 ---------- */
const xeqSO3 = (Tc, P = 1) => {
  const T = Tc + 273.15, Kp = Math.pow(10, 5186 / T - 4.91), a = 0.10, b = 0.11;
  let lo = 0, hi = 1 - 1e-12; for (let i = 0; i < 60; i++) { const x = (lo + hi) / 2, nt = 1 - a * x / 2, qv = (a * x / nt) / ((a * (1 - x) / nt) * Math.sqrt(Math.max(1e-9, (b - a * x / 2) / nt * P))); if (qv < Kp) lo = x; else hi = x; }
  return (lo + hi) / 2;
};

/* ======================= ৪.৭ স্পর্শ পদ্ধতি ======================= */
V.c4_contact = {
  t: 'স্পর্শ পদ্ধতিতে সালফিউরিক এসিড: প্রবাহচিত্র ও চার-স্তর রূপান্তরকের রূপান্তর-তাপমাত্রা চিত্র', k: ['anim', 'int', '2d', 'calc'],
  cap: '"প্রবাহচিত্র" এ সালফার পুড়িয়ে SO₂, বিশুদ্ধকরণ (ধুলা ও As₂O₃ প্রভাবক-বিষ দূর) ও শুষ্ককরণ, তারপর V₂O₅ প্রভাবকের চারটি স্তরে ৪৫০ °C ও ১–২ atm এ SO₂ → SO₃; SO₃ সরাসরি পানিতে নয়, ৯৮% H₂SO₄ এ শোষিত হয়ে ওলিয়াম (H₂S₂O₇), পরে পানি মিশিয়ে H₂SO₄। "স্তরভিত্তিক রূপান্তর" চিত্রে নীল বক্ররেখা সাম্য রূপান্তর — তাপমাত্রা বাড়লে কমে (তাপোৎপাদী)। প্রতিটি স্তরে বিক্রিয়ার তাপে গ্যাস গরম হয় (লাল তির্যক রেখা) এবং সাম্য বক্ররেখার কাছে গিয়ে থামে; স্তরের মাঝে শীতলীকরণে (অনুভূমিক রেখা) তাপমাত্রা কমিয়ে আবার এগোনো যায় — লা-শাতেলিয়ারের নীতির সরাসরি প্রয়োগ। স্তর সংখ্যা ও প্রবেশ তাপমাত্রা বদলে চূড়ান্ত রূপান্তর দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('v', [['plant', 'প্রবাহচিত্র'], ['beds', 'স্তরভিত্তিক রূপান্তর']], 'plant')}</div>${X.cv('স্পর্শ পদ্ধতির প্রবাহচিত্র ও রূপান্তর-তাপমাত্রা চিত্র')}<div class="grid2" style="margin-top:8px"><label class="small">প্রতি স্তরে প্রবেশ তাপমাত্রা = <b data-tv></b> °C<input type="range" min="380" max="500" step="5" value="420" data-t></label><label class="small">প্রভাবক স্তরের সংখ্যা = <b data-nv></b><input type="range" min="1" max="4" step="1" value="4" data-n></label></div><div class="ctl"><button class="btn sm" data-rs>${X.ico('play')}আবার চালাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const c = el.querySelector('canvas'), out = el.querySelector('[data-out]'), q = s => el.querySelector(s);
    const hf = w => wide(w) ? Math.max(340, w * 0.5 + 40) : 560;
    let L = X.fit(c, hf), view = 'plant', Tin = 420, nb = 4, t = 0, prog = 0;
    const DTAD = 280;
    const beds = () => { const res = []; let x0 = 0; for (let k = 0; k < nb; k++) { let lo = x0, hi = 1; for (let i = 0; i < 50; i++) { const m = (lo + hi) / 2, Tm = Tin + DTAD * (m - x0); if (m < 0.97 * xeqSO3(Tm) + 0.03 * x0) lo = m; else hi = m; } const x1 = (lo + hi) / 2; res.push({ x0, x1, T1: Tin + DTAD * (x1 - x0) }); x0 = x1; } return res; };
    const drawPlant = (g, W, H, col) => {
      const fS = '#e2c24a', fO = '#d06a1e', fA = '#c0392b';
      if (wide(W)) {
        const s = W / 760, U = (x, y, w, h, ti, sub, fill, sh) => unit(g, col, x * s, y * s, w * s, h * s, ti, sub, fill, sh), p = a => a.map(([x, y]) => [x * s, y * s]);
        pipe(g, col, p([[100, 70], [130, 70]]), fS, t); pipe(g, col, p([[210, 70], [240, 70]]), fS, t); pipe(g, col, p([[320, 70], [350, 70]]), fS, t);
        pipe(g, col, p([[390, 100], [390, 140], [430, 140]]), fS, t);
        pipe(g, col, p([[520, 140], [560, 140], [560, 90], [590, 90]]), [fO, fA], t);
        pipe(g, col, p([[650, 150], [650, 200]]), '#8c3e14', t * 0.5); pipe(g, col, p([[650, 250], [650, 290]]), '#5b6bd6', t * 0.5);
        U(20, 45, 80, 50, 'সালফার চুল্লি', 'S + O₂ → SO₂', '#fbefc8');
        U(130, 45, 80, 50, 'বিশুদ্ধকারক', 'ধুলা, As₂O₃ দূর');
        U(240, 45, 80, 50, 'শুষ্ককারক', 'গাঢ় H₂SO₄', '#e6eef7');
        U(350, 40, 80, 60, 'তাপ বিনিময়ক', '৪২০ °C');
        // converter with 4 beds
        const rx = 430 * s, ry = 110 * s, rw = 90 * s, rh = 200 * s; unit(g, col, rx, ry - 70 * s, rw, rh, '', '', '#f3ece4', 'tower');
        for (let k = 0; k < 4; k++) { const by = ry - 70 * s + (16 + k * 46) * s; g.fillStyle = k < nb ? '#c98a2b' : col.s3; g.fillRect(rx + 6 * s, by, rw - 12 * s, 24 * s); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(k < nb ? `V₂O₅ স্তর ${bn(k + 1)}` : '—', rx + rw / 2, by + 15 * s); if (k < 3) { g.fillStyle = '#6fa8dc'; g.fillRect(rx + rw - 2, by + 30 * s, 14 * s, 8 * s); } }
        g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'center'; g.fillText('রূপান্তরক (৪৫০ °C, ১–২ atm)', rx + rw / 2, ry - 78 * s); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.fillText('নীল = স্তরের মাঝে শীতলীকরণ', rx + rw / 2, ry + rh - 56 * s);
        U(590, 40, 120, 110, 'শোষণ স্তম্ভ', '৯৮% H₂SO₄ এ SO₃', '#f5e3dc', 'tower');
        U(600, 200, 100, 50, 'ওলিয়াম', 'H₂S₂O₇', '#ecd6c8'); U(600, 290, 100, 50, 'লঘুকরণ', '+ H₂O → H₂SO₄', '#dde3f7');
        g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('অতিরিক্ত বাতাস (O₂) যোগ', 300 * s, 160 * s);
        const B = beds(), xf = B[B.length - 1].x1; meter(g, col, 30, 300 * s, 320 * s, `চূড়ান্ত SO₂ → SO₃ রূপান্তর (${bn(nb)} স্তর)`, xf, '#c0392b', fx(xf * 100, 1) + '%');
        const one = B[0].x1; meter(g, col, 30, 340 * s, 320 * s, 'শুধু প্রথম স্তরে রূপান্তর (তুলনা)', one, '#9aa3ad', fx(one * 100, 1) + '%');
      } else {
        const s = W / 360, U = (x, y, w, h, ti, sub, fill, sh) => unit(g, col, x * s, y * s, w * s, h * s, ti, sub, fill, sh), p = a => a.map(([x, y]) => [x * s, y * s]);
        pipe(g, col, p([[60, 55], [60, 75]]), fS, t); pipe(g, col, p([[100, 95], [140, 95]]), fS, t); pipe(g, col, p([[220, 95], [255, 95]]), fS, t);
        pipe(g, col, p([[295, 115], [295, 150], [210, 150], [210, 165]]), fS, t);
        pipe(g, col, p([[210, 375], [210, 395]]), [fO, fA], t);
        U(20, 15, 80, 40, 'সালফার চুল্লি', 'S + O₂ → SO₂', '#fbefc8'); U(20, 75, 80, 40, 'বিশুদ্ধকারক', '', ''); U(140, 75, 80, 40, 'শুষ্ককারক', 'গাঢ় H₂SO₄'); U(255, 75, 80, 40, 'তাপ বিনিময়ক', '');
        const rx = 160 * s, ry = 165 * s, rw = 100 * s, rh = 210 * s; unit(g, col, rx, ry, rw, rh, '', '', '#f3ece4', 'tower');
        for (let k = 0; k < 4; k++) { const by = ry + (16 + k * 48) * s; g.fillStyle = k < nb ? '#c98a2b' : col.s3; g.fillRect(rx + 6 * s, by, rw - 12 * s, 26 * s); g.fillStyle = col.fg; g.font = `9px ${col.font}`; g.textAlign = 'center'; g.fillText(k < nb ? `V₂O₅ স্তর ${bn(k + 1)}` : '—', rx + rw / 2, by + 16 * s); }
        g.fillStyle = col.fg; g.font = `bold 9.5px ${col.font}`; g.fillText('রূপান্তরক ৪৫০ °C', rx + rw / 2, ry - 4);
        U(120, 395, 180, 45, 'শোষণ স্তম্ভ → ওলিয়াম', '৯৮% H₂SO₄ এ SO₃ · পরে + H₂O', '#f5e3dc');
        const B = beds(), xf = B[B.length - 1].x1; meter(g, col, 20, 470 * s, W - 40, `চূড়ান্ত রূপান্তর (${bn(nb)} স্তর)`, xf, '#c0392b', fx(xf * 100, 1) + '%');
      }
    };
    const drawBeds = (g, W, H, col) => {
      const gh = wide(W) ? H - 70 : H - 140, P1 = cplot(g, { x0: 52, y0: 18, w: W - 72, h: gh, xmin: 380, xmax: 680, ymax: 1, col, xt: [400, 450, 500, 550, 600, 650], yt: [0, 0.25, 0.5, 0.75, 1], fy: v => bn(Math.round(v * 100)) + '%', xl: 'গ্যাসের তাপমাত্রা (°C)', yl: 'SO₂ → SO₃ রূপান্তর', ylx: 36 });
      g.fillStyle = 'rgba(224,64,46,.08)'; g.fillRect(52, 18, P1.X(400) - 52, gh); g.fillStyle = col.mu; g.font = `9px ${col.font}`; g.save(); g.translate(P1.X(390), 18 + gh / 2); g.rotate(-Math.PI / 2); g.textAlign = 'center'; g.fillText('V₂O₅ নিষ্ক্রিয় (হার অতি ধীর)', 0, 0); g.restore();
      const eq = []; for (let Tc = 380; Tc <= 680; Tc += 4) eq.push([P1.X(Tc), P1.Y(xeqSO3(Tc))]); path(g, eq, '#2d6fd6', 2.8);
      g.fillStyle = '#2d6fd6'; g.font = `bold 10px ${col.font}`; g.textAlign = 'right'; g.fillText('সাম্য রূপান্তর বক্ররেখা', P1.X(675), P1.Y(xeqSO3(660)) - 8);
      const B = beds(); let rem = prog; const tot = B.length * 2;
      B.forEach((b, k) => {
        const f1 = Math.max(0, Math.min(1, rem)); rem -= 1; const xa = b.x0 + (b.x1 - b.x0) * f1, Ta = Tin + DTAD * (xa - b.x0);
        if (f1 > 0) { path(g, [[P1.X(Tin), P1.Y(b.x0)], [P1.X(Ta), P1.Y(xa)]], '#c0392b', 2.6); if (f1 >= 1) { const ex = P1.X(b.T1), ey = P1.Y(b.x1); g.fillStyle = '#c0392b'; g.beginPath(); g.arc(ex + 9, ey + 11, 7.5, 0, 7); g.fill(); g.fillStyle = '#fff'; g.font = `bold 9.5px ${col.font}`; g.textAlign = 'center'; g.fillText(bn(k + 1), ex + 9, ey + 14.5); } }
        const f2 = Math.max(0, Math.min(1, rem)); rem -= 1;
        if (f2 > 0 && k < B.length - 1) { path(g, [[P1.X(b.T1), P1.Y(b.x1)], [P1.X(b.T1 - (b.T1 - Tin) * f2), P1.Y(b.x1)]], '#6fa8dc', 2.2, [5, 3]); }
        if (f1 > 0 && f1 < 1) ball(g, P1.X(Ta), P1.Y(xa), 5, '#c0392b', '#ffb3a8');
      });
      { const done = B.filter((b, k) => prog >= 2 * k + 1); const tx = W - 30 - 150, ty = 18 + gh - 22 - B.length * 16; g.fillStyle = col.sf; g.strokeStyle = col.line || col.mu; g.lineWidth = 1; g.fillRect(tx, ty, 150, 20 + B.length * 16); g.strokeRect(tx, ty, 150, 20 + B.length * 16); g.fillStyle = col.fg; g.font = `bold 10px ${col.font}`; g.textAlign = 'left'; g.fillText('স্তর শেষে রূপান্তর', tx + 8, ty + 14); g.font = `10px ${col.font}`; B.forEach((b, k) => { g.fillStyle = k < done.length ? col.fg : col.mu; g.fillText(`স্তর ${bn(k + 1)}: ${k < done.length ? fx(b.x1 * 100, 1) + '%' : '…'} (${bn(Math.round(b.T1))} °C)`, tx + 8, ty + 30 + k * 16); }); }
      g.fillStyle = col.mu; g.font = `9.5px ${col.font}`; g.textAlign = 'left'; g.fillText('লাল = স্তরে বিক্রিয়া (তাপে গরম হয়)  ·  নীল ড্যাশ = স্তরের মাঝে শীতলীকরণ', 56, 18 + gh + 42 > H - 4 ? H - 4 : 18 + gh + 42);
      return tot;
    };
    const draw = () => { const { g, W, H } = L, col = X.C(); g.clearRect(0, 0, W, H); if (view === 'plant') drawPlant(g, W, H, col); else drawBeds(g, W, H, col); };
    const info = () => {
      const B = beds(), xf = B[B.length - 1].x1;
      q('[data-tv]').textContent = bn(Tin); q('[data-nv]').textContent = bn(nb);
      out.innerHTML = TXB(`\\ce{2SO2(g) + O2(g) <=>[\\text{V}_2\\text{O}_5][\\text{450 °C, 1–2 atm}] 2SO3(g)}`) + TXB(`\\Delta H = -196\\ \\mathrm{kJ\\,mol^{-1}},\\quad \\Delta n_g = -1`) +
        TXB(`\\ce{SO3 + H2SO4 -> H2S2O7}\\qquad \\ce{H2S2O7 + H2O -> 2H2SO4}`) +
        `<div class="small">প্রবেশ ${bn(Tin)} °C, ${bn(nb)}টি স্তর: ${B.map((b, k) => `স্তর ${bn(k + 1)} শেষে ${fx(b.x1 * 100, 1)}%`).join(' → ')}। চূড়ান্ত রূপান্তর <b>${fx(xf * 100, 1)}%</b>। ${nb === 1 ? 'এক স্তরে তাপমাত্রা বেড়ে সাম্য বক্ররেখায় আটকে যায় — রূপান্তর সীমিত।' : 'স্তরের মাঝে ঠান্ডা করায় প্রতিবার সাম্য আবার ডানে সরে।'} বাস্তবে তৃতীয় স্তরের পর SO₃ শোষণ করে (দ্বৈত শোষণ, DCDA) মোট রূপান্তর ৯৯.৭% পর্যন্ত তোলা হয়।</div>`;
    };
    const A = X.anim(el, dt => { if (dt) { t += dt; if (view === 'beds') prog = Math.min(nb * 2, prog + dt * 0.9); } draw(); }, { paused: false });
    X.onSeg(el, 'v', v => { view = v; prog = 0; A.draw(); });
    q('[data-t]').oninput = e => { Tin = +e.target.value; prog = view === 'beds' ? 0 : prog; info(); A.draw(); };
    q('[data-n]').oninput = e => { nb = +e.target.value; prog = 0; info(); A.draw(); };
    q('[data-rs]').onclick = () => { prog = 0; A.draw(); };
    info(); draw();
    const un = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
    return () => { A.stop(); un(); };
  }
};
})();
