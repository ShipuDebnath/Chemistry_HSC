/* Chapter 3 visuals part 3 — bonding, VBT overlap, σ/π, hybridization, 3D shapes, VSEPR, coordinate bonds (3.7–3.14) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C3 = window.C3V;
const bn = X.bn, f1 = v => (+v).toFixed(1);
const INK = '#1b1b1f';

/* =====================================================================
   shared 3D ball-and-stick renderer (canvas)
   mol = { atoms:[[el,x,y,z]], bonds:[[i,j,order]], lps:[[i,dx,dy,dz]], ang:[[c,i,j,label]] }   (y = up)
   ===================================================================== */
const CPK = { H: '#EDEDED', C: '#4A4A4A', N: '#3B5BDB', O: '#E5383B', F: '#7BC74D', Cl: '#2BB24C', Br: '#A23B2A', I: '#7E3FA0', B: '#F0A58F', Be: '#B5D334', P: '#F08A24', S: '#E9C21D', Xe: '#3FA0B5', Al: '#A7A7C8', Si: '#C8A26A', Na: '#8E6FD6', Cu: '#D08A4A', M: '#C9A25C' };
const ARAD = { H: 0.2, C: 0.29, N: 0.28, O: 0.27, F: 0.26, B: 0.29, Be: 0.29, Cl: 0.34, Br: 0.36, I: 0.4, P: 0.35, S: 0.34, Xe: 0.4, Al: 0.36, Si: 0.35 };
const shade = (hex, k) => { const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255; const f = c => Math.max(0, Math.min(255, Math.round(k > 0 ? c + (255 - c) * k : c * (1 + k)))); return `rgb(${f(r)},${f(g)},${f(b)})`; };
C3.CPK = CPK;
C3.mol3d = (g, W, H, mol, yaw, pitch, o = {}) => {
  const C = X.C(), S = (o.scale || 1) * Math.min(W, H) * 0.34, cx = W / 2, cy = H / 2 + (o.dy || 0), Dd = 9;
  const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const P = (x, y, z) => { const x1 = x * cyw + z * syw, z1 = -x * syw + z * cyw; const y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp; const f = Dd / (Dd + z2); return [cx + x1 * S * f, cy - y2 * S * f, z2, f]; };
  g.clearRect(0, 0, W, H);
  const A = mol.atoms.map(([el, x, y, z]) => ({ el, p: P(x, y, z), v: [x, y, z] }));
  const items = [];
  A.forEach((a, i) => items.push({ z: a.p[2], t: 'a', i }));
  (mol.bonds || []).forEach((b, k) => { items.push({ z: A[b[0]].p[2] + 0.001, t: 'b', k, h: 0 }); items.push({ z: A[b[1]].p[2] + 0.001, t: 'b', k, h: 1 }); });
  if (o.lp !== false) (mol.lps || []).forEach((l, k) => items.push({ z: A[l[0]].p[2] + (l[1] * Math.sin(-yaw) * 0 + 0) + 0.01, t: 'l', k }));
  // depth for lone pairs: use the projected lobe centre
  items.forEach(it => { if (it.t === 'l') { const [i, dx, dy, dz] = mol.lps[it.k]; const a = A[i].v; it.z = P(a[0] + dx * 0.55, a[1] + dy * 0.55, a[2] + dz * 0.55)[2]; } });
  items.sort((p, q) => q.z - p.z);
  const rad = el => (ARAD[el] || 0.32) * (el === 'H' ? 0.92 : 0.8) * S;
  for (const it of items) {
    if (it.t === 'b') {
      const [i, j, ord] = mol.bonds[it.k], a = A[i], b = A[j];
      const dx = b.p[0] - a.p[0], dy = b.p[1] - a.p[1], L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L;
      const f = (a.p[3] + b.p[3]) / 2, w = (ord > 1 ? 0.075 : 0.11) * S * f;
      const offs = ord === 1 ? [0] : ord === 2 ? [-0.6, 0.6] : [-1.15, 0, 1.15];
      offs.forEach(k0 => {
        const ox = nx * k0 * w * 1.25, oy = ny * k0 * w * 1.25, mx = (a.p[0] + b.p[0]) / 2 + ox, my = (a.p[1] + b.p[1]) / 2 + oy;
        g.lineCap = 'round';
        [[a, mx, my], [b, mx, my]].filter((_, q) => q === it.h).forEach(([at, ex, ey]) => {
          g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = w + 1.6; g.beginPath(); g.moveTo(at.p[0] + ox, at.p[1] + oy); g.lineTo(ex, ey); g.stroke();
          g.strokeStyle = shade(CPK[at.el] || '#999', -0.1); g.lineWidth = w; g.beginPath(); g.moveTo(at.p[0] + ox, at.p[1] + oy); g.lineTo(ex, ey); g.stroke();
          g.strokeStyle = 'rgba(255,255,255,.28)'; g.lineWidth = w * 0.3; g.beginPath(); g.moveTo(at.p[0] + ox - nx * w * 0.18, at.p[1] + oy - ny * w * 0.18); g.lineTo(ex - nx * w * 0.18, ey - ny * w * 0.18); g.stroke();
        });
      });
    } else if (it.t === 'a') {
      const a = A[it.i], r = rad(a.el) * a.p[3], col = CPK[a.el] || '#999';
      const gr = g.createRadialGradient(a.p[0] - r * 0.38, a.p[1] - r * 0.42, r * 0.08, a.p[0], a.p[1], r);
      gr.addColorStop(0, shade(col, 0.75)); gr.addColorStop(0.45, col); gr.addColorStop(1, shade(col, -0.45));
      g.fillStyle = gr; g.beginPath(); g.arc(a.p[0], a.p[1], r, 0, 6.283); g.fill();
      g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 0.8; g.stroke();
      if (o.labels !== false && a.el !== 'H' && r > 9) { g.fillStyle = ['C', 'N', 'Br', 'I', 'Xe', 'Cl', 'O', 'P', 'Na'].includes(a.el) ? '#fff' : INK; g.font = `600 ${Math.round(r * 0.72)}px ${C.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(a.el, a.p[0], a.p[1] + 0.5); }
    } else {
      const [i, dx, dy, dz] = mol.lps[it.k], a = A[i].v;
      const c = P(a[0] + dx * 0.56, a[1] + dy * 0.56, a[2] + dz * 0.56), b = P(a[0] + dx * 0.22, a[1] + dy * 0.22, a[2] + dz * 0.22), t = P(a[0] + dx * 0.9, a[1] + dy * 0.9, a[2] + dz * 0.9);
      const ang = Math.atan2(t[1] - b[1], t[0] - b[0]), len = Math.hypot(t[0] - b[0], t[1] - b[1]);
      const rx = Math.max(len / 2, 0.16 * S * c[3]), ry = 0.17 * S * c[3];
      g.save(); g.translate(c[0], c[1]); g.rotate(ang);
      const lg = g.createRadialGradient(0, 0, 1, 0, 0, rx); lg.addColorStop(0, 'rgba(255,190,90,.55)'); lg.addColorStop(1, 'rgba(255,170,60,.18)');
      g.fillStyle = lg; g.beginPath(); g.ellipse(0, 0, rx, ry, 0, 0, 6.283); g.fill(); g.strokeStyle = 'rgba(214,130,30,.7)'; g.lineWidth = 1; g.stroke();
      g.fillStyle = '#B9650F'; const dd = Math.min(rx * 0.35, ry * 0.9); g.beginPath(); g.arc(-dd * 0.2, -ry * 0.35, 2, 0, 6.283); g.arc(-dd * 0.2, ry * 0.35, 2, 0, 6.283); g.fill();
      g.restore();
    }
  }
  if (o.ang !== false) (mol.ang || []).forEach(([c0, i, j, lab]) => {
    const c = A[c0].v, u = A[i].v.map((x, k) => x - c[k]), v = A[j].v.map((x, k) => x - c[k]);
    const nu = Math.hypot(...u), nv = Math.hypot(...v); const uu = u.map(x => x / nu), vv = v.map(x => x / nv);
    const th = Math.acos(Math.max(-1, Math.min(1, uu[0] * vv[0] + uu[1] * vv[1] + uu[2] * vv[2])));
    const R = 0.62, pts = [];
    if (th > 3.0) { const cc = P(...c), lt = P(c[0], c[1] + 0.62, c[2]); g.font = `600 12px ${C.font}`; g.textAlign = 'center'; g.textBaseline = 'middle'; const tw = g.measureText(lab).width + 8; g.fillStyle = C.sf || '#fff'; g.globalAlpha = 0.85; g.fillRect(lt[0] - tw / 2, lt[1] - 9, tw, 18); g.globalAlpha = 1; g.fillStyle = C.fg; g.fillText(lab, lt[0], lt[1]); return; }
    for (let k = 0; k <= 16; k++) { const t = k / 16, s1 = Math.sin((1 - t) * th) / Math.sin(th), s2 = Math.sin(t * th) / Math.sin(th); const d = uu.map((x, m) => x * s1 + vv[m] * s2); pts.push(P(c[0] + d[0] * R, c[1] + d[1] * R, c[2] + d[2] * R)); }
    g.strokeStyle = C.fg; g.lineWidth = 1.4; g.setLineDash([3, 2]); g.beginPath(); pts.forEach((p, k) => k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.stroke(); g.setLineDash([]);
    const m = pts[8], cc = P(...c); const lx = m[0] + (m[0] - cc[0]) * 0.42, ly = m[1] + (m[1] - cc[1]) * 0.42;
    g.font = `600 12px ${C.font}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    const tw = g.measureText(lab).width + 8; g.fillStyle = C.sf || '#fff'; g.globalAlpha = 0.85; g.fillRect(lx - tw / 2, ly - 9, tw, 18); g.globalAlpha = 1; g.fillStyle = C.fg; g.fillText(lab, lx, ly);
  });
};
/* geometry helpers */
const N3 = v => { const n = Math.hypot(...v); return v.map(x => x / n); };
const G = {
  lin: [[1, 0, 0], [-1, 0, 0]],
  tri: [[0, 1, 0], [-0.866, -0.5, 0], [0.866, -0.5, 0]],
  tet: [[0, 1, 0], [0.943, -0.333, 0], [-0.471, -0.333, 0.816], [-0.471, -0.333, -0.816]],
  tbp: [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-0.5, 0, 0.866], [-0.5, 0, -0.866]],
  oct: [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]
};
const pyr = deg => { const c = Math.cos(deg * Math.PI / 180), cf = Math.sqrt((c + 0.5) / 1.5), sf = Math.sqrt(1 - cf * cf); return [0, 1, 2].map(i => { const t = Math.PI / 2 + i * 2 * Math.PI / 3; return [sf * Math.cos(t), -cf, sf * Math.sin(t)]; }); };
const bent = deg => { const h = deg / 2 * Math.PI / 180; return [[Math.sin(h), -Math.cos(h), 0], [-Math.sin(h), -Math.cos(h), 0]]; };
/* build AXnEm: centre el, ligand list (el or [el,order,len]), vectors for ligands, vectors for lone pairs */
const axe = (cen, ligs, lv, lpv = [], ang) => {
  const atoms = [[cen, 0, 0, 0]], bonds = [];
  ligs.forEach((L, k) => { const [el, ord = 1] = Array.isArray(L) ? L : [L]; const len = el === 'H' ? 0.98 : 1.12; atoms.push([el, lv[k][0] * len, lv[k][1] * len, lv[k][2] * len]); bonds.push([0, k + 1, ord]); });
  return { atoms, bonds, lps: lpv.map(v => [0, ...v]), ang: ang || [[0, 1, 2]] };
};
const lab = (m, t) => { m.ang = m.ang.map(a => a.length === 4 ? a : [...a, t]); return m; };
const MOLS = {
  BeCl2: { n: 'BeCl₂ (বাষ্প)', m: () => lab(axe('Be', ['Cl', 'Cl'], G.lin), '180°'), axe: 'AX₂', eg: 'রৈখিক', sh: 'রৈখিক', hy: 'sp', an: '180°', mu: 'অপোলার (μ = 0)' },
  CO2: { n: 'CO₂', m: () => lab(axe('C', [['O', 2], ['O', 2]], G.lin), '180°'), axe: 'AX₂', eg: 'রৈখিক', sh: 'রৈখিক', hy: 'sp', an: '180°', mu: 'অপোলার (μ = 0)' },
  BF3: { n: 'BF₃', m: () => lab(axe('B', ['F', 'F', 'F'], G.tri), '120°'), axe: 'AX₃', eg: 'ত্রিকোণীয় সমতলীয়', sh: 'ত্রিকোণীয় সমতলীয়', hy: 'sp²', an: '120°', mu: 'অপোলার (μ = 0)' },
  SO2: { n: 'SO₂', m: () => lab(axe('S', [['O', 2], ['O', 2]], bent(119), [[0, 1, 0]], [[0, 1, 2]]), '119°'), axe: 'AX₂E', eg: 'ত্রিকোণীয় সমতলীয়', sh: 'কৌণিক (V)', hy: 'sp²', an: '119°', mu: 'পোলার (1.63 D)' },
  CH4: { n: 'CH₄', m: () => lab(axe('C', ['H', 'H', 'H', 'H'], G.tet, [], [[0, 2, 3]]), '109.5°'), axe: 'AX₄', eg: 'চতুস্তলকীয়', sh: 'চতুস্তলকীয়', hy: 'sp³', an: '109.5°', mu: 'অপোলার (μ = 0)' },
  NH4: { n: 'NH₄⁺', m: () => lab(axe('N', ['H', 'H', 'H', 'H'], G.tet, [], [[0, 2, 3]]), '109.5°'), axe: 'AX₄', eg: 'চতুস্তলকীয়', sh: 'চতুস্তলকীয়', hy: 'sp³', an: '109.5°', mu: 'আয়ন (প্রতিসম)' },
  NH3: { n: 'NH₃', m: () => lab(axe('N', ['H', 'H', 'H'], pyr(107), [[0, 1, 0]], [[0, 1, 2]]), '107°'), axe: 'AX₃E', eg: 'চতুস্তলকীয়', sh: 'ত্রিকোণীয় পিরামিড', hy: 'sp³', an: '107°', mu: 'পোলার (1.47 D)' },
  H2O: { n: 'H₂O', m: () => lab(axe('O', ['H', 'H'], bent(104.5), [[0, 0.537, 0.843], [0, 0.537, -0.843]], [[0, 1, 2]]), '104.5°'), axe: 'AX₂E₂', eg: 'চতুস্তলকীয়', sh: 'কৌণিক (V)', hy: 'sp³', an: '104.5°', mu: 'পোলার (1.85 D)' },
  PCl5: { n: 'PCl₅', m: () => { const m = axe('P', ['Cl', 'Cl', 'Cl', 'Cl', 'Cl'], G.tbp, [], [[0, 1, 3, '90°'], [0, 3, 4, '120°']]); return m; }, axe: 'AX₅', eg: 'ত্রিকোণীয় দ্বিপিরামিড', sh: 'ত্রিকোণীয় দ্বিপিরামিড', hy: 'sp³d', an: '90° (অক্ষীয়–নিরক্ষীয়) ও 120° (নিরক্ষীয়)', mu: 'অপোলার (μ = 0)' },
  SF4: { n: 'SF₄', m: () => axe('S', ['F', 'F', 'F', 'F'], [G.tbp[0], G.tbp[1], G.tbp[3], G.tbp[4]], [G.tbp[2]], [[0, 3, 4, '≈102°']]), axe: 'AX₄E', eg: 'ত্রিকোণীয় দ্বিপিরামিড', sh: 'দোলনা (see-saw)', hy: 'sp³d', an: '≈102° (নিরক্ষীয়), ≈173° (অক্ষীয়)', mu: 'পোলার' },
  ClF3: { n: 'ClF₃', m: () => axe('Cl', ['F', 'F', 'F'], [G.tbp[0], G.tbp[1], G.tbp[2]], [G.tbp[3], G.tbp[4]], [[0, 1, 3, '≈87.5°']]), axe: 'AX₃E₂', eg: 'ত্রিকোণীয় দ্বিপিরামিড', sh: 'T-আকৃতি', hy: 'sp³d', an: '≈87.5°', mu: 'পোলার' },
  XeF2: { n: 'XeF₂', m: () => axe('Xe', ['F', 'F'], [G.tbp[0], G.tbp[1]], [G.tbp[2], G.tbp[3], G.tbp[4]], [[0, 1, 2, '180°']]), axe: 'AX₂E₃', eg: 'ত্রিকোণীয় দ্বিপিরামিড', sh: 'রৈখিক', hy: 'sp³d', an: '180°', mu: 'অপোলার (μ = 0)' },
  SF6: { n: 'SF₆', m: () => axe('S', ['F', 'F', 'F', 'F', 'F', 'F'], G.oct, [], [[0, 1, 3, '90°']]), axe: 'AX₆', eg: 'অষ্টতলকীয়', sh: 'অষ্টতলকীয়', hy: 'sp³d²', an: '90°', mu: 'অপোলার (μ = 0)' },
  BrF5: { n: 'BrF₅', m: () => axe('Br', ['F', 'F', 'F', 'F', 'F'], [G.oct[0], G.oct[2], G.oct[3], G.oct[4], G.oct[5]], [G.oct[1]], [[0, 1, 2, '≈85°']]), axe: 'AX₅E', eg: 'অষ্টতলকীয়', sh: 'বর্গাকার পিরামিড', hy: 'sp³d²', an: '≈85°', mu: 'পোলার' },
  XeF4: { n: 'XeF₄', m: () => axe('Xe', ['F', 'F', 'F', 'F'], [G.oct[2], G.oct[3], G.oct[4], G.oct[5]], [G.oct[0], G.oct[1]], [[0, 1, 3, '90°']]), axe: 'AX₄E₂', eg: 'অষ্টতলকীয়', sh: 'বর্গাকার সমতলীয়', hy: 'sp³d²', an: '90°', mu: 'অপোলার (μ = 0)' },
  C2H4: { n: 'C₂H₄ (ইথিন)', m: () => { const c = 0.67, h = 0.82; const a = [['C', -c, 0, 0], ['C', c, 0, 0], ['H', -c - h * 0.5, h * 0.866, 0], ['H', -c - h * 0.5, -h * 0.866, 0], ['H', c + h * 0.5, h * 0.866, 0], ['H', c + h * 0.5, -h * 0.866, 0]]; return { atoms: a, bonds: [[0, 1, 2], [0, 2, 1], [0, 3, 1], [1, 4, 1], [1, 5, 1]], lps: [], ang: [[0, 2, 3, '≈117°']] }; }, axe: 'প্রতিটি C: AX₃', eg: 'ত্রিকোণীয় সমতলীয় (প্রতিটি C)', sh: 'সমতলীয় অণু', hy: 'sp² (প্রতিটি C)', an: '≈120° (H–C–H 117°)', mu: 'অপোলার (μ = 0)' },
  C2H2: { n: 'C₂H₂ (ইথাইন)', m: () => { const c = 0.6, h = 0.82; return { atoms: [['C', -c, 0, 0], ['C', c, 0, 0], ['H', -c - h, 0, 0], ['H', c + h, 0, 0]], bonds: [[0, 1, 3], [0, 2, 1], [1, 3, 1]], lps: [], ang: [] }; }, axe: 'প্রতিটি C: AX₂', eg: 'রৈখিক', sh: 'রৈখিক', hy: 'sp (প্রতিটি C)', an: '180°', mu: 'অপোলার (μ = 0)' },
  HCN: { n: 'HCN', m: () => ({ atoms: [['C', 0, 0, 0], ['H', -0.82, 0, 0], ['N', 1.0, 0, 0]], bonds: [[0, 1, 1], [0, 2, 3]], lps: [[2, 1, 0, 0]], ang: [] }), axe: 'AX₂', eg: 'রৈখিক', sh: 'রৈখিক', hy: 'sp', an: '180°', mu: 'পোলার (2.98 D)' }
};
C3.MOLS = MOLS; C3.axe = axe; C3.G = G; C3.pyr = pyr; C3.bent = bent;
/* mount a rotatable canvas; returns controller */
C3.view3d = (el, getMol, opts = {}) => {
  const c = el.querySelector('canvas'); const hf = W => Math.min(400, Math.max(250, W * 0.72)); let L = X.fit(c, hf);
  let yaw = opts.yaw != null ? opts.yaw : 0.55, pitch = opts.pitch != null ? opts.pitch : -0.2, mol = getMol();
  const st = { lp: true, ang: true };
  const dragging = X.drag(c, (dx, dy) => { yaw += dx * 0.011; pitch = Math.max(-1.45, Math.min(1.45, pitch + dy * 0.011)); A.draw(); });
  c.style.touchAction = 'none';
  const A = X.anim(c, dt => { if (!dragging() && opts.spin !== false) yaw += dt * 0.4; C3.mol3d(L.g, L.W, L.H, mol, yaw, pitch, { lp: st.lp, ang: st.ang, scale: opts.scale }); }, { paused: X.rm() });
  const ro = X.onResize(el, () => { L = X.fit(c, hf); A.draw(); });
  return { A, set(m) { mol = m; A.draw(); }, st, redraw: () => A.draw(), stop() { A.stop(); ro(); } };
};

/* ======================= ৩.৭ বন্ধন ত্রিভুজ (ভ্যান আর্কেল–কেটেলার) ======================= */
const BT = [
  ['Cs', 0.79, 0, 'ধাতব'], ['Na', 0.93, 0, 'ধাতব'], ['Mg', 1.31, 0, 'ধাতব'], ['Al', 1.61, 0, 'ধাতব'], ['Si', 1.90, 0, 'ধাতুকল্প (সমযোজী জালক)'], ['H₂', 2.20, 0, 'অপোলার সমযোজী'], ['Cl₂', 3.16, 0, 'অপোলার সমযোজী'], ['O₂', 3.44, 0, 'অপোলার সমযোজী'], ['F₂', 3.98, 0, 'অপোলার সমযোজী'],
  ['CsF', 2.385, 3.19, 'আয়নিক'], ['NaCl', 2.045, 2.23, 'আয়নিক'], ['KCl', 1.99, 2.34, 'আয়নিক'], ['MgO', 2.375, 2.13, 'আয়নিক'], ['MgCl₂', 2.235, 1.85, 'প্রধানত আয়নিক'], ['Al₂O₃', 2.525, 1.83, 'আয়নিক–সমযোজী সীমানায়'], ['AlCl₃', 2.385, 1.55, 'পোলার সমযোজী বৈশিষ্ট্য প্রবল'], ['BeCl₂', 2.365, 1.59, 'পোলার সমযোজী'],
  ['HF', 3.09, 1.78, 'পোলার সমযোজী'], ['H₂O', 2.82, 1.24, 'পোলার সমযোজী'], ['HCl', 2.68, 0.96, 'পোলার সমযোজী'], ['NH₃', 2.62, 0.84, 'পোলার সমযোজী'], ['CO₂', 3.0, 0.89, 'পোলার বন্ধন, অপোলার অণু'], ['CH₄', 2.375, 0.35, 'প্রায় অপোলার সমযোজী'], ['SiO₂', 2.67, 1.54, 'পোলার সমযোজী জালক']
];
V.c3_bondTypes = {
  t: 'বন্ধন ত্রিভুজ: তড়িৎ ঋণাত্মকতা থেকে আয়নিক, সমযোজী ও ধাতব বন্ধন', k: ['2d', 'int'],
  cap: 'অনুভূমিক অক্ষে দুই পরমাণুর গড় তড়িৎ ঋণাত্মকতা, উল্লম্ব অক্ষে তাদের পার্থক্য (ΔEN)। ত্রিভুজের তিন কোণ তিন চরম বন্ধন: নিচে-বামে ধাতব (Cs — দুজনেরই EN কম, ইলেকট্রন সহজে ছেড়ে দেয়), নিচে-ডানে অপোলার সমযোজী (F₂ — দুজনেরই EN বেশি, ইলেকট্রন শেয়ার করে), উপরে আয়নিক (CsF — একজন দেয়, অন্যজন নেয়)। যেকোনো বিন্দুতে চাপ দিলে পদার্থটির বন্ধন দেখাবে। অঞ্চলের সীমারেখাগুলো আনুমানিক — বাস্তবে বন্ধনের ধরন ধীরে ধীরে পরিবর্তিত হয়।',
  html: () => `<div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let sel = 10;
    const x0 = 44, x1 = 392, y0 = 230, y1 = 24, tx = v => x0 + (v - 0.7) / (4.0 - 0.7) * (x1 - x0), ty = v => y0 - v / 3.3 * (y0 - y1);
    const draw = () => {
      let s = '';
      const pL = [tx(0.79), ty(0)], pR = [tx(3.98), ty(0)], pT = [tx(2.385), ty(3.19)];
      const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
      const tI = 1.7 / 3.19, iL = lerp(pL, pT, tI), iR = lerp(pR, pT, tI); // ionic boundary at ΔEN 1.7
      const mB = [tx(2.0), ty(0)], mT = [tx(2.2), ty(1.7)]; // metallic/covalent boundary (approx)
      s += `<path d="M${f1(iL[0])} ${f1(iL[1])} L${f1(pT[0])} ${f1(pT[1])} L${f1(iR[0])} ${f1(iR[1])}Z" fill="#E5484D" opacity=".14"/>`;
      s += `<path d="M${f1(pL[0])} ${f1(pL[1])} L${f1(mB[0])} ${f1(mB[1])} L${f1(mT[0])} ${f1(mT[1])} L${f1(iL[0])} ${f1(iL[1])}Z" fill="#E9A53B" opacity=".16"/>`;
      s += `<path d="M${f1(mB[0])} ${f1(mB[1])} L${f1(pR[0])} ${f1(pR[1])} L${f1(iR[0])} ${f1(iR[1])} L${f1(mT[0])} ${f1(mT[1])}Z" fill="#5B9BD5" opacity=".14"/>`;
      s += `<path d="M${f1(pL[0])} ${f1(pL[1])} L${f1(pT[0])} ${f1(pT[1])} L${f1(pR[0])} ${f1(pR[1])}Z" fill="none" class="s-fg" stroke-width="1.6"/>`;
      s += `<line x1="${f1(iL[0])}" y1="${f1(iL[1])}" x2="${f1(iR[0])}" y2="${f1(iR[1])}" class="s-mu" stroke-dasharray="4 3"/><line x1="${f1(mB[0])}" y1="${f1(mB[1])}" x2="${f1(mT[0])}" y2="${f1(mT[1])}" class="s-mu" stroke-dasharray="4 3"/>`;
      s += `<text x="${f1(pT[0])}" y="${f1(ty(2.55))}" text-anchor="middle" style="font-size:13px;font-weight:700;fill:#C9373C">আয়নিক</text><text x="${f1(tx(1.25))}" y="${f1(ty(0.55))}" text-anchor="middle" style="font-size:13px;font-weight:700;fill:#B9790C">ধাতব</text><text x="${f1(tx(3.05))}" y="${f1(ty(0.55))}" text-anchor="middle" style="font-size:13px;font-weight:700;fill:#2F6FB5">সমযোজী</text>`;
      [0, 1, 2, 3].forEach(v => s += `<text x="${x0 - 5}" y="${f1(ty(v) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:10px">${v}</text>`);
      [1, 1.5, 2, 2.5, 3, 3.5, 4].forEach(v => s += `<text x="${f1(tx(v))}" y="${y0 + 14}" text-anchor="middle" class="tm mono" style="font-size:10px">${v}</text>`);
      s += `<text x="${x0}" y="${y1 - 8}" class="tm" style="font-size:10.5px">ΔEN (পার্থক্য)</text><text x="${x1}" y="${y0 + 28}" text-anchor="end" class="tm" style="font-size:10.5px">গড় তড়িৎ ঋণাত্মকতা →</text>`;
      BT.forEach(([n, a, d, k], i) => { const x = tx(a), y = ty(d), on = i === sel; s += `<g data-i="${i}" style="cursor:pointer"><circle cx="${f1(x)}" cy="${f1(y)}" r="${on ? 6.5 : 4.2}" class="${on ? 'f-fg' : 'f-acc'}" stroke="var(--surface)" stroke-width="1.2"/><circle cx="${f1(x)}" cy="${f1(y)}" r="12" fill="transparent"/></g>`; if (on || ['Cs', 'F₂', 'CsF', 'NaCl', 'HCl', 'H₂O', 'Cl₂', 'Mg', 'AlCl₃', 'CH₄'].includes(n)) s += `<text x="${f1(x + (d === 0 ? 0 : 8))}" y="${f1(d === 0 ? y - 8 : y + 4)}" text-anchor="${d === 0 ? 'middle' : 'start'}" style="font-size:${on ? 12 : 10.5}px;font-weight:${on ? 700 : 500}">${n}</text>`; });
      box.innerHTML = X.svg(400, 262, s, 'বন্ধন ত্রিভুজ');
      const [n, a, d, k] = BT[sel]; out.innerHTML = `<b>${n}</b> · গড় EN = ${a.toFixed(2)} · ΔEN = ${d.toFixed(2)} → <b>${k}</b>`;
    };
    box.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g) { sel = +g.dataset.i; draw(); } });
    draw();
  }
};

/* ======================= ৩.৮ যোজনী বন্ধন মতবাদ: অধিক্রমণ ======================= */
const lpLobe = (x, y, ang, L, w) => lobe(x, y, ang, L, w, 'lp');
const lobe = (x, y, ang, L, w, cls, sign) => { const c = Math.cos(ang), s = Math.sin(ang), ex = x + c * L, ey = y + s * L; const px = -s * w, py = c * w; return `<path d="M${f1(x)} ${f1(y)} C${f1(x + c * L * 0.25 + px)} ${f1(y + s * L * 0.25 + py)} ${f1(ex + px * 0.9)} ${f1(ey + py * 0.9)} ${f1(ex)} ${f1(ey)} C${f1(ex - px * 0.9)} ${f1(ey - py * 0.9)} ${f1(x + c * L * 0.25 - px)} ${f1(y + s * L * 0.25 - py)} ${f1(x)} ${f1(y)}Z" ${cls === 'lp' ? 'fill="rgba(255,175,70,.45)" stroke="rgba(214,130,30,.85)"' : `class="${cls}" opacity=".55"`} stroke-width="1"/>`; };
V.c3_overlap = {
  t: 'যোজনী বন্ধন মতবাদ: অরবিটাল অধিক্রমণ ও বন্ধন শক্তি', k: ['anim', 'int'],
  cap: '"H₂ গঠন" দৃশ্যে স্লাইডার দিয়ে দুটি H পরমাণুকে কাছে আনো (বা চালাও চাপো)। দূরে থাকলে আকর্ষণ নেই (শক্তি শূন্য)। কাছে আসলে 1s অরবিটাল অধিক্রমণ করে, দুই নিউক্লিয়াসের মাঝে ইলেকট্রন ঘনত্ব বাড়ে এবং শক্তি কমে। 74 pm দূরত্বে শক্তি সর্বনিম্ন (−436 kJ mol⁻¹) — এটিই বন্ধন দৈর্ঘ্য ও বন্ধন শক্তি। আরও কাছে আনলে নিউক্লিয়াস-নিউক্লিয়াস বিকর্ষণে শক্তি দ্রুত বাড়ে। "অধিক্রমণের ধরন" দৃশ্যে s-s, s-p, p-p (অক্ষীয়) ও p-p (পার্শ্বীয়) অধিক্রমণ।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['pes', 'H₂ গঠন'], ['types', 'অধিক্রমণের ধরন']], 'pes')}</div><div data-svg></div><div data-ctl></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), ctl = el.querySelector('[data-ctl]'), out = el.querySelector('[data-out]'); let raf = 0, mode = 'pes';
    const E = r => { const De = 436, a = 0.0195, re = 74; return De * (Math.pow(1 - Math.exp(-a * (r - re)), 2) - 1); }; // Morse, kJ/mol, r in pm
    const pes = r => {
      let s = '';
      // top: atoms
      const cx = 200, sc = 0.9, xA = cx - r * sc / 2, xB = cx + r * sc / 2, cy = 52, R = 34;
      s += `<defs><radialGradient id="c3s1"><stop offset="0" stop-color="#5B9BD5" stop-opacity=".55"/><stop offset="1" stop-color="#5B9BD5" stop-opacity="0"/></radialGradient></defs>`;
      s += `<circle cx="${f1(xA)}" cy="${cy}" r="${R}" fill="url(#c3s1)"/><circle cx="${f1(xB)}" cy="${cy}" r="${R}" fill="url(#c3s1)"/>`;
      if (r < 160) { const ov = Math.max(0, 1 - r / 150); s += `<ellipse cx="${cx}" cy="${cy}" rx="${f1(10 + 26 * ov)}" ry="${f1(14 + 14 * ov)}" fill="#2F6FB5" opacity="${(ov * 0.55).toFixed(2)}"/>`; }
      s += `<circle cx="${f1(xA)}" cy="${cy}" r="3.5" class="f-fg"/><circle cx="${f1(xB)}" cy="${cy}" r="3.5" class="f-fg"/><text x="${f1(xA)}" y="${cy - R - 4}" text-anchor="middle" style="font-size:12px;font-weight:600">H</text><text x="${f1(xB)}" y="${cy - R - 4}" text-anchor="middle" style="font-size:12px;font-weight:600">H</text>`;
      // bottom: energy curve
      const x0 = 50, x1 = 392, y0b = 250, yt = 110, rmin = 30, rmax = 300, Emin = -480, Emax = 200;
      const tx = v => x0 + (v - rmin) / (rmax - rmin) * (x1 - x0), ty = v => yt + (Emax - v) / (Emax - Emin) * (y0b - yt);
      s += `<line x1="${x0}" y1="${f1(ty(0))}" x2="${x1}" y2="${f1(ty(0))}" class="s-ln"/><line x1="${x0}" y1="${yt}" x2="${x0}" y2="${y0b}" class="s-ln"/>`;
      [-400, -200, 0, 200].forEach(v => s += `<text x="${x0 - 4}" y="${f1(ty(v) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:9.5px">${v}</text>`);
      [50, 100, 150, 200, 250, 300].forEach(v => s += `<text x="${f1(tx(v))}" y="${f1(ty(0) + 13)}" text-anchor="middle" class="tm mono" style="font-size:9.5px">${v}</text>`);
      s += `<text x="${x0 + 4}" y="${yt - 4}" class="tm" style="font-size:10px">শক্তি (kJ mol⁻¹)</text><text x="${x1}" y="${f1(ty(0) - 5)}" text-anchor="end" class="tm" style="font-size:10px">নিউক্লিয়াসের দূরত্ব r (pm)</text>`;
      let d = ''; for (let v = 42; v <= rmax; v += 2) { const e = Math.min(Emax, E(v)); d += (v > 42 ? 'L' : 'M') + f1(tx(v)) + ' ' + f1(ty(e)); }
      s += `<path d="${d}" fill="none" class="s-acc" stroke-width="2.4"/>`;
      s += `<line x1="${f1(tx(74))}" y1="${f1(ty(-436))}" x2="${f1(tx(74))}" y2="${f1(ty(0))}" class="s-mu" stroke-dasharray="3 3"/><text x="${f1(tx(74) + 5)}" y="${f1(ty(-436) + 14)}" style="font-size:10px" class="tm">74 pm, −436</text>`;
      const e = Math.min(Emax, E(r)); s += `<circle cx="${f1(tx(Math.max(42, r)))}" cy="${f1(ty(e))}" r="6" fill="#E5484D" stroke="var(--surface)" stroke-width="1.5"/>`;
      box.innerHTML = X.svg(400, 258, s, 'H₂ গঠন');
      const st = r > 220 ? 'পরমাণু দুটি অনেক দূরে — কোনো আকর্ষণ নেই।' : r > 90 ? 'অরবিটাল অধিক্রমণ শুরু — নিউক্লিয়াস ও শেয়ারকৃত ইলেকট্রনের আকর্ষণে শক্তি কমছে।' : r >= 66 ? '<b>বন্ধন দৈর্ঘ্যের কাছাকাছি</b> — সর্বোচ্চ কার্যকর অধিক্রমণ, শক্তি সর্বনিম্ন। H–H বন্ধন গঠিত (σ, s-s অধিক্রমণ)।' : 'অতিরিক্ত কাছে — নিউক্লিয়াস-নিউক্লিয়াস বিকর্ষণে শক্তি দ্রুত বাড়ছে।';
      out.innerHTML = `r = <b>${Math.round(r)} pm</b> · শক্তি = <b>${Math.round(e)} kJ mol⁻¹</b><br>${st}`;
    };
    const types = () => {
      let s = `<defs><radialGradient id="c3s2"><stop offset="0" stop-color="#5B9BD5" stop-opacity=".7"/><stop offset="1" stop-color="#5B9BD5" stop-opacity=".1"/></radialGradient></defs>`;
      const cell = (ox, oy, t, sub) => `<text x="${ox + 95}" y="${oy + 14}" text-anchor="middle" style="font-size:12px;font-weight:700">${t}</text><text x="${ox + 95}" y="${oy + 112}" text-anchor="middle" class="tm" style="font-size:10.5px">${sub}</text>`;
      // s-s
      s += cell(0, 0, 's–s (σ)', 'H₂: H(1s) + H(1s)') + `<circle cx="72" cy="62" r="26" fill="url(#c3s2)" stroke="#2F6FB5"/><circle cx="118" cy="62" r="26" fill="url(#c3s2)" stroke="#2F6FB5"/><circle cx="72" cy="62" r="2.5" class="f-fg"/><circle cx="118" cy="62" r="2.5" class="f-fg"/>`;
      // s-p
      s += cell(200, 0, 's–p (σ)', 'HCl: H(1s) + Cl(3p)') + `<circle cx="248" cy="62" r="24" fill="url(#c3s2)" stroke="#2F6FB5"/>` + lobe(300, 62, Math.PI, 40, 18, 'f-acc s-acc') + lobe(300, 62, 0, 44, 18, 'f-a2 s-a2') + `<circle cx="248" cy="62" r="2.5" class="f-fg"/><circle cx="300" cy="62" r="2.5" class="f-fg"/>`;
      // p-p axial
      s += cell(0, 128, 'p–p অক্ষীয় (σ)', 'Cl₂: Cl(3p) + Cl(3p)') + lobe(64, 190, Math.PI, 40, 17, 'f-a2 s-a2') + lobe(64, 190, 0, 38, 17, 'f-acc s-acc') + lobe(126, 190, Math.PI, 38, 17, 'f-acc s-acc') + lobe(126, 190, 0, 40, 17, 'f-a2 s-a2') + `<circle cx="64" cy="190" r="2.5" class="f-fg"/><circle cx="126" cy="190" r="2.5" class="f-fg"/>`;
      // p-p sideways
      s += cell(200, 128, 'p–p পার্শ্বীয় (π)', 'দুটি সমান্তরাল p অরবিটাল') + lobe(268, 190, -Math.PI / 2, 40, 15, 'f-acc s-acc') + lobe(268, 190, Math.PI / 2, 40, 15, 'f-a2 s-a2') + lobe(322, 190, -Math.PI / 2, 40, 15, 'f-acc s-acc') + lobe(322, 190, Math.PI / 2, 40, 15, 'f-a2 s-a2') + `<ellipse cx="295" cy="162" rx="22" ry="9" fill="#2F6FB5" opacity=".25"/><ellipse cx="295" cy="218" rx="22" ry="9" fill="#2F6FB5" opacity=".25"/><line x1="250" y1="190" x2="340" y2="190" class="s-mu" stroke-dasharray="3 3"/><circle cx="268" cy="190" r="2.5" class="f-fg"/><circle cx="322" cy="190" r="2.5" class="f-fg"/>`;
      s += `<line x1="200" y1="6" x2="200" y2="244" class="s-ln" stroke-dasharray="3 3"/><line x1="6" y1="124" x2="394" y2="124" class="s-ln" stroke-dasharray="3 3"/>`;
      box.innerHTML = X.svg(400, 248, s, 'অধিক্রমণের ধরন');
      out.innerHTML = '<b>σ (সিগমা) বন্ধন</b>: দুই নিউক্লিয়াসের সংযোগ অক্ষ বরাবর মুখোমুখি (head-on) অধিক্রমণ — s-s, s-p ও অক্ষীয় p-p; ইলেকট্রন ঘনত্ব অক্ষের উপর, অধিক্রমণ বেশি, বন্ধন শক্তিশালী, অক্ষের চারদিকে ঘূর্ণন সম্ভব।<br><b>π (পাই) বন্ধন</b>: দুটি সমান্তরাল p অরবিটালের পাশাপাশি অধিক্রমণ; ইলেকট্রন ঘনত্ব অক্ষের উপরে ও নিচে দুই খণ্ডে (নোডাল তল অক্ষ বরাবর), অধিক্রমণ কম, বন্ধন দুর্বল, ঘূর্ণন বাধাগ্রস্ত। রঙ দুটি তরঙ্গ ফাংশনের দশা (+/−) বোঝায় — বন্ধনের জন্য একই দশার খণ্ড অধিক্রমণ করে।';
    };
    let r = 220;
    const setMode = m => {
      mode = m; cancelAnimationFrame(raf);
      if (m === 'pes') {
        ctl.innerHTML = `<div class="ctl"><label style="flex:none">দূরত্ব</label><input type="range" min="45" max="300" value="${r}" data-r style="flex:1"><button class="btn sm" data-go>চালাও</button></div>`;
        const sl = ctl.querySelector('[data-r]'); sl.oninput = () => { cancelAnimationFrame(raf); r = +sl.value; pes(r); };
        ctl.querySelector('[data-go]').onclick = () => { cancelAnimationFrame(raf); r = 300; const t0 = performance.now(); const step = t => { const k = Math.min(1, (t - t0) / 2600); r = 300 - (300 - 74) * (1 - Math.pow(1 - k, 2.2)); sl.value = r; pes(r); if (k < 1) raf = requestAnimationFrame(step); }; if (X.rm()) { r = 74; sl.value = 74; pes(74); } else raf = requestAnimationFrame(step); };
        pes(r);
      } else { ctl.innerHTML = ''; types(); }
    };
    X.onSeg(el, 'm', setMode); setMode('pes');
    return () => cancelAnimationFrame(raf);
  }
};

/* ======================= ৩.৮.১ সিগমা ও পাই বন্ধন ======================= */
const SPM = {
  H2: { n: 'H₂', a: [['H', 120, 70], ['H', 280, 70]], b: [[0, 1, 1]] },
  Cl2: { n: 'Cl₂', a: [['Cl', 120, 70], ['Cl', 280, 70]], b: [[0, 1, 1]] },
  O2: { n: 'O₂', a: [['O', 130, 70], ['O', 270, 70]], b: [[0, 1, 2]] },
  N2: { n: 'N₂', a: [['N', 130, 70], ['N', 270, 70]], b: [[0, 1, 3]] },
  C2H4: { n: 'C₂H₄', a: [['C', 160, 70], ['C', 240, 70], ['H', 110, 30], ['H', 110, 110], ['H', 290, 30], ['H', 290, 110]], b: [[0, 1, 2], [0, 2, 1], [0, 3, 1], [1, 4, 1], [1, 5, 1]] },
  C2H2: { n: 'C₂H₂', a: [['C', 160, 70], ['C', 240, 70], ['H', 90, 70], ['H', 310, 70]], b: [[0, 1, 3], [0, 2, 1], [1, 3, 1]] },
  CO2: { n: 'CO₂', a: [['O', 110, 70], ['C', 200, 70], ['O', 290, 70]], b: [[0, 1, 2], [1, 2, 2]] },
  HCN: { n: 'HCN', a: [['H', 100, 70], ['C', 180, 70], ['N', 280, 70]], b: [[0, 1, 1], [1, 2, 3]] }
};
V.c3_sigmaPi = {
  t: 'সিগমা (σ) ও পাই (π) বন্ধন গণনা', k: ['2d', 'int'],
  cap: 'অণু বেছে নাও। গাঢ় রেখা = σ বন্ধন, রঙিন রেখা = π বন্ধন। নিয়ম: প্রতিটি একক বন্ধন = ১টি σ; দ্বিবন্ধন = ১σ + ১π; ত্রিবন্ধন = ১σ + ২π। দুই পরমাণুর মধ্যে প্রথম বন্ধনটি সবসময় σ, কারণ অক্ষ বরাবর অধিক্রমণ একবারই সম্ভব; বাকিগুলো পাশাপাশি অধিক্রমণে π। নিচের চিত্রে দ্বি ও ত্রিবন্ধনের অরবিটাল গঠন দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', Object.keys(SPM).map(k => [k, SPM[k].n]), 'C2H4')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = k => {
      const M = SPM[k]; let s = '', ns = 0, np = 0, maxo = 1;
      M.b.forEach(([i, j, o]) => {
        const [, x1, y1] = M.a[i], [, x2, y2] = M.a[j]; const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L, nx = -uy, ny = ux, r1 = 16, r2 = 16;
        const ax = x1 + ux * r1, ay = y1 + uy * r1, bx = x2 - ux * r2, by = y2 - uy * r2;
        ns++; np += o - 1; maxo = Math.max(maxo, o);
        s += `<line x1="${f1(ax)}" y1="${f1(ay)}" x2="${f1(bx)}" y2="${f1(by)}" class="s-fg" stroke-width="3"/>`;
        const offs = o === 2 ? [7] : o === 3 ? [7, -7] : [];
        offs.forEach(d => s += `<line x1="${f1(ax + nx * d)}" y1="${f1(ay + ny * d)}" x2="${f1(bx + nx * d)}" y2="${f1(by + ny * d)}" stroke="#E5484D" stroke-width="2.6" stroke-dasharray="${o === 3 && d < 0 ? '6 3' : ''}"/>`);
      });
      M.a.forEach(([e, x, y]) => s += `<circle cx="${x}" cy="${y}" r="15" fill="${CPK[e] || '#999'}" stroke="rgba(0,0,0,.3)"/><text x="${x}" y="${y + 5}" text-anchor="middle" style="font-size:14px;font-weight:700;fill:${['C', 'N', 'O', 'Cl'].includes(e) ? '#fff' : INK}">${e}</text>`);
      // orbital picture of the highest-order bond
      const oy = 178, cx = 200;
      if (maxo === 1) {
        s += lobe(cx - 30, oy, Math.PI, 34, 14, 'f-acc s-acc') + lobe(cx + 30, oy, 0, 34, 14, 'f-acc s-acc') + `<ellipse cx="${cx}" cy="${oy}" rx="34" ry="14" fill="#2F6FB5" opacity=".45"/><circle cx="${cx - 30}" cy="${oy}" r="3" class="f-fg"/><circle cx="${cx + 30}" cy="${oy}" r="3" class="f-fg"/><text x="${cx}" y="${oy + 44}" text-anchor="middle" class="tm" style="font-size:10.5px">একক বন্ধন: শুধু σ — অক্ষ বরাবর ইলেকট্রন ঘনত্ব</text>`;
      } else {
        s += `<ellipse cx="${cx}" cy="${oy}" rx="40" ry="10" fill="#2F6FB5" opacity=".55"/>`;
        [-40, 40].forEach(dx => s += lobe(cx + dx, oy, -Math.PI / 2, 34, 12, 'f-a2 s-a2') + lobe(cx + dx, oy, Math.PI / 2, 34, 12, 'f-a2 s-a2'));
        s += `<path d="M${cx - 44} ${oy - 26} Q${cx} ${oy - 44} ${cx + 44} ${oy - 26} Q${cx} ${oy - 18} ${cx - 44} ${oy - 26}Z" fill="#E5484D" opacity=".35"/><path d="M${cx - 44} ${oy + 26} Q${cx} ${oy + 44} ${cx + 44} ${oy + 26} Q${cx} ${oy + 18} ${cx - 44} ${oy + 26}Z" fill="#E5484D" opacity=".35"/>`;
        if (maxo === 3) s += `<ellipse cx="${cx - 40}" cy="${oy}" rx="13" ry="30" fill="none" stroke="#E5484D" stroke-dasharray="3 2" opacity=".8" transform="rotate(70 ${cx - 40} ${oy})"/><ellipse cx="${cx + 40}" cy="${oy}" rx="13" ry="30" fill="none" stroke="#E5484D" stroke-dasharray="3 2" opacity=".8" transform="rotate(70 ${cx + 40} ${oy})"/><path d="M${cx - 28} ${oy + 16} Q${cx} ${oy + 30} ${cx + 52} ${oy + 12}" fill="none" stroke="#E5484D" stroke-dasharray="3 2"/>`;
        s += `<circle cx="${cx - 40}" cy="${oy}" r="3" class="f-fg"/><circle cx="${cx + 40}" cy="${oy}" r="3" class="f-fg"/><text x="${cx}" y="${oy + 60}" text-anchor="middle" class="tm" style="font-size:10.5px">${maxo === 2 ? 'দ্বিবন্ধন: ১σ (নীল, অক্ষ বরাবর) + ১π (লাল, উপরে ও নিচে)' : 'ত্রিবন্ধন: ১σ + ২π (দুটি π পরস্পর লম্ব তলে; দ্বিতীয়টি ড্যাশ)'}</text>`;
      }
      const ly = maxo === 1 ? 246 : 262;
      s += `<line x1="110" y1="${ly}" x2="134" y2="${ly}" class="s-fg" stroke-width="3"/><text x="140" y="${ly + 4}" style="font-size:11px">σ বন্ধন</text><line x1="210" y1="${ly}" x2="234" y2="${ly}" stroke="#E5484D" stroke-width="2.6"/><text x="240" y="${ly + 4}" style="font-size:11px">π বন্ধন</text><line x1="10" y1="128" x2="390" y2="128" class="s-ln" stroke-dasharray="2 3"/><text x="10" y="144" class="tm" style="font-size:10px">অরবিটাল চিত্র</text>`;
      box.innerHTML = X.svg(400, ly + 10, s, 'সিগমা পাই');
      out.innerHTML = `<b>${M.n}</b>: মোট বন্ধন ${bn(ns + np)} = <b>${bn(ns)}টি σ</b> + <b>${bn(np)}টি π</b>${k === 'O2' ? '<br><span class="small">(VBT চিত্র; O₂ এর প্যারাচৌম্বকত্ব ব্যাখ্যায় আণবিক অরবিটাল মতবাদ লাগে।)</span>' : ''}`;
    };
    X.onSeg(el, 'm', draw); draw('C2H4');
  }
};

/* ======================= ৩.৯ সংকরণ: শক্তিস্তর চিত্র ======================= */
const HYB = {
  sp3: { at: 'C', ex: 'CH₄', g: { s: 2, p: [1, 1, 0] }, e: { s: 1, p: [1, 1, 1] }, n: 4, left: 0, lp: 0, geo: 'চতুস্তলকীয়, 109.5°', note: 'একটি 2s ও তিনটি 2p মিশে চারটি সমশক্তির sp³ অরবিটাল (২৫% s, ৭৫% p)। প্রতিটি H এর 1s এর সাথে σ বন্ধন।' },
  sp2: { at: 'C', ex: 'C₂H₄', g: { s: 2, p: [1, 1, 0] }, e: { s: 1, p: [1, 1, 1] }, n: 3, left: 1, lp: 0, geo: 'ত্রিকোণীয় সমতলীয়, 120°', note: 'একটি 2s ও দুটি 2p মিশে তিনটি sp² (৩৩% s)। অসংকরিত একটি 2p অরবিটাল তলের লম্বভাবে থাকে এবং পাশের C এর সাথে π বন্ধন গঠন করে।' },
  sp: { at: 'C', ex: 'C₂H₂', g: { s: 2, p: [1, 1, 0] }, e: { s: 1, p: [1, 1, 1] }, n: 2, left: 2, lp: 0, geo: 'রৈখিক, 180°', note: 'একটি 2s ও একটি 2p মিশে দুটি sp (৫০% s)। অসংকরিত দুটি 2p দুটি π বন্ধন গঠন করে — ত্রিবন্ধন।' },
  Bsp2: { at: 'B', ex: 'BF₃', g: { s: 2, p: [1, 0, 0] }, e: { s: 1, p: [1, 1, 0] }, n: 3, left: 1, lp: 0, empty: true, geo: 'ত্রিকোণীয় সমতলীয়, 120°', note: 'B: 2s² 2p¹ → উত্তেজিত 2s¹ 2p² → তিনটি sp²। একটি খালি 2p থাকে — তাই BF₃ ইলেকট্রন-ঘাটতি, লুইস এসিড।' },
  Besp: { at: 'Be', ex: 'BeCl₂', g: { s: 2, p: [0, 0, 0] }, e: { s: 1, p: [1, 0, 0] }, n: 2, left: 2, lp: 0, empty: true, geo: 'রৈখিক, 180°', note: 'Be: 2s² → উত্তেজিত 2s¹ 2p¹ → দুটি sp; দুটি 2p খালি থাকে।' },
  Nsp3: { at: 'N', ex: 'NH₃', g: { s: 2, p: [1, 1, 1] }, e: null, n: 4, left: 0, lp: 1, geo: 'চতুস্তলকীয় সজ্জা → পিরামিড, 107°', note: 'N: 2s² 2p³ — উত্তেজনা লাগে না। চারটি sp³ এর একটিতে নিঃসঙ্গ যুগল, তিনটিতে একটি করে ইলেকট্রন — তিনটি N–H σ বন্ধন।' },
  Osp3: { at: 'O', ex: 'H₂O', g: { s: 2, p: [2, 1, 1] }, e: null, n: 4, left: 0, lp: 2, geo: 'চতুস্তলকীয় সজ্জা → কৌণিক, 104.5°', note: 'O: 2s² 2p⁴ — চারটি sp³ এর দুটিতে নিঃসঙ্গ যুগল, দুটিতে একক ইলেকট্রন — দুটি O–H বন্ধন।' }
};
V.c3_hybrid = {
  t: 'সংকরণের ধাপ: ভূমি অবস্থা → উত্তেজিত অবস্থা → সংকর অরবিটাল', k: ['anim', 'int'],
  cap: 'সংকরণের ধরন বেছে নিয়ে "পরের ধাপ" চাপো। ধাপ ১: ভূমি অবস্থার বিন্যাস। ধাপ ২: একটি 2s ইলেকট্রন খালি 2p তে উন্নীত হয় (প্রয়োজন হলে) — এতে অযুগ্ম ইলেকট্রন বাড়ে, ফলে বেশি বন্ধন গঠন করে উন্নীত করার শক্তির চেয়ে বেশি শক্তি ফেরত পাওয়া যায়। ধাপ ৩: অংশগ্রহণকারী অরবিটালগুলো মিশে সমান শক্তি ও আকৃতির সংকর অরবিটাল তৈরি করে (মাঝামাঝি শক্তিস্তরে)। কমলা বাক্স নিঃসঙ্গ যুগল, ধূসর বাক্স অসংকরিত p অরবিটাল। নিচে সংকর অরবিটালগুলোর জ্যামিতিক সজ্জা।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('h', [['sp3', 'C: sp³'], ['sp2', 'C: sp²'], ['sp', 'C: sp'], ['Bsp2', 'B: sp²'], ['Besp', 'Be: sp'], ['Nsp3', 'N: sp³'], ['Osp3', 'O: sp³']], 'sp3')}</div><div data-svg></div><div class="ctl"><button class="btn sm" data-prev>← আগের ধাপ</button><button class="btn sm primary" data-next>পরের ধাপ →</button><span class="small muted" data-step></span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), stp = el.querySelector('[data-step]'); let key = 'sp3', step = 3;
    const bx = (x, y, e, cls, w = 24) => { let t = `<rect x="${x}" y="${y}" width="${w}" height="24" rx="2" ${cls === 'lpbox' ? 'fill="rgba(255,175,70,.45)"' : `class="${cls || 'f-sf'}"`} stroke="var(--fg)" stroke-width="1.3"/>`; if (e >= 1) t += `<text x="${x + w / 2 - (e === 2 ? 5 : 0)}" y="${y + 18}" text-anchor="middle" style="font-size:16px;font-weight:700">↑</text>`; if (e >= 2) t += `<text x="${x + w / 2 + 5}" y="${y + 18}" text-anchor="middle" style="font-size:16px;font-weight:700">↓</text>`; return t; };
    const draw = () => {
      const H = HYB[key], hasEx = !!H.e; const maxStep = hasEx ? 3 : 2; step = Math.min(step, maxStep);
      let s = `<defs>${X.arrow('c3hy')}</defs>`;
      const col = (cx, label, conf, kind) => {
        let t = `<text x="${cx}" y="16" text-anchor="middle" style="font-size:11.5px;font-weight:700">${label}</text>`;
        if (kind === 'h') {
          const n = H.n, w = 22, tot = n * w, sx = cx - tot / 2 - (H.left ? 14 : 0);
          // electrons in hybrids: lone pairs first
          const nel = H.at === 'N' ? 5 : H.at === 'O' ? 6 : H.at === 'C' ? 4 : H.at === 'B' ? 3 : 2;
          const pel = H.left && !H.empty ? H.left : 0; let he = nel - pel; const arr = [];
          for (let i = 0; i < n; i++) arr.push(0); for (let i = 0; i < H.lp; i++) arr[i] = 2; he -= 2 * H.lp; for (let i = H.lp; i < n && he > 0; i++) { arr[i] = 1; he--; }
          arr.forEach((e, i) => t += bx(sx + i * w, 92, e, i < H.lp ? 'lpbox' : 'f-a2s', w));
          t += `<text x="${sx + tot / 2}" y="132" text-anchor="middle" class="mono" style="font-size:11px;font-weight:600">${n} × ${{ 4: 'sp³', 3: 'sp²', 2: 'sp' }[n]}</text>`;
          if (H.left) { for (let i = 0; i < H.left; i++) t += bx(sx + tot + 8 + i * w, 52, H.empty ? 0 : 1, 'f-s3', w); t += `<text x="${sx + tot + 8 + H.left * w / 2}" y="46" text-anchor="middle" class="mono tm" style="font-size:10.5px">2p (অসংকরিত)</text>`; }
          return t;
        }
        const sx = cx - 50;
        t += bx(sx, 130, conf.s) + `<text x="${sx + 12}" y="168" text-anchor="middle" class="mono tm" style="font-size:10.5px">2s</text>`;
        conf.p.forEach((e, i) => t += bx(sx + 34 + i * 24, 52, e));
        t += `<text x="${sx + 70}" y="46" text-anchor="middle" class="mono tm" style="font-size:10.5px">2p</text>`;
        return t;
      };
      const xs = hasEx ? [72, 200, 328] : [100, 300];
      s += col(xs[0], 'ভূমি অবস্থা', H.g, 'g');
      if (hasEx && step >= 2) s += col(xs[1], 'উত্তেজিত অবস্থা', H.e, 'e') + `<path d="M${xs[1] - 38} 128 Q${xs[1] - 30} 92 ${xs[1] + 26} 80" fill="none" stroke="#E5484D" stroke-width="1.6" stroke-dasharray="4 3" marker-end="url(#c3hy)"/>`;
      if (step >= maxStep) s += col(xs[xs.length - 1], 'সংকরিত অবস্থা', null, 'h');
      s += `<line x1="8" y1="176" x2="8" y2="30" class="s-mu" marker-end="url(#c3hy)"/><text x="12" y="34" class="tm" style="font-size:9.5px">শক্তি</text>`;
      // geometry sketch
      const gy = 236, gx = 200, nh = HYB[key].n, angs = nh === 4 ? [-90, 28, 152, 98] : nh === 3 ? [-90, 30, 150] : [0, 180];
      s += `<line x1="0" y1="186" x2="400" y2="186" class="s-ln" stroke-dasharray="2 3"/>`;
      if (H.left === 2) { s += `<g opacity=".7">` + lobe(gx, gy, -Math.PI / 2, 34, 11, 'f-none s-mu') + lobe(gx, gy, Math.PI / 2, 34, 11, 'f-none s-mu') + `</g>`; }
      if (H.left) s += `<circle cx="${gx}" cy="${gy}" r="16" fill="none" class="s-mu" stroke-dasharray="3 2"/><text x="${gx}" y="${gy + 50}" text-anchor="middle" class="tm" style="font-size:9.5px">ড্যাশ: অসংকরিত 2p (${H.left === 2 ? 'একটি উপর-নিচে, একটি তলের লম্বভাবে' : 'তলের লম্বভাবে'})</text>`;
      angs.slice().sort((a, b) => (a === 98 ? -1 : b === 98 ? 1 : 0)).forEach(a => { const i = angs.indexOf(a), r = a * Math.PI / 180, isLp = i < H.lp, back = nh === 4 && a === 98; s += `<g opacity="${back ? 0.6 : 1}">` + lobe(gx, gy, r + Math.PI, 11, 6, 'f-s3 s-mu') + lobe(gx, gy, r, back ? 28 : 44, 13, isLp ? 'lp' : 'f-a2 s-a2') + '</g>'; });
      s += `<circle cx="${gx}" cy="${gy}" r="5" class="f-fg"/><text x="${gx - 70}" y="${gy - 4}" text-anchor="end" style="font-size:12px;font-weight:700">${H.ex}</text><text x="${gx - 70}" y="${gy + 12}" text-anchor="end" class="tm" style="font-size:10px">${H.at} পরমাণু</text><text x="${gx + 62}" y="${gy - 4}" style="font-size:10.5px">${H.geo.split(' → ')[0].split(', ')[0]}</text><text x="${gx + 62}" y="${gy + 12}" style="font-size:10.5px;font-weight:600">${H.geo.includes('→') ? H.geo.split(' → ')[1] : H.geo.split(', ')[1]}</text>`;
      box.innerHTML = X.svg(400, 292, s, 'সংকরণ');
      stp.textContent = `ধাপ ${bn(step)}/${bn(maxStep)}`;
      out.innerHTML = step < maxStep ? (step === 1 ? `${H.at} এর ভূমি অবস্থার বিন্যাস। অযুগ্ম ইলেকট্রন: ${bn(H.g.p.filter(x => x === 1).length + (H.g.s === 1 ? 1 : 0))}টি।` : `একটি 2s ইলেকট্রন 2p তে উন্নীত — এখন ${bn(H.e.p.filter(x => x === 1).length + 1)}টি অযুগ্ম ইলেকট্রন।`) : H.note;
    };
    X.onSeg(el, 'h', k => { key = k; step = 1; draw(); });
    el.querySelector('[data-next]').onclick = () => { step++; draw(); };
    el.querySelector('[data-prev]').onclick = () => { step = Math.max(1, step - 1); draw(); };
    draw();
  }
};

/* ======================= ৩D আণবিক আকৃতি ======================= */
const SH_ORDER = ['BeCl2', 'CO2', 'BF3', 'SO2', 'CH4', 'NH3', 'H2O', 'NH4', 'PCl5', 'SF4', 'ClF3', 'XeF2', 'SF6', 'BrF5', 'XeF4', 'C2H4', 'C2H2', 'HCN'];
V.c3_shapes3d = {
  t: '৩D আণবিক আকৃতি: বল-কাঠি মডেল (টেনে ঘোরাও)', k: ['3d', 'int'],
  cap: 'যেকোনো অণু বেছে নাও এবং আঙুল দিয়ে টেনে চারদিকে ঘুরিয়ে দেখো। পরমাণুর রং প্রচলিত CPK রীতিতে (C কালচে, H সাদা, O লাল, N নীল, F/Cl সবুজ, S হলুদ, P কমলা)। কমলা স্বচ্ছ খণ্ডগুলো নিঃসঙ্গ ইলেকট্রন যুগল — এরা জায়গা নেয় কিন্তু "আকৃতি" বলতে শুধু পরমাণুগুলোর অবস্থান বোঝায়। তাই NH₃ এর যুগল সজ্জা চতুস্তলকীয় হলেও আকৃতি পিরামিড, H₂O এর কৌণিক। ড্যাশ বৃত্তচাপ ও সংখ্যা বন্ধন কোণ। দ্বিবন্ধন দুটি ও ত্রিবন্ধন তিনটি কাঠিতে দেখানো হয়েছে।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><select class="inp" data-m style="flex:1">${SH_ORDER.map(k => `<option value="${k}" ${k === 'NH3' ? 'selected' : ''}>${MOLS[k].n} — ${MOLS[k].sh}</option>`).join('')}</select></div>` + X.cv('৩D অণু') + `<div class="ctl"><button class="btn sm" data-pp></button><button class="btn sm primary" data-lp>নিঃসঙ্গ যুগল</button><button class="btn sm primary" data-an>বন্ধন কোণ</button><span class="small muted">টেনে ঘোরাও</span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const sel = el.querySelector('[data-m]'), out = el.querySelector('[data-out]');
    const vw = C3.view3d(el, () => MOLS.NH3.m());
    X.pp(el, vw.A);
    const info = k => { const M = MOLS[k]; out.innerHTML = `<b>${M.n}</b> · ${M.axe}<br>ইলেকট্রন যুগলের সজ্জা: <b>${M.eg}</b><br>আণবিক আকৃতি: <b>${M.sh}</b> · সংকরণ: <b>${M.hy}</b><br>বন্ধন কোণ: <b>${M.an}</b> · ${M.mu}`; };
    sel.onchange = () => { vw.set(MOLS[sel.value].m()); info(sel.value); };
    const tg = (b, key) => b.onclick = () => { vw.st[key] = !vw.st[key]; b.classList.toggle('primary', vw.st[key]); vw.redraw(); };
    tg(el.querySelector('[data-lp]'), 'lp'); tg(el.querySelector('[data-an]'), 'ang');
    info('NH3');
    return () => vw.stop();
  }
};

/* ======================= ৩.১০.১ সংকরণ নির্ণয়: H = ½(V + M − C + A) ======================= */
const HC = [
  // [label, central, V, M, C, A, attached atoms, mol key for 3D or null]
  ['CH₄', 'C', 4, 4, 0, 0, 4, 'CH4'], ['NH₃', 'N', 5, 3, 0, 0, 3, 'NH3'], ['H₂O', 'O', 6, 2, 0, 0, 2, 'H2O'], ['BF₃', 'B', 3, 3, 0, 0, 3, 'BF3'], ['BeCl₂', 'Be', 2, 2, 0, 0, 2, 'BeCl2'],
  ['CO₂', 'C', 4, 0, 0, 0, 2, 'CO2'], ['SO₂', 'S', 6, 0, 0, 0, 2, 'SO2'], ['NH₄⁺', 'N', 5, 4, 1, 0, 4, 'NH4'], ['H₃O⁺', 'O', 6, 3, 1, 0, 3, null], ['CO₃²⁻', 'C', 4, 0, 0, 2, 3, null], ['NO₃⁻', 'N', 5, 0, 0, 1, 3, null], ['SO₄²⁻', 'S', 6, 0, 0, 2, 4, null],
  ['PCl₅', 'P', 5, 5, 0, 0, 5, 'PCl5'], ['SF₄', 'S', 6, 4, 0, 0, 4, 'SF4'], ['ClF₃', 'Cl', 7, 3, 0, 0, 3, 'ClF3'], ['XeF₂', 'Xe', 8, 2, 0, 0, 2, 'XeF2'], ['SF₆', 'S', 6, 6, 0, 0, 6, 'SF6'], ['BrF₅', 'Br', 7, 5, 0, 0, 5, 'BrF5'], ['XeF₄', 'Xe', 8, 4, 0, 0, 4, 'XeF4'], ['I₃⁻', 'I', 7, 2, 0, 1, 2, null], ['PCl₄⁺', 'P', 5, 4, 1, 0, 4, null], ['ICl₄⁻', 'I', 7, 4, 0, 1, 4, null]
];
const HYN = { 2: ['sp', 'রৈখিক'], 3: ['sp²', 'ত্রিকোণীয় সমতলীয়'], 4: ['sp³', 'চতুস্তলকীয়'], 5: ['sp³d', 'ত্রিকোণীয় দ্বিপিরামিড'], 6: ['sp³d²', 'অষ্টতলকীয়'] };
const SHAPE = { '2,0': 'রৈখিক', '3,0': 'ত্রিকোণীয় সমতলীয়', '2,1': 'কৌণিক (V)', '4,0': 'চতুস্তলকীয়', '3,1': 'ত্রিকোণীয় পিরামিড', '2,2': 'কৌণিক (V)', '5,0': 'ত্রিকোণীয় দ্বিপিরামিড', '4,1': 'দোলনা (see-saw)', '3,2': 'T-আকৃতি', '2,3': 'রৈখিক', '6,0': 'অষ্টতলকীয়', '5,1': 'বর্গাকার পিরামিড', '4,2': 'বর্গাকার সমতলীয়' };
C3.SHAPE = SHAPE; C3.HYN = HYN;
/* generic AXnEm builder for any valid (n, m) — used by calculator & model kit */
C3.buildAXE = (n, m, cen = 'S', lig = 'F') => {
  const T = n + m;
  const sets = { 2: G.lin, 3: G.tri, 4: G.tet, 5: G.tbp, 6: G.oct };
  // which positions are lone pairs (VSEPR preferences)
  const lpIdx = { 3: [0], 4: [0, 1].slice(0, m), 5: [2, 3, 4].slice(0, m), 6: m === 1 ? [1] : [0, 1] }[T] || [];
  let vec = sets[T].slice(), lp = lpIdx.map(i => vec[i]);
  let lv = vec.filter((_, i) => !lpIdx.includes(i));
  if (T === 4 && m === 1) { lv = pyr(107); lp = [[0, 1, 0]]; }
  if (T === 4 && m === 2) { lv = bent(104.5); lp = [[0, 0.537, 0.843], [0, 0.537, -0.843]]; }
  if (T === 3 && m === 1) { lv = bent(118); lp = [[0, 1, 0]]; }
  const ligs = lv.map(() => lig);
  const ang = lv.length >= 2 ? [[0, 1, 2]] : [];
  const mol = axe(cen, ligs, lv, lp, ang);
  if (lv.length >= 2) { let best = null; for (let i = 0; i < lv.length; i++) for (let j = i + 1; j < lv.length; j++) { const a = lv[i], b = lv[j]; const d = Math.acos(Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]))) * 180 / Math.PI; if (!best || d < best[0] - 0.01) best = [d, i, j]; } mol.ang = [[0, best[1] + 1, best[2] + 1, Math.round(best[0] * 2) / 2 + '°']]; }
  return mol;
};
V.c3_hybCalc = {
  t: 'কেন্দ্রীয় পরমাণুর সংকরণ নির্ণয়: H = ½(V + M − C + A)', k: ['calc', '3d', 'int'],
  cap: 'তালিকা থেকে অণু/আয়ন বেছে নাও বা নিজে মান বসাও। V = কেন্দ্রীয় পরমাণুর যোজ্যতা ইলেকট্রন, M = যুক্ত একযোজী পরমাণুর সংখ্যা (H, F, Cl, Br, I — অক্সিজেন বা সালফারের মতো দ্বিযোজী পরমাণু গণনা হয় না), C = ক্যাটায়নের চার্জ, A = অ্যানায়নের চার্জ। H = ২ → sp, ৩ → sp², ৪ → sp³, ৫ → sp³d, ৬ → sp³d²। নিঃসঙ্গ যুগল = H − যুক্ত পরমাণুর সংখ্যা। নিচে ফলাফলের ৩D গঠন দেখাবে।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><select class="inp" data-m style="flex:1">${HC.map((r, i) => `<option value="${i}" ${i === 1 ? 'selected' : ''}>${r[0]}</option>`).join('')}<option value="-1">নিজে মান দাও…</option></select></div>
    <div class="grid2" data-cus style="display:none"><label class="small">V <input class="inp" type="number" min="1" max="8" value="6" data-v></label><label class="small">M <input class="inp" type="number" min="0" max="7" value="4" data-mm></label><label class="small">C (ক্যাটায়ন চার্জ) <input class="inp" type="number" min="0" max="3" value="0" data-c></label><label class="small">A (অ্যানায়ন চার্জ) <input class="inp" type="number" min="0" max="3" value="0" data-a></label><label class="small" style="grid-column:1/-1">যুক্ত পরমাণুর মোট সংখ্যা <input class="inp" type="number" min="1" max="6" value="4" data-n></label></div>
    <div class="calc-out" data-out></div>` + X.cv('৩D গঠন') + `<div class="ctl"><button class="btn sm" data-pp></button><span class="small muted">টেনে ঘোরাও</span></div>`,
  mount(el) {
    const sel = el.querySelector('[data-m]'), cus = el.querySelector('[data-cus]'), out = el.querySelector('[data-out]');
    const vw = C3.view3d(el, () => MOLS.NH3.m(), { scale: 0.95 }); X.pp(el, vw.A);
    const q = s => +el.querySelector(s).value;
    const run = () => {
      const i = +sel.value; cus.style.display = i < 0 ? '' : 'none';
      let lab, cen, V0, M, C, A0, n, key;
      if (i >= 0) [lab, cen, V0, M, C, A0, n, key] = HC[i]; else { lab = 'তোমার অণু'; cen = 'X'; V0 = q('[data-v]'); M = q('[data-mm]'); C = q('[data-c]'); A0 = q('[data-a]'); n = q('[data-n]'); key = null; }
      const Hn = (V0 + M - C + A0) / 2, lp = Hn - n;
      if (Hn % 1 || !HYN[Hn] || lp < 0 || lp > 3) { out.innerHTML = `H = ½(${V0} + ${M} − ${C} + ${A0}) = <b>${Hn}</b> — এই মানগুলো দিয়ে বৈধ সংকরণ পাওয়া যায় না (H পূর্ণসংখ্যা ২–৬ হতে হবে এবং নিঃসঙ্গ যুগল ঋণাত্মক হবে না)।`; return; }
      const [hy, eg] = HYN[Hn], sh = SHAPE[n + ',' + lp] || '—';
      out.innerHTML = `<b>${lab}</b> (কেন্দ্রীয় পরমাণু ${cen})<br>H = ½(V + M − C + A) = ½(${V0} + ${M} − ${C} + ${A0}) = <b>${Hn}</b> → <b>${hy}</b><br>যুক্ত পরমাণু = ${bn(n)}টি (σ বন্ধন যুগল) · নিঃসঙ্গ যুগল = ${bn(Hn)} − ${bn(n)} = <b>${bn(lp)}</b><br>যুগলের সজ্জা: ${eg} · আকৃতি: <b>${sh}</b>`;
      const ligEl = { CH4: 'H', NH3: 'H', H2O: 'H', NH4: 'H' }[key] || (/O|CO|NO|SO/.test(lab) && M === 0 ? 'O' : 'F');
      vw.set(key ? MOLS[key].m() : C3.buildAXE(n, lp, cen.length <= 2 && CPK[cen] ? cen : 'S', /H₃O|PCl/.test(lab) ? (lab.startsWith('H') ? 'H' : 'Cl') : ligEl));
    };
    sel.onchange = run; el.querySelectorAll('[data-cus] input').forEach(x => x.oninput = run);
    run();
    return () => vw.stop();
  }
};

/* ======================= ৩.১১ VSEPR: নিঃসঙ্গ যুগল ও বন্ধন কোণ ======================= */
const LPA = {
  lp: { t: 'নিঃসঙ্গ যুগলের সংখ্যা', items: [['CH₄', 'C', 'H', 4, 0, 109.5], ['NH₃', 'N', 'H', 3, 1, 107], ['H₂O', 'O', 'H', 2, 2, 104.5]], note: 'তিনটিতেই কেন্দ্রীয় পরমাণুর চারটি ইলেকট্রন যুগল (sp³)। বিকর্ষণের ক্রম: নিঃসঙ্গ-নিঃসঙ্গ > নিঃসঙ্গ-বন্ধন > বন্ধন-বন্ধন — নিঃসঙ্গ যুগল কেবল একটি নিউক্লিয়াসে আবদ্ধ, তাই বেশি ছড়িয়ে থাকে ও বেশি জায়গা নেয়। নিঃসঙ্গ যুগল যত বাড়ে, বন্ধন যুগলগুলো তত চেপে আসে: 109.5° → 107° → 104.5°।' },
  cen: { t: 'কেন্দ্রীয় পরমাণুর EN ও আকার', items: [['NH₃', 'N', 'H', 3, 1, 107], ['PH₃', 'P', 'H', 3, 1, 93.5], ['H₂O', 'O', 'H', 2, 2, 104.5], ['H₂S', 'S', 'H', 2, 2, 92.1]], note: 'কেন্দ্রীয় পরমাণু যত বেশি তড়িৎ ঋণাত্মক ও ছোট (N > P, O > S), বন্ধন যুগল তত কেন্দ্রের কাছে টেনে আনে — কেন্দ্রের কাছে বন্ধন যুগলগুলোর পারস্পরিক বিকর্ষণ বেশি, কোণ বড়। P ও S বড় ও কম তড়িৎ ঋণাত্মক — বন্ধন যুগল দূরে, বিকর্ষণ কম; তাছাড়া প্রায় বিশুদ্ধ p অরবিটাল ব্যবহারে কোণ ৯০° এর কাছাকাছি।' },
  sub: { t: 'পার্শ্বপরমাণুর EN', items: [['NH₃', 'N', 'H', 3, 1, 107], ['NF₃', 'N', 'F', 3, 1, 102.3], ['H₂O', 'O', 'H', 2, 2, 104.5], ['OF₂', 'O', 'F', 2, 2, 103.1]], note: 'পার্শ্বপরমাণু যত বেশি তড়িৎ ঋণাত্মক (F > H), বন্ধন যুগল তত কেন্দ্র থেকে দূরে (পার্শ্বপরমাণুর দিকে) সরে যায় — কেন্দ্রের কাছে বিকর্ষণ কমে, নিঃসঙ্গ যুগল বেশি জায়গা পায়, কোণ কমে: NH₃ 107° > NF₃ 102.3°, H₂O 104.5° > OF₂ 103.1°।' }
};
V.c3_lpAngle = {
  t: 'VSEPR: বন্ধন কোণের ওপর নিঃসঙ্গ যুগল ও তড়িৎ ঋণাত্মকতার প্রভাব', k: ['2d', 'int'],
  cap: 'তিন দৃশ্যে তিনটি নিয়ামক। প্রতিটি অণুর চিত্রে কমলা খণ্ড নিঃসঙ্গ যুগল এবং বন্ধন যুগলের অবস্থানে ছোট বিন্দু দেখায় ইলেকট্রন যুগল কেন্দ্রের কত কাছে আছে (তড়িৎ ঋণাত্মকতা অনুযায়ী)। কোণের মান প্রকৃত পরীক্ষালব্ধ মান। নিচের স্তম্ভগুলো কোণের তুলনা।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['lp', 'নিঃসঙ্গ যুগল'], ['cen', 'কেন্দ্রীয় পরমাণু'], ['sub', 'পার্শ্বপরমাণু']], 'lp')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const ENV = { H: 2.2, F: 3.98, N: 3.04, P: 2.19, O: 3.44, S: 2.58, C: 2.55 };
    const draw = m => {
      const D = LPA[m], n = D.items.length, cw = 400 / n; let s = '';
      D.items.forEach(([f, c, l, nb, nl, ang], i) => {
        const cx = cw * i + cw / 2, cy = 82, L = Math.min(48, cw * 0.38);
        const half = ang / 2 * Math.PI / 180, base = Math.PI / 2;
        // bond directions in 2D (downwards fan); for 3 bonds show the pyramid as 2 in-plane + 1 wedge
        const dirs = nb === 4 ? [base - half, base + half, -Math.PI / 2 + 0.35, -Math.PI / 2 - 0.35] : nb === 3 ? [base - half, base + half, base] : [base - half, base + half];
        // lone pairs up
        const lpd = nl === 1 ? [-Math.PI / 2] : nl === 2 ? [-Math.PI / 2 - 0.62, -Math.PI / 2 + 0.62] : [];
        lpd.forEach(a => s += lpLobe(cx, cy, a, 36, 14));
        lpd.forEach(a => { const px = cx + Math.cos(a) * 22, py = cy + Math.sin(a) * 22; s += `<circle cx="${f1(px - 3 * Math.sin(a))}" cy="${f1(py + 3 * Math.cos(a))}" r="2" fill="#B9650F"/><circle cx="${f1(px + 3 * Math.sin(a))}" cy="${f1(py - 3 * Math.cos(a))}" r="2" fill="#B9650F"/>`; });
        dirs.forEach((a, k) => {
          const ex = cx + Math.cos(a) * L, ey = cy + Math.sin(a) * L, wedge = (nb === 3 && k === 2) || (nb === 4 && k === 2), hashed = nb === 4 && k === 3;
          if (wedge) { const px = -Math.sin(a) * 5, py = Math.cos(a) * 5; s += `<path d="M${cx} ${cy} L${f1(ex + px)} ${f1(ey + py)} L${f1(ex - px)} ${f1(ey - py)}Z" class="f-fg" opacity=".85"/>`; }
          else if (hashed) { for (let t = 0.2; t <= 1; t += 0.16) { const qx = cx + Math.cos(a) * L * t, qy = cy + Math.sin(a) * L * t, w = 5 * t; s += `<line x1="${f1(qx - Math.sin(a) * w)}" y1="${f1(qy + Math.cos(a) * w)}" x2="${f1(qx + Math.sin(a) * w)}" y2="${f1(qy - Math.cos(a) * w)}" class="s-fg" stroke-width="1.4"/>`; } }
          else s += `<line x1="${cx}" y1="${cy}" x2="${f1(ex)}" y2="${f1(ey)}" class="s-fg" stroke-width="2.4"/>`;
          // bonding-pair position dot (closer to centre if centre more EN)
          const share = ENV[c] / (ENV[c] + ENV[l]); const t = 1 - share; const dx = cx + Math.cos(a) * L * (0.15 + 0.7 * t), dy = cy + Math.sin(a) * L * (0.15 + 0.7 * t);
          if (!wedge && !hashed) s += `<circle cx="${f1(dx)}" cy="${f1(dy)}" r="3" fill="#2F86D6"/>`;
          s += `<circle cx="${f1(ex)}" cy="${f1(ey)}" r="${l === 'H' ? 9 : 11}" fill="${CPK[l]}" stroke="rgba(0,0,0,.3)"/><text x="${f1(ex)}" y="${f1(ey + 4)}" text-anchor="middle" style="font-size:10.5px;font-weight:700;fill:${INK}">${l}</text>`;
        });
        s += `<circle cx="${cx}" cy="${cy}" r="13" fill="${CPK[c]}" stroke="rgba(0,0,0,.3)"/><text x="${cx}" y="${cy + 4.5}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:${['C', 'N', 'O', 'P'].includes(c) ? '#fff' : INK}">${c}</text>`;
        // angle arc between first two bonds
        const a1 = dirs[0], a2 = dirs[1], R = 26; s += `<path d="M${f1(cx + Math.cos(a1) * R)} ${f1(cy + Math.sin(a1) * R)} A${R} ${R} 0 0 1 ${f1(cx + Math.cos(a2) * R)} ${f1(cy + Math.sin(a2) * R)}" fill="none" stroke="#E5484D" stroke-width="1.6"/>`;
        s += `<text x="${cx}" y="${cy + 72}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:#E5484D">${ang}°</text><text x="${cx}" y="${cy + 88}" text-anchor="middle" style="font-size:12.5px;font-weight:700">${f}</text>`;
      });
      // bars
      const by = 252, bmin = 85, bmax = 112, bh = 64;
      D.items.forEach(([f, , , , , ang], i) => { const cx = cw * i + cw / 2, h = (ang - bmin) / (bmax - bmin) * bh; s += `<rect x="${f1(cx - 16)}" y="${f1(by - h)}" width="32" height="${f1(h)}" rx="3" fill="#E5484D" opacity=".75"/><text x="${cx}" y="${f1(by - h - 4)}" text-anchor="middle" class="mono" style="font-size:10px;font-weight:600">${ang}°</text>`; });
      s += `<line x1="10" y1="${by}" x2="390" y2="${by}" class="s-ln"/><text x="10" y="${by + 14}" class="tm" style="font-size:10px">বন্ধন কোণ (৮৫° থেকে স্কেল) · নীল বিন্দু = বন্ধন যুগলের অবস্থান</text>`;
      box.innerHTML = X.svg(400, by + 20, s, 'VSEPR');
      out.innerHTML = `<b>${D.t}</b>: ${D.note}`;
    };
    X.onSeg(el, 'm', draw); draw('lp');
  }
};

/* ======================= ৩.১২ ভার্চুয়াল বল-কাঠি মডেল কিট ======================= */
const KITEX = { '2,0': 'BeCl₂, CO₂', '3,0': 'BF₃, SO₃', '2,1': 'SO₂, O₃', '4,0': 'CH₄, CCl₄, NH₄⁺', '3,1': 'NH₃, PCl₃', '2,2': 'H₂O, H₂S, OF₂', '5,0': 'PCl₅', '4,1': 'SF₄', '3,2': 'ClF₃', '2,3': 'XeF₂, I₃⁻', '6,0': 'SF₆', '5,1': 'BrF₅, IF₅', '4,2': 'XeF₄, ICl₄⁻' };
V.c3_modelKit = {
  t: 'ভার্চুয়াল মডেল কিট: কাঠি ও নিঃসঙ্গ যুগল বসিয়ে আকৃতি তৈরি', k: ['3d', 'int'],
  cap: 'ব্যবহারিক ক্লাসের বল-কাঠি মডেলের মতো: কেন্দ্রীয় পরমাণুতে কয়টি পরমাণু (কাঠি) ও কয়টি নিঃসঙ্গ যুগল থাকবে বেছে নাও। VSEPR নিয়মে যুগলগুলো সবচেয়ে দূরে সরে সজ্জিত হয় — মোট যুগল সংখ্যা ঠিক করে যুগলের জ্যামিতি, আর নিঃসঙ্গ যুগলগুলো যেখানে বসে তা ঠিক করে আকৃতি। ত্রিকোণীয় দ্বিপিরামিডে নিঃসঙ্গ যুগল নিরক্ষীয় অবস্থানে (বিকর্ষণ কম), অষ্টতলকে দুটি নিঃসঙ্গ যুগল পরস্পর বিপরীতে বসে। টেনে ঘোরাও।',
  html: () => `<div class="ctl" style="margin:0 0 4px"><label style="flex:none;min-width:100px">যুক্ত পরমাণু</label>${X.seg('n', [2, 3, 4, 5, 6].map(v => [v, bn(v)]), 4)}</div><div class="ctl" style="margin:0 0 6px"><label style="flex:none;min-width:100px">নিঃসঙ্গ যুগল</label>${X.seg('l', [0, 1, 2, 3].map(v => [v, bn(v)]), 0)}</div>` + X.cv('মডেল কিট') + `<div class="ctl"><button class="btn sm" data-pp></button><span class="small muted">টেনে ঘোরাও</span></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const out = el.querySelector('[data-out]'); let n = 4, l = 0;
    const vw = C3.view3d(el, () => C3.buildAXE(4, 0, 'C', 'H')); X.pp(el, vw.A);
    const run = () => {
      const T = n + l, key = n + ',' + l, sh = SHAPE[key];
      if (!sh) { out.innerHTML = `মোট ${bn(T)}টি যুগল — ${T > 6 ? 'HSC সিলেবাসে ৬টির বেশি যুগলের গঠন নেই।' : 'এই সমন্বয়টি সাধারণ উদাহরণে পাওয়া যায় না।'} অন্য সমন্বয় বেছে নাও।`; return; }
      const cen = { '4,0': 'C', '3,1': 'N', '2,2': 'O', '3,0': 'B', '2,0': 'Be', '2,1': 'S' }[key] || (T >= 5 ? (l >= 2 ? 'Xe' : l === 1 ? 'S' : 'P') : 'S');
      const lig = ['C', 'N', 'O'].includes(cen) && T === 4 ? 'H' : cen === 'P' ? 'Cl' : cen === 'Be' ? 'Cl' : cen === 'S' && T === 3 ? 'O' : 'F';
      vw.set(C3.buildAXE(n, l, cen, lig));
      out.innerHTML = `মোট যুগল = ${bn(n)} + ${bn(l)} = <b>${bn(T)}</b> → যুগলের জ্যামিতি: <b>${HYN[T][1]}</b> (${HYN[T][0]})<br>আণবিক আকৃতি: <b>${sh}</b> · প্রতীক: AX${X.sub(n)}${l ? 'E' + (l > 1 ? X.sub(l) : '') : ''}<br>উদাহরণ: <b>${KITEX[key]}</b>`;
    };
    X.onSeg(el, 'n', k => { n = +k; run(); }); X.onSeg(el, 'l', k => { l = +k; run(); });
    run();
    return () => vw.stop();
  }
};

/* ======================= ৩.১৩ সন্নিবেশ বন্ধন গঠন (অ্যানিমেশন) ======================= */
const CO = {
  nh4: { n: 'NH₃ + H⁺ → NH₄⁺', don: 'N', acc: 'H⁺', dl: [['H', -46, 0], ['H', 0, 46], ['H', 0, -46]], al: [], prod: '[NH₄]⁺', note: 'NH₃ এর N পরমাণুর একটি নিঃসঙ্গ যুগল আছে (দাতা)। H⁺ আয়নের 1s অরবিটাল সম্পূর্ণ খালি (গ্রহীতা)। N তার যুগলটি H⁺ এর সাথে শেয়ার করে N→H সন্নিবেশ বন্ধন গঠন করে। গঠনের পর চারটি N–H বন্ধন সম্পূর্ণ অভিন্ন (দৈর্ঘ্য, শক্তি), এবং ধনাত্মক চার্জ পুরো আয়নে ছড়িয়ে পড়ে।' },
  h3o: { n: 'H₂O + H⁺ → H₃O⁺', don: 'O', acc: 'H⁺', dl: [['H', -46, 0], ['H', 0, 46]], al: [], lp2: true, prod: '[H₃O]⁺', note: 'পানির O পরমাণুর দুটি নিঃসঙ্গ যুগলের একটি H⁺ কে দান করে হাইড্রোনিয়াম আয়ন তৈরি হয়। এজন্যই এসিডের জলীয় দ্রবণে মুক্ত H⁺ থাকে না, H₃O⁺ থাকে। একটি নিঃসঙ্গ যুগল অবশিষ্ট থাকে — আকৃতি ত্রিকোণীয় পিরামিড।' },
  bf3: { n: 'NH₃ + BF₃ → H₃N→BF₃', don: 'N', acc: 'B', dl: [['H', -46, 0], ['H', 0, 46], ['H', 0, -46]], al: [['F', 46, 0], ['F', 0, 46], ['F', 0, -46]], prod: 'H₃N→BF₃', note: 'BF₃ এর B এর চারপাশে মাত্র ৬টি ইলেকট্রন — অষ্টক অপূর্ণ, একটি খালি 2p অরবিটাল (লুইস এসিড)। NH₃ এর নিঃসঙ্গ যুগল (লুইস ক্ষারক) B এ দান করে যুত যৌগ (adduct) তৈরি করে; এখন N ও B দুজনেরই অষ্টক পূর্ণ, B sp² থেকে sp³ হয়।' }
};
V.c3_coord = {
  t: 'সন্নিবেশ বন্ধন গঠন: দাতা নিঃসঙ্গ যুগল → খালি অরবিটাল', k: ['anim', 'int'],
  cap: 'বিক্রিয়া বেছে নিয়ে "চালাও" চাপো বা স্লাইডার টানো। লাল বিন্দু দুটি দাতা পরমাণুর নিঃসঙ্গ যুগল; ড্যাশ বাক্স গ্রহীতার খালি অরবিটাল। যুগলটি দাতা ও গ্রহীতার মাঝে চলে এসে শেয়ার হয়ে যায় — দুটি ইলেকট্রনই এসেছে একটি পরমাণু থেকে। গঠনের পর বন্ধনটিকে তীর (দাতা → গ্রহীতা) দিয়ে দেখানো হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('r', Object.keys(CO).map(k => [k, CO[k].n]), 'nh4')}</div><div data-svg></div><div class="ctl"><input type="range" min="0" max="100" value="0" data-t style="flex:1"><button class="btn sm primary" data-go>চালাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sl = el.querySelector('[data-t]'); let k = 'nh4', raf = 0;
    const draw = t => {
      const R = CO[k]; let s = `<defs>${X.arrowC('c3co', '#E5484D')}</defs>`;
      const gap = 150 - 96 * t, dx = 200 - gap / 2 - 20, ax = 200 + gap / 2 + 20, cy = 112;
      // donor
      R.dl.forEach(([e, x, y]) => s += `<line x1="${dx}" y1="${cy}" x2="${dx + x}" y2="${cy + y}" class="s-fg" stroke-width="2"/><circle cx="${dx + x}" cy="${cy + y}" r="11" fill="${CPK[e]}" stroke="rgba(0,0,0,.3)"/><text x="${dx + x}" y="${cy + y + 4}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:${INK}">${e}</text>`);
      if (R.lp2) s += `<circle cx="${dx - 6}" cy="${cy + 26}" r="3" class="f-fg"/><circle cx="${dx + 6}" cy="${cy + 26}" r="3" class="f-fg"/>`;
      s += `<circle cx="${dx}" cy="${cy}" r="15" fill="${CPK[R.don]}" stroke="rgba(0,0,0,.3)"/><text x="${dx}" y="${cy + 5}" text-anchor="middle" style="font-size:13px;font-weight:700;fill:#fff">${R.don}</text>`;
      // acceptor
      R.al.forEach(([e, x, y]) => s += `<line x1="${ax}" y1="${cy}" x2="${ax + x}" y2="${cy + y}" class="s-fg" stroke-width="2"/><circle cx="${ax + x}" cy="${cy + y}" r="11" fill="${CPK[e]}" stroke="rgba(0,0,0,.3)"/><text x="${ax + x}" y="${cy + y + 4}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:${INK}">${e}</text>`);
      const accEl = R.acc === 'H⁺' ? 'H' : R.acc;
      s += `<rect x="${ax - 34}" y="${cy - 10}" width="18" height="20" rx="3" fill="none" class="s-mu" stroke-dasharray="3 2" opacity="${(1 - t).toFixed(2)}"/><circle cx="${ax}" cy="${cy}" r="${accEl === 'H' ? 11 : 15}" fill="${CPK[accEl]}" stroke="rgba(0,0,0,.3)"/><text x="${ax}" y="${cy + 4.5}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:${INK}">${R.acc}</text>`;
      // the moving electron pair
      const px = dx + 22 + (ax - 26 - dx - 22) * Math.min(1, t * 1.1) * 0.5 + (t > 0.9 ? 0 : 0);
      const mid = (dx + ax) / 2, pX = t < 0.5 ? dx + 24 + (mid - dx - 24) * (t / 0.5) : mid;
      const pyo = t >= 0.98 ? -12 : 0; s += `<circle cx="${f1(pX - (t >= 0.98 ? 5 : 0))}" cy="${cy - 5 + pyo + (t >= 0.98 ? 5 : 0)}" r="3.6" fill="#E5484D"/><circle cx="${f1(pX + (t >= 0.98 ? 5 : 0))}" cy="${cy + 5 + pyo - (t >= 0.98 ? 5 : 0)}" r="3.6" fill="#E5484D"/>`;
      if (t >= 0.98) s += `<line x1="${dx + 16}" y1="${cy}" x2="${ax - (accEl === 'H' ? 12 : 16)}" y2="${cy}" stroke="#E5484D" stroke-width="2.4" marker-end="url(#c3co)"/><text x="${mid}" y="${cy + 30}" text-anchor="middle" style="font-size:11px;fill:#E5484D;font-weight:600">সন্নিবেশ বন্ধন</text>`;
      s += `<text x="${dx}" y="${cy - 74}" text-anchor="middle" class="tm" style="font-size:10.5px">দাতা (লুইস ক্ষারক)</text><text x="${ax}" y="${cy - 74}" text-anchor="middle" class="tm" style="font-size:10.5px">গ্রহীতা (লুইস এসিড)</text>`;
      s += `<text x="200" y="212" text-anchor="middle" style="font-size:13px;font-weight:700">${t >= 0.98 ? 'উৎপাদ: ' + R.prod : R.n}</text>`;
      box.innerHTML = X.svg(400, 222, s, 'সন্নিবেশ বন্ধন');
      out.innerHTML = t >= 0.98 ? R.note : t > 0 ? 'নিঃসঙ্গ যুগলটি গ্রহীতার খালি অরবিটালের দিকে এগোচ্ছে…' : 'শুরু: দাতার নিঃসঙ্গ যুগল (লাল) ও গ্রহীতার খালি অরবিটাল (ড্যাশ বাক্স) চিহ্নিত করো।';
    };
    sl.oninput = () => { cancelAnimationFrame(raf); draw(+sl.value / 100); };
    el.querySelector('[data-go]').onclick = () => { cancelAnimationFrame(raf); if (X.rm()) { sl.value = 100; draw(1); return; } const t0 = performance.now(); const st = tt => { const p = Math.min(1, (tt - t0) / 2200); sl.value = p * 100; draw(p); if (p < 1) raf = requestAnimationFrame(st); }; raf = requestAnimationFrame(st); };
    X.onSeg(el, 'r', x => { k = x; cancelAnimationFrame(raf); sl.value = 0; draw(0); });
    draw(0);
    return () => cancelAnimationFrame(raf);
  }
};

/* ======================= ৩.১৩.১ একই যৌগে একাধিক বন্ধন ======================= */
const BF = {
  NH4Cl: { n: 'NH₄Cl', a: [['N', 130, 100], ['H', 130, 46], ['H', 76, 100], ['H', 130, 154], ['H', 184, 100], ['Cl', 310, 100]], b: [[0, 1, 'c', 1], [0, 2, 'c', 1], [0, 3, 'c', 1], [0, 4, 'd']], ions: [[[40, 26, 222, 174], '+'], [[270, 60, 350, 140], '−']], cnt: [3, 1, 1], note: 'NH₄⁺ আয়নের ভেতরে তিনটি সাধারণ N–H সমযোজী ও একটি N→H সন্নিবেশ বন্ধন (গঠনের পর চারটি অভিন্ন); NH₄⁺ ও Cl⁻ এর মধ্যে আয়নিক বন্ধন।' },
  NaOH: { n: 'NaOH', a: [['Na', 100, 100], ['O', 260, 100], ['H', 320, 100]], b: [[1, 2, 'c', 1]], ions: [[[66, 66, 134, 134], '+'], [[226, 66, 350, 134], '−']], cnt: [1, 0, 1], note: 'OH⁻ আয়নে O–H সমযোজী বন্ধন; Na⁺ ও OH⁻ এর মধ্যে আয়নিক বন্ধন।' },
  KCN: { n: 'KCN', a: [['K', 90, 100], ['C', 250, 100], ['N', 320, 100]], b: [[1, 2, 'c', 3]], ions: [[[56, 66, 124, 134], '+'], [[218, 66, 352, 134], '−']], cnt: [1, 0, 1], note: 'CN⁻ আয়নে C≡N ত্রিবন্ধন (১σ + ২π, সমযোজী); K⁺ ও CN⁻ এর মধ্যে আয়নিক বন্ধন।' },
  HNO3: { n: 'HNO₃', a: [['H', 70, 100], ['O', 140, 100], ['N', 220, 100], ['O', 280, 50], ['O', 280, 150]], b: [[0, 1, 'c', 1], [1, 2, 'c', 1], [2, 3, 'c', 2], [2, 4, 'd']], ions: [], cnt: [3, 1, 0], note: 'প্রচলিত গঠনে: O–H ও N–O একক সমযোজী, N=O দ্বিবন্ধন এবং N→O সন্নিবেশ বন্ধন (N এর নিঃসঙ্গ যুগল O কে দান)। বাস্তবে দুই প্রান্তীয় N–O বন্ধন অনুরণনের জন্য সমান দৈর্ঘ্যের।' },
  O3: { n: 'O₃', a: [['O', 110, 120], ['O', 200, 70], ['O', 290, 120]], b: [[0, 1, 'c', 2], [1, 2, 'd']], ions: [], cnt: [1, 1, 0], note: 'ওজোনের প্রচলিত গঠন O=O→O: একটি দ্বিবন্ধন ও একটি সন্নিবেশ বন্ধন। অনুরণনের জন্য প্রকৃতপক্ষে দুটি O–O বন্ধনই সমান (128 pm)।' },
  Cu: { n: '[Cu(NH₃)₄]SO₄', a: [['Cu', 140, 110], ['N', 140, 46], ['N', 76, 110], ['N', 140, 174], ['N', 204, 110], ['S', 320, 110], ['O', 320, 62], ['O', 320, 158], ['O', 272, 110], ['O', 368, 110]], b: [[1, 0, 'd'], [2, 0, 'd'], [3, 0, 'd'], [4, 0, 'd'], [5, 6, 'c', 2], [5, 7, 'c', 2], [5, 8, 'c', 1], [5, 9, 'c', 1]], ions: [[[46, 18, 236, 202], '2+'], [[252, 34, 390, 186], '2−']], cnt: [4, 4, 1], extra: 'প্রতিটি NH₃ এ আরও ৩টি N–H সমযোজী (চিত্রে দেখানো হয়নি)', note: 'চারটি NH₃ লিগ্যান্ড Cu²⁺ এ সন্নিবেশ বন্ধনে (N→Cu) যুক্ত; NH₃ এর ভেতরে N–H এবং SO₄²⁻ এর ভেতরে S–O সমযোজী বন্ধন; জটিল ক্যাটায়ন ও সালফেটের মধ্যে আয়নিক বন্ধন।' }
};
V.c3_bondFinder = {
  t: 'একই যৌগে আয়নিক, সমযোজী ও সন্নিবেশ বন্ধন শনাক্তকরণ', k: ['2d', 'int'],
  cap: 'যৌগ বেছে নাও। কালো রেখা = সমযোজী বন্ধন (দুই রেখা দ্বিবন্ধন, তিন রেখা ত্রিবন্ধন), লাল তীর = সন্নিবেশ বন্ধন (দাতা → গ্রহীতা), আর তৃতীয় বন্ধনীর আয়নগুলোর মধ্যে বিপরীত চার্জের আকর্ষণ = আয়নিক বন্ধন। নিচে প্রতিটি ধরনের সংখ্যা।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('c', Object.keys(BF).map(k => [k, BF[k].n]), 'NH4Cl')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = k => {
      const D = BF[k]; let s = `<defs>${X.arrowC('c3bf', '#E5484D')}</defs>`;
      D.ions.forEach(([[x1, y1, x2, y2], ch]) => s += `<path d="M${x1 + 8} ${y1} L${x1} ${y1} L${x1} ${y2} L${x1 + 8} ${y2}" fill="none" class="s-mu" stroke-width="1.6"/><path d="M${x2 - 8} ${y1} L${x2} ${y1} L${x2} ${y2} L${x2 - 8} ${y2}" fill="none" class="s-mu" stroke-width="1.6"/><text x="${x2 + 3}" y="${y1 + 10}" style="font-size:13px;font-weight:700">${ch}</text>`);
      if (D.ions.length === 2) { const a = D.ions[0][0], b = D.ions[1][0]; s += `<text x="${(a[2] + b[0]) / 2 + 2}" y="${(a[1] + a[3]) / 2 + 4}" text-anchor="middle" style="font-size:16px;fill:#7E57C2">⇆</text><text x="${(a[2] + b[0]) / 2 + 2}" y="${(a[1] + a[3]) / 2 + 20}" text-anchor="middle" style="font-size:9.5px;fill:#7E57C2;font-weight:600">আয়নিক</text>`; }
      D.b.forEach(([i, j, t, o]) => {
        const [, x1, y1] = D.a[i], [, x2, y2] = D.a[j]; const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L, nx = -uy, ny = ux, r = 14;
        const ax = x1 + ux * r, ay = y1 + uy * r, bx = x2 - ux * r, by = y2 - uy * r;
        if (t === 'd') s += `<line x1="${f1(ax)}" y1="${f1(ay)}" x2="${f1(bx)}" y2="${f1(by)}" stroke="#E5484D" stroke-width="2.4" marker-end="url(#c3bf)"/>`;
        else { const offs = o === 1 ? [0] : o === 2 ? [-3.5, 3.5] : [-5.5, 0, 5.5]; offs.forEach(d => s += `<line x1="${f1(ax + nx * d)}" y1="${f1(ay + ny * d)}" x2="${f1(bx + nx * d)}" y2="${f1(by + ny * d)}" class="s-fg" stroke-width="2"/>`); }
      });
      D.a.forEach(([e, x, y]) => s += `<circle cx="${x}" cy="${y}" r="${e === 'H' ? 10 : 13}" fill="${CPK[e] || '#999'}" stroke="rgba(0,0,0,.3)"/><text x="${x}" y="${y + 4.5}" text-anchor="middle" style="font-size:${e.length > 1 ? 10.5 : 12}px;font-weight:700;fill:${['C', 'N', 'O', 'Cl', 'Na', 'Cu'].includes(e) ? '#fff' : INK}">${e}</text>`);
      s += `<line x1="16" y1="222" x2="40" y2="222" class="s-fg" stroke-width="2"/><text x="44" y="226" style="font-size:10.5px">সমযোজী</text><line x1="112" y1="222" x2="140" y2="222" stroke="#E5484D" stroke-width="2.4" marker-end="url(#c3bf)"/><text x="146" y="226" style="font-size:10.5px">সন্নিবেশ</text><text x="216" y="226" style="font-size:13px;fill:#7E57C2">⇆</text><text x="232" y="226" style="font-size:10.5px">আয়নিক (বিপরীত চার্জের আকর্ষণ)</text>`;
      box.innerHTML = X.svg(400, 234, s, 'বন্ধন শনাক্তকরণ');
      out.innerHTML = `<b>${D.n}</b>: সমযোজী <b>${bn(D.cnt[0])}</b>টি${D.extra ? '*' : ''} · সন্নিবেশ <b>${bn(D.cnt[1])}</b>টি · আয়নিক আকর্ষণ <b>${D.cnt[2] ? 'আছে' : 'নেই'}</b>${D.extra ? '<br><span class="small">* ' + D.extra + '</span>' : ''}<br>${D.note}`;
    };
    X.onSeg(el, 'c', draw); draw('NH4Cl');
  }
};

/* ======================= ৩.১৪ সন্নিবেশ বনাম সাধারণ সমযোজী ======================= */
V.c3_coordVsCov = {
  t: 'সাধারণ সমযোজী বনাম সন্নিবেশ বন্ধন: ইলেকট্রন কোথা থেকে আসে?', k: ['anim', 'int'],
  cap: 'বাম দিকে সাধারণ সমযোজী বন্ধন (H₂ ও HCl): প্রতিটি পরমাণু একটি করে ইলেকট্রন দেয় — নীল ও সবুজ দুই রঙের ইলেকট্রন মিলে যুগল। ডান দিকে সন্নিবেশ বন্ধন (NH₄⁺ গঠন): দুটি ইলেকট্রনই একই রঙের — শুধু N থেকে আসা। "চালাও" চাপলে ইলেকট্রনগুলো বন্ধন অঞ্চলে চলে আসবে। গঠিত হওয়ার পর দুই বন্ধনের ইলেকট্রন যুগলকে আলাদা করে চেনা যায় না — পার্থক্য কেবল উৎপত্তিতে।',
  html: () => `<div data-svg></div><div class="ctl"><input type="range" min="0" max="100" value="0" data-t style="flex:1"><button class="btn sm primary" data-go>চালাও</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), sl = el.querySelector('[data-t]'); let raf = 0;
    const draw = t => {
      let s = `<defs>${X.arrowC('c3cv', '#E5484D')}</defs><line x1="200" y1="8" x2="200" y2="200" class="s-ln" stroke-dasharray="3 3"/>`;
      s += `<text x="100" y="20" text-anchor="middle" style="font-size:12px;font-weight:700">সাধারণ সমযোজী (H–Cl)</text><text x="300" y="20" text-anchor="middle" style="font-size:12px;font-weight:700">সন্নিবেশ (H₃N→H⁺)</text>`;
      // left: H . + . Cl
      const hx = 55 + 15 * t, clx = 150 - 15 * t, cy = 100, mid = (hx + clx) / 2;
      s += `<circle cx="${f1(hx)}" cy="${cy}" r="14" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><text x="${f1(hx)}" y="${cy + 4.5}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:${INK}">H</text><circle cx="${f1(clx)}" cy="${cy}" r="18" fill="${CPK.Cl}" stroke="rgba(0,0,0,.3)"/><text x="${f1(clx)}" y="${cy + 4.5}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:#fff">Cl</text>`;
      const e1 = hx + 18 + (mid - 4 - hx - 18) * t, e2 = clx - 22 - (clx - 22 - mid - 4) * t;
      s += `<circle cx="${f1(e1)}" cy="${cy}" r="4" fill="#2F86D6"/><circle cx="${f1(e2)}" cy="${cy}" r="4" fill="#2BB24C"/>`;
      [[-1, -1], [1, -1], [-1, 1], [1, 1], [0, 1.4], [0, -1.4]].forEach(([a, b]) => s += `<circle cx="${f1(clx + a * 12 + (a === 0 ? 0 : 8))}" cy="${f1(cy + b * 18)}" r="2" class="f-mu"/>`);
      s += `<text x="100" y="158" text-anchor="middle" style="font-size:11px"><tspan fill="#2F86D6">●</tspan> H থেকে ১টি + <tspan fill="#2BB24C">●</tspan> Cl থেকে ১টি</text>`;
      if (t > 0.97) s += `<text x="100" y="178" text-anchor="middle" class="tb" style="font-size:12px">H–Cl (রেখা দিয়ে)</text>`;
      // right: N lone pair to H+
      const nx = 255 + 10 * t, hpx = 350 - 42 * t, m2 = (nx + hpx) / 2;
      [[-30, -20], [-30, 20], [0, 34]].forEach(([a, b]) => s += `<line x1="${f1(nx)}" y1="${cy}" x2="${f1(nx + a)}" y2="${cy + b}" class="s-fg" stroke-width="1.8"/><circle cx="${f1(nx + a)}" cy="${cy + b}" r="9" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><text x="${f1(nx + a)}" y="${cy + b + 3.5}" text-anchor="middle" style="font-size:10px;font-weight:700;fill:${INK}">H</text>`);
      s += `<circle cx="${f1(nx)}" cy="${cy}" r="15" fill="${CPK.N}" stroke="rgba(0,0,0,.3)"/><text x="${f1(nx)}" y="${cy + 5}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:#fff">N</text>`;
      s += `<circle cx="${f1(hpx)}" cy="${cy}" r="11" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><text x="${f1(hpx)}" y="${cy + 4}" text-anchor="middle" style="font-size:10px;font-weight:700;fill:${INK}">H⁺</text>`;
      const lx = nx + 20 + (m2 - nx - 20) * t;
      s += `<circle cx="${f1(lx)}" cy="${cy - 5}" r="4" fill="#3B5BDB"/><circle cx="${f1(lx)}" cy="${cy + 5}" r="4" fill="#3B5BDB"/>`;
      s += `<text x="300" y="158" text-anchor="middle" style="font-size:11px"><tspan fill="#3B5BDB">●●</tspan> দুটিই N থেকে, H⁺ দেয় ০টি</text>`;
      if (t > 0.97) s += `<line x1="${f1(nx + 16)}" y1="${cy + 22}" x2="${f1(hpx - 10)}" y2="${cy + 22}" stroke="#E5484D" stroke-width="2" marker-end="url(#c3cv)"/><text x="300" y="178" text-anchor="middle" class="tb" style="font-size:12px">H₃N→H (তীর দিয়ে)</text>`;
      box.innerHTML = X.svg(400, 190, s, 'তুলনা');
      out.innerHTML = '<b>মূল পার্থক্য</b>: সাধারণ সমযোজী বন্ধনে দুই পরমাণু একটি করে ইলেকট্রন দেয়; সন্নিবেশ বন্ধনে একটি পরমাণু (দাতা, যার নিঃসঙ্গ যুগল আছে) দুটি ইলেকট্রনই দেয় এবং অপরটির (গ্রহীতা) একটি খালি অরবিটাল থাকে। সন্নিবেশ বন্ধনকে তীর (→) দিয়ে দাতা থেকে গ্রহীতার দিকে দেখানো হয়।';
    };
    sl.oninput = () => { cancelAnimationFrame(raf); draw(+sl.value / 100); };
    el.querySelector('[data-go]').onclick = () => { cancelAnimationFrame(raf); if (X.rm()) { sl.value = 100; draw(1); return; } const t0 = performance.now(); const st = tt => { const p = Math.min(1, (tt - t0) / 2000); sl.value = p * 100; draw(p); if (p < 1) raf = requestAnimationFrame(st); }; raf = requestAnimationFrame(st); };
    draw(0);
    return () => cancelAnimationFrame(raf);
  }
};
})();
