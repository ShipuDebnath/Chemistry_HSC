/* Chapter 3 visuals part 4 — polarisation, ionic potential, diagonal relationship, dipoles (3.15–3.16) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C3 = window.C3V;
const bn = X.bn, f1 = v => (+v).toFixed(1);
const INK = '#1b1b1f';
const CPK = C3.CPK;

/* ======================= ৩.১৫.১ ফাজানের নীতি: পোলারায়ন ======================= */
const CAT = { 'Cs⁺': [1, 167, 0], 'Na⁺': [1, 102, 0], 'Li⁺': [1, 76, 0], 'Mg²⁺': [2, 72, 0], 'Be²⁺': [2, 45, 0], 'Al³⁺': [3, 53.5, 0], 'Ag⁺': [1, 115, 1], 'Cu⁺': [1, 77, 1] };
const ANI = { 'F⁻': [133, 1.0], 'Cl⁻': [181, 3.7], 'Br⁻': [196, 4.8], 'I⁻': [220, 7.1] }; // radius pm, relative polarisability
const MP = { 'Na⁺F⁻': [993, 'NaF'], 'Na⁺Cl⁻': [801, 'NaCl'], 'Na⁺Br⁻': [747, 'NaBr'], 'Na⁺I⁻': [661, 'NaI'], 'Li⁺F⁻': [845, 'LiF'], 'Li⁺Cl⁻': [605, 'LiCl'], 'Li⁺Br⁻': [552, 'LiBr'], 'Li⁺I⁻': [469, 'LiI'], 'Cs⁺Cl⁻': [645, 'CsCl'], 'Cs⁺F⁻': [682, 'CsF'], 'Mg²⁺Cl⁻': [714, 'MgCl₂'], 'Mg²⁺F⁻': [1263, 'MgF₂'], 'Be²⁺Cl⁻': [399, 'BeCl₂'], 'Al³⁺Cl⁻': [192, 'AlCl₃ (চাপে; ১৮০ °C এ ঊর্ধ্বপাতিত)'], 'Al³⁺F⁻': [1290, 'AlF₃ (ঊর্ধ্বপাতিত)'], 'Ag⁺Cl⁻': [455, 'AgCl'], 'Ag⁺Br⁻': [432, 'AgBr'], 'Ag⁺I⁻': [558, 'AgI'], 'Cu⁺Cl⁻': [423, 'CuCl'], 'Na⁺': 0 };
V.c3_fajans = {
  t: 'ফাজানের নীতি: ক্যাটায়ন অ্যানায়নের ইলেকট্রন মেঘ বিকৃত করে', k: ['2d', 'int'],
  cap: 'ক্যাটায়ন ও অ্যানায়ন বেছে নাও। আয়নগুলো প্রকৃত আকারের অনুপাতে আঁকা। ক্যাটায়ন যত ছোট ও উচ্চ চার্জের (বেশি পোলারায়ন ক্ষমতা) এবং অ্যানায়ন যত বড় (বেশি পোলারায়নযোগ্য), অ্যানায়নের ইলেকট্রন মেঘ তত বেশি ক্যাটায়নের দিকে টেনে আসে — দুই আয়নের মাঝে ইলেকট্রন ঘনত্ব জমে, যা সমযোজী বন্ধনের বৈশিষ্ট্য। Ag⁺ ও Cu⁺ এর ছদ্ম-নিষ্ক্রিয় গ্যাস বিন্যাস (d¹⁰) d ইলেকট্রনের দুর্বল আবরণের জন্য একই আকারের Na⁺ এর চেয়ে বেশি পোলারায়ন করে। মিটার একটি তুলনামূলক সূচক মাত্র; গলনাঙ্ক প্রকৃত মান।',
  html: () => `<div class="ctl" style="margin:0 0 4px"><label style="flex:none;min-width:70px">ক্যাটায়ন</label>${X.seg('c', Object.keys(CAT).map(k => [k, k]), 'Na⁺')}</div><div class="ctl" style="margin:0 0 6px"><label style="flex:none;min-width:70px">অ্যানায়ন</label>${X.seg('a', Object.keys(ANI).map(k => [k, k]), 'Cl⁻')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let c = 'Na⁺', a = 'Cl⁻';
    const draw = () => {
      const [z, rc, ps] = CAT[c], [ra, al] = ANI[a];
      const phi = z / rc, pol = phi * 100 * (ps ? 1.8 : 1) * Math.sqrt(al);
      const sc = 0.32, Rc = rc * sc, Ra = ra * sc, gap = 6, cxC = 200 - (Rc + Ra + gap) / 2 + Rc * 0.2, cxA = cxC + Rc + Ra + gap, cy = 92;
      const k = Math.min(0.42, pol / 22); // distortion
      let d = ''; for (let i = 0; i <= 72; i++) { const th = i / 72 * 2 * Math.PI; const toward = Math.cos(th - Math.PI); const r = Ra * (1 + k * Math.max(0, toward) ** 1.6 - k * 0.18 * Math.max(0, -toward)); d += (i ? 'L' : 'M') + f1(cxA + r * Math.cos(th)) + ' ' + f1(cy + r * Math.sin(th) * (1 - k * 0.15 * Math.max(0, toward))); }
      let s = `<defs><radialGradient id="c3fjA" cx="${(0.5 - k * 0.45).toFixed(2)}" cy="0.5" r="0.62"><stop offset="0" stop-color="#5BAED9" stop-opacity=".75"/><stop offset="1" stop-color="#5BAED9" stop-opacity=".2"/></radialGradient><radialGradient id="c3fjC"><stop offset="0" stop-color="#F3A483"/><stop offset="1" stop-color="#E0603C"/></radialGradient>${X.arrowC('c3fja', '#E0603C')}</defs>`;
      // undistorted reference outline
      s += `<circle cx="${f1(cxA)}" cy="${cy}" r="${f1(Ra)}" fill="none" class="s-mu" stroke-dasharray="3 3" opacity=".7"/>`;
      s += `<path d="${d}Z" fill="url(#c3fjA)" stroke="#2F86D6" stroke-width="1.2"/>`;
      if (k > 0.05) s += `<ellipse cx="${f1(cxC + Rc + gap / 2)}" cy="${cy}" rx="${f1(4 + k * 18)}" ry="${f1(6 + k * 22)}" fill="#2F6FB5" opacity="${(k * 1.4).toFixed(2)}"/>`;
      s += `<circle cx="${f1(cxC)}" cy="${cy}" r="${f1(Rc)}" fill="url(#c3fjC)" stroke="#B9472A"/><text x="${f1(cxC)}" y="${cy + 5}" text-anchor="middle" style="font-size:${Rc < 18 ? 11 : 14}px;font-weight:700;fill:${INK}">${c}</text><text x="${f1(cxA + Ra * 0.25)}" y="${cy + 5}" text-anchor="middle" style="font-size:15px;font-weight:700;fill:${INK}">${a}</text>`;
      if (k > 0.05) s += `<line x1="${f1(cxA - Ra * 0.15)}" y1="${cy - Ra - 8}" x2="${f1(cxC + Rc * 0.4)}" y2="${cy - Ra - 8}" stroke="#E0603C" stroke-width="1.6" marker-end="url(#c3fja)"/><text x="${f1((cxA + cxC) / 2)}" y="${cy - Ra - 13}" text-anchor="middle" style="font-size:10px;fill:#E0603C">ইলেকট্রন মেঘ টানে</text>`;
      // meter
      const mx0 = 30, mx1 = 370, my = 206, t = Math.min(1, pol / 20);
      s += `<defs><linearGradient id="c3fjm" x1="0" x2="1"><stop offset="0" stop-color="#E9775C"/><stop offset=".5" stop-color="#E9C46A"/><stop offset="1" stop-color="#5B9BD5"/></linearGradient></defs><rect x="${mx0}" y="${my}" width="${mx1 - mx0}" height="12" rx="6" fill="url(#c3fjm)"/><path d="M${f1(mx0 + t * (mx1 - mx0))} ${my - 2} l-6 -10 h12z" class="f-fg"/><text x="${mx0}" y="${my + 28}" class="tm" style="font-size:10.5px">প্রায় বিশুদ্ধ আয়নিক</text><text x="${mx1}" y="${my + 28}" text-anchor="end" class="tm" style="font-size:10.5px">সমযোজী বৈশিষ্ট্য প্রবল</text>`;
      box.innerHTML = X.svg(400, 240, s, 'ফাজানের নীতি');
      const mp = MP[c + a];
      out.innerHTML = `ক্যাটায়ন ${c}: চার্জ ${z}, ব্যাসার্ধ ${rc} pm → আয়নিক বিভব z/r = <b>${phi.toFixed(4)} pm⁻¹</b>${ps ? ' · <b>ছদ্ম-নিষ্ক্রিয় (d¹⁰) বিন্যাস</b>' : ''}<br>অ্যানায়ন ${a}: ব্যাসার্ধ ${ra} pm · আপেক্ষিক পোলারায়নযোগ্যতা ${al}${mp ? `<br>যৌগ <b>${mp[1]}</b> এর গলনাঙ্ক: <b>${mp[0]} °C</b>` : ''}<br><span class="small">${k > 0.3 ? 'তীব্র পোলারায়ন — উল্লেখযোগ্য সমযোজী বৈশিষ্ট্য: কম গলনাঙ্ক, জৈব দ্রাবকে দ্রাব্যতা, আর্দ্রবিশ্লেষণ।' : k > 0.15 ? 'মাঝারি পোলারায়ন — আংশিক সমযোজী বৈশিষ্ট্য।' : 'পোলারায়ন সামান্য — প্রধানত আয়নিক।'}</span>`;
    };
    X.onSeg(el, 'c', v => { c = v; draw(); }); X.onSeg(el, 'a', v => { a = v; draw(); }); draw();
  }
};

/* ======================= ৩.১৫.৩ আয়নিক বিভব ======================= */
const IP = [['Cs⁺', 1, 169], ['K⁺', 1, 133], ['Na⁺', 1, 95], ['Ba²⁺', 2, 135], ['Li⁺', 1, 60], ['Ca²⁺', 2, 99], ['Mg²⁺', 2, 65], ['Al³⁺', 3, 50], ['Be²⁺', 2, 31], ['B³⁺', 3, 20], ['P⁵⁺', 5, 34], ['S⁶⁺', 6, 29]];
const IPOX = { 'Cs⁺': 'CsOH — তীব্র ক্ষার', 'K⁺': 'KOH — তীব্র ক্ষার', 'Na⁺': 'NaOH — তীব্র ক্ষার', 'Ba²⁺': 'Ba(OH)₂ — তীব্র ক্ষার', 'Li⁺': 'LiOH — ক্ষার (অন্য ক্ষার ধাতুর চেয়ে দুর্বল)', 'Ca²⁺': 'Ca(OH)₂ — ক্ষার', 'Mg²⁺': 'Mg(OH)₂ — দুর্বল ক্ষার', 'Al³⁺': 'Al(OH)₃ — উভধর্মী', 'Be²⁺': 'Be(OH)₂ — উভধর্মী', 'B³⁺': 'B(OH)₃ = H₃BO₃ — দুর্বল এসিড', 'P⁵⁺': 'PO(OH)₃ = H₃PO₄ — এসিড', 'S⁶⁺': 'SO₂(OH)₂ = H₂SO₄ — তীব্র এসিড' };
V.c3_ionicPot = {
  t: 'আয়নিক বিভব (φ = z/r): পোলারায়ন ক্ষমতা ও হাইড্রক্সাইডের প্রকৃতি', k: ['2d', 'calc', 'int'],
  cap: 'স্তম্ভের দৈর্ঘ্য আয়নিক বিভব (পলিং আয়নিক ব্যাসার্ধে, Å⁻¹ এককে দেখানো, ১ Å = ১০০ pm)। কার্টলেজের নিয়মে √φ < ২.২ হলে হাইড্রক্সাইড ক্ষারীয়, ২.২–৩.২ উভধর্মী এবং > ৩.২ হলে অম্লীয় (রঙ দেখো)। কারণ: φ বেশি হলে ক্যাটায়ন M–O–H এর O থেকে ইলেকট্রন টেনে নেয়; O–H বন্ধন দুর্বল হয়ে H⁺ মুক্ত হয় (অম্লীয়)। φ কম হলে M–O বন্ধন সহজে ভাঙে, OH⁻ মুক্ত হয় (ক্ষারীয়)। এটি একটি মোটামুটি নিয়ম — কিছু ব্যতিক্রম আছে। নিচে নিজের মান দিয়ে হিসাব করো।',
  html: () => `<div data-svg></div><div class="calc-out" data-out></div><div class="small" style="margin-top:10px;font-weight:600">নিজে হিসাব করো</div><div class="grid2" style="margin-top:4px"><label class="small" style="display:block">চার্জ z<input class="inp" type="number" min="1" max="7" value="2" data-z style="width:100%;margin-top:3px"></label><label class="small" style="display:block">ব্যাসার্ধ r (pm)<input class="inp" type="number" min="10" max="200" value="65" data-r style="width:100%;margin-top:3px"></label></div><div class="calc-out" data-c></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), co = el.querySelector('[data-c]'); let sel = 7;
    const cls = sq => sq < 2.2 ? ['ক্ষারীয়', '#5B8DEF'] : sq <= 3.2 ? ['উভধর্মী', '#4CAF50'] : ['অম্লীয়', '#E5484D'];
    const draw = () => {
      const x0 = 52, x1 = 370, rh = 19, y0 = 22, mx = 21; let s = '';
      [0, 5, 10, 15, 20].forEach(v => { const x = x0 + v / mx * (x1 - x0); s += `<line x1="${f1(x)}" y1="${y0 - 4}" x2="${f1(x)}" y2="${y0 + IP.length * rh}" class="s-ln" opacity=".25"/><text x="${f1(x)}" y="${y0 + IP.length * rh + 13}" text-anchor="middle" class="tm mono" style="font-size:10px">${v}</text>`; });
      IP.forEach(([n, z, r], i) => { const phi = z / (r / 100), sq = Math.sqrt(phi), [, col] = cls(sq), y = y0 + i * rh, w = phi / mx * (x1 - x0), on = i === sel; s += `<g data-i="${i}" style="cursor:pointer"><rect x="0" y="${y}" width="400" height="${rh}" fill="transparent"/><text x="${x0 - 6}" y="${y + 13.5}" text-anchor="end" style="font-size:12px;font-weight:${on ? 700 : 500}">${n}</text><rect x="${x0}" y="${y + 3}" width="${f1(Math.min(w, x1 - x0))}" height="${rh - 6}" rx="3" fill="${col}" opacity="${on ? 1 : 0.7}" ${on ? 'stroke="var(--fg)" stroke-width="1.4"' : ''}/><text x="${f1(x0 + Math.min(w, x1 - x0) + 4)}" y="${y + 13.5}" class="mono" style="font-size:10px">${phi.toFixed(1)}</text></g>`; });
      s += `<text x="${x1}" y="${y0 + IP.length * rh + 27}" text-anchor="end" class="tm" style="font-size:10.5px">φ = z/r (Å⁻¹)</text>`;
      s += `<rect x="${x0}" y="${y0 + IP.length * rh + 18}" width="10" height="10" rx="2" fill="#5B8DEF"/><text x="${x0 + 14}" y="${y0 + IP.length * rh + 27}" class="tm" style="font-size:10px">ক্ষারীয়</text><rect x="${x0 + 60}" y="${y0 + IP.length * rh + 18}" width="10" height="10" rx="2" fill="#4CAF50"/><text x="${x0 + 74}" y="${y0 + IP.length * rh + 27}" class="tm" style="font-size:10px">উভধর্মী</text><rect x="${x0 + 124}" y="${y0 + IP.length * rh + 18}" width="10" height="10" rx="2" fill="#E5484D"/><text x="${x0 + 138}" y="${y0 + IP.length * rh + 27}" class="tm" style="font-size:10px">অম্লীয়</text>`;
      box.innerHTML = X.svg(400, y0 + IP.length * rh + 34, s, 'আয়নিক বিভব');
      const [n, z, r] = IP[sel], phi = z / r, sq = Math.sqrt(z / (r / 100));
      out.innerHTML = `<b>${n}</b>: φ = ${z}/${r} pm = <b>${phi.toFixed(4)} pm⁻¹</b> (= ${(z / (r / 100)).toFixed(2)} Å⁻¹, √φ = ${sq.toFixed(2)})<br>হাইড্রক্সাইড: <b>${IPOX[n]}</b>`;
    };
    const calc = () => { const z = +el.querySelector('[data-z]').value, r = +el.querySelector('[data-r]').value; if (!(z > 0 && r > 0)) return; const phi = z / r, sq = Math.sqrt(z / (r / 100)), [c] = cls(sq); co.innerHTML = `φ = ${z}/${r} = <b>${phi.toFixed(4)} pm⁻¹</b> · √φ(Å) = ${sq.toFixed(2)} → হাইড্রক্সাইড সম্ভবত <b>${c}</b>`; };
    box.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g) { sel = +g.dataset.i; draw(); } });
    el.querySelectorAll('[data-z],[data-r]').forEach(i => i.oninput = calc);
    draw(); calc();
  }
};

/* ======================= ৩.১৬ কর্ণ সম্পর্ক ======================= */
const DG = { Li: [152, 0.98, 1, 60, 'Li'], Be: [112, 1.57, 2, 31], B: [88, 2.04, 3, 20], C: [77, 2.55], Na: [186, 0.93, 1, 95], Mg: [160, 1.31, 2, 65], Al: [143, 1.61, 3, 50], Si: [117, 1.90, 4, 41] };
const DGP = { Li: ['Mg', 'Na', ['N₂ এর সাথে সরাসরি নাইট্রাইড (Li₃N, Mg₃N₂)', 'O₂ তে পুড়ে শুধু সাধারণ অক্সাইড (Li₂O, MgO)', 'কার্বনেট ও নাইট্রেট তাপে বিয়োজিত', 'ক্লোরাইড জৈব দ্রাবকে দ্রবণীয়, আর্দ্রতাগ্রাহী', 'ফ্লোরাইড, কার্বনেট, ফসফেট স্বল্প দ্রবণীয়']], Be: ['Al', 'Mg', ['অক্সাইড ও হাইড্রক্সাইড উভধর্মী', 'ক্লোরাইড সমযোজী, সেতুবন্ধনযুক্ত, লুইস এসিড', 'ক্ষারের সাথে H₂ দেয়', 'গাঢ় HNO₃ এ নিষ্ক্রিয়', 'কার্বাইড পানির সাথে CH₄ দেয়']], B: ['Si', 'Al', ['উভয়ই ধাতুকল্প, অর্ধপরিবাহী, উচ্চ গলনাঙ্ক', 'অক্সাইড অম্লীয় দানবীয় জালক (B₂O₃, SiO₂)', 'অনেক উদ্বায়ী হাইড্রাইড (বোরেন, সিলেন)', 'ক্লোরাইড পানিতে আর্দ্রবিশ্লেষিত', 'অত্যন্ত কঠিন কার্বাইড (B₄C, SiC)']] };
V.c3_diagonal = {
  t: 'কর্ণ সম্পর্ক: Li–Mg, Be–Al, B–Si', k: ['2d', 'int'],
  cap: 'পর্যায় সারণির খণ্ডে তীরগুলো কর্ণ সম্পর্ক দেখায়। একটি জোড়া বেছে নাও — নিচে তিনটি ধর্ম (পারমাণবিক ব্যাসার্ধ, তড়িৎ ঋণাত্মকতা ও আয়নিক বিভব) কর্ণ-সঙ্গী এবং নিজ গ্রুপের সদস্যের সাথে পাশাপাশি তুলনা করা হয়েছে। লক্ষ করো, কর্ণ-সঙ্গীর মান নিজ গ্রুপের সদস্যের চেয়ে প্রায়শই বেশি কাছাকাছি। কারণ: ডানে গেলে আকার কমে ও EN বাড়ে, নিচে গেলে আকার বাড়ে ও EN কমে — কোণাকুণি গেলে দুটি পরিবর্তন প্রায় কাটাকাটি হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('p', [['Li', 'Li – Mg'], ['Be', 'Be – Al'], ['B', 'B – Si']], 'Be')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = p => {
      const [dia, grp, sim] = DGP[p]; let s = `<defs>${X.arrowC('c3dg', '#E5484D')}${X.arrowC('c3dg2', '#9AA0A6')}</defs>`;
      const els = [['Li', 'Be', 'B', 'C'], ['Na', 'Mg', 'Al', 'Si']], cw = 62, ch = 48, ox = 76, oy = 16;
      ['১', '২', '১৩', '১৪'].forEach((g, j) => s += `<text x="${ox + j * cw + cw / 2}" y="${oy - 4}" text-anchor="middle" class="tm" style="font-size:10px">গ্রুপ ${g}</text>`);
      els.forEach((row, i) => { s += `<text x="${ox - 8}" y="${oy + i * ch + ch / 2 + 4}" text-anchor="end" class="tm" style="font-size:10px">পর্যায় ${['২', '৩'][i]}</text>`; row.forEach((e, j) => { const on = e === p || e === dia, gr = e === grp; s += `<rect x="${ox + j * cw + 2}" y="${oy + i * ch + 2}" width="${cw - 4}" height="${ch - 4}" rx="6" fill="${on ? '#F3B38C' : gr ? 'var(--surface-3)' : 'var(--surface-2)'}" ${on ? 'stroke="#E5484D" stroke-width="2"' : ''}/><text x="${ox + j * cw + cw / 2}" y="${oy + i * ch + ch / 2 + 6}" text-anchor="middle" style="font-size:17px;font-weight:700;fill:${on ? INK : 'var(--fg)'}">${e}</text>`; }); });
      [['Li', 0], ['Be', 1], ['B', 2]].forEach(([e, j]) => { const on = e === p; s += `<line x1="${ox + j * cw + cw - 10}" y1="${oy + ch - 8}" x2="${ox + (j + 1) * cw + 12}" y2="${oy + ch + 12}" stroke="${on ? '#E5484D' : '#9AA0A6'}" stroke-width="${on ? 2.4 : 1.4}" marker-end="url(#${on ? 'c3dg' : 'c3dg2'})"/>`; });
      // property comparison bars
      const props = [['ব্যাসার্ধ (pm)', 0, 200], ['তড়িৎ ঋণাত্মকতা', 1, 2.6]];
      if (DG[p][3]) props.push(['আয়নিক বিভব z/r (pm⁻¹)', 'phi', 0.07]);
      let y = oy + 2 * ch + 22;
      props.forEach(([lab, k, mx]) => {
        s += `<text x="10" y="${y}" style="font-size:11px;font-weight:700">${lab}</text>`; y += 6;
        [[p, '#E5484D'], [dia, '#F08A24'], [grp, '#9AA0A6']].forEach(([e, col]) => {
          const D = DG[e]; const v = k === 'phi' ? D[2] / D[3] : D[k]; const w = v / mx * 250;
          s += `<text x="44" y="${y + 11}" text-anchor="end" style="font-size:11.5px;font-weight:600">${e}</text><rect x="50" y="${y + 1}" width="${f1(w)}" height="12" rx="3" fill="${col}" opacity=".85"/><text x="${f1(54 + w)}" y="${y + 11}" class="mono" style="font-size:10px">${k === 'phi' ? v.toFixed(4) : v}</text>`; y += 16;
        });
        y += 12;
      });
      s += `<text x="10" y="${y}" class="tm" style="font-size:10px"><tspan fill="#E5484D">■</tspan> মৌল  <tspan fill="#F08A24">■</tspan> কর্ণ-সঙ্গী  <tspan fill="#9AA0A6">■</tspan> নিজ গ্রুপের পরের সদস্য</text>`;
      box.innerHTML = X.svg(400, y + 8, s, 'কর্ণ সম্পর্ক');
      out.innerHTML = `<b>${p} ও ${dia} এর সাদৃশ্য</b><ul class="pts" style="margin:4px 0 0">${sim.map(x => `<li>${x}</li>`).join('')}</ul>`;
    };
    X.onSeg(el, 'p', draw); draw('Be');
  }
};

/* ======================= ৩.১৬ পরীক্ষা: পানির ধারা ======================= */
const WL = { w: ['পানি (H₂O)', 1.85, 'rgba(120,180,235,.85)'], e: ['ইথানল', 1.69, 'rgba(160,200,235,.85)'], c: ['ক্লোরোফর্ম', 1.04, 'rgba(200,215,235,.85)'], t: ['CCl₄', 0, 'rgba(210,210,220,.9)'], h: ['হেক্সেন', 0, 'rgba(225,225,210,.9)'] };
V.c3_waterStream = {
  t: 'পরীক্ষা: চার্জিত দণ্ডের কাছে তরলের ধারা (পানির ডাইপোল প্রমাণ)', k: ['anim', 'int'],
  cap: 'তরল ও দণ্ড বেছে নাও। পোলার তরলের ধারা দণ্ডের দিকে বেঁকে যায়, অপোলার CCl₄ বা হেক্সেনের ধারা সোজা পড়ে। ডান দিকের বড় করা বৃত্তে দেখো দণ্ডের পাশে অণুগুলো কীভাবে ঘুরে দাঁড়ায়: ধনাত্মক (কাচ) দণ্ডের দিকে O (δ⁻) প্রান্ত, ঋণাত্মক (এবোনাইট) দণ্ডের দিকে H (δ⁺) প্রান্ত — দুই ক্ষেত্রেই কাছের প্রান্ত বিপরীত চার্জের, তাই সবসময় আকর্ষণ। বাঁকের পরিমাণ এখানে ডাইপোল মোমেন্টের অনুপাতে আনুমানিকভাবে দেখানো।',
  html: () => `<div class="ctl" style="margin:0 0 4px"><label style="flex:none;min-width:48px">তরল</label>${X.seg('l', Object.keys(WL).map(k => [k, WL[k][0]]), 'w')}</div><div class="ctl" style="margin:0 0 6px"><label style="flex:none;min-width:48px">দণ্ড</label>${X.seg('r', [['n', 'কোনো দণ্ড নেই'], ['p', 'কাচ + রেশম (+)'], ['m', 'এবোনাইট + পশম (−)']], 'p')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let l = 'w', r = 'p', bend = 0, raf = 0, ph = 0, last = 0;
    const tgt = () => r === 'n' ? 0 : WL[l][1] / 1.85;
    const draw = () => {
      const [nm, mu, col] = WL[l]; const bx = 110, top = 64, bot = 262;
      let s = `<defs><clipPath id="c3bur"><rect x="${bx - 9}" y="8" width="18" height="44"/></clipPath><linearGradient id="c3rod" x1="0" x2="1"><stop offset="0" stop-color="${r === 'm' ? '#3a3a3a' : '#cfe3ea'}"/><stop offset=".5" stop-color="${r === 'm' ? '#6a6a6a' : '#f3fbfd'}"/><stop offset="1" stop-color="${r === 'm' ? '#2a2a2a' : '#b9d3dc'}"/></linearGradient></defs>`;
      // stand + burette
      s += `<rect x="40" y="4" width="6" height="270" class="f-s3"/><rect x="24" y="270" width="160" height="8" rx="2" class="f-s3"/><line x1="46" y1="30" x2="${bx - 10}" y2="30" class="s-mu" stroke-width="4"/>`;
      s += `<rect x="${bx - 9}" y="0" width="18" height="52" rx="2" fill="none" class="s-fg" stroke-width="1.5"/><rect x="${bx - 8}" y="10" width="16" height="42" fill="${col}" clip-path="url(#c3bur)"/><path d="M${bx - 9} 52 L${bx - 3} 60 L${bx + 3} 60 L${bx + 9} 52" fill="none" class="s-fg" stroke-width="1.5"/><rect x="${bx - 12}" y="44" width="24" height="5" rx="1.5" class="f-mu"/>`;
      // beaker
      s += `<path d="M${bx - 34} 230 L${bx - 34} 266 Q${bx - 34} 270 ${bx - 30} 270 L${bx + 70} 270 Q${bx + 74} 270 ${bx + 74} 266 L${bx + 74} 230" fill="none" class="s-fg" stroke-width="1.5"/><rect x="${bx - 33}" y="252" width="106" height="17" fill="${col}" opacity=".6"/>`;
      // stream: quadratic toward rod
      const dx = 46 * bend; const sx = bx, ex = bx + dx * 0.95; const cx1 = bx, cy1 = 160;
      const path = `M${sx} ${top} Q${f1(sx + dx * 0.05)} ${f1(cy1 - 20)} ${f1(sx + dx * 0.55)} 175 T${f1(ex)} 252`;
      s += `<path d="${path}" fill="none" stroke="${col}" stroke-width="4.5" stroke-linecap="round"/><path d="${path}" fill="none" stroke="rgba(255,255,255,.75)" stroke-width="1.6" stroke-dasharray="3 14" stroke-dashoffset="${f1(-ph)}"/>`;
      // rod
      if (r !== 'n') { s += `<g transform="rotate(-18 ${bx + 70} 150)"><rect x="${bx + 52}" y="120" width="16" height="110" rx="7" fill="url(#c3rod)" stroke="rgba(0,0,0,.35)"/>`; for (let i = 0; i < 5; i++) s += `<text x="${bx + 60}" y="${136 + i * 20}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:${r === 'p' ? '#C9373C' : '#7FB2FF'}">${r === 'p' ? '+' : '−'}</text>`; s += `</g><text x="${bx + 86}" y="106" style="font-size:10.5px" class="tm">${r === 'p' ? 'কাচদণ্ড (+)' : 'এবোনাইট দণ্ড (−)'}</text>`; }
      // magnifier inset
      const mx = 318, my = 150, mr = 70;
      s += `<line x1="${f1(bx + dx * 0.6 + 6)}" y1="172" x2="${mx - mr + 6}" y2="${my}" class="s-mu" stroke-dasharray="3 3"/><circle cx="${mx}" cy="${my}" r="${mr}" class="f-sf s-fg" stroke-width="1.6"/>`;
      if (r !== 'n') s += `<rect x="${mx + mr - 22}" y="${my - 52}" width="10" height="104" rx="4" fill="url(#c3rod)" opacity=".9"/>${[0, 1, 2, 3].map(i => `<text x="${mx + mr - 17}" y="${my - 34 + i * 24}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:${r === 'p' ? '#C9373C' : '#7FB2FF'}">${r === 'p' ? '+' : '−'}</text>`).join('')}`;
      const polar = mu > 0;
      [[-28, -34], [8, -40], [-36, 4], [0, 0], [-24, 38], [12, 36]].forEach(([ox, oy], i) => {
        const x = mx + ox, y = my + oy;
        let ang;
        if (!polar || r === 'n') ang = (i * 73) % 360; else ang = r === 'p' ? 0 : 180; // 0 → O (δ−) points right (toward rod)
        if (polar && r !== 'n') ang += (i % 2 ? 8 : -8);
        if (l === 'w' || l === 'e' || l === 'c') {
          s += `<g transform="translate(${x} ${y}) rotate(${ang})"><circle cx="5" cy="0" r="8" fill="${CPK.O}"/><circle cx="-4" cy="-7" r="5" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><circle cx="-4" cy="7" r="5" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/></g>`;
          if (polar && r !== 'n' && i === 3) s += `<text x="${x + (r === 'p' ? 16 : -18)}" y="${y - 10}" style="font-size:10px;font-weight:700;fill:#2F86D6">δ⁻</text><text x="${x + (r === 'p' ? -20 : 14)}" y="${y - 10}" style="font-size:10px;font-weight:700;fill:#E8775C">δ⁺</text>`;
        } else {
          s += `<g transform="translate(${x} ${y}) rotate(${ang})"><circle cx="0" cy="0" r="7" fill="${l === 't' ? CPK.C : CPK.C}"/>${l === 't' ? [0, 1, 2, 3].map(k => `<circle cx="${f1(10 * Math.cos(k * 1.571 + 0.4))}" cy="${f1(10 * Math.sin(k * 1.571 + 0.4))}" r="5.5" fill="${CPK.Cl}"/>`).join('') : `<circle cx="-12" cy="0" r="6" fill="${CPK.C}"/><circle cx="12" cy="0" r="6" fill="${CPK.C}"/>`}</g>`;
        }
      });
      s += `<text x="${mx}" y="${my + mr + 16}" text-anchor="middle" class="tm" style="font-size:10.5px">বড় করে দেখানো: দণ্ডের পাশের অণু</text>`;
      box.innerHTML = X.svg(400, 282, s, 'পানির ধারা');
    };
    const msg = () => { const [nm, mu] = WL[l]; out.innerHTML = r === 'n' ? `দণ্ড নেই — <b>${nm}</b> এর ধারা সোজা নিচে পড়ছে।` : mu > 0 ? `<b>${nm}</b> (μ = ${mu} D) এর ধারা <b>দণ্ডের দিকে বেঁকে যাচ্ছে</b> — অণুগুলো পোলার; ${r === 'p' ? 'δ⁻ প্রান্ত ধনাত্মক দণ্ডের দিকে' : 'δ⁺ প্রান্ত ঋণাত্মক দণ্ডের দিকে'} সজ্জিত হয়ে আকৃষ্ট হয়।` : `<b>${nm}</b> (μ = 0) এর ধারা <b>সোজা পড়ছে</b> — অপোলার অণু; সজ্জিত হওয়ার মতো স্থায়ী ডাইপোল নেই।`; };
    const tick = t => { const dt = last ? Math.min(0.05, (t - last) / 1000) : 0.016; last = t; bend += (tgt() - bend) * Math.min(1, dt * 3); ph += dt * 60; draw(); raf = requestAnimationFrame(tick); };
    X.onSeg(el, 'l', k => { l = k; msg(); if (X.rm()) { bend = tgt(); draw(); } }); X.onSeg(el, 'r', k => { r = k; msg(); if (X.rm()) { bend = tgt(); draw(); } });
    msg();
    if (X.rm()) { bend = tgt(); draw(); } else raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }
};

/* ======================= ৩.১৬.১ ডাইপোল মোমেন্ট: ভেক্টর যোগ ======================= */
// 2D drawing of molecules with bond dipole vectors; each: atoms [el,x,y], bonds [i,j], bdip [[from,to,mag]] arrows point δ+ → δ−, lp [[i,angle]], mu
const DM = {
  CO2: { n: 'CO₂', a: [['C', 0, 0], ['O', -70, 0], ['O', 70, 0]], b: [[0, 1, 2], [0, 2, 2]], d: [[0, 1, 1], [0, 2, 1]], lp: [], mu: 0, t: 'রৈখিক: দুটি সমান C=O ডাইপোল বিপরীতমুখী — লব্ধি শূন্য।' },
  H2O: { n: 'H₂O', a: [['O', 0, -14], ['H', -52, 26], ['H', 52, 26]], b: [[0, 1, 1], [0, 2, 1]], d: [[1, 0, 1], [2, 0, 1]], lp: [[0, -125], [0, -55]], mu: 1.85, t: 'কৌণিক (104.5°): দুটি O–H ডাইপোলের উল্লম্ব উপাংশ যোগ হয়, অনুভূমিক উপাংশ বাতিল — লব্ধি O এর দিকে, 1.85 D।' },
  SO2: { n: 'SO₂', a: [['S', 0, -12], ['O', -60, 22], ['O', 60, 22]], b: [[0, 1, 2], [0, 2, 2]], d: [[0, 1, 1], [0, 2, 1]], lp: [[0, -90]], mu: 1.63, t: 'কৌণিক (119°): S এর নিঃসঙ্গ যুগল — ডাইপোল বাতিল হয় না, লব্ধি O গুলোর দিকে (নিচে), 1.63 D।' },
  BF3: { n: 'BF₃', a: [['B', 0, 0], ['F', 0, -66], ['F', -57, 33], ['F', 57, 33]], b: [[0, 1, 1], [0, 2, 1], [0, 3, 1]], d: [[0, 1, 1], [0, 2, 1], [0, 3, 1]], lp: [], mu: 0, t: 'ত্রিকোণীয় সমতলীয় (120°): তিনটি সমান ডাইপোলের ভেক্টর যোগফল শূন্য।' },
  NH3: { n: 'NH₃', a: [['N', 0, -14], ['H', -54, 24], ['H', 54, 24], ['H', 0, 42]], b: [[0, 1, 1], [0, 2, 1], [0, 3, 1]], d: [[1, 0, 1], [2, 0, 1], [3, 0, 1]], lp: [[0, -90]], mu: 1.47, t: 'পিরামিড: N–H ডাইপোল (H → N) নিঃসঙ্গ যুগলের দিকে — একই দিকে যোগ হয়, 1.47 D।' },
  NF3: { n: 'NF₃', a: [['N', 0, -14], ['F', -56, 24], ['F', 56, 24], ['F', 0, 44]], b: [[0, 1, 1], [0, 2, 1], [0, 3, 1]], d: [[0, 1, 1], [0, 2, 1], [0, 3, 1]], lp: [[0, -90]], mu: 0.23, t: 'পিরামিড: N–F ডাইপোল (N → F) নিঃসঙ্গ যুগলের বিপরীতে — প্রায় বাতিল, মাত্র 0.23 D।' },
  CCl4: { n: 'CCl₄', a: [['C', 0, 0], ['Cl', 0, -68], ['Cl', -62, 30], ['Cl', 62, 30], ['Cl', 0, 34]], b: [[0, 1, 1], [0, 2, 1], [0, 3, 1], [0, 4, 1]], d: [[0, 1, 1], [0, 2, 1], [0, 3, 1], [0, 4, 0.6]], lp: [], mu: 0, t: 'চতুস্তলক (দ্বিমাত্রিক অভিক্ষেপ): চারটি সমান C–Cl ডাইপোলের যোগফল শূন্য।' },
  CHCl3: { n: 'CHCl₃', a: [['C', 0, 0], ['H', 0, -58], ['Cl', -62, 30], ['Cl', 62, 30], ['Cl', 0, 34]], b: [[0, 1, 1], [0, 2, 1], [0, 3, 1], [0, 4, 1]], d: [[1, 0, 0.4], [0, 2, 1], [0, 3, 1], [0, 4, 0.6]], lp: [], mu: 1.04, t: 'একটি Cl এর জায়গায় H — প্রতিসাম্য নষ্ট, লব্ধি Cl গুলোর দিকে, 1.04 D।' },
  cis: { n: 'cis-C₂H₂Cl₂', a: [['C', -26, 0], ['C', 26, 0], ['Cl', -60, 44], ['Cl', 60, 44], ['H', -56, -36], ['H', 56, -36]], b: [[0, 1, 2], [0, 2, 1], [1, 3, 1], [0, 4, 1], [1, 5, 1]], d: [[0, 2, 1], [1, 3, 1]], lp: [], mu: 1.90, t: 'cis: দুটি C–Cl ডাইপোল একই দিকে (নিচে) হেলে — লব্ধি 1.90 D।' },
  trans: { n: 'trans-C₂H₂Cl₂', a: [['C', -26, 0], ['C', 26, 0], ['Cl', -60, 44], ['Cl', 60, -44], ['H', -56, -36], ['H', 56, 36]], b: [[0, 1, 2], [0, 2, 1], [1, 3, 1], [0, 4, 1], [1, 5, 1]], d: [[0, 2, 1], [1, 3, 1]], lp: [], mu: 0, t: 'trans: দুটি C–Cl ডাইপোল সমান ও বিপরীতমুখী — লব্ধি শূন্য।' }
};
V.c3_dipole = {
  t: 'ডাইপোল মোমেন্ট: বন্ধন ডাইপোলের ভেক্টর যোগ', k: ['2d', 'int', 'calc'],
  cap: '"অণু" দৃশ্যে ছোট কালো তীর (✚→) প্রতিটি বন্ধন-ডাইপোল (δ⁺ থেকে δ⁻ এর দিকে), আর মোটা লাল তীর অণুর লব্ধি ডাইপোল মোমেন্ট। কমলা খণ্ড নিঃসঙ্গ যুগল। "হিসাব" দৃশ্যে AX₂ ধরনের অণুর বন্ধন কোণ বদলাও — μ = 2μ₁cos(θ/২) সূত্রে লব্ধি কীভাবে 180° এ শূন্য হয় এবং কোণ কমলে বাড়ে তা লেখচিত্রে দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['mol', 'অণু'], ['calc', 'হিসাব: μ = 2μ₁cos(θ/২)']], 'mol')}</div><div data-body></div>`,
  mount(el) {
    const body = el.querySelector('[data-body]');
    const vec = (x1, y1, x2, y2, col, w, id) => `<line x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}" stroke="${col}" stroke-width="${w}" marker-end="url(#${id})"/>`;
    const mol = () => {
      body.innerHTML = `<div class="ctl" style="margin:0 0 6px">${X.seg('k', Object.keys(DM).map(k => [k, DM[k].n]), 'H2O')}</div><div data-svg></div><div class="calc-out" data-out></div>`;
      const box = body.querySelector('[data-svg]'), out = body.querySelector('[data-out]');
      const draw = k => {
        const D = DM[k], cx = 200, cy = 100; let s = `<defs>${X.arrow('c3dpa')}${X.arrowC('c3dpr', '#E5484D')}</defs>`;
        D.lp.forEach(([i, ang]) => { const a = D.a[i], r = ang * Math.PI / 180, x = cx + a[1], y = cy + a[2]; const c = Math.cos(r), sn = Math.sin(r); s += `<ellipse cx="${f1(x + c * 26)}" cy="${f1(y + sn * 26)}" rx="20" ry="11" transform="rotate(${ang} ${f1(x + c * 26)} ${f1(y + sn * 26)})" fill="rgba(255,175,70,.45)" stroke="rgba(214,130,30,.85)"/>`; });
        D.b.forEach(([i, j, o]) => { const A = D.a[i], B = D.a[j]; const x1 = cx + A[1], y1 = cy + A[2], x2 = cx + B[1], y2 = cy + B[2]; const L = Math.hypot(x2 - x1, y2 - y1), nx = -(y2 - y1) / L, ny = (x2 - x1) / L; (o === 2 ? [-3.5, 3.5] : [0]).forEach(dd => s += `<line x1="${f1(x1 + nx * dd)}" y1="${f1(y1 + ny * dd)}" x2="${f1(x2 + nx * dd)}" y2="${f1(y2 + ny * dd)}" class="s-fg" stroke-width="2"/>`); });
        D.a.forEach(([e, x, y]) => s += `<circle cx="${cx + x}" cy="${cy + y}" r="${e === 'H' ? 11 : 15}" fill="${CPK[e]}" stroke="rgba(0,0,0,.3)"/><text x="${cx + x}" y="${cy + y + 4.5}" text-anchor="middle" style="font-size:${e.length > 1 ? 11 : 13}px;font-weight:700;fill:${['C', 'N', 'O', 'Cl'].includes(e) ? '#fff' : INK}">${e}</text>`);
        // bond dipole arrows, offset beside the bond
        D.d.forEach(([i, j, m]) => { const A = D.a[i], B = D.a[j]; let x1 = cx + A[1], y1 = cy + A[2], x2 = cx + B[1], y2 = cy + B[2]; const L = Math.hypot(x2 - x1, y2 - y1), ux = (x2 - x1) / L, uy = (y2 - y1) / L, nx = -uy, ny = ux, off = 15; const sx = x1 + ux * L * 0.22 + nx * off, sy = y1 + uy * L * 0.22 + ny * off, ex = x1 + ux * L * (0.22 + 0.55 * m) + nx * off, ey = y1 + uy * L * (0.22 + 0.55 * m) + ny * off; s += vec(sx, sy, ex, ey, 'var(--fg)', 1.6, 'c3dpa') + `<line x1="${f1(sx + ux * 5 - nx * 4)}" y1="${f1(sy + uy * 5 - ny * 4)}" x2="${f1(sx + ux * 5 + nx * 4)}" y2="${f1(sy + uy * 5 + ny * 4)}" class="s-fg" stroke-width="1.6"/>`; });
        // resultant
        if (D.mu > 0) { const dir = k === 'SO2' || k === 'CHCl3' || k === 'cis' ? 1 : -1; const len = 22 + D.mu * 26, x0 = 330; s += vec(x0, 100 - dir * len / 2, x0, 100 + dir * len / 2, '#E5484D', 4, 'c3dpr') + `<line x1="${x0 - 6}" y1="${f1(100 - dir * len / 2 + dir * 8)}" x2="${x0 + 6}" y2="${f1(100 - dir * len / 2 + dir * 8)}" stroke="#E5484D" stroke-width="3"/><text x="${x0}" y="${f1(100 + dir * len / 2 + dir * 16 + (dir > 0 ? 4 : 0))}" text-anchor="middle" style="font-size:11.5px;font-weight:700;fill:#E5484D">μ = ${D.mu} D</text>`; }
        else s += `<text x="330" y="104" text-anchor="middle" style="font-size:13px;font-weight:700;fill:#2BB24C">μ = 0</text>`;
        s += `<text x="330" y="${D.mu > 0 ? 34 : 84}" text-anchor="middle" class="tm" style="font-size:10px">লব্ধি</text>`;
        box.innerHTML = X.svg(400, 190, s, 'ডাইপোল');
        out.innerHTML = `<b>${D.n}</b>: ${D.t}<br><span class="small">${D.mu > 0 ? 'পোলার অণু' : 'অপোলার অণু (বন্ধন পোলার হলেও)'}</span>`;
      };
      X.onSeg(body, 'k', draw); draw('H2O');
    };
    const calc = () => {
      body.innerHTML = `<div class="ctl" style="margin:0"><label style="flex:none">বন্ধন কোণ θ</label><input type="range" min="60" max="180" value="104.5" step="0.5" data-th style="flex:1"><span class="mono" data-tv style="min-width:56px;text-align:right"></span></div><div class="ctl" style="margin:0"><label style="flex:none">বন্ধন-ডাইপোল μ₁ (D)</label><input class="inp" type="number" min="0.1" max="3" step="0.01" value="1.51" data-m1 style="width:90px"></div><div data-svg></div><div class="calc-out" data-out></div>`;
      const box = body.querySelector('[data-svg]'), out = body.querySelector('[data-out]'), th = body.querySelector('[data-th]'), m1 = body.querySelector('[data-m1]');
      const run = () => {
        const t = +th.value, u = +m1.value || 1.51, mu = 2 * u * Math.cos(t / 2 * Math.PI / 180);
        body.querySelector('[data-tv]').textContent = t + '°';
        let s = `<defs>${X.arrow('c3dq')}${X.arrowC('c3dqr', '#E5484D')}</defs>`;
        // vector diagram
        const cx = 100, cy = 70, L = 52, h = t / 2 * Math.PI / 180;
        const ax = cx - Math.sin(h) * L, ay = cy + Math.cos(h) * L, bx = cx + Math.sin(h) * L, by = cy + Math.cos(h) * L;
        s += `<line x1="${cx}" y1="${cy}" x2="${f1(ax)}" y2="${f1(ay)}" class="s-fg" stroke-width="2"/><line x1="${cx}" y1="${cy}" x2="${f1(bx)}" y2="${f1(by)}" class="s-fg" stroke-width="2"/><circle cx="${cx}" cy="${cy}" r="12" fill="${CPK.O}"/><circle cx="${f1(ax)}" cy="${f1(ay)}" r="8" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><circle cx="${f1(bx)}" cy="${f1(by)}" r="8" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/>`;
        // vectors from H to O drawn from origin as tail-to-tail summation below
        const sc = 30, vx = Math.sin(h) * u * sc, vy = -Math.cos(h) * u * sc, ox = 100, oy = 214;
        s += vec(ox, oy, ox + vx, oy + vy, 'var(--fg)', 1.6, 'c3dq') + vec(ox + vx, oy + vy, ox + vx - vx, oy + 2 * vy, 'var(--fg)', 1.6, 'c3dq');
        s += `<line x1="${ox}" y1="${oy}" x2="${ox}" y2="${f1(oy + 2 * vy)}" stroke="#E5484D" stroke-width="3.2" ${Math.abs(mu) > 0.02 ? 'marker-end="url(#c3dqr)"' : ''}/><text x="${f1(ox + vx + 6)}" y="${f1(oy + vy * 0.5 + 4)}" style="font-size:10px">μ₁</text><text x="${f1(ox + vx + 6)}" y="${f1(oy + vy * 1.5 + 4)}" style="font-size:10px">μ₁</text><text x="${ox - 6}" y="${f1(oy + vy + 4)}" text-anchor="end" style="font-size:10.5px;font-weight:700;fill:#E5484D">μ</text><text x="${ox}" y="${oy + 16}" text-anchor="middle" class="tm" style="font-size:10px">ভেক্টর যোগ</text>`;
        // graph
        const x0 = 222, x1 = 382, y0 = 214, y1 = 24, tx = v => x0 + (v - 60) / 120 * (x1 - x0), ty = v => y0 - v / (2 * u) * (y0 - y1);
        s += `<line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y0}" class="s-ln"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y1}" class="s-ln"/>`;
        let d = ''; for (let a = 60; a <= 180; a += 2) d += (a > 60 ? 'L' : 'M') + f1(tx(a)) + ' ' + f1(ty(2 * u * Math.cos(a / 2 * Math.PI / 180)));
        s += `<path d="${d}" fill="none" class="s-acc" stroke-width="2"/><circle cx="${f1(tx(t))}" cy="${f1(ty(mu))}" r="5" fill="#E5484D"/>`;
        [0, u, 2 * u].forEach(v => s += `<text x="${x0 - 4}" y="${f1(ty(v) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:9.5px">${v.toFixed(1)}</text><line x1="${x0}" y1="${f1(ty(v))}" x2="${x1}" y2="${f1(ty(v))}" class="s-ln" opacity=".2"/>`);
        [60, 90, 120, 150, 180].forEach(a => s += `<text x="${f1(tx(a))}" y="${y0 + 13}" text-anchor="middle" class="tm mono" style="font-size:9.5px">${a}°</text>`);
        s += `<text x="${x0 + 4}" y="${y1 - 6}" class="tm" style="font-size:10px">μ (D)</text><text x="${x1}" y="${y0 + 26}" text-anchor="end" class="tm" style="font-size:10px">θ</text>`;
        [[104.5, 'H₂O'], [180, 'CO₂']].forEach(([a, n]) => s += `<line x1="${f1(tx(a))}" y1="${y0}" x2="${f1(tx(a))}" y2="${y1}" class="s-mu" stroke-dasharray="2 3" opacity=".6"/><text x="${f1(tx(a) - 3)}" y="${y1 + 10}" text-anchor="end" class="tm" style="font-size:9.5px">${n}</text>`);
        box.innerHTML = X.svg(400, 240, s, 'μ হিসাব');
        out.innerHTML = `μ = 2 × ${u} × cos(${t}°/২) = 2 × ${u} × ${Math.cos(t / 2 * Math.PI / 180).toFixed(3)} = <b>${Math.abs(mu).toFixed(2)} D</b>${t === 180 ? ' — রৈখিক অণু, ডাইপোল বাতিল।' : ''}<br><span class="small muted">μ₁ = 1.51 D ও θ = 104.5° দিলে পানির পরীক্ষালব্ধ মান 1.85 D পাওয়া যায়।</span>`;
      };
      th.oninput = run; m1.oninput = run; run();
    };
    X.onSeg(el, 'm', k => k === 'mol' ? mol() : calc()); mol();
  }
};
})();
