/* Chapter 3 visuals part 1 — periodic table, position finder, s/p/d/f blocks (3.1–3.2) */
(function () {
'use strict';
const V = window.VIS, X = window.VX;
const C3 = window.C3V = window.C3V || {};
const bn = X.bn, f1 = v => (+v).toFixed(1);
const INK = '#1b1b1f';                       // text on the pastel element tiles (both themes)

/* ---------- shared: periodic table as SVG ---------- */
C3.cellXY = (e, cell, gap, ox, oy) => {
  if (e.block === 'f') {
    const lan = e.per === 6, k = e.Z - (lan ? 58 : 90);
    return [ox + (3 + k) * (cell + gap), oy + (7 + (lan ? 0 : 1)) * (cell + gap) + cell * 0.45];
  }
  return [ox + (e.g - 1) * (cell + gap), oy + (e.per - 1) * (cell + gap)];
};
/* opts: cell, gap, fill(e), op(e), sel (Z), mark(e)->bool, label(e) (2nd line), nums, maxZ, fRows */
C3.pt = (o = {}) => {
  const cell = o.cell || 22, gap = o.gap == null ? 1.6 : o.gap, ox = o.nums === false ? 2 : 16, oy = o.nums === false ? 2 : 14;
  const maxZ = o.maxZ || 118, fRows = o.fRows !== false && maxZ > 57;
  const W = ox + 18 * (cell + gap) + 2, H = oy + (fRows ? 9 : 7) * (cell + gap) + (fRows ? cell * 0.45 : 0) + 2;
  let s = '';
  if (o.nums !== false) {
    for (let g = 1; g <= 18; g++) s += `<text x="${f1(ox + (g - 1) * (cell + gap) + cell / 2)}" y="${oy - 4}" text-anchor="middle" class="tm mono" style="font-size:${cell * 0.36}px">${g}</text>`;
    for (let p = 1; p <= 7; p++) s += `<text x="${ox - 4}" y="${f1(oy + (p - 1) * (cell + gap) + cell * 0.64)}" text-anchor="end" class="tm mono" style="font-size:${cell * 0.36}px">${p}</text>`;
  }
  if (fRows) {
    const yl = oy + 7 * (cell + gap) + cell * 0.45;
    s += `<text x="${f1(ox + 3 * (cell + gap) - 3)}" y="${f1(yl + cell * 0.62)}" text-anchor="end" class="tm" style="font-size:${cell * 0.34}px">৬</text><text x="${f1(ox + 3 * (cell + gap) - 3)}" y="${f1(yl + cell + gap + cell * 0.62)}" text-anchor="end" class="tm" style="font-size:${cell * 0.34}px">৭</text>`;
  }
  for (const e of X.PT) {
    if (e.Z > maxZ) break;
    if (e.block === 'f' && !fRows) continue;
    const [x, y] = C3.cellXY(e, cell, gap, ox, oy);
    const fill = o.fill ? o.fill(e) : X.PTCAT[e.cat][1], op = o.op ? o.op(e) : 1, sel = o.sel === e.Z, mk = o.mark && o.mark(e);
    const lab = o.label ? o.label(e) : '';
    s += `<g data-z="${e.Z}" style="cursor:pointer" opacity="${op}"><rect x="${f1(x)}" y="${f1(y)}" width="${cell}" height="${cell}" rx="${cell * 0.12}" fill="${fill || 'var(--surface-2)'}" ${sel ? 'stroke="var(--fg)" stroke-width="2"' : mk ? 'stroke="var(--fg)" stroke-width="1.2"' : 'stroke="rgba(0,0,0,.18)" stroke-width=".5"'}/>`
      + `<text x="${f1(x + cell / 2)}" y="${f1(y + (lab ? cell * 0.5 : cell * 0.66))}" text-anchor="middle" style="font-size:${cell * (e.sym.length > 2 ? 0.34 : 0.42)}px;font-weight:600;fill:${fill ? (o.ink ? o.ink(e) : INK) : 'var(--fg)'}">${e.sym}</text>`
      + (lab ? `<text x="${f1(x + cell / 2)}" y="${f1(y + cell * 0.86)}" text-anchor="middle" class="mono" style="font-size:${cell * 0.27}px;fill:${fill ? INK : 'var(--muted)'}">${lab}</text>` : '')
      + `</g>`;
  }
  return { s, W: Math.ceil(W), H: Math.ceil(H), cell, gap, ox, oy };
};
C3.onZ = (root, fn) => root.addEventListener('click', e => { const g = e.target.closest('[data-z]'); if (g) fn(+g.dataset.z); });
C3.legend = items => `<div class="small" style="display:flex;flex-wrap:wrap;gap:6px 12px;margin-top:8px">${items.map(([c, n]) => `<span style="display:inline-flex;align-items:center;gap:5px"><i style="width:12px;height:12px;border-radius:3px;background:${c};display:inline-block;border:1px solid rgba(0,0,0,.15)"></i>${n}</span>`).join('')}</div>`;
C3.el = Z => X.PT[Z - 1];
C3.grpName = e => e.block === 'f' ? (e.per === 6 ? 'ল্যান্থানাইড (গ্রুপ ৩ এর অংশ)' : 'অ্যাক্টিনাইড (গ্রুপ ৩ এর অংশ)') : 'গ্রুপ ' + bn(e.g);
/* simple scale helpers for charts */
C3.axis = (o) => {
  // o: {x0,x1,y0,y1, ymin,ymax, yt:[ticks], ylab, xlab, fmt}
  let s = `<line x1="${o.x0}" y1="${o.y0}" x2="${o.x1}" y2="${o.y0}" class="s-ln"/><line x1="${o.x0}" y1="${o.y0}" x2="${o.x0}" y2="${o.y1}" class="s-ln"/>`;
  const ty = v => o.y0 - (v - o.ymin) / (o.ymax - o.ymin) * (o.y0 - o.y1);
  (o.yt || []).forEach(v => s += `<line x1="${o.x0}" y1="${f1(ty(v))}" x2="${o.x1}" y2="${f1(ty(v))}" class="s-ln" opacity=".2"/><text x="${o.x0 - 4}" y="${f1(ty(v) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:10px">${o.fmt ? o.fmt(v) : v}</text>`);
  if (o.ylab) s += `<text x="${o.x0}" y="${o.y1 - 6}" class="tm" style="font-size:10.5px">${o.ylab}</text>`;
  if (o.xlab) s += `<text x="${o.x1}" y="${o.y0 + 26}" text-anchor="end" class="tm" style="font-size:10.5px">${o.xlab}</text>`;
  return { s, ty };
};

/* ৩.১ পর্যায় সারণি → visuals7.js (পূর্ণ ইন্টারঅ্যাকটিভ সংস্করণ) */

/* ======================= ৩.১.১ ইলেকট্রন বিন্যাস থেকে অবস্থান ======================= */
V.c3_posFinder = {
  t: 'ইলেকট্রন বিন্যাস থেকে পর্যায়, গ্রুপ ও ব্লক নির্ণয়', k: ['int', 'calc'],
  cap: 'পারমাণবিক সংখ্যা বদলাও। ধাপগুলো ঠিক পরীক্ষার খাতার মতো: (১) বিন্যাস লেখো, (২) সর্বোচ্চ প্রধান কোয়ান্টাম সংখ্যা n = পর্যায়, (৩) শেষ ইলেকট্রন যে উপস্তরে যায় সেটিই ব্লক, (৪) ব্লক অনুযায়ী নিয়মে গ্রুপ। নিচের সারণিতে মৌলটির অবস্থান চিহ্নিত হবে।',
  html: () => `<div class="ctl" style="margin:0"><label style="flex:none">Z =</label><input type="range" min="1" max="118" value="26" data-z style="flex:1"><input class="inp" type="number" min="1" max="118" value="26" data-n style="width:72px"></div>
    <div class="ctl">${[11, 17, 20, 24, 29, 35, 47, 56, 64, 82].map(z => `<button class="btn sm" data-q="${z}">${C3.el(z).sym}</button>`).join('')}</div>
    <div class="calc-out" data-out></div><div data-svg style="margin-top:8px"></div>`,
  mount(el) {
    const sl = el.querySelector('[data-z]'), nb = el.querySelector('[data-n]'), out = el.querySelector('[data-out]'), box = el.querySelector('[data-svg]');
    const run = Z => {
      Z = Math.max(1, Math.min(118, Z | 0)); sl.value = Z; nb.value = Z;
      const e = C3.el(Z), o = X.occZ(Z), keys = Object.keys(o);
      const nmax = Math.max(...keys.map(k => +k[0]));
      const order = X.SUBS.filter(s => o[s]); const last = order[order.length - 1];
      // the "differentiating" subshell by Madelung filling (La/Ac/Lr-type exceptions handled by block)
      const blk = e.block;
      const ns = o[nmax + 's'] || 0, np = o[nmax + 'p'] || 0, nd = o[(nmax - 1) + 'd'] || 0;
      let grp;
      if (blk === 's') grp = Z === 2 ? `He এর বিন্যাস 1s² — s-ব্লকের হলেও পূর্ণ স্তরের জন্য গ্রুপ <b>১৮</b> এ রাখা হয়` : `s-ব্লক: গ্রুপ = ns ইলেকট্রন সংখ্যা = <b>${bn(ns)}</b>`;
      else if (blk === 'p') grp = `p-ব্লক: গ্রুপ = ১০ + ns + np = ১০ + ${bn(ns)} + ${bn(np)} = <b>${bn(10 + ns + np)}</b>`;
      else if (blk === 'd') grp = `d-ব্লক: গ্রুপ = ns + (n−1)d = ${bn(ns)} + ${bn(nd)} = <b>${bn(ns + nd)}</b>`;
      else grp = `f-ব্লক: ${e.per === 6 ? 'ল্যান্থানাইড' : 'অ্যাক্টিনাইড'} — সবগুলো গ্রুপ ৩ এর অংশ ধরা হয় (আলাদা সারিতে দেখানো হয়)`;
      const ex = X.EXC[Z] ? `<br><span class="small">⚠ ব্যতিক্রম: আউফবাউ নিয়মের প্রত্যাশিত বিন্যাস ${X.cfgZ(Z, true, false)}, কিন্তু অর্ধপূর্ণ/পূর্ণ উপস্তরের স্থিতিশীলতা বা শক্তির নৈকট্যের জন্য প্রকৃত বিন্যাস ভিন্ন।</span>` : '';
      out.innerHTML = `<b>${e.sym}</b> (${e.name}), Z = ${bn(Z)}<br>১. বিন্যাস: <span class="mono">${X.cfgZ(Z, false)}</span><br><span class="small muted">সংক্ষেপে: ${X.cfgZ(Z)}</span>${ex}<br>২. সর্বোচ্চ n = <b>${bn(nmax)}</b> → পর্যায় <b>${bn(e.per)}</b><br>৩. শেষ ইলেকট্রন <b>${blk === 'f' ? (e.per === 6 ? '4f' : '5f') : blk === 'd' ? (nmax - 1) + 'd' : last}</b> উপস্তরে → <b>${blk}-ব্লক</b><br>৪. ${grp}`;
      const r = C3.pt({ cell: 20, sel: Z, fill: x => x.Z === Z ? X.PTBLK[x.block] : x.block === blk ? X.PTBLK[blk] + '66' : null, op: () => 1 });
      box.innerHTML = X.svg(r.W, r.H, r.s, 'অবস্থান');
    };
    sl.addEventListener('input', () => run(+sl.value)); nb.addEventListener('change', () => run(+nb.value));
    el.querySelectorAll('[data-q]').forEach(b => b.onclick = () => run(+b.dataset.q));
    C3.onZ(box, run);
    run(26);
  }
};

/* ======================= ৩.২.১ s-ব্লক ======================= */
const SB = {
  1: { els: ['Li', 'Na', 'K', 'Rb', 'Cs'], rad: [152, 186, 227, 248, 265], ie: [520, 496, 419, 403, 376], mp: [180.5, 97.8, 63.5, 39.3, 28.4], d: [0.534, 0.968, 0.862, 1.532, 1.873], en: [0.98, 0.93, 0.82, 0.82, 0.79],
    fl: [['#D7263D', 'টকটকে লাল'], ['#FFB000', 'সোনালি হলুদ'], ['#B57EDC', 'হালকা বেগুনি (লাইল্যাক)'], ['#C2185B', 'লালচে বেগুনি'], ['#7E57C2', 'নীলাভ বেগুনি']] },
  2: { els: ['Be', 'Mg', 'Ca', 'Sr', 'Ba'], rad: [112, 160, 197, 215, 222], ie: [899, 738, 590, 550, 503], mp: [1287, 650, 842, 777, 727], d: [1.85, 1.74, 1.55, 2.64, 3.51], en: [1.57, 1.31, 1.00, 0.95, 0.89],
    fl: [[null, 'বর্ণ নেই'], [null, 'বর্ণ নেই (জ্বলে উজ্জ্বল সাদা আলো)'], ['#D9541E', 'ইটের মতো লাল'], ['#E53935', 'টকটকে লাল'], ['#7CB342', 'আপেল সবুজ']] }
};
const SBP = { rad: ['পারমাণবিক ব্যাসার্ধ', 'pm'], ie: ['প্রথম আয়নীকরণ শক্তি', 'kJ mol⁻¹'], mp: ['গলনাঙ্ক', '°C'], d: ['ঘনত্ব', 'g cm⁻³'], en: ['তড়িৎ ঋণাত্মকতা (পলিং)', ''] };
const SBN = {
  1: { rad: 'গ্রুপে নিচে নতুন শক্তিস্তর যুক্ত হয় — আকার বাড়ে।', ie: 'আকার বাড়ায় বাইরের ns¹ ইলেকট্রন সহজে সরে — IE কমে, সক্রিয়তা বাড়ে।', mp: 'ধাতব বন্ধনে একটিমাত্র যোজ্যতা ইলেকট্রন ও বড় আয়ন — বন্ধন দুর্বল হয়ে নিচে গলনাঙ্ক কমে। Cs হাতের তালুতে গলে যায় (28.4 °C)।', d: 'সাধারণত নিচে বাড়ে, কিন্তু K (0.862) এর ঘনত্ব Na (0.968) এর চেয়ে কম — K এর আকার অস্বাভাবিক বেশি বাড়ে। Li, Na, K পানিতে ভাসে।', en: 'নিচে EN কমে; Cs সবচেয়ে কম তড়িৎ ঋণাত্মক স্থিতিশীল মৌল।' },
  2: { rad: 'গ্রুপ ১ এর একই পর্যায়ের মৌলের চেয়ে ছোট (নিউক্লিয়ার চার্জ বেশি)।', ie: 'দুটি ns² ইলেকট্রন — IE গ্রুপ ১ এর চেয়ে বেশি, নিচে কমে।', mp: 'দুটি যোজ্যতা ইলেকট্রন — ধাতব বন্ধন শক্তিশালী, গলনাঙ্ক গ্রুপ ১ এর চেয়ে অনেক বেশি। Mg (650 °C) ব্যতিক্রম — কেলাস গঠনের পার্থক্য।', d: 'Ca পর্যন্ত কমে, তারপর বাড়ে — ভর বৃদ্ধি আকার বৃদ্ধিকে ছাড়িয়ে যায়।', en: 'নিচে EN কমে; Be এর EN (1.57) Al (1.61) এর কাছাকাছি — কর্ণ সম্পর্ক।' }
};
V.c3_sblock = {
  t: 's-ব্লক: গ্রুপ ১ ও ২ এর ধর্মের প্রবণতা', k: ['2d', 'int'],
  cap: 'গ্রুপ ও ধর্ম বেছে নাও — প্রকৃত মান দিয়ে আঁকা স্তম্ভ লেখচিত্র দেখাবে। নিচে প্রতিটি মৌলের শিখা পরীক্ষার রং। প্রবণতার পেছনের কারণ ও ব্যতিক্রম (যেমন K এর ঘনত্ব Na এর চেয়ে কম, Mg এর গলনাঙ্ক) লেখচিত্রের নিচে লেখা আছে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('g', [[1, 'গ্রুপ ১: ক্ষার ধাতু'], [2, 'গ্রুপ ২: মৃৎক্ষার ধাতু']], 1)}</div><div class="ctl" style="margin:0 0 6px">${X.seg('p', Object.keys(SBP).map(k => [k, SBP[k][0].split(' (')[0]]), 'ie')}</div><div data-svg></div><div data-fl></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), fl = el.querySelector('[data-fl]'); let g = 1, p = 'ie';
    const draw = () => {
      const D = SB[g], vals = D[p], mx = Math.max(...vals) * 1.15;
      const x0 = 50, x1 = 390, y0 = 196, y1 = 22, bw = 44, gap = (x1 - x0 - bw * 5) / 6;
      const nice = mx > 1000 ? 400 : mx > 400 ? 100 : mx > 100 ? 50 : mx > 10 ? 5 : mx > 2 ? 0.5 : 0.2;
      const yt = []; for (let v = 0; v <= mx; v += nice) yt.push(+v.toFixed(2));
      const A = C3.axis({ x0, x1, y0, y1, ymin: 0, ymax: mx, yt, ylab: SBP[p][0] + (SBP[p][1] ? ' (' + SBP[p][1] + ')' : ''), fmt: v => (v % 1 ? v.toFixed(1) : v) });
      let s = A.s;
      vals.forEach((v, i) => {
        const x = x0 + gap + i * (bw + gap), y = A.ty(v), col = g === 1 ? '#E8775C' : '#E9A53B';
        s += `<rect x="${f1(x)}" y="${f1(y)}" width="${bw}" height="${f1(y0 - y)}" rx="3" fill="${col}" opacity="${0.55 + 0.09 * i}"/><text x="${f1(x + bw / 2)}" y="${f1(y - 5)}" text-anchor="middle" class="mono" style="font-size:11px;font-weight:600">${v}</text><text x="${f1(x + bw / 2)}" y="${y0 + 16}" text-anchor="middle" style="font-size:13px;font-weight:600">${D.els[i]}</text>`;
      });
      s += `<text x="${x1}" y="${y0 + 32}" text-anchor="end" class="tm" style="font-size:10.5px">গ্রুপে উপর থেকে নিচে →</text>`;
      box.innerHTML = X.svg(400, 234, s, 's-ব্লকের ধর্ম');
      fl.innerHTML = `<div class="small" style="margin-top:6px;font-weight:600">শিখা পরীক্ষার রং</div><div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-top:4px">${D.fl.map(([c, n], i) => `<div style="text-align:center"><div style="height:34px;border-radius:50% 50% 45% 45% / 70% 70% 30% 30%;margin:0 auto;width:26px;background:${c ? `radial-gradient(circle at 50% 70%, #fff8 0, ${c} 55%, ${c}00 100%)` : 'var(--surface-2)'};border:${c ? '0' : '1px dashed var(--line-strong)'}"></div><div class="small"><b>${D.els[i]}</b></div><div class="small muted" style="font-size:11px;line-height:1.3">${n}</div></div>`).join('')}</div>`;
      out.innerHTML = SBN[g][p];
    };
    X.onSeg(el, 'g', k => { g = +k; draw(); }); X.onSeg(el, 'p', k => { p = k; draw(); }); draw();
  }
};

/* ======================= ৩.২.২ p-ব্লক ======================= */
const PB = [
  // [sym, nature m/ml/nm/ng, oxidation states, stable-note]
  [['B', 'ml', '+3'], ['C', 'nm', '−4, +2, +4'], ['N', 'nm', '−3 থেকে +5'], ['O', 'nm', '−2 (−1)'], ['F', 'nm', '−1'], ['Ne', 'ng', '০']],
  [['Al', 'm', '+3'], ['Si', 'ml', '−4, +4'], ['P', 'nm', '−3, +3, +5'], ['S', 'nm', '−2, +4, +6'], ['Cl', 'nm', '−1, +1, +3, +5, +7'], ['Ar', 'ng', '০']],
  [['Ga', 'm', '+3 (+1)'], ['Ge', 'ml', '+4, +2'], ['As', 'ml', '−3, +3, +5'], ['Se', 'nm', '−2, +4, +6'], ['Br', 'nm', '−1, +1, +5'], ['Kr', 'ng', '০, +2']],
  [['In', 'm', '+3, +1'], ['Sn', 'm', '+4, +2'], ['Sb', 'ml', '+3, +5'], ['Te', 'ml', '−2, +4, +6'], ['I', 'nm', '−1, +1, +5, +7'], ['Xe', 'ng', '+2, +4, +6']],
  [['Tl', 'm', '+1 (স্থিতিশীল), +3'], ['Pb', 'm', '+2 (স্থিতিশীল), +4'], ['Bi', 'm', '+3 (স্থিতিশীল), +5'], ['Po', 'm', '+2, +4'], ['At', 'ml', '−1, +1'], ['Rn', 'ng', '+2']]
];
const PBN = { m: ['ধাতু', '#8AA0B3'], ml: ['ধাতুকল্প', '#5FB09A'], nm: ['অধাতু', '#6FA8DC'], ng: ['নিষ্ক্রিয় গ্যাস', '#A88BD8'] };
V.c3_pblock = {
  t: 'p-ব্লক: ধাতু থেকে অধাতু এবং নিষ্ক্রিয় যুগল প্রভাব', k: ['2d', 'int'],
  cap: 'p-ব্লকেই ধাতু, ধাতুকল্প ও অধাতু — তিন ধরনের মৌল পাশাপাশি আছে। মোটা "সিঁড়ি" রেখার বামে-নিচে ধাতু, ঠিক ডানে রেখা বরাবর ধাতুকল্প (B, Si, Ge, As, Sb, Te, At) এবং আরও উপরে-ডানে অধাতু। মৌলে চাপ দিলে তার জারণ অবস্থা দেখাবে। "নিষ্ক্রিয় যুগল প্রভাব" চালু করলে দেখবে গ্রুপ ১৩–১৫ এ নিচের দিকে গ্রুপ জারণ অবস্থার চেয়ে ২ কম জারণ অবস্থা বেশি স্থিতিশীল হয় (Tl⁺, Pb²⁺, Bi³⁺) — কারণ ns² ইলেকট্রন যুগল বন্ধনে অংশ নিতে চায় না।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><button class="btn sm" data-ip>নিষ্ক্রিয় যুগল প্রভাব দেখাও</button></div><div data-svg></div><div data-leg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let ip = false, sel = [1, 3];
    el.querySelector('[data-leg]').innerHTML = C3.legend(Object.values(PBN).map(([n, c]) => [c, n]));
    const draw = () => {
      const cw = 58, ch = 40, ox = 34, oy = 22; let s = '';
      ['১৩', '১৪', '১৫', '১৬', '১৭', '১৮'].forEach((g, j) => s += `<text x="${ox + j * cw + cw / 2}" y="${oy - 7}" text-anchor="middle" class="tm" style="font-size:11px">গ্রুপ ${g}</text>`);
      ['২', '৩', '৪', '৫', '৬'].forEach((p, i) => s += `<text x="${ox - 6}" y="${oy + i * ch + ch / 2 + 4}" text-anchor="end" class="tm" style="font-size:11px">${p}</text>`);
      PB.forEach((row, i) => row.forEach(([sym, nat, ox_], j) => {
        const x = ox + j * cw, y = oy + i * ch, isSel = sel[0] === i && sel[1] === j;
        const inert = ip && i >= 3 && j <= 2;
        s += `<g data-c="${i},${j}" style="cursor:pointer"><rect x="${x + 1.5}" y="${y + 1.5}" width="${cw - 3}" height="${ch - 3}" rx="5" fill="${PBN[nat][1]}" opacity="${ip && !inert ? 0.35 : 1}" ${isSel ? 'stroke="var(--fg)" stroke-width="2.2"' : ''}/><text x="${x + cw / 2}" y="${y + (ip ? 17 : 25)}" text-anchor="middle" style="font-size:15px;font-weight:700;fill:${INK}">${sym}</text>${inert ? `<text x="${x + cw / 2}" y="${y + 32}" text-anchor="middle" class="mono" style="font-size:10.5px;font-weight:600;fill:${INK}">${[['In⁺', 'Sn²⁺', 'Sb³⁺'], ['Tl⁺', 'Pb²⁺', 'Bi³⁺']][i - 3][j]}</text>` : ''}</g>`;
      }));
      // staircase: boundary between metals (left/below) and metalloids + non-metals
      const fc = PB.map(r => r.findIndex(c => c[1] !== 'm'));
      let d = `M${ox + fc[0] * cw} ${oy}`;
      fc.forEach((c, i) => { d += ` L${ox + c * cw} ${oy + (i + 1) * ch}`; if (i < fc.length - 1) d += ` L${ox + fc[i + 1] * cw} ${oy + (i + 1) * ch}`; });
      s += `<path d="${d}" fill="none" class="s-fg" stroke-width="2.6" stroke-linejoin="round"/>`;
      s += `<text x="${ox + 2}" y="${oy + 5 * ch + 16}" class="tm" style="font-size:11px">← ধাতব ধর্ম বাড়ে (নিচে ও বামে)</text><text x="${ox + 6 * cw}" y="${oy + 5 * ch + 30}" text-anchor="end" class="tm" style="font-size:11px">অধাতব ধর্ম ও EN বাড়ে (উপরে ও ডানে) →</text>`;
      box.innerHTML = X.svg(ox + 6 * cw + 6, oy + 5 * ch + 36, s, 'p-ব্লক');
      const [sym, nat, oxs] = PB[sel[0]][sel[1]];
      const e = X.PT.find(z => z.sym === sym);
      out.innerHTML = `<b>${sym}</b> (${e.name}) · ${PBN[nat][0]} · <span class="mono">${X.cfgZ(e.Z)}</span><br>প্রধান জারণ অবস্থা: <b>${oxs}</b>` + (ip ? `<br><span class="small">নিষ্ক্রিয় যুগল প্রভাব: ভারী মৌলে ns² ইলেকট্রন নিউক্লিয়াসের খুব কাছে ভেদন করে (d ও f ইলেকট্রনের দুর্বল আবরণ) — যুগলটি বন্ধনে অংশ নিতে চায় না। তাই PbO₂ জারক (Pb⁴⁺ → Pb²⁺), TlCl স্থিতিশীল, Bi(V) যৌগ শক্তিশালী জারক (NaBiO₃)।</span>` : '');
    };
    box.addEventListener('click', e => { const g = e.target.closest('[data-c]'); if (g) { sel = g.dataset.c.split(',').map(Number); draw(); } });
    el.querySelector('[data-ip]').onclick = function () { ip = !ip; this.classList.toggle('primary', ip); this.textContent = ip ? 'নিষ্ক্রিয় যুগল প্রভাব লুকাও' : 'নিষ্ক্রিয় যুগল প্রভাব দেখাও'; draw(); };
    draw();
  }
};

/* ======================= ৩.২.৩ d-ব্লক: জারণ অবস্থা ও আয়নের রং ======================= */
const DB = ['Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn'];
// oxidation states: [state, 'c' common | 'r' rare]
const DOX = [[[3, 'c']], [[2, 'r'], [3, 'c'], [4, 'c']], [[2, 'c'], [3, 'c'], [4, 'c'], [5, 'c']], [[2, 'c'], [3, 'c'], [4, 'r'], [5, 'r'], [6, 'c']], [[2, 'c'], [3, 'c'], [4, 'c'], [5, 'r'], [6, 'c'], [7, 'c']], [[2, 'c'], [3, 'c'], [6, 'r']], [[2, 'c'], [3, 'c']], [[2, 'c'], [3, 'r']], [[1, 'c'], [2, 'c']], [[2, 'c']]];
const DION = [
  ['Sc³⁺', 21, 3, '#F4F4F4', 'বর্ণহীন'], ['Ti³⁺', 22, 3, '#8E44AD', 'বেগুনি'], ['V³⁺', 23, 3, '#3C8D2F', 'সবুজ'], ['V²⁺', 23, 2, '#7B3FA0', 'বেগুনি'],
  ['Cr³⁺', 24, 3, '#4F7F3A', 'সবুজ (হেক্সাঅ্যাকোয়া: বেগুনি-ধূসর)'], ['Cr²⁺', 24, 2, '#3D6FC4', 'নীল'], ['Mn²⁺', 25, 2, '#F6D5DC', 'হালকা গোলাপি'], ['Fe²⁺', 26, 2, '#B7D9A8', 'হালকা সবুজ'],
  ['Fe³⁺', 26, 3, '#C8962E', 'হলদে-বাদামি'], ['Co²⁺', 27, 2, '#E58FA6', 'গোলাপি'], ['Ni²⁺', 28, 2, '#4CAF50', 'সবুজ'], ['Cu²⁺', 29, 2, '#2F86D6', 'নীল'], ['Cu⁺', 29, 1, '#F4F4F4', 'বর্ণহীন'], ['Zn²⁺', 30, 2, '#F4F4F4', 'বর্ণহীন']
];
const dCount = (Z, q) => { // d-electron count of M^q+ (3d series): remove 4s first
  const o = X.occZ(Z); let d = o['3d'] || 0, s = o['4s'] || 0; let r = q; const fs = Math.min(s, r); r -= fs; d -= r; return d;
};
V.c3_dblock = {
  t: 'd-ব্লক (৩d সারি): পরিবর্তনশীল জারণ অবস্থা, রঙিন আয়ন ও চুম্বকত্ব', k: ['2d', 'int'],
  cap: '"জারণ অবস্থা" দৃশ্যে প্রতিটি বিন্দু একটি জারণ অবস্থা; গাঢ় বিন্দু সাধারণ, হালকা বিন্দু বিরল। লক্ষ করো Mn পর্যন্ত সর্বোচ্চ জারণ অবস্থা = (n−1)d + ns ইলেকট্রন সংখ্যা (Mn: +৭), তারপর কমে। "আয়নের রং" দৃশ্যে আয়নে চাপ দিলে তার d-ইলেকট্রন বিন্যাস, অযুগ্ম ইলেকট্রন ও চৌম্বক ভ্রামক μ = √[n(n+2)] BM দেখাবে। d⁰ (Sc³⁺) ও d¹⁰ (Zn²⁺, Cu⁺) আয়নে d–d স্থানান্তর সম্ভব নয় — তাই বর্ণহীন ও ডায়াচৌম্বক।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['ox', 'জারণ অবস্থা'], ['col', 'আয়নের রং ও চুম্বকত্ব']], 'ox')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let mode = 'ox', sel = 11;
    const draw = () => {
      let s = '';
      if (mode === 'ox') {
        const x0 = 44, cw = 35, y0 = 230, rh = 27;
        for (let k = 1; k <= 7; k++) s += `<text x="${x0 - 8}" y="${y0 - k * rh + 4}" text-anchor="end" class="tm mono" style="font-size:11px">+${k}</text><line x1="${x0}" y1="${y0 - k * rh}" x2="${x0 + 10 * cw}" y2="${y0 - k * rh}" class="s-ln" opacity=".18"/>`;
        let maxPath = '';
        DB.forEach((sym, i) => {
          const x = x0 + i * cw + cw / 2;
          s += `<text x="${x}" y="${y0 + 16}" text-anchor="middle" style="font-size:13px;font-weight:600">${sym}</text>`;
          DOX[i].forEach(([k, t]) => s += `<circle cx="${x}" cy="${y0 - k * rh}" r="${t === 'c' ? 8 : 6}" fill="${t === 'c' ? '#E3B04B' : 'none'}" stroke="#C08A1E" stroke-width="${t === 'c' ? 0 : 1.6}"/>`);
          const mx = Math.max(...DOX[i].map(a => a[0])); maxPath += (i ? 'L' : 'M') + x + ' ' + (y0 - mx * rh);
        });
        s += `<path d="${maxPath}" fill="none" class="s-mu" stroke-dasharray="4 3"/><text x="${x0 + 4 * cw + cw / 2}" y="${y0 - 7 * rh - 10}" text-anchor="middle" class="tm" style="font-size:10.5px">সর্বোচ্চ: Mn⁷⁺ (MnO₄⁻)</text>`;
        s += `<text x="${x0}" y="${y0 + 34}" class="tm" style="font-size:10.5px">● সাধারণ ○ বিরল · ড্যাশ রেখা: সর্বোচ্চ জারণ অবস্থা</text>`;
        box.innerHTML = X.svg(x0 + 10 * cw + 6, y0 + 42, s, 'জারণ অবস্থা');
        out.innerHTML = 'অবস্থান্তর মৌলে (n−1)d ও ns উপস্তরের শক্তি খুব কাছাকাছি, তাই উভয় থেকে ভিন্ন সংখ্যক ইলেকট্রন বন্ধনে অংশ নিতে পারে — <b>পরিবর্তনশীল জারণ অবস্থা</b>। Sc শুধু +৩ (d⁰) এবং Zn শুধু +২ (d¹⁰) দেখায় — এজন্য এরা "আদর্শ" অবস্থান্তর মৌল নয়; Zn কে অবস্থান্তর মৌল ধরা হয় না।';
      } else {
        const cols = 5, cw = 78, ch = 74, ox = 4, oy = 4;
        DION.forEach(([n, Z, q, c, cn], i) => {
          const x = ox + (i % cols) * cw, y = oy + Math.floor(i / cols) * ch, on = i === sel;
          s += `<g data-i="${i}" style="cursor:pointer"><rect x="${x + 2}" y="${y + 2}" width="${cw - 4}" height="${ch - 4}" rx="8" class="f-s2" ${on ? 'stroke="var(--fg)" stroke-width="2"' : ''}/>`
            + `<path d="M${x + 22} ${y + 14} L${x + 22} ${y + 44} Q${x + 22} ${y + 52} ${x + 30} ${y + 52} L${x + cw - 30} ${y + 52} Q${x + cw - 22} ${y + 52} ${x + cw - 22} ${y + 44} L${x + cw - 22} ${y + 14}" fill="none" class="s-mu" stroke-width="1.4"/>`
            + `<path d="M${x + 23} ${y + 26} L${x + 23} ${y + 44} Q${x + 23} ${y + 51} ${x + 30} ${y + 51} L${x + cw - 30} ${y + 51} Q${x + cw - 23} ${y + 51} ${x + cw - 23} ${y + 44} L${x + cw - 23} ${y + 26}Z" fill="${c}" opacity=".9"/>`
            + `<text x="${x + cw / 2}" y="${y + 67}" text-anchor="middle" style="font-size:12.5px;font-weight:600">${n}</text></g>`;
        });
        box.innerHTML = X.svg(cols * cw + 8, Math.ceil(DION.length / cols) * ch + 8, s, 'আয়নের রং');
        const [n, Z, q, c, cn] = DION[sel]; const d = dCount(Z, q); const up = d <= 5 ? d : 10 - d; const mu = Math.sqrt(up * (up + 2));
        let boxes = ''; for (let k = 0; k < 5; k++) { const a = k < d ? 1 : 0, b = k + 5 < d ? 1 : 0; boxes += `<span style="display:inline-flex;width:24px;height:24px;border:1.5px solid var(--line-strong);margin-right:-1.5px;align-items:center;justify-content:center;font-size:13px;font-family:var(--font-mono)">${a ? '↑' : ''}${b ? '↓' : ''}</span>`; }
        out.innerHTML = `<b>${n}</b> — জলীয় দ্রবণে <b>${cn}</b><br>বিন্যাস: <span class="mono">[Ar] 3d${X.sup(d)}</span> &nbsp; 3d: ${boxes}<br>অযুগ্ম ইলেকট্রন n = <b>${bn(up)}</b> · μ = √[n(n+2)] = <b>${mu.toFixed(2)} BM</b> · ${up ? 'প্যারাচৌম্বক' : 'ডায়াচৌম্বক'}<br><span class="small">${d === 0 || d === 10 ? 'd⁰/d¹⁰: d–d স্থানান্তর অসম্ভব → বর্ণহীন।' : 'আংশিক পূর্ণ d অরবিটাল: লিগ্যান্ডের প্রভাবে d অরবিটাল দুই শক্তিস্তরে বিভক্ত হয়; দৃশ্যমান আলোর একটি অংশ শোষণ করে ইলেকট্রন উপরে যায় — আমরা পরিপূরক রং দেখি।'}</span>`;
      }
    };
    X.onSeg(el, 'm', k => { mode = k; draw(); });
    box.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g) { sel = +g.dataset.i; draw(); } });
    draw();
  }
};

/* ======================= ৩.২.৪ f-ব্লক: ল্যান্থানাইড সংকোচন ======================= */
const LN = ['La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb', 'Lu'];
const LNR = [103.2, 101, 99, 98.3, 97, 95.8, 94.7, 93.8, 92.3, 91.2, 90.1, 89, 88, 86.8, 86.1]; // Ln³⁺, CN 6 (Shannon)
V.c3_fblock = {
  t: 'f-ব্লক: ল্যান্থানাইড সংকোচন ও এর ফলাফল', k: ['2d', 'int'],
  cap: 'La³⁺ থেকে Lu³⁺ পর্যন্ত ১৪টি 4f ইলেকট্রন যুক্ত হয়, প্রতিবার নিউক্লিয়ার চার্জ এক করে বাড়ে। কিন্তু 4f অরবিটালের বিস্তৃত আকৃতির জন্য এরা বাইরের ইলেকট্রনকে খুব দুর্বলভাবে আবরণ করে — কার্যকর নিউক্লিয়ার চার্জ বাড়তে থাকে এবং আয়নের আকার ক্রমাগত কমে (প্রায় ১৭ pm)। একে ল্যান্থানাইড সংকোচন বলে। দ্বিতীয় দৃশ্যে এর সবচেয়ে বিখ্যাত ফলাফল: ৫ম ও ৬ষ্ঠ পর্যায়ের d-ব্লক মৌলগুলোর আকার প্রায় সমান (Zr ≈ Hf), তাই এদের পৃথক করা অত্যন্ত কঠিন। লেখচিত্রে বিন্দুতে চাপ দিলে মান দেখাবে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['lc', 'ল্যান্থানাইড সংকোচন'], ['tw', 'Zr–Hf যমজ']], 'lc')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let mode = 'lc', sel = 14;
    const draw = () => {
      let s = '';
      if (mode === 'lc') {
        const x0 = 46, x1 = 390, y0 = 200, y1 = 22;
        const A = C3.axis({ x0, x1, y0, y1, ymin: 84, ymax: 106, yt: [84, 88, 92, 96, 100, 104], ylab: 'Ln³⁺ আয়নিক ব্যাসার্ধ (pm)' });
        s += A.s; const tx = i => x0 + 12 + i * (x1 - x0 - 24) / 14;
        let d = ''; LNR.forEach((r, i) => d += (i ? 'L' : 'M') + f1(tx(i)) + ' ' + f1(A.ty(r)));
        s += `<path d="${d}" fill="none" stroke="#B784C7" stroke-width="2.4"/>`;
        LNR.forEach((r, i) => s += `<g data-i="${i}" style="cursor:pointer"><circle cx="${f1(tx(i))}" cy="${f1(A.ty(r))}" r="${i === sel ? 6.5 : 4.5}" fill="#B784C7" ${i === sel ? 'stroke="var(--fg)" stroke-width="2"' : 'stroke="var(--surface)" stroke-width="1.2"'}/><rect x="${f1(tx(i) - 11)}" y="${y1}" width="22" height="${y0 - y1 + 20}" fill="transparent"/></g><text x="${f1(tx(i))}" y="${y0 + 14}" text-anchor="middle" style="font-size:${i % 2 ? 9.5 : 10.5}px" ${i % 2 ? 'class="tm"' : ''}>${LN[i]}</text>`);
        s += `<text x="${x1}" y="${y0 + 30}" text-anchor="end" class="tm" style="font-size:10.5px">পারমাণবিক সংখ্যা ৫৭ → ৭১ (4f⁰ → 4f¹⁴)</text>`;
        box.innerHTML = X.svg(400, 238, s, 'ল্যান্থানাইড সংকোচন');
        out.innerHTML = `<b>${LN[sel]}³⁺</b> (Z = ${bn(57 + sel)}) · 4f${X.sup(sel)} · ব্যাসার্ধ <b>${LNR[sel]} pm</b><br>La³⁺ থেকে মোট সংকোচন: <b>${(LNR[0] - LNR[sel]).toFixed(1)} pm</b><span class="small muted"> (শ্যানন, সন্নিবেশ সংখ্যা ৬)</span>`;
      } else {
        const rows = [['৪র্থ পর্যায় (3d)', [['Ti', 147], ['V', 134], ['Cr', 128]]], ['৫ম পর্যায় (4d)', [['Zr', 160], ['Nb', 146], ['Mo', 139]]], ['৬ষ্ঠ পর্যায় (5d)', [['Hf', 159], ['Ta', 146], ['W', 139]]]];
        const sc = 0.21, cx0 = 150, dx = 92, rh = 84;
        rows.forEach(([lab, els], i) => {
          const y = 44 + i * rh;
          s += `<text x="8" y="${y + 4}" class="tm" style="font-size:11.5px">${lab}</text>`;
          els.forEach(([sym, r], j) => { const x = cx0 + j * dx; s += `<circle cx="${x}" cy="${y}" r="${f1(r * sc)}" fill="#E3B04B" opacity="${0.55 + 0.15 * i}" stroke="#B88716"/><text x="${x}" y="${y + 1}" text-anchor="middle" style="font-size:13.5px;font-weight:700;fill:${INK}">${sym}</text><text x="${x}" y="${y + 15}" text-anchor="middle" class="mono" style="font-size:10px;fill:${INK}">${r} pm</text>`; });
        });
        s += `<rect x="${cx0 - 46}" y="${44 + rh - 42}" width="${2 * dx + 92}" height="${rh + 84}" rx="10" fill="none" class="s-acc" stroke-width="1.6" stroke-dasharray="5 4"/><text x="${cx0 + dx}" y="${44 + 2 * rh + 58}" text-anchor="middle" style="font-size:11.5px" class="tb">প্রায় সমান আকার!</text>`;
        box.innerHTML = X.svg(420, 44 + 2 * 84 + 66, s, 'Zr Hf');
        out.innerHTML = 'স্বাভাবিকভাবে গ্রুপে নিচে আকার বাড়ার কথা। ৪র্থ → ৫ম পর্যায়ে বাড়েও (Ti 147 → Zr 160 pm)। কিন্তু ৫ম → ৬ষ্ঠ পর্যায়ের মাঝে ১৪টি ল্যান্থানাইড বসে আছে — তাদের সংকোচন বাড়তি স্তরের প্রভাবকে প্রায় বাতিল করে দেয়: Zr 160 ≈ Hf 159 pm। ফলে Zr ও Hf এর রাসায়নিক ধর্ম প্রায় অভিন্ন, প্রকৃতিতে একসাথে পাওয়া যায় এবং পৃথক করা খুব কঠিন। একই কারণে ৬ষ্ঠ পর্যায়ের Au, Pt এর ঘনত্ব অত্যন্ত বেশি এবং এরা কম সক্রিয়।';
      }
    };
    X.onSeg(el, 'm', k => { mode = k; draw(); });
    box.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g) { sel = +g.dataset.i; draw(); } });
    draw();
  }
};
})();
