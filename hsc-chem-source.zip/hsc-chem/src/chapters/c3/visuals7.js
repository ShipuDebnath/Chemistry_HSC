/* Chapter 3 · চিত্র ৩.১ — ইন্টারঅ্যাকটিভ পর্যায় সারণি (পূর্ণ সংস্করণ)
   ধর্ম অনুযায়ী রং (শ্রেণি/ব্লক/অবস্থা/যোজ্যতা ইলেকট্রন/ব্যাসার্ধ/IE/EN/EA/গলনাঙ্ক), হাইলাইট, খোঁজা,
   কার্সরের কাছে টাইল সামান্য বড় হয় (ডেস্কটপ), মৌলে চাপ দিলে বোর মডেল অ্যানিমেশন + অরবিটাল বাক্স + ধর্মের মিটার।
   সস্তা ফোনের জন্য: শুধু transform/opacity অ্যানিমেশন, rAF-থ্রটল, অফ-স্ক্রিনে বোর অ্যানিমেশন বন্ধ, DPR ≤ 2। */
(function () {
'use strict';
const V = window.VIS, X = window.VX;
const bn = X.bn;

/* ---- ধর্মের তথ্য (সব ১১৮টি মৌল) ----
   Name | Pauling EN | সমযোজী ব্যাসার্ধ pm (Cordero 2008) | IE₁ kJ/mol | EA kJ/mol | গলনাঙ্ক K */
const RAW = `Hydrogen|2.20|31|1312|72.8|13.99
Helium||28|2372||
Lithium|0.98|128|520.2|59.6|453.65
Beryllium|1.57|96|899.5||1560
Boron|2.04|84|800.6|27.0|2349
Carbon|2.55|76|1086.5|121.8|3823
Nitrogen|3.04|71|1402.3||63.15
Oxygen|3.44|66|1313.9|141.0|54.36
Fluorine|3.98|57|1681.0|328.2|53.48
Neon||58|2080.7||24.56
Sodium|0.93|166|495.8|52.9|370.87
Magnesium|1.31|141|737.7||923
Aluminium|1.61|121|577.5|42.5|933.47
Silicon|1.90|111|786.5|134.1|1687
Phosphorus|2.19|107|1011.8|72.0|317.3
Sulfur|2.58|105|999.6|200.4|388.36
Chlorine|3.16|102|1251.2|348.6|171.6
Argon||106|1520.6||83.8
Potassium|0.82|203|418.8|48.4|336.53
Calcium|1.00|176|589.8|2.37|1115
Scandium|1.36|170|633.1|18.1|1814
Titanium|1.54|160|658.8|7.6|1941
Vanadium|1.63|153|650.9|50.6|2183
Chromium|1.66|139|652.9|64.3|2180
Manganese|1.55|139|717.3||1519
Iron|1.83|132|762.5|14.6|1811
Cobalt|1.88|126|760.4|63.7|1768
Nickel|1.91|124|737.1|112|1728
Copper|1.90|132|745.5|119.2|1357.77
Zinc|1.65|122|906.4||692.68
Gallium|1.81|122|578.8|41|302.91
Germanium|2.01|120|762.0|119|1211.4
Arsenic|2.18|119|947.0|78|1090
Selenium|2.55|120|941.0|195|453
Bromine|2.96|120|1139.9|324.6|265.8
Krypton|3.00|116|1350.8||115.78
Rubidium|0.82|220|403.0|46.9|312.46
Strontium|0.95|195|549.5|5.03|1050
Yttrium|1.22|190|600|29.6|1799
Zirconium|1.33|175|640.1|41.1|2128
Niobium|1.6|164|652.1|86.1|2750
Molybdenum|2.16|154|684.3|71.9|2896
Technetium|1.9|147|702|53|2430
Ruthenium|2.2|146|710.2|101.3|2607
Rhodium|2.28|142|719.7|109.7|2237
Palladium|2.20|139|804.4|53.7|1828
Silver|1.93|145|731.0|125.6|1234.93
Cadmium|1.69|144|867.8||594.22
Indium|1.78|142|558.3|37.4|429.75
Tin|1.96|139|708.6|107.3|505.08
Antimony|2.05|139|834|101|903.78
Tellurium|2.1|138|869.3|190.2|722.66
Iodine|2.66|139|1008.4|295.2|386.85
Xenon|2.6|140|1170.4||161.4
Caesium|0.79|244|375.7|45.5|301.59
Barium|0.89|215|502.9|13.95|1000
Lanthanum|1.10|207|538.1|48|1193
Cerium|1.12|204|534.4||1068
Praseodymium|1.13|203|527||1208
Neodymium|1.14|201|533.1||1297
Promethium|1.13|199|540||1315
Samarium|1.17|198|544.5||1345
Europium|1.2|198|547.1||1099
Gadolinium|1.2|196|593.4||1585
Terbium|1.2|194|565.8||1629
Dysprosium|1.22|192|573.0||1680
Holmium|1.23|192|581.0||1734
Erbium|1.24|189|589.3||1802
Thulium|1.25|190|596.7||1818
Ytterbium|1.1|187|603.4||1097
Lutetium|1.27|187|523.5||1925
Hafnium|1.3|175|658.5||2506
Tantalum|1.5|170|761|31|3290
Tungsten|2.36|162|770|78.6|3695
Rhenium|1.9|151|760|14.5|3459
Osmium|2.2|144|840|106|3306
Iridium|2.20|141|880|151|2739
Platinum|2.28|136|870|205.3|2041.4
Gold|2.54|136|890.1|222.8|1337.33
Mercury|2.00|132|1007.1||234.32
Thallium|1.62|145|589.4|36.4|577
Lead|2.33|146|715.6|35.1|600.61
Bismuth|2.02|148|703|91.2|544.7
Polonium|2.0|140|812.1|183|527
Astatine|2.2|150|899||
Radon|2.2|150|1037||202
Francium|0.7|260|393|46.9|
Radium|0.9|221|509.3|9.65|973
Actinium|1.1|215|499||1323
Thorium|1.3|206|587||2115
Protactinium|1.5|200|568||1841
Uranium|1.38|196|597.6||1405.3
Neptunium|1.36|190|604.5||917
Plutonium|1.28|187|584.7||912.5
Americium|1.13|180|578||1449
Curium|1.28|169|581||1613
Berkelium|1.3||601||1259
Californium|1.3||608||1173
Einsteinium|1.3||619||1133
Fermium|1.3||627||
Mendelevium|1.3||635||
Nobelium|1.3||642||
Lawrencium|1.3||478.6||
Rutherfordium|||||
Dubnium|||||
Seaborgium|||||
Bohrium|||||
Hassium|||||
Meitnerium|||||
Darmstadtium|||||
Roentgenium|||||
Copernicium|||||
Nihonium|||||
Flerovium|||||
Moscovium|||||
Livermorium|||||
Tennessine|||||
Oganesson|||||`;
const nv = x => x === '' || x === undefined ? null : +x;
const GAS = [1, 2, 7, 8, 9, 10, 17, 18, 36, 54, 86], LIQ = [35, 80];
const EL = RAW.split('\n').map((l, i) => {
  const [en, e, r, ie, ea, mp] = l.split('|'), p = X.PT[i], Z = i + 1;
  const row = p.block === 'f' ? (p.per === 6 ? 9 : 10) : p.per, col = p.block === 'f' ? 3 + (Z - (p.per === 6 ? 58 : 90)) + 1 : p.g;
  const st = GAS.includes(Z) ? 'gas' : LIQ.includes(Z) ? 'liq' : Z >= 104 ? 'unk' : 'sol';
  const val = Z === 2 ? 2 : p.block === 's' ? p.g : p.block === 'p' ? p.g - 10 : null;
  return Object.assign({}, p, { en, eneg: nv(e), rad: nv(r), ie: nv(ie), ea: nv(ea), mp: nv(mp), row, col, st, val, ra: Z === 43 || Z === 61 || Z >= 84 });
});

/* ---- রং ও স্কেল ---- */
const VIR = [[68, 1, 84], [59, 82, 139], [33, 145, 140], [94, 201, 98], [253, 231, 37]];
function vir(t) { const x = Math.max(0, Math.min(1, t)) * 4, i = Math.min(3, Math.floor(x)), f = x - i; return '#' + VIR[i].map((v, k) => Math.round(v + (VIR[i + 1][k] - v) * f).toString(16).padStart(2, '0')).join(''); }
function ink(hex) { if (!hex || hex[0] !== '#') return null; const n = parseInt(hex.slice(1, 7), 16), l = (0.299 * (n >> 16) + 0.587 * (n >> 8 & 255) + 0.114 * (n & 255)) / 255; return l > 0.58 ? '#14161b' : '#fff'; }
const NUM = ['rad', 'ie', 'eneg', 'ea', 'mp'];
const RNG = {}; NUM.forEach(k => { const v = EL.map(e => e[k]).filter(x => x != null); RNG[k] = [Math.min(...v), Math.max(...v)]; });
const fmt = v => v >= 100 ? String(Math.round(v)) : v >= 10 ? v.toFixed(1) : v.toFixed(2);
const DC = {
  cat: Object.fromEntries(Object.entries(X.PTCAT).map(([k, [n, c]]) => [k, [n, c]])),
  blk: { s: ['s-ব্লক', X.PTBLK.s], p: ['p-ব্লক', X.PTBLK.p], d: ['d-ব্লক', X.PTBLK.d], f: ['f-ব্লক', X.PTBLK.f] },
  st: { sol: ['কঠিন', '#9AA3B2'], liq: ['তরল', '#3FBF8F'], gas: ['গ্যাস', '#5DA9E9'], unk: ['অজানা', '#D3D8E0'] },
  val: Object.fromEntries([1, 2, 3, 4, 5, 6, 7, 8].map(v => [v, [bn(v) + 'টি', vir((v - 1) / 7)]]))
};
const dval = (e, m) => m === 'cat' ? e.cat : m === 'blk' ? e.block : m === 'st' ? e.st : m === 'val' ? e.val : null;
function colorOf(e, m) { if (DC[m]) { const v = dval(e, m); return v == null ? null : DC[m][v][1]; } const v = e[m]; if (v == null) return null; const [a, b] = RNG[m]; return vir((v - a) / (b - a)); }
const MODES = [['cat', 'শ্রেণি', 'Category'], ['blk', 'ব্লক', 'Block'], ['st', 'অবস্থা (২৫°C)', 'State'], ['val', 'যোজ্যতা ইলেকট্রন', 'Valence e⁻'], ['rad', 'ব্যাসার্ধ', 'Radius'], ['ie', 'আয়নীকরণ শক্তি', 'Ionisation energy'], ['eneg', 'তড়িৎ ঋণাত্মকতা', 'Electronegativity'], ['ea', 'ইলেকট্রন আসক্তি', 'Electron affinity'], ['mp', 'গলনাঙ্ক', 'Melting point']];
const MN = Object.fromEntries(MODES.map(m => [m[0], m]));
const UN = { rad: 'pm', ie: 'kJ/mol', eneg: '', ea: 'kJ/mol', mp: 'K' };
const NOTE = {
  cat: ['রং দেখে মৌলের পরিবার চেনা যায়। ধাতুকল্পের “সিঁড়ি” (B–Si–As–Te…) ধাতু ও অধাতুকে আলাদা করেছে।', 'Colours show element families; the metalloid staircase separates metals from non-metals.'],
  blk: ['সবশেষ ইলেকট্রন যে উপস্তরে প্রবেশ করে, সেটিই মৌলের ব্লক: s, p, d বা f।', 'The block is the subshell that receives the last electron.'],
  st: ['২৫°C তাপমাত্রায় ১১টি গ্যাস ও ২টি তরল (Br, Hg); Z ≥ ১০৪ এর অবস্থা অজানা।', 'At 25 °C: 11 gases and 2 liquids (Br, Hg); Z ≥ 104 unknown.'],
  val: ['মুখ্য গ্রুপে যোজ্যতা ইলেকট্রন = গ্রুপ নম্বর (১, ২) অথবা গ্রুপ − ১০ (১৩–১৮)। অবস্থান্তর মৌলে পরিবর্তনশীল।', 'Main groups: valence e⁻ = group (1, 2) or group − 10 (13–18).'],
  rad: ['পর্যায়ে বাম→ডানে কমে (নিউক্লিয়াসের টান বাড়ে); গ্রুপে উপর→নিচে বাড়ে (নতুন শক্তিস্তর)। এখানে সব মৌলের সমযোজী ব্যাসার্ধ (Cordero 2008) — তুলনা সমান রাখতে।', 'Covalent radii (Cordero 2008): shrink across, grow down.'],
  ie: ['পর্যায়ে ডানে বাড়ে, গ্রুপে নিচে কমে। ব্যতিক্রম: Be > B এবং N > O (অর্ধপূর্ণ/পূর্ণ উপস্তরের স্থিতিশীলতা)।', 'Rises across, falls down; dips at B and O.'],
  eneg: ['পর্যায়ে ডানে বাড়ে, গ্রুপে নিচে কমে। ফ্লুরিন সর্বোচ্চ (৩.৯৮, পলিং স্কেল); নিষ্ক্রিয় গ্যাসে সাধারণত মান ধরা হয় না।', 'Pauling scale; F is highest (3.98).'],
  ea: ['পর্যায়ে সাধারণত ডানে বাড়ে, হ্যালোজেনে সর্বোচ্চ। ব্যতিক্রম: Cl > F — F এর ছোট 2p উপস্তরে ইলেকট্রন-বিকর্ষণ বেশি। ধূসর = অ্যানায়ন স্থিতিশীল নয় (≈ ০)।', 'Peaks at halogens; Cl > F.'],
  mp: ['সরল প্রবণতা নেই: বন্ধন সবচেয়ে শক্ত মাঝের দিকে (C, W) — সেখানে সর্বোচ্চ, দুই প্রান্তে কম।', 'No simple trend; peaks mid-table (C, W).']
};
const TR = { rad: [-1, 1], ie: [1, -1], eneg: [1, -1], ea: [1, -1] };
const METAL = ['alk', 'ae', 'tr', 'zn', 'post', 'lan', 'act'];
const HL = [['all', 'সব', () => 1], ['metal', 'ধাতু', e => METAL.includes(e.cat)], ['mtl', 'ধাতুকল্প', e => e.cat === 'mtl'], ['non', 'অধাতু', e => ['nm', 'hal', 'noble'].includes(e.cat)], ['gas', 'গ্যাস', e => e.st === 'gas'], ['liq', 'তরল', e => e.st === 'liq'], ['ra', 'তেজস্ক্রিয়', e => e.ra]];
const HLF = Object.fromEntries(HL.map(h => [h[0], h[2]]));
const SHL = 'KLMNOPQ';
const unpaired = o => { let u = 0; for (const k in o) { const q = 2 * 'spdf'.indexOf(k[1]) + 1, n = o[k]; u += n <= q ? n : 2 * q - n; } return u; };
const shellsOf = Z => { const o = X.occZ(Z), s = []; for (const k in o) s[+k[0] - 1] = (s[+k[0] - 1] || 0) + o[k]; return [...s].map(x => x || 0); };
/* বোর অ্যানিমেশনের জন্য প্রতিটি শেলের ইলেকট্রন: 2 = জোড়, 1 = একক (হুন্ড) */
function unitsOf(Z) {
  const o = X.occZ(Z), s = [];
  Object.keys(o).forEach(k => { const q = 2 * 'spdf'.indexOf(k[1]) + 1, n = o[k], sh = +k[0] - 1; s[sh] = s[sh] || []; for (let i = 0; i < q; i++) { const c = n <= q ? (i < n ? 1 : 0) : (i < n - q ? 2 : 1); if (c) s[sh].push(c); } });
  return [...s].map(x => x || []);
}

/* ---- স্টাইল (একবারই যুক্ত হয়) ---- */
const CSS = `.xpt{--cw:22px;display:flex;flex-direction:column;gap:8px}
.xpt .xr{display:flex;gap:6px;align-items:center;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:2px 1px;scroll-snap-type:x proximity}
.xpt .xr::-webkit-scrollbar{display:none}
.xpt .xl{font-size:11.5px;color:var(--muted);flex:none;font-weight:600}
.xpt .xc{flex:none;border:1px solid var(--line-strong);background:var(--surface);color:var(--fg);border-radius:999px;padding:5px 11px;font:inherit;font-size:12.5px;min-height:32px;scroll-snap-align:start;transition:transform .15s,background .2s}
.xpt .xc:hover{transform:translateY(-1px)}
.xpt .xc.on{background:var(--accent);border-color:var(--accent);color:#fff}
.xpt .xq{flex:1 1 140px;min-width:120px;font:inherit;font-size:13px;color:var(--fg);background:var(--surface);border:1px solid var(--line-strong);border-radius:999px;padding:6px 12px;min-height:32px}
.xpt .xn{font-size:13px;line-height:1.55;background:var(--surface-2);border-radius:12px;padding:8px 12px}
.xpt .xn .en{display:block;color:var(--muted);font-size:12px}
.xpt .tchip{display:inline-block;margin:5px 6px 0 0;padding:1px 9px;border-radius:99px;font-size:11.5px;font-weight:700;background:var(--surface);color:var(--accent);border:1px solid var(--line)}
.xpt .xlg{display:flex;flex-wrap:wrap;gap:5px;align-items:center;font-size:12px;min-height:28px}
.xpt .lgi{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:99px;border:1px solid var(--line);background:var(--surface);color:var(--fg);font:inherit;font-size:12px;transition:transform .15s,border-color .15s}
.xpt .lgi i{width:11px;height:11px;border-radius:3px;flex:none}
.xpt .lgi.on,.xpt .lgi:hover{border-color:var(--accent);transform:translateY(-1px)}
.xpt .lgi small{color:var(--muted)}
.xpt .gbar{height:10px;flex:1 1 120px;max-width:240px;border-radius:5px;background:linear-gradient(90deg,#440154,#3b528b,#21918c,#5ec962,#fde725)}
.xpt .xw{position:relative;overflow-x:auto;overflow-y:visible;padding:6px 2px 8px;-webkit-overflow-scrolling:touch}
.xpt .xg{position:relative;display:grid;grid-template-columns:calc(var(--cw)*.55) repeat(18,var(--cw));grid-template-rows:calc(var(--cw)*.5) repeat(7,var(--cw)) calc(var(--cw)*.35) repeat(2,var(--cw));gap:calc(var(--cw)*.07);width:max-content;margin:0 auto}
.xpt .gh{font-size:calc(var(--cw)*.32);color:var(--muted);display:flex;align-items:flex-end;justify-content:center;font-family:var(--font-mono,monospace)}
.xpt .ph{font-size:calc(var(--cw)*.32);color:var(--muted);display:flex;align-items:center;justify-content:center;font-family:var(--font-mono,monospace)}
.xpt .t{position:relative;border:0;padding:0;margin:0;border-radius:calc(var(--cw)*.16);display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.05;background:var(--b,var(--surface-2));color:var(--f,var(--muted));font:inherit;cursor:pointer;transform-origin:50% 60%;transition:transform .14s ease-out,opacity .25s;-webkit-tap-highlight-color:transparent}
.xpt .t i{position:absolute;top:calc(var(--cw)*.05);left:calc(var(--cw)*.09);font-size:calc(var(--cw)*.2);font-style:normal;opacity:.82;font-family:var(--font-mono,monospace)}
.xpt .t b{font-size:calc(var(--cw)*.4);font-weight:700}
.xpt .t s{text-decoration:none;font-size:calc(var(--cw)*.17);opacity:.9;max-width:94%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:1px}
.xpt.small .t i,.xpt.small .t s{display:none}
.xpt.mid .t s{display:none}
.xpt.small .t b{font-size:calc(var(--cw)*.47)}
.xpt.small .xlg{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none}
.xpt.small .xlg::-webkit-scrollbar{display:none}
.xpt.small .lgi,.xpt.small .xlg>span{flex:none;white-space:nowrap}
.xpt.small .big{width:60px;height:66px;font-size:24px}
.xpt.fitm .xg{touch-action:pan-y}
.xpt .bub{position:absolute;z-index:8;pointer-events:none;min-width:64px;padding:6px 10px 7px;border-radius:14px;background:var(--surface);color:var(--fg);box-shadow:0 10px 28px rgba(0,0,0,.3);border:2px solid var(--bc,var(--accent));text-align:center;transform:translate(-50%,-100%);line-height:1.15;opacity:0;transition:opacity .12s}
.xpt .bub.on{opacity:1}
.xpt .bub b{display:block;font-size:24px}
.xpt .bub small{display:block;font-size:11px;color:var(--muted);white-space:nowrap}
.xpt .t{z-index:1}
.xpt .hlb{pointer-events:none;border-radius:calc(var(--cw)*.2);background:color-mix(in srgb,var(--accent) 22%,transparent);z-index:0;margin:calc(var(--cw)*-.05);display:none}
.xpt .hlb.on{display:block}
.xpt .t.off{opacity:.16;filter:grayscale(1)}
.xpt .t.sel{z-index:3;box-shadow:0 0 0 2.5px var(--fg),0 6px 16px rgba(0,0,0,.28)}
.xpt .t:active{transform:scale(1.14)}
.xpt .t.pop{animation:xptPop .5s cubic-bezier(.2,.9,.3,1.25) var(--d) backwards}
.xpt .t.wave{animation:xptWave .55s ease var(--wd)}
@keyframes xptPop{from{opacity:0;transform:scale(.45) translateY(8px)}}
@keyframes xptWave{40%{transform:scale(1.16);filter:brightness(1.18)}}
.xpt .xz{position:absolute;right:4px;top:4px;z-index:5}
.xpt .xd{border:1px solid var(--line);background:var(--surface);border-radius:16px;padding:12px;display:flex;flex-direction:column;gap:8px}
.xpt .xd .hd{display:flex;gap:12px;align-items:center}
.xpt .big{position:relative;width:74px;height:80px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:700;flex:none;box-shadow:0 6px 18px rgba(0,0,0,.2)}
.xpt .big i{position:absolute;top:5px;left:8px;font-size:12px;font-style:normal;font-weight:500}
.xpt .xd h3{margin:0;font-size:18px;line-height:1.25}
.xpt .xd .sub{font-size:12.5px;color:var(--muted)}
.xpt .xd .hd{position:relative;padding-right:80px}
.xpt .nav2{display:flex;gap:6px;position:absolute;top:0;right:0}
.xpt .nav2 button{width:34px;height:34px;border-radius:10px;border:1px solid var(--line);background:var(--surface-2);color:var(--fg);font:inherit}
.xpt .bw{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
.xpt .bw canvas{width:200px;height:200px;flex:none;margin:0 auto}
.xpt .bw .sh{font-size:12.5px;color:var(--muted);font-family:var(--font-mono,monospace)}
.xpt .bw .rt{flex:1 1 200px;min-width:0;display:flex;flex-direction:column;gap:6px}
.xpt dl{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;font-size:13px;margin:0}
.xpt dt{color:var(--muted)}.xpt dd{margin:0}
.xpt .orb{display:flex;flex-wrap:wrap;gap:6px 12px}
.xpt .or{display:flex;align-items:center;gap:2px;font-size:12px}.xpt .or b{min-width:22px;color:var(--muted);font-weight:600;font-family:var(--font-mono,monospace)}
.xpt .bx{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border:1.5px solid var(--line-strong);border-radius:5px;font-size:11.5px;letter-spacing:-2px;font-weight:700}
.xpt .bx.o2{background:color-mix(in srgb,var(--accent) 16%,transparent);border-color:var(--accent)}
.xpt .bx.o1{background:color-mix(in srgb,#f59e0b 22%,transparent);border-color:#f59e0b}
.xpt .hn{font-size:12.5px}
.xpt .m{display:grid;grid-template-columns:minmax(84px,auto) 1fr auto;gap:8px;align-items:center;font-size:12.5px}
.xpt .m .tr{height:7px;border-radius:4px;background:var(--surface-2);overflow:hidden}
.xpt .m .tr u{display:block;height:100%;width:0;border-radius:4px;background:var(--accent);transition:width .7s cubic-bezier(.2,.9,.3,1)}
.xpt .m span:last-child{text-align:right;font-variant-numeric:tabular-nums;font-family:var(--font-mono,monospace)}
.xpt .warn{font-size:12.5px;background:color-mix(in srgb,#f59e0b 16%,transparent);border-radius:10px;padding:6px 10px}
.xpt .tip{font-size:11.5px;color:var(--muted)}
@media (hover:none){.xpt .xc:hover,.xpt .lgi:hover{transform:none}}
html[data-motion="reduce"] .xpt *{animation:none!important;transition:none!important}
@media (prefers-reduced-motion:reduce){html:not([data-motion="full"]) .xpt *{animation:none!important;transition:none!important}}`;
function addCSS() { if (document.getElementById('xpt-css')) return; const s = document.createElement('style'); s.id = 'xpt-css'; s.textContent = CSS; document.head.appendChild(s); }

V.c3_ptable = {
  t: 'আধুনিক দীর্ঘ পর্যায় সারণি — ধর্ম, প্রবণতা ও পরমাণুর গঠন (১১৮টি মৌল)', k: ['2d', 'int', 'anim'],
  cap: 'উপরে ধর্ম বেছে নাও — রং বদলে প্রবণতা দেখাবে (→ পর্যায়ে, ↓ গ্রুপে)। নিচের রঙের তালিকায় চাপ দিলে শুধু সেই দল আলাদা হবে। যেকোনো মৌলে চাপ দাও — বোর মডেলে ইলেকট্রনের ঘূর্ণন, অরবিটাল বাক্সে পাউলি ও হুন্ডের নীতি, আর ধর্মের মান দেখাবে। ল্যান্থানাম (La) ও অ্যাক্টিনিয়াম (Ac) গ্রুপ ৩ এ; Ce–Lu ও Th–Lr নিচের দুই সারিতে।',
  html: () => `<div class="xpt" data-xpt>
    <div class="xr" data-modes><span class="xl">রং:</span>${MODES.map(([k, n]) => `<button type="button" class="xc ${k === 'cat' ? 'on' : ''}" data-m="${k}">${n}</button>`).join('')}</div>
    <div class="xr" data-hls><span class="xl">হাইলাইট:</span>${HL.map(([k, n]) => `<button type="button" class="xc ${k === 'all' ? 'on' : ''}" data-h="${k}">${n}</button>`).join('')}</div>
    <div class="xr"><input class="xq" type="search" data-q placeholder="খোঁজো: নাম / প্রতীক / Z (যেমন Fe, সোডিয়াম, 29)" autocomplete="off"><button type="button" class="xc" data-lang>English নাম</button><button type="button" class="xc" data-zoom>বড় করো</button></div>
    <div class="xn" data-note></div>
    <div class="xlg" data-lg></div>
    <div class="xw" data-wrap><div class="xg" data-grid></div></div>
    <div class="xd" data-det></div>
  </div>`,
  mount(el) {
    addCSS();
    const root = el.querySelector('[data-xpt]'), grid = root.querySelector('[data-grid]'), wrap = root.querySelector('[data-wrap]'), det = root.querySelector('[data-det]');
    const St = { m: 'cat', h: 'all', q: '', iso: null, sel: 26, en: false, zoom: false };
    const RM = X.rm(), fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
    /* টাইল তৈরি */
    let h = '';
    for (let c = 1; c <= 18; c++) h += `<div class="gh" style="grid-area:1/${c + 1}">${bn(c)}</div>`;
    for (let r = 1; r <= 7; r++) h += `<div class="ph" style="grid-area:${r + 1}/1">${bn(r)}</div>`;
    h += `<div class="ph" style="grid-area:10/1;font-size:calc(var(--cw)*.24)">৬</div><div class="ph" style="grid-area:11/1;font-size:calc(var(--cw)*.24)">৭</div>`;
    EL.forEach(e => { h += `<button type="button" class="t ${RM ? '' : 'pop'}" data-z="${e.Z}" style="grid-area:${e.row + 1}/${e.col + 1};--d:${e.col * 18 + e.row * 30}ms" aria-label="${e.name} (${e.sym}), Z ${e.Z}"><i>${e.Z}</i><b>${e.sym}</b><s></s></button>`; });
    grid.innerHTML = h;
    const TL = [...grid.querySelectorAll('.t')];
    setTimeout(() => TL.forEach(t => t.classList.remove('pop')), 1700);
    grid.addEventListener('animationend', ev => ev.target.classList.remove('wave'));
    /* মাপ: ফোনে পুরো সারণি স্ক্রিনে আঁটে; "বড় করো" দিলে টাইল বড় হয়ে পাশে স্ক্রল */
    let cw = 22;
    const size = () => {
      const W = wrap.clientWidth - 6;
      cw = St.zoom ? Math.max(46, Math.min(60, W / 19.3)) : Math.max(12, Math.min(58, (W - 4) / (18 * 1.07 + 0.55)));
      root.style.setProperty('--cw', cw.toFixed(2) + 'px');
      root.classList.toggle('small', cw < 30); root.classList.toggle('fitm', !St.zoom); root.classList.toggle('mid', cw >= 30 && cw < 44);
      cache();
    };
    /* কার্সরের কাছে টাইল একটু বড় (ডক-ইফেক্ট) — শুধু মাউস/প্যাডে; rAF দিয়ে প্রতি ফ্রেমে একবার */
    let CEN = [], mx = 0, my = 0, raf = 0, act = new Set();
    function cache() { CEN = TL.map(t => [t.offsetLeft + t.offsetWidth / 2, t.offsetTop + t.offsetHeight / 2]); }
    function fish() {
      raf = 0; const R = cw * 2.3, nxt = new Set(); let best = -1, bd = cw * 0.62;
      for (let i = 0; i < TL.length; i++) {
        const dx = CEN[i][0] - mx, dy = CEN[i][1] - my; if (Math.abs(dx) > R || Math.abs(dy) > R) continue;
        const d = Math.hypot(dx, dy); if (d < bd) { bd = d; best = i; } if (d >= R) continue;
        const k = 1 - d / R, s = 1 + 0.26 * k * k; nxt.add(i);
        TL[i].style.transform = `translate(${(-dx * 0.06 * k).toFixed(1)}px,${(-dy * 0.06 * k - 2 * k).toFixed(1)}px) scale(${s.toFixed(3)})`; TL[i].style.zIndex = s > 1.08 ? 4 : 2;
      }
      act.forEach(i => { if (!nxt.has(i)) { TL[i].style.transform = ''; TL[i].style.zIndex = ''; } }); act = nxt; if (best >= 0) setRel(EL[best]); else relOff();
    }
    const fishOff = () => { act.forEach(i => { TL[i].style.transform = ''; TL[i].style.zIndex = ''; }); act = new Set(); };
    if (fine && !RM) {
      grid.addEventListener('pointermove', ev => { if (ev.pointerType !== 'mouse' && ev.pointerType !== 'pen') return; const r = grid.getBoundingClientRect(); mx = ev.clientX - r.left; my = ev.clientY - r.top; if (!raf) raf = requestAnimationFrame(fish); });
      grid.addEventListener('pointerleave', () => { cancelAnimationFrame(raf); raf = 0; fishOff(); relOff(); });
    }
    /* ফোনে: আঙুল সারি বরাবর টানলে টাইলগুলো ফুলে ওঠে + উপরে বড় করে মৌলের নাম দেখায়; ছেড়ে দিলে সেই মৌল খোলে */
    const bub = document.createElement('div'); bub.className = 'bub'; wrap.appendChild(bub);
    let tch = null, dragged = false;
    const tileAt = (x, y) => { const t = document.elementFromPoint(x, y); return t && t.closest ? t.closest('.xg .t') : null; };
    const showBub = (t, x, y) => {
      if (!t) { bub.classList.remove('on'); return; }
      const e = EL[t.dataset.z - 1], m = St.m, v = DC[m] ? '' : (e[m] == null ? '—' : fmt(e[m]) + ' ' + UN[m]);
      bub.style.setProperty('--bc', colorOf(e, m) || 'var(--line-strong)');
      bub.innerHTML = `<small>${bn(e.Z)}</small><b>${e.sym}</b><small>${St.en ? e.en : e.name}</small>${v ? `<small><b style="display:inline;font-size:12px;color:var(--fg)">${v}</b></small>` : ''}`;
      const wr = wrap.getBoundingClientRect(); bub.style.left = Math.max(40, Math.min(wr.width - 40, x - wr.left + wrap.scrollLeft)) + 'px'; bub.style.top = Math.max(60, y - wr.top - cw * 0.9) + 'px'; bub.classList.add('on');
    };
    grid.addEventListener('pointerdown', ev => { if (ev.pointerType !== 'touch' || St.zoom) return; tch = { x: ev.clientX, y: ev.clientY }; dragged = false; });
    grid.addEventListener('pointermove', ev => {
      if (ev.pointerType !== 'touch' || !tch || St.zoom) return;
      if (!dragged && Math.abs(ev.clientX - tch.x) < 6) return; dragged = true;
      const r = grid.getBoundingClientRect(); mx = ev.clientX - r.left; my = ev.clientY - r.top; if (!RM && !raf) raf = requestAnimationFrame(fish);
      showBub(tileAt(ev.clientX, ev.clientY), ev.clientX, ev.clientY);
    });
    const tEnd = ev => { if (!tch) return; const was = dragged; tch = null; bub.classList.remove('on'); cancelAnimationFrame(raf); raf = 0; fishOff(); if (was && ev.type === 'pointerup') { const t = tileAt(ev.clientX, ev.clientY); if (t) { openEl(+t.dataset.z, true); det.scrollIntoView({ behavior: RM ? 'auto' : 'smooth', block: 'nearest' }); } supClick = Date.now(); } };
    let supClick = 0;
    grid.addEventListener('pointerup', tEnd); grid.addEventListener('pointercancel', tEnd);
    /* একই পর্যায়/গ্রুপ আলো */
    let relZ = 0; const hR = document.createElement('div'), hC = document.createElement('div'); hR.className = hC.className = 'hlb'; grid.prepend(hR, hC);
    const relOff = () => { if (!relZ) return; hR.classList.remove('on'); hC.classList.remove('on'); relZ = 0; };
    if (fine && RM) grid.addEventListener('pointerover', ev => { const t = ev.target.closest('.t'); if (t) setRel(EL[t.dataset.z - 1]); });
    function setRel(e) { if (relZ === e.Z) return; relZ = e.Z; if (e.row <= 7) { hR.style.gridArea = `${e.row + 1}/2/${e.row + 2}/20`; hR.classList.add('on'); } else hR.classList.remove('on'); if (e.block !== 'f') { hC.style.gridArea = `2/${e.col + 1}/9/${e.col + 2}`; hC.classList.add('on'); } else hC.classList.remove('on'); }
    const T2 = (b, en) => St.en ? `${b}<span class="en">${en}</span>` : b;
    const match = e => { const q = St.q.trim().toLowerCase(); if (!q) return true; const qd = q.replace(/[০-৯]/g, d => '০১২৩৪৫৬৭৮৯'.indexOf(d)); return e.sym.toLowerCase() === q || e.en.toLowerCase().includes(q) || e.name.includes(St.q.trim()) || String(e.Z) === qd; };
    function draw() {
      const m = St.m, num = !DC[m];
      TL.forEach((t, i) => {
        const e = EL[i], c = colorOf(e, m), on = HLF[St.h](e) && match(e) && (St.iso == null || (!num && String(dval(e, m)) === String(St.iso)));
        t.style.setProperty('--b', c || 'var(--surface-2)'); t.style.setProperty('--f', c ? ink(c) : 'var(--muted)');
        t.classList.toggle('off', !on); t.classList.toggle('sel', St.sel === e.Z);
        t.querySelector('s').textContent = num ? (e[m] == null ? '—' : fmt(e[m])) : (St.en ? e.en : e.name);
      });
      root.querySelectorAll('[data-m]').forEach(b => b.classList.toggle('on', b.dataset.m === m));
      root.querySelectorAll('[data-h]').forEach(b => b.classList.toggle('on', b.dataset.h === St.h));
      const tr = TR[m];
      root.querySelector('[data-note]').innerHTML = `<b>${MN[m][1]}</b> — ${NOTE[m][0]}${St.en ? `<span class="en">${MN[m][2]}: ${NOTE[m][1]}</span>` : ''}${tr ? `<div><span class="tchip">→ পর্যায়ে ${tr[0] > 0 ? '▲ বাড়ে' : '▼ কমে'}</span><span class="tchip">↓ গ্রুপে ${tr[1] > 0 ? '▲ বাড়ে' : '▼ কমে'}</span></div>` : ''}`;
      const lg = root.querySelector('[data-lg]');
      if (num) { const [a, b] = RNG[m], u = UN[m]; lg.innerHTML = `<span class="mono">${fmt(a)} ${u}</span><span class="gbar"></span><span class="mono">${fmt(b)} ${u}</span><span class="tip">· ধূসর = তথ্য নেই</span>`; }
      else lg.innerHTML = Object.keys(DC[m]).map(k => { const d = DC[m][k], n = EL.filter(e => String(dval(e, m)) === k).length; return n ? `<button type="button" class="lgi ${String(St.iso) === k ? 'on' : ''}" data-iso="${k}"><i style="background:${d[1]}"></i>${d[0]} <small>${bn(n)}</small></button>` : ''; }).join('') + `<span class="tip">· চাপ দিলে শুধু সেই দল</span>`;
    }
    /* বিস্তারিত প্যানেল */
    let A = null, units = [], col = '#888', PC = null;
    function orbHTML(Z) {
      const o = X.occZ(Z), cores = [[86, 'Rn'], [54, 'Xe'], [36, 'Kr'], [18, 'Ar'], [10, 'Ne'], [2, 'He']], cr = cores.find(c => Z > c[0]), co = cr ? X.occZ(cr[0], false) : {};
      const keys = Object.keys(o).filter(k => !(co[k] && co[k] === o[k])).sort((a, b) => (+a[0] - +b[0]) || ('spdf'.indexOf(a[1]) - 'spdf'.indexOf(b[1])));
      const rows = keys.map(k => { const q = 2 * 'spdf'.indexOf(k[1]) + 1, n = o[k]; let bx = ''; for (let i = 0; i < q; i++) { const c = n <= q ? (i < n ? 1 : 0) : (i < n - q ? 2 : 1); bx += `<span class="bx o${c}">${c === 2 ? '↑↓' : c === 1 ? '↑' : ''}</span>`; } return `<div class="or"><b>${k}</b>${bx}</div>`; }).join('');
      const un = unpaired(o);
      return `<div class="orb">${cr ? `<div class="or"><b>[${cr[1]}]</b></div>` : ''}${rows}</div><div class="hn">অযুগ্ম ইলেকট্রন: <b>${bn(un)}</b> — ${un ? 'প্যারাচৌম্বক (চুম্বকে আকৃষ্ট হয়)' : 'ডায়াচৌম্বক (সব ইলেকট্রন জোড়ায়)'}</div>
      <div class="tip">প্রতিটি ঘর একটি অরবিটাল — সর্বোচ্চ ২টি ইলেকট্রন, বিপরীত স্পিনে (পাউলির বর্জন নীতি)। সমশক্তির অরবিটালে আগে একটি করে বসে, পরে জোড় বাঁধে (হুন্ডের নীতি)। ${Z > 20 && Z !== 24 && Z !== 29 ? '' : ''}</div>`;
    }
    function openEl(Z, wave) {
      Z = Math.max(1, Math.min(118, Z)); St.sel = Z; PC = null; const e = EL[Z - 1]; col = X.PTCAT[e.cat][1]; units = unitsOf(Z);
      const sh = shellsOf(Z), row = (k, v) => `<dt>${k}</dt><dd>${v}</dd>`;
      const mt = (key, label) => { const v = e[key], mxv = RNG[key][1]; return `<div class="m"><span>${label}</span><div class="tr"><u data-w="${v == null ? 0 : Math.max(3, v / mxv * 100)}"></u></div><span>${v == null ? '—' : fmt(v) + (UN[key] ? ' ' + UN[key] : '')}</span></div>`; };
      const book = Z <= 56 && X.RAD && X.RAD[Z - 1] != null ? ` <span class="tip">(বইয়ের সারণিতে ${bn(X.RAD[Z - 1])} pm${METAL.includes(e.cat) ? ' — ধাতব ব্যাসার্ধ' : ''})</span>` : '';
      det.innerHTML = `<div class="hd"><div class="big" style="background:${col};color:${ink(col)}"><i>${bn(Z)}</i>${e.sym}</div><div style="min-width:0"><h3>${e.name} <span class="sub">${e.en}</span></h3><div class="sub">${X.PTCAT[e.cat][0]} · পারমাণবিক ভর ${e.mass} u</div></div><div class="nav2"><button type="button" data-step="-1" aria-label="আগের মৌল">‹</button><button type="button" data-step="1" aria-label="পরের মৌল">›</button></div></div>
      <div class="bw"><canvas width="400" height="400" role="img" aria-label="${e.name} এর বোর মডেল"></canvas><div class="rt"><div class="sh">${sh.map((n, i) => SHL[i] + ' ' + bn(n)).join(' · ')}</div>${orbHTML(Z)}</div></div>
      <dl>${row('পর্যায়', bn(e.per))}${row('গ্রুপ', e.block === 'f' ? (e.per === 6 ? 'ল্যান্থানাইড (গ্রুপ ৩ এর অংশ)' : 'অ্যাক্টিনাইড (গ্রুপ ৩ এর অংশ)') : bn(e.g))}${row('ব্লক', e.block + '-ব্লক')}${row('অবস্থা (২৫°C)', DC.st[e.st][0])}${row('যোজ্যতা ইলেকট্রন', e.val == null ? 'পরিবর্তনশীল' : bn(e.val))}${row('ইলেকট্রন বিন্যাস', `<b class="mono">${X.cfgZ(Z)}</b>${X.EXC[Z] ? ' <span class="tip">(ব্যতিক্রমী)</span>' : ''}`)}</dl>
      ${mt('rad', 'সমযোজী ব্যাসার্ধ')}${book ? `<div class="tip" style="margin-top:-4px">${book}</div>` : ''}${mt('ie', 'আয়নীকরণ শক্তি')}${mt('eneg', 'তড়িৎ ঋণাত্মকতা')}${mt('ea', 'ইলেকট্রন আসক্তি')}${mt('mp', 'গলনাঙ্ক')}
      ${e.ra ? '<div class="warn">☢ তেজস্ক্রিয় মৌল — স্থিতিশীল কোনো আইসোটোপ নেই।</div>' : ''}${Z >= 104 ? '<div class="warn">অতিভারী কৃত্রিম মৌল: বিন্যাস ও অবস্থা তাত্ত্বিক পূর্বাভাস।</div>' : ''}`;
      requestAnimationFrame(() => requestAnimationFrame(() => det.querySelectorAll('u').forEach(u => { u.style.width = u.dataset.w + '%'; })));
      if (A) A.stop(); const cv = det.querySelector('canvas'); A = X.anim(cv, (dt, ts) => bohr(cv, ts || performance.now())); A.draw();
      if (wave && !RM) { const c = e.col, r = e.row; TL.forEach((t, j) => { const o = EL[j], d = Math.hypot(o.col - c, o.row - r); if (d > 6) return; t.style.setProperty('--wd', (d * 34) + 'ms'); t.classList.remove('wave'); void t.offsetWidth; t.classList.add('wave'); }); }
      draw();
    }
    function bohr(c, ts) {
      const g = c.getContext('2d'), d = Math.min(2, window.devicePixelRatio || 1), S = 200;
      if (c.width !== S * d) { c.width = S * d; c.height = S * d; }
      g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, S, S);
      const C = PC || (PC = X.C()), n = units.length, cx = S / 2, R = i => n > 1 ? 24 + i * (70 / (n - 1)) : 56, p = RM ? 1 : 1 + 0.1 * Math.sin(ts / 450);
      const gr = g.createRadialGradient(cx, cx, 1, cx, cx, 18 * p); gr.addColorStop(0, '#fff'); gr.addColorStop(0.35, col); gr.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(cx, cx, 18 * p, 0, 7); g.fill();
      units.forEach((k, i) => {
        const r = R(i); g.strokeStyle = C.mu || '#888'; g.globalAlpha = 0.35; g.lineWidth = 1; g.beginPath(); g.arc(cx, cx, r, 0, 7); g.stroke(); g.globalAlpha = 1;
        const m = k.length;
        for (let j = 0; j < m; j++) {
          const a = (RM ? 0 : ts * 0.0007 * (1.7 / (i + 1))) + j * 2 * Math.PI / m + i * 0.6, pr = k[j] === 2, dd = pr ? 4 / r : 0;
          const dot = (x, fill) => { g.fillStyle = fill; g.strokeStyle = col; g.lineWidth = 1.3; g.beginPath(); g.arc(cx + r * Math.cos(x), cx + r * Math.sin(x), 2.6, 0, 7); g.fill(); if (fill !== col) g.stroke(); };
          if (pr) { dot(a - dd, col); dot(a + dd, C.sf || '#fff'); }
          else { g.globalAlpha = RM ? 1 : 0.55 + 0.45 * Math.sin(ts / 240 + j + i); dot(a, col); g.globalAlpha = 1; }
        }
      });
      g.fillStyle = C.mu || '#888'; g.font = `10px ${C.font}`; g.textAlign = 'center'; g.fillText('●○ জোড় (বিপরীত স্পিন) · জ্বলজ্বলে ● = অযুগ্ম', cx, S - 4);
    }
    /* ইভেন্ট */
    root.addEventListener('click', ev => {
      const t = ev.target.closest('.t'); if (t && Date.now() - supClick < 400) return; if (t) { openEl(+t.dataset.z, true); if (!fine) det.scrollIntoView({ behavior: RM ? 'auto' : 'smooth', block: 'nearest' }); return; }
      const b = ev.target.closest('button'); if (!b) return;
      if (b.dataset.m) { St.m = b.dataset.m; St.iso = null; draw(); }
      else if (b.dataset.h) { St.h = b.dataset.h; draw(); }
      else if (b.dataset.iso != null) { St.iso = String(St.iso) === b.dataset.iso ? null : b.dataset.iso; draw(); }
      else if (b.dataset.step) openEl(St.sel + (+b.dataset.step), true);
      else if (b.hasAttribute('data-lang')) { St.en = !St.en; b.classList.toggle('on', St.en); draw(); openEl(St.sel); }
      else if (b.hasAttribute('data-zoom')) { St.zoom = !St.zoom; b.classList.toggle('on', St.zoom); b.textContent = St.zoom ? 'স্ক্রিনে আঁটাও' : 'বড় করো'; size(); }
    });
    const q = root.querySelector('[data-q]');
    q.addEventListener('input', () => { St.q = q.value; draw(); });
    q.addEventListener('keydown', ev => { if (ev.key === 'Enter') { const f = EL.find(match); if (f) openEl(f.Z, true); } });
    size(); draw(); openEl(26);
    const unR = X.onResize(wrap, size);
    return () => { unR(); if (A) A.stop(); cancelAnimationFrame(raf); };
  }
};
})();
