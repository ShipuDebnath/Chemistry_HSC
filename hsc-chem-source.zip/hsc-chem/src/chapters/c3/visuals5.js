/* Chapter 3 visuals part 5 — intermolecular forces, hydrogen bonding, water (3.17–3.20) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C3 = window.C3V;
const bn = X.bn, f1 = v => (+v).toFixed(1);
const INK = '#1b1b1f';
const CPK = C3.CPK;

/* ======================= ৩.১৭ ভ্যানডার ওয়ালস বল: তিন প্রকার (অ্যানিমেশন) ======================= */
V.c3_vdw = {
  t: 'ভ্যানডার ওয়ালস বলের তিন রূপ: ডাইপোল-ডাইপোল, আবিষ্ট ডাইপোল ও লন্ডন বল', k: ['anim', 'int'],
  cap: '"লন্ডন বল" দৃশ্যে দুটি আর্গন পরমাণুর ইলেকট্রন মেঘ (নীল) ক্রমাগত দোলে — কোনো এক মুহূর্তে বাম পরমাণুর মেঘ একদিকে সরে গিয়ে তাৎক্ষণিক ডাইপোল তৈরি করে, আর সাথে সাথে ডান পরমাণুর মেঘ বিপরীত দিকে সরে আবিষ্ট ডাইপোল হয়। দুটির δ⁺ ও δ⁻ পাশাপাশি থাকায় গড়ে সবসময় আকর্ষণ। "ডাইপোল-আবিষ্ট" দৃশ্যে পানির স্থায়ী ডাইপোল O₂ এর মেঘকে বিকৃত করে। "ডাইপোল-ডাইপোল" দৃশ্যে HCl অণুগুলো মাথা-লেজ (δ⁺···δ⁻) সজ্জায় থাকে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['lon', 'লন্ডন বল'], ['ind', 'ডাইপোল-আবিষ্ট ডাইপোল'], ['dd', 'ডাইপোল-ডাইপোল']], 'lon')}</div><div data-svg></div><div class="ctl"><button class="btn sm" data-pp></button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let m = 'lon', t = 0, raf = 0, last = 0, paused = X.rm();
    const pp = el.querySelector('[data-pp]'); const upd = () => pp.innerHTML = paused ? X.ico('play') + 'চালাও' : X.ico('pause') + 'থামাও'; pp.onclick = () => { paused = !paused; upd(); if (!paused) loop(); }; upd();
    const cloud = (cx, cy, R, sh, id, col = '#5B9BD5') => `<defs><radialGradient id="${id}" cx="${(0.5 + sh * 0.35).toFixed(3)}" cy="0.5" r="0.6"><stop offset="0" stop-color="${col}" stop-opacity=".7"/><stop offset="1" stop-color="${col}" stop-opacity=".08"/></radialGradient></defs><ellipse cx="${f1(cx + sh * R * 0.25)}" cy="${cy}" rx="${f1(R * (1 + Math.abs(sh) * 0.12))}" ry="${f1(R * (1 - Math.abs(sh) * 0.06))}" fill="url(#${id})" stroke="${col}" stroke-opacity=".5"/>`;
    const dl = (x, y, sgn) => `<text x="${f1(x)}" y="${f1(y)}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:${sgn > 0 ? '#E8775C' : '#2F86D6'}">${sgn > 0 ? 'δ⁺' : 'δ⁻'}</text>`;
    const draw = () => {
      let s = '';
      if (m === 'lon') {
        const sh = Math.sin(t * 2.2) * 0.9; // instantaneous shift of left cloud (−1..1)
        const cy = 90, R = 46, xa = 120, xb = 280;
        s += cloud(xa, cy, R, sh, 'c3l1') + cloud(xb, cy, R, sh * 0.85, 'c3l2');
        s += `<circle cx="${xa}" cy="${cy}" r="6" fill="#E9A53B"/><circle cx="${xb}" cy="${cy}" r="6" fill="#E9A53B"/><text x="${xa}" y="${cy + 64}" text-anchor="middle" style="font-size:12px;font-weight:700">Ar</text><text x="${xb}" y="${cy + 64}" text-anchor="middle" style="font-size:12px;font-weight:700">Ar</text>`;
        if (Math.abs(sh) > 0.25) { const sg = Math.sign(sh); s += dl(xa - sg * 34, cy - 50, sg) + dl(xa + sg * 34, cy - 50, -sg) + dl(xb - sg * 34, cy - 50, sg) + dl(xb + sg * 34, cy - 50, -sg); s += `<text x="200" y="${cy + 4}" text-anchor="middle" style="font-size:18px;fill:#7E57C2">⟷</text><text x="200" y="${cy + 22}" text-anchor="middle" style="font-size:10px;fill:#7E57C2;font-weight:600">আকর্ষণ</text>`; }
        s += `<text x="${xa}" y="20" text-anchor="middle" class="tm" style="font-size:10.5px">তাৎক্ষণিক ডাইপোল</text><text x="${xb}" y="20" text-anchor="middle" class="tm" style="font-size:10.5px">আবিষ্ট ডাইপোল</text>`;
        out.innerHTML = '<b>লন্ডন বিচ্ছুরণ বল</b>: সব অণু ও পরমাণুতে থাকে; অপোলার কণার (He, Ar, H₂, Cl₂, CH₄) মধ্যে এটিই একমাত্র আকর্ষণ। ইলেকট্রন মেঘ যত বড় ও সহজে বিকৃত হয় (পোলারায়নযোগ্যতা বেশি), বল তত বেশি।';
      } else if (m === 'ind') {
        const cy = 92, sh = 0.55 + Math.sin(t * 1.5) * 0.08;
        // water (permanent dipole), O facing right
        s += `<g transform="translate(110 ${cy})"><circle cx="16" cy="0" r="22" fill="${CPK.O}"/><circle cx="-12" cy="-20" r="14" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><circle cx="-12" cy="20" r="14" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/></g>` + dl(80, cy - 40, 1) + dl(150, cy - 32, -1);
        s += cloud(280, cy, 44, sh, 'c3i1', '#9DB6CC') + `<circle cx="266" cy="${cy}" r="12" fill="${CPK.O}"/><circle cx="294" cy="${cy}" r="12" fill="${CPK.O}"/><line x1="272" y1="${cy - 3}" x2="288" y2="${cy - 3}" stroke="#fff" stroke-width="1.5"/><line x1="272" y1="${cy + 3}" x2="288" y2="${cy + 3}" stroke="#fff" stroke-width="1.5"/>` + dl(244, cy - 46, 1) + dl(318, cy - 46, -1);
        s += `<text x="200" y="${cy + 4}" text-anchor="middle" style="font-size:18px;fill:#7E57C2">⟷</text><text x="110" y="${cy + 62}" text-anchor="middle" style="font-size:12px;font-weight:700">H₂O (স্থায়ী ডাইপোল)</text><text x="280" y="${cy + 62}" text-anchor="middle" style="font-size:12px;font-weight:700">O₂ (আবিষ্ট ডাইপোল)</text>`;
        out.innerHTML = '<b>ডাইপোল-আবিষ্ট ডাইপোল (ডিবাই) বল</b>: পোলার অণুর δ⁻ প্রান্ত অপোলার অণুর ইলেকট্রন মেঘকে দূরে ঠেলে দেয় — অপোলার অণুতে সাময়িক ডাইপোল আবিষ্ট হয় এবং দুটি আকর্ষিত হয়। এ কারণেই অপোলার O₂ পানিতে সামান্য দ্রবীভূত হয় (মাছের শ্বাস)।';
      } else {
        const wob = k => Math.sin(t * 1.3 + k) * 4;
        [[60, 60, 0], [190, 60, 1], [320, 60, 2], [125, 128, 3], [255, 128, 4]].forEach(([x, y, k]) => {
          const a = wob(k); s += `<g transform="translate(${x} ${y}) rotate(${f1(a)})"><line x1="-18" y1="0" x2="18" y2="0" class="s-fg" stroke-width="3"/><circle cx="-20" cy="0" r="11" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><circle cx="18" cy="0" r="17" fill="${CPK.Cl}"/><text x="18" y="4.5" text-anchor="middle" style="font-size:11px;font-weight:700;fill:#fff">Cl</text><text x="-20" y="4" text-anchor="middle" style="font-size:10px;font-weight:700;fill:${INK}">H</text><text x="-22" y="-16" text-anchor="middle" style="font-size:10px;font-weight:700;fill:#E8775C">δ⁺</text><text x="18" y="-22" text-anchor="middle" style="font-size:10px;font-weight:700;fill:#2F86D6">δ⁻</text></g>`;
        });
        [[95, 60], [225, 60], [190, 128]].forEach(([x, y]) => s += `<line x1="${x}" y1="${y}" x2="${x + 34}" y2="${y}" stroke="#7E57C2" stroke-width="1.6" stroke-dasharray="3 3"/>`);
        s += `<text x="200" y="176" text-anchor="middle" class="tm" style="font-size:10.5px">ড্যাশ রেখা: δ⁻ (Cl) ··· δ⁺ (H) আকর্ষণ — মাথা-লেজ সজ্জা</text>`;
        out.innerHTML = '<b>ডাইপোল-ডাইপোল (কিসম) বল</b>: স্থায়ী ডাইপোলযুক্ত পোলার অণুগুলো এমনভাবে সজ্জিত হয় যাতে এক অণুর δ⁺ প্রান্ত পাশের অণুর δ⁻ প্রান্তের কাছে থাকে। পোলার অণুতে লন্ডন বলও একই সাথে কাজ করে। উদাহরণ: HCl, SO₂, অ্যাসিটোন।';
      }
      box.innerHTML = X.svg(400, m === 'dd' ? 186 : 170, s, 'ভ্যানডার ওয়ালস');
    };
    const loop = () => { cancelAnimationFrame(raf); last = 0; const st = tt => { const dt = last ? Math.min(0.05, (tt - last) / 1000) : 0.016; last = tt; t += dt; draw(); if (!paused) raf = requestAnimationFrame(st); }; raf = requestAnimationFrame(st); };
    X.onSeg(el, 'm', k => { m = k; draw(); });
    draw(); if (!paused) loop();
    return () => cancelAnimationFrame(raf);
  }
};

/* ======================= ৩.১৭.১ স্ফুটনাঙ্কের উপর লন্ডন বলের প্রভাব ======================= */
const VB = {
  ng: { t: 'নিষ্ক্রিয় গ্যাস', l: ['He', 'Ne', 'Ar', 'Kr', 'Xe', 'Rn'], v: [-269, -246, -186, -153, -108, -62], e: [2, 10, 18, 36, 54, 86], n: 'ইলেকট্রন সংখ্যা বাড়লে পোলারায়নযোগ্যতা ও লন্ডন বল বাড়ে — স্ফুটনাঙ্ক নিয়মিত বাড়ে।' },
  hal: { t: 'হ্যালোজেন', l: ['F₂', 'Cl₂', 'Br₂', 'I₂'], v: [-188, -34, 59, 184], e: [18, 34, 70, 106], n: 'F₂ ও Cl₂ এর স্ফুটনাঙ্ক ঘরের তাপমাত্রার (২৫ °C) নিচে — গ্যাস; Br₂ এর গলনাঙ্ক নিচে কিন্তু স্ফুটনাঙ্ক উপরে — তরল; I₂ এর গলনাঙ্কও (114 °C) উপরে — কঠিন।', room: true },
  alk: { t: 'অ্যালকেন (সরল শিকল)', l: ['C₁', 'C₂', 'C₃', 'C₄', 'C₅', 'C₆', 'C₇', 'C₈'], v: [-162, -89, -42, -0.5, 36, 69, 98, 126], e: [10, 18, 26, 34, 42, 50, 58, 66], n: 'প্রতিটি অতিরিক্ত –CH₂– একক শিকল লম্বা করে, স্পর্শতল ও ইলেকট্রন বাড়ায় — স্ফুটনাঙ্ক প্রায় ২০–৩০ °C করে বাড়ে। C₁–C₄ গ্যাস (LPG), C₅ থেকে তরল।', room: true }
};
V.c3_vdwBp = {
  t: 'লন্ডন বল ও স্ফুটনাঙ্ক: ইলেকট্রন সংখ্যা, শিকলের দৈর্ঘ্য ও আকৃতি', k: ['2d', 'int'],
  cap: 'প্রথম তিন দৃশ্যে স্তম্ভের উচ্চতা স্ফুটনাঙ্ক (°C, নিচের অংশ ঋণাত্মক); সবুজ ড্যাশ রেখা ঘরের তাপমাত্রা ২৫ °C — রেখার নিচে যাদের স্ফুটনাঙ্ক, তারা ঘরের তাপমাত্রায় গ্যাস। "সমাণু" দৃশ্যে একই সংকেত C₅H₁₂ এর তিনটি অণুর আকৃতি: সরল শিকল পাশাপাশি অনেক বিন্দুতে স্পর্শ করে (বেশি লন্ডন বল), গোলাকার নিওপেন্টেন কেবল অল্প জায়গায় (কম লন্ডন বল)।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['ng', 'নিষ্ক্রিয় গ্যাস'], ['hal', 'হ্যালোজেন'], ['alk', 'অ্যালকেন'], ['iso', 'C₅H₁₂ সমাণু']], 'hal')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = m => {
      let s = '';
      if (m !== 'iso') {
        const D = VB[m], x0 = 50, x1 = 392, y0 = 214, y1 = 24, lo = -300, hi = 200, ty = v => y0 - (v - lo) / (hi - lo) * (y0 - y1), z = ty(0), n = D.l.length, cw = (x1 - x0) / n;
        [-300, -200, -100, 0, 100, 200].forEach(v => s += `<line x1="${x0}" y1="${f1(ty(v))}" x2="${x1}" y2="${f1(ty(v))}" class="s-ln" opacity="${v === 0 ? 0.8 : 0.2}"/><text x="${x0 - 4}" y="${f1(ty(v) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:10px">${v}</text>`);
        s += `<line x1="${x0}" y1="${f1(ty(25))}" x2="${x1}" y2="${f1(ty(25))}" stroke="#2BB24C" stroke-width="1.6" stroke-dasharray="5 4"/><text x="${x1}" y="${f1(ty(25) - 4)}" text-anchor="end" style="font-size:9.5px;fill:#2BB24C;font-weight:600">ঘরের তাপমাত্রা ২৫ °C</text>`;
        D.v.forEach((v, i) => { const x = x0 + i * cw + cw * 0.18, w = cw * 0.64, y = ty(v); s += `<rect x="${f1(x)}" y="${f1(Math.min(y, z))}" width="${f1(w)}" height="${f1(Math.abs(z - y))}" rx="3" fill="${v > 25 ? '#E9A53B' : '#6FA8DC'}"/><text x="${f1(x + w / 2)}" y="${f1(v >= 0 ? y - 4 : y + 12)}" text-anchor="middle" class="mono" style="font-size:${n > 6 ? 9 : 10}px;font-weight:600">${v}</text><text x="${f1(x + w / 2)}" y="${y0 + 14}" text-anchor="middle" style="font-size:${n > 6 ? 11 : 12.5}px;font-weight:600">${D.l[i]}</text><text x="${f1(x + w / 2)}" y="${y0 + 27}" text-anchor="middle" class="tm mono" style="font-size:9px">${D.e[i]}e⁻</text>`; });
        s += `<text x="${x0}" y="${y1 - 8}" class="tm" style="font-size:10.5px">স্ফুটনাঙ্ক (°C)</text>`;
        box.innerHTML = X.svg(400, y0 + 34, s, D.t);
        out.innerHTML = `<b>${D.t}</b>: ${D.n}<br><span class="small"><span style="color:#6FA8DC">■</span> ২৫ °C এ গ্যাস · <span style="color:#E9A53B">■</span> ২৫ °C এ তরল বা কঠিন</span>`;
      } else {
        const C = (x, y) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="11" fill="${CPK.C}" stroke="rgba(0,0,0,.35)"/>`;
        const Hh = (x, y) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="6.5" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/>`;
        const col = (x, y, w, h, rx) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="#5B9BD5" opacity=".14" stroke="#5B9BD5" stroke-dasharray="3 3"/>`;
        // n-pentane zigzag
        let s1 = col(14, 16, 150, 60, 28);
        const zx = [30, 60, 90, 120, 150], zy = [56, 36, 56, 36, 56];
        zx.forEach((x, i) => { if (i) s1 += `<line x1="${zx[i - 1]}" y1="${zy[i - 1]}" x2="${x}" y2="${zy[i]}" class="s-fg" stroke-width="3"/>`; });
        zx.forEach((x, i) => s1 += C(x, zy[i]));
        s += `<text x="90" y="98" text-anchor="middle" style="font-size:12px;font-weight:700">n-পেন্টেন</text><text x="90" y="113" text-anchor="middle" class="mono" style="font-size:11px">36 °C</text>` + s1;
        // isopentane
        let s2 = col(176, 16, 112, 72, 32); const ix = [194, 222, 250, 276], iy = [60, 40, 60, 40];
        ix.forEach((x, i) => { if (i) s2 += `<line x1="${ix[i - 1]}" y1="${iy[i - 1]}" x2="${x}" y2="${iy[i]}" class="s-fg" stroke-width="3"/>`; }); s2 += `<line x1="222" y1="40" x2="222" y2="74" class="s-fg" stroke-width="3"/>`;
        ix.forEach((x, i) => s2 += C(x, iy[i])); s2 += C(222, 74);
        s += s2 + `<text x="232" y="106" text-anchor="middle" style="font-size:12px;font-weight:700">আইসোপেন্টেন</text><text x="232" y="121" text-anchor="middle" class="mono" style="font-size:11px">28 °C</text>`;
        // neopentane
        let s3 = `<circle cx="346" cy="52" r="40" fill="#5B9BD5" opacity=".14" stroke="#5B9BD5" stroke-dasharray="3 3"/>`; [[346, 22], [318, 64], [374, 64], [346, 70]].forEach(([x, y]) => s3 += `<line x1="346" y1="52" x2="${x}" y2="${y}" class="s-fg" stroke-width="3"/>`); [[346, 22], [318, 64], [374, 64]].forEach(([x, y]) => s3 += C(x, y)); s3 += C(346, 52) + C(346, 74);
        s += s3 + `<text x="346" y="110" text-anchor="middle" style="font-size:12px;font-weight:700">নিওপেন্টেন</text><text x="346" y="125" text-anchor="middle" class="mono" style="font-size:11px">9.5 °C</text>`;
        // contact illustration
        s += `<line x1="10" y1="140" x2="390" y2="140" class="s-ln" stroke-dasharray="2 3"/><text x="10" y="158" style="font-size:11px;font-weight:700">দুটি অণুর পারস্পরিক স্পর্শ</text>`;
        s += `<rect x="20" y="168" width="150" height="22" rx="11" fill="#5B9BD5" opacity=".35"/><rect x="20" y="192" width="150" height="22" rx="11" fill="#5B9BD5" opacity=".35"/>`; for (let i = 0; i < 7; i++) s += `<line x1="${30 + i * 21}" y1="190" x2="${30 + i * 21}" y2="192" stroke="#7E57C2" stroke-width="2"/>`;
        s += `<text x="95" y="232" text-anchor="middle" class="tm" style="font-size:10px">লম্বা শিকল: অনেক স্পর্শবিন্দু</text>`;
        s += `<circle cx="300" cy="190" r="22" fill="#5B9BD5" opacity=".35"/><circle cx="345" cy="190" r="22" fill="#5B9BD5" opacity=".35"/><line x1="322" y1="186" x2="323" y2="194" stroke="#7E57C2" stroke-width="2"/><text x="322" y="232" text-anchor="middle" class="tm" style="font-size:10px">গোলক: এক বিন্দুতে স্পর্শ</text>`;
        box.innerHTML = X.svg(400, 240, s, 'সমাণু');
        out.innerHTML = 'তিনটির সংকেত (C₅H₁₂), ভর (72) ও ইলেকট্রন সংখ্যা একই — পার্থক্য কেবল আকৃতিতে। শাখা বাড়লে অণু গোলাকার হয়, পৃষ্ঠতল ক্ষেত্রফল ও পাশের অণুর সাথে স্পর্শ কমে, লন্ডন বল কমে: স্ফুটনাঙ্ক 36 > 28 > 9.5 °C। (চিত্রে শুধু কার্বন কঙ্কাল দেখানো হয়েছে; প্রতিটি C এর সাথে H পরমাণু যুক্ত থাকে।)';
      }
    };
    X.onSeg(el, 'm', draw); draw('hal');
  }
};

/* ======================= ৩.১৮ হাইড্রোজেন বন্ধন: পানি, HF, NH₃ ======================= */
const wmol = (x, y, ang, hl) => { const r = ang * Math.PI / 180; const h = (a, L) => [x + Math.cos(r + a) * L, y + Math.sin(r + a) * L]; const h1 = h(0.91, 26), h2 = h(-0.91, 26); return { o: [x, y], h: [h1, h2], svg: `<line x1="${x}" y1="${y}" x2="${f1(h1[0])}" y2="${f1(h1[1])}" class="s-fg" stroke-width="2.6"/><line x1="${x}" y1="${y}" x2="${f1(h2[0])}" y2="${f1(h2[1])}" class="s-fg" stroke-width="2.6"/><circle cx="${f1(h1[0])}" cy="${f1(h1[1])}" r="7.5" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><circle cx="${f1(h2[0])}" cy="${f1(h2[1])}" r="7.5" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><circle cx="${x}" cy="${y}" r="12" fill="${CPK.O}" ${hl ? 'stroke="var(--fg)" stroke-width="2.2"' : 'stroke="rgba(0,0,0,.3)"'}/>` }; };
const hb = (a, b) => { const L = Math.hypot(b[0] - a[0], b[1] - a[1]), ux = (b[0] - a[0]) / L, uy = (b[1] - a[1]) / L; return `<line x1="${f1(a[0] + ux * 9)}" y1="${f1(a[1] + uy * 9)}" x2="${f1(b[0] - ux * 13)}" y2="${f1(b[1] - uy * 13)}" stroke="#E5484D" stroke-width="2" stroke-dasharray="3 3"/>`; };
V.c3_hbond = {
  t: 'হাইড্রোজেন বন্ধন: দাতা H ও গ্রহীতা নিঃসঙ্গ যুগল', k: ['2d', 'int'],
  cap: 'লাল ড্যাশ রেখা হাইড্রোজেন বন্ধন (X–H···Y)। "পানি" দৃশ্যে মাঝের অণুটি (কালো বর্ডার) দুটি H দিয়ে দুটি প্রতিবেশীকে (দাতা) এবং O এর দুটি নিঃসঙ্গ যুগল দিয়ে আরও দুটির H কে (গ্রহীতা) ধরে রেখেছে — মোট চারটি H-বন্ধন, ত্রিমাত্রিকভাবে চতুস্তলকীয়। HF এ প্রতি অণুতে H মাত্র একটি, তাই জিগজ্যাগ শিকল (গড়ে ২টি বন্ধন); NH₃ এ নিঃসঙ্গ যুগল একটি (গড়ে ২টি)। এজন্য H₂O এর স্ফুটনাঙ্ক সর্বোচ্চ।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['w', 'পানি (H₂O)'], ['f', 'HF শিকল'], ['n', 'NH₃']], 'w')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = m => {
      let s = '';
      if (m === 'w') {
        const c = wmol(200, 104, 90, true), D = 46;
        const nb = [0, 1].map(k => { const dx = c.h[k][0] - c.o[0], dy = c.h[k][1] - c.o[1], L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L; return wmol(c.h[k][0] + ux * D, c.h[k][1] + uy * D, Math.atan2(uy, ux) * 180 / Math.PI); });
        const ac = [-144.75, -35.25].map(phi => { const r = phi * Math.PI / 180, ux = Math.cos(r), uy = Math.sin(r); const ox = c.o[0] + ux * (D + 12 + 26), oy = c.o[1] + uy * (D + 12 + 26); return wmol(ox, oy, (phi + 180) - 52); });
        const n1 = nb[0], n2 = nb[1], a1 = ac[0], a2 = ac[1];
        s += hb(c.h[0], n1.o) + hb(c.h[1], n2.o) + hb(a1.h[0], c.o) + hb(a2.h[0], c.o);
        s += [n1, n2, a1, a2].map(q => q.svg).join('') + c.svg;
        // labels
        s += `<text x="${f1((c.h[0][0] + n1.o[0]) / 2 - 30)}" y="${f1((c.h[0][1] + n1.o[1]) / 2)}" style="font-size:10px;fill:#E5484D">দাতা</text><text x="${f1((a1.h[0][0] + c.o[0]) / 2 - 10)}" y="${f1((a1.h[0][1] + c.o[1]) / 2 - 8)}" style="font-size:10px;fill:#E5484D">গ্রহীতা</text>`;
        s += `<text x="300" y="132" style="font-size:10.5px" class="tm">O–H: 96 pm</text><text x="300" y="148" style="font-size:10.5px;fill:#E5484D">H···O: 177 pm</text>`;
        box.innerHTML = X.svg(400, 214, s, 'পানির H-বন্ধন');
        out.innerHTML = 'প্রতিটি পানির অণু: <b>২টি দাতা H + ২টি গ্রহীতা নিঃসঙ্গ যুগল = ৪টি H-বন্ধন</b>। সমযোজী O–H বন্ধন (96 pm, 463 kJ mol⁻¹) এর তুলনায় H···O হাইড্রোজেন বন্ধন দীর্ঘ (177 pm) ও দুর্বল (~21 kJ mol⁻¹)।';
      } else if (m === 'f') {
        const pts = [[40, 120], [100, 80], [160, 120], [220, 80], [280, 120], [340, 80]];
        pts.forEach(([x, y], i) => { const nx = pts[i + 1]; const hx = nx ? x + (nx[0] - x) * 0.32 : x + 22, hy = nx ? y + (nx[1] - y) * 0.32 : y - 12; s += `<line x1="${x}" y1="${y}" x2="${f1(hx)}" y2="${f1(hy)}" class="s-fg" stroke-width="2.6"/>`; if (nx) s += hb([hx, hy], nx); s += `<circle cx="${f1(hx)}" cy="${f1(hy)}" r="7.5" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/><circle cx="${x}" cy="${y}" r="13" fill="${CPK.F}" stroke="rgba(0,0,0,.3)"/><text x="${x}" y="${y + 4.5}" text-anchor="middle" style="font-size:12px;font-weight:700;fill:${INK}">F</text>`; });
        s += `<text x="200" y="168" text-anchor="middle" class="tm" style="font-size:10.5px">(HF)ₙ জিগজ্যাগ শিকল · F–H···F কোণ প্রায় রৈখিক, শিকলে F কোণ ~১২০°</text>`;
        box.innerHTML = X.svg(400, 180, s, 'HF');
        out.innerHTML = 'F–H···F সবচেয়ে শক্তিশালী একক H-বন্ধন (~29 kJ mol⁻¹), কারণ F সবচেয়ে তড়িৎ ঋণাত্মক। কিন্তু প্রতি HF অণুতে দাতা H মাত্র একটি — তাই গড়ে ২টি বন্ধন, শিকল তৈরি হয়। স্ফুটনাঙ্ক 20 °C (পানির 100 °C এর চেয়ে কম)।';
      } else {
        const N = (x, y) => { let t = ''; [[-20, -22], [-20, 22], [-30, 0]].forEach(([a, b]) => t += `<line x1="${x}" y1="${y}" x2="${x + a}" y2="${y + b}" class="s-fg" stroke-width="2.4"/><circle cx="${x + a}" cy="${y + b}" r="7" fill="${CPK.H}" stroke="rgba(0,0,0,.3)"/>`); t += `<ellipse cx="${x + 24}" cy="${y}" rx="13" ry="8" fill="rgba(255,175,70,.45)" stroke="rgba(214,130,30,.85)"/><circle cx="${x + 22}" cy="${y - 3}" r="1.8" fill="#B9650F"/><circle cx="${x + 22}" cy="${y + 3}" r="1.8" fill="#B9650F"/><circle cx="${x}" cy="${y}" r="12" fill="${CPK.N}"/><text x="${x}" y="${y + 4.5}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:#fff">N</text>`; return t; };
        const xs = [76, 200, 324], yy = 100;
        xs.forEach((x, i) => { if (i) s += hb([x - 30, yy], [xs[i - 1] + 8, yy]); });
        xs.forEach(x => s += N(x, yy));
        s += `<text x="200" y="160" text-anchor="middle" class="tm" style="font-size:10.5px">N–H···:N · প্রতি অণুতে ৩টি H কিন্তু নিঃসঙ্গ যুগল (কমলা) মাত্র ১টি</text>`;
        box.innerHTML = X.svg(400, 170, s, 'NH₃');
        out.innerHTML = 'N–H···N বন্ধন দুর্বলতম (~13 kJ mol⁻¹) — N এর তড়িৎ ঋণাত্মকতা (3.04) O ও F এর চেয়ে কম। তাছাড়া গ্রহীতা নিঃসঙ্গ যুগল একটি, তাই গড়ে ২টি বন্ধন। স্ফুটনাঙ্ক −33 °C — তবুও PH₃ (−88 °C) এর চেয়ে অনেক বেশি।';
      }
    };
    X.onSeg(el, 'm', draw); draw('w');
  }
};

/* ======================= ৩.১৮.১ আন্তঃ বনাম অন্তঃআণবিক H-বন্ধন ======================= */
const ring = (cx, cy, R) => { let p = '', inner = ''; for (let i = 0; i < 6; i++) { const a = Math.PI / 6 + i * Math.PI / 3; p += (i ? 'L' : 'M') + f1(cx + R * Math.cos(a)) + ' ' + f1(cy + R * Math.sin(a)); } return `<path d="${p}Z" fill="none" class="s-fg" stroke-width="2"/><circle cx="${cx}" cy="${cy}" r="${R * 0.58}" fill="none" class="s-fg" stroke-width="1.6"/>`; };
const vtx = (cx, cy, R, i) => { const a = -Math.PI / 2 + i * Math.PI / 3; return [cx + R * Math.cos(a), cy + R * Math.sin(a)]; };
V.c3_hbondTypes = {
  t: 'আন্তঃআণবিক বনাম অন্তঃআণবিক হাইড্রোজেন বন্ধন', k: ['2d', 'int'],
  cap: '"নাইট্রোফেনল" দৃশ্যে বামে o-নাইট্রোফেনল: –OH ও –NO₂ পাশাপাশি থাকায় অণুর ভেতরেই ছয় সদস্যের বলয় তৈরি করে H-বন্ধন (অন্তঃআণবিক) — অণু "নিজের মধ্যে গুটিয়ে" যায়। ডানে p-নাইট্রোফেনল: গ্রুপ দুটি বিপরীত প্রান্তে, তাই এক অণুর –OH অন্য অণুর –NO₂ এর সাথে বন্ধন করে (আন্তঃআণবিক) — অণুগুলো শিকলে যুক্ত। নিচের স্তম্ভে গলনাঙ্ক ও পানিতে দ্রাব্যতা। "অ্যালকোহল বনাম ইথার" দৃশ্যে সমান ভরের তিন যৌগ।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['np', 'নাইট্রোফেনল'], ['ae', 'অ্যালকোহল বনাম ইথার']], 'np')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const at = (x, y, e, r = 9) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="${r}" fill="${CPK[e]}" stroke="rgba(0,0,0,.3)"/><text x="${f1(x)}" y="${f1(y + 3.8)}" text-anchor="middle" style="font-size:${r > 8 ? 10.5 : 9}px;font-weight:700;fill:${e === 'H' ? INK : '#fff'}">${e}</text>`;
    const bond = (a, b, w = 2) => `<line x1="${f1(a[0])}" y1="${f1(a[1])}" x2="${f1(b[0])}" y2="${f1(b[1])}" class="s-fg" stroke-width="${w}"/>`;
    const draw = m => {
      let s = '';
      if (m === 'np') {
        // ortho
        const cx = 92, cy = 110, R = 30; s += ring(cx, cy, R);
        const v0 = vtx(cx, cy, R, 0), v1 = vtx(cx, cy, R, 1);
        const O1 = [v0[0], v0[1] - 26], H1 = [O1[0] + 22, O1[1] - 8], N1 = [v1[0] + 24, v1[1] - 14], Oa = [N1[0] + 2, N1[1] - 26], Ob = [N1[0] + 26, N1[1] + 8];
        s += bond(v0, O1) + bond(O1, H1) + bond(v1, N1) + bond(N1, Oa) + bond(N1, Ob);
        s += hb(H1, Oa) + `<path d="M${f1(v0[0])} ${f1(v0[1])} L${f1(O1[0])} ${f1(O1[1])} L${f1(H1[0])} ${f1(H1[1])} L${f1(Oa[0])} ${f1(Oa[1])} L${f1(N1[0])} ${f1(N1[1])} L${f1(v1[0])} ${f1(v1[1])}Z" fill="#E5484D" opacity=".08"/>`;
        s += at(...O1, 'O') + at(...H1, 'H', 7) + at(...N1, 'N') + at(...Oa, 'O') + at(...Ob, 'O');
        s += `<text x="${cx}" y="${cy + 54}" text-anchor="middle" style="font-size:12px;font-weight:700">o-নাইট্রোফেনল</text><text x="${cx}" y="${cy + 69}" text-anchor="middle" style="font-size:10px;fill:#E5484D">অন্তঃআণবিক (৬-সদস্যের বলয়)</text>`;
        // para x2
        const P = (cx, cy) => { const R = 26; let t = ring(cx, cy, R); const t0 = vtx(cx, cy, R, 0), t3 = vtx(cx, cy, R, 3); const O = [t0[0], t0[1] - 22], H = [O[0] + 16, O[1] - 10], N = [t3[0], t3[1] + 22], Oa = [N[0] - 18, N[1] + 12], Ob = [N[0] + 18, N[1] + 12]; t += bond(t0, O) + bond(O, H) + bond(t3, N) + bond(N, Oa) + bond(N, Ob) + at(...O, 'O') + at(...H, 'H', 7) + at(...N, 'N') + at(...Oa, 'O') + at(...Ob, 'O'); return { t, H, Ob }; };
        const p1 = P(250, 62), p2 = P(330, 168);
        s += p1.t + p2.t + hb(p2.H, p1.Ob) + `<text x="300" y="260" text-anchor="middle" style="font-size:12px;font-weight:700">p-নাইট্রোফেনল</text><text x="300" y="275" text-anchor="middle" style="font-size:10px;fill:#E5484D">আন্তঃআণবিক (অণু-অণু শিকল)</text>`;
        // bars
        s += `<line x1="10" y1="290" x2="390" y2="290" class="s-ln" stroke-dasharray="2 3"/>`;
        const bars = [['গলনাঙ্ক (°C)', 45, 114, 130], ['পানিতে দ্রাব্যতা (g/L)', 2.1, 16, 18]];
        bars.forEach(([lab, a, b, mx], i) => { const y = 312 + i * 46; s += `<text x="10" y="${y}" style="font-size:11px;font-weight:700">${lab}</text><text x="40" y="${y + 17}" text-anchor="end" style="font-size:10.5px">o</text><rect x="46" y="${y + 7}" width="${f1(a / mx * 290)}" height="12" rx="3" fill="#E5484D" opacity=".75"/><text x="${f1(50 + a / mx * 290)}" y="${y + 17}" class="mono" style="font-size:10px">${a}</text><text x="40" y="${y + 33}" text-anchor="end" style="font-size:10.5px">p</text><rect x="46" y="${y + 23}" width="${f1(b / mx * 290)}" height="12" rx="3" fill="#5B9BD5" opacity=".85"/><text x="${f1(50 + b / mx * 290)}" y="${y + 33}" class="mono" style="font-size:10px">${b}</text>`; });
        box.innerHTML = X.svg(400, 404, s, 'নাইট্রোফেনল');
        out.innerHTML = '<b>o-নাইট্রোফেনল</b>: –OH এর H নিজের –NO₂ এর সাথে ব্যস্ত → অন্য অণু বা পানির সাথে বন্ধন কম → গলনাঙ্ক কম (45 °C), দ্রাব্যতা কম, <b>বাষ্প-উদ্বায়ী</b>।<br><b>p-নাইট্রোফেনল</b>: অণুগুলো আন্তঃআণবিক H-বন্ধনে সংযুক্ত → গলনাঙ্ক বেশি (114 °C), পানির সাথেও H-বন্ধন → দ্রাব্যতা বেশি। বাষ্প পাতনে দুটি পৃথক করা যায়।';
      } else {
        const items = [['ইথানল', 'CH₃CH₂–OH', 78, true, 'আন্তঃআণবিক H-বন্ধন (O–H···O)'], ['ডাইমিথাইল ইথার', 'CH₃–O–CH₃', -24, false, 'O–H নেই → নিজেদের মধ্যে H-বন্ধন নেই; শুধু ডাইপোল-ডাইপোল'], ['প্রোপেন', 'CH₃CH₂CH₃', -42, false, 'অপোলার → শুধু লন্ডন বল']];
        items.forEach(([n, f, bp, h, why], i) => {
          const y = 30 + i * 70;
          s += `<text x="12" y="${y}" style="font-size:12.5px;font-weight:700">${n}</text><text x="12" y="${y + 17}" class="mono" style="font-size:11.5px">${f}</text><text x="12" y="${y + 33}" class="tm" style="font-size:9.8px">${why}</text>`;
          const z = 300, sc = 0.7, w = bp * sc; s += `<rect x="${f1(Math.min(z, z + w))}" y="${y - 10}" width="${f1(Math.abs(w))}" height="20" rx="3" fill="${h ? '#E5484D' : bp > -30 ? '#E9A53B' : '#6FA8DC'}"/><text x="${f1(bp >= 0 ? z + w + 4 : z + w - 4)}" y="${y + 4}" text-anchor="${bp >= 0 ? 'start' : 'end'}" class="mono" style="font-size:11px;font-weight:700">${bp} °C</text>`;
        });
        s += `<line x1="300" y1="14" x2="300" y2="196" class="s-fg"/><text x="300" y="210" text-anchor="middle" class="tm" style="font-size:10px">০ °C · স্ফুটনাঙ্ক (সবার আণবিক ভর ৪৪–৪৬)</text>`;
        box.innerHTML = X.svg(400, 218, s, 'অ্যালকোহল ইথার');
        out.innerHTML = 'আণবিক ভর প্রায় সমান হলেও স্ফুটনাঙ্ক ১২০ °C পর্যন্ত আলাদা — আন্তঃআণবিক বলের ধরনই নির্ণায়ক: H-বন্ধন > ডাইপোল-ডাইপোল > লন্ডন। ইথার নিজে H-বন্ধন দাতা নয়, তবে এর O পানির H এর গ্রহীতা হতে পারে — তাই ইথার পানিতে কিছুটা দ্রবণীয়, প্রোপেন নয়।';
      }
    };
    X.onSeg(el, 'm', draw); draw('np');
  }
};

/* ======================= ৩.১৯ হাইড্রাইডের স্ফুটনাঙ্ক লেখচিত্র ======================= */
const HY = [
  ['১৪', ['CH₄', 'SiH₄', 'GeH₄', 'SnH₄'], [-162, -112, -88, -52], '#8AA0B3'],
  ['১৫', ['NH₃', 'PH₃', 'AsH₃', 'SbH₃'], [-33, -88, -62, -17], '#3B5BDB'],
  ['১৬', ['H₂O', 'H₂S', 'H₂Se', 'H₂Te'], [100, -60, -41, -2], '#E5383B'],
  ['১৭', ['HF', 'HCl', 'HBr', 'HI'], [20, -85, -67, -35], '#2BB24C']
];
V.c3_hydrides = {
  t: 'গ্রুপ ১৪–১৭ এর হাইড্রাইডের স্ফুটনাঙ্ক: NH₃, H₂O ও HF এর অস্বাভাবিকতা', k: ['2d', 'int'],
  cap: 'চারটি গ্রুপের হাইড্রাইডের স্ফুটনাঙ্ক পর্যায় ২ থেকে ৫ পর্যন্ত। গ্রুপ ১৪ (CH₄ …) নিয়মিত বাড়ে — শুধু লন্ডন বল। বাকি তিন গ্রুপে পর্যায় ৩ থেকে ৫ নিয়মিত বাড়ে, কিন্তু পর্যায় ২ এর NH₃, H₂O ও HF হঠাৎ অনেক উঁচুতে — হাইড্রোজেন বন্ধন। ড্যাশ রেখা দেখায় H-বন্ধন না থাকলে পানির স্ফুটনাঙ্ক প্রবণতা অনুযায়ী কোথায় হতো (প্রায় −80 °C)। নিচের বোতামে কোনো গ্রুপ লুকাও/দেখাও; বিন্দুতে চাপ দিলে মান দেখাবে।',
  html: () => `<div class="ctl" style="margin:0 0 6px" data-tg>${HY.map(([g, , , c], i) => `<button class="btn sm" data-g="${i}" data-on="1" style="border:2px solid ${c};background:${c};color:#fff">গ্রুপ ${g}</button>`).join('')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); const on = [1, 1, 1, 1]; let sel = [2, 0];
    const draw = () => {
      const x0 = 50, x1 = 384, y0 = 230, y1 = 22, lo = -180, hi = 120, ty = v => y0 - (v - lo) / (hi - lo) * (y0 - y1), tx = p => x0 + 20 + (p - 2) / 3 * (x1 - x0 - 40);
      let s = '';
      [-150, -100, -50, 0, 50, 100].forEach(v => s += `<line x1="${x0}" y1="${f1(ty(v))}" x2="${x1}" y2="${f1(ty(v))}" class="s-ln" opacity="${v === 0 ? 0.7 : 0.2}"/><text x="${x0 - 4}" y="${f1(ty(v) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:10px">${v}</text>`);
      [2, 3, 4, 5].forEach(p => s += `<text x="${f1(tx(p))}" y="${y0 + 14}" text-anchor="middle" class="tm" style="font-size:10.5px">পর্যায় ${bn(p)}</text>`);
      s += `<text x="${x0}" y="${y1 - 8}" class="tm" style="font-size:10.5px">স্ফুটনাঙ্ক (°C)</text>`;
      if (on[2]) { // expected water
        const a = HY[2][2]; const slope = (a[2] - a[1]); const exp = a[1] - slope * 1.0 - 20; s += `<path d="M${f1(tx(3))} ${f1(ty(a[1]))} L${f1(tx(2))} ${f1(ty(-80))}" fill="none" stroke="#E5383B" stroke-dasharray="4 4" opacity=".7"/><circle cx="${f1(tx(2))}" cy="${f1(ty(-80))}" r="4" fill="none" stroke="#E5383B" stroke-dasharray="2 2"/><text x="${f1(tx(2) + 8)}" y="${f1(ty(-80) + 14)}" style="font-size:9.5px;fill:#E5383B">প্রত্যাশিত ≈ −80</text>`;
        s += `<path d="M${f1(tx(2) - 8)} ${f1(ty(-72))} L${f1(tx(2) - 8)} ${f1(ty(92))}" stroke="#E5383B" stroke-width="1.4" marker-end="url(#c3hya)"/><text x="${f1(tx(2) - 12)}" y="${f1(ty(10))}" text-anchor="end" style="font-size:9.5px;fill:#E5383B;font-weight:600">H-বন্ধন</text>`; }
      HY.forEach(([g, n, v, c], i) => { if (!on[i]) return; let d = ''; v.forEach((b, k) => d += (k ? 'L' : 'M') + f1(tx(k + 2)) + ' ' + f1(ty(b))); s += `<path d="${d}" fill="none" stroke="${c}" stroke-width="2.4"/>`; v.forEach((b, k) => { const isS = sel[0] === i && sel[1] === k; s += `<g data-p="${i},${k}" style="cursor:pointer"><circle cx="${f1(tx(k + 2))}" cy="${f1(ty(b))}" r="${isS ? 7 : 5}" fill="${c}" stroke="var(--surface)" stroke-width="1.5"/><circle cx="${f1(tx(k + 2))}" cy="${f1(ty(b))}" r="12" fill="transparent"/></g>`; }); if (i > 0) s += `<text x="${f1(tx(2) + 9)}" y="${f1(ty(v[0]) - 6)}" style="font-size:10.5px;font-weight:700;fill:${c}">${n[0]}</text>`; });
      HY.forEach(([g, n, v, c], i) => { const lx = 12 + i * 97; s += `<line x1="${lx}" y1="${y0 + 34}" x2="${lx + 18}" y2="${y0 + 34}" stroke="${c}" stroke-width="3"/><text x="${lx + 22}" y="${y0 + 38}" style="font-size:9.5px">${n[0]}–${n[3]}</text>`; });
      box.innerHTML = X.svg(400, y0 + 46, `<defs>${X.arrowC('c3hya', '#E5383B')}</defs>` + s, 'হাইড্রাইড');
      const [g, n, v] = HY[sel[0]]; out.innerHTML = `<b>${n[sel[1]]}</b> (গ্রুপ ${g}, পর্যায় ${bn(sel[1] + 2)}): স্ফুটনাঙ্ক <b>${v[sel[1]]} °C</b>${sel[1] === 0 && sel[0] > 0 ? ' — হাইড্রোজেন বন্ধনের জন্য অস্বাভাবিক উঁচু' : sel[0] === 0 ? ' — অপোলার, শুধু লন্ডন বল' : ' — H-বন্ধন নেই; লন্ডন বলের জন্য নিচের দিকে বাড়ে'}<br><span class="small">অস্বাভাবিকতার ক্রম: H₂O > HF > NH₃ (প্রতি অণুতে H-বন্ধনের সংখ্যা ও শক্তি)।</span>`;
    };
    el.querySelectorAll('[data-g]').forEach(b => b.onclick = () => { const i = +b.dataset.g; on[i] = on[i] ? 0 : 1; b.style.background = on[i] ? HY[i][3] : 'transparent'; b.style.color = on[i] ? '#fff' : 'var(--fg)'; draw(); });
    box.addEventListener('click', e => { const g = e.target.closest('[data-p]'); if (g) { sel = g.dataset.p.split(',').map(Number); draw(); } });
    draw();
  }
};

/* ======================= ৩.২০ বরফের ঘনত্ব ও পানির অস্বাভাবিক প্রসারণ ======================= */
const WD = [[0, 0.99984], [1, 0.99990], [2, 0.99994], [3, 0.99996], [4, 0.99997], [5, 0.99996], [6, 0.99994], [8, 0.99985], [10, 0.99970], [12, 0.99950], [15, 0.99910], [20, 0.99821], [25, 0.99705], [30, 0.99565]];
V.c3_iceDensity = {
  t: 'বরফ কেন ভাসে: পানির ঘনত্ব, বরফের খোলা জালক ও শীতের হ্রদ', k: ['2d', 'int'],
  cap: '"ঘনত্ব লেখ" দৃশ্যে পানির ঘনত্ব (প্রকৃত মান) 4 °C এ সর্বোচ্চ — এর নিচে ঠান্ডা করলে পানি আবার প্রসারিত হয়। বরফের ঘনত্ব 0.917 g cm⁻³ — লেখের অনেক নিচে (তীর)। "গঠন" দৃশ্যে বরফের ষড়ভুজাকার জালক: প্রতিটি O চারটি H-বন্ধনে আবদ্ধ, মাঝে বড় ফাঁকা; তরলে কিছু H-বন্ধন ভেঙে অণুগুলো ফাঁকা জায়গায় ঢুকে পড়ে — ঘনত্ব বাড়ে। "শীতের হ্রদ" দৃশ্যে তাপমাত্রার স্তর: উপরে বরফ, তলায় 4 °C এর ভারী পানিতে মাছ বেঁচে থাকে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['c', 'ঘনত্ব লেখ'], ['s', 'গঠন: বরফ বনাম পানি'], ['l', 'শীতের হ্রদ']], 'c')}</div><div data-svg style="touch-action:pan-y"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let T = 4;
    const dens = t => { for (let i = 1; i < WD.length; i++) if (t <= WD[i][0]) { const a = WD[i - 1], b = WD[i], k = (t - a[0]) / (b[0] - a[0]); return a[1] + (b[1] - a[1]) * k; } return WD[WD.length - 1][1]; };
    const curve = () => {
      const x0 = 60, x1 = 390, y0 = 196, y1 = 22, lo = 0.9955, hi = 1.0002, tx = t => x0 + t / 30 * (x1 - x0), ty = d => y0 - (d - lo) / (hi - lo) * (y0 - y1);
      let s = '';
      [0.996, 0.997, 0.998, 0.999, 1.000].forEach(v => s += `<line x1="${x0}" y1="${f1(ty(v))}" x2="${x1}" y2="${f1(ty(v))}" class="s-ln" opacity=".2"/><text x="${x0 - 4}" y="${f1(ty(v) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:9.5px">${v.toFixed(3)}</text>`);
      [0, 4, 10, 20, 30].forEach(t => s += `<text x="${f1(tx(t))}" y="${y0 + 14}" text-anchor="middle" class="tm mono" style="font-size:10px">${t}</text>`);
      s += `<line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y0}" class="s-ln"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y1}" class="s-ln"/><text x="${x0}" y="${y1 - 8}" class="tm" style="font-size:10.5px">ঘনত্ব (g cm⁻³)</text><text x="${x1}" y="${y0 + 28}" text-anchor="end" class="tm" style="font-size:10.5px">তাপমাত্রা (°C)</text>`;
      let d = ''; for (let t = 0; t <= 30.01; t += 0.5) d += (t ? 'L' : 'M') + f1(tx(t)) + ' ' + f1(ty(dens(t)));
      s += `<path d="${d}" fill="none" stroke="#2F86D6" stroke-width="2.4"/>`;
      s += `<line x1="${f1(tx(4))}" y1="${f1(ty(0.99997))}" x2="${f1(tx(4))}" y2="${y0}" class="s-mu" stroke-dasharray="3 3"/><text x="${f1(tx(4) + 4)}" y="${f1(ty(0.99997) - 6)}" style="font-size:10px;font-weight:700">সর্বোচ্চ: 4 °C, 0.99997</text>`;
      s += `<path d="M${f1(tx(0) + 8)} ${y0 - 14} L${f1(tx(0) + 8)} ${y0 - 2}" stroke="#7E57C2" stroke-width="1.6" marker-end="url(#c3ica)"/><text x="${f1(tx(0) + 14)}" y="${y0 - 6}" style="font-size:9.5px;fill:#7E57C2">বরফ (0 °C): 0.917 — লেখের অনেক নিচে</text>`;
      const d0 = dens(T); s += `<circle cx="${f1(tx(T))}" cy="${f1(ty(d0))}" r="6" fill="#E5484D" stroke="var(--surface)" stroke-width="1.5"/>`;
      s += `<rect data-hit x="${x0}" y="${y1}" width="${x1 - x0}" height="${y0 - y1}" fill="transparent" style="cursor:crosshair"/>`;
      box.innerHTML = X.svg(400, 230, `<defs>${X.arrowC('c3ica', '#7E57C2')}</defs>` + s, 'ঘনত্ব');
      out.innerHTML = `${T.toFixed(1)} °C এ পানির ঘনত্ব = <b>${d0.toFixed(5)} g cm⁻³</b>${T < 4 ? ' — 4 °C এর চেয়ে কম (খোলা H-বন্ধন গুচ্ছ এখনও আছে)' : T > 4.05 ? ' — তাপীয় প্রসারণে কমছে' : ' — সর্বোচ্চ ঘনত্ব'}<br><span class="small muted">লেখের উপর আঙুল টেনে তাপমাত্রা বদলাও।</span>`;
      const hit = box.querySelector('[data-hit]'), svg = box.querySelector('svg');
      const pick = ev => { const r = svg.getBoundingClientRect(); const x = (ev.clientX - r.left) / r.width * 400; T = Math.max(0, Math.min(30, (x - x0) / (x1 - x0) * 30)); curve(); };
      hit.addEventListener('pointerdown', ev => { pick(ev); });
    };
    const struct = () => {
      let s = '';
      // ice: honeycomb of O with H-bonds
      const a = 26, ox = 22, oy = 38; const pts = [];
      for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) { const x = ox + c * a * 1.732 + (r % 2) * a * 0.866, y = oy + r * a * 1.5; pts.push([x, y], [x, y + a]); }
      const P = pts.filter(([x, y]) => x < 190 && y < 190);
      // bonds between neighbours at distance a
      P.forEach((p, i) => P.forEach((q, j) => { if (j <= i) return; const d = Math.hypot(p[0] - q[0], p[1] - q[1]); if (Math.abs(d - a) < 1.5) { const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2; s += `<line x1="${f1(p[0])}" y1="${f1(p[1])}" x2="${f1(mx)}" y2="${f1(my)}" class="s-fg" stroke-width="1.8"/><line x1="${f1(mx)}" y1="${f1(my)}" x2="${f1(q[0])}" y2="${f1(q[1])}" stroke="#E5484D" stroke-width="1.4" stroke-dasharray="2.5 2"/><circle cx="${f1(p[0] + (q[0] - p[0]) * 0.36)}" cy="${f1(p[1] + (q[1] - p[1]) * 0.36)}" r="3.2" fill="${CPK.H}" stroke="rgba(0,0,0,.35)" stroke-width=".6"/>`; } }));
      P.forEach(([x, y]) => s += `<circle cx="${f1(x)}" cy="${f1(y)}" r="6" fill="${CPK.O}"/>`);
      s += `<text x="100" y="212" text-anchor="middle" style="font-size:12px;font-weight:700">বরফ: খোলা ষড়ভুজাকার জালক</text><text x="100" y="227" text-anchor="middle" class="tm" style="font-size:10px">প্রতি O এর ৪টি H-বন্ধন, বড় ফাঁকা স্থান</text>`;
      // liquid: denser random
      const rnd = X.rng(7); let n = 0; const L = [];
      while (L.length < 46 && n < 8000) { n++; const x = 228 + rnd() * 152, y = 32 + rnd() * 156; if (L.every(([u, v]) => Math.hypot(u - x, v - y) > 17.5)) L.push([x, y]); }
      L.forEach(([x, y], i) => { const r = rnd() * 6.283; s += `<line x1="${f1(x)}" y1="${f1(y)}" x2="${f1(x + Math.cos(r) * 9)}" y2="${f1(y + Math.sin(r) * 9)}" class="s-fg" stroke-width="1.6"/><line x1="${f1(x)}" y1="${f1(y)}" x2="${f1(x + Math.cos(r + 1.82) * 9)}" y2="${f1(y + Math.sin(r + 1.82) * 9)}" class="s-fg" stroke-width="1.6"/><circle cx="${f1(x + Math.cos(r) * 9)}" cy="${f1(y + Math.sin(r) * 9)}" r="3.2" fill="${CPK.H}" stroke="rgba(0,0,0,.35)" stroke-width=".6"/><circle cx="${f1(x + Math.cos(r + 1.82) * 9)}" cy="${f1(y + Math.sin(r + 1.82) * 9)}" r="3.2" fill="${CPK.H}" stroke="rgba(0,0,0,.35)" stroke-width=".6"/><circle cx="${f1(x)}" cy="${f1(y)}" r="6" fill="${CPK.O}"/>`; });
      s += `<rect x="218" y="22" width="172" height="176" rx="8" fill="none" class="s-mu" stroke-dasharray="3 3"/><rect x="10" y="22" width="190" height="176" rx="8" fill="none" class="s-mu" stroke-dasharray="3 3"/>`;
      s += `<text x="304" y="212" text-anchor="middle" style="font-size:12px;font-weight:700">তরল পানি: ঘন, এলোমেলো</text><text x="304" y="227" text-anchor="middle" class="tm" style="font-size:10px">কিছু H-বন্ধন ভাঙা, অণু ফাঁকে ঢুকে পড়ে</text>`;
      s += `<text x="100" y="14" text-anchor="middle" class="mono" style="font-size:10.5px;font-weight:600">0.917 g cm⁻³</text><text x="304" y="14" text-anchor="middle" class="mono" style="font-size:10.5px;font-weight:600">1.000 g cm⁻³</text>`;
      box.innerHTML = X.svg(400, 234, s, 'বরফের গঠন');
      out.innerHTML = 'একই আয়তনের বাক্সে বরফে কম অণু, তরলে বেশি অণু — তাই তরল পানি বরফের চেয়ে প্রায় ৯% ঘন এবং বরফ পানিতে ভাসে (বরফখণ্ডের প্রায় ৯০% পানির নিচে থাকে)। চিত্রটি দ্বিমাত্রিক সরলীকরণ; প্রকৃত বরফে প্রতিটি O চতুস্তলকীয়ভাবে চারটি O দ্বারা বেষ্টিত।';
    };
    const lake = () => {
      let s = `<defs><linearGradient id="c3lake" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#BFE3F7"/><stop offset="1" stop-color="#2F6FB5"/></linearGradient></defs>`;
      s += `<rect x="0" y="0" width="400" height="40" fill="#E7F1F8" opacity=".6"/><text x="12" y="24" style="font-size:11px">বাতাস: −15 °C</text>`;
      s += `<path d="M10 52 L390 52 L370 230 Q200 248 30 230Z" fill="url(#c3lake)" opacity=".85"/>`;
      s += `<rect x="10" y="40" width="380" height="16" rx="3" fill="#F4FBFF" stroke="#9CC7E4"/><text x="200" y="52" text-anchor="middle" style="font-size:10.5px;font-weight:700;fill:${INK}">বরফ (0 °C) — ভাসে, তাপ অপরিবাহী আবরণ</text>`;
      [[78, '1 °C'], [118, '2 °C'], [160, '3 °C'], [204, '4 °C (সবচেয়ে ভারী)']].forEach(([y, t], i) => s += `<line x1="${30 + i * 3}" y1="${y}" x2="${370 - i * 3}" y2="${y}" stroke="#fff" stroke-opacity=".5" stroke-dasharray="4 5"/><text x="${360 - i * 4}" y="${y - 4}" text-anchor="end" style="font-size:10.5px;font-weight:600;fill:${i > 1 ? '#fff' : INK}">${t}</text>`);
      const fish = (x, y, sc, flip) => `<g transform="translate(${x} ${y}) scale(${flip ? -sc : sc} ${sc})"><path d="M-16 0 Q-4 -10 12 0 Q-4 10 -16 0Z" fill="#F2A541" stroke="#B5701A"/><path d="M12 0 L22 -7 L22 7Z" fill="#F2A541" stroke="#B5701A"/><circle cx="-9" cy="-2" r="1.6" fill="${INK}"/></g>`;
      s += fish(90, 216, 1.1, false) + fish(200, 224, 0.9, true) + fish(170, 190, 0.8, false);
      s += `<text x="40" y="240" style="font-size:10px" class="tm">তলদেশ</text>`;
      box.innerHTML = X.svg(400, 250, s, 'শীতের হ্রদ');
      out.innerHTML = 'শরতে উপরের পানি ঠান্ডা হয়ে 4 °C এ পৌঁছালে সবচেয়ে ভারী হয়ে নিচে নামে। আরও ঠান্ডা (4 °C এর নিচে) পানি হালকা — উপরে থাকে এবং 0 °C এ জমে বরফ হয়। বরফ ভাসে ও নিচের পানিকে বাইরের ঠান্ডা থেকে আড়াল করে। তলদেশে প্রায় 4 °C এর তরল পানিতে মাছ ও জলজ উদ্ভিদ বেঁচে থাকে।';
    };
    X.onSeg(el, 'm', k => k === 'c' ? curve() : k === 's' ? struct() : lake()); curve();
  }
};
})();
