/* Chapter 3 visuals part 2 — periodic properties, Zeff, IE/EA/EN, oxides (3.3–3.6) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C3 = window.C3V;
const bn = X.bn, f1 = v => (+v).toFixed(1);
const INK = '#1b1b1f';
const SYM = Z => X.PT[Z - 1].sym;

/* ======================= প্রবণতা লেখচিত্র: ধর্ম বনাম Z ======================= */
const TP = {
  rad: { a: X.RAD, n: 'পারমাণবিক ব্যাসার্ধ', u: 'pm', yt: [0, 50, 100, 150, 200, 250], max: 280, hi: [3, 11, 19, 37, 55], hn: 'ক্ষার ধাতু — প্রতি পর্যায়ে সর্ববৃহৎ' },
  ie: { a: X.IE1, n: 'প্রথম আয়নীকরণ শক্তি', u: 'kJ mol⁻¹', yt: [0, 500, 1000, 1500, 2000, 2500], max: 2750, hi: [2, 10, 18, 36, 54], hn: 'নিষ্ক্রিয় গ্যাস — প্রতি পর্যায়ে সর্বোচ্চ' },
  en: { a: X.EN, n: 'তড়িৎ ঋণাত্মকতা (পলিং)', u: '', yt: [0, 1, 2, 3, 4], max: 4.2, hi: [9, 17, 35, 53], hn: 'হ্যালোজেন — প্রতি পর্যায়ে সর্বোচ্চ' },
  ea: { a: X.EA, n: 'ইলেকট্রন আসক্তি (মুক্ত শক্তি)', u: 'kJ mol⁻¹', yt: [0, 100, 200, 300], max: 370, hi: [9, 17, 35, 53], hn: 'হ্যালোজেন — প্রতি পর্যায়ে সর্বোচ্চ' }
};
V.c3_trendPlot = {
  t: 'পর্যায়বৃত্ততার লেখচিত্র: পারমাণবিক সংখ্যা বনাম ধর্ম (Z = ১–৫৬)', k: ['2d', 'int'],
  cap: 'ধর্ম বেছে নাও। ধূসর ড্যাশ রেখা পর্যায়ের সীমা; প্রতিটি পর্যায়ে একই ধাঁচের ঢেউ বারবার ফিরে আসে — এটিই "পর্যায়বৃত্ততা"। লেখচিত্রের উপর আঙুল টানলে প্রতিটি মৌলের মান দেখাবে। বড় বিন্দুগুলো প্রতি পর্যায়ের চরম মানের মৌল। ব্যাসার্ধ: ধাতুর জন্য ধাতব ও অধাতুর জন্য সমযোজী ব্যাসার্ধ; নিষ্ক্রিয় গ্যাসের তুলনীয় মান নেই। EN এর মান নিষ্ক্রিয় গ্যাসের জন্য সংজ্ঞায়িত নয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('p', [['rad', 'ব্যাসার্ধ'], ['ie', 'আয়নীকরণ শক্তি'], ['en', 'তড়িৎ ঋণাত্মকতা'], ['ea', 'ইলেকট্রন আসক্তি']], 'ie')}</div><div data-svg style="touch-action:pan-y"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let p = 'ie', cur = 11;
    const x0 = 44, x1 = 394, y0 = 200, y1 = 24, tx = Z => x0 + (Z - 0.5) / 56 * (x1 - x0);
    const draw = () => {
      const D = TP[p]; const A = C3.axis({ x0, x1, y0, y1, ymin: 0, ymax: D.max, yt: D.yt, ylab: D.n + (D.u ? ' (' + D.u + ')' : '') });
      let s = A.s;
      [2.5, 10.5, 18.5, 36.5, 54.5].forEach(z => s += `<line x1="${f1(tx(z))}" y1="${y0}" x2="${f1(tx(z))}" y2="${y1}" class="s-mu" stroke-dasharray="3 3" opacity=".5"/>`);
      [[1.5, '১'], [6.5, '২'], [14.5, '৩'], [27.5, '৪'], [45.5, '৫'], [55.5, '৬']].forEach(([z, n]) => s += `<text x="${f1(tx(z))}" y="${y0 + 14}" text-anchor="middle" class="tm" style="font-size:10px">${n}</text>`);
      s += `<text x="${x1}" y="${y0 + 28}" text-anchor="end" class="tm" style="font-size:10.5px">পর্যায় → (পারমাণবিক সংখ্যা ১–৫৬)</text>`;
      let d = '', pen = false;
      for (let Z = 1; Z <= 56; Z++) { const v = D.a[Z - 1]; if (v == null) { pen = false; continue; } d += (pen ? 'L' : 'M') + f1(tx(Z)) + ' ' + f1(A.ty(v)); pen = true; }
      s += `<path d="${d}" fill="none" class="s-acc" stroke-width="2" stroke-linejoin="round"/>`;
      for (let Z = 1; Z <= 56; Z++) { const v = D.a[Z - 1]; if (v == null) continue; const h = D.hi.includes(Z); s += `<circle cx="${f1(tx(Z))}" cy="${f1(A.ty(v))}" r="${h ? 4 : 2}" class="${h ? 'f-a2' : 'f-acc'}"/>`; if (h) s += `<text x="${f1(tx(Z))}" y="${f1(A.ty(v) - 7)}" text-anchor="middle" style="font-size:10px;font-weight:600">${SYM(Z)}</text>`; }
      s += `<g pointer-events="none" data-mk></g><rect data-hit x="${x0}" y="${y1}" width="${x1 - x0}" height="${y0 - y1}" fill="transparent" style="cursor:crosshair"/>`;
      box.innerHTML = X.svg(400, 236, s, D.n);
      const mk = box.querySelector('[data-mk]');
      const mark = () => {
        const v = D.a[cur - 1], e = X.PT[cur - 1];
        mk.innerHTML = `<line x1="${f1(tx(cur))}" y1="${y0}" x2="${f1(tx(cur))}" y2="${y1}" class="s-fg" opacity=".35"/>${v != null ? `<circle cx="${f1(tx(cur))}" cy="${f1(A.ty(v))}" r="5.5" fill="none" class="s-fg" stroke-width="2"/>` : ''}`;
        out.innerHTML = `<b>${e.sym}</b> (${e.name}, Z = ${bn(cur)}, পর্যায় ${bn(e.per)}, ${C3.grpName(e)}): ${D.n} = <b>${v == null ? 'সংজ্ঞায়িত/তুলনীয় নয়' : v + (D.u ? ' ' + D.u : '')}</b><br><span class="small muted">● বড় বিন্দু: ${D.hn}</span>`;
      };
      const hit = box.querySelector('[data-hit]'), svg = box.querySelector('svg');
      const pick = ev => { const r = svg.getBoundingClientRect(); const x = (ev.clientX - r.left) / r.width * 400; const Z = Math.max(1, Math.min(56, Math.round((x - x0) / (x1 - x0) * 56 + 0.5))); if (Z !== cur) { cur = Z; mark(); } };
      hit.addEventListener('pointerdown', ev => { pick(ev); try { hit.setPointerCapture(ev.pointerId); } catch (_) { } });
      hit.addEventListener('pointermove', ev => { if (ev.buttons || ev.pointerType === 'mouse') pick(ev); });
      mark();
    };
    X.onSeg(el, 'p', k => { p = k; draw(); }); draw();
  }
};

/* ======================= পারমাণবিক ও আয়নিক ব্যাসার্ধ তুলনা ======================= */
const RC = {
  cat: { k: 0.2, rows: [[['Na', 186, 'n'], ['Na⁺', 102, 'c']], [['Mg', 160, 'n'], ['Mg²⁺', 72, 'c']], [['Al', 143, 'n'], ['Al³⁺', 53.5, 'c']]], note: 'ধাতব পরমাণু ইলেকট্রন ত্যাগ করে ক্যাটায়ন হলে (১) বাইরের পুরো শক্তিস্তর হারিয়ে যায় এবং (২) একই নিউক্লিয়ার চার্জ কম ইলেকট্রনকে টানে — প্রতি ইলেকট্রনে কার্যকর আকর্ষণ বাড়ে। তাই ক্যাটায়ন সবসময় মূল পরমাণুর চেয়ে ছোট; চার্জ যত বেশি, তত ছোট।' },
  an: { k: 0.2, rows: [[['F', 72, 'n'], ['F⁻', 133, 'a']], [['O', 73, 'n'], ['O²⁻', 140, 'a']], [['Cl', 99, 'n'], ['Cl⁻', 181, 'a']]], note: 'অধাতব পরমাণু ইলেকট্রন গ্রহণ করে অ্যানায়ন হলে নিউক্লিয়ার চার্জ একই থাকে কিন্তু ইলেকট্রন বাড়ে — ইলেকট্রন-ইলেকট্রন বিকর্ষণ বাড়ে ও প্রতি ইলেকট্রনে আকর্ষণ কমে; ইলেকট্রন মেঘ প্রসারিত হয়। তাই অ্যানায়ন মূল পরমাণুর চেয়ে বড়।' },
  iso: { k: 0.24, rows: [[['N³⁻', 146, 'a'], ['O²⁻', 140, 'a'], ['F⁻', 133, 'a']], [['Na⁺', 102, 'c'], ['Mg²⁺', 72, 'c'], ['Al³⁺', 53.5, 'c']]], note: 'সব কয়টি আয়নে ১০টি করে ইলেকট্রন (Ne এর বিন্যাস 1s² 2s² 2p⁶) — সমইলেকট্রনীয়। ইলেকট্রন সংখ্যা সমান হলে যার নিউক্লিয়ার চার্জ (Z = ৭ → ১৩) যত বেশি, সে ইলেকট্রন মেঘকে তত জোরে টানে — আকার তত ছোট: N³⁻ > O²⁻ > F⁻ > Na⁺ > Mg²⁺ > Al³⁺।' },
  grp: { k: 0.145, rows: [[['Li', 152, 'n'], ['Na', 186, 'n'], ['K', 227, 'n'], ['Rb', 248, 'n'], ['Cs', 265, 'n']]], note: 'গ্রুপে নিচে প্রতি পর্যায়ে একটি করে নতুন শক্তিস্তর যুক্ত হয় এবং ভেতরের স্তরগুলো বাইরের ইলেকট্রনকে আবরণ করে — নিউক্লিয়ার চার্জ বাড়লেও আকার বাড়ে।' }
};
const RCOL = { n: '#9DB6CC', c: '#E8775C', a: '#5BAED9' };
V.c3_radiusCmp = {
  t: 'পরমাণু ও আয়নের আকার: স্কেল অনুযায়ী তুলনা', k: ['2d', 'int'],
  cap: 'বৃত্তগুলো প্রকৃত ব্যাসার্ধের অনুপাতে আঁকা (নিচে ১০০ pm স্কেল দেখো)। ধাতব পরমাণুর জন্য ধাতব ব্যাসার্ধ, অধাতুর জন্য সমযোজী ব্যাসার্ধ এবং আয়নের জন্য শ্যানন আয়নিক ব্যাসার্ধ (সন্নিবেশ সংখ্যা ৬; N³⁻ ৪) নেওয়া হয়েছে। "ব্যাসার্ধের প্রকার" দৃশ্যে একই ক্লোরিনের সমযোজী ও ভ্যানডার ওয়ালস ব্যাসার্ধের পার্থক্য এবং সোডিয়ামের ধাতব ব্যাসার্ধ কীভাবে মাপা হয় তা দেখো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['cat', 'ক্যাটায়ন'], ['an', 'অ্যানায়ন'], ['iso', 'সমইলেকট্রনীয়'], ['grp', 'গ্রুপে নিচে'], ['type', 'ব্যাসার্ধের প্রকার']], 'cat')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = m => {
      let s = '', W = 400, H;
      if (m === 'type') {
        const k = 0.42, cy = 70;
        // covalent: Cl2 overlapping
        const r = 99 * k; s += `<text x="10" y="18" class="tb" style="font-size:12px">সমযোজী ব্যাসার্ধ (Cl₂ অণু)</text>`;
        s += `<circle cx="${f1(100 - r)}" cy="${cy}" r="${f1(r * 1.45)}" fill="#5BAED9" opacity=".2" stroke="#2F86D6" stroke-width=".8"/><circle cx="${f1(100 + r)}" cy="${cy}" r="${f1(r * 1.45)}" fill="#5BAED9" opacity=".2" stroke="#2F86D6" stroke-width=".8"/>`;
        s += `<circle cx="${100 - r}" cy="${cy}" r="3" class="f-fg"/><circle cx="${100 + r}" cy="${cy}" r="3" class="f-fg"/><text x="${100 - r}" y="${cy - 8}" text-anchor="middle" style="font-size:12px;font-weight:600">Cl</text><text x="${100 + r}" y="${cy - 8}" text-anchor="middle" style="font-size:12px;font-weight:600">Cl</text>`;
        s += `<line x1="${100 - r}" y1="${cy + 18}" x2="${100 + r}" y2="${cy + 18}" class="s-fg" marker-start="url(#c3ra)" marker-end="url(#c3ra)"/><text x="100" y="${cy + 32}" text-anchor="middle" class="mono" style="font-size:11px">d = 198 pm</text><text x="100" y="${cy + 46}" text-anchor="middle" class="tb mono" style="font-size:11.5px">r(সমযোজী) = 99 pm</text>`;
        // vdW: two Cl2 molecules non-bonded
        const ox = 250, rv = 175 * k * 0.5;
        s += `<text x="${ox - 30}" y="18" class="tb" style="font-size:12px">ভ্যানডার ওয়ালস ব্যাসার্ধ</text>`;
        [ox, ox + 2 * rv].forEach((x, i) => s += `<circle cx="${f1(x)}" cy="${cy}" r="${f1(rv)}" fill="#E9A53B" opacity=".22" stroke="#C08A1E" stroke-width="1"/><circle cx="${f1(x)}" cy="${cy}" r="3" class="f-fg"/><text x="${f1(x)}" y="${cy - 8}" text-anchor="middle" style="font-size:12px;font-weight:600">Cl</text>`);
        s += `<line x1="${ox}" y1="${cy + 18}" x2="${f1(ox + 2 * rv)}" y2="${cy + 18}" class="s-fg" marker-start="url(#c3ra)" marker-end="url(#c3ra)"/><text x="${f1(ox + rv)}" y="${cy + 32}" text-anchor="middle" class="mono" style="font-size:11px">d = 350 pm</text><text x="${f1(ox + rv)}" y="${cy + 46}" text-anchor="middle" class="tb mono" style="font-size:11.5px">r(vdW) = 175 pm</text><text x="${f1(ox + rv)}" y="${cy + 60}" text-anchor="middle" class="tm" style="font-size:10px">(দুটি পৃথক অণুর বন্ধনহীন Cl)</text>`;
        // metallic
        const ky = 196, rm = 186 * 0.2;
        s += `<text x="10" y="${ky - 46}" class="tb" style="font-size:12px">ধাতব ব্যাসার্ধ (সোডিয়াম কেলাস)</text>`;
        for (let i = 0; i < 4; i++) { const x = 50 + rm + i * 2 * rm; s += `<circle cx="${f1(x)}" cy="${ky}" r="${f1(rm)}" fill="#9DB6CC" opacity=".55" stroke="#6E8BA6"/><text x="${f1(x)}" y="${ky + 4}" text-anchor="middle" style="font-size:11px;font-weight:600;fill:${INK}">Na</text>`; }
        s += `<line x1="${f1(50 + rm)}" y1="${ky + rm + 10}" x2="${f1(50 + 3 * rm)}" y2="${ky + rm + 10}" class="s-fg" marker-start="url(#c3ra)" marker-end="url(#c3ra)"/><text x="${f1(50 + 2 * rm)}" y="${ky + rm + 24}" text-anchor="middle" class="mono" style="font-size:11px">d = 372 pm → r(ধাতব) = 186 pm</text>`;
        H = ky + rm + 32;
        box.innerHTML = X.svg(W, H, `<defs>${X.arrow('c3ra')}</defs>` + s, 'ব্যাসার্ধের প্রকার');
        out.innerHTML = '<b>সমযোজী ব্যাসার্ধ</b>: সমযোজী বন্ধনে আবদ্ধ দুটি একই পরমাণুর নিউক্লিয়াসের দূরত্বের অর্ধেক। <b>ভ্যানডার ওয়ালস ব্যাসার্ধ</b>: পাশাপাশি দুটি অণুর বন্ধনহীন পরমাণুর নিউক্লিয়াসের ন্যূনতম দূরত্বের অর্ধেক — সবসময় সমযোজী ব্যাসার্ধের চেয়ে বড়। <b>ধাতব ব্যাসার্ধ</b>: ধাতব কেলাসে পাশাপাশি দুটি পরমাণুর নিউক্লিয়াসের দূরত্বের অর্ধেক।';
        return;
      }
      const D = RC[m], k = D.k; let y = 18;
      D.rows.forEach(row => {
        const maxr = Math.max(...row.map(a => a[1])) * k; const cy = y + maxr + 4;
        const tot = row.reduce((t, a) => t + 2 * a[1] * k, 0), gap = (W - 20 - tot) / (row.length + 1);
        let x = 10 + gap;
        row.forEach(([n, r, t], i) => {
          const rr = r * k, cx = x + rr;
          s += `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(rr)}" fill="${RCOL[t]}" opacity="${t === 'n' ? 0.55 : 0.75}" stroke="${t === 'n' ? '#6E8BA6' : 'rgba(0,0,0,.25)'}" ${t === 'n' ? 'stroke-dasharray="3 2"' : ''}/>`;
          s += `<text x="${f1(cx)}" y="${f1(cy + (rr < 12 ? 3.8 : 4.6))}" text-anchor="middle" style="font-size:${rr < 12 ? 10.5 : 13}px;font-weight:700;fill:${INK}">${rr < 9 ? '' : n}</text>`;
          s += `<text x="${f1(cx)}" y="${f1(cy + maxr + 16)}" text-anchor="middle" class="mono" style="font-size:11px">${rr < 9 ? n + ' ' : ''}${r} pm</text>`;
          if (i < row.length - 1 && (m === 'cat' || m === 'an')) s += `<text x="${f1(x + 2 * rr + gap / 2)}" y="${f1(cy + 4)}" text-anchor="middle" class="tm" style="font-size:16px">→</text>`;
          x += 2 * rr + gap;
        });
        y = cy + maxr + 30;
      });
      // scale bar
      s += `<line x1="14" y1="${y}" x2="${f1(14 + 100 * k)}" y2="${y}" class="s-fg" stroke-width="2"/><line x1="14" y1="${y - 4}" x2="14" y2="${y + 4}" class="s-fg"/><line x1="${f1(14 + 100 * k)}" y1="${y - 4}" x2="${f1(14 + 100 * k)}" y2="${y + 4}" class="s-fg"/><text x="${f1(20 + 100 * k)}" y="${y + 4}" class="tm mono" style="font-size:10.5px">১০০ pm</text>`;
      const lg = [['#9DB6CC', 'নিরপেক্ষ পরমাণু'], ['#E8775C', 'ক্যাটায়ন'], ['#5BAED9', 'অ্যানায়ন']];
      let lx = 140; lg.forEach(([c, n]) => { s += `<circle cx="${lx}" cy="${y}" r="5" fill="${c}"/><text x="${lx + 8}" y="${y + 4}" class="tm" style="font-size:10.5px">${n}</text>`; lx += 86; });
      H = y + 12;
      box.innerHTML = X.svg(W, H, s, 'আকার তুলনা');
      out.innerHTML = D.note;
    };
    X.onSeg(el, 'm', draw); draw('cat');
  }
};

/* ======================= ক্রমিক আয়নীকরণ শক্তি ======================= */
const IES = { Li: [520, 7298, 11815], Be: [900, 1757, 14849, 21007], B: [801, 2427, 3660, 25026, 32827], C: [1086, 2353, 4621, 6223, 37831, 47277], Na: [496, 4562, 6910, 9543, 13354, 16613], Mg: [738, 1451, 7733, 10543, 13630, 18020], Al: [578, 1817, 2745, 11577, 14842, 18379], Si: [787, 1577, 3232, 4356, 16091, 19805], P: [1012, 1907, 2914, 4964, 6274, 21267] };
V.c3_ieSucc = {
  t: 'ক্রমিক আয়নীকরণ শক্তি: বড় লাফ থেকে গ্রুপ নির্ণয়', k: ['2d', 'int'],
  cap: 'মৌল বেছে নাও। স্তম্ভগুলো IE₁, IE₂, IE₃ … (লগারিদমিক স্কেলে — প্রতিটি দাগে মান ১০ গুণ)। প্রতিবার ইলেকট্রন সরালে অবশিষ্ট ইলেকট্রনের উপর নিউক্লিয়াসের টান বাড়ে, তাই IE ক্রমশ বাড়ে। কিন্তু যোজ্যতা স্তর খালি হয়ে যাওয়ার পর পরের ইলেকট্রনটি ভেতরের পূর্ণ (নিষ্ক্রিয় গ্যাস বিন্যাসের) স্তর থেকে সরাতে হয় — তখন হঠাৎ বিশাল লাফ। লাফের আগে যতগুলো ইলেকট্রন সরানো গেল, সেটিই যোজ্যতা ইলেকট্রন সংখ্যা।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('e', Object.keys(IES).map(k => [k, k]), 'Mg')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = sym => {
      const v = IES[sym], x0 = 50, x1 = 392, y0 = 196, y1 = 24, lmin = 2, lmax = 5;
      const ty = val => y0 - (Math.log10(val) - lmin) / (lmax - lmin) * (y0 - y1);
      let s = `<line x1="${x0}" y1="${y0}" x2="${x1}" y2="${y0}" class="s-ln"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y1}" class="s-ln"/>`;
      [100, 1000, 10000, 100000].forEach(t => s += `<line x1="${x0}" y1="${f1(ty(t))}" x2="${x1}" y2="${f1(ty(t))}" class="s-ln" opacity=".22"/><text x="${x0 - 4}" y="${f1(ty(t) + 3.5)}" text-anchor="end" class="tm mono" style="font-size:10px">${t >= 1000 ? (t / 1000) + 'k' : t}</text>`);
      s += `<text x="${x0}" y="${y1 - 8}" class="tm" style="font-size:10.5px">আয়নীকরণ শক্তি (kJ mol⁻¹, লগ স্কেল)</text>`;
      let jump = 0, jr = 0; for (let i = 1; i < v.length; i++) { const r = v[i] / v[i - 1]; if (r > jr) { jr = r; jump = i; } }
      const n = v.length, bw = Math.min(42, (x1 - x0 - 20) / n - 10), gap = (x1 - x0 - n * bw) / (n + 1);
      v.forEach((val, i) => {
        const x = x0 + gap + i * (bw + gap), y = ty(val), core = i >= jump;
        s += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(bw)}" height="${f1(y0 - y)}" rx="3" fill="${core ? '#E5484D' : '#5B9BD5'}" opacity="${core ? 0.85 : 0.8}"/><text x="${f1(x + bw / 2)}" y="${f1(y - 5)}" text-anchor="middle" class="mono" style="font-size:10px;font-weight:600">${val}</text><text x="${f1(x + bw / 2)}" y="${y0 + 15}" text-anchor="middle" class="mono" style="font-size:11px">IE${X.sub(i + 1)}</text>`;
      });
      const xa = x0 + gap + (jump - 1) * (bw + gap) + bw / 2, xb = x0 + gap + jump * (bw + gap) + bw / 2, ya = ty(v[jump - 1]) - 18, yb = ty(v[jump]) - 18;
      s += `<path d="M${f1(xa)} ${f1(ya)} Q${f1((xa + xb) / 2)} ${f1(Math.min(ya, yb) - 24)} ${f1(xb)} ${f1(yb)}" fill="none" stroke="#E5484D" stroke-width="1.8" marker-end="url(#c3ie)"/><text x="${f1((xa + xb) / 2)}" y="${f1(Math.min(ya, yb) - 26)}" text-anchor="middle" style="font-size:11px;font-weight:700;fill:#E5484D">×${jr.toFixed(1)} লাফ!</text>`;
      s += `<rect x="${x1 - 150}" y="${y1 - 2}" width="10" height="10" rx="2" fill="#5B9BD5"/><text x="${x1 - 136}" y="${y1 + 7}" class="tm" style="font-size:10px">যোজ্যতা স্তর</text><rect x="${x1 - 72}" y="${y1 - 2}" width="10" height="10" rx="2" fill="#E5484D"/><text x="${x1 - 58}" y="${y1 + 7}" class="tm" style="font-size:10px">ভেতরের স্তর</text>`;
      box.innerHTML = X.svg(400, 222, `<defs>${X.arrowC('c3ie', '#E5484D')}</defs>` + s, 'ক্রমিক IE');
      const e = X.PT.find(z => z.sym === sym);
      out.innerHTML = `<b>${sym}</b> (${e.name}): <span class="mono">${X.cfgZ(e.Z)}</span><br>সবচেয়ে বড় লাফ IE${X.sub(jump)} → IE${X.sub(jump + 1)} (${v[jump - 1]} → ${v[jump]} kJ mol⁻¹, প্রায় <b>${jr.toFixed(1)} গুণ</b>)<br>⇒ যোজ্যতা ইলেকট্রন <b>${bn(jump)}টি</b> ⇒ <b>গ্রুপ ${bn(e.g)}</b> · সাধারণ আয়ন: <b>${sym}${jump > 1 ? X.sup(jump) : ''}⁺</b>${jump === 4 ? ' <span class="small muted">(কার্বনের ক্ষেত্রে আয়ন নয়, ৪টি সমযোজী বন্ধন)</span>' : ''}`;
    };
    X.onSeg(el, 'e', draw); draw('Mg');
  }
};

/* ======================= তাপ-মানচিত্র: EN / EA / IE / ব্যাসার্ধ ======================= */
const RAMP = ['#FCF4D9', '#F8D79A', '#F1A76A', '#DB6E4C', '#B23A48', '#7A1F48'];
const ramp = t => { t = Math.max(0, Math.min(1, t)); const i = Math.min(RAMP.length - 2, Math.floor(t * (RAMP.length - 1))), u = t * (RAMP.length - 1) - i; const h = c => [1, 3, 5].map(k => parseInt(c.substr(k, 2), 16)); const a = h(RAMP[i]), b = h(RAMP[i + 1]); return '#' + a.map((x, k) => Math.round(x + (b[k] - x) * u).toString(16).padStart(2, '0')).join(''); };
const HM = { en: ['তড়িৎ ঋণাত্মকতা', X.EN, 0.7, 4.0, ''], ea: ['ইলেকট্রন আসক্তি', X.EA, 0, 350, 'kJ mol⁻¹'], ie: ['প্রথম আয়নীকরণ শক্তি', X.IE1, 370, 2400, 'kJ mol⁻¹'], rad: ['পারমাণবিক ব্যাসার্ধ', X.RAD, 30, 270, 'pm'] };
V.c3_heatmap = {
  t: 'পর্যায় সারণির তাপ-মানচিত্র: তড়িৎ ঋণাত্মকতা ও ইলেকট্রন আসক্তি', k: ['2d', 'int'],
  cap: 'যত গাঢ় রং, মান তত বেশি। এক নজরে দেখো: EN ও EA উপরে-ডানে সবচেয়ে বেশি (F, Cl, O), নিচে-বামে সবচেয়ে কম (Cs, Rb) — কিন্তু ব্যাসার্ধের ক্ষেত্রে ঠিক উল্টো। ইলেকট্রন আসক্তিতে লক্ষ করো: Be, Mg (পূর্ণ ns²), N (অর্ধপূর্ণ 2p³) ও নিষ্ক্রিয় গ্যাসের মান প্রায় শূন্য (হালকা ঘর), আর Cl এর মান F এর চেয়েও বেশি। মৌলে চাপ দিলে প্রকৃত মান দেখাবে (Z = ১–৫৬)।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('p', [['en', 'তড়িৎ ঋণাত্মকতা'], ['ea', 'ইলেকট্রন আসক্তি'], ['ie', 'আয়নীকরণ শক্তি'], ['rad', 'ব্যাসার্ধ']], 'en')}</div><div data-svg></div><div data-leg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), leg = el.querySelector('[data-leg]'); let p = 'en', sel = 9;
    const draw = () => {
      const [n, a, lo, hi, u] = HM[p];
      const r = C3.pt({ maxZ: 56, fRows: false, sel, fill: e => a[e.Z - 1] == null ? null : ramp((a[e.Z - 1] - lo) / (hi - lo)), ink: e => (a[e.Z - 1] - lo) / (hi - lo) > 0.62 ? '#fff' : INK });
      box.innerHTML = X.svg(r.W, r.H - (r.cell + r.gap) + 2, r.s, n);
      leg.innerHTML = `<div style="display:flex;align-items:center;gap:8px;margin-top:6px" class="small"><span class="mono">${lo}</span><span style="flex:1;height:10px;border-radius:5px;background:linear-gradient(90deg,${RAMP.join(',')})"></span><span class="mono">${hi}${u ? ' ' + u : ''}</span></div><div class="small muted" style="margin-top:2px">সাদা ঘর: মান সংজ্ঞায়িত/তুলনীয় নয়</div>`;
      const e = X.PT[sel - 1], v = a[sel - 1];
      out.innerHTML = `<b>${e.sym}</b> (${e.name}) · ${n}: <b>${v == null ? 'সংজ্ঞায়িত নয়' : v + (u ? ' ' + u : '')}</b>${p === 'ea' && v === 0 ? ' <span class="small">(ইলেকট্রন গ্রহণে শক্তি মুক্ত হয় না বা শোষিত হয়)</span>' : ''}`;
    };
    X.onSeg(el, 'p', k => { p = k; draw(); }); C3.onZ(box, z => { if (z <= 56) { sel = z; draw(); } }); draw();
  }
};

/* ======================= ৩য় পর্যায়: গলনাঙ্ক, যোজনী, জারণ-বিজারণ ======================= */
const P3 = ['Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar'];
const P3MP = [98, 650, 660, 1414, 44, 115, -101, -189], P3BP = [883, 1090, 2519, 3265, 281, 445, -34, -186];
const P3T = ['m', 'm', 'm', 'gc', 'mol', 'mol', 'mol', 'mono'];
const P3TN = { m: ['ধাতব জালক', '#E8775C'], gc: ['দানবীয় সমযোজী জালক', '#5FB09A'], mol: ['সরল অণু (P₄, S₈, Cl₂)', '#6FA8DC'], mono: ['একপরমাণুক', '#A88BD8'] };
V.c3_period3 = {
  t: '৩য় পর্যায় (Na → Ar): গলনাঙ্ক, যোজনী ও জারণ-বিজারণ ধর্ম', k: ['2d', 'int'],
  cap: '"গলনাঙ্ক" দৃশ্যে স্তম্ভের রং বলে দেয় কেলাসে কোন ধরনের বল ভাঙতে হয়: Na → Al ধাতব বন্ধন শক্তিশালী হয় (যোজ্যতা ইলেকট্রন ১ → ৩), Si তে পুরো দানবীয় সমযোজী জালক ভাঙতে হয় (সর্বোচ্চ), আর P, S, Cl এ শুধু দুর্বল আন্তঃআণবিক বল — হঠাৎ পতন। "যোজনী" দৃশ্যে অক্সিজেনের সাপেক্ষে যোজনী ১ → ৭ বাড়ে, হাইড্রোজেনের সাপেক্ষে ১ → ৪ → ১। "জারণ-বিজারণ" দৃশ্যে বামের ধাতু শক্তিশালী বিজারক, ডানের অধাতু শক্তিশালী জারক।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['mp', 'গলনাঙ্ক ও গঠন'], ['val', 'যোজনী'], ['rx', 'জারণ-বিজারণ']], 'mp')}</div><div data-svg></div><div data-leg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'), leg = el.querySelector('[data-leg]'); let m = 'mp', bp = false;
    const draw = () => {
      let s = ''; leg.innerHTML = '';
      const x0 = 50, x1 = 394, cw = (x1 - x0) / 8;
      if (m === 'mp') {
        const vals = bp ? P3BP : P3MP, ymin = -380, ymax = bp ? 3500 : 1600, y0 = 210, y1 = 24;
        const yt = bp ? [0, 1000, 2000, 3000] : [-200, 0, 400, 800, 1200, 1600];
        const A = C3.axis({ x0, x1, y0, y1, ymin, ymax, yt, ylab: (bp ? 'স্ফুটনাঙ্ক' : 'গলনাঙ্ক') + ' (°C)' }); s += A.s;
        const z = A.ty(0); s += `<line x1="${x0}" y1="${f1(z)}" x2="${x1}" y2="${f1(z)}" class="s-fg" stroke-width="1"/>`;
        vals.forEach((v, i) => { const x = x0 + i * cw + 6, y = A.ty(v); s += `<rect x="${f1(x)}" y="${f1(Math.min(y, z))}" width="${f1(cw - 12)}" height="${f1(Math.abs(z - y))}" rx="2" fill="${P3TN[P3T[i]][1]}"/><text x="${f1(x + (cw - 12) / 2)}" y="${f1(v >= 0 ? y - 4 : y + 12)}" text-anchor="middle" class="mono" style="font-size:9.5px;font-weight:600">${v}</text><text x="${f1(x + (cw - 12) / 2)}" y="${y0 + 15}" text-anchor="middle" style="font-size:12.5px;font-weight:600">${P3[i]}</text>`; });
        box.innerHTML = X.svg(400, 230, s, 'গলনাঙ্ক') + `<div class="ctl"><button class="btn sm" data-bp>${bp ? 'গলনাঙ্ক দেখাও' : 'স্ফুটনাঙ্ক দেখাও'}</button></div>`;
        box.querySelector('[data-bp]').onclick = () => { bp = !bp; draw(); };
        leg.innerHTML = C3.legend(Object.values(P3TN).map(([n, c]) => [c, n]));
        out.innerHTML = 'Na (98 °C) → Mg (650) → Al (660): ধাতব বন্ধনে অংশ নেওয়া ইলেকট্রন বাড়ে ও আয়ন ছোট হয় — বন্ধন শক্তিশালী। Si (1414 °C) সর্বোচ্চ — প্রতিটি Si চারটি সমযোজী বন্ধনে ত্রিমাত্রিক জালকে যুক্ত। P₄ (44), S₈ (115), Cl₂ (−101), Ar (−189): এখানে শুধু অণুগুলোর মধ্যের দুর্বল ভ্যানডার ওয়ালস বল ভাঙতে হয়; S₈ বড় অণু বলে P₄ এর চেয়ে বেশি।';
      } else if (m === 'val') {
        const ox = ['Na₂O', 'MgO', 'Al₂O₃', 'SiO₂', 'P₄O₁₀', 'SO₃', 'Cl₂O₇', '—'], hy = ['NaH', 'MgH₂', 'AlH₃', 'SiH₄', 'PH₃', 'H₂S', 'HCl', '—'];
        const vo = [1, 2, 3, 4, 5, 6, 7, 0], vh = [1, 2, 3, 4, 3, 2, 1, 0], y0 = 200, y1 = 40, ty = v => y0 - v / 7.5 * (y0 - y1);
        const A = C3.axis({ x0, x1, y0, y1, ymin: 0, ymax: 7.5, yt: [0, 1, 2, 3, 4, 5, 6, 7], ylab: 'যোজনী' }); s += A.s;
        let po = '', ph = '';
        P3.forEach((e, i) => { const cx = x0 + i * cw + cw / 2; if (i < 7) { po += (i ? 'L' : 'M') + f1(cx) + ' ' + f1(ty(vo[i])); ph += (i ? 'L' : 'M') + f1(cx) + ' ' + f1(ty(vh[i])); } s += `<text x="${f1(cx)}" y="${y0 + 15}" text-anchor="middle" style="font-size:12.5px;font-weight:600">${e}</text><text x="${f1(cx)}" y="${y0 + 29}" text-anchor="middle" style="font-size:9.5px;fill:#E5484D">${ox[i]}</text><text x="${f1(cx)}" y="${y0 + 42}" text-anchor="middle" style="font-size:9.5px;fill:#2F86D6">${hy[i]}</text>`; });
        s += `<path d="${po}" fill="none" stroke="#E5484D" stroke-width="2.4"/><path d="${ph}" fill="none" stroke="#2F86D6" stroke-width="2.4" stroke-dasharray="6 4"/>`;
        P3.forEach((e, i) => { if (i < 7) { const cx = x0 + i * cw + cw / 2; s += `<circle cx="${f1(cx)}" cy="${f1(ty(vo[i]))}" r="4" fill="#E5484D"/><circle cx="${f1(cx)}" cy="${f1(ty(vh[i]))}" r="4" fill="#2F86D6"/>`; } });
        s += `<text x="${x0 + 8}" y="${y1 - 22}" style="font-size:11px;fill:#E5484D;font-weight:600">— অক্সিজেনের সাপেক্ষে (সর্বোচ্চ অক্সাইড)</text><text x="${x0 + 8}" y="${y1 - 8}" style="font-size:11px;fill:#2F86D6;font-weight:600">- - হাইড্রোজেনের সাপেক্ষে (হাইড্রাইড)</text>`;
        box.innerHTML = X.svg(400, 250, s, 'যোজনী');
        out.innerHTML = 'অক্সিজেনের সাপেক্ষে যোজনী = যোজ্যতা ইলেকট্রন সংখ্যা (১ → ৭) — সব যোজ্যতা ইলেকট্রন বন্ধনে দেওয়া যায়। হাইড্রোজেনের সাপেক্ষে যোজনী গ্রুপ ১৪ পর্যন্ত বাড়ে (১ → ৪), তারপর অষ্টক পূরণে যত ইলেকট্রন লাগে তত (৮ − যোজ্যতা ইলেকট্রন: ৩, ২, ১)। Ar নিষ্ক্রিয় — যোজনী শূন্য।';
      } else {
        const y = 70; let g = `<defs><linearGradient id="c3rx" x1="0" x2="1"><stop offset="0" stop-color="#E8775C"/><stop offset=".45" stop-color="#C9B8A3"/><stop offset="1" stop-color="#4FB6C9"/></linearGradient>${X.arrow('c3rxa')}</defs>`;
        s += `<rect x="${x0}" y="${y}" width="${x1 - x0}" height="26" rx="13" fill="url(#c3rx)"/>`;
        P3.forEach((e, i) => { const cx = x0 + i * cw + cw / 2; s += `<text x="${f1(cx)}" y="${y + 18}" text-anchor="middle" style="font-size:13px;font-weight:700;fill:${INK}">${e}</text>`; });
        s += `<line x1="${x0 + 10}" y1="${y - 14}" x2="${x1 - 10}" y2="${y - 14}" class="s-fg" marker-end="url(#c3rxa)"/><text x="${(x0 + x1) / 2}" y="${y - 22}" text-anchor="middle" style="font-size:11.5px">ধাতব ধর্ম কমে, অধাতব ধর্ম বাড়ে</text>`;
        s += `<text x="${x0}" y="${y + 50}" style="font-size:11.5px;font-weight:600;fill:#D2552F">শক্তিশালী বিজারক</text><text x="${x0}" y="${y + 66}" class="tm" style="font-size:10.5px">ইলেকট্রন দান করে: Na → Na⁺ + e⁻</text>`;
        s += `<text x="${x1}" y="${y + 50}" text-anchor="end" style="font-size:11.5px;font-weight:600;fill:#2A8FA6">শক্তিশালী জারক</text><text x="${x1}" y="${y + 66}" text-anchor="end" class="tm" style="font-size:10.5px">ইলেকট্রন গ্রহণ করে: Cl₂ + 2e⁻ → 2Cl⁻</text>`;
        s += `<text x="${(x0 + x1) / 2}" y="${y + 96}" text-anchor="middle" style="font-size:11.5px">Na ও Cl₂ এর বিক্রিয়া: 2Na + Cl₂ → 2NaCl</text><text x="${(x0 + x1) / 2}" y="${y + 112}" text-anchor="middle" class="tm" style="font-size:10.5px">Na জারিত (০ → +১) · Cl বিজারিত (০ → −১)</text>`;
        box.innerHTML = X.svg(400, y + 122, g + s, 'জারণ বিজারণ');
        out.innerHTML = 'পর্যায়ে বাম থেকে ডানে আয়নীকরণ শক্তি ও তড়িৎ ঋণাত্মকতা বাড়ে — ইলেকট্রন ত্যাগের প্রবণতা (বিজারণ ক্ষমতা, ধাতব ধর্ম) কমে এবং ইলেকট্রন গ্রহণের প্রবণতা (জারণ ক্ষমতা, অধাতব ধর্ম) বাড়ে। গ্রুপে নিচে ধাতুর বিজারণ ক্ষমতা বাড়ে (Cs সবচেয়ে সক্রিয়) এবং হ্যালোজেনের জারণ ক্ষমতা কমে (F₂ > Cl₂ > Br₂ > I₂)।';
      }
    };
    X.onSeg(el, 'm', k => { m = k; draw(); }); draw();
  }
};

/* ======================= স্লেটারের নিয়মে Zeff ======================= */
const SLG = [['1s'], ['2s', '2p'], ['3s', '3p'], ['3d'], ['4s', '4p'], ['4d'], ['4f'], ['5s', '5p']];
const slater = (Z, sub) => {
  const o = X.occZ(Z), gi = SLG.findIndex(g => g.includes(sub)), grp = SLG[gi], n = +sub[0], isd = sub[1] === 'd' || sub[1] === 'f';
  const rows = []; let sig = 0;
  SLG.forEach((g, i) => {
    const cnt = g.reduce((t, k) => t + (o[k] || 0), 0); if (!cnt) return;
    let c = cnt, f = 0, why = '';
    if (i === gi) { c = cnt - 1; f = sub === '1s' ? 0.30 : 0.35; why = 'একই গ্রুপ (নিজেকে বাদ দিয়ে)'; }
    else if (i > gi) { f = 0; why = 'ডানের গ্রুপ — আবরণ করে না'; }
    else if (isd) { f = 1; why = 'বামের সব গ্রুপ (d/f ইলেকট্রনের জন্য)'; }
    else { const gn = +g[0][0]; if (gn === n - 1) { f = 0.85; why = '(n−1) শক্তিস্তর'; } else if (gn === n && g[0][1] === 'd') { f = 0; why = '—'; } else { f = 1; why = '(n−2) বা আরও ভেতরের স্তর'; } }
    if (!c && i === gi) { rows.push([g.join(','), 0, f, 0, why]); return; }
    rows.push([g.join(','), c, f, c * f, why]); sig += c * f;
  });
  return { rows, sig, zeff: Z - sig };
};
const valSub = Z => { const o = X.occZ(Z), k = Object.keys(o); let best = k[0]; k.forEach(s => { const a = +s[0], b = +best[0]; if (a > b || (a === b && 'spdf'.indexOf(s[1]) > 'spdf'.indexOf(best[1]) && s[1] !== 'd')) best = s; }); return best; };
V.c3_zeff = {
  t: 'কার্যকর নিউক্লিয়ার চার্জ: স্লেটারের নিয়মে হিসাব', k: ['calc', 'int'],
  cap: 'মৌল ও ইলেকট্রন বেছে নাও — স্লেটারের নিয়মের প্রতিটি ধাপ সারণিতে দেখাবে: ইলেকট্রনগুলোকে (1s)(2s,2p)(3s,3p)(3d)(4s,4p)… গ্রুপে সাজাও; ns/np ইলেকট্রনের জন্য একই গ্রুপের প্রতিটি অন্য ইলেকট্রন ০.৩৫ (1s এ ০.৩০), (n−1) স্তরের প্রতিটি ০.৮৫ এবং আরও ভেতরের প্রতিটি ১.০০ আবরণ দেয়; d বা f ইলেকট্রনের জন্য বামের সব ইলেকট্রন ১.০০। Zeff = Z − σ। নিচের লেখচিত্রে একই পর্যায়ে বাম থেকে ডানে যোজ্যতা ইলেকট্রনের Zeff কীভাবে বাড়ে তা দেখো — এটিই পর্যায়ে আকার কমা ও IE বাড়ার মূল কারণ।',
  html: () => `<div class="ctl" style="margin:0"><label style="flex:none">মৌল</label><select class="inp" data-z style="flex:1">${X.PT.slice(0, 36).map(e => `<option value="${e.Z}" ${e.Z === 11 ? 'selected' : ''}>${bn(e.Z)} ${e.sym} — ${e.name}</option>`).join('')}</select></div><div class="ctl" data-subs></div><div data-tab></div><div class="calc-out" data-out></div><div data-svg></div>`,
  mount(el) {
    const sel = el.querySelector('[data-z]'), subs = el.querySelector('[data-subs]'), tab = el.querySelector('[data-tab]'), out = el.querySelector('[data-out]'), box = el.querySelector('[data-svg]');
    let Z = 11, sub = '3s';
    const chart = () => {
      const e = X.PT[Z - 1], per = e.per; const lo = [1, 3, 11, 19][per - 1], hi = [2, 10, 18, 36][per - 1];
      const zs = []; for (let z = lo; z <= hi; z++) if (per < 4 || (z <= 20 || z >= 31)) zs.push(z);
      const vals = zs.map(z => slater(z, valSub(z)).zeff);
      const x0 = 40, x1 = 392, y0 = 150, y1 = 22, mx = Math.ceil(Math.max(...vals) + 0.5);
      const A = C3.axis({ x0, x1, y0, y1, ymin: 0, ymax: mx, yt: Array.from({ length: mx + 1 }, (_, i) => i).filter(i => mx < 9 || i % 2 === 0), ylab: `যোজ্যতা ইলেকট্রনের Zeff — ${bn(per)} পর্যায়` });
      let s = A.s; const cw = (x1 - x0) / zs.length;
      zs.forEach((z, i) => { const x = x0 + i * cw + cw * 0.18, y = A.ty(vals[i]), on = z === Z; s += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(cw * 0.64)}" height="${f1(y0 - y)}" rx="2" fill="${on ? '#E5484D' : X.PTBLK[X.PT[z - 1].block]}" opacity="${on ? 1 : 0.7}"/><text x="${f1(x + cw * 0.32)}" y="${f1(y - 4)}" text-anchor="middle" class="mono" style="font-size:${zs.length > 10 ? 8 : 9.5}px">${vals[i].toFixed(2)}</text><text x="${f1(x + cw * 0.32)}" y="${y0 + 13}" text-anchor="middle" style="font-size:${zs.length > 10 ? 9.5 : 11.5}px;font-weight:600">${SYM(z)}</text>`; });
      box.innerHTML = X.svg(400, 168, s, 'Zeff লেখচিত্র') + (per === 4 ? '<div class="small muted">৪র্থ পর্যায়ে শুধু s ও p-ব্লকের মৌল দেখানো হয়েছে।</div>' : '');
    };
    const run = () => {
      const o = X.occZ(Z), ks = Object.keys(o).sort((a, b) => X.SUBS.indexOf(a) - X.SUBS.indexOf(b));
      if (!o[sub]) sub = valSub(Z);
      subs.innerHTML = '<label style="flex:none">কোন ইলেকট্রনের জন্য?</label>' + X.seg('s', ks.map(k => [k, k]), sub);
      X.onSeg(subs, 's', k => { sub = k; run(); });
      const r = slater(Z, sub);
      tab.innerHTML = `<div class="table-wrap" style="margin-top:8px"><table class="t"><thead><tr><th>গ্রুপ</th><th class="c">ইলেকট্রন</th><th class="c">গুণক</th><th class="c">অবদান</th></tr></thead><tbody>${r.rows.map(([g, c, f, v, w]) => `<tr><td><span class="mono">(${g})</span><br><span class="small muted">${w}</span></td><td class="c">${c}</td><td class="c mono">${f.toFixed(2)}</td><td class="c mono">${v.toFixed(2)}</td></tr>`).join('')}<tr><td colspan="3"><b>মোট আবরণ ধ্রুবক σ</b></td><td class="c mono"><b>${r.sig.toFixed(2)}</b></td></tr></tbody></table></div>`;
      out.innerHTML = `<b>${X.PT[Z - 1].sym}</b> এর একটি <b>${sub}</b> ইলেকট্রন: Zeff = Z − σ = ${Z} − ${r.sig.toFixed(2)} = <b>${r.zeff.toFixed(2)}</b><br><span class="small">অর্থাৎ ${Z}টি প্রোটনের মধ্যে এ ইলেকট্রন কার্যত মাত্র ${r.zeff.toFixed(2)}টির টান অনুভব করে।</span>`;
      chart();
    };
    sel.addEventListener('change', () => { Z = +sel.value; sub = valSub(Z); run(); });
    run();
  }
};

/* ======================= IE এর নিয়ামক: আকার ও স্থিতিশীল বিন্যাস ======================= */
const IEP = {
  BeB: { a: ['Be', 4, { '2s': 2, '2p': 0 }, 900], b: ['B', 5, { '2s': 2, '2p': 1 }, 801], rm: ['2s', '2p'], t: 'B এর ইলেকট্রনটি 2p থেকে সরে — 2p উপস্তর 2s এর চেয়ে বেশি শক্তির ও নিউক্লিয়াস থেকে গড়ে দূরে, তাছাড়া 2s ইলেকট্রন 2p কে আংশিক আবরণ করে (ভেদন ক্ষমতা s > p)। তাই B এর IE₁ (801) Be (900, পূর্ণ 2s²) এর চেয়ে কম — পর্যায়ের সাধারণ প্রবণতার ব্যতিক্রম।' },
  NO: { a: ['N', 7, { '2s': 2, '2p': 3 }, 1402], b: ['O', 8, { '2s': 2, '2p': 4 }, 1314], rm: ['2p', '2p'], t: 'N এর 2p³ অর্ধপূর্ণ — তিনটি অরবিটালে একটি করে ইলেকট্রন, অতিরিক্ত স্থিতিশীল (বিনিময় শক্তি সর্বাধিক)। O এর 2p⁴ এ একটি অরবিটালে দুটি ইলেকট্রন — যুগ্ম ইলেকট্রনের পারস্পরিক বিকর্ষণে একটিকে সরানো সহজ। তাই O এর IE₁ (1314) N (1402) এর চেয়ে কম।' },
  MgAl: { a: ['Mg', 12, { '3s': 2, '3p': 0 }, 738], b: ['Al', 13, { '3s': 2, '3p': 1 }, 578], rm: ['3s', '3p'], t: 'Be–B এর মতোই: Al এর ইলেকট্রন বেশি শক্তির 3p থেকে সরে এবং 3s² দ্বারা আবৃত — তাই Al (578) < Mg (738)।' },
  PS: { a: ['P', 15, { '3s': 2, '3p': 3 }, 1012], b: ['S', 16, { '3s': 2, '3p': 4 }, 1000], rm: ['3p', '3p'], t: 'N–O এর মতোই: P এর 3p³ অর্ধপূর্ণ ও স্থিতিশীল; S এর 3p⁴ এ যুগ্ম ইলেকট্রনের বিকর্ষণ। তাই S (1000) < P (1012) — তবে ৩য় পর্যায়ে বড় আকারের জন্য পার্থক্য কম।' }
};
V.c3_ieFactors = {
  t: 'আয়নীকরণ শক্তির নিয়ামক: আকার, আবরণ ও স্থিতিশীল বিন্যাস', k: ['2d', 'int'],
  cap: '"গ্রুপ ১" দৃশ্যে পরমাণুগুলো ব্যাসার্ধের অনুপাতে আঁকা; প্রতিটি বৃত্তরেখা একটি শক্তিস্তর, লাল বিন্দু যোজ্যতা ইলেকট্রন। আকার যত বড়, নিউক্লিয়াস থেকে যোজ্যতা ইলেকট্রনের দূরত্ব তত বেশি এবং ভেতরের স্তরের আবরণ তত বেশি — টান কম, IE কম। বাকি দৃশ্যগুলোতে পর্যায়ের দুই বিখ্যাত ব্যতিক্রম অরবিটাল বাক্স চিত্রে: যে ইলেকট্রনটি সরানো হবে সেটি লাল।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['grp', 'গ্রুপ ১: আকারের প্রভাব'], ['BeB', 'Be বনাম B'], ['NO', 'N বনাম O'], ['MgAl', 'Mg বনাম Al'], ['PS', 'P বনাম S']], 'grp')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = m => {
      let s = '';
      if (m === 'grp') {
        const D = [['Li', 152, 2, 520], ['Na', 186, 3, 496], ['K', 227, 4, 419], ['Rb', 248, 5, 403], ['Cs', 265, 6, 376]], k = 0.135; let x = 10;
        const cy = 64;
        D.forEach(([sym, r, sh, ie]) => {
          const R = r * k, cx = x + R + 4;
          for (let i = 1; i <= sh; i++) s += `<circle cx="${f1(cx)}" cy="${cy}" r="${f1(R * i / sh)}" fill="none" class="s-ln" ${i === sh ? 'stroke-width="1.4"' : 'stroke-dasharray="2 2"'}/>`;
          s += `<circle cx="${f1(cx)}" cy="${cy}" r="${f1(R * 0.22)}" fill="#E9A53B" opacity=".55"/><text x="${f1(cx)}" y="${cy + 3.5}" text-anchor="middle" style="font-size:9px;font-weight:700">+</text><circle cx="${f1(cx + R)}" cy="${cy}" r="3.6" fill="#E5484D"/>`;
          s += `<text x="${f1(cx)}" y="${f1(cy + 46)}" text-anchor="middle" style="font-size:12.5px;font-weight:700">${sym}</text><text x="${f1(cx)}" y="${f1(cy + 59)}" text-anchor="middle" class="tm mono" style="font-size:10px">${r} pm</text>`;
          const bh = ie / 520 * 66; s += `<rect x="${f1(cx - 13)}" y="${f1(cy + 160 - bh)}" width="26" height="${f1(bh)}" rx="3" fill="#5B9BD5"/><text x="${f1(cx)}" y="${f1(cy + 156 - bh)}" text-anchor="middle" class="mono" style="font-size:10px;font-weight:600">${ie}</text>`;
          x = cx + R + 6;
        });
        s += `<line x1="8" y1="${cy + 160}" x2="392" y2="${cy + 160}" class="s-ln"/><text x="8" y="${cy + 176}" class="tm" style="font-size:10.5px">IE₁ (kJ mol⁻¹) · লাল বিন্দু = ns¹ যোজ্যতা ইলেকট্রন</text>`;
        box.innerHTML = X.svg(400, cy + 182, s, 'গ্রুপ ১');
        out.innerHTML = 'Li → Cs: শক্তিস্তর ২ → ৬, ব্যাসার্ধ 152 → 265 pm। নিউক্লিয়ার চার্জ ৩ থেকে ৫৫ পর্যন্ত বাড়লেও ভেতরের স্তরগুলোর আবরণে যোজ্যতা ইলেকট্রনের Zeff প্রায় একই থাকে (স্লেটার ≈ ১.৩–২.২), অথচ দূরত্ব অনেক বাড়ে। আকর্ষণ বল ∝ Zeff/r² — তাই IE কমে: Li 520 → Cs 376 kJ mol⁻¹, আর সক্রিয়তা বাড়ে।';
        return;
      }
      const P = IEP[m];
      const drawAtom = ([sym, Z, occ, ie], rm, ox) => {
        let g = `<text x="${ox + 70}" y="22" text-anchor="middle" style="font-size:15px;font-weight:700">${sym}</text><text x="${ox + 70}" y="38" text-anchor="middle" class="tm mono" style="font-size:10.5px">${X.cfgZ(Z)}</text>`;
        const keys = Object.keys(occ), ns = keys[0], np = keys[1], bw = 26, by = 112;
        // ns box (lower) and np boxes (higher energy)
        const box1 = (x, y, e, red) => { let t = `<rect x="${x}" y="${y}" width="${bw}" height="${bw}" fill="none" class="s-fg" stroke-width="1.4"/>`; if (e >= 1) t += `<text x="${x + 8}" y="${y + 19}" text-anchor="middle" style="font-size:17px;font-weight:700;fill:${red === 1 ? '#E5484D' : 'var(--fg)'}">↑</text>`; if (e >= 2) t += `<text x="${x + 18}" y="${y + 19}" text-anchor="middle" style="font-size:17px;font-weight:700;fill:${red === 2 ? '#E5484D' : 'var(--fg)'}">↓</text>`; return t; };
        const npE = occ[np]; const fill = [0, 0, 0]; for (let i = 0; i < npE; i++) fill[i % 3]++;
        // which electron is removed: last added
        let redNs = 0, redNp = -1;
        if (npE === 0) redNs = 2; else { const lastIdx = (npE - 1) % 3; redNp = lastIdx; }
        g += box1(ox + 20, by, occ[ns], redNs ? 2 : 0) + `<text x="${ox + 33}" y="${by + bw + 14}" text-anchor="middle" class="mono tm" style="font-size:10.5px">${ns}</text>`;
        for (let i = 0; i < 3; i++) g += box1(ox + 62 + i * bw, by - 36, fill[i], i === redNp ? (fill[i] === 2 ? 2 : 1) : 0);
        g += `<text x="${ox + 62 + 1.5 * bw}" y="${by - 42}" text-anchor="middle" class="mono tm" style="font-size:10.5px">${np}</text>`;
        g += `<line x1="${ox + 8}" y1="${by + bw + 24}" x2="${ox + 8}" y2="${by - 50}" class="s-mu" marker-end="url(#c3ief)"/><text x="${ox + 4}" y="${by - 54}" class="tm" style="font-size:9.5px">শক্তি</text>`;
        const bh = ie / 1500 * 70; g += `<rect x="${ox + 52}" y="${f1(by + 120 - bh)}" width="36" height="${f1(bh)}" rx="3" fill="#5B9BD5"/><text x="${ox + 70}" y="${f1(by + 114 - bh)}" text-anchor="middle" class="mono" style="font-size:11px;font-weight:700">${ie}</text>`;
        return g;
      };
      s += drawAtom(P.a, P.rm[0], 20) + drawAtom(P.b, P.rm[1], 220);
      s += `<line x1="200" y1="10" x2="200" y2="236" class="s-ln" stroke-dasharray="3 3"/><line x1="20" y1="232" x2="380" y2="232" class="s-ln"/><text x="380" y="248" text-anchor="end" class="tm" style="font-size:10.5px">IE₁ (kJ mol⁻¹) · লাল = যে ইলেকট্রন সরবে</text>`;
      box.innerHTML = X.svg(400, 254, `<defs>${X.arrow('c3ief')}</defs>` + s, 'IE ব্যতিক্রম');
      out.innerHTML = P.t;
    };
    X.onSeg(el, 'm', draw); draw('grp');
  }
};

/* ======================= ইলেকট্রন আসক্তির ব্যতিক্রম ======================= */
const EAD = {
  g17: { els: ['F', 'Cl', 'Br', 'I'], v: [328, 349, 325, 295], t: 'গ্রুপে নিচে আকার বাড়ায় সাধারণত EA কমে (Cl > Br > I)। কিন্তু F এর EA (328) Cl (349) এর চেয়ে কম! F অত্যন্ত ক্ষুদ্র — এর 2p উপস্তরে ইতিমধ্যে ৭টি ইলেকট্রন খুব ছোট জায়গায় গাদাগাদি করে আছে। আগত ইলেকট্রনকে তাদের তীব্র বিকর্ষণ সইতে হয়। Cl এর 3p উপস্তর বড় — বিকর্ষণ কম, তাই বেশি শক্তি মুক্ত হয়। একইভাবে O (141) < S (200)।' },
  p2: { els: ['Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne'], v: [60, 0, 27, 122, 0, 141, 328, 0], t: 'পর্যায়ে ডানে EA সাধারণত বাড়ে, কিন্তু তিনটি খাদ: Be (পূর্ণ 2s² — নতুন ইলেকট্রনকে বেশি শক্তির 2p তে যেতে হয়), N (অর্ধপূর্ণ 2p³ — নতুন ইলেকট্রনকে যুগ্ম হতে হয়, বিকর্ষণ) এবং Ne (পূর্ণ অষ্টক — নতুন ইলেকট্রনকে পরের শক্তিস্তরে যেতে হয়)। এদের EA প্রায় শূন্য বা ঋণাত্মক (শক্তি শোষিত হয়)।' },
  g16: { els: ['O', 'S', 'Se', 'Te'], v: [141, 200, 195, 190], t: 'হ্যালোজেনের মতোই: ক্ষুদ্র O এর 2p উপস্তরে ইলেকট্রন-ইলেকট্রন বিকর্ষণ বেশি, তাই O এর EA (141) S (200) এর চেয়ে কম। S থেকে নিচে আকার বাড়ায় স্বাভাবিকভাবে কমে।' }
};
V.c3_eaAnomaly = {
  t: 'ইলেকট্রন আসক্তি: আকারের প্রভাব ও ব্যতিক্রম', k: ['2d', 'int'],
  cap: 'স্তম্ভের উচ্চতা = ইলেকট্রন যুক্ত হলে মুক্ত শক্তি (kJ mol⁻¹)। হ্যাচ করা ধূসর স্তম্ভ মানে আসক্তি প্রায় শূন্য বা ঋণাত্মক — ইলেকট্রন যোগ করতে উল্টো শক্তি লাগে। প্রতিটি দৃশ্যের নিচে ব্যতিক্রমের কারণ লেখা আছে।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['g17', 'গ্রুপ ১৭: F বনাম Cl'], ['g16', 'গ্রুপ ১৬: O বনাম S'], ['p2', '২য় পর্যায়']], 'g17')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const draw = m => {
      const D = EAD[m], x0 = 46, x1 = 392, y0 = 190, y1 = 24, n = D.els.length;
      const A = C3.axis({ x0, x1, y0, y1, ymin: 0, ymax: 380, yt: [0, 100, 200, 300], ylab: 'ইলেকট্রন আসক্তি (kJ mol⁻¹)' });
      let s = `<defs><pattern id="c3hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" class="s-mu" stroke-width="2"/></pattern></defs>` + A.s;
      const cw = (x1 - x0) / n, mx = Math.max(...D.v);
      D.els.forEach((e, i) => {
        const v = D.v[i], x = x0 + i * cw + cw * 0.2, w = cw * 0.6;
        if (v > 0) { const y = A.ty(v); s += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(y0 - y)}" rx="3" fill="${v === mx ? '#E5484D' : '#4FB6C9'}"/><text x="${f1(x + w / 2)}" y="${f1(y - 5)}" text-anchor="middle" class="mono" style="font-size:10.5px;font-weight:600">${v}</text>`; }
        else s += `<rect x="${f1(x)}" y="${y0 - 14}" width="${f1(w)}" height="14" fill="url(#c3hatch)" stroke="var(--muted)" stroke-width=".8"/><text x="${f1(x + w / 2)}" y="${y0 - 19}" text-anchor="middle" class="mono tm" style="font-size:10px">≈০/−</text>`;
        s += `<text x="${f1(x + w / 2)}" y="${y0 + 15}" text-anchor="middle" style="font-size:12.5px;font-weight:600">${e}</text>`;
      });
      if (m !== 'p2') {
        // inset: small vs large atom with crowded electrons
        const ix = 150, iy = y0 + 66;
        s += `<g opacity=".95"><circle cx="${ix}" cy="${iy}" r="18" fill="#4FB6C9" opacity=".25" stroke="#2A8FA6"/><text x="${ix}" y="${iy + 4}" text-anchor="middle" style="font-size:11px;font-weight:700">${D.els[0]}</text>`;
        for (let i = 0; i < 7; i++) { const a = i / 7 * 6.283; s += `<circle cx="${f1(ix + 15 * Math.cos(a))}" cy="${f1(iy + 15 * Math.sin(a))}" r="2.2" class="f-fg"/>`; }
        s += `<circle cx="${ix + 72}" cy="${iy}" r="30" fill="#4FB6C9" opacity=".18" stroke="#2A8FA6"/><text x="${ix + 72}" y="${iy + 4}" text-anchor="middle" style="font-size:11px;font-weight:700">${D.els[1]}</text>`;
        for (let i = 0; i < 7; i++) { const a = i / 7 * 6.283; s += `<circle cx="${f1(ix + 72 + 26 * Math.cos(a))}" cy="${f1(iy + 26 * Math.sin(a))}" r="2.2" class="f-fg"/>`; }
        s += `<text x="${ix + 36}" y="${iy + 48}" text-anchor="middle" class="tm" style="font-size:10px">ছোট মেঘে গাদাগাদি (বিকর্ষণ বেশি) বনাম বড় মেঘে ছড়ানো</text></g>`;
      }
      box.innerHTML = X.svg(400, m === 'p2' ? 212 : y0 + 122, s, 'ইলেকট্রন আসক্তি');
      out.innerHTML = D.t;
    };
    X.onSeg(el, 'm', draw); draw('g17');
  }
};

/* ======================= ΔEN, বন্ধন পোলারিটি ও % আয়নিক বৈশিষ্ট্য ======================= */
const ENL = ['H', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'K', 'Ca', 'Br', 'I', 'Cs'];
const zOf = s => X.PT.find(e => e.sym === s).Z;
const ENI = { I: 2.66, Cs: 0.79 };
const enOf = s => ENI[s] != null ? ENI[s] : X.EN[zOf(s) - 1];
V.c3_enDiff = {
  t: 'তড়িৎ ঋণাত্মকতার পার্থক্য: অপোলার, পোলার না আয়নিক?', k: ['calc', 'int'],
  cap: 'দুটি মৌল বেছে নাও। শেয়ারকৃত ইলেকট্রন মেঘ (রঙিন ছায়া) বেশি তড়িৎ ঋণাত্মক পরমাণুর দিকে সরে যায় — সেখানে δ⁻, অপর প্রান্তে δ⁺। নিচের স্কেলে ΔEN এর অবস্থান দেখায় বন্ধনটি অপোলার সমযোজী (ΔEN < ০.৪), পোলার সমযোজী (০.৪–১.৭) না আয়নিক প্রাধান্যের (> ১.৭)। শতকরা আয়নিক বৈশিষ্ট্য পলিং-এর সূত্রে: [১ − e^(−ΔEN²/৪)] × ১০০। মনে রাখো ১.৭ একটি মোটামুটি সীমা — HF (ΔEN ১.৭৮) আসলে সমযোজী অণু।',
  html: () => `<div class="grid2"><select class="inp" data-a>${ENL.map(s => `<option ${s === 'H' ? 'selected' : ''}>${s}</option>`).join('')}</select><select class="inp" data-b>${ENL.map(s => `<option ${s === 'Cl' ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
    <div class="ctl">${[['H', 'H'], ['C', 'H'], ['H', 'Cl'], ['H', 'F'], ['Na', 'Cl'], ['Cs', 'F'], ['Al', 'Cl']].map(([a, b]) => `<button class="btn sm" data-p="${a},${b}">${a}–${b}</button>`).join('')}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const A = el.querySelector('[data-a]'), B = el.querySelector('[data-b]'), box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]');
    const run = () => {
      const a = A.value, b = B.value, ea = enOf(a), eb = enOf(b), d = Math.abs(ea - eb), pi = (1 - Math.exp(-d * d / 4)) * 100;
      const left = ea <= eb ? a : b, right = ea <= eb ? b : a, el_ = Math.min(ea, eb), er = Math.max(ea, eb);
      const cls = d < 0.4 ? ['অপোলার সমযোজী', '#5FB09A'] : d <= 1.7 ? ['পোলার সমযোজী', '#E9A53B'] : ['আয়নিক প্রাধান্য', '#E5484D'];
      const cxL = 120, cxR = 280, cy = 70, shift = Math.min(1, d / 3.2) * 80;
      let s = `<defs><radialGradient id="c3cloud"><stop offset="0" stop-color="${cls[1]}" stop-opacity=".55"/><stop offset="1" stop-color="${cls[1]}" stop-opacity="0"/></radialGradient>${X.arrow('c3dm')}</defs>`;
      s += `<ellipse cx="${f1(200 + shift)}" cy="${cy}" rx="${f1(120 - shift * 0.45)}" ry="${f1(46 - shift * 0.08)}" fill="url(#c3cloud)"/>`;
      s += `<circle cx="${cxL}" cy="${cy}" r="24" class="f-sf s-fg" stroke-width="1.5"/><circle cx="${cxR}" cy="${cy}" r="24" class="f-sf s-fg" stroke-width="1.5"/><text x="${cxL}" y="${cy + 5}" text-anchor="middle" style="font-size:16px;font-weight:700">${left}</text><text x="${cxR}" y="${cy + 5}" text-anchor="middle" style="font-size:16px;font-weight:700">${right}</text>`;
      s += `<text x="${cxL}" y="${cy - 32}" text-anchor="middle" class="mono tm" style="font-size:11px">EN ${el_.toFixed(2)}</text><text x="${cxR}" y="${cy - 32}" text-anchor="middle" class="mono tm" style="font-size:11px">EN ${er.toFixed(2)}</text>`;
      if (d >= 0.05) s += `<text x="${cxL}" y="${cy + 44}" text-anchor="middle" style="font-size:14px;font-weight:700;fill:#E8775C">${d > 1.7 ? '+' : 'δ⁺'}</text><text x="${cxR}" y="${cy + 44}" text-anchor="middle" style="font-size:14px;font-weight:700;fill:#2F86D6">${d > 1.7 ? '−' : 'δ⁻'}</text><line x1="${cxL + 30}" y1="${cy + 54}" x2="${cxR - 30}" y2="${cy + 54}" class="s-fg" stroke-width="1.4" marker-end="url(#c3dm)"/><line x1="${cxL + 36}" y1="${cy + 49}" x2="${cxL + 36}" y2="${cy + 59}" class="s-fg" stroke-width="1.4"/><text x="200" y="${cy + 68}" text-anchor="middle" class="tm" style="font-size:9.5px">ডাইপোল তীর (δ⁺ → δ⁻)</text>`;
      // scale
      const sx0 = 30, sx1 = 370, sy = 166, sxv = v => sx0 + v / 3.3 * (sx1 - sx0);
      s += `<rect x="${sx0}" y="${sy}" width="${f1(sxv(0.4) - sx0)}" height="14" fill="#5FB09A" opacity=".75"/><rect x="${f1(sxv(0.4))}" y="${sy}" width="${f1(sxv(1.7) - sxv(0.4))}" height="14" fill="#E9A53B" opacity=".75"/><rect x="${f1(sxv(1.7))}" y="${sy}" width="${f1(sx1 - sxv(1.7))}" height="14" fill="#E5484D" opacity=".7"/>`;
      [0, 0.4, 1, 1.7, 2.5, 3.3].forEach(v => s += `<text x="${f1(sxv(v))}" y="${sy + 38}" text-anchor="middle" class="mono tm" style="font-size:9.5px">${v}</text>`);
      s += `<text x="${f1((sx0 + sxv(0.4)) / 2)}" y="${sy - 5}" text-anchor="middle" style="font-size:9.5px">অপোলার</text><text x="${f1((sxv(0.4) + sxv(1.7)) / 2)}" y="${sy - 5}" text-anchor="middle" style="font-size:9.5px">পোলার সমযোজী</text><text x="${f1((sxv(1.7) + sx1) / 2)}" y="${sy - 5}" text-anchor="middle" style="font-size:9.5px">আয়নিক</text>`;
      s += `<path d="M${f1(sxv(Math.min(3.3, d)))} ${sy + 16} l-6 10 h12z" class="f-fg"/>`;
      s += `<text x="${sx1}" y="${sy + 52}" text-anchor="end" class="tm" style="font-size:10px">ΔEN স্কেল</text>`;
      box.innerHTML = X.svg(400, sy + 58, s, 'ΔEN');
      out.innerHTML = `ΔEN = |${ea.toFixed(2)} − ${eb.toFixed(2)}| = <b>${d.toFixed(2)}</b> → <b style="color:${cls[1]}">${cls[0]}</b><br>পলিং অনুযায়ী আয়নিক বৈশিষ্ট্য ≈ <b>${pi.toFixed(1)}%</b>, সমযোজী বৈশিষ্ট্য ≈ <b>${(100 - pi).toFixed(1)}%</b>${d === 0 ? '<br><span class="small">একই মৌল — ইলেকট্রন যুগল সমানভাবে শেয়ার হয় (বিশুদ্ধ অপোলার)।</span>' : ''}`;
    };
    A.onchange = B.onchange = run;
    el.querySelectorAll('[data-p]').forEach(b => b.onclick = () => { const [a, c] = b.dataset.p.split(','); A.value = a; B.value = c; run(); });
    run();
  }
};

/* ======================= ২য় ও ৩য় পর্যায়ের অক্সাইড ======================= */
const OXN = { b: ['ক্ষারীয়', '#8FB3F0'], a: ['উভধর্মী', '#9CD08F'], wa: ['মৃদু অম্লীয়', '#F5C98A'], ac: ['অম্লীয়', '#F0A38C'] };
const OXD = {
  3: [
    ['Na₂O', 'b', 'আয়নিক জালক', 'Na₂O + H₂O → 2NaOH (তীব্র ক্ষার, pH ≈ 14)<br>Na₂O + 2HCl → 2NaCl + H₂O'],
    ['MgO', 'b', 'আয়নিক জালক', 'MgO + H₂O → Mg(OH)₂ (সামান্য দ্রবণীয়, pH ≈ 9–10)<br>MgO + 2HCl → MgCl₂ + H₂O'],
    ['Al₂O₃', 'a', 'আয়নিক (সমযোজী বৈশিষ্ট্যসহ)', 'পানিতে অদ্রবণীয়<br>এসিডের সাথে: Al₂O₃ + 6HCl → 2AlCl₃ + 3H₂O<br>ক্ষারের সাথে: Al₂O₃ + 2NaOH + 3H₂O → 2Na[Al(OH)₄]'],
    ['SiO₂', 'wa', 'দানবীয় সমযোজী জালক', 'পানিতে অদ্রবণীয়; গরম গাঢ় ক্ষারের সাথে: SiO₂ + 2NaOH → Na₂SiO₃ + H₂O'],
    ['P₄O₁₀', 'ac', 'সরল সমযোজী অণু', 'P₄O₁₀ + 6H₂O → 4H₃PO₄ (pH ≈ 1–2)'],
    ['SO₃', 'ac', 'সরল সমযোজী অণু', 'SO₃ + H₂O → H₂SO₄ (pH ≈ 0–1)<br>(SO₂ + H₂O ⇌ H₂SO₃)'],
    ['Cl₂O₇', 'ac', 'সরল সমযোজী অণু', 'Cl₂O₇ + H₂O → 2HClO₄ (পারক্লোরিক এসিড, অত্যন্ত তীব্র)']
  ],
  2: [
    ['Li₂O', 'b', 'আয়নিক জালক', 'Li₂O + H₂O → 2LiOH (ক্ষার)'],
    ['BeO', 'a', 'সমযোজী বৈশিষ্ট্যযুক্ত', 'BeO + 2HCl → BeCl₂ + H₂O<br>BeO + 2NaOH + H₂O → Na₂[Be(OH)₄]'],
    ['B₂O₃', 'wa', 'সমযোজী জালক', 'B₂O₃ + 3H₂O → 2H₃BO₃ (দুর্বল বোরিক এসিড)'],
    ['CO₂', 'ac', 'সরল সমযোজী অণু', 'CO₂ + H₂O ⇌ H₂CO₃ (দুর্বল কার্বনিক এসিড)<br><span class="small">CO নিরপেক্ষ অক্সাইড</span>'],
    ['N₂O₅', 'ac', 'সরল সমযোজী অণু', 'N₂O₅ + H₂O → 2HNO₃<br><span class="small">NO ও N₂O নিরপেক্ষ অক্সাইড</span>']
  ]
};
V.c3_oxides = {
  t: 'পর্যায়ে অক্সাইডের প্রকৃতি: ক্ষারীয় → উভধর্মী → অম্লীয়', k: ['2d', 'int'],
  cap: 'পর্যায় বেছে নিয়ে যেকোনো অক্সাইডে চাপ দাও — তার বন্ধনের ধরন এবং পানি, এসিড বা ক্ষারের সাথে বিক্রিয়ার সমীকরণ দেখাবে। বামের ধাতব অক্সাইড আয়নিক ও ক্ষারীয় (O²⁻ আয়ন পানির H⁺ গ্রহণ করে OH⁻ দেয়), মাঝের Al₂O₃ ও BeO উভধর্মী, আর ডানের অধাতব অক্সাইড সমযোজী ও অম্লীয় (পানির সাথে অক্সো-এসিড দেয়)। কারণ: পর্যায়ে ডানে মৌলের তড়িৎ ঋণাত্মকতা বাড়ে, ফলে M–O বন্ধন আয়নিক থেকে সমযোজী হয়।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('p', [[3, '৩য় পর্যায়'], [2, '২য় পর্যায়']], 3)}</div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let p = 3, sel = 2;
    const draw = () => {
      const D = OXD[p], n = D.length, x0 = 8, cw = (384) / n; let s = `<defs><linearGradient id="c3oxg" x1="0" x2="1"><stop offset="0" stop-color="#5B5FC7"/><stop offset=".45" stop-color="#4CAF50"/><stop offset=".65" stop-color="#F2A541"/><stop offset="1" stop-color="#E5484D"/></linearGradient></defs>`;
      D.forEach(([f, t], i) => { const x = x0 + i * cw, on = i === sel; s += `<g data-i="${i}" style="cursor:pointer"><rect x="${f1(x + 2)}" y="10" width="${f1(cw - 4)}" height="62" rx="8" fill="${OXN[t][1]}" ${on ? 'stroke="var(--fg)" stroke-width="2.2"' : ''}/><text x="${f1(x + cw / 2)}" y="38" text-anchor="middle" style="font-size:${n > 5 ? 12.5 : 14}px;font-weight:700;fill:${INK}">${f}</text><text x="${f1(x + cw / 2)}" y="58" text-anchor="middle" style="font-size:10px;fill:${INK}">${OXN[t][0]}</text></g>`; });
      s += `<rect x="${x0}" y="84" width="384" height="10" rx="5" fill="url(#c3oxg)"/><text x="${x0}" y="110" class="tm" style="font-size:10.5px">← ক্ষারীয় (আয়নিক)</text><text x="${x0 + 384}" y="110" text-anchor="end" class="tm" style="font-size:10.5px">অম্লীয় (সমযোজী) →</text>`;
      box.innerHTML = X.svg(400, 116, s, 'অক্সাইড');
      const [f, t, b, r] = D[sel]; out.innerHTML = `<b>${f}</b> · <b>${OXN[t][0]}</b> · ${b}<br>${r}`;
    };
    X.onSeg(el, 'p', k => { p = +k; sel = p === 3 ? 2 : 1; draw(); });
    box.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g) { sel = +g.dataset.i; draw(); } });
    draw();
  }
};

/* ======================= ব্যবহারিক: অক্সাইডের দ্রবণে নির্দেশক ======================= */
const OL = { Na2O: ['Na₂O', 13.5, 'Na₂O + H₂O → 2NaOH', 'b'], CaO: ['CaO', 12.4, 'CaO + H₂O → Ca(OH)₂', 'b'], MgO: ['MgO', 10.3, 'MgO + H₂O → Mg(OH)₂ (স্বল্প দ্রবণীয়)', 'b'], CO2: ['CO₂', 5.0, 'CO₂ + H₂O ⇌ H₂CO₃', 'a'], SO2: ['SO₂', 2.5, 'SO₂ + H₂O ⇌ H₂SO₃', 'a'], P4O10: ['P₄O₁₀', 1.5, 'P₄O₁₀ + 6H₂O → 4H₃PO₄', 'a'] };
const UNI = ['#D62828', '#D62828', '#E8432A', '#F25C2A', '#F78C1E', '#F6C21C', '#E6DE2E', '#7DC243', '#2FA84F', '#1F9AAE', '#2A6FC9', '#3E4FB8', '#5B3FA8', '#6A2A8E', '#6A2A8E'];
const indCol = (ind, pH) => ind === 'uni' ? UNI[Math.round(Math.max(0, Math.min(14, pH)))] : ind === 'php' ? (pH < 8.2 ? 'rgba(220,235,245,.55)' : pH < 10 ? '#F7A1C4' : '#D6337F') : ind === 'mo' ? (pH < 3.1 ? '#D7263D' : pH < 4.4 ? '#F28C28' : '#F2C84B') : 'rgba(200,225,245,.55)';
const indTxt = (ind, pH) => ind === 'uni' ? `pH ≈ ${pH}` : ind === 'php' ? (pH < 8.2 ? 'বর্ণহীন থাকে' : 'গোলাপি হয়') : ind === 'mo' ? (pH < 3.1 ? 'লাল হয়' : pH < 4.4 ? 'কমলা হয়' : 'হলুদ হয়') : (pH < 7 ? 'নীল লিটমাস লাল হয়, লাল লিটমাস লালই থাকে' : 'লাল লিটমাস নীল হয়, নীল লিটমাস নীলই থাকে');
V.c3_oxideLab = {
  t: 'ভার্চুয়াল ল্যাব: দ্রবণীয় অক্সাইডের অম্ল-ক্ষার প্রকৃতি নির্ণয়', k: ['anim', 'int'],
  cap: 'একটি অক্সাইড ও একটি নির্দেশক বেছে নাও — অক্সাইড পাতিত পানিতে দ্রবীভূত হয়ে এসিড বা ক্ষার তৈরি করবে, তারপর নির্দেশকের ফোঁটা পড়ে রং বদলাবে। লিটমাস নির্বাচন করলে লাল ও নীল দুটি লিটমাস কাগজ ডোবানো হবে। ব্যবহারিক খাতার মতো পর্যবেক্ষণ ও সিদ্ধান্ত নিচে লেখা হবে। (MgO পানিতে খুব কম দ্রবণীয়, তবুও দ্রবণ মৃদু ক্ষারীয়; CO₂ এর দ্রবণ দুর্বল অম্লীয়।)',
  html: () => `<div class="ctl" style="margin:0 0 6px"><label style="flex:none">অক্সাইড</label>${X.seg('o', Object.keys(OL).map(k => [k, OL[k][0]]), 'Na2O')}</div><div class="ctl" style="margin:0 0 6px"><label style="flex:none">নির্দেশক</label>${X.seg('i', [['lit', 'লিটমাস'], ['php', 'ফেনলফথ্যালিন'], ['mo', 'মিথাইল অরেঞ্জ'], ['uni', 'সার্বজনীন']], 'php')}</div><div data-svg></div><div class="ctl"><button class="btn sm primary" data-go>আবার পরীক্ষা করো</button></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let o = 'Na2O', ind = 'php', tm = [];
    const clear = () => { tm.forEach(clearTimeout); tm = []; };
    const run = () => {
      clear();
      const [f, pH, eq, t] = OL[o], col = indCol(ind, pH);
      const lit = ind === 'lit';
      let s = `<defs><clipPath id="c3bk"><path d="M128 60 L128 196 Q128 214 146 214 L254 214 Q272 214 272 196 L272 60Z"/></clipPath></defs>`;
      s += `<g clip-path="url(#c3bk)"><rect data-liq x="120" y="104" width="160" height="120" fill="rgba(200,225,245,.55)" style="transition:fill 1.1s ease"/>`;
      s += `<g data-pow opacity="0"><circle cx="186" cy="110" r="3" class="f-mu"/><circle cx="196" cy="114" r="2.5" class="f-mu"/><circle cx="206" cy="108" r="3" class="f-mu"/><circle cx="214" cy="116" r="2" class="f-mu"/></g></g>`;
      s += `<path d="M124 52 L128 60 L128 196 Q128 214 146 214 L254 214 Q272 214 272 196 L272 60 L276 52" fill="none" class="s-fg" stroke-width="2"/>`;
      [130, 150, 170, 190].forEach((y, i) => s += `<line x1="128" y1="${y}" x2="${i % 2 ? 138 : 144}" y2="${y}" class="s-mu"/>`);
      if (lit) {
        s += `<g data-strip style="transition:transform .9s ease" transform="translate(0,-60)"><rect x="168" y="70" width="14" height="80" rx="2" fill="#D9534F" data-r style="transition:fill 1s ease 1s"/><rect x="218" y="70" width="14" height="80" rx="2" fill="#4A7BD0" data-bl style="transition:fill 1s ease 1s"/><text x="175" y="64" text-anchor="middle" style="font-size:10px">লাল</text><text x="225" y="64" text-anchor="middle" style="font-size:10px">নীল</text></g>`;
      } else s += `<path d="M196 8 L204 8 L204 30 L200 38 L196 30Z" class="f-s3 s-mu"/><circle data-drop cx="200" cy="42" r="4.5" fill="${ind === 'php' ? '#F1F1F1' : col}" stroke="var(--muted)" stroke-width=".6" opacity="0" style="transition:transform .7s ease-in, opacity .2s"/>`;
      s += `<text x="200" y="236" text-anchor="middle" class="tm" style="font-size:11px">${f} + পাতিত পানি</text>`;
      box.innerHTML = X.svg(400, 244, s, 'অক্সাইড ল্যাব');
      const liq = box.querySelector('[data-liq]'), pow = box.querySelector('[data-pow]');
      out.innerHTML = '<span class="muted">পরীক্ষা চলছে…</span>';
      tm.push(setTimeout(() => { pow.setAttribute('opacity', '1'); }, 150));
      tm.push(setTimeout(() => { pow.setAttribute('opacity', '0'); }, 900));
      if (lit) tm.push(setTimeout(() => { const g = box.querySelector('[data-strip]'); g.setAttribute('transform', 'translate(0,40)'); const r = box.querySelector('[data-r]'), b = box.querySelector('[data-bl]'); if (pH < 7) b.setAttribute('fill', '#D9534F'); else r.setAttribute('fill', '#4A7BD0'); }, 1000));
      else tm.push(setTimeout(() => { const d = box.querySelector('[data-drop]'); d.setAttribute('opacity', '1'); requestAnimationFrame(() => d.style.transform = 'translateY(66px)'); }, 1000), setTimeout(() => { box.querySelector('[data-drop]').setAttribute('opacity', '0'); liq.setAttribute('fill', col); }, 1750));
      tm.push(setTimeout(() => {
        out.innerHTML = `<b>বিক্রিয়া:</b> ${eq}<br><b>পর্যবেক্ষণ:</b> ${indTxt(ind, pH)}<br><b>সিদ্ধান্ত:</b> দ্রবণটি <b>${t === 'b' ? 'ক্ষারীয়' : 'অম্লীয়'}</b> — ${f} একটি <b>${t === 'b' ? 'ক্ষারীয় (ধাতব)' : 'অম্লীয় (অধাতব)'}</b> অক্সাইড।<span class="small muted"> (আনুমানিক pH ${pH})</span>`;
      }, X.rm() ? 50 : 2300));
      if (X.rm()) { liq.setAttribute('fill', lit ? 'rgba(200,225,245,.55)' : col); }
    };
    X.onSeg(el, 'o', k => { o = k; run(); }); X.onSeg(el, 'i', k => { ind = k; run(); });
    el.querySelector('[data-go]').onclick = run;
    run();
    return clear;
  }
};
})();
