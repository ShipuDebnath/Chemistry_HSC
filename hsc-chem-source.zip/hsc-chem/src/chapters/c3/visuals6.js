/* Chapter 3 visuals part 6 — naming, complex compounds, concept map, trend quiz (3.21, summary) */
(function () {
'use strict';
const V = window.VIS, X = window.VX, C3 = window.C3V;
const bn = X.bn, f1 = v => (+v).toFixed(1);
const INK = '#1b1b1f';
const CPK = C3.CPK;
const ROM = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
const gcd = (a, b) => b ? gcd(b, a % b) : a;

/* ======================= ৩.২১ নামকরণ: সংকেত গঠন, অক্সো-অ্যানায়ন সিঁড়ি ও কুইজ ======================= */
// cation: [display, formula core, charge, name, variable?, poly?]
const CA = [['Na⁺', 'Na', 1, 'সোডিয়াম', 0, 0], ['K⁺', 'K', 1, 'পটাসিয়াম', 0, 0], ['NH₄⁺', 'NH₄', 1, 'অ্যামোনিয়াম', 0, 1], ['Ca²⁺', 'Ca', 2, 'ক্যালসিয়াম', 0, 0], ['Mg²⁺', 'Mg', 2, 'ম্যাগনেসিয়াম', 0, 0], ['Al³⁺', 'Al', 3, 'অ্যালুমিনিয়াম', 0, 0], ['Fe²⁺', 'Fe', 2, 'আয়রন', 1, 0], ['Fe³⁺', 'Fe', 3, 'আয়রন', 1, 0], ['Cu⁺', 'Cu', 1, 'কপার', 1, 0], ['Cu²⁺', 'Cu', 2, 'কপার', 1, 0], ['Pb²⁺', 'Pb', 2, 'লেড', 1, 0], ['Sn⁴⁺', 'Sn', 4, 'টিন', 1, 0]];
const AN = [['Cl⁻', 'Cl', 1, 'ক্লোরাইড', 0], ['O²⁻', 'O', 2, 'অক্সাইড', 0], ['S²⁻', 'S', 2, 'সালফাইড', 0], ['OH⁻', 'OH', 1, 'হাইড্রক্সাইড', 1], ['NO₃⁻', 'NO₃', 1, 'নাইট্রেট', 1], ['NO₂⁻', 'NO₂', 1, 'নাইট্রাইট', 1], ['SO₄²⁻', 'SO₄', 2, 'সালফেট', 1], ['SO₃²⁻', 'SO₃', 2, 'সালফাইট', 1], ['CO₃²⁻', 'CO₃', 2, 'কার্বনেট', 1], ['HCO₃⁻', 'HCO₃', 1, 'হাইড্রোজেন কার্বনেট', 1], ['PO₄³⁻', 'PO₄', 3, 'ফসফেট', 1], ['ClO⁻', 'ClO', 1, 'হাইপোক্লোরাইট', 1], ['ClO₃⁻', 'ClO₃', 1, 'ক্লোরেট', 1], ['MnO₄⁻', 'MnO₄', 1, 'পারম্যাঙ্গানেট', 1], ['Cr₂O₇²⁻', 'Cr₂O₇', 2, 'ডাইক্রোমেট', 1]];
const formula = (c, a) => { const g = gcd(c[2], a[2]), nc = a[2] / g, na = c[2] / g; const part = (core, n, poly) => n === 1 ? core : (poly ? `(${core})` : core) + X.sub(n); return { f: part(c[1], nc, c[5]) + part(a[1], na, a[4]), nc, na, name: `${c[3]}${c[4] ? '(' + ROM[c[2]] + ')' : ''} ${a[3]}` }; };
const OXL = [['ClO⁻', 'হাইপোক্লোরাইট', 'HClO', 'হাইপোক্লোরাস এসিড', 1, 1], ['ClO₂⁻', 'ক্লোরাইট', 'HClO₂', 'ক্লোরাস এসিড', 2, 3], ['ClO₃⁻', 'ক্লোরেট', 'HClO₃', 'ক্লোরিক এসিড', 3, 5], ['ClO₄⁻', 'পারক্লোরেট', 'HClO₄', 'পারক্লোরিক এসিড', 4, 7]];
V.c3_naming = {
  t: 'অজৈব যৌগের নামকরণ: সংকেত গঠন, অক্সো-অ্যানায়ন ও অনুশীলন', k: ['int', 'calc'],
  cap: '"সংকেত তৈরি" দৃশ্যে একটি ক্যাটায়ন ও একটি অ্যানায়ন বেছে নাও — চার্জ আড়াআড়ি বসিয়ে (ক্রস পদ্ধতি) সরল অনুপাতে সংকেত তৈরি হবে এবং IUPAC নাম দেখাবে; পরিবর্তনশীল যোজ্যতার ধাতুর নামের পর রোমান সংখ্যা (স্টক পদ্ধতি)। "অক্সো-অ্যানায়ন" দৃশ্যে ক্লোরিনের চারটি অক্সো-অ্যানায়ন ও এসিডের নামের নিয়ম: O বাড়লে -আইট → -এট, সবচেয়ে কম হলে হাইপো-, সবচেয়ে বেশি হলে পার-; এসিডে -আইট → -আস, -এট → -ইক। "কুইজ" দৃশ্যে নিজেকে যাচাই করো।',
  html: () => `<div class="ctl" style="margin:0 0 6px">${X.seg('m', [['b', 'সংকেত তৈরি'], ['o', 'অক্সো-অ্যানায়ন'], ['q', 'কুইজ']], 'b')}</div><div data-body></div>`,
  mount(el) {
    const body = el.querySelector('[data-body]');
    const build = () => {
      body.innerHTML = `<div class="grid2"><select class="inp" data-c>${CA.map((c, i) => `<option value="${i}" ${i === 7 ? 'selected' : ''}>${c[0]} — ${c[3]}${c[4] ? '(' + ROM[c[2]] + ')' : ''}</option>`).join('')}</select><select class="inp" data-a>${AN.map((a, i) => `<option value="${i}" ${i === 6 ? 'selected' : ''}>${a[0]} — ${a[3]}</option>`).join('')}</select></div><div data-svg></div><div class="calc-out" data-out></div>`;
      const box = body.querySelector('[data-svg]'), out = body.querySelector('[data-out]');
      const run = () => {
        const c = CA[+body.querySelector('[data-c]').value], a = AN[+body.querySelector('[data-a]').value], F = formula(c, a);
        let s = `<defs>${X.arrowC('c3nm', '#E5484D')}</defs>`;
        s += `<text x="110" y="40" text-anchor="middle" style="font-size:22px;font-weight:700">${c[1]}</text><text x="${132 + c[1].length * 4}" y="26" style="font-size:14px;fill:#E8775C;font-weight:700">${c[2]}+</text>`;
        s += `<text x="270" y="40" text-anchor="middle" style="font-size:22px;font-weight:700">${a[1]}</text><text x="${292 + a[1].length * 4}" y="26" style="font-size:14px;fill:#2F86D6;font-weight:700">${a[2]}−</text>`;
        s += `<path d="M${136 + c[1].length * 4} 30 C200 50 240 70 ${300 + a[1].length * 5} 84" fill="none" stroke="#E8775C" stroke-width="1.6" stroke-dasharray="4 3" marker-end="url(#c3nm)"/><path d="M${296 + a[1].length * 4} 30 C220 50 170 70 ${124 + c[1].length * 6} 84" fill="none" stroke="#2F86D6" stroke-width="1.6" stroke-dasharray="4 3" marker-end="url(#c3nm)"/>`;
        s += `<text x="200" y="118" text-anchor="middle" style="font-size:26px;font-weight:700">${F.f}</text>`;
        s += `<text x="200" y="142" text-anchor="middle" class="tm" style="font-size:10.5px">মোট চার্জ: ${F.nc} × (+${c[2]}) + ${F.na} × (−${a[2]}) = ০</text>`;
        box.innerHTML = X.svg(400, 150, s, 'সংকেত');
        out.innerHTML = `সংকেত: <b>${F.f}</b><br>IUPAC নাম: <b>${F.name}</b>${c[4] ? `<br><span class="small">${c[3]} এর একাধিক জারণ অবস্থা আছে, তাই নামে রোমান সংখ্যা (${ROM[c[2]]}) = +${c[2]} জারণ অবস্থা। ${c[1] === 'Fe' ? (c[2] === 2 ? 'পুরোনো নাম: ফেরাস' : 'পুরোনো নাম: ফেরিক') : c[1] === 'Cu' ? (c[2] === 1 ? 'পুরোনো নাম: কিউপ্রাস' : 'পুরোনো নাম: কিউপ্রিক') : ''}</span>` : ''}${c[5] || (a[4] && F.na > 1) ? '<br><span class="small">একাধিক বহুপরমাণুক আয়ন থাকলে বন্ধনী ব্যবহার করতে হয়।</span>' : ''}`;
      };
      body.querySelectorAll('select').forEach(x => x.onchange = run); run();
    };
    const ladder = () => {
      let s = '';
      const x0 = 70, bw = 70, gap = 12;
      OXL.forEach(([ion, nm, ac, an, nO, ox], i) => {
        const x = x0 + i * (bw + gap), h = 30 + nO * 26, y = 170 - h;
        s += `<rect x="${x}" y="${y}" width="${bw}" height="${h}" rx="5" fill="#4FB6C9" opacity="${0.35 + i * 0.18}"/>`;
        for (let k = 0; k < nO; k++) s += `<circle cx="${x + bw / 2 + (k % 2 ? 12 : -12)}" cy="${170 - 18 - Math.floor(k / 2) * 26 - (k % 2) * 13}" r="9" fill="${CPK.O}"/>`;
        s += `<text x="${x + bw / 2}" y="${y - 8}" text-anchor="middle" class="mono" style="font-size:11px;font-weight:700">Cl: +${ox}</text><text x="${x + bw / 2}" y="188" text-anchor="middle" style="font-size:12.5px;font-weight:700">${ion}</text><text x="${x + bw / 2}" y="204" text-anchor="middle" style="font-size:10.5px">${nm}</text><text x="${x + bw / 2}" y="226" text-anchor="middle" class="mono" style="font-size:11.5px;font-weight:700">${ac}</text><text x="${x + bw / 2}" y="242" text-anchor="middle" style="font-size:9.5px">${an}</text>`;
      });
      s += `<text x="8" y="196" class="tm" style="font-size:10px">অ্যানায়ন</text><text x="8" y="234" class="tm" style="font-size:10px">এসিড</text><line x1="${x0}" y1="252" x2="${x0 + 4 * (bw + gap) - gap}" y2="252" class="s-fg" marker-end="url(#c3ol)"/><text x="${x0 + 2 * (bw + gap)}" y="268" text-anchor="middle" class="tm" style="font-size:10.5px">O এর সংখ্যা, Cl এর জারণ সংখ্যা ও অম্লশক্তি বাড়ে →</text>`;
      body.innerHTML = X.svg(400, 274, `<defs>${X.arrow('c3ol')}</defs>` + s, 'অক্সো-অ্যানায়ন') + `<div class="calc-out"><b>অ্যানায়ন:</b> হাইপো—আইট &lt; —আইট &lt; —এট &lt; পার—এট (O এর সংখ্যা বাড়ে)<br><b>এসিড:</b> -আইট → <b>-আস</b> এসিড; -এট → <b>-ইক</b> এসিড<br><span class="small">একই নিয়ম অন্য মৌলেও: SO₃²⁻ সালফাইট → H₂SO₃ সালফিউরাস এসিড; SO₄²⁻ সালফেট → H₂SO₄ সালফিউরিক এসিড; NO₂⁻ → HNO₂ নাইট্রাস; NO₃⁻ → HNO₃ নাইট্রিক।</span></div>`;
    };
    const quiz = () => {
      let score = 0, total = 0, cur = null; const rnd = X.rng(Date.now() % 100000 + 7);
      body.innerHTML = `<div class="calc-out" data-q style="font-size:16px"></div><div data-opts style="display:grid;gap:6px;margin-top:8px"></div><div class="ctl"><button class="btn sm primary" data-n>পরের প্রশ্ন</button><span class="small muted" data-s></span></div><div class="small" data-x style="margin-top:6px"></div>`;
      const qEl = body.querySelector('[data-q]'), oEl = body.querySelector('[data-opts]'), sEl = body.querySelector('[data-s]'), xEl = body.querySelector('[data-x]');
      const next = () => {
        const c = CA[Math.floor(rnd() * CA.length)], a = AN[Math.floor(rnd() * AN.length)], F = formula(c, a);
        const wrong = new Set(); const alt = () => { const kind = Math.floor(rnd() * 4); if (kind === 0 && c[4]) return `${c[3]}(${ROM[c[2] === 2 ? 3 : 2]}) ${a[3]}`; if (kind === 1) { const b = AN[Math.floor(rnd() * AN.length)]; return `${c[3]}${c[4] ? '(' + ROM[c[2]] + ')' : ''} ${b[3]}`; } if (kind === 2) return `${c[3]} ${['ডাই', 'ট্রাই', 'মনো'][Math.floor(rnd() * 3)]}${a[3]}`; const d = CA[Math.floor(rnd() * CA.length)]; return `${d[3]}${d[4] ? '(' + ROM[d[2]] + ')' : ''} ${a[3]}`; };
        let guard = 0; while (wrong.size < 3 && guard++ < 50) { const w = alt(); if (w !== F.name) wrong.add(w); }
        const opts = [F.name, ...wrong].sort(() => rnd() - 0.5); cur = F;
        qEl.innerHTML = `<b style="font-size:20px" class="mono">${F.f}</b> এর IUPAC নাম কী?`;
        oEl.innerHTML = opts.map(o => `<button class="btn" data-o="${o}" style="text-align:left;justify-content:flex-start">${o}</button>`).join('');
        xEl.innerHTML = '';
        oEl.querySelectorAll('[data-o]').forEach(b => b.onclick = () => { if (oEl.dataset.done) return; oEl.dataset.done = 1; total++; const ok = b.dataset.o === F.name; if (ok) score++; b.style.borderColor = ok ? '#2BB24C' : '#E5484D'; b.style.background = ok ? 'rgba(43,178,76,.15)' : 'rgba(229,72,77,.12)'; if (!ok) oEl.querySelector(`[data-o="${F.name}"]`).style.borderColor = '#2BB24C'; sEl.textContent = `স্কোর: ${bn(score)}/${bn(total)}`; xEl.innerHTML = ok ? '✓ সঠিক!' : `✗ সঠিক উত্তর: <b>${F.name}</b>`; });
        delete oEl.dataset.done;
      };
      body.querySelector('[data-n]').onclick = next; next();
    };
    X.onSeg(el, 'm', k => k === 'b' ? build() : k === 'o' ? ladder() : quiz()); build();
  }
};

/* ======================= ৩.২১.১ জটিল যৌগের নামকরণ ======================= */
const LIG = { NH3: ['অ্যামিন', 'ammine', 0, 'NH₃', 'N'], H2O: ['অ্যাকোয়া', 'aqua', 0, 'H₂O', 'O'], Cl: ['ক্লোরো', 'chloro', -1, 'Cl', 'Cl'], CN: ['সায়ানো', 'cyano', -1, 'CN', 'C'], CO: ['কার্বনিল', 'carbonyl', 0, 'CO', 'C'], OH: ['হাইড্রক্সো', 'hydroxo', -1, 'OH', 'O'], F: ['ফ্লুরো', 'fluoro', -1, 'F', 'F'], I: ['আয়োডো', 'iodo', -1, 'I', 'I'] };
const MET = { Fe: ['আয়রন', 'ফেরেট'], Co: ['কোবাল্ট', 'কোবাল্টেট'], Cu: ['কপার', 'কিউপ্রেট'], Ag: ['সিলভার', 'আর্জেন্টেট'], Ni: ['নিকেল', 'নিকেলেট'], Pt: ['প্লাটিনাম', 'প্লাটিনেট'], Cr: ['ক্রোমিয়াম', 'ক্রোমেট'], Zn: ['জিংক', 'জিংকেট'], Al: ['অ্যালুমিনিয়াম', 'অ্যালুমিনেট'], Hg: ['মারকারি', 'মারকিউরেট'] };
const PRE = ['', 'মনো', 'ডাই', 'ট্রাই', 'টেট্রা', 'পেন্টা', 'হেক্সা'];
// [label, outer cation [sym,name,count,charge] | null, metal, ligands {k:n}, outer anion [formula,name,count,charge] | null]
const CX = [
  ['K₄[Fe(CN)₆]', ['K', 'পটাসিয়াম', 4, 1], 'Fe', { CN: 6 }, null],
  ['K₃[Fe(CN)₆]', ['K', 'পটাসিয়াম', 3, 1], 'Fe', { CN: 6 }, null],
  ['[Cu(NH₃)₄]SO₄', null, 'Cu', { NH3: 4 }, ['SO₄', 'সালফেট', 1, 2]],
  ['[Ag(NH₃)₂]Cl', null, 'Ag', { NH3: 2 }, ['Cl', 'ক্লোরাইড', 1, 1]],
  ['[Co(NH₃)₆]Cl₃', null, 'Co', { NH3: 6 }, ['Cl', 'ক্লোরাইড', 3, 1]],
  ['[Co(NH₃)₅Cl]Cl₂', null, 'Co', { NH3: 5, Cl: 1 }, ['Cl', 'ক্লোরাইড', 2, 1]],
  ['[Cr(H₂O)₆]Cl₃', null, 'Cr', { H2O: 6 }, ['Cl', 'ক্লোরাইড', 3, 1]],
  ['[Pt(NH₃)₂Cl₂]', null, 'Pt', { NH3: 2, Cl: 2 }, null],
  ['[Ni(CO)₄]', null, 'Ni', { CO: 4 }, null],
  ['Na₃[AlF₆]', ['Na', 'সোডিয়াম', 3, 1], 'Al', { F: 6 }, null],
  ['Na[Al(OH)₄]', ['Na', 'সোডিয়াম', 1, 1], 'Al', { OH: 4 }, null],
  ['K₂[HgI₄]', ['K', 'পটাসিয়াম', 2, 1], 'Hg', { I: 4 }, null]
];
V.c3_complexName = {
  t: 'জটিল যৌগের নামকরণ: ধাপে ধাপে বিশ্লেষণ', k: ['2d', 'int'],
  cap: 'জটিল যৌগ বেছে নাও। উপরের চিত্রে কেন্দ্রীয় ধাতু (কমলা) ও তার চারপাশে লিগ্যান্ডগুলো সন্নিবেশ বন্ধনে (তীর: দাতা পরমাণু → ধাতু) যুক্ত; সন্নিবেশ সংখ্যা অনুযায়ী আকৃতি (২ রৈখিক, ৪ বর্গাকার/চতুস্তলকীয়, ৬ অষ্টতলকীয়)। নিচে নামটি রঙ দিয়ে টুকরো টুকরো করে দেখানো হয়েছে এবং ধাপগুলো: (১) জটিল আয়নের চার্জ, (২) ধাতুর জারণ সংখ্যা, (৩) লিগ্যান্ড বর্ণানুক্রমে ও সংখ্যাবাচক উপসর্গ, (৪) অ্যানায়নিক হলে "-এট"।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><select class="inp" data-c style="flex:1">${CX.map((c, i) => `<option value="${i}">${c[0]}</option>`).join('')}</select></div><div data-svg></div><div class="calc-out" data-name style="font-size:16px;line-height:1.9"></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const sel = el.querySelector('[data-c]'), box = el.querySelector('[data-svg]'), nm = el.querySelector('[data-name]'), out = el.querySelector('[data-out]');
    const COL = { cat: '#7E57C2', num: '#C08A1E', lig: '#2F86D6', met: '#E8775C', ox: '#2BB24C', an: '#D63384' };
    const run = () => {
      const [lab, oc, M, L, oa] = CX[+sel.value];
      const ligs = Object.keys(L).sort((a, b) => LIG[a][1].localeCompare(LIG[b][1]));
      const cn = ligs.reduce((t, k) => t + L[k], 0), lc = ligs.reduce((t, k) => t + L[k] * LIG[k][2], 0);
      const ionQ = oc ? -oc[2] * oc[3] : oa ? oa[2] * oa[3] : 0, ox = ionQ - lc, anionic = ionQ < 0;
      // drawing
      const cx = 200, cy = 104, R = 62; let s = `<defs>${X.arrowC('c3cx', '#E5484D')}</defs>`;
      const list = []; ligs.forEach(k => { for (let i = 0; i < L[k]; i++) list.push(k); });
      const pos = cn === 2 ? [[-1, 0], [1, 0]] : cn === 4 ? [[-1, 0], [1, 0], [0, -1], [0, 1]] : [[-1, 0], [1, 0], [0, -1], [0, 1], [-0.7, 0.72], [0.7, -0.72]];
      list.forEach((k, i) => { const [px, py] = pos[i]; const x = cx + px * R, y = cy + py * R * 0.95, back = cn === 6 && i === 5; const dx = cx - x, dy = cy - y, Ld = Math.hypot(dx, dy); s += `<line x1="${f1(x + dx / Ld * 18)}" y1="${f1(y + dy / Ld * 18)}" x2="${f1(cx - dx / Ld * 20)}" y2="${f1(cy - dy / Ld * 20)}" stroke="#E5484D" stroke-width="2" marker-end="url(#c3cx)" ${back ? 'stroke-dasharray="4 3"' : ''}/><g opacity="${back ? 0.75 : 1}"><circle cx="${f1(x)}" cy="${f1(y)}" r="17" fill="${CPK[LIG[k][4]] || '#999'}" stroke="rgba(0,0,0,.3)"/><text x="${f1(x)}" y="${f1(y + 4)}" text-anchor="middle" style="font-size:${LIG[k][3].length > 2 ? 9.5 : 11}px;font-weight:700;fill:${['N', 'O', 'C', 'Cl', 'I'].includes(LIG[k][4]) ? '#fff' : INK}">${LIG[k][3]}</text></g>`; });
      s += `<circle cx="${cx}" cy="${cy}" r="20" fill="#E9A53B" stroke="#B9790C" stroke-width="1.5"/><text x="${cx}" y="${cy + 5}" text-anchor="middle" style="font-size:13px;font-weight:700;fill:${INK}">${M}</text>`;
      s += `<path d="M${cx - R - 34} ${cy - R - 12} L${cx - R - 42} ${cy - R - 12} L${cx - R - 42} ${cy + R + 12} L${cx - R - 34} ${cy + R + 12}" fill="none" class="s-mu" stroke-width="1.6"/><path d="M${cx + R + 34} ${cy - R - 12} L${cx + R + 42} ${cy - R - 12} L${cx + R + 42} ${cy + R + 12} L${cx + R + 34} ${cy + R + 12}" fill="none" class="s-mu" stroke-width="1.6"/><text x="${cx + R + 46}" y="${cy - R - 2}" style="font-size:13px;font-weight:700">${ionQ === 0 ? '0' : Math.abs(ionQ) + (ionQ > 0 ? '+' : '−')}</text>`;
      s += `<text x="${cx}" y="${cy + R + 34}" text-anchor="middle" class="tm" style="font-size:10.5px">সন্নিবেশ সংখ্যা ${bn(cn)} · ${cn === 2 ? 'রৈখিক' : cn === 4 ? (M === 'Pt' || M === 'Cu' ? 'বর্গাকার সমতলীয়' : 'চতুস্তলকীয় (দ্বিমাত্রিক অভিক্ষেপ)') : 'অষ্টতলকীয়'}</text>`;
      box.innerHTML = X.svg(400, cy + R + 44, s, 'জটিল আয়ন');
      // name
      const sp = (t, c) => `<span style="color:${c};font-weight:700">${t}</span>`;
      let n = '';
      if (oc) n += sp(oc[1], COL.cat) + ' ';
      ligs.forEach(k => { n += (L[k] > 1 ? sp(PRE[L[k]], COL.num) : '') + sp(LIG[k][0], COL.lig); });
      n += sp(anionic ? MET[M][1] : MET[M][0], COL.met) + sp(`(${ox === 0 ? '0' : ROM[ox]})`, COL.ox);
      if (oa) n += ' ' + sp(oa[1], COL.an);
      nm.innerHTML = `<div class="small muted">IUPAC নাম</div>${n}`;
      out.innerHTML = `১. জটিল আয়নের চার্জ: ${oc ? `${oc[2]}টি ${oc[0]}⁺ এর চার্জ +${oc[2] * oc[3]}, তাই জটিল আয়ন = <b>${ionQ}</b>` : oa ? `${oa[2]}টি ${oa[0]} এর চার্জ −${oa[2] * oa[3]}, তাই জটিল আয়ন = <b>+${ionQ}</b>` : 'বাইরে কোনো আয়ন নেই — জটিলটি <b>নিরপেক্ষ</b>'}<br>২. ধাতুর জারণ সংখ্যা: x + (${ligs.map(k => `${L[k]} × ${LIG[k][2]}`).join(' + ')}) = ${ionQ} ⇒ <b>x = ${ox >= 0 ? '+' : ''}${ox}</b><br>৩. লিগ্যান্ড বর্ণানুক্রমে (ইংরেজি নামে: ${ligs.map(k => LIG[k][1]).join(', ')}) ও উপসর্গ (ডাই, টেট্রা, হেক্সা…)<br>৪. ${anionic ? `জটিল আয়ন <b>অ্যানায়ন</b> — ধাতুর নাম + "-এট": ${MET[M][0]} → <b>${MET[M][1]}</b>` : `জটিল আয়ন ${ionQ > 0 ? 'ক্যাটায়ন' : 'নিরপেক্ষ'} — ধাতুর সাধারণ নাম <b>${MET[M][0]}</b>`}`;
    };
    sel.onchange = run; run();
  }
};

/* ======================= সারসংক্ষেপ: ধারণা মানচিত্র ======================= */
const CM = [
  ['ইলেকট্রন বিন্যাস', '৩.১.১', 'আউফবাউ, হুন্ড, পাউলি; Cr ও Cu এর ব্যতিক্রম', 'O: 1s² 2s² 2p⁴ · S: [Ne] 3s² 3p⁴'],
  ['পর্যায় সারণিতে অবস্থান', '৩.১–৩.২', 'পর্যায় = সর্বোচ্চ n; ব্লক = শেষ উপস্তর; গ্রুপ নির্ণয়ের নিয়ম', 'O: পর্যায় ২, গ্রুপ ১৬ · S: পর্যায় ৩, গ্রুপ ১৬'],
  ['পর্যায়বৃত্ত ধর্ম', '৩.৩–৩.৬', 'আকার, IE, EA, EN; Zeff ও আবরণ; ব্যতিক্রম; অক্সাইডের প্রকৃতি', 'O: 73 pm, EN 3.44 · S: 104 pm, EN 2.58'],
  ['বন্ধনের ধরন', '৩.৭, ৩.১৩–৩.১৪', 'ΔEN থেকে আয়নিক/সমযোজী/ধাতব; সন্নিবেশ বন্ধন', 'H₂O ও H₂S দুটিই পোলার সমযোজী'],
  ['সংকরণ ও আকৃতি', '৩.৮–৩.১২', 'VBT, σ ও π; sp, sp², sp³…; VSEPR, H = ½(V+M−C+A)', 'H₂O: sp³, কৌণিক 104.5° · H₂S: 92°'],
  ['পোলারিটি', '৩.১৫–৩.১৬', 'বন্ধন ও আণবিক পোলারিটি, μ = q × d, ফাজানস নীতি, কর্ণ সম্পর্ক', 'μ: H₂O 1.85 D · H₂S 0.97 D'],
  ['আন্তঃআণবিক বল', '৩.১৭–৩.২০', 'লন্ডন, ডাইপোল-ডাইপোল, H-বন্ধন (F, O, N)', 'H₂O: H-বন্ধন (৪টি) · H₂S: শুধু ভ্যানডার ওয়ালস'],
  ['ভৌত ধর্ম', '৩.১৭–৩.২০', 'গলনাঙ্ক, স্ফুটনাঙ্ক, দ্রাব্যতা, সান্দ্রতা, ঘনত্ব', 'H₂O তরল (100 °C) · H₂S গ্যাস (−60 °C)']
];
V.c3_conceptMap = {
  t: 'অধ্যায়ের ধারণা মানচিত্র: বিন্যাস থেকে ভৌত ধর্ম', k: ['info', 'int'],
  cap: 'পুরো অধ্যায় একটি শৃঙ্খল: প্রতিটি ধাপ পরের ধাপকে নির্ধারণ করে। যেকোনো ঘরে চাপ দিলে সেই ধাপের মূল ধারণা ও অনুচ্ছেদ নম্বর দেখাবে। "O বনাম S উদাহরণ" চালু করলে প্রতিটি ঘরের পাশে পানি ও হাইড্রোজেন সালফাইডের তুলনা দেখাবে — একই গ্রুপ, অথচ একটি তরল ও একটি গ্যাস; শৃঙ্খল ধরে কারণটা খুঁজে পাওয়া যায়। নামকরণ (৩.২১) এ শৃঙ্খলের পাশের একটি স্বতন্ত্র দক্ষতা।',
  html: () => `<div class="ctl" style="margin:0 0 6px"><button class="btn sm" data-ex>O বনাম S উদাহরণ</button></div><div data-svg></div><div class="calc-out" data-out></div>`,
  mount(el) {
    const box = el.querySelector('[data-svg]'), out = el.querySelector('[data-out]'); let ex = false, sel = 4;
    const cols = ['#5B9BD5', '#4FB6C9', '#5FB09A', '#9CC36B', '#E9A53B', '#E8775C', '#D16BA5', '#8E7CC3'];
    const draw = () => {
      const bw = ex ? 168 : 232, bh = 34, gx = ex ? 14 : 84, gy = 10, step = 46; let s = `<defs>${X.arrow('c3cm')}</defs>`;
      CM.forEach(([t, sec, , e], i) => {
        const y = gy + i * step, on = i === sel;
        s += `<g data-i="${i}" style="cursor:pointer"><rect x="${gx}" y="${y}" width="${bw}" height="${bh}" rx="9" fill="${cols[i]}" opacity="${on ? 1 : 0.82}" ${on ? 'stroke="var(--fg)" stroke-width="2.2"' : ''}/><text x="${gx + 12}" y="${y + 22}" style="font-size:13px;font-weight:700;fill:${INK}">${t}</text><text x="${gx + bw - 10}" y="${y + 22}" text-anchor="end" class="mono" style="font-size:9.5px;fill:${INK}">${sec}</text></g>`;
        if (i < CM.length - 1) s += `<line x1="${gx + bw / 2}" y1="${y + bh + 1}" x2="${gx + bw / 2}" y2="${y + step - 2}" class="s-fg" stroke-width="1.6" marker-end="url(#c3cm)"/>`;
        if (ex) { const [a, b] = e.split(' · '); s += `<text x="${gx + bw + 10}" y="${y + 14}" style="font-size:10px">${a}</text><text x="${gx + bw + 10}" y="${y + 29}" class="tm" style="font-size:10px">${b || ''}</text>`; }
      });
      const ny = gy + CM.length * step + 6;
      s += `<rect x="${gx}" y="${ny}" width="${bw}" height="30" rx="9" fill="none" class="s-mu" stroke-dasharray="4 3"/><text x="${gx + bw / 2}" y="${ny + 19}" text-anchor="middle" style="font-size:12px">পাশের দক্ষতা: নামকরণ (৩.২১)</text>`;
      box.innerHTML = X.svg(400, ny + 36, s, 'ধারণা মানচিত্র');
      const [t, sec, d, e] = CM[sel]; out.innerHTML = `<b>${t}</b> <span class="small muted">(${sec})</span><br>${d}<br><span class="small">উদাহরণ: ${e}</span>`;
    };
    box.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g) { sel = +g.dataset.i; draw(); } });
    el.querySelector('[data-ex]').onclick = function () { ex = !ex; this.classList.toggle('primary', ex); draw(); };
    draw();
  }
};

/* ======================= অনুশীলনী: প্রবণতা সাজানোর খেলা ======================= */
const TQ = [
  ['প্রথম আয়নীকরণ শক্তির ঊর্ধ্বক্রমে সাজাও', ['Na', 'Mg', 'Al', 'Si'], ['Na', 'Al', 'Mg', 'Si'], 'Na 496 < Al 578 < Mg 738 < Si 787 — Al ব্যতিক্রম (3p ইলেকট্রন সহজে সরে)।'],
  ['প্রথম আয়নীকরণ শক্তির ঊর্ধ্বক্রমে সাজাও', ['C', 'N', 'O', 'F'], ['C', 'O', 'N', 'F'], 'C 1086 < O 1314 < N 1402 < F 1681 — N এর অর্ধপূর্ণ 2p³।'],
  ['পারমাণবিক ব্যাসার্ধের ঊর্ধ্বক্রমে সাজাও', ['K', 'Na', 'Mg', 'Li'], ['Li', 'Mg', 'Na', 'K'], 'Li 152 < Mg 160 < Na 186 < K 227 pm।'],
  ['আয়নিক ব্যাসার্ধের ঊর্ধ্বক্রমে সাজাও', ['O²⁻', 'F⁻', 'Na⁺', 'Mg²⁺'], ['Mg²⁺', 'Na⁺', 'F⁻', 'O²⁻'], 'সমইলেকট্রনীয়: Z বাড়লে আকার কমে — Mg²⁺ 72 < Na⁺ 102 < F⁻ 133 < O²⁻ 140 pm।'],
  ['ইলেকট্রন আসক্তির ঊর্ধ্বক্রমে সাজাও', ['F', 'Cl', 'Br', 'I'], ['I', 'Br', 'F', 'Cl'], 'I 295 < Br 325 < F 328 < Cl 349 kJ mol⁻¹ — F ক্ষুদ্র, ইলেকট্রন বিকর্ষণ বেশি।'],
  ['তড়িৎ ঋণাত্মকতার ঊর্ধ্বক্রমে সাজাও', ['O', 'N', 'Cl', 'F'], ['N', 'Cl', 'O', 'F'], 'N 3.04 < Cl 3.16 < O 3.44 < F 3.98।'],
  ['বন্ধন কোণের ঊর্ধ্বক্রমে সাজাও', ['NH₃', 'H₂O', 'CH₄', 'BF₃'], ['H₂O', 'NH₃', 'CH₄', 'BF₃'], '104.5° < 107° < 109.5° < 120° — নিঃসঙ্গ যুগল কোণ কমায়।'],
  ['বন্ধন কোণের ঊর্ধ্বক্রমে সাজাও', ['H₂S', 'H₂O', 'NH₃', 'PH₃'], ['H₂S', 'PH₃', 'H₂O', 'NH₃'], 'H₂S 92° < PH₃ 93.5° < H₂O 104.5° < NH₃ 107°।'],
  ['সমযোজী বৈশিষ্ট্যের ঊর্ধ্বক্রমে সাজাও', ['NaCl', 'MgCl₂', 'AlCl₃', 'KCl'], ['KCl', 'NaCl', 'MgCl₂', 'AlCl₃'], 'ক্যাটায়নের আয়নিক বিভব বাড়ে: K⁺ < Na⁺ < Mg²⁺ < Al³⁺ (ফাজানস নীতি)।'],
  ['সমযোজী বৈশিষ্ট্যের ঊর্ধ্বক্রমে সাজাও', ['LiF', 'LiCl', 'LiBr', 'LiI'], ['LiF', 'LiCl', 'LiBr', 'LiI'], 'অ্যানায়ন যত বড়, পোলারায়ন তত বেশি: F⁻ < Cl⁻ < Br⁻ < I⁻।'],
  ['ডাইপোল মোমেন্টের ঊর্ধ্বক্রমে সাজাও', ['NH₃', 'NF₃', 'H₂O', 'CO₂'], ['CO₂', 'NF₃', 'NH₃', 'H₂O'], 'CO₂ 0 < NF₃ 0.23 < NH₃ 1.47 < H₂O 1.85 D।'],
  ['স্ফুটনাঙ্কের ঊর্ধ্বক্রমে সাজাও', ['HF', 'HCl', 'HBr', 'HI'], ['HCl', 'HBr', 'HI', 'HF'], 'HCl −85 < HBr −67 < HI −35 < HF 20 °C — HF এ H-বন্ধন।'],
  ['স্ফুটনাঙ্কের ঊর্ধ্বক্রমে সাজাও', ['H₂O', 'H₂S', 'H₂Se', 'H₂Te'], ['H₂S', 'H₂Se', 'H₂Te', 'H₂O'], '−60 < −41 < −2 < 100 °C — পানিতে H-বন্ধন।'],
  ['স্ফুটনাঙ্কের ঊর্ধ্বক্রমে সাজাও', ['n-পেন্টেন', 'নিওপেন্টেন', 'আইসোপেন্টেন'], ['নিওপেন্টেন', 'আইসোপেন্টেন', 'n-পেন্টেন'], '9.5 < 28 < 36 °C — শাখা বাড়লে স্পর্শতল ও লন্ডন বল কমে।'],
  ['s-চরিত্রের ঊর্ধ্বক্রমে সাজাও', ['sp²', 'sp³', 'sp'], ['sp³', 'sp²', 'sp'], '25% < 33% < 50%।'],
  ['অক্সো-এসিডের অম্লশক্তির ঊর্ধ্বক্রমে সাজাও', ['HClO₃', 'HClO', 'HClO₄', 'HClO₂'], ['HClO', 'HClO₂', 'HClO₃', 'HClO₄'], 'O ও Cl এর জারণ সংখ্যা বাড়লে অম্লত্ব বাড়ে।']
];
V.c3_trendQuiz = {
  t: 'প্রবণতা সাজানোর চ্যালেঞ্জ: ঊর্ধ্বক্রমে সাজাও', k: ['int'],
  cap: 'প্রতিটি প্রশ্নে কয়েকটি চিপ দেওয়া আছে — যে ক্রমে চাপবে সে ক্রমে নিচের সারিতে বসবে (সবচেয়ে কম মানেরটি প্রথমে)। ভুল হলে "আবার" চাপো। "যাচাই করো" চাপলে সঠিক ক্রম, প্রকৃত মান ও ব্যতিক্রমের কারণ দেখাবে। এ অধ্যায়ের প্রায় সব ক্রমবিন্যাস প্রশ্ন এখানে আছে — পরীক্ষার আগে একবার খেলে নাও।',
  html: () => `<div class="calc-out" data-q style="font-size:15.5px"></div><div class="small muted" style="margin-top:8px">চিপগুলো ক্রমানুসারে চাপো:</div><div data-pool style="display:flex;flex-wrap:wrap;gap:6px;margin-top:4px;min-height:44px"></div><div class="small muted" style="margin-top:8px">তোমার ক্রম (কম → বেশি):</div><div data-ans style="display:flex;flex-wrap:wrap;gap:6px;margin-top:4px;min-height:44px;padding:6px;border:1.5px dashed var(--line-strong);border-radius:10px"></div><div class="ctl"><button class="btn sm" data-r>আবার</button><button class="btn sm primary" data-c>যাচাই করো</button><button class="btn sm" data-n>পরের প্রশ্ন →</button><span class="small muted" data-s></span></div><div class="calc-out" data-out style="display:none"></div>`,
  mount(el) {
    const q = el.querySelector('[data-q]'), pool = el.querySelector('[data-pool]'), ans = el.querySelector('[data-ans]'), out = el.querySelector('[data-out]'), sc = el.querySelector('[data-s]');
    let i = 0, pick = [], done = false, score = 0, tried = 0; const order = TQ.map((_, k) => k);
    const rnd = X.rng(Date.now() % 9973 + 3); order.sort(() => rnd() - 0.5);
    const chip = (t, on) => `<button class="btn sm" data-t="${t}" style="min-width:56px;${on ? 'opacity:.35' : ''}">${t}</button>`;
    const render = () => {
      const [qq, items] = TQ[order[i]];
      q.innerHTML = `<b>প্রশ্ন ${bn(i + 1)}/${bn(TQ.length)}:</b> ${qq}`;
      pool.innerHTML = items.map(t => chip(t, pick.includes(t))).join('');
      ans.innerHTML = pick.map((t, k) => `<span class="btn sm" style="pointer-events:none;background:var(--accent-soft);border-color:var(--accent)">${bn(k + 1)}. ${t}</span>`).join('') || '<span class="small muted">এখনও কিছু বেছে নেওয়া হয়নি</span>';
      pool.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { if (done || pick.includes(b.dataset.t)) return; pick.push(b.dataset.t); render(); });
      sc.textContent = tried ? `স্কোর: ${bn(score)}/${bn(tried)}` : '';
    };
    const check = () => {
      const [, items, corr, why] = TQ[order[i]]; if (pick.length < items.length || done) { if (!done) { out.style.display = ''; out.innerHTML = 'সবগুলো চিপ ক্রমানুসারে বেছে নাও।'; } return; }
      done = true; tried++; const ok = pick.every((t, k) => t === corr[k]); if (ok) score++;
      out.style.display = ''; out.innerHTML = `${ok ? '<b style="color:#2BB24C">✓ সঠিক!</b>' : '<b style="color:#E5484D">✗ হয়নি।</b>'} সঠিক ক্রম: <b>${corr.join(' &lt; ')}</b><br>${why}`;
      render();
    };
    el.querySelector('[data-r]').onclick = () => { pick = []; done = false; out.style.display = 'none'; render(); };
    el.querySelector('[data-c]').onclick = check;
    el.querySelector('[data-n]').onclick = () => { i = (i + 1) % TQ.length; pick = []; done = false; out.style.display = 'none'; render(); };
    render();
  }
};
})();
