/* ═══════════════════════════════════════════════════════════════════════
   CORE · HSC রেজিস্ট্রি — সব অধ্যায় এখানে নিবন্ধিত হয়
   ───────────────────────────────────────────────────────────────────────
   ফাইলের কাঠামো (ওপর থেকে নিচে):
     ১. CORE  — স্টাইল, এই রেজিস্ট্রি, ভিজ্যুয়াল টুলকিট (VX), অ্যাপ ইঞ্জিন
     ২. CHAPTER BLOCKS — প্রতিটি অধ্যায় আলাদা <script> ব্লকে
     ৩. "নতুন অধ্যায় এখানে যোগ করো" চিহ্নিত জায়গা — ফাইলের একেবারে শেষে

   অ্যাপ ইঞ্জিন পৃষ্ঠা পুরো লোড হওয়ার পর (DOMContentLoaded) চালু হয়,
   তাই ফাইলের শেষে যোগ করা যেকোনো অধ্যায় আপনাআপনি অ্যাপে চলে আসে।

   একটি অধ্যায় যোগ করার নিয়ম:
     HSC.chapter({ id:'c3', paper:'১ম পত্র', no:'৩', order:3, t:'অধ্যায়ের নাম',
                   cats:{ A:'…', B:'…', C:'…', D:'…', E:'পুনরালোচনা' } });
     SEC.push({ …অংশ… });          // যত খুশি অংশ — নিজে থেকেই এই অধ্যায়ে যুক্ত হয়
     VIS.myVisual = { … };          // (ঐচ্ছিক) চিত্র/সিমুলেশন
     CMPT.push({ … });              // (ঐচ্ছিক) পার্থক্য সারণির তালিকা
     HSC.more('c3s1', { L:[…] });   // (ঐচ্ছিক) আগের অংশে আরও পাঠ/প্রশ্ন যোগ
   বিস্তারিত ছাঁচ ফাইলের শেষে দেওয়া আছে।

   নিয়ম: সব id (অধ্যায়, অংশ, পাঠ, চিত্র) পুরো ফাইলে অনন্য হতে হবে।
   পরামর্শ: অধ্যায়ের id দিয়ে শুরু করো — যেমন 'c3s1', 'c3s1a', 'c3_orbitalFill'।
   (অধ্যায় ২ এর id গুলো পুরোনো — s1, s1a … — অগ্রগতি ধরে রাখতে বদলানো হয়নি।)
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const H = window.HSC = { version: '2.0', chapters: [], cur: null, problems: [] };
const warn = m => { H.problems.push(m); try { console.warn('[HSC] ' + m); } catch (e) { } };
H.warn = warn;

/* অধ্যায় ঘোষণা — এর পরে যত SEC.push হবে সব এই অধ্যায়ের */
H.chapter = function (meta) {
  if (!meta || !meta.id) { warn('HSC.chapter(): id ছাড়া অধ্যায় ঘোষণা উপেক্ষা করা হলো'); return null; }
  const old = H.chapters.find(c => c.id === meta.id);
  if (old) { warn('অধ্যায় id "' + meta.id + '" একাধিকবার ঘোষণা করা হয়েছে — প্রথমটির সাথে যুক্ত করা হলো'); H.cur = old; return old; }
  const c = Object.assign({ paper: '১ম পত্র', no: '?', t: meta.id, order: H.chapters.length + 1, cats: {} }, meta);
  if (!c.paperNo) c.paperNo = /২|2/.test(c.paper) ? 2 : 1;
  if (!c.subject) c.subject = 'chem' + c.paperNo;   /* বিষয় না দিলে পত্র থেকে ধরা হয় */
  H.chapters.push(c); H.cur = c; return c;
};

/* বিষয় (subject) ঘোষণা — ভবিষ্যতে অন্য বিষয় যোগ করতে:
   HSC.subject({ id:'phy1', t:'পদার্থবিজ্ঞান ১ম পত্র', group:'পদার্থবিজ্ঞান', order:3, color:'#2d6fd6' });
   তারপর সেই বিষয়ের অধ্যায়ে HSC.chapter({ …, subject:'phy1' }) লেখো। */
H.subjects = [];
H.subject = function (meta) {
  if (!meta || !meta.id) return null;
  const old = H.subjects.find(x => x.id === meta.id); if (old) return Object.assign(old, meta);
  const s = Object.assign({ order: H.subjects.length + 1, group: meta.t }, meta); H.subjects.push(s); return s;
};
H.subject({ id: 'chem1', t: 'রসায়ন ১ম পত্র', group: 'রসায়ন', short: 'রসায়ন ১ম', order: 1, color: '#2f7d6d' });
H.subject({ id: 'chem2', t: 'রসায়ন ২য় পত্র', group: 'রসায়ন', short: 'রসায়ন ২য়', order: 2, color: '#8a5a2b' });

/* অধ্যায় ঘোষণা না করেই কিছু যোগ হলে "অশ্রেণিকৃত" অধ্যায়ে যায় */
let warned = false;
const curCh = () => {
  if (H.cur) return H.cur;
  if (!warned) { warned = true; warn('HSC.chapter(...) ঘোষণার আগেই অংশ যোগ হয়েছে — "অশ্রেণিকৃত" অধ্যায়ে রাখা হলো'); }
  return H.chapter({ id: 'misc', no: '—', paper: 'অন্যান্য', paperNo: 9, t: 'অশ্রেণিকৃত অংশ' });
};
const tag = o => { if (o && typeof o === 'object' && !o.ch) o.ch = curCh().id; return o; };
const taggedList = () => { const a = []; Object.defineProperty(a, 'push', { value: function (...xs) { xs.forEach(tag); return Array.prototype.push.apply(this, xs); } }); return a; };

window.SEC = taggedList();    /* অংশ (section) — SEC.push({...}) */
window.CMPT = taggedList();   /* পার্থক্য সারণির সূচি — CMPT.push({ g, t, l, k }) */
window.EX = {}; window.CMP = {};

/* চিত্রের রেজিস্ট্রি: একই নামে দুবার সংজ্ঞায়িত হলে সতর্কবার্তা */
const store = {};
window.VIS = new Proxy(store, {
  set(t, k, v) {
    if (Object.prototype.hasOwnProperty.call(t, k)) warn('চিত্র "' + String(k) + '" একাধিকবার সংজ্ঞায়িত — শেষেরটি রাখা হলো');
    if (v && typeof v === 'object' && !v.ch && H.cur) v.ch = H.cur.id;
    t[k] = v; return true;
  }
});
window.VX = window.VX || {};

/* বড় অংশকে একাধিক ফাইলে ভাগ করে লেখার জন্য: আগে SEC.push করা অংশে আরও পাঠ/প্রশ্ন যোগ করো
   HSC.more('c3s9', { L:[…], Q:{ mcq:[…], cq:[…] }, F:[…], FM:[…], exam:{ pat:[…], board:[…] } }) */
H.more = function (sid, add) {
  const s = window.SEC.find(x => x && x.id === sid);
  if (!s) { warn('HSC.more(): অংশ "' + sid + '" পাওয়া যায়নি — যোগ করা হলো না'); return null; }
  const cat = (a, b) => (a || []).concat(b || []);
  if (add.L) s.L = cat(s.L, add.L);
  if (add.Q) { s.Q = s.Q || {}; for (const k in add.Q) s.Q[k] = cat(s.Q[k], add.Q[k]); }
  if (add.F) s.F = cat(s.F, add.F);
  if (add.FM) s.FM = cat(s.FM, add.FM);
  if (add.exam) { s.exam = s.exam || {}; for (const k in add.exam) s.exam[k] = cat(s.exam[k], add.exam[k]); }
  return s;
};

/* MCQ উত্তরের অবস্থান সুষম করা (ক/খ/গ/ঘ সমান হারে) — নির্ধারিত (deterministic), প্রতিবার একই ফল।
   বহুপদী (i, ii, iii) প্রশ্ন ও "সবগুলো/কোনোটিই" ধরনের বিকল্প অপরিবর্তিত থাকে। অধ্যায় ২ বাদ (balance:false)। */
const FIXOPT = /^(সবগুলো|কোনোটিই|সব কয়টি|উপরের সবগুলো|সবগুলোই)/;
H.balance = function () {
  const groups = {};
  window.SEC.forEach(s => {
    if (!s || !s.ch || s.ch === 'c2') return; const ch = H.chapters.find(c => c.id === s.ch); if (!ch || ch.balance === false) return;
    const g = groups[s.ch] = groups[s.ch] || [];
    (s.L || []).forEach(l => (l.xm || []).forEach(m => g.push(m))); ((s.Q && s.Q.mcq) || []).forEach(m => g.push(m));
  });
  Object.values(groups).forEach(list => {
    const cnt = [0, 0, 0, 0], free = [];
    list.forEach(m => {
      if (!Array.isArray(m) || !Array.isArray(m[1]) || m[1].length !== 4) return;
      const fixed = m[1].map(o => FIXOPT.test(String(o)));
      if (/<br>\s*i\./.test(m[0]) || fixed[m[2]]) { cnt[m[2]]++; return; }
      free.push([m, fixed]);
    });
    free.forEach(([m, fixed], k) => {
      let t = -1, best = 1e9;
      let h = 7; const str = String(m[0]); for (let c = 0; c < str.length; c++) h = (h * 31 + str.charCodeAt(c)) % 9973;
      for (let j = 0; j < 4; j++) { const q = (j + h) % 4; if (!fixed[q] && cnt[q] < best) { best = cnt[q]; t = q; } }
      if (t < 0) { cnt[m[2]]++; return; }
      if (t !== m[2]) { const o = m[1]; [o[t], o[m[2]]] = [o[m[2]], o[t]]; m[2] = t; }
      cnt[t]++;
    });
  });
};
document.addEventListener('DOMContentLoaded', () => { try { window.__HSC_SRC = '<!doctype html>\n' + document.documentElement.outerHTML; } catch (e) { } try { H.balance(); } catch (e) { warn('balance: ' + e.message); } });

/* সুবিধাজনক বিকল্প নাম */
H.section = s => (window.SEC.push(s), s);
H.compare = (...e) => window.CMPT.push(...e);
H.visual = (k, def) => (window.VIS[k] = def);
})();
